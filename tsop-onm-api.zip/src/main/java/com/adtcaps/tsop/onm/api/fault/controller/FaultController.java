package com.adtcaps.tsop.onm.api.fault.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.util.CollectionUtils;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.adtcaps.tsop.onm.api.authentication.domain.JwtAuthResultDto;
import com.adtcaps.tsop.onm.api.domain.OomFaultDto;
import com.adtcaps.tsop.onm.api.domain.OomUserRoleAuthorityDetailDto;
import com.adtcaps.tsop.onm.api.fault.domain.FaultDetailResultDto;
import com.adtcaps.tsop.onm.api.fault.domain.FaultGridRequestDto;
import com.adtcaps.tsop.onm.api.fault.domain.FaultGridResultDto;
import com.adtcaps.tsop.onm.api.fault.domain.FaultProcessingDto;
import com.adtcaps.tsop.onm.api.fault.service.FaultService;
import com.adtcaps.tsop.onm.api.file.domain.BlobRequestDto;
import com.adtcaps.tsop.onm.api.helper.constant.Const;
import com.adtcaps.tsop.onm.api.helper.domain.ResultDto;
import com.adtcaps.tsop.onm.api.helper.util.CommonObjectUtil;
import com.adtcaps.tsop.onm.api.helper.util.PageUtil;
import com.adtcaps.tsop.onm.api.user.domain.UserRoleMenuAuthorityRequestDto;
import com.adtcaps.tsop.onm.api.user.service.UserRoleService;

import lombok.extern.slf4j.Slf4j;

/**
 * 
 * <ul>
 * <li>업무 그룹명 : tsop-onm-api</li>
 * <li>서브 업무명 : com.adtcaps.tsop.onm.api.fault.controller</li>
 * <li>설  명 : FaultController.java</li>
 * <li>작성일 : 2021. 1. 17.</li>
 * <li>작성자 : jeonyb4</li>
 * </ul>
 */
@Slf4j
@RestController
@RequestMapping("/api/faults")
public class FaultController {
	
	private final String MENU_ID = "ONM0010";
	
	private final String ERR_MSG_NULL_LOGIN_USER_ID = "로그인 사용자ID가 없습니다.";
	private final String ERR_MSG_NULL_MGR_YN = "관리자여부가 없습니다.";
	private final String ERR_MSG_NULL_PAGE_NUMBER = "페이지 번호가 없습니다.";
	private final String ERR_MSG_NULL_SERACH_DATE = "조회기간(From or To)이 없습니다.";
	private final String ERR_MSG_NULL_TENANT_ID = "테넌트ID가 없습니다.";
	private final String ERR_MSG_NULL_ALARM_TYPE_CD = "알람유형코드가 없습니다.";
	private final String ERR_MSG_NULL_FAULT_CONTENT = "장애내용이 없습니다.";
	private final String ERR_MSG_NULL_FAULT_ACTION_STATUS_CD = "장애조치상태코드가 없습니다.";
	private final String ERR_MSG_NULL_FAULT_INFO = "장애 등록정보가 없습니다.";
	private final String ERR_MSG_NULL_LOCAL_FILE_PATH = "로컬파일경로가 없습니다.";
	private final String ERR_MSG_NULL_EVENT_DATETIME = "이벤트일시가 없습니다.";
	
	private final String ERR_MSG_ALREADY_EXIST_FAULT_FOR_ALARM = "해당 알람에 대한 장애 등록정보가 이미 있으므로 저장할 수 없습니다.";
	
	private final String ERR_MSG_NO_AUTH = "권한이 없는 사용자 입니다.";
	private final String ERR_MSG_ATTACH_FILE_DELETE_FAIL = "첨부파일 삭제에 실패하였습니다.";
	private final String ERR_MSG_NULL_SEARCH_RESULT_LIST = "조회 결과가 없습니다.";
	private final String ERR_MSG_CREATE_FAIL = "등록에 실패하였습니다.";
	private final String ERR_MSG_READ_FAIL = "조회에 실패하였습니다.";
	private final String ERR_MSG_UPDATE_FAIL = "수정에 실패하였습니다.";
	private final String ERR_MSG_SMS_SEND_FAIL = "알림톡 발송에 실패하였습니다.";
	
	@Autowired
	private FaultService faultService;
	
	@Autowired
	private UserRoleService userRoleService;
	
	/**
	 * 
	 * listPageFault
	 *
	 * @param faultGridRequestDto
	 * @return ResponseEntity
	 */
	@SuppressWarnings("rawtypes")
    @GetMapping(value="", produces="application/json; charset=UTF-8")
    public ResponseEntity listPageFault(FaultGridRequestDto faultGridRequestDto) throws Exception {
        
    	ResponseEntity<ResultDto> resEntity = null;
		String returnString = "";
    	
		int pageNumber = faultGridRequestDto.getPageNumber();
		if (pageNumber < 1) {
			log.error(">>>>>> pageNumber ERROR:{}", ERR_MSG_NULL_PAGE_NUMBER);
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_PAGE_NUMBER));
			return resEntity;
		}
		String fromDate = faultGridRequestDto.getFromDate();
		String toDate = faultGridRequestDto.getToDate();
		if ("".equals(fromDate) || "".equals(toDate)) {
			log.error(">>>>>> fromDate or toDate ERROR:{}", ERR_MSG_NULL_SERACH_DATE);
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_SERACH_DATE));
			return resEntity;
		}
		
		// 장애 목록 조회....
		Map<String, Object> faultGridResultDtoListMap = new HashMap<String, Object>();
		List<FaultGridResultDto> faultGridResultDtoList = faultService.listPageFault(faultGridRequestDto);
		if (CollectionUtils.isEmpty(faultGridResultDtoList)) {
			returnString = Const.Common.RESULT_CODE.SUCCESS;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_SEARCH_RESULT_LIST, faultGridResultDtoListMap));
		} else {
			returnString = Const.Common.RESULT_CODE.SUCCESS;
			faultGridResultDtoListMap.put(Const.Definition.PAGE.PAGER, PageUtil.getPageInfo(faultGridResultDtoList));
			faultGridResultDtoListMap.put(Const.Definition.PAGE.LISTS, faultGridResultDtoList);
			resEntity = ResponseEntity.ok(new ResultDto(returnString, "", faultGridResultDtoListMap));
		}
    	
    	return resEntity;
    }
	
	/**
	 * 
	 * createFault
	 *
	 * @param reqFaultProcessingDto
	 * @return ResponseEntity
	 */
	@SuppressWarnings("rawtypes")
    @PostMapping(value="", produces="application/json; charset=UTF-8")
    public ResponseEntity createFault(@AuthenticationPrincipal JwtAuthResultDto authResultDto, 
    		@RequestBody FaultProcessingDto reqFaultProcessingDto) throws Exception {
        
    	ResponseEntity<ResultDto> resEntity = null;
		String returnString = "";
    	
		String loginUserId = StringUtils.defaultString(authResultDto.getUserId());
		if ("".equals(loginUserId)) {
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_LOGIN_USER_ID));
			return resEntity;
		}
		String mgrYn = StringUtils.defaultString(authResultDto.getMgrYn());
		if ("".equals(mgrYn)) {
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_MGR_YN));
			return resEntity;
		}
		//String loginUserId = "tsop-admin"; // 이후 세션에서 얻어올 값...
		
		if (!"Y".equals(mgrYn)) {
			String authorityTypeCd = "";
			UserRoleMenuAuthorityRequestDto userRoleMenuAuthorityRequestDto = new UserRoleMenuAuthorityRequestDto();
			userRoleMenuAuthorityRequestDto.setUserId(loginUserId);
			userRoleMenuAuthorityRequestDto.setMenuId(MENU_ID);
			OomUserRoleAuthorityDetailDto rsltOomUserRoleAuthorityDetailDto = userRoleService.readMenuAuthority(userRoleMenuAuthorityRequestDto);
			if (rsltOomUserRoleAuthorityDetailDto != null) {
				authorityTypeCd = StringUtils.defaultString(rsltOomUserRoleAuthorityDetailDto.getAuthorityTypeCd());
			}
			if (!"W".equals(authorityTypeCd)) {
				returnString = Const.Common.RESULT_CODE.FAIL;
				resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NO_AUTH));
				return resEntity;
			}
		}
		
		OomFaultDto reqOomFaultDto = reqFaultProcessingDto.getFaultInfo();
		if (reqOomFaultDto == null) {
			log.error(">>>>>> reqOomFaultDto ERROR:{}", ERR_MSG_NULL_FAULT_INFO);
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_FAULT_INFO));
			return resEntity;
		}
		String tenantId = StringUtils.defaultString(reqOomFaultDto.getTenantId());
		if ("".equals(tenantId)) {
			log.error(">>>>>> tenantId ERROR:{}", ERR_MSG_NULL_TENANT_ID);
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_TENANT_ID));
			return resEntity;
		}
		String onmAlarmTypeCd = StringUtils.defaultString(reqOomFaultDto.getOnmAlarmTypeCd());
		if ("".equals(onmAlarmTypeCd)) {
			log.error(">>>>>> onmAlarmTypeCd ERROR:{}", ERR_MSG_NULL_ALARM_TYPE_CD);
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_ALARM_TYPE_CD));
			return resEntity;
		}
		String faultContent = StringUtils.defaultString(reqOomFaultDto.getFaultContent());
		if ("".equals(faultContent)) {
			log.error(">>>>>> faultContent ERROR:{}", ERR_MSG_NULL_FAULT_CONTENT);
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_FAULT_CONTENT));
			return resEntity;
		}
		String faultActionStatusCd = StringUtils.defaultString(reqOomFaultDto.getFaultActionStatusCd());
		if ("".equals(faultActionStatusCd)) {
			log.error(">>>>>> faultActionStatusCd ERROR:{}", ERR_MSG_NULL_FAULT_ACTION_STATUS_CD);
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_FAULT_ACTION_STATUS_CD));
			return resEntity;
		}
		BlobRequestDto blobRequestDto = reqFaultProcessingDto.getAttachFile();
		if (blobRequestDto != null) {
			String localFilePath = StringUtils.defaultString(blobRequestDto.getLocalFilePath());
			if ("".equals(localFilePath)) {
    			log.error(">>>>>> localFilePath ERROR:{}", ERR_MSG_NULL_LOCAL_FILE_PATH);
				returnString = Const.Common.RESULT_CODE.FAIL;
    			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_LOCAL_FILE_PATH));
    			return resEntity;
    		}
		}
		
		reqOomFaultDto.setAuditId(loginUserId);
		reqOomFaultDto.setRegisterId(loginUserId);
		reqFaultProcessingDto.setFaultInfo(reqOomFaultDto);
		
		// 해당 알람정보로 등록된 장애가 있는지 확인
		int faultCount = CommonObjectUtil.defaultNumber(faultService.readFalutCountForAlarm(reqOomFaultDto));
		if (faultCount > 0) {
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_ALREADY_EXIST_FAULT_FOR_ALARM));
			return resEntity;
		}
		
		// 장애 등록...
		int affectRowCount = faultService.createFault(reqFaultProcessingDto);
		if (affectRowCount < 1) {
			if (affectRowCount < 0) {
				returnString = Const.Common.RESULT_CODE.FAIL;
    			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_SMS_SEND_FAIL, affectRowCount));
			} else {
				returnString = Const.Common.RESULT_CODE.FAIL;
    			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_CREATE_FAIL, affectRowCount));
			}
		} else {
			returnString = Const.Common.RESULT_CODE.SUCCESS;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, "", affectRowCount));
		}
    	
    	return resEntity;
    }
	
	/**
	 * 
	 * readFault
	 *
	 * @param faultId
	 * @param reqOomFaultDto
	 * @return ResponseEntity
	 */
	@SuppressWarnings("rawtypes")
    @GetMapping(value="/{onmFaultId}", produces="application/json; charset=UTF-8")
    public ResponseEntity readFault(@PathVariable("onmFaultId") int onmFaultId) throws Exception {
        
    	ResponseEntity<ResultDto> resEntity = null;
		String returnString = "";
    	
		OomFaultDto reqOomFaultDto = new OomFaultDto();
		reqOomFaultDto.setOnmFaultId(onmFaultId);
		
		FaultDetailResultDto faultDetailResultDto = faultService.readFault(reqOomFaultDto);
		if (faultDetailResultDto == null) {
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_READ_FAIL, faultDetailResultDto));
		} else {
			returnString = Const.Common.RESULT_CODE.SUCCESS;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, "", faultDetailResultDto));
		}
    	
    	return resEntity;
    }
	
	/**
	 * 
	 * deleteFaultAttachFile
	 *
	 * @param faultId
	 * @param attachFileNum
	 * @param reqOomFaultDto
	 * @return ResponseEntity
	 */
	@SuppressWarnings("rawtypes")
    @DeleteMapping(value="/{onmFaultId}/attach-files/{attachFileNum}", produces="application/json; charset=UTF-8")
    public ResponseEntity deleteFaultAttachFile(@AuthenticationPrincipal JwtAuthResultDto authResultDto, 
    		@PathVariable("onmFaultId") int onmFaultId, @PathVariable("attachFileNum") int attachFileNum) throws Exception {
        
    	ResponseEntity<ResultDto> resEntity = null;
		String returnString = "";
		
		String loginUserId = StringUtils.defaultString(authResultDto.getUserId());
		if ("".equals(loginUserId)) {
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_LOGIN_USER_ID));
			return resEntity;
		}
		String mgrYn = StringUtils.defaultString(authResultDto.getMgrYn());
		if ("".equals(mgrYn)) {
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_MGR_YN));
			return resEntity;
		}
		//String loginUserId = "tsop-admin"; // 이후 세션에서 얻어올 값...
		
		if (!"Y".equals(mgrYn)) {
			String authorityTypeCd = "";
			UserRoleMenuAuthorityRequestDto userRoleMenuAuthorityRequestDto = new UserRoleMenuAuthorityRequestDto();
			userRoleMenuAuthorityRequestDto.setUserId(loginUserId);
			userRoleMenuAuthorityRequestDto.setMenuId(MENU_ID);
			OomUserRoleAuthorityDetailDto rsltOomUserRoleAuthorityDetailDto = userRoleService.readMenuAuthority(userRoleMenuAuthorityRequestDto);
			if (rsltOomUserRoleAuthorityDetailDto != null) {
				authorityTypeCd = StringUtils.defaultString(rsltOomUserRoleAuthorityDetailDto.getAuthorityTypeCd());
			}
			if (!"W".equals(authorityTypeCd)) {
				returnString = Const.Common.RESULT_CODE.FAIL;
				resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NO_AUTH));
				return resEntity;
			}
		}
    	
		OomFaultDto reqOomFaultDto = new OomFaultDto();
		reqOomFaultDto.setOnmFaultId(onmFaultId);
		reqOomFaultDto.setAttachFileNum(attachFileNum);
		int affectRowCount = faultService.deleteFaultAttachFile(reqOomFaultDto);
		if (affectRowCount < 1) {
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_ATTACH_FILE_DELETE_FAIL, affectRowCount));
		} else {
			returnString = Const.Common.RESULT_CODE.SUCCESS;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, "", affectRowCount));
		}
    	
    	return resEntity;
    }
	
	/**
	 * 
	 * updateFault
	 *
	 * @param reqFaultProcessingDto
	 * @return ResponseEntity
	 */
	@SuppressWarnings("rawtypes")
    @PutMapping(value="/{onmFaultId}", produces="application/json; charset=UTF-8")
    public ResponseEntity updateFault(@AuthenticationPrincipal JwtAuthResultDto authResultDto, 
    		@PathVariable("onmFaultId") int onmFaultId, @RequestBody FaultProcessingDto reqFaultProcessingDto) throws Exception {
        
    	ResponseEntity<ResultDto> resEntity = null;
		String returnString = "";
    	
		String loginUserId = StringUtils.defaultString(authResultDto.getUserId());
		if ("".equals(loginUserId)) {
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_LOGIN_USER_ID));
			return resEntity;
		}
		String mgrYn = StringUtils.defaultString(authResultDto.getMgrYn());
		if ("".equals(mgrYn)) {
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_MGR_YN));
			return resEntity;
		}
		//String loginUserId = "tsop-admin"; // 이후 세션에서 얻어올 값...
		
		if (!"Y".equals(mgrYn)) {
			String authorityTypeCd = "";
			UserRoleMenuAuthorityRequestDto userRoleMenuAuthorityRequestDto = new UserRoleMenuAuthorityRequestDto();
			userRoleMenuAuthorityRequestDto.setUserId(loginUserId);
			userRoleMenuAuthorityRequestDto.setMenuId(MENU_ID);
			OomUserRoleAuthorityDetailDto rsltOomUserRoleAuthorityDetailDto = userRoleService.readMenuAuthority(userRoleMenuAuthorityRequestDto);
			if (rsltOomUserRoleAuthorityDetailDto != null) {
				authorityTypeCd = StringUtils.defaultString(rsltOomUserRoleAuthorityDetailDto.getAuthorityTypeCd());
			}
			if (!"W".equals(authorityTypeCd)) {
				returnString = Const.Common.RESULT_CODE.FAIL;
				resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NO_AUTH));
				return resEntity;
			}
		}
		
		OomFaultDto reqOomFaultDto = reqFaultProcessingDto.getFaultInfo();
		if (reqOomFaultDto == null) {
			log.error(">>>>>> reqOomFaultDto ERROR:{}", ERR_MSG_NULL_FAULT_INFO);
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_FAULT_INFO));
			return resEntity;
		}
		String faultContent = StringUtils.defaultString(reqOomFaultDto.getFaultContent());
		if ("".equals(faultContent)) {
			log.error(">>>>>> faultContent ERROR:{}", ERR_MSG_NULL_FAULT_CONTENT);
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_FAULT_CONTENT));
			return resEntity;
		}
		String faultActionStatusCd = StringUtils.defaultString(reqOomFaultDto.getFaultActionStatusCd());
		if ("".equals(faultActionStatusCd)) {
			log.error(">>>>>> faultActionStatusCd ERROR:{}", ERR_MSG_NULL_FAULT_ACTION_STATUS_CD);
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_FAULT_ACTION_STATUS_CD));
			return resEntity;
		}
		BlobRequestDto blobRequestDto = reqFaultProcessingDto.getAttachFile();
		if (blobRequestDto != null) {
			String localFilePath = StringUtils.defaultString(blobRequestDto.getLocalFilePath());
			if ("".equals(localFilePath)) {
    			log.error(">>>>>> localFilePath ERROR:{}", ERR_MSG_NULL_LOCAL_FILE_PATH);
				returnString = Const.Common.RESULT_CODE.FAIL;
    			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_LOCAL_FILE_PATH));
    			return resEntity;
    		}
		}
		
		reqOomFaultDto.setOnmFaultId(onmFaultId);
		reqOomFaultDto.setAuditId(loginUserId);
		reqFaultProcessingDto.setFaultInfo(reqOomFaultDto);
		
		// 장애 수정...
		int affectRowCount = faultService.updateFault(reqFaultProcessingDto);
		if (affectRowCount < 1) {
			if (affectRowCount < 0) {
				returnString = Const.Common.RESULT_CODE.FAIL;
    			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_SMS_SEND_FAIL, affectRowCount));
			} else {
				returnString = Const.Common.RESULT_CODE.FAIL;
    			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_UPDATE_FAIL, affectRowCount));
			}
		} else {
			returnString = Const.Common.RESULT_CODE.SUCCESS;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, "", affectRowCount));
		}
    	
    	return resEntity;
    }
	
	/**
	 * 
	 * readFaultDuplicationCheck
	 *
	 * @param onmAlarmEventId
	 * @param reqOomFaultDto
	 * @return ResponseEntity
	 */
	@SuppressWarnings("rawtypes")
    @GetMapping(value="/alarm-events/{onmAlarmEventId}", produces="application/json; charset=UTF-8")
    public ResponseEntity readFaultDuplicationCheck(@PathVariable("onmAlarmEventId") int onmAlarmEventId, OomFaultDto reqOomFaultDto) throws Exception {
        
    	ResponseEntity<ResultDto> resEntity = null;
		String returnString = "";
    	
		String eventDatetime = StringUtils.defaultString(reqOomFaultDto.getEventDatetime());
		if ("".equals(eventDatetime)) {
			log.error(">>>>>> eventDatetime ERROR:{}", ERR_MSG_NULL_EVENT_DATETIME);
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_EVENT_DATETIME));
			return resEntity;
		}
		
		reqOomFaultDto.setOnmAlarmEventId(onmAlarmEventId);
		
		FaultDetailResultDto faultDetailResultDto = faultService.readOomFaultDuplicationCheck(reqOomFaultDto);
		if (faultDetailResultDto == null) {
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_READ_FAIL, faultDetailResultDto));
		} else {
			returnString = Const.Common.RESULT_CODE.SUCCESS;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, "", faultDetailResultDto));
		}
    	
    	return resEntity;
    }

}
