package com.adtcaps.tsop.onm.api.alimTalk.domain;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class AlimTalkResponseDto {
	private String msgIdx;
	private String responseCode;
	private String msg;
}
