package com.adtcaps.tsop.onm.api.dashboard.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;

import com.adtcaps.tsop.onm.api.dashboard.domain.DashboardHttpErrResultDto;
import com.adtcaps.tsop.onm.api.dashboard.domain.DashboardHttpResponseResultDto;
import com.adtcaps.tsop.onm.api.dashboard.domain.DashboardRequestDto;

/**
 * 
 * <ul>
 * <li>업무 그룹명 : tsop-onm-api</li>
 * <li>서브 업무명 : com.adtcaps.tsop.onm.api.dashboard.mapper</li>
 * <li>설  명 : OomWebappResourceMetricHistMapper.java</li>
 * <li>작성일 : 2021. 2. 1.</li>
 * <li>작성자 : song</li>
 * </ul>
 */
@Mapper
public interface OomWebappResourceMetricHistMapper {
	
	public List<DashboardHttpErrResultDto> listDashboardHttpErrResult(DashboardRequestDto reqDashboardDto);
	public List<DashboardHttpResponseResultDto> listDashboardHttpResponseResult(DashboardRequestDto reqDashboardDto);
	
}
