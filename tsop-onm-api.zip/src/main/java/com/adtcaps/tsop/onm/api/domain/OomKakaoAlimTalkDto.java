package com.adtcaps.tsop.onm.api.domain;

import lombok.Getter;
import lombok.Setter;

/**
 * 
 * <ul>
 * <li>업무 그룹명 : tsop-onm-api</li>
 * <li>서브 업무명 : com.adtcaps.tsop.onm.api.domain</li>
 * <li>설  명 : OomKakaoAlimTalkDto.java</li>
 * <li>작성일 : 2022. 1. 8.</li>
 * <li>작성자 : jeonyb4</li>
 * </ul>
 */
@Getter
@Setter
public class OomKakaoAlimTalkDto {
	private String tmpltCode;
	private String smsCreateCd;
	private String smsCreateCdName;
	private String title;
	private String message;
	private String attach;
	private String attachName;
	private String supplement;
	private String auditDatetime;
	private String auditId;
	private String auditName;
	private String contactNetworkName;

}
