package com.adtcaps.tsop.onm.api.board.service;

import java.util.List;

import com.adtcaps.tsop.onm.api.board.domain.BulletinboardDetailResultDto;
import com.adtcaps.tsop.onm.api.board.domain.BulletinboardGridRequestDto;
import com.adtcaps.tsop.onm.api.board.domain.BulletinboardGridResultDto;
import com.adtcaps.tsop.onm.api.board.domain.BulletinboardProcessingDto;
import com.adtcaps.tsop.onm.api.board.domain.DeleteBulletinboardRequestDto;
import com.adtcaps.tsop.onm.api.domain.OomBulletinboardDto;
import com.adtcaps.tsop.onm.api.helper.domain.ResultDto;

/**
 * 
 * <ul>
 * <li>업무 그룹명 : tsop-onm-api</li>
 * <li>서브 업무명 : com.adtcaps.tsop.onm.api.board.service</li>
 * <li>설  명 : BulletinboardService.java</li>
 * <li>작성일 : 2021. 1. 8.</li>
 * <li>작성자 : jeonyb4</li>
 * </ul>
 */
public interface BulletinboardService {
	/**
	 * 
	 * listPageBulletinboard
	 *
	 * @param bulletinboardGridRequestDto
	 * @return List<BulletinboardGridResultDto>
	 * @throws Exception 
	 */
	public List<BulletinboardGridResultDto> listPageBulletinboard(BulletinboardGridRequestDto bulletinboardGridRequestDto) throws Exception;
	
	/**
	 * 
	 * createBulletinboard
	 *
	 * @param reqBulletinboardProcessingDto
	 * @return ResultDto
	 * @throws Exception 
	 */
	public ResultDto createBulletinboard(BulletinboardProcessingDto reqBulletinboardProcessingDto) throws Exception;
	
	/**
	 * 
	 * readBulletinboard
	 *
	 * @param reqOomBulletinboardDto
	 * @return BulletinboardDetailResultDto
	 * @throws Exception 
	 */
	public BulletinboardDetailResultDto readBulletinboard(OomBulletinboardDto reqOomBulletinboardDto) throws Exception;
	
	/**
	 * 
	 * deleteBulletinboardAttachFile
	 *
	 * @param deleteBulletinboardRequestDto
	 * @return ResultDto
	 * @throws Exception 
	 */
	public ResultDto deleteBulletinboardAttachFile(DeleteBulletinboardRequestDto deleteBulletinboardRequestDto) throws Exception;
	
	/**
	 * 
	 * updateBulletinboard
	 *
	 * @param reqBulletinboardProcessingDto
	 * @return ResultDto
	 * @throws Exception 
	 */
	public ResultDto updateBulletinboard(BulletinboardProcessingDto reqBulletinboardProcessingDto) throws Exception;
	
	/**
	 * 
	 * deleteBulletinboard
	 *
	 * @param deleteBulletinboardRequestDto
	 * @return ResultDto
	 * @throws Exception 
	 */
	public ResultDto deleteBulletinboard(DeleteBulletinboardRequestDto deleteBulletinboardRequestDto) throws Exception;

}
