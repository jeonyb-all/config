package com.adtcaps.tsop.onm.api.alimTalk.domain;

import java.util.List;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class AlimTalkBatchResultDto {
	private String responseCode;
	private String msg;
	private String sender;
	private List<AlimTalkResponseDto> msgList;
	/*private List<AlimTalkResultDto> resultMsgList;*/
}
