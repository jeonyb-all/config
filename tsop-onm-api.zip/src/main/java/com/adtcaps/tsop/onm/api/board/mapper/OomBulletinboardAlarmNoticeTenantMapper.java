package com.adtcaps.tsop.onm.api.board.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;

import com.adtcaps.tsop.onm.api.board.domain.BulletinboardAlarmNoticeTenantGridResultDto;
import com.adtcaps.tsop.onm.api.domain.OomBulletinboardAlarmNoticeTenantDto;
import com.adtcaps.tsop.onm.api.domain.OomBulletinboardDto;

/**
 * 
 * <ul>
 * <li>업무 그룹명 : tsop-onm-api</li>
 * <li>서브 업무명 : com.adtcaps.tsop.onm.api.board.mapper</li>
 * <li>설  명 : OomBulletinboardAlarmNoticeTenantMapper.java</li>
 * <li>작성일 : 2021. 2. 5.</li>
 * <li>작성자 : jeonyb4</li>
 * </ul>
 */
@Mapper
public interface OomBulletinboardAlarmNoticeTenantMapper {
	/**
	 * 
	 * createOomBulletinboardAlarmNoticeTenant
	 *
	 * @param reqOomBulletinboardAlarmNoticeTenantDto
	 * @return int
	 */
	public int createOomBulletinboardAlarmNoticeTenant(OomBulletinboardAlarmNoticeTenantDto reqOomBulletinboardAlarmNoticeTenantDto);
	
	/**
	 * 
	 * listBulletinboardAlarmNoticeTenant
	 *
	 * @param reqOomBulletinboardDto
	 * @return List<BulletinboardAlarmNoticeTenantGridResultDto>
	 */
	public List<BulletinboardAlarmNoticeTenantGridResultDto> listBulletinboardAlarmNoticeTenant(OomBulletinboardDto reqOomBulletinboardDto);
	
	/**
	 * 
	 * deleteOomBulletinboardAlarmNoticeTenant
	 *
	 * @param reqOomBulletinboardDto
	 * @return int
	 */
	public int deleteOomBulletinboardAlarmNoticeTenant(OomBulletinboardDto reqOomBulletinboardDto);

}
