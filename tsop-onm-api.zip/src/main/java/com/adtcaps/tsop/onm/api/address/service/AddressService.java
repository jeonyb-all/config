package com.adtcaps.tsop.onm.api.address.service;

import java.util.List;

import com.adtcaps.tsop.onm.api.address.domain.CtPvcNameForComboResultDto;
import com.adtcaps.tsop.onm.api.address.domain.StreetnameAddressGridRequestDto;
import com.adtcaps.tsop.onm.api.address.domain.StreetnameAddressGridResultDto;

/**
 * 
 * <ul>
 * <li>업무 그룹명 : tsop-onm-api</li>
 * <li>서브 업무명 : com.adtcaps.tsop.onm.api.address.service</li>
 * <li>설  명 : AddressService.java</li>
 * <li>작성일 : 2021. 2. 2.</li>
 * <li>작성자 : jeonyb4</li>
 * </ul>
 */
public interface AddressService {
	/**
	 * 
	 * listCtPvcNameForCombo
	 *
	 * @return List<CtPvcNameForComboResultDto>
	 * @throws Exception 
	 */
	public List<CtPvcNameForComboResultDto> listCtPvcNameForCombo() throws Exception;
	
	/**
	 * 
	 * listCtGunGuNameForCombo
	 *
	 * @param ctPvcNameForComboResultDto
	 * @return List<CtPvcNameForComboResultDto>
	 * @throws Exception 
	 */
	public List<CtPvcNameForComboResultDto> listCtGunGuNameForCombo(CtPvcNameForComboResultDto ctPvcNameForComboResultDto) throws Exception;
	
	/**
	 * 
	 * listPageStreetnameAddress
	 *
	 * @param streetnameAddressGridRequestDto
	 * @return List<StreetnameAddressGridResultDto>
	 * @throws Exception 
	 */
	public List<StreetnameAddressGridResultDto> listPageStreetnameAddress(StreetnameAddressGridRequestDto streetnameAddressGridRequestDto) throws Exception;

}
