package com.adtcaps.tsop.onm.api.board.domain;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

import lombok.Getter;
import lombok.Setter;

/**
 * 
 * <ul>
 * <li>업무 그룹명 : tsop-backend-api</li>
 * <li>서브 업무명 : com.adtcaps.tsop.portal.api.board.domain</li>
 * <li>설  명 : BulletinboardDetailResultDto.java</li>
 * <li>작성일 : 2020. 12. 17.</li>
 * <li>작성자 : jeonyb4</li>
 * </ul>
 */
@Getter
@Setter
@JsonInclude(Include.NON_EMPTY)
public class BulletinboardDetailResultDto {
	private Integer bulletinNum;
	private String bulletinTypeCd;
	private String bulletinClCd;
	private String bulletinClName;
	private String bulletinTitleName;
	private String bulletinContent;
	private String bulletinStartDatetime;
	private String bulletinEndDatetime;
	private String smsAlarmNoticeYn;
	private String pushAlarmNoticeYn;
	private Integer attachFileNum;
	private String attachFileName;
	private String registerId;
	private List<BulletinboardAlarmNoticeSmsGridResultDto> smsUserList;
	private List<BulletinboardAlarmNoticeTenantGridResultDto> tenantList;

}
