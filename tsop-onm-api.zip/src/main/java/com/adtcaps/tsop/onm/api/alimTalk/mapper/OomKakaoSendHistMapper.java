package com.adtcaps.tsop.onm.api.alimTalk.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;

import com.adtcaps.tsop.onm.api.domain.OomKakaoSendHistDto;

/**
 * <ul>
 * <li>업무 그룹명 : tsop-onm-api</li>
 * <li>서브 업무명 : com.adtcaps.tsop.onm.api.alimTalk.mapper</li>
 * <li>설  명 : OomKakaoSendHistMapper.java</li>
 * <li>작성일 : 2022. 1. 8.</li>
 * <li>작성자 : vader</li>
 * </ul>
 */
@Mapper
public interface OomKakaoSendHistMapper {
	/**
	 * createOomKakaoSendHist
	 * @param oomKakaoSendHistDto
	 * @return int
	 */
	public int createOomKakaoSendHist(OomKakaoSendHistDto oomKakaoSendHistDto);

	/**
	 * updateOomKakaoSendHist
	 * @param oomKakaoSendHistDto
	 * @return int
	 */
	public int updateOomKakaoSendHist(OomKakaoSendHistDto oomKakaoSendHistDto);

	/**
	 * readRequestResultCnt
	 * @param oomKakaoSendHistDto
	 * @return int
	 */
	public int readRequestResultCnt(OomKakaoSendHistDto oomKakaoSendHistDto);

	/**
	 * listResendSms
	 * @param oomKakaoSendHistDto
	 * @return List<OomKakaoSendHistDto>
	 */
	public List<OomKakaoSendHistDto> listResendSms(OomKakaoSendHistDto oomKakaoSendHistDto);

	/**
	 * listAlimTalkResult
	 * @param oomKakaoSendHistDto
	 * @return List<OomKakaoSendHistDto>
	 */
	public List<OomKakaoSendHistDto> listAlimTalkResult(OomKakaoSendHistDto oomKakaoSendHistDto);

	/**
	 * deleteOomKakaoSendHist
	 * @param fromDate
	 * @return int
	 */
	public int deleteOomKakaoSendHist(String fromDate);
}
