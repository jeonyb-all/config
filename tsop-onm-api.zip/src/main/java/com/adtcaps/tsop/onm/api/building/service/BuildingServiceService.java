package com.adtcaps.tsop.onm.api.building.service;

import java.util.List;

import com.adtcaps.tsop.onm.api.building.domain.BuildingServiceConnectionDetailResultDto;
import com.adtcaps.tsop.onm.api.building.domain.BuildingServiceConnectionGridRequestDto;
import com.adtcaps.tsop.onm.api.building.domain.BuildingServiceConnectionGridResultDto;
import com.adtcaps.tsop.onm.api.building.domain.BuildingServiceForComboResultDto;
import com.adtcaps.tsop.onm.api.building.domain.BuildingServiceUseYnResultDto;
import com.adtcaps.tsop.onm.api.domain.OomBuildingServiceConnectionDto;
import com.adtcaps.tsop.onm.api.domain.OomBuildingServiceConnectionIpDto;
import com.adtcaps.tsop.onm.api.domain.OomBuildingServiceDto;

/**
 * 
 * <ul>
 * <li>업무 그룹명 : tsop-onm-api</li>
 * <li>서브 업무명 : com.adtcaps.tsop.onm.api.building.service</li>
 * <li>설  명 : BuildingServiceService.java</li>
 * <li>작성일 : 2021. 1. 6.</li>
 * <li>작성자 : jeonyb4</li>
 * </ul>
 */
public interface BuildingServiceService {
	/**
	 * 
	 * listBuildingServiceForCombo
	 *
	 * @param reqOomBuildingServiceDto
	 * @return List<BuildingServiceForComboResultDto>
	 * @throws Exception 
	 */
	public List<BuildingServiceForComboResultDto> listBuildingServiceForCombo(OomBuildingServiceDto reqOomBuildingServiceDto) throws Exception;
	
	/**
	 * 
	 * listBuildingServiceUseYn
	 *
	 * @param reqOomBuildingServiceDto
	 * @return List<BuildingServiceUseYnResultDto>
	 * @throws Exception 
	 */
	public List<BuildingServiceUseYnResultDto> listBuildingServiceUseYn(OomBuildingServiceDto reqOomBuildingServiceDto) throws Exception;
	
	/**
	 * 
	 * readBuildingServiceConnection
	 *
	 * @param reqOomBuildingServiceConnectionDto
	 * @return OomBuildingServiceConnectionDto
	 * @throws Exception 
	 */
	public OomBuildingServiceConnectionDto readBuildingServiceConnection(OomBuildingServiceConnectionDto reqOomBuildingServiceConnectionDto) throws Exception;
	
	/**
	 * 
	 * readBuildingServiceConnectionCount
	 *
	 * @param reqOomBuildingServiceConnectionDto
	 * @return int
	 * @throws Exception 
	 */
	public int readBuildingServiceConnectionCount(OomBuildingServiceConnectionDto reqOomBuildingServiceConnectionDto) throws Exception;
	
	/**
	 * 
	 * listBuildingServiceConnection
	 *
	 * @param reqOomBuildingServiceConnectionDto
	 * @return List<OomBuildingServiceConnectionDto>
	 * @throws Exception 
	 */
	public List<OomBuildingServiceConnectionDto> listBuildingServiceConnection(OomBuildingServiceConnectionDto reqOomBuildingServiceConnectionDto) throws Exception;
	
	/**
	 * 
	 * listBuildingServiceConnectionIp
	 *
	 * @param reqOomBuildingServiceConnectionIpDto
	 * @return List<OomBuildingServiceConnectionIpDto>
	 * @throws Exception 
	 */
	public List<OomBuildingServiceConnectionIpDto> listBuildingServiceConnectionIp(OomBuildingServiceConnectionIpDto reqOomBuildingServiceConnectionIpDto) throws Exception;
	
	/**
	 * 
	 * listPageBuildingServiceConnection
	 *
	 * @param buildingServiceConnectionGridRequestDto
	 * @return List<BuildingServiceConnectionGridResultDto>
	 * @throws Exception 
	 */
	public List<BuildingServiceConnectionGridResultDto> listPageBuildingServiceConnection(BuildingServiceConnectionGridRequestDto buildingServiceConnectionGridRequestDto) throws Exception;
	
	/**
	 * 
	 * readBuildingServiceConnectionInfo
	 *
	 * @param reqOomBuildingServiceConnectionDto
	 * @return BuildingServiceConnectionDetailResultDto
	 * @throws Exception 
	 */
	public BuildingServiceConnectionDetailResultDto readBuildingServiceConnectionInfo(OomBuildingServiceConnectionDto reqOomBuildingServiceConnectionDto) throws Exception;

}
