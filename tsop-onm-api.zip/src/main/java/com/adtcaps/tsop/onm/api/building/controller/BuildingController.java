package com.adtcaps.tsop.onm.api.building.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.util.CollectionUtils;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.adtcaps.tsop.onm.api.building.domain.BuildingForComboResultDto;
import com.adtcaps.tsop.onm.api.building.domain.BuildingGridDto;
import com.adtcaps.tsop.onm.api.building.domain.TenantBuildingGridResultDto;
import com.adtcaps.tsop.onm.api.building.service.BuildingService;
import com.adtcaps.tsop.onm.api.domain.OomBuildingDto;
import com.adtcaps.tsop.onm.api.helper.constant.Const;
import com.adtcaps.tsop.onm.api.helper.domain.ResultDto;
import com.adtcaps.tsop.onm.api.helper.util.PageUtil;

import lombok.extern.slf4j.Slf4j;

/**
 * 
 * <ul>
 * <li>업무 그룹명 : tsop-onm-api</li>
 * <li>서브 업무명 : com.adtcaps.tsop.onm.api.building.controller</li>
 * <li>설  명 : BuildingController.java</li>
 * <li>작성일 : 2021. 1. 5.</li>
 * <li>작성자 : jeonyb4</li>
 * </ul>
 */
@Slf4j
@RestController
@RequestMapping("/api/buildings")
public class BuildingController {
	
	private final String ERR_MSG_NULL_TENANT_ID = "테넌트ID가 없습니다.";
	private final String ERR_MSG_NULL_SEARCH_RESULT_LIST = "조회 결과가 없습니다.";
	private final String ERR_MSG_READ_FAIL = "조회에 실패하였습니다.";
	
	@Autowired
	private BuildingService buildingService;
	
	/**
	 * 
	 * listBuildingForCombo
	 *
	 * @return ResponseEntity
	 */
	@SuppressWarnings("rawtypes")
	@GetMapping(value="/combobox", produces="application/json; charset=UTF-8")
	public ResponseEntity listBuildingForCombo(OomBuildingDto reqOomBuildingDto) throws Exception {
		
		ResponseEntity<ResultDto> resEntity = null;
		String returnString = "";
		
		String tenantId = StringUtils.defaultString(reqOomBuildingDto.getTenantId());
		if ("".equals(tenantId)) {
			log.error(">>>>>> tenantId ERROR:{}", ERR_MSG_NULL_TENANT_ID);
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_TENANT_ID));
			return resEntity;
		}
		// 콤보박스용 빌딩 목록조회
		List<BuildingForComboResultDto> buildingForComboResultDtoList = buildingService.listBuildingForCombo(reqOomBuildingDto);
		if (CollectionUtils.isEmpty(buildingForComboResultDtoList)) {
			returnString = Const.Common.RESULT_CODE.SUCCESS;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_SEARCH_RESULT_LIST, buildingForComboResultDtoList));
        } else {
        	returnString = Const.Common.RESULT_CODE.SUCCESS;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, "", buildingForComboResultDtoList));
		}
    	
		return resEntity;
	}
	
	/**
	 * 
	 * listTenantBuilding
	 *
	 * @param tenantId
	 * @return ResponseEntity
	 */
	@SuppressWarnings("rawtypes")
	@GetMapping(value="/tenants/{tenantId}", produces="application/json; charset=UTF-8")
	public ResponseEntity listTenantBuilding(@PathVariable("tenantId") String tenantId) throws Exception {
		
		ResponseEntity<ResultDto> resEntity = null;
		String returnString = "";
		
		OomBuildingDto reqOomBuildingDto = new OomBuildingDto();
		reqOomBuildingDto.setTenantId(tenantId);
		
		// 테넌트별 빌딩 목록조회
		Map<String, Object> tenantBuildingGridResultDtoListMap = new HashMap<String, Object>();
		List<TenantBuildingGridResultDto> tenantBuildingGridResultDtoList = buildingService.listTenantBuilding(reqOomBuildingDto);
		if (CollectionUtils.isEmpty(tenantBuildingGridResultDtoList)) {
			returnString = Const.Common.RESULT_CODE.SUCCESS;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_SEARCH_RESULT_LIST, tenantBuildingGridResultDtoListMap));
        } else {
        	returnString = Const.Common.RESULT_CODE.SUCCESS;
			int totalCount = tenantBuildingGridResultDtoList.size();
			Map<String, Object> totalCountMap = new HashMap<String, Object>();
			totalCountMap.put("totalCount", totalCount);
        	
			tenantBuildingGridResultDtoListMap.put(Const.Definition.PAGE.PAGER, totalCountMap);
			tenantBuildingGridResultDtoListMap.put(Const.Definition.PAGE.LISTS, tenantBuildingGridResultDtoList);
        	resEntity = ResponseEntity.ok(new ResultDto(returnString, "", tenantBuildingGridResultDtoListMap));
		}
    	
		return resEntity;
	}
	
	
	
	/**
	 * 
	 * listPageBuilding
	 *
	 * @param reqBuildingGridDto
	 * @return ResponseEntity
	 */
	@SuppressWarnings("rawtypes")
	@GetMapping("")
	public ResponseEntity listPageBuilding(BuildingGridDto reqBuildingGridDto) throws Exception {
		
		ResponseEntity<ResultDto> resEntity = null;
		String returnString = "";
		
		// 빌딩 목록조회
		List<BuildingGridDto> rsltBuildingGridDtoList = buildingService.listPageBuilding(reqBuildingGridDto);
		Map<String, Object> rsltBuildingGridDtoListMap = null;
		if (CollectionUtils.isEmpty(rsltBuildingGridDtoList)) {
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_READ_FAIL, rsltBuildingGridDtoListMap));
        } else {
        	returnString = Const.Common.RESULT_CODE.SUCCESS;
        	rsltBuildingGridDtoListMap = new HashMap<String, Object>();
        	rsltBuildingGridDtoListMap.put(Const.Definition.PAGE.PAGER, PageUtil.getPageInfo(rsltBuildingGridDtoList));
        	rsltBuildingGridDtoListMap.put(Const.Definition.PAGE.LISTS, rsltBuildingGridDtoList);
        	resEntity = ResponseEntity.ok(new ResultDto(returnString, "", rsltBuildingGridDtoListMap));
		}

		return resEntity;
	}

}
