package com.adtcaps.tsop.onm.api.menu.service.impl;

import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.CollectionUtils;

import com.adtcaps.tsop.onm.api.domain.OomTenantServicePortalMenuDto;
import com.adtcaps.tsop.onm.api.helper.domain.BasePageDto;
import com.adtcaps.tsop.onm.api.helper.util.CommonDateUtil;
import com.adtcaps.tsop.onm.api.menu.domain.TenantServicePortalMenuDetailResultDto;
import com.adtcaps.tsop.onm.api.menu.domain.TenantServicePortalMenuForComboResultDto;
import com.adtcaps.tsop.onm.api.menu.domain.TenantServicePortalMenuForShortGridResultDto;
import com.adtcaps.tsop.onm.api.menu.domain.TenantServicePortalMenuGridRequestDto;
import com.adtcaps.tsop.onm.api.menu.domain.TenantServicePortalMenuGridResultDto;
import com.adtcaps.tsop.onm.api.menu.mapper.OomTenantServicePortalMenuMapper;
import com.adtcaps.tsop.onm.api.menu.service.PortalMenuService;

/**
 * 
 * <ul>
 * <li>업무 그룹명 : tsop-onm-api</li>
 * <li>서브 업무명 : com.adtcaps.tsop.onm.api.menu.service.impl</li>
 * <li>설  명 : PortalMenuServiceImpl.java</li>
 * <li>작성일 : 2021. 1. 11.</li>
 * <li>작성자 : jeonyb4</li>
 * </ul>
 */
@Transactional
@Service
public class PortalMenuServiceImpl implements PortalMenuService {
	
	@Autowired
	private OomTenantServicePortalMenuMapper oomTenantServicePortalMenuMapper;
	
	/**
	 * 
	 * listTenantServicePortalMenuForCombo
	 *
	 * @param reqOomTenantServicePortalMenuDto
	 * @return List<TenantServicePortalMenuForComboResultDto>
	 * @throws Exception 
	 */
	@Override
	public List<TenantServicePortalMenuForComboResultDto> listTenantServicePortalMenuForCombo(OomTenantServicePortalMenuDto reqOomTenantServicePortalMenuDto) throws Exception {
		
		List<TenantServicePortalMenuForComboResultDto> tenantServicePortalMenuForComboResultDtoList = null;
		try {
			tenantServicePortalMenuForComboResultDtoList = oomTenantServicePortalMenuMapper.listTenantServicePortalMenuForCombo(reqOomTenantServicePortalMenuDto);
		} catch (Exception e) {
			throw e;
		}
		return tenantServicePortalMenuForComboResultDtoList;
	}
	
	/**
	 * 
	 * listTenantServicePortalMenuForShortGrid
	 *
	 * @param reqBasePageDto
	 * @return List<TenantServicePortalMenuForShortGridResultDto>
	 * @throws Exception 
	 */
	@Override
	public List<TenantServicePortalMenuForShortGridResultDto> listTenantServicePortalMenuForShortGrid(BasePageDto reqBasePageDto) throws Exception {
		
		List<TenantServicePortalMenuForShortGridResultDto> tenantServicePortalMenuForShortGridResultDtoList = null;
		try {
			tenantServicePortalMenuForShortGridResultDtoList = oomTenantServicePortalMenuMapper.listTenantServicePortalMenuForShortGrid(reqBasePageDto);
		} catch (Exception e) {
			throw e;
		}
		return tenantServicePortalMenuForShortGridResultDtoList;
	}
	
	/**
	 * 
	 * listPageTenantServicePortalMenu
	 *
	 * @param tenantServicePortalMenuGridRequestDto
	 * @return List<TenantServicePortalMenuGridResultDto>
	 * @throws Exception 
	 */
	@Override
	public List<TenantServicePortalMenuGridResultDto> listPageTenantServicePortalMenu(TenantServicePortalMenuGridRequestDto tenantServicePortalMenuGridRequestDto) throws Exception {
		
		List<TenantServicePortalMenuGridResultDto> tenantServicePortalMenuGridResultDtoList = null;
		try {
			tenantServicePortalMenuGridResultDtoList = oomTenantServicePortalMenuMapper.listPageTenantServicePortalMenu(tenantServicePortalMenuGridRequestDto);
    		if (!CollectionUtils.isEmpty(tenantServicePortalMenuGridResultDtoList)) {
    			for (int idx = 0; idx < tenantServicePortalMenuGridResultDtoList.size(); idx++) {
    				
    				TenantServicePortalMenuGridResultDto tenantServicePortalMenuGridResultDto = tenantServicePortalMenuGridResultDtoList.get(idx);
    				
    				String registDatetime = StringUtils.defaultString(tenantServicePortalMenuGridResultDto.getRegistDatetime());
    				registDatetime = CommonDateUtil.makeDatetimeFormat(registDatetime);
    				tenantServicePortalMenuGridResultDto.setRegistDatetime(registDatetime);
    				
    				tenantServicePortalMenuGridResultDtoList.set(idx, tenantServicePortalMenuGridResultDto);
    			}
    		}
    		
		} catch (Exception e) {
			throw e;
		}
		return tenantServicePortalMenuGridResultDtoList;
	}
	
	/**
	 * 
	 * createTenantServicePortalMenu
	 *
	 * @param reqOomTenantServicePortalMenuDto
	 * @return int
	 * @throws Exception 
	 */
	@Override
	public int createTenantServicePortalMenu(OomTenantServicePortalMenuDto reqOomTenantServicePortalMenuDto) throws Exception {
		
		int affectRowCount = 0;
		
		try {
			// 테넌트별서비스포털메뉴 등록...
			int insertRow = oomTenantServicePortalMenuMapper.createOomTenantServicePortalMenu(reqOomTenantServicePortalMenuDto);
			affectRowCount = affectRowCount + insertRow;
			
		} catch (Exception e) {
			throw e;
		}
		
		return affectRowCount;
	}
	
	/**
	 * 
	 * readTenantServicePortalMenu
	 *
	 * @param reqOomTenantServicePortalMenuDto
	 * @return TenantServicePortalMenuDetailResultDto
	 * @throws Exception 
	 */
	@Override
	public TenantServicePortalMenuDetailResultDto readTenantServicePortalMenu(OomTenantServicePortalMenuDto reqOomTenantServicePortalMenuDto) throws Exception {
		
		TenantServicePortalMenuDetailResultDto tenantServicePortalMenuDetailResultDto = null;
		
		try {
			// 테넌트별서비스포털메뉴 상세조회...
			tenantServicePortalMenuDetailResultDto = oomTenantServicePortalMenuMapper.readOomTenantServicePortalMenu(reqOomTenantServicePortalMenuDto);
			if (tenantServicePortalMenuDetailResultDto != null) {
				String registDatetime = StringUtils.defaultString(tenantServicePortalMenuDetailResultDto.getRegistDatetime());
				registDatetime = CommonDateUtil.makeDatetimeFormat(registDatetime);
				tenantServicePortalMenuDetailResultDto.setRegistDatetime(registDatetime);
			}
			
		} catch (Exception e) {
			throw e;
		}
		
		return tenantServicePortalMenuDetailResultDto;
	}
	
	/**
	 * 
	 * updateTenantServicePortalMenu
	 *
	 * @param reqOomTenantServicePortalMenuDto
	 * @return int
	 * @throws Exception 
	 */
	@Override
	public int updateTenantServicePortalMenu(OomTenantServicePortalMenuDto reqOomTenantServicePortalMenuDto) throws Exception {
		
		int affectRowCount = 0;
		
		try {
			// 테넌트별서비스포털메뉴 수정...
			int updateRow = oomTenantServicePortalMenuMapper.updateOomTenantServicePortalMenu(reqOomTenantServicePortalMenuDto);
			affectRowCount = affectRowCount + updateRow;
			
		} catch (Exception e) {
			throw e;
		}
		
		return affectRowCount;
	}
	
	/**
	 * 
	 * deleteTenantServicePortalMenu
	 *
	 * @param reqOomTenantServicePortalMenuDto
	 * @return int
	 * @throws Exception 
	 */
	@Override
	public int deleteTenantServicePortalMenu(OomTenantServicePortalMenuDto reqOomTenantServicePortalMenuDto) throws Exception {
		
		int affectRowCount = 0;
		
		try {
			// 테넌트별서비스포털메뉴 삭제...
			int deleteRow = oomTenantServicePortalMenuMapper.deleteOomTenantServicePortalMenu(reqOomTenantServicePortalMenuDto);
			affectRowCount = affectRowCount + deleteRow;
			
		} catch (Exception e) {
			throw e;
		}
		
		return affectRowCount;
	}
	
	/**
	 * 
	 * readTenantServicePortalChildMenuCount
	 *
	 * @param reqOomTenantServicePortalMenuDto
	 * @return int
	 * @throws Exception 
	 */
	@Override
	public int readTenantServicePortalChildMenuCount(OomTenantServicePortalMenuDto reqOomTenantServicePortalMenuDto) throws Exception {
		
		int childMenuCount = 0;
		
		try {
			childMenuCount = oomTenantServicePortalMenuMapper.readTenantServicePortalChildMenuCount(reqOomTenantServicePortalMenuDto);
			
		} catch (Exception e) {
			throw e;
		}
		
		return childMenuCount;
	}
	
	/**
	 * 
	 * readTenantServicePortalMenuSameMenuNameCount
	 *
	 * @param reqOomTenantServicePortalMenuDto
	 * @return int
	 * @throws Exception 
	 */
	@Override
	public int readTenantServicePortalMenuSameMenuNameCount(OomTenantServicePortalMenuDto reqOomTenantServicePortalMenuDto) throws Exception {
		
		int menuCount = 0;
		
		try {
			menuCount = oomTenantServicePortalMenuMapper.readTenantServicePortalMenuSameMenuNameCount(reqOomTenantServicePortalMenuDto);
			
		} catch (Exception e) {
			throw e;
		}
		
		return menuCount;
	}

}
