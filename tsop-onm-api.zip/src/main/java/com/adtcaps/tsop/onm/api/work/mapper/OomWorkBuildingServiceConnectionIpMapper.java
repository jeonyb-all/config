package com.adtcaps.tsop.onm.api.work.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;

import com.adtcaps.tsop.onm.api.domain.OomWorkBuildingServiceConnectionIpDto;

/**
 * 
 * <ul>
 * <li>업무 그룹명 : tsop-onm-api</li>
 * <li>서브 업무명 : com.adtcaps.tsop.onm.api.work.mapper</li>
 * <li>설  명 : OomWorkBuildingServiceConnectionIpMapper.java</li>
 * <li>작성일 : 2021. 1. 30.</li>
 * <li>작성자 : jeonyb4</li>
 * </ul>
 */
@Mapper
public interface OomWorkBuildingServiceConnectionIpMapper {
	/**
	 * 
	 * insertOomWorkBuildingServiceConnectionIp
	 *
	 * @param reqOomWorkBuildingServiceConnectionIpDto
	 * @return int
	 */
	public int insertOomWorkBuildingServiceConnectionIp(OomWorkBuildingServiceConnectionIpDto reqOomWorkBuildingServiceConnectionIpDto);
	
	/**
	 * 
	 * deleteOomWorkBuildingServiceConnectionIp
	 *
	 * @param reqOomWorkBuildingServiceConnectionIpDto
	 * @return int
	 */
	public int deleteOomWorkBuildingServiceConnectionIp(OomWorkBuildingServiceConnectionIpDto reqOomWorkBuildingServiceConnectionIpDto);
	
	/**
	 * 
	 * mergeOomWorkBuildingServiceConnectionIp
	 *
	 * @param reqOomWorkBuildingServiceConnectionIpDto
	 * @return int
	 */
	public int mergeOomWorkBuildingServiceConnectionIp(OomWorkBuildingServiceConnectionIpDto reqOomWorkBuildingServiceConnectionIpDto);
	
	/**
	 * 
	 * listOomWorkBuildingServiceConnectionIp
	 *
	 * @param reqOomWorkBuildingServiceConnectionIpDto
	 * @return List<OomWorkBuildingServiceConnectionIpDto>
	 */
	public List<OomWorkBuildingServiceConnectionIpDto> listOomWorkBuildingServiceConnectionIp(OomWorkBuildingServiceConnectionIpDto reqOomWorkBuildingServiceConnectionIpDto);
	
	/**
	 * 
	 * createServiceConnectionIpFromWork
	 *
	 * @param reqOomWorkBuildingServiceConnectionIpDto
	 * @return int
	 */
	public int createServiceConnectionIpFromWork(OomWorkBuildingServiceConnectionIpDto reqOomWorkBuildingServiceConnectionIpDto);

}
