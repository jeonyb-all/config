package com.adtcaps.tsop.onm.api.authentication.mapper;

import org.apache.ibatis.annotations.Mapper;

import com.adtcaps.tsop.onm.api.authentication.domain.JwtAuthResultDto;
import com.adtcaps.tsop.onm.api.authentication.domain.JwtAuthSmsDto;
import com.adtcaps.tsop.onm.api.authentication.domain.JwtRequest;

/**
 * 
 * <ul>
 * <li>업무 그룹명 : tsop-backend-api</li>
 * <li>서브 업무명 : com.adtcaps.tsop.authentication.mapper</li>
 * <li>설  명 : JwtAuthenticationMapper.java auth/token</li>
 * <li>작성일 : 2020. 12. 31.</li>
 * <li>작성자 : kang</li>
 * </ul>
 */

 @Mapper
public interface JwtAuthenticationMapper {

     /**
	 * 
	 * readAuthUserByPassword
	 *
	 * @param JwtRequest
	 * @return JwtAuthResultDto
	 */
	public JwtAuthResultDto readAuthUserByPassword(JwtRequest request);

	/**
	 * 
	 * readAuthUserByUserid
	 *
	 * @param String
	 * @return JwtAuthResultDto
	 */
	public JwtAuthResultDto readAuthUserByUserid(String request);

	/**
	 * 
	 * createAuthSms
	 *
	 * @param JwtAuthSmsDto
	 * @return int
	 */
	public int createAuthSms(JwtAuthSmsDto request);

	/**
	 * 
	 * readAuthSms
	 *
	 * @param readAuthSmsToken
	 * @return JwtAuthSmsDto
	 */
	public JwtAuthSmsDto readAuthSmsToken(JwtAuthSmsDto request);
	

	/**
	 * 
	 * checkAuthSmsCntByUserid
	 *
	 * @param readAuthSmsToken
	 * @return int
	 */
	public int checkAuthSmsCntByUserid(JwtAuthSmsDto request);
	

	/**
	 * 
	 * checkAuthSmsCntByIp
	 *
	 * @param readAuthSmsToken
	 * @return int
	 */
	public int checkAuthSmsCntByIp(JwtAuthSmsDto request);

	/**
	 * 
	 * createAuthHist
	 *
	 * @param JwtAuthSmsDto
	 * @return int
	 */
	public int createAuthHist(JwtAuthSmsDto request);

	/**
	 * 
	 * updateAuthHist
	 *
	 * @param JwtAuthSmsDto
	 * @return int
	 */
	public int updateAuthHist(JwtAuthSmsDto request);

		/**
	 * 
	 * updateAuthHist
	 *
	 * @param JwtAuthSmsDto
	 * @return int
	 */
	public int updateAuthUseYn(JwtAuthSmsDto request);

	/**
	 * 
	 * createInitSms
	 *
	 * @param JwtAuthSmsDto
	 * @return int
	 */
	public int createInitSms(JwtAuthSmsDto request);

	/**
	 * 
	 * readInitSmsToken
	 *
	 * @param JwtAuthSmsDto
	 * @return JwtAuthSmsDto
	 */
	public JwtAuthSmsDto readInitSmsToken(JwtAuthSmsDto request);

	 /**
	 * 
	 * updateLockUser
	 *
	 * @param String
	 * @return int
	 */
	public int updateLockUser(String request);

	
	
}
