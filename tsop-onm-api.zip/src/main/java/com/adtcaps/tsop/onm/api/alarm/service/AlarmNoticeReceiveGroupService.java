package com.adtcaps.tsop.onm.api.alarm.service;

import java.util.List;

import com.adtcaps.tsop.onm.api.alarm.domain.AlarmNoticeReceiveGroupDetailResultDto;
import com.adtcaps.tsop.onm.api.alarm.domain.AlarmNoticeReceiveGroupForComboResultDto;
import com.adtcaps.tsop.onm.api.alarm.domain.AlarmNoticeReceiveGroupGridRequestDto;
import com.adtcaps.tsop.onm.api.alarm.domain.AlarmNoticeReceiveGroupGridResultDto;
import com.adtcaps.tsop.onm.api.alarm.domain.AlarmNoticeReceiveGroupProcessingDto;
import com.adtcaps.tsop.onm.api.domain.OomAlarmNoticeReceiveGroupDto;

/**
 * 
 * <ul>
 * <li>업무 그룹명 : tsop-onm-api</li>
 * <li>서브 업무명 : com.adtcaps.tsop.onm.api.alarm.service</li>
 * <li>설  명 : AlarmNoticeReceiveGroupService.java</li>
 * <li>작성일 : 2021. 1. 8.</li>
 * <li>작성자 : jeonyb4</li>
 * </ul>
 */
public interface AlarmNoticeReceiveGroupService {
	/**
	 * 
	 * listAlarmNoticeReceiveGroupForCombo
	 *
	 * @return List<AlarmNoticeReceiveGroupForComboResultDto>
	 * @throws Exception 
	 */
	public List<AlarmNoticeReceiveGroupForComboResultDto> listAlarmNoticeReceiveGroupForCombo() throws Exception;
	
	/**
	 * 
	 * listPageAlarmNoticeReceiveGroup
	 *
	 * @param alarmReceiveGroupGridRequestDto
	 * @return List<AlarmNoticeReceiveGroupGridResultDto>
	 * @throws Exception 
	 */
	public List<AlarmNoticeReceiveGroupGridResultDto> listPageAlarmNoticeReceiveGroup(AlarmNoticeReceiveGroupGridRequestDto alarmReceiveGroupGridRequestDto) throws Exception;
	
	/**
	 * 
	 * createAlarmNoticeReceiveGroup
	 *
	 * @param reqAlarmNoticeReceiveGroupProcessingDto
	 * @return int
	 * @throws Exception 
	 */
	public int createAlarmNoticeReceiveGroup(AlarmNoticeReceiveGroupProcessingDto reqAlarmNoticeReceiveGroupProcessingDto) throws Exception;
	
	/**
	 * 
	 * readAlarmNoticeReceiveGroup
	 *
	 * @param reqOomAlarmNoticeReceiveGroupDto
	 * @return AlarmNoticeReceiveGroupDetailResultDto
	 * @throws Exception 
	 */
	public AlarmNoticeReceiveGroupDetailResultDto readAlarmNoticeReceiveGroup(OomAlarmNoticeReceiveGroupDto reqOomAlarmNoticeReceiveGroupDto) throws Exception;
	
	/**
	 * 
	 * updateAlarmNoticeReceiveGroup
	 *
	 * @param reqOomAlarmNoticeReceiveGroupDto
	 * @return int
	 * @throws Exception 
	 */
	public int updateAlarmNoticeReceiveGroup(AlarmNoticeReceiveGroupProcessingDto reqAlarmNoticeReceiveGroupProcessingDto) throws Exception;
	
	/**
	 * 
	 * deleteAlarmNoticeReceiveGroup
	 *
	 * @param reqOomAlarmNoticeReceiveGroupDto
	 * @return int
	 * @throws Exception 
	 */
	public int deleteAlarmNoticeReceiveGroup(OomAlarmNoticeReceiveGroupDto reqOomAlarmNoticeReceiveGroupDto) throws Exception;
	
	/**
	 * 
	 * updateAlarmReceiveGroupReuse
	 *
	 * @param reqOomAlarmNoticeReceiveGroupDto
	 * @return int
	 * @throws Exception 
	 */
	public int updateAlarmReceiveGroupReuse(OomAlarmNoticeReceiveGroupDto reqOomAlarmNoticeReceiveGroupDto) throws Exception;
	
	/**
	 * 
	 * getAlarmReceiveGroupCount
	 *
	 * @param reqOomAlarmNoticeReceiveGroupDto
	 * @return int
	 * @throws Exception 
	 */
	public int getAlarmReceiveGroupCount(OomAlarmNoticeReceiveGroupDto reqOomAlarmNoticeReceiveGroupDto) throws Exception;
	
}
