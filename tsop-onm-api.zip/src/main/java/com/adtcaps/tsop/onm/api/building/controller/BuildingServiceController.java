package com.adtcaps.tsop.onm.api.building.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.util.CollectionUtils;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.adtcaps.tsop.onm.api.building.domain.BuildingServiceConnectionDetailResultDto;
import com.adtcaps.tsop.onm.api.building.domain.BuildingServiceConnectionGridRequestDto;
import com.adtcaps.tsop.onm.api.building.domain.BuildingServiceConnectionGridResultDto;
import com.adtcaps.tsop.onm.api.building.domain.BuildingServiceForComboResultDto;
import com.adtcaps.tsop.onm.api.building.domain.BuildingServiceUseYnResultDto;
import com.adtcaps.tsop.onm.api.building.service.BuildingServiceService;
import com.adtcaps.tsop.onm.api.domain.OomBuildingServiceConnectionDto;
import com.adtcaps.tsop.onm.api.domain.OomBuildingServiceDto;
import com.adtcaps.tsop.onm.api.helper.constant.Const;
import com.adtcaps.tsop.onm.api.helper.domain.ResultDto;
import com.adtcaps.tsop.onm.api.helper.util.PageUtil;

import lombok.extern.slf4j.Slf4j;

/**
 * 
 * <ul>
 * <li>업무 그룹명 : tsop-onm-api</li>
 * <li>서브 업무명 : com.adtcaps.tsop.onm.api.building.controller</li>
 * <li>설  명 : BuildingServiceController.java</li>
 * <li>작성일 : 2021. 1. 6.</li>
 * <li>작성자 : jeonyb4</li>
 * </ul>
 */
@Slf4j
@RestController
@RequestMapping("/api/building-services")
public class BuildingServiceController {
	
	private final String ERR_MSG_NULL_BLD_ID = "빌딩ID가 없습니다.";
	private final String ERR_MSG_NULL_SERVICE_CL_CD = "서비스구분코드가 없습니다.";
	private final String ERR_MSG_NULL_PAGE_NUMBER = "페이지 번호가 없습니다.";
	private final String ERR_MSG_NULL_SERVICE_SYS_NAME = "서비스시스템명이 없습니다.";
	private final String ERR_MSG_NULL_CONNECT_VERSION_VAL = "연결버전값이 없습니다.";
	
	private final String ERR_MSG_NULL_SEARCH_RESULT_LIST = "조회 결과가 없습니다.";
	private final String ERR_MSG_READ_FAIL = "조회에 실패하였습니다.";
	
	@Autowired
	private BuildingServiceService buildingServiceService;
	
	/**
	 * 
	 * listBuildingServiceForCombo
	 *
	 * @param reqOomBuildingServiceDto
	 * @return ResponseEntity
	 */
	@SuppressWarnings("rawtypes")
	@GetMapping(value="/combobox", produces="application/json; charset=UTF-8")
	public ResponseEntity listBuildingServiceForCombo(OomBuildingServiceDto reqOomBuildingServiceDto) throws Exception {
		
		ResponseEntity<ResultDto> resEntity = null;
		String returnString = "";
		
		String bldId = StringUtils.defaultString(reqOomBuildingServiceDto.getBldId());
		if ("".equals(bldId)) {
			log.error(">>>>>> bldId ERROR:{}", ERR_MSG_NULL_BLD_ID);
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_BLD_ID));
			return resEntity;
		}
		// 콤보박스 제공용 빌딩별 서비스 목록 조회...
		List<BuildingServiceForComboResultDto> buildingServiceForComboResultDtoList = buildingServiceService.listBuildingServiceForCombo(reqOomBuildingServiceDto);
		if (CollectionUtils.isEmpty(buildingServiceForComboResultDtoList)) {
			returnString = Const.Common.RESULT_CODE.SUCCESS;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_SEARCH_RESULT_LIST, buildingServiceForComboResultDtoList));
		} else {
			returnString = Const.Common.RESULT_CODE.SUCCESS;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, "", buildingServiceForComboResultDtoList));
		}

		return resEntity;
	}
	
	/**
	 * 
	 * listBuildingServiceUseYn
	 *
	 * @param reqOomBuildingServiceDto
	 * @return ResponseEntity
	 */
	@SuppressWarnings("rawtypes")
	@GetMapping(value="/use-list", produces="application/json; charset=UTF-8")
	public ResponseEntity listBuildingServiceUseYn(OomBuildingServiceDto reqOomBuildingServiceDto) throws Exception {
		
		ResponseEntity<ResultDto> resEntity = null;
		String returnString = "";
		
		String bldId = StringUtils.defaultString(reqOomBuildingServiceDto.getBldId());
		if ("".equals(bldId)) {
			log.error(">>>>>> bldId ERROR:{}", ERR_MSG_NULL_BLD_ID);
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_BLD_ID));
			return resEntity;
		}
		// 빌딩별 서비스 사용여부 목록 조회...
		List<BuildingServiceUseYnResultDto> buildingServiceUseYnResultDtoList = buildingServiceService.listBuildingServiceUseYn(reqOomBuildingServiceDto);
		if (CollectionUtils.isEmpty(buildingServiceUseYnResultDtoList)) {
			returnString = Const.Common.RESULT_CODE.SUCCESS;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_SEARCH_RESULT_LIST, buildingServiceUseYnResultDtoList));
		} else {
			returnString = Const.Common.RESULT_CODE.SUCCESS;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, "", buildingServiceUseYnResultDtoList));
		}

		return resEntity;
	}
	
	/**
	 * 
	 * readBuildingServiceConnection
	 *
	 * @param reqOomBuildingServiceConnectionDto
	 * @return ResponseEntity
	 */
	@SuppressWarnings("rawtypes")
	@GetMapping(value="/connection-info", produces="application/json; charset=UTF-8")
	public ResponseEntity readBuildingServiceConnection(OomBuildingServiceConnectionDto reqOomBuildingServiceConnectionDto) throws Exception {
		
		ResponseEntity<ResultDto> resEntity = null;
		String returnString = "";
		
		String bldId = StringUtils.defaultString(reqOomBuildingServiceConnectionDto.getBldId());
		if ("".equals(bldId)) {
			log.error(">>>>>> bldId ERROR:{}", ERR_MSG_NULL_BLD_ID);
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_BLD_ID));
			return resEntity;
		}
		String serviceClCd = StringUtils.defaultString(reqOomBuildingServiceConnectionDto.getServiceClCd());
		if ("".equals(serviceClCd)) {
			log.error(">>>>>> serviceClCd ERROR:{}", ERR_MSG_NULL_SERVICE_CL_CD);
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_SERVICE_CL_CD));
			return resEntity;
		}
		// 빌딩별 서비스별 건물서비스연동 정보 조회...
		OomBuildingServiceConnectionDto rsltOomBuildingServiceConnectionDto = buildingServiceService.readBuildingServiceConnection(reqOomBuildingServiceConnectionDto);
		if (rsltOomBuildingServiceConnectionDto == null) {
			returnString = Const.Common.RESULT_CODE.SUCCESS;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_SEARCH_RESULT_LIST, rsltOomBuildingServiceConnectionDto));
		} else {
			returnString = Const.Common.RESULT_CODE.SUCCESS;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, "", rsltOomBuildingServiceConnectionDto));
		}

		return resEntity;
	}
	
	/**
	 * 
	 * listPageBuildingServiceConnection
	 *
	 * @param buildingServiceConnectionGridRequestDto
	 * @return ResponseEntity
	 */
	@SuppressWarnings("rawtypes")
    @GetMapping(value="", produces="application/json; charset=UTF-8")
    public ResponseEntity listPageBuildingServiceConnection(BuildingServiceConnectionGridRequestDto buildingServiceConnectionGridRequestDto) throws Exception {
        
    	ResponseEntity<ResultDto> resEntity = null;
		String returnString = "";
    	
		int pageNumber = buildingServiceConnectionGridRequestDto.getPageNumber();
		if (pageNumber < 1) {
			log.error(">>>>>> pageNumber ERROR:{}", ERR_MSG_NULL_PAGE_NUMBER);
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_PAGE_NUMBER));
			return resEntity;
		}
		
		// 빌딩별 연동정보 목록 조회....
		Map<String, Object> buildingServiceConnectionGridResultDtoListMap = new HashMap<String, Object>();
		List<BuildingServiceConnectionGridResultDto> buildingServiceConnectionGridResultDtoList = buildingServiceService.listPageBuildingServiceConnection(buildingServiceConnectionGridRequestDto);
		if (CollectionUtils.isEmpty(buildingServiceConnectionGridResultDtoList)) {
			returnString = Const.Common.RESULT_CODE.SUCCESS;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_SEARCH_RESULT_LIST, buildingServiceConnectionGridResultDtoListMap));
		} else {
			returnString = Const.Common.RESULT_CODE.SUCCESS;
			buildingServiceConnectionGridResultDtoListMap.put(Const.Definition.PAGE.PAGER, PageUtil.getPageInfo(buildingServiceConnectionGridResultDtoList));
			buildingServiceConnectionGridResultDtoListMap.put(Const.Definition.PAGE.LISTS, buildingServiceConnectionGridResultDtoList);
			resEntity = ResponseEntity.ok(new ResultDto(returnString, "", buildingServiceConnectionGridResultDtoListMap));
		}
    	
    	return resEntity;
    }
	
	/**
	 * 
	 * readBuildingServiceConnectionInfo
	 *
	 * @param serviceClCd
	 * @param reqOomBuildingServiceConnectionDto
	 * @return ResponseEntity
	 */
	@SuppressWarnings("rawtypes")
    @GetMapping(value="/{serviceClCd}", produces="application/json; charset=UTF-8")
    public ResponseEntity readBuildingServiceConnectionInfo(@PathVariable("serviceClCd") String serviceClCd, OomBuildingServiceConnectionDto reqOomBuildingServiceConnectionDto) throws Exception {
        
    	ResponseEntity<ResultDto> resEntity = null;
		String returnString = "";
    	
		String bldId = StringUtils.defaultString(reqOomBuildingServiceConnectionDto.getBldId());
		if ("".equals(bldId)) {
			log.error(">>>>>> bldId ERROR:{}", ERR_MSG_NULL_BLD_ID);
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_BLD_ID));
			return resEntity;
		}
		String serviceSysName = StringUtils.defaultString(reqOomBuildingServiceConnectionDto.getServiceSysName());
		if ("".equals(serviceSysName)) {
			log.error(">>>>>> serviceSysName ERROR:{}", ERR_MSG_NULL_SERVICE_SYS_NAME);
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_SERVICE_SYS_NAME));
			return resEntity;
		}
		String connectVersionVal = StringUtils.defaultString(reqOomBuildingServiceConnectionDto.getConnectVersionVal());
		if ("".equals(connectVersionVal)) {
			log.error(">>>>>> connectVersionVal ERROR:{}", ERR_MSG_NULL_CONNECT_VERSION_VAL);
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_CONNECT_VERSION_VAL));
			return resEntity;
		}
		
		reqOomBuildingServiceConnectionDto.setServiceClCd(serviceClCd);
		
		// 빌딩별 연동정보 상세 조회....
		BuildingServiceConnectionDetailResultDto buildingServiceConnectionDetailResultDto = buildingServiceService.readBuildingServiceConnectionInfo(reqOomBuildingServiceConnectionDto);
		if (buildingServiceConnectionDetailResultDto == null) {
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_READ_FAIL, buildingServiceConnectionDetailResultDto));
		} else {
			returnString = Const.Common.RESULT_CODE.SUCCESS;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, "", buildingServiceConnectionDetailResultDto));
		}
    	
    	return resEntity;
    }

}
