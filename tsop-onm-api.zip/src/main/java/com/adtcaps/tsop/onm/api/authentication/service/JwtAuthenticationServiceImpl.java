package com.adtcaps.tsop.onm.api.authentication.service;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import com.adtcaps.tsop.onm.api.authentication.domain.JwtAuthResultDto;
import com.adtcaps.tsop.onm.api.authentication.domain.JwtRequest;
import com.adtcaps.tsop.onm.api.authentication.mapper.JwtAuthenticationMapper;

@Service
public class JwtAuthenticationServiceImpl implements UserDetailsService{

  @Autowired
  JwtAuthenticationMapper jwtAuthenticationMapper;

    @Override
    public JwtAuthResultDto loadUserByUsername(String userid) throws UsernameNotFoundException {
      
    	JwtAuthResultDto jwtAuthResultDto = jwtAuthenticationMapper.readAuthUserByUserid(userid);
    	return jwtAuthResultDto;
    }

    public JwtAuthResultDto loadUserByUsernamePassword(JwtRequest reuqest) throws UsernameNotFoundException{
     
      JwtAuthResultDto jwtAuthResultDto = jwtAuthenticationMapper.readAuthUserByPassword(reuqest);
     
      return jwtAuthResultDto;
     
    }
    
}
