package com.adtcaps.tsop.onm.api.threshold.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;

import com.adtcaps.tsop.onm.api.domain.OomTenantResourceMonitoringThresholdDto;
import com.adtcaps.tsop.onm.api.threshold.domain.ThresholdDetailResultDto;
import com.adtcaps.tsop.onm.api.threshold.domain.ThresholdGridRequestDto;
import com.adtcaps.tsop.onm.api.threshold.domain.ThresholdGridResultDto;

/**
 * 
 * <ul>
 * <li>업무 그룹명 : tsop-onm-api</li>
 * <li>서브 업무명 : com.adtcaps.tsop.onm.api.threshold.mapper</li>
 * <li>설  명 : OomTenantResourceMonitoringThresholdMapper.java</li>
 * <li>작성일 : 2021. 1. 17.</li>
 * <li>작성자 : jeonyb4</li>
 * </ul>
 */
@Mapper
public interface OomTenantResourceMonitoringThresholdMapper {
	/**
	 * 
	 * listPageTenantResourceMonitoringThreshold
	 *
	 * @param thresholdGridRequestDto
	 * @return List<ThresholdGridResultDto>
	 */
	public List<ThresholdGridResultDto> listPageTenantResourceMonitoringThreshold(ThresholdGridRequestDto thresholdGridRequestDto);
	
	/**
	 * 
	 * createOomTenantResourceMonitoringThreshold
	 *
	 * @param reqOomTenantResourceMonitoringThresholdDto
	 * @return int
	 */
	public int createOomTenantResourceMonitoringThreshold(OomTenantResourceMonitoringThresholdDto reqOomTenantResourceMonitoringThresholdDto);
	
	/**
	 * 
	 * readOomTenantResourceMonitoringThreshold
	 *
	 * @param reqOomTenantResourceMonitoringThresholdDto
	 * @return ThresholdDetailResultDto
	 */
	public ThresholdDetailResultDto readOomTenantResourceMonitoringThreshold(OomTenantResourceMonitoringThresholdDto reqOomTenantResourceMonitoringThresholdDto);
	
	/**
	 * 
	 * updateOomTenantResourceMonitoringThreshold
	 *
	 * @param reqOomTenantResourceMonitoringThresholdDto
	 * @return int
	 */
	public int updateOomTenantResourceMonitoringThreshold(OomTenantResourceMonitoringThresholdDto reqOomTenantResourceMonitoringThresholdDto);
	
	/**
	 * 
	 * deleteOomTenantResourceMonitoringThreshold
	 *
	 * @param reqOomTenantResourceMonitoringThresholdDto
	 * @return int
	 */
	public int deleteOomTenantResourceMonitoringThreshold(OomTenantResourceMonitoringThresholdDto reqOomTenantResourceMonitoringThresholdDto);

}
