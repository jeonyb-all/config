package com.adtcaps.tsop.onm.api.dashboard.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.util.CollectionUtils;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.adtcaps.tsop.onm.api.dashboard.domain.DashboardAlarmCountResultDto;
import com.adtcaps.tsop.onm.api.dashboard.domain.DashboardAlarmGraphResultDto;
import com.adtcaps.tsop.onm.api.dashboard.domain.DashboardAlarmGridResultDto;
import com.adtcaps.tsop.onm.api.dashboard.domain.DashboardHttpErrResultDto;
import com.adtcaps.tsop.onm.api.dashboard.domain.DashboardHttpResponseResultDto;
import com.adtcaps.tsop.onm.api.dashboard.domain.DashboardRequestDto;
import com.adtcaps.tsop.onm.api.dashboard.domain.DashboardTopoResourceResultDto;
import com.adtcaps.tsop.onm.api.dashboard.domain.DashboardTrafficResultDto;
import com.adtcaps.tsop.onm.api.dashboard.service.DashboardService;
import com.adtcaps.tsop.onm.api.helper.constant.Const;
import com.adtcaps.tsop.onm.api.helper.domain.ResultDto;

import lombok.extern.slf4j.Slf4j;


/**
 * 
 * <ul>
 * <li>업무 그룹명 : tsop-onm-api</li>
 * <li>서브 업무명 : com.adtcaps.tsop.onm.api.dashboard.controller</li>
 * <li>설  명 : DashboardController.java</li>
 * <li>작성일 : 2021. 1. 31.</li>
 * <li>작성자 : song</li>
 * </ul>
 */
@Slf4j
@RestController
@RequestMapping("/api/dashboard")
public class DashboardController {

	private final String SUCC_MSG_UPDATE = "수정에 성공하였습니다.";
	
	private final String ERR_MSG_NULL_SEARCH_RESULT_LIST = "조회 결과가 없습니다.";
	private final String ERR_MSG_NULL_RESOURCE_LIST = "조회 대상 RESOURCE가 없습니다.";
	private final String ERR_MSG_UPDATE_FAIL = "수정에 실패하였습니다.";
	private final String ERR_MSG_NULL_TENANT_ID = "TENANT_ID가 없습니다.";
	private final String ERR_MSG_NULL_EVENT_ID = "EVENT_ID가 없습니다.";
	private final String ERR_MSG_NULL_ACK_ID = "ACK_ID가 없습니다.";
	private final String ERR_MSG_NULL_ACK_YN = "ACK_YN 값이 없습니다.";
	private final String ERR_MSG_NULL_MASK_YN = "MASK_YN 값이 없습니다.";
	private final String ERR_MSG_NULL_AUDIT_ID = "AUDIT_ID 값이 없습니다.";
	private final String ERR_MSG_NULL_RESOURCE_ID = "RESOURCE_ID 값이 없습니다.";
	private final String ERR_MSG_NULL_ALARM_CD = "ALARM_CD 값이 없습니다.";
	private final String ERR_MSG_NOT_YN = "입력된 값이 Y 또는 N 이 아닙니다.";
	
	
	@Autowired
	DashboardService dashboardService;
	
	
	@SuppressWarnings("rawtypes")
	@GetMapping(value="/topo-resource", produces="application/json; charset=UTF-8")
	public ResponseEntity listDashboardTopoResource(DashboardRequestDto reqDashboardDto) throws Exception {
		
		ResponseEntity<ResultDto> resEntity = null;
		
		if (reqDashboardDto.getTenantId() == null || "".equals(reqDashboardDto.getTenantId())) {
			log.error(">>>>>> tenantId ERROR:{}", ERR_MSG_NULL_TENANT_ID);
			resEntity = ResponseEntity.ok(new ResultDto(Const.Common.RESULT_CODE.FAIL, ERR_MSG_NULL_TENANT_ID));
			return resEntity;
		}
		
		String returnString = "";
		
		List<DashboardTopoResourceResultDto> dashboardTopoResourceList = dashboardService.listDashboardTopoResource(reqDashboardDto);
		if (CollectionUtils.isEmpty(dashboardTopoResourceList)) {
			returnString = Const.Common.RESULT_CODE.SUCCESS;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_SEARCH_RESULT_LIST, dashboardTopoResourceList));
		} else {
			returnString = Const.Common.RESULT_CODE.SUCCESS;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, "", dashboardTopoResourceList));
		}
     	
    	return resEntity;
	}
	
	
	@SuppressWarnings("rawtypes")
	@GetMapping(value="/alarm-graph", produces="application/json; charset=UTF-8")
	public ResponseEntity listDashboardAlarmGraph(DashboardRequestDto reqDashboardDto) throws Exception {
		
		ResponseEntity<ResultDto> resEntity = null;
		String returnString = "";
		
		List<DashboardAlarmGraphResultDto> dashboardAlarmGraphResultList = dashboardService.listDashboardAlarmGraph(reqDashboardDto);
		if (CollectionUtils.isEmpty(dashboardAlarmGraphResultList)) {
			returnString = Const.Common.RESULT_CODE.SUCCESS;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_SEARCH_RESULT_LIST, dashboardAlarmGraphResultList));
		} else {
			returnString = Const.Common.RESULT_CODE.SUCCESS;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, "", dashboardAlarmGraphResultList));
		}
    	
    	return resEntity;
	}
	
	
	@SuppressWarnings("rawtypes")
	@GetMapping(value="/alarm-list", produces="application/json; charset=UTF-8")
	public ResponseEntity listDashboardAlarmGrid(DashboardRequestDto reqDashboardDto) throws Exception {
		
		ResponseEntity<ResultDto> resEntity = null;
		String returnString = "";
		
		List<DashboardAlarmGridResultDto> dashboardAlarmListResultList = dashboardService.listDashboardAlarmGrid(reqDashboardDto);
		if (CollectionUtils.isEmpty(dashboardAlarmListResultList)) {
			returnString = Const.Common.RESULT_CODE.SUCCESS;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_SEARCH_RESULT_LIST, dashboardAlarmListResultList));
		} else {
			returnString = Const.Common.RESULT_CODE.SUCCESS;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, "", dashboardAlarmListResultList));
		}
    	
    	return resEntity;
	}
	
	
	@SuppressWarnings("rawtypes")
	@GetMapping(value="/tenant-alarm", produces="application/json; charset=UTF-8")
	public ResponseEntity listDashboardTenantAlarm(DashboardRequestDto reqDashboardDto) throws Exception {
		
		ResponseEntity<ResultDto> resEntity = null;
		String returnString = "";
		
		List<DashboardAlarmCountResultDto> dashboardAlarmCountResultList = dashboardService.listDashboardTenantAlarm(reqDashboardDto);
		if (CollectionUtils.isEmpty(dashboardAlarmCountResultList)) {
			returnString = Const.Common.RESULT_CODE.SUCCESS;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_SEARCH_RESULT_LIST, dashboardAlarmCountResultList));
		} else {
			returnString = Const.Common.RESULT_CODE.SUCCESS;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, "", dashboardAlarmCountResultList));
		}
    	
    	return resEntity;
	}
	
	
	@SuppressWarnings("rawtypes")
	@GetMapping(value="/resource-alarm", produces="application/json; charset=UTF-8")
	public ResponseEntity listDashboardResourceAlarm(DashboardRequestDto reqDashboardDto) throws Exception {
		
		ResponseEntity<ResultDto> resEntity = null;
		String returnString = "";
		
		List<DashboardAlarmCountResultDto> dashboardAlarmCountResultList = dashboardService.listDashboardResourceAlarm(reqDashboardDto);
		if (CollectionUtils.isEmpty(dashboardAlarmCountResultList)) {
			returnString = Const.Common.RESULT_CODE.SUCCESS;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_SEARCH_RESULT_LIST, dashboardAlarmCountResultList));
		} else {
			returnString = Const.Common.RESULT_CODE.SUCCESS;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, "", dashboardAlarmCountResultList));
		}
    	
    	return resEntity;
	}
	
	
	@SuppressWarnings("rawtypes")
	@GetMapping(value="/building-alarm", produces="application/json; charset=UTF-8")
	public ResponseEntity listDashboardBuildingAlarm(DashboardRequestDto reqDashboardDto) throws Exception {
		
		ResponseEntity<ResultDto> resEntity = null;
		String returnString = "";
		
		List<DashboardAlarmCountResultDto> dashboardAlarmCountResultList = dashboardService.listDashboardBuildingAlarm(reqDashboardDto);
		if (CollectionUtils.isEmpty(dashboardAlarmCountResultList)) {
			returnString = Const.Common.RESULT_CODE.SUCCESS;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_SEARCH_RESULT_LIST, dashboardAlarmCountResultList));
		} else {
			returnString = Const.Common.RESULT_CODE.SUCCESS;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, "", dashboardAlarmCountResultList));
		}
    	
    	return resEntity;
	}
	
	
	@SuppressWarnings("rawtypes")
	@GetMapping(value="/service-alarm", produces="application/json; charset=UTF-8")
	public ResponseEntity listDashboardServiceAlarm(DashboardRequestDto reqDashboardDto) throws Exception {
		
		ResponseEntity<ResultDto> resEntity = null;
		String returnString = "";
		
		List<DashboardAlarmCountResultDto> dashboardAlarmCountResultList = dashboardService.listDashboardServiceAlarm(reqDashboardDto);
		if (CollectionUtils.isEmpty(dashboardAlarmCountResultList)) {
			returnString = Const.Common.RESULT_CODE.SUCCESS;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_SEARCH_RESULT_LIST, dashboardAlarmCountResultList));
		} else {
			returnString = Const.Common.RESULT_CODE.SUCCESS;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, "", dashboardAlarmCountResultList));
		}
    	
    	return resEntity;
	}
	
	
	@SuppressWarnings("rawtypes")
	@GetMapping(value="/trffic-info", produces="application/json; charset=UTF-8")
	public ResponseEntity listDashboardTrafficResult(DashboardRequestDto reqDashboardDto) throws Exception {
		
		ResponseEntity<ResultDto> resEntity = null;
		
		if (reqDashboardDto.getTenantId() == null || "".equals(reqDashboardDto.getTenantId())) {
			log.error(">>>>>> tenantId ERROR:{}", ERR_MSG_NULL_TENANT_ID);
			resEntity = ResponseEntity.ok(new ResultDto(Const.Common.RESULT_CODE.FAIL, ERR_MSG_NULL_TENANT_ID));
			return resEntity;
		}
		
		reqDashboardDto.setOnmResourceCategoryCd("EHB");
		
		String returnString = "";
		int resourceCount = 0;
		
		resourceCount = dashboardService.getCountTenantResourceDetail(reqDashboardDto);
		if ( resourceCount < 1) {
			returnString = Const.Common.RESULT_CODE.SUCCESS;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_RESOURCE_LIST, resourceCount));
			return resEntity;
		} 

		List<DashboardTrafficResultDto> dashboardTrafficResultList = dashboardService.listDashboardTrafficResult(reqDashboardDto);
		if (CollectionUtils.isEmpty(dashboardTrafficResultList)) {
			returnString = Const.Common.RESULT_CODE.SUCCESS;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_SEARCH_RESULT_LIST, dashboardTrafficResultList));
		} else {
			returnString = Const.Common.RESULT_CODE.SUCCESS;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, "", dashboardTrafficResultList));
		}
    	
    	return resEntity;
	}
	
	
	@SuppressWarnings("rawtypes")
	@GetMapping(value="/http-err", produces="application/json; charset=UTF-8")
	public ResponseEntity listDashboardHttpErrResult(DashboardRequestDto reqDashboardDto) throws Exception {
		
		ResponseEntity<ResultDto> resEntity = null;
		
		if (reqDashboardDto.getTenantId() == null || "".equals(reqDashboardDto.getTenantId())) {
			log.error(">>>>>> tenantId ERROR:{}", ERR_MSG_NULL_TENANT_ID);
			resEntity = ResponseEntity.ok(new ResultDto(Const.Common.RESULT_CODE.FAIL, ERR_MSG_NULL_TENANT_ID));
			return resEntity;
		}
		
		reqDashboardDto.setOnmResourceCategoryCd("APP");
		
		String returnString = "";
		int resourceCount = 0;
		
		resourceCount = dashboardService.getCountTenantResourceDetail(reqDashboardDto);
		if ( resourceCount < 1) {
			returnString = Const.Common.RESULT_CODE.SUCCESS;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_RESOURCE_LIST, resourceCount));
			return resEntity;
		} 
		
		List<DashboardHttpErrResultDto> dashboardHttpErrResultList = dashboardService.listDashboardHttpErrResult(reqDashboardDto);
		if (CollectionUtils.isEmpty(dashboardHttpErrResultList)) {
			returnString = Const.Common.RESULT_CODE.SUCCESS;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_SEARCH_RESULT_LIST, dashboardHttpErrResultList));
		} else {
			returnString = Const.Common.RESULT_CODE.SUCCESS;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, "", dashboardHttpErrResultList));
		}
    	
    	return resEntity;
	}
	
	
	@SuppressWarnings("rawtypes")
	@GetMapping(value="/http-response", produces="application/json; charset=UTF-8")
	public ResponseEntity listDashboardHttpResponseResult(DashboardRequestDto reqDashboardDto) throws Exception {
		
		ResponseEntity<ResultDto> resEntity = null;
		
		if (reqDashboardDto.getTenantId() == null || "".equals(reqDashboardDto.getTenantId())) {
			log.error(">>>>>> tenantId ERROR:{}", ERR_MSG_NULL_TENANT_ID);
			resEntity = ResponseEntity.ok(new ResultDto(Const.Common.RESULT_CODE.FAIL, ERR_MSG_NULL_TENANT_ID));
			return resEntity;
		}
		
		reqDashboardDto.setOnmResourceCategoryCd("APP");
		
		String returnString = "";
		int resourceCount = 0;
		
		resourceCount = dashboardService.getCountTenantResourceDetail(reqDashboardDto);
		if ( resourceCount < 1) {
			returnString = Const.Common.RESULT_CODE.SUCCESS;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_RESOURCE_LIST, resourceCount));
			return resEntity;
		} 
		
		List<DashboardHttpResponseResultDto> dashboardHttpResponseResultList = dashboardService.listDashboardHttpResponseResult(reqDashboardDto);
		if (CollectionUtils.isEmpty(dashboardHttpResponseResultList)) {
			returnString = Const.Common.RESULT_CODE.SUCCESS;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_SEARCH_RESULT_LIST, dashboardHttpResponseResultList));
		} else {
			returnString = Const.Common.RESULT_CODE.SUCCESS;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, "", dashboardHttpResponseResultList));
		}
    	
    	return resEntity;
	}
	
	
	@SuppressWarnings("rawtypes")
	@GetMapping(value="/update-alarm-ack", produces="application/json; charset=UTF-8")
	public ResponseEntity updateOomAlarmEventAckYn(DashboardRequestDto reqDashboardDto) throws Exception {
		
		ResponseEntity<ResultDto> resEntity = null;
		
		if (reqDashboardDto.getTenantId() == null || "".equals(reqDashboardDto.getTenantId())) {
			log.error(">>>>>> tenantId ERROR:{}", ERR_MSG_NULL_TENANT_ID);
			resEntity = ResponseEntity.ok(new ResultDto(Const.Common.RESULT_CODE.FAIL, ERR_MSG_NULL_TENANT_ID));
			return resEntity;
		}
		
		if (reqDashboardDto.getOnmAlarmEventId() == null || "".equals(reqDashboardDto.getOnmAlarmEventId())) {
			log.error(">>>>>> eventId ERROR:{}", ERR_MSG_NULL_EVENT_ID);
			resEntity = ResponseEntity.ok(new ResultDto(Const.Common.RESULT_CODE.FAIL, ERR_MSG_NULL_EVENT_ID));
			return resEntity;
		}
		
		if (reqDashboardDto.getOnmAlarmAckId() == null || "".equals(reqDashboardDto.getOnmAlarmAckId())) {
			log.error(">>>>>> onmAlarmAckId ERROR:{}", ERR_MSG_NULL_ACK_ID);
			resEntity = ResponseEntity.ok(new ResultDto(Const.Common.RESULT_CODE.FAIL, ERR_MSG_NULL_ACK_ID));
			return resEntity;
		}
		
		if (reqDashboardDto.getOnmAlarmAckYn() == null || "".equals(reqDashboardDto.getOnmAlarmAckYn())) {
			log.error(">>>>>> onmAlarmAckYn ERROR:{}", ERR_MSG_NULL_ACK_YN);
			resEntity = ResponseEntity.ok(new ResultDto(Const.Common.RESULT_CODE.FAIL, ERR_MSG_NULL_ACK_YN));
			return resEntity;
		}
		
		if (!"Y".equals(reqDashboardDto.getOnmAlarmAckYn()) && !"N".equals(reqDashboardDto.getOnmAlarmAckYn())) {
			log.error(">>>>>> onmAlarmAckYn ERROR:{}", ERR_MSG_NOT_YN);
			resEntity = ResponseEntity.ok(new ResultDto(Const.Common.RESULT_CODE.FAIL, ERR_MSG_NOT_YN));
			return resEntity;
		}
		
		String returnString = "";
		
		int updateCount = dashboardService.updateOomAlarmEventAckYn(reqDashboardDto);
		
		if (updateCount < 1) {
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_UPDATE_FAIL, updateCount));
		} else {
			returnString = Const.Common.RESULT_CODE.SUCCESS;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, SUCC_MSG_UPDATE, updateCount));
		}
    	
    	return resEntity;
	}
	
	
	@SuppressWarnings("rawtypes")
	@GetMapping(value="/update-alarm-mask", produces="application/json; charset=UTF-8")
	public ResponseEntity updateOomAlarmEventMaskYn(DashboardRequestDto reqDashboardDto) throws Exception {
		
		ResponseEntity<ResultDto> resEntity = null;
		
		if (reqDashboardDto.getTenantId() == null || "".equals(reqDashboardDto.getTenantId())) {
			log.error(">>>>>> tenantId ERROR:{}", ERR_MSG_NULL_TENANT_ID);
			resEntity = ResponseEntity.ok(new ResultDto(Const.Common.RESULT_CODE.FAIL, ERR_MSG_NULL_TENANT_ID));
			return resEntity;
		}
		if (reqDashboardDto.getOnmResourceId() == null || "".equals(reqDashboardDto.getOnmResourceId())) {
			log.error(">>>>>> onmResourceId ERROR:{}", ERR_MSG_NULL_RESOURCE_ID);
			resEntity = ResponseEntity.ok(new ResultDto(Const.Common.RESULT_CODE.FAIL, ERR_MSG_NULL_RESOURCE_ID));
			return resEntity;
		}
		if (reqDashboardDto.getOnmAlarmCd() == null || "".equals(reqDashboardDto.getOnmAlarmCd())) {
			log.error(">>>>>> onmAlarmCd ERROR:{}", ERR_MSG_NULL_ALARM_CD);
			resEntity = ResponseEntity.ok(new ResultDto(Const.Common.RESULT_CODE.FAIL, ERR_MSG_NULL_ALARM_CD));
			return resEntity;
		}
		if (reqDashboardDto.getAuditId() == null || "".equals(reqDashboardDto.getAuditId())) {
			log.error(">>>>>> auditId ERROR:{}", ERR_MSG_NULL_AUDIT_ID);
			resEntity = ResponseEntity.ok(new ResultDto(Const.Common.RESULT_CODE.FAIL, ERR_MSG_NULL_AUDIT_ID));
			return resEntity;
		}
		if (reqDashboardDto.getOnmAlarmMaskYn() == null || "".equals(reqDashboardDto.getOnmAlarmMaskYn())) {
			log.error(">>>>>> onmAlarmMaskYn ERROR:{}", ERR_MSG_NULL_MASK_YN);
			resEntity = ResponseEntity.ok(new ResultDto(Const.Common.RESULT_CODE.FAIL, ERR_MSG_NULL_MASK_YN));
			return resEntity;
		}
		if (!"Y".equals(reqDashboardDto.getOnmAlarmMaskYn()) && !"N".equals(reqDashboardDto.getOnmAlarmMaskYn())) {
			log.error(">>>>>> onmAlarmMaskYn ERROR:{}", ERR_MSG_NOT_YN);
			resEntity = ResponseEntity.ok(new ResultDto(Const.Common.RESULT_CODE.FAIL, ERR_MSG_NOT_YN));
			return resEntity;
		}
		
		String returnString = "";
		
		int updateCount = dashboardService.updateOomAlarmMaskYn(reqDashboardDto);
		
		if (updateCount < 1) {
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_UPDATE_FAIL, updateCount));
		} else {
			returnString = Const.Common.RESULT_CODE.SUCCESS;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, SUCC_MSG_UPDATE, updateCount));
		}
    	
    	return resEntity;
	}
	
}
