package com.adtcaps.tsop.onm.api.send.service.impl;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.CollectionUtils;

import com.adtcaps.tsop.onm.api.alimTalk.domain.AlimTalkDetailDto;
import com.adtcaps.tsop.onm.api.alimTalk.domain.AlimTalkRequestDto;
import com.adtcaps.tsop.onm.api.alimTalk.service.AlimTalkService;
import com.adtcaps.tsop.onm.api.domain.OomSmsHistDetailDto;
import com.adtcaps.tsop.onm.api.domain.OomSmsHistDto;
import com.adtcaps.tsop.onm.api.helper.util.CommonDateUtil;
import com.adtcaps.tsop.onm.api.send.domain.NoticeSendReceiverDto;
import com.adtcaps.tsop.onm.api.send.domain.SmsHistDetailResultDto;
import com.adtcaps.tsop.onm.api.send.domain.SmsHistGridRequestDto;
import com.adtcaps.tsop.onm.api.send.domain.SmsHistGridResultDto;
import com.adtcaps.tsop.onm.api.send.mapper.OomSmsHistDetailMapper;
import com.adtcaps.tsop.onm.api.send.mapper.OomSmsHistMapper;
import com.adtcaps.tsop.onm.api.send.service.SendService;

/**
 * 
 * <ul>
 * <li>업무 그룹명 : tsop-onm-api</li>
 * <li>서브 업무명 : com.adtcaps.tsop.onm.api.send.service.impl</li>
 * <li>설  명 : SendServiceImpl.java</li>
 * <li>작성일 : 2021. 1. 30.</li>
 * <li>작성자 : jeonyb4</li>
 * </ul>
 */
@Transactional
@Service
public class SendServiceImpl implements SendService {
	
	@Autowired
	private OomSmsHistMapper oomSmsHistMapper;
	
	@Autowired
	private OomSmsHistDetailMapper oomSmsHistDetailMapper;
	
	@Autowired
	private AlimTalkService alimTalkService;
	
	/**
	 * 
	 * listPageSmsHist
	 *
	 * @param reqSmsHistGridRequestDto
	 * @return List<SmsHistGridResultDto>
	 * @throws Exception 
	 */
	@Override
	public List<SmsHistGridResultDto> listPageSmsHist(SmsHistGridRequestDto reqSmsHistGridRequestDto) throws Exception {
		
		List<SmsHistGridResultDto> smsHistGridResultDtoList = null;
		try {
			String fromDate = reqSmsHistGridRequestDto.getFromDate();
    		String toDate = reqSmsHistGridRequestDto.getToDate();
    		
    		fromDate = CommonDateUtil.makeFromDatetime(fromDate);
    		toDate = CommonDateUtil.makeToDatetime(toDate);
    		
    		reqSmsHistGridRequestDto.setFromDate(fromDate);
    		reqSmsHistGridRequestDto.setToDate(toDate);
    		
    		smsHistGridResultDtoList = oomSmsHistMapper.listPageSmsHist(reqSmsHistGridRequestDto);
    		if (!CollectionUtils.isEmpty(smsHistGridResultDtoList)) {
    			for (int idx = 0; idx < smsHistGridResultDtoList.size(); idx++) {
    				
    				SmsHistGridResultDto smsHistGridResultDto = smsHistGridResultDtoList.get(idx);
    				
    				String transDatetime = StringUtils.defaultString(smsHistGridResultDto.getTransDatetime());
    				transDatetime = CommonDateUtil.makeDatetimeFormat(transDatetime);
    				smsHistGridResultDto.setTransDatetimeFormat(transDatetime);
    				
    				smsHistGridResultDtoList.set(idx, smsHistGridResultDto);
    			}
    		}
    		
		} catch (Exception e) {
			throw e;
		}
		return smsHistGridResultDtoList;
	}
	
	/**
	 * 
	 * readSmsHist
	 *
	 * @param reqOomSmsHistDto
	 * @return SmsHistDetailResultDto
	 * @throws Exception 
	 */
	@Override
	public SmsHistDetailResultDto readSmsHist(OomSmsHistDto reqOomSmsHistDto) throws Exception {
		
		SmsHistDetailResultDto smsHistDetailResultDto = null;
		try {
			// 발송내역 상세조회
			smsHistDetailResultDto = oomSmsHistMapper.readOomSmsHist(reqOomSmsHistDto);
    		if (smsHistDetailResultDto != null) {
				String transDatetime = StringUtils.defaultString(smsHistDetailResultDto.getTransDatetime());
				transDatetime = CommonDateUtil.makeDatetimeFormat(transDatetime);
				smsHistDetailResultDto.setTransDatetime(transDatetime);
				
				// 수신자 목록조회
				OomSmsHistDetailDto reqOomSmsHistDetailDto = new OomSmsHistDetailDto();
				reqOomSmsHistDetailDto.setSmsTransSeq(reqOomSmsHistDto.getSmsTransSeq());
				List<NoticeSendReceiverDto> noticeSendReceiverDtoList = oomSmsHistDetailMapper.listSmsHistDetail(reqOomSmsHistDetailDto);
				smsHistDetailResultDto.setRecevierList(noticeSendReceiverDtoList);
    		}
    		
		} catch (Exception e) {
			throw e;
		}
		return smsHistDetailResultDto;
	}
	
	/**
	 * 
	 * resendSmsHistDto
	 *
	 * @param paramOomSmsHistDto
	 * @return String
	 * @throws Exception 
	 */
	@Override
	public String resendSmsHistDto(OomSmsHistDto paramOomSmsHistDto) throws Exception {
		
		String resultCd = "2";
		
		try {
			// 발송내역 상세조회
			String auditId = paramOomSmsHistDto.getAuditId();
			SmsHistDetailResultDto smsHistDetailResultDto = oomSmsHistMapper.readOomSmsHist(paramOomSmsHistDto);
    		if (smsHistDetailResultDto != null) {
    			String msgContent = smsHistDetailResultDto.getMsgContent();
    			String smsCreateCd = smsHistDetailResultDto.getSmsCreateCd();
    			String tenantId = StringUtils.defaultString(smsHistDetailResultDto.getTenantId());
    			String tmpltCode = StringUtils.defaultString(smsHistDetailResultDto.getTmpltCode());
    			
				// 수신자 목록조회
				OomSmsHistDetailDto paramOomSmsHistDetailDto = new OomSmsHistDetailDto();
				paramOomSmsHistDetailDto.setSmsTransSeq(paramOomSmsHistDto.getSmsTransSeq());
				List<NoticeSendReceiverDto> noticeSendReceiverDtoList = oomSmsHistDetailMapper.listSmsHistDetail(paramOomSmsHistDetailDto);
				StringBuilder rcvPhoneNumBuilder = new StringBuilder();
				List<AlimTalkDetailDto> alimTalkDetailDtoList = new ArrayList<AlimTalkDetailDto>();
				for (int idx = 0; idx < noticeSendReceiverDtoList.size(); idx++) {
					NoticeSendReceiverDto reqNoticeSendReceiverDto = noticeSendReceiverDtoList.get(idx);
					String rcverId = StringUtils.defaultString(reqNoticeSendReceiverDto.getRcverId());
					String rcverName = StringUtils.defaultString(reqNoticeSendReceiverDto.getRcverName());
					String rcvPhoneNum = StringUtils.defaultString(reqNoticeSendReceiverDto.getRcvPhoneNum());
					
					AlimTalkDetailDto alimTalkDetailDto = new AlimTalkDetailDto();
					alimTalkDetailDto.setRcverId(rcverId);
					alimTalkDetailDto.setRcverName(rcverName);
					alimTalkDetailDto.setRcvPhoneNum(rcvPhoneNum);
					alimTalkDetailDtoList.add(alimTalkDetailDto);
					
					rcvPhoneNumBuilder.append(rcvPhoneNum);
					if (idx != noticeSendReceiverDtoList.size() - 1) {
						rcvPhoneNumBuilder.append(",");
					}
				}
				// 카카오 알림톡 발송 처리..
				AlimTalkRequestDto alimTalkRequestDto = new AlimTalkRequestDto();
				alimTalkRequestDto.setTenantId(tenantId);
				alimTalkRequestDto.setRecipient(rcvPhoneNumBuilder.toString());
				alimTalkRequestDto.setMessage(msgContent);
				alimTalkRequestDto.setTmpltCode(tmpltCode);
				alimTalkRequestDto.setSmsCreateCd(smsCreateCd);
				alimTalkRequestDto.setAuditId(auditId);
				alimTalkRequestDto.setDetailList(alimTalkDetailDtoList);
				resultCd = alimTalkService.sendOnmAlimTalk(alimTalkRequestDto);
				if (!"1".equals(resultCd)) {
					// 성공이 아니면.. 모두 실패 처리...
					resultCd = "2";
				}
    		}
			
		} catch (Exception e) {
			throw e;
		}
		return resultCd;
	}

}
