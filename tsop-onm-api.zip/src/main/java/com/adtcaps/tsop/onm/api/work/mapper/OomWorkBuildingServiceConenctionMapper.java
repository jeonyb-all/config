package com.adtcaps.tsop.onm.api.work.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;

import com.adtcaps.tsop.onm.api.domain.OomWorkBuildingServiceConenctionDto;
import com.adtcaps.tsop.onm.api.work.domain.InterfaceWorkDetailResultDto;
import com.adtcaps.tsop.onm.api.work.domain.SearchWorkConenctionDto;
import com.adtcaps.tsop.onm.api.work.domain.WorkServiceUseYnDto;

/**
 * 
 * <ul>
 * <li>업무 그룹명 : tsop-onm-api</li>
 * <li>서브 업무명 : com.adtcaps.tsop.onm.api.work.mapper</li>
 * <li>설  명 : OomWorkBuildingServiceConenctionMapper.java</li>
 * <li>작성일 : 2021. 1. 27.</li>
 * <li>작성자 : jeonyb4</li>
 * </ul>
 */
@Mapper
public interface OomWorkBuildingServiceConenctionMapper {
	/**
	 * 
	 * insertOomWorkBuildingServiceConenction
	 *
	 * @param reqOomWorkBuildingServiceConenctionDto
	 * @return int
	 */
	public int insertOomWorkBuildingServiceConenction(OomWorkBuildingServiceConenctionDto reqOomWorkBuildingServiceConenctionDto);
	
	/**
	 * 
	 * deleteOomWorkBuildingServiceConenction
	 *
	 * @param reqOomWorkBuildingServiceConenctionDto
	 * @return int
	 */
	public int deleteOomWorkBuildingServiceConenction(OomWorkBuildingServiceConenctionDto reqOomWorkBuildingServiceConenctionDto);
	
	/**
	 * 
	 * mergeOomWorkBuildingServiceConenction
	 *
	 * @param reqOomWorkBuildingServiceConenctionDto
	 * @return int
	 */
	public int mergeOomWorkBuildingServiceConenction(OomWorkBuildingServiceConenctionDto reqOomWorkBuildingServiceConenctionDto);
	
	/**
	 * 
	 * updateOomWorkBuildingServiceConenctionInterface
	 *
	 * @param reqOomWorkBuildingServiceConenctionDto
	 * @return int
	 */
	public int updateOomWorkBuildingServiceConenctionInterface(OomWorkBuildingServiceConenctionDto reqOomWorkBuildingServiceConenctionDto);
	
	/**
	 * 
	 * updateOomWorkBuildingServiceConenctionUseYn
	 *
	 * @param reqOomWorkBuildingServiceConenctionDto
	 * @return int
	 */
	public int updateOomWorkBuildingServiceConenctionUseYn(OomWorkBuildingServiceConenctionDto reqOomWorkBuildingServiceConenctionDto);
	
	/**
	 * 
	 * readInterfaceWorkDetail
	 *
	 * @param reqOomWorkBuildingServiceConenctionDto
	 * @return InterfaceWorkDetailResultDto
	 */
	public InterfaceWorkDetailResultDto readInterfaceWorkDetail(OomWorkBuildingServiceConenctionDto reqOomWorkBuildingServiceConenctionDto);
	
	/**
	 * 
	 * readInterfaceWorkDetailAttachFile
	 *
	 * @param reqOomWorkBuildingServiceConenctionDto
	 * @return InterfaceWorkDetailResultDto
	 */
	public InterfaceWorkDetailResultDto readInterfaceWorkDetailAttachFile(OomWorkBuildingServiceConenctionDto reqOomWorkBuildingServiceConenctionDto);
	
	/**
	 * 
	 * listInterfaceWorkDetail
	 *
	 * @param reqOomWorkBuildingServiceConenctionDto
	 * @return List<InterfaceWorkDetailResultDto>
	 */
	public List<InterfaceWorkDetailResultDto> listInterfaceWorkDetail(OomWorkBuildingServiceConenctionDto reqOomWorkBuildingServiceConenctionDto);
	
	/**
	 * 
	 * listWorkBuildingService
	 * 
	 * @param reqOomWorkBuildingServiceConenctionDto
	 * @return List<OomWorkBuildingServiceConenctionDto>
	 */
	public List<WorkServiceUseYnDto> listWorkBuildingService(OomWorkBuildingServiceConenctionDto reqOomWorkBuildingServiceConenctionDto);
	
	/**
	 * 
	 * listWorkBuildingNotService
	 *
	 * @param reqOomWorkBuildingServiceConenctionDto
	 * @return List<WorkServiceUseYnDto>
	 */
	public List<WorkServiceUseYnDto> listWorkBuildingNotService(OomWorkBuildingServiceConenctionDto reqOomWorkBuildingServiceConenctionDto);
	
	/**
	 * 
	 * listOomWorkBuildingServiceConenction
	 *
	 * @param reqOomWorkBuildingServiceConenctionDto
	 * @return List<SearchWorkConenctionDto>
	 */
	public List<SearchWorkConenctionDto> listOomWorkBuildingServiceConenction(OomWorkBuildingServiceConenctionDto reqOomWorkBuildingServiceConenctionDto);
	
	/**
	 * 
	 * updateWorkInterfaceAttachFileNum
	 *
	 * @param reqOomWorkBuildingServiceConenctionDto
	 * @return int
	 */
	public int updateWorkInterfaceAttachFileNum(OomWorkBuildingServiceConenctionDto reqOomWorkBuildingServiceConenctionDto);
	
	/**
	 * 
	 * createServiceFromWork
	 *
	 * @param reqOomWorkBuildingServiceConenctionDto
	 * @return int
	 */
	public int createServiceFromWork(OomWorkBuildingServiceConenctionDto reqOomWorkBuildingServiceConenctionDto);
	
	/**
	 * 
	 * updateServiceUseYnFromWork
	 *
	 * @param reqOomWorkBuildingServiceConenctionDto
	 * @return int
	 */
	public int updateServiceUseYnFromWork(OomWorkBuildingServiceConenctionDto reqOomWorkBuildingServiceConenctionDto);
	
	/**
	 * 
	 * createServiceConnectionFromWork
	 *
	 * @param reqOomWorkBuildingServiceConenctionDto
	 * @return int
	 */
	public int createServiceConnectionFromWork(OomWorkBuildingServiceConenctionDto reqOomWorkBuildingServiceConenctionDto);
	
	/**
	 * 
	 * updateServiceConnectionFromWork
	 *
	 * @param reqOomWorkBuildingServiceConenctionDto
	 * @return int
	 */
	public int updateServiceConnectionFromWork(OomWorkBuildingServiceConenctionDto reqOomWorkBuildingServiceConenctionDto);

}
