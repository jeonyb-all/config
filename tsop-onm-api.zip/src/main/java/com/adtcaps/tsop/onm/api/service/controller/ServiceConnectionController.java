package com.adtcaps.tsop.onm.api.service.controller;

import java.io.File;
import java.io.FileInputStream;
import java.io.OutputStream;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.io.FileUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.util.CollectionUtils;
import org.springframework.util.FileCopyUtils;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.adtcaps.tsop.onm.api.authentication.domain.JwtAuthResultDto;
import com.adtcaps.tsop.onm.api.building.service.BuildingServiceService;
import com.adtcaps.tsop.onm.api.domain.OomBuildingServiceConnectionDto;
import com.adtcaps.tsop.onm.api.domain.OomServiceConnectionApiListDto;
import com.adtcaps.tsop.onm.api.domain.OomServiceConnectionDto;
import com.adtcaps.tsop.onm.api.domain.OomUserRoleAuthorityDetailDto;
import com.adtcaps.tsop.onm.api.file.domain.BlobRequestDto;
import com.adtcaps.tsop.onm.api.helper.constant.Const;
import com.adtcaps.tsop.onm.api.helper.domain.ResultDto;
import com.adtcaps.tsop.onm.api.helper.util.PageUtil;
import com.adtcaps.tsop.onm.api.service.domain.LinkageStandardVersionForComboResultDto;
import com.adtcaps.tsop.onm.api.service.domain.ServiceConnectionDetailResultDto;
import com.adtcaps.tsop.onm.api.service.domain.ServiceConnectionGridRequestDto;
import com.adtcaps.tsop.onm.api.service.domain.ServiceConnectionGridResultDto;
import com.adtcaps.tsop.onm.api.service.domain.ServiceConnectionProcessingDto;
import com.adtcaps.tsop.onm.api.service.domain.ServiceSysLinkageMethodForComboResultDto;
import com.adtcaps.tsop.onm.api.service.domain.ServiceSysNameForComboResultDto;
import com.adtcaps.tsop.onm.api.service.service.ServiceConnectionService;
import com.adtcaps.tsop.onm.api.user.domain.UserRoleMenuAuthorityRequestDto;
import com.adtcaps.tsop.onm.api.user.service.UserRoleService;

import lombok.extern.slf4j.Slf4j;

/**
 * 
 * <ul>
 * <li>업무 그룹명 : tsop-onm-api</li>
 * <li>서브 업무명 : com.adtcaps.tsop.onm.api.service.controller</li>
 * <li>설  명 : ServiceConnectionController.java</li>
 * <li>작성일 : 2021. 1. 27.</li>
 * <li>작성자 : jeonyb4</li>
 * </ul>
 */
@Slf4j
@RestController
@RequestMapping("/api/service-connections")
public class ServiceConnectionController {
	
	private final String MENU_ID = "ONM0015";
	
	private final String ERR_MSG_NULL_LOGIN_USER_ID = "로그인 사용자ID가 없습니다.";
	private final String ERR_MSG_NULL_MGR_YN = "관리자여부가 없습니다.";
	private final String ERR_MSG_NULL_PAGE_NUMBER = "페이지 번호가 없습니다.";
	private final String ERR_MSG_NULL_SERVICE_CONNECTION_INFO = "서비스연동정보가 없습니다.";
	private final String ERR_MSG_NULL_SERVICE_CL_CD = "서비스구분코드가 없습니다.";
	private final String ERR_MSG_NULL_SERVICE_SYS_NAME = "서비스시스템명이 없습니다.";
	private final String ERR_MSG_NULL_LINKAGE_STANDARD_VERSION_VAL = "연동규격버전값이 없습니다.";
	private final String ERR_MSG_NULL_SERVICE_SYS_LINKAGE_METHOD_CD = "서비스시스템연동방식코드가 없습니다.";
	private final String ERR_MSG_NULL_LOCAL_FILE_PATH = "로컬파일경로가 없습니다.";
	
	private final String ERR_MSG_ALREADY_EXIST_SERVICE_CONNECTION = "해당 서비스연동 정보가 이미 존재하므로 등록할 수 없습니다.";
	private final String ERR_MSG_ALREADY_USE_SERVICE_CONNECTION = "해당 서비스연동 정보가 이미 사용중이므로 삭제할 수 없습니다.";
	
	private final String ERR_MSG_NO_AUTH = "권한이 없는 사용자 입니다.";
	private final String ERR_MSG_NULL_SEARCH_RESULT_LIST = "조회 결과가 없습니다.";
	private final String ERR_MSG_ATTACH_FILE_DELETE_FAIL = "첨부파일 삭제에 실패하였습니다.";
	private final String ERR_MSG_CREATE_FAIL = "등록에 실패하였습니다.";
	private final String ERR_MSG_READ_FAIL = "조회에 실패하였습니다.";
	private final String ERR_MSG_UPDATE_FAIL = "수정에 실패하였습니다.";
	private final String ERR_MSG_DELETE_FAIL = "삭제에 실패하였습니다.";
	
	@Autowired
	private ServiceConnectionService serviceConnectionService;
	
	@Autowired
	private BuildingServiceService buildingServiceService;
	
	@Autowired
	private UserRoleService userRoleService;
	
	/**
	 * 
	 * listServiceSysLinkageMethodForCombo
	 *
	 * @param reqOomServiceConnectionDto
	 * @return ResponseEntity
	 */
	@SuppressWarnings("rawtypes")
    @GetMapping(value="/service-sys-linkage-methods/combobox", produces="application/json; charset=UTF-8")
    public ResponseEntity listServiceSysLinkageMethodForCombo(OomServiceConnectionDto reqOomServiceConnectionDto) throws Exception {
        
    	ResponseEntity<ResultDto> resEntity = null;
		String returnString = "";
    	
		String serviceClCd = StringUtils.defaultString(reqOomServiceConnectionDto.getServiceClCd());
		if ("".equals(serviceClCd)) {
			log.error(">>>>>> serviceClCd ERROR:{}", ERR_MSG_NULL_SERVICE_CL_CD);
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_SERVICE_CL_CD));
			return resEntity;
		}
		// 콤보박스 제공용 서비스시스템연동방식코드 목록 조회....
		List<ServiceSysLinkageMethodForComboResultDto> ServiceSysLinkageMethodForComboResultDtoList = serviceConnectionService.listServiceSysLinkageMethodForCombo(reqOomServiceConnectionDto);
		if (CollectionUtils.isEmpty(ServiceSysLinkageMethodForComboResultDtoList)) {
			returnString = Const.Common.RESULT_CODE.SUCCESS;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_SEARCH_RESULT_LIST, ServiceSysLinkageMethodForComboResultDtoList));
		} else {
			returnString = Const.Common.RESULT_CODE.SUCCESS;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, "", ServiceSysLinkageMethodForComboResultDtoList));
		}
    	
    	return resEntity;
    }
	
	/**
	 * 
	 * listServiceSysNameForCombo
	 *
	 * @param reqOomServiceConnectionDto
	 * @return ResponseEntity
	 */
	@SuppressWarnings("rawtypes")
    @GetMapping(value="/service-sys-names/combobox", produces="application/json; charset=UTF-8")
    public ResponseEntity listServiceSysNameForCombo(OomServiceConnectionDto reqOomServiceConnectionDto) throws Exception {
        
    	ResponseEntity<ResultDto> resEntity = null;
		String returnString = "";
    	
		String serviceClCd = StringUtils.defaultString(reqOomServiceConnectionDto.getServiceClCd());
		if ("".equals(serviceClCd)) {
			log.error(">>>>>> serviceClCd ERROR:{}", ERR_MSG_NULL_SERVICE_CL_CD);
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_SERVICE_CL_CD));
			return resEntity;
		}
		String serviceSysLinkageMethodCd = StringUtils.defaultString(reqOomServiceConnectionDto.getServiceSysLinkageMethodCd());
		if ("".equals(serviceSysLinkageMethodCd)) {
			log.error(">>>>>> serviceSysLinkageMethodCd ERROR:{}", ERR_MSG_NULL_SERVICE_SYS_LINKAGE_METHOD_CD);
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_SERVICE_SYS_LINKAGE_METHOD_CD));
			return resEntity;
		}
		// 콤보박스 제공용 서비스시스템연동방식코드 목록 조회....
		List<ServiceSysNameForComboResultDto> serviceSysNameForComboResultDtoList = serviceConnectionService.listServiceSysNameForCombo(reqOomServiceConnectionDto);
		if (CollectionUtils.isEmpty(serviceSysNameForComboResultDtoList)) {
			returnString = Const.Common.RESULT_CODE.SUCCESS;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_SEARCH_RESULT_LIST, serviceSysNameForComboResultDtoList));
		} else {
			returnString = Const.Common.RESULT_CODE.SUCCESS;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, "", serviceSysNameForComboResultDtoList));
		}
    	
    	return resEntity;
    }
	
	/**
	 * 
	 * listLinkageStandardVersionForCombo
	 *
	 * @param reqOomServiceConnectionDto
	 * @return ResponseEntity
	 */
	@SuppressWarnings("rawtypes")
    @GetMapping(value="/linkage-standard-versions/combobox", produces="application/json; charset=UTF-8")
    public ResponseEntity listLinkageStandardVersionForCombo(OomServiceConnectionDto reqOomServiceConnectionDto) throws Exception {
        
    	ResponseEntity<ResultDto> resEntity = null;
		String returnString = "";
    	
		String serviceClCd = StringUtils.defaultString(reqOomServiceConnectionDto.getServiceClCd());
		if ("".equals(serviceClCd)) {
			log.error(">>>>>> serviceClCd ERROR:{}", ERR_MSG_NULL_SERVICE_CL_CD);
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_SERVICE_CL_CD));
			return resEntity;
		}
		String serviceSysLinkageMethodCd = StringUtils.defaultString(reqOomServiceConnectionDto.getServiceSysLinkageMethodCd());
		if ("".equals(serviceSysLinkageMethodCd)) {
			log.error(">>>>>> serviceSysLinkageMethodCd ERROR:{}", ERR_MSG_NULL_SERVICE_SYS_LINKAGE_METHOD_CD);
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_SERVICE_SYS_LINKAGE_METHOD_CD));
			return resEntity;
		}
		String serviceSysName = StringUtils.defaultString(reqOomServiceConnectionDto.getServiceSysName());
		if ("".equals(serviceSysName)) {
			log.error(">>>>>> serviceSysName ERROR:{}", ERR_MSG_NULL_SERVICE_SYS_NAME);
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_SERVICE_SYS_NAME));
			return resEntity;
		}
		// 콤보박스 제공용 서비스시스템연동방식코드 목록 조회....
		List<LinkageStandardVersionForComboResultDto> linkageStandardVersionForComboResultDtoList = serviceConnectionService.listLinkageStandardVersionForCombo(reqOomServiceConnectionDto);
		if (CollectionUtils.isEmpty(linkageStandardVersionForComboResultDtoList)) {
			returnString = Const.Common.RESULT_CODE.SUCCESS;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_SEARCH_RESULT_LIST, linkageStandardVersionForComboResultDtoList));
		} else {
			returnString = Const.Common.RESULT_CODE.SUCCESS;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, "", linkageStandardVersionForComboResultDtoList));
		}
    	
    	return resEntity;
    }
	
	/**
	 * 
	 * listPageServiceConnection
	 *
	 * @param serviceConnectionGridRequestDto
	 * @return ResponseEntity
	 */
	@SuppressWarnings("rawtypes")
    @GetMapping(value="", produces="application/json; charset=UTF-8")
    public ResponseEntity listPageServiceConnection(ServiceConnectionGridRequestDto serviceConnectionGridRequestDto) throws Exception {
        
    	ResponseEntity<ResultDto> resEntity = null;
		String returnString = "";
    	
		int pageNumber = serviceConnectionGridRequestDto.getPageNumber();
		if (pageNumber < 1) {
			log.error(">>>>>> pageNumber ERROR:{}", ERR_MSG_NULL_PAGE_NUMBER);
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_PAGE_NUMBER));
			return resEntity;
		}
		// 서비스연동 목록 조회....
		Map<String, Object> serviceConnectionGridResultDtoListMap = new HashMap<String, Object>();
		List<ServiceConnectionGridResultDto> serviceConnectionGridResultDtoList = serviceConnectionService.listPageServiceConnection(serviceConnectionGridRequestDto);
		if (CollectionUtils.isEmpty(serviceConnectionGridResultDtoList)) {
			returnString = Const.Common.RESULT_CODE.SUCCESS;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_SEARCH_RESULT_LIST, serviceConnectionGridResultDtoListMap));
		} else {
			returnString = Const.Common.RESULT_CODE.SUCCESS;
			serviceConnectionGridResultDtoListMap.put(Const.Definition.PAGE.PAGER, PageUtil.getPageInfo(serviceConnectionGridResultDtoList));
			serviceConnectionGridResultDtoListMap.put(Const.Definition.PAGE.LISTS, serviceConnectionGridResultDtoList);
			resEntity = ResponseEntity.ok(new ResultDto(returnString, "", serviceConnectionGridResultDtoListMap));
		}
    	
    	return resEntity;
    }
	
	/**
	 * 
	 * listConnectionApiListExcel
	 *
	 * @param request
	 * @param response
	 * @param reqOomServiceConnectionApiListDto
	 * @return ResponseEntity
	 */
	@SuppressWarnings("rawtypes")
    @GetMapping(value="/apis/excels", produces="application/json; charset=UTF-8")
    public ResponseEntity listConnectionApiListExcel(HttpServletRequest request, HttpServletResponse response, OomServiceConnectionApiListDto reqOomServiceConnectionApiListDto) throws Exception {
        
    	ResponseEntity<ResultDto> resEntity = null;
		String returnString = "";
    	
		String serviceClCd = StringUtils.defaultString(reqOomServiceConnectionApiListDto.getServiceClCd());
		String serviceSysName = StringUtils.defaultString(reqOomServiceConnectionApiListDto.getServiceSysName());
		String linkageStandardVersionVal = StringUtils.defaultString(reqOomServiceConnectionApiListDto.getLinkageStandardVersionVal());
		
		if ("".equals(serviceClCd) && "".equals(serviceSysName) && "".equals(linkageStandardVersionVal)) {
			reqOomServiceConnectionApiListDto.setServiceClCd(Const.Definition.COMMON_VAL.DUMMY);
			reqOomServiceConnectionApiListDto.setServiceSysName(Const.Definition.COMMON_VAL.DUMMY);
			reqOomServiceConnectionApiListDto.setLinkageStandardVersionVal(Const.Definition.COMMON_VAL.DUMMY);
		} else {
			serviceClCd = StringUtils.defaultString(reqOomServiceConnectionApiListDto.getServiceClCd());
    		if ("".equals(serviceClCd)) {
    			log.error(">>>>>> serviceClCd ERROR:{}", ERR_MSG_NULL_SERVICE_CL_CD);
				returnString = Const.Common.RESULT_CODE.FAIL;
    			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_SERVICE_CL_CD));
    			return resEntity;
    		}
    		serviceSysName = StringUtils.defaultString(reqOomServiceConnectionApiListDto.getServiceSysName());
    		if ("".equals(serviceSysName)) {
    			log.error(">>>>>> serviceSysName ERROR:{}", ERR_MSG_NULL_SERVICE_SYS_NAME);
				returnString = Const.Common.RESULT_CODE.FAIL;
    			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_SERVICE_SYS_NAME));
    			return resEntity;
    		}
    		linkageStandardVersionVal = StringUtils.defaultString(reqOomServiceConnectionApiListDto.getLinkageStandardVersionVal());
    		if ("".equals(linkageStandardVersionVal)) {
    			log.error(">>>>>> linkageStandardVersionVal ERROR:{}", ERR_MSG_NULL_LINKAGE_STANDARD_VERSION_VAL);
				returnString = Const.Common.RESULT_CODE.FAIL;
    			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_LINKAGE_STANDARD_VERSION_VAL));
    			return resEntity;
    		}
		}
		
		StringBuilder fileNameBuilder = new StringBuilder();
		fileNameBuilder.append("connection-api-list");
		fileNameBuilder.append(".");
		fileNameBuilder.append(Const.Definition.FILE_EXTENTION.EXCEL);
		String fileName = fileNameBuilder.toString();
		
		// 엑셀 파일 생성...
		String fileFullPathName = serviceConnectionService.listConnectionApiListExcel(reqOomServiceConnectionApiListDto, fileName);
		
		// Excel File Download...
        response.setHeader("Content-Disposition", "attachment;filename=\"" + fileName + "\";");
        response.setContentType("application/octet-stream");
        response.setHeader("Content-transfer-Encoding", "binary");
        response.setHeader("mediaType", "application/vnd.ms-excel");
        OutputStream out = null;
        out = response.getOutputStream();
        FileInputStream fis = new FileInputStream(fileFullPathName);
        FileCopyUtils.copy(fis, out);
     
        out.flush();
		
		// Local Temp Directory 삭제...
        int lastSlashIndexVal = StringUtils.lastIndexOf(fileFullPathName, "/");
		String tempDirPath = StringUtils.substring(fileFullPathName, 0, lastSlashIndexVal);
		File downloadTempDirectory = new File(tempDirPath);
		if (downloadTempDirectory.isDirectory()) {
			FileUtils.deleteDirectory(downloadTempDirectory);
		}
    	
    	return resEntity;
    }
	
	/**
	 * 
	 * createServiceConnection
	 *
	 * @param authResultDto
	 * @param reqOomServiceConnectionDto
	 * @return ResponseEntity
	 */
	@SuppressWarnings("rawtypes")
    @PostMapping(value="", produces="application/json; charset=UTF-8")
    public ResponseEntity createServiceConnection(@AuthenticationPrincipal JwtAuthResultDto authResultDto, 
    		@RequestBody ServiceConnectionProcessingDto serviceConnectionProcessingDto) throws Exception {
        
    	ResponseEntity<ResultDto> resEntity = null;
		String returnString = "";
    	
		String loginUserId = StringUtils.defaultString(authResultDto.getUserId());
		if ("".equals(loginUserId)) {
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_LOGIN_USER_ID));
			return resEntity;
		}
		String mgrYn = StringUtils.defaultString(authResultDto.getMgrYn());
		if ("".equals(mgrYn)) {
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_MGR_YN));
			return resEntity;
		}
		//String loginUserId = "tsop-admin"; // 이후 세션에서 얻어올 값...
		
		if (!"Y".equals(mgrYn)) {
			String authorityTypeCd = "";
			UserRoleMenuAuthorityRequestDto userRoleMenuAuthorityRequestDto = new UserRoleMenuAuthorityRequestDto();
			userRoleMenuAuthorityRequestDto.setUserId(loginUserId);
			userRoleMenuAuthorityRequestDto.setMenuId(MENU_ID);
			OomUserRoleAuthorityDetailDto rsltOomUserRoleAuthorityDetailDto = userRoleService.readMenuAuthority(userRoleMenuAuthorityRequestDto);
			if (rsltOomUserRoleAuthorityDetailDto != null) {
				authorityTypeCd = StringUtils.defaultString(rsltOomUserRoleAuthorityDetailDto.getAuthorityTypeCd());
			}
			if (!"W".equals(authorityTypeCd)) {
				returnString = Const.Common.RESULT_CODE.FAIL;
				resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NO_AUTH));
				return resEntity;
			}
		}
		
		OomServiceConnectionDto reqOomServiceConnectionDto = serviceConnectionProcessingDto.getConnectionInfo();
		if (reqOomServiceConnectionDto == null) {
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_SERVICE_CONNECTION_INFO));
			return resEntity;
		}
		String serviceClCd = StringUtils.defaultString(reqOomServiceConnectionDto.getServiceClCd());
		if ("".equals(serviceClCd)) {
			log.error(">>>>>> serviceClCd ERROR:{}", ERR_MSG_NULL_SERVICE_CL_CD);
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_SERVICE_CL_CD));
			return resEntity;
		}
		String serviceSysName = StringUtils.defaultString(reqOomServiceConnectionDto.getServiceSysName());
		if ("".equals(serviceSysName)) {
			log.error(">>>>>> serviceSysName ERROR:{}", ERR_MSG_NULL_SERVICE_SYS_NAME);
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_SERVICE_SYS_NAME));
			return resEntity;
		}
		String linkageStandardVersionVal = StringUtils.defaultString(reqOomServiceConnectionDto.getLinkageStandardVersionVal());
		if ("".equals(linkageStandardVersionVal)) {
			log.error(">>>>>> linkageStandardVersionVal ERROR:{}", ERR_MSG_NULL_LINKAGE_STANDARD_VERSION_VAL);
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_LINKAGE_STANDARD_VERSION_VAL));
			return resEntity;
		}
		BlobRequestDto blobRequestDto = serviceConnectionProcessingDto.getAttachFile();
		if (blobRequestDto != null) {
			String localFilePath = StringUtils.defaultString(blobRequestDto.getLocalFilePath());
			if ("".equals(localFilePath)) {
    			log.error(">>>>>> localFilePath ERROR:{}", ERR_MSG_NULL_LOCAL_FILE_PATH);
				returnString = Const.Common.RESULT_CODE.FAIL;
    			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_LOCAL_FILE_PATH));
    			return resEntity;
    		}
		}
		
		// 서비스연동 중복 체크
		ServiceConnectionDetailResultDto serviceConnectionDetailResultDto = serviceConnectionService.readServiceConnection(reqOomServiceConnectionDto);
		if (serviceConnectionDetailResultDto != null) {
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_ALREADY_EXIST_SERVICE_CONNECTION));
			return resEntity;
		}
		
		// 서비스연동 등록...
		reqOomServiceConnectionDto.setAuditId(loginUserId);
		reqOomServiceConnectionDto.setRegisterId(loginUserId);
		String resultMessage = serviceConnectionService.createServiceConnection(serviceConnectionProcessingDto);
		if ("".equals(resultMessage)) {
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_CREATE_FAIL, resultMessage));
		} else {
			returnString = Const.Common.RESULT_CODE.SUCCESS;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, resultMessage, ""));
		}
    	
    	return resEntity;
    }
	
	/**
	 * 
	 * readServiceConnection
	 *
	 * @param onmAlarmCd
	 * @param reqOomServiceConnectionDto
	 * @return ResponseEntity
	 */
	@SuppressWarnings("rawtypes")
    @GetMapping(value="/{serviceClCd}", produces="application/json; charset=UTF-8")
    public ResponseEntity readServiceConnection(@PathVariable("serviceClCd") String serviceClCd, OomServiceConnectionDto reqOomServiceConnectionDto) throws Exception {
        
    	ResponseEntity<ResultDto> resEntity = null;
		String returnString = "";
    	
		String serviceSysName = StringUtils.defaultString(reqOomServiceConnectionDto.getServiceSysName());
		if ("".equals(serviceSysName)) {
			log.error(">>>>>> serviceSysName ERROR:{}", ERR_MSG_NULL_SERVICE_SYS_NAME);
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_SERVICE_SYS_NAME));
			return resEntity;
		}
		String linkageStandardVersionVal = StringUtils.defaultString(reqOomServiceConnectionDto.getLinkageStandardVersionVal());
		if ("".equals(linkageStandardVersionVal)) {
			log.error(">>>>>> linkageStandardVersionVal ERROR:{}", ERR_MSG_NULL_LINKAGE_STANDARD_VERSION_VAL);
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_LINKAGE_STANDARD_VERSION_VAL));
			return resEntity;
		}
		
		reqOomServiceConnectionDto.setServiceClCd(serviceClCd);
		
		ServiceConnectionDetailResultDto serviceConnectionDetailResultDto = serviceConnectionService.readServiceConnection(reqOomServiceConnectionDto);
		if (serviceConnectionDetailResultDto == null) {
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_READ_FAIL, serviceConnectionDetailResultDto));
		} else {
			returnString = Const.Common.RESULT_CODE.SUCCESS;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, "", serviceConnectionDetailResultDto));
		}
    	
    	return resEntity;
    }
	
	/**
	 * 
	 * deleteServiceConnectionAttachFile
	 *
	 * @param serviceClCd
	 * @param attachFileNum
	 * @param reqOomServiceConnectionDto
	 * @return ResponseEntity
	 */
	@SuppressWarnings("rawtypes")
    @DeleteMapping(value="/{serviceClCd}/attach-files/{attachFileNum}", produces="application/json; charset=UTF-8")
    public ResponseEntity deleteServiceConnectionAttachFile(@AuthenticationPrincipal JwtAuthResultDto authResultDto, 
    		@PathVariable("serviceClCd") String serviceClCd, @PathVariable("attachFileNum") int attachFileNum, @RequestBody OomServiceConnectionDto reqOomServiceConnectionDto) throws Exception {
        
    	ResponseEntity<ResultDto> resEntity = null;
		String returnString = "";
    	
		String loginUserId = StringUtils.defaultString(authResultDto.getUserId());
		if ("".equals(loginUserId)) {
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_LOGIN_USER_ID));
			return resEntity;
		}
		String mgrYn = StringUtils.defaultString(authResultDto.getMgrYn());
		if ("".equals(mgrYn)) {
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_MGR_YN));
			return resEntity;
		}
		//String loginUserId = "admin"; // 이후 세션에서 얻어올 값...
    	
		if (!"Y".equals(mgrYn)) {
			String authorityTypeCd = "";
			UserRoleMenuAuthorityRequestDto userRoleMenuAuthorityRequestDto = new UserRoleMenuAuthorityRequestDto();
			userRoleMenuAuthorityRequestDto.setUserId(loginUserId);
			userRoleMenuAuthorityRequestDto.setMenuId(MENU_ID);
			OomUserRoleAuthorityDetailDto rsltOomUserRoleAuthorityDetailDto = userRoleService.readMenuAuthority(userRoleMenuAuthorityRequestDto);
			if (rsltOomUserRoleAuthorityDetailDto != null) {
				authorityTypeCd = StringUtils.defaultString(rsltOomUserRoleAuthorityDetailDto.getAuthorityTypeCd());
			}
			if (!"W".equals(authorityTypeCd)) {
				returnString = Const.Common.RESULT_CODE.FAIL;
				resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NO_AUTH));
				return resEntity;
			}
		}
		
		String serviceSysName = StringUtils.defaultString(reqOomServiceConnectionDto.getServiceSysName());
		if ("".equals(serviceSysName)) {
			log.error(">>>>>> serviceSysName ERROR:{}", ERR_MSG_NULL_SERVICE_SYS_NAME);
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_SERVICE_SYS_NAME));
			return resEntity;
		}
		String linkageStandardVersionVal = StringUtils.defaultString(reqOomServiceConnectionDto.getLinkageStandardVersionVal());
		if ("".equals(linkageStandardVersionVal)) {
			log.error(">>>>>> linkageStandardVersionVal ERROR:{}", ERR_MSG_NULL_LINKAGE_STANDARD_VERSION_VAL);
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_LINKAGE_STANDARD_VERSION_VAL));
			return resEntity;
		}
		
		reqOomServiceConnectionDto.setServiceClCd(serviceClCd);
		reqOomServiceConnectionDto.setAttachFileNum(attachFileNum);
		int affectRowCount = serviceConnectionService.deleteServiceConnectionAttachFile(reqOomServiceConnectionDto);
		if (affectRowCount < 1) {
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_ATTACH_FILE_DELETE_FAIL, affectRowCount));
		} else {
			returnString = Const.Common.RESULT_CODE.SUCCESS;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, "", affectRowCount));
		}
    	
    	return resEntity;
    }
	
	/**
	 * 
	 * updateServiceConnection
	 *
	 * @param authResultDto
	 * @param onmAlarmCd
	 * @param reqOomServiceConnectionDto
	 * @return ResponseEntity
	 */
	@SuppressWarnings("rawtypes")
    @PutMapping(value="/{serviceClCd}", produces="application/json; charset=UTF-8")
    public ResponseEntity updateServiceConnection(@AuthenticationPrincipal JwtAuthResultDto authResultDto, 
    		@PathVariable("serviceClCd") String serviceClCd, @RequestBody ServiceConnectionProcessingDto serviceConnectionProcessingDto) throws Exception {
        
    	ResponseEntity<ResultDto> resEntity = null;
		String returnString = "";
    	
		String loginUserId = StringUtils.defaultString(authResultDto.getUserId());
		if ("".equals(loginUserId)) {
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_LOGIN_USER_ID));
			return resEntity;
		}
		String mgrYn = StringUtils.defaultString(authResultDto.getMgrYn());
		if ("".equals(mgrYn)) {
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_MGR_YN));
			return resEntity;
		}
		//String loginUserId = "tsop-admin"; // 이후 세션에서 얻어올 값...
		
		if (!"Y".equals(mgrYn)) {
			String authorityTypeCd = "";
			UserRoleMenuAuthorityRequestDto userRoleMenuAuthorityRequestDto = new UserRoleMenuAuthorityRequestDto();
			userRoleMenuAuthorityRequestDto.setUserId(loginUserId);
			userRoleMenuAuthorityRequestDto.setMenuId(MENU_ID);
			OomUserRoleAuthorityDetailDto rsltOomUserRoleAuthorityDetailDto = userRoleService.readMenuAuthority(userRoleMenuAuthorityRequestDto);
			if (rsltOomUserRoleAuthorityDetailDto != null) {
				authorityTypeCd = StringUtils.defaultString(rsltOomUserRoleAuthorityDetailDto.getAuthorityTypeCd());
			}
			if (!"W".equals(authorityTypeCd)) {
				returnString = Const.Common.RESULT_CODE.FAIL;
				resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NO_AUTH));
				return resEntity;
			}
		}
		
		OomServiceConnectionDto reqOomServiceConnectionDto = serviceConnectionProcessingDto.getConnectionInfo();
		if (reqOomServiceConnectionDto == null) {
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_SERVICE_CONNECTION_INFO));
			return resEntity;
		}
		String serviceSysName = StringUtils.defaultString(reqOomServiceConnectionDto.getServiceSysName());
		if ("".equals(serviceSysName)) {
			log.error(">>>>>> serviceSysName ERROR:{}", ERR_MSG_NULL_SERVICE_SYS_NAME);
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_SERVICE_SYS_NAME));
			return resEntity;
		}
		String linkageStandardVersionVal = StringUtils.defaultString(reqOomServiceConnectionDto.getLinkageStandardVersionVal());
		if ("".equals(linkageStandardVersionVal)) {
			log.error(">>>>>> linkageStandardVersionVal ERROR:{}", ERR_MSG_NULL_LINKAGE_STANDARD_VERSION_VAL);
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_LINKAGE_STANDARD_VERSION_VAL));
			return resEntity;
		}
		BlobRequestDto blobRequestDto = serviceConnectionProcessingDto.getAttachFile();
		if (blobRequestDto != null) {
			String localFilePath = StringUtils.defaultString(blobRequestDto.getLocalFilePath());
			if ("".equals(localFilePath)) {
    			log.error(">>>>>> localFilePath ERROR:{}", ERR_MSG_NULL_LOCAL_FILE_PATH);
				returnString = Const.Common.RESULT_CODE.FAIL;
    			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_LOCAL_FILE_PATH));
    			return resEntity;
    		}
		}
		
		reqOomServiceConnectionDto.setServiceClCd(serviceClCd);
		reqOomServiceConnectionDto.setAuditId(loginUserId);
		
		// 서비스연동 수정...
		String resultMessage = serviceConnectionService.updateServiceConnection(serviceConnectionProcessingDto);
		if ("".equals(resultMessage)) {
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_UPDATE_FAIL, resultMessage));
		} else {
			returnString = Const.Common.RESULT_CODE.SUCCESS;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, resultMessage, ""));
		}
    	
    	return resEntity;
    }
	
	/**
	 * 
	 * deleteServiceConnection
	 *
	 * @param onmAlarmCd
	 * @param reqOomServiceConnectionDto
	 * @return ResponseEntity
	 */
	@SuppressWarnings("rawtypes")
    @DeleteMapping(value="/{serviceClCd}", produces="application/json; charset=UTF-8")
    public ResponseEntity deleteServiceConnection(@AuthenticationPrincipal JwtAuthResultDto authResultDto, 
    		@PathVariable("serviceClCd") String serviceClCd, @RequestBody OomServiceConnectionDto reqOomServiceConnectionDto) throws Exception {
        
    	ResponseEntity<ResultDto> resEntity = null;
		String returnString = "";
		
		String loginUserId = StringUtils.defaultString(authResultDto.getUserId());
		if ("".equals(loginUserId)) {
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_LOGIN_USER_ID));
			return resEntity;
		}
		String mgrYn = StringUtils.defaultString(authResultDto.getMgrYn());
		if ("".equals(mgrYn)) {
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_MGR_YN));
			return resEntity;
		}
		//String loginUserId = "admin"; // 이후 세션에서 얻어올 값...
    	
		if (!"Y".equals(mgrYn)) {
			String authorityTypeCd = "";
			UserRoleMenuAuthorityRequestDto userRoleMenuAuthorityRequestDto = new UserRoleMenuAuthorityRequestDto();
			userRoleMenuAuthorityRequestDto.setUserId(loginUserId);
			userRoleMenuAuthorityRequestDto.setMenuId(MENU_ID);
			OomUserRoleAuthorityDetailDto rsltOomUserRoleAuthorityDetailDto = userRoleService.readMenuAuthority(userRoleMenuAuthorityRequestDto);
			if (rsltOomUserRoleAuthorityDetailDto != null) {
				authorityTypeCd = StringUtils.defaultString(rsltOomUserRoleAuthorityDetailDto.getAuthorityTypeCd());
			}
			if (!"W".equals(authorityTypeCd)) {
				returnString = Const.Common.RESULT_CODE.FAIL;
				resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NO_AUTH));
				return resEntity;
			}
		}
    	
		String serviceSysName = StringUtils.defaultString(reqOomServiceConnectionDto.getServiceSysName());
		if ("".equals(serviceSysName)) {
			log.error(">>>>>> serviceSysName ERROR:{}", ERR_MSG_NULL_SERVICE_SYS_NAME);
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_SERVICE_SYS_NAME));
			return resEntity;
		}
		String linkageStandardVersionVal = StringUtils.defaultString(reqOomServiceConnectionDto.getLinkageStandardVersionVal());
		if ("".equals(linkageStandardVersionVal)) {
			log.error(">>>>>> linkageStandardVersionVal ERROR:{}", ERR_MSG_NULL_LINKAGE_STANDARD_VERSION_VAL);
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_LINKAGE_STANDARD_VERSION_VAL));
			return resEntity;
		}
		
		reqOomServiceConnectionDto.setServiceClCd(serviceClCd);
		
		OomBuildingServiceConnectionDto reqOomBuildingServiceConnectionDto = new OomBuildingServiceConnectionDto();
		reqOomBuildingServiceConnectionDto.setServiceClCd(serviceClCd);
		reqOomBuildingServiceConnectionDto.setServiceSysName(serviceSysName);
		reqOomBuildingServiceConnectionDto.setLinkageStandardVersionVal(linkageStandardVersionVal);
		int connectionCount = buildingServiceService.readBuildingServiceConnectionCount(reqOomBuildingServiceConnectionDto);
		if (connectionCount > 0) {
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_ALREADY_USE_SERVICE_CONNECTION));
			return resEntity;
		}
		
		// 서비스연동 삭제...
		int affectRowCount = serviceConnectionService.deleteServiceConnection(reqOomServiceConnectionDto);
		if (affectRowCount < 1) {
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_DELETE_FAIL, affectRowCount));
		} else {
			returnString = Const.Common.RESULT_CODE.SUCCESS;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, "", affectRowCount));
		}
    	
    	return resEntity;
    }

}
