package com.adtcaps.tsop.onm.api.board.service.impl;

import java.net.ConnectException;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.apache.http.conn.ConnectTimeoutException;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.CollectionUtils;

import com.adtcaps.tsop.onm.api.alimTalk.domain.AlimTalkDetailDto;
import com.adtcaps.tsop.onm.api.alimTalk.domain.AlimTalkRequestDto;
import com.adtcaps.tsop.onm.api.alimTalk.mapper.OomKakaoAlimTalkMapper;
import com.adtcaps.tsop.onm.api.alimTalk.service.AlimTalkService;
import com.adtcaps.tsop.onm.api.board.domain.BulletinboardAlarmNoticeSmsGridResultDto;
import com.adtcaps.tsop.onm.api.board.domain.BulletinboardAlarmNoticeTenantGridResultDto;
import com.adtcaps.tsop.onm.api.board.domain.BulletinboardDetailResultDto;
import com.adtcaps.tsop.onm.api.board.domain.BulletinboardGridRequestDto;
import com.adtcaps.tsop.onm.api.board.domain.BulletinboardGridResultDto;
import com.adtcaps.tsop.onm.api.board.domain.BulletinboardProcessingDto;
import com.adtcaps.tsop.onm.api.board.domain.DeleteBulletinboardRequestDto;
import com.adtcaps.tsop.onm.api.board.mapper.OomBulletinboardAlarmNoticeMapper;
import com.adtcaps.tsop.onm.api.board.mapper.OomBulletinboardAlarmNoticeSmsMapper;
import com.adtcaps.tsop.onm.api.board.mapper.OomBulletinboardAlarmNoticeTenantMapper;
import com.adtcaps.tsop.onm.api.board.mapper.OomBulletinboardMapper;
import com.adtcaps.tsop.onm.api.board.service.BulletinboardService;
import com.adtcaps.tsop.onm.api.config.TenantConfig;
import com.adtcaps.tsop.onm.api.domain.OomBulletinboardAlarmNoticeDto;
import com.adtcaps.tsop.onm.api.domain.OomBulletinboardAlarmNoticeSmsDto;
import com.adtcaps.tsop.onm.api.domain.OomBulletinboardAlarmNoticeTenantDto;
import com.adtcaps.tsop.onm.api.domain.OomBulletinboardDto;
import com.adtcaps.tsop.onm.api.domain.OomKakaoAlimTalkDto;
import com.adtcaps.tsop.onm.api.domain.OomUserDto;
import com.adtcaps.tsop.onm.api.file.domain.BlobRequestDto;
import com.adtcaps.tsop.onm.api.file.service.FileService;
import com.adtcaps.tsop.onm.api.helper.constant.Const;
import com.adtcaps.tsop.onm.api.helper.domain.ResultDto;
import com.adtcaps.tsop.onm.api.helper.util.CommonDateUtil;
import com.adtcaps.tsop.onm.api.helper.util.CommonObjectUtil;
import com.adtcaps.tsop.onm.api.user.service.UserService;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.gson.Gson;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.squareup.okhttp.MediaType;
import com.squareup.okhttp.OkHttpClient;
import com.squareup.okhttp.Request;
import com.squareup.okhttp.RequestBody;
import com.squareup.okhttp.Response;

/**
 * 
 * <ul>
 * <li>업무 그룹명 : tsop-onm-api</li>
 * <li>서브 업무명 : com.adtcaps.tsop.onm.api.board.service.impl</li>
 * <li>설  명 : BulletinboardServiceImpl.java</li>
 * <li>작성일 : 2021. 1. 8.</li>
 * <li>작성자 : jeonyb4</li>
 * </ul>
 */
@Transactional
@Service
public class BulletinboardServiceImpl implements BulletinboardService {
	
	private final String ERR_MSG_REMOTE_EXECUTION_FAIL = "원격 실행에 실패하였습니다.";
	private final String ERR_MSG_REMOTE_CALL_CONNECTION_FAIL = "원격 접속이 실패하였습니다.";
	private final String ERR_MSG_REMOTE_CALL_TIMEOUT = "원격 실행 시 Timeout이 발생하였습니다.";
	
	@Autowired
	private OomBulletinboardMapper oomBulletinboardMapper;
	
	@Autowired
	private OomBulletinboardAlarmNoticeMapper oomBulletinboardAlarmNoticeMapper;
	
	@Autowired
	private OomBulletinboardAlarmNoticeSmsMapper oomBulletinboardAlarmNoticeSmsMapper;
	
	@Autowired
	private OomBulletinboardAlarmNoticeTenantMapper oomBulletinboardAlarmNoticeTenantMapper;
	
	@Autowired
	private UserService userService;
	
	@Autowired
	private FileService fileService;
	
	@Autowired
	private TenantConfig tenantConfig;
	
	@Autowired
	private OomKakaoAlimTalkMapper oomKakaoAlimTalkMapper;
	
	@Autowired
	private AlimTalkService alimTalkService;
	
	/**
	 * 
	 * listPageBulletinboard
	 *
	 * @param bulletinboardGridRequestDto
	 * @return List<BulletinboardGridResultDto>
	 * @throws Exception 
	 */
	@Override
	public List<BulletinboardGridResultDto> listPageBulletinboard(BulletinboardGridRequestDto bulletinboardGridRequestDto) throws Exception {
		
		List<BulletinboardGridResultDto> bulletinboardGridResultDtoList = null;
		try {
			String bulletinTypeCd = bulletinboardGridRequestDto.getBulletinTypeCd();
			String fromDate = bulletinboardGridRequestDto.getFromDate();
    		String toDate = bulletinboardGridRequestDto.getToDate();
    		
    		fromDate = CommonDateUtil.makeFromDatetime(fromDate);
    		toDate = CommonDateUtil.makeToDatetime(toDate);
    		
    		bulletinboardGridRequestDto.setFromDate(fromDate);
    		bulletinboardGridRequestDto.setToDate(toDate);
    		
			bulletinboardGridResultDtoList = oomBulletinboardMapper.listPageBulletinboard(bulletinboardGridRequestDto);
			
			if (!CollectionUtils.isEmpty(bulletinboardGridResultDtoList)) {
				for (int idx = 0; idx < bulletinboardGridResultDtoList.size(); idx++) {
    				
					BulletinboardGridResultDto bulletinboardGridResultDto = bulletinboardGridResultDtoList.get(idx);
    				
    				int attachFileNum = CommonObjectUtil.defaultNumber(bulletinboardGridResultDto.getAttachFileNum());
    				if (attachFileNum > 0) {
    					bulletinboardGridResultDto.setAttachFileYn("Y");
    				} else {
    					bulletinboardGridResultDto.setAttachFileYn("N");
    				}
    				
    				String deleteYn = StringUtils.defaultString(bulletinboardGridResultDto.getDeleteYn());
    				if ("Y".equals(deleteYn)) {
    					bulletinboardGridResultDto.setBulletinStatusVal(Const.Definition.BOARD_STATUS_VAL.DELETE);
    				} else {
    					bulletinboardGridResultDto.setBulletinStatusVal(Const.Definition.BOARD_STATUS_VAL.POST);
    				}
    				
    				String bulletinStartDatetime = StringUtils.defaultString(bulletinboardGridResultDto.getBulletinStartDatetime());
    				bulletinStartDatetime = CommonDateUtil.makeDatetimeToDateFormat(bulletinStartDatetime);
    				
    				String bulletinEndDatetime = StringUtils.defaultString(bulletinboardGridResultDto.getBulletinEndDatetime());
    				bulletinEndDatetime = CommonDateUtil.makeDatetimeToDateFormat(bulletinEndDatetime);
    				
    				StringBuilder bulletinStartEndDateBuilder = new StringBuilder();
    				if (!"".equals(bulletinStartDatetime)) {
    					bulletinStartEndDateBuilder.append(bulletinStartDatetime);
    				}
    				bulletinStartEndDateBuilder.append(" ~ ");
    				if (!"".equals(bulletinEndDatetime)) {
    					bulletinStartEndDateBuilder.append(bulletinEndDatetime);
    				}
    				bulletinboardGridResultDto.setBulletinStartEndDate(bulletinStartEndDateBuilder.toString());
    				
    				String registDatetime = StringUtils.defaultString(bulletinboardGridResultDto.getRegistDatetime());
    				if (Const.Code.BULLETIN_TYPE_CD.NOTICE.equals(bulletinTypeCd)) {
    					registDatetime = CommonDateUtil.makeDatetimeToDateFormat(registDatetime);
    				} else {
    					registDatetime = CommonDateUtil.makeDatetimeFormat(registDatetime);
    				}
    				bulletinboardGridResultDto.setRegistDatetime(registDatetime);
    				
    				bulletinboardGridResultDtoList.set(idx, bulletinboardGridResultDto);
    			}
			}
			
		} catch (Exception e) {
			throw e;
		}
		return bulletinboardGridResultDtoList;
	}
	
	/**
	 * 
	 * createBulletinboard
	 *
	 * @param reqBulletinboardProcessingDto
	 * @return ResultDto
	 * @throws Exception 
	 */
	@Override
	public ResultDto createBulletinboard(BulletinboardProcessingDto reqBulletinboardProcessingDto) throws Exception {
		
		ResultDto resultDto = null;
		
		try {
			// 첨부파일 등록
			OomBulletinboardDto reqOomBulletinboardDto = reqBulletinboardProcessingDto.getBoardInfo();
			BlobRequestDto blobRequestDto = reqBulletinboardProcessingDto.getAttachFile();
			if (blobRequestDto != null) {
				blobRequestDto.setContainerName(Const.Definition.BLOB_CONTAINER.FILE);
				blobRequestDto.setBlobBaseDir(Const.Definition.BLOB_BASEDIR.BOARD);
				int attachFileNum = fileService.createAttachFile(blobRequestDto);
				if (attachFileNum > 0) {
					reqOomBulletinboardDto.setAttachFileNum(attachFileNum);
				}
			}
			
			// 게시물 등록
			String bulletinTypeCd = reqOomBulletinboardDto.getBulletinTypeCd();
			if (Const.Code.BULLETIN_TYPE_CD.NOTICE.equals(bulletinTypeCd)) {
				String bulletinStartDatetime = reqOomBulletinboardDto.getBulletinStartDatetime();
        		String bulletinEndDatetime = reqOomBulletinboardDto.getBulletinEndDatetime();
        		bulletinStartDatetime = CommonDateUtil.makeFromDatetime(bulletinStartDatetime);
        		bulletinEndDatetime = CommonDateUtil.makeToDatetime(bulletinEndDatetime);
        		reqOomBulletinboardDto.setBulletinStartDatetime(bulletinStartDatetime);
        		reqOomBulletinboardDto.setBulletinEndDatetime(bulletinEndDatetime);
			}
			oomBulletinboardMapper.createOomBulletinboard(reqOomBulletinboardDto);
			
			int bulletinNum = reqOomBulletinboardDto.getBulletinNum();
			String registerId = reqOomBulletinboardDto.getRegisterId();
			String smsAlarmNoticeYn = reqOomBulletinboardDto.getSmsAlarmNoticeYn();
			
			// 공지사항 처리...
			if (Const.Code.BULLETIN_TYPE_CD.NOTICE.equals(bulletinTypeCd)) {
				if ("Y".equals(smsAlarmNoticeYn)) {
					String alarmNoticeResultCd = "1";
					OomKakaoAlimTalkDto reqOomKakaoAlimTalkDto = new OomKakaoAlimTalkDto();
					reqOomKakaoAlimTalkDto.setTmpltCode(Const.Definition.MSG_TEMPLATE_CODE.TSOP_002);
					reqOomKakaoAlimTalkDto.setSmsCreateCd(Const.Code.SMS_CREATE_CD.BOARD);
					OomKakaoAlimTalkDto oomKakaoAlimTalkDto = oomKakaoAlimTalkMapper.readKakaoAlimTalk(reqOomKakaoAlimTalkDto);
					if (oomKakaoAlimTalkDto != null) {
						List<AlimTalkDetailDto> alimTalkDetailDtoList = new ArrayList<AlimTalkDetailDto>();
						List<OomBulletinboardAlarmNoticeSmsDto> reqOomBulletinboardAlarmNoticeSmsDtoList = reqBulletinboardProcessingDto.getSmsUserList();
						StringBuilder rcvPhoneNumBuilder = new StringBuilder();
						for (int idx = 0; idx < reqOomBulletinboardAlarmNoticeSmsDtoList.size(); idx++) {
							OomBulletinboardAlarmNoticeSmsDto reqOomBulletinboardAlarmNoticeSmsDto = reqOomBulletinboardAlarmNoticeSmsDtoList.get(idx);
							String rcverId = StringUtils.defaultString(reqOomBulletinboardAlarmNoticeSmsDto.getRcverId());
							String rcverName = StringUtils.defaultString(reqOomBulletinboardAlarmNoticeSmsDto.getRcverName());
							String rcvPhoneNum = StringUtils.defaultString(reqOomBulletinboardAlarmNoticeSmsDto.getRcvPhoneNum());
							AlimTalkDetailDto alimTalkDetailDto = new AlimTalkDetailDto();
							alimTalkDetailDto.setRcverId(rcverId);
							alimTalkDetailDto.setRcverName(rcverName);
							alimTalkDetailDto.setRcvPhoneNum(rcvPhoneNum);
							alimTalkDetailDtoList.add(alimTalkDetailDto);
							
							rcvPhoneNumBuilder.append(rcvPhoneNum);
							if (idx != reqOomBulletinboardAlarmNoticeSmsDtoList.size() - 1) {
								rcvPhoneNumBuilder.append(",");
							}
						}
						
						String bulletinTitleName = StringUtils.defaultString(reqOomBulletinboardDto.getBulletinTitleName());
						String message = oomKakaoAlimTalkDto.getMessage();
						message = message.replaceAll("#\\{\"등록\"\\}", "등록");
						message = message.replaceAll("#\\{\"\"HVAC 전층 화재 알람 2등급 => 1등급으로 6/3일자 변경\"\"\\}", "\"" + bulletinTitleName + "\"");
						// 카카오 알림톡 발송 처리..
						AlimTalkRequestDto alimTalkRequestDto = new AlimTalkRequestDto();
						alimTalkRequestDto.setTmpltCode(Const.Definition.MSG_TEMPLATE_CODE.TSOP_002);
						alimTalkRequestDto.setRecipient(rcvPhoneNumBuilder.toString());
						alimTalkRequestDto.setMessage(message);
						alimTalkRequestDto.setSmsCreateCd(Const.Code.SMS_CREATE_CD.BOARD);
						alimTalkRequestDto.setBulletinTypeCd(bulletinTypeCd);
						alimTalkRequestDto.setBulletinNum(bulletinNum);
						alimTalkRequestDto.setAuditId(registerId);
						alimTalkRequestDto.setDetailList(alimTalkDetailDtoList);
						alarmNoticeResultCd = alimTalkService.sendOnmAlimTalk(alimTalkRequestDto);
						if (!"1".equals(alarmNoticeResultCd)) {
							// 성공이 아니면.. 모두 실패 처리...
							alarmNoticeResultCd = "2";
						}
						
						// 게시판알람통지내역 등록
						String alarmNoticeMethodClCd = Const.Code.ALARM_NOTICE_METHOD_CL_CD.SMS;
						OomBulletinboardAlarmNoticeDto reqOomBulletinboardAlarmNoticeDto = new OomBulletinboardAlarmNoticeDto();
						reqOomBulletinboardAlarmNoticeDto.setBulletinTypeCd(bulletinTypeCd);
						reqOomBulletinboardAlarmNoticeDto.setBulletinNum(bulletinNum);
						reqOomBulletinboardAlarmNoticeDto.setAuditId(registerId);
						reqOomBulletinboardAlarmNoticeDto.setAlarmNoticeMethodClCd(alarmNoticeMethodClCd);
						reqOomBulletinboardAlarmNoticeDto.setAlarmNoticeResultCd(alarmNoticeResultCd);
						oomBulletinboardAlarmNoticeMapper.createOomBulletinboardAlarmNotice(reqOomBulletinboardAlarmNoticeDto);
						
						// 게시판알람통지SMS대상상세 등록
						int transSeq = reqOomBulletinboardAlarmNoticeDto.getTransSeq();
						List<OomBulletinboardAlarmNoticeSmsDto> oomBulletinboardAlarmNoticeSmsDtoList = reqBulletinboardProcessingDto.getSmsUserList();
						for (OomBulletinboardAlarmNoticeSmsDto reqOomBulletinboardAlarmNoticeSmsDto : oomBulletinboardAlarmNoticeSmsDtoList) {
							reqOomBulletinboardAlarmNoticeSmsDto.setBulletinTypeCd(bulletinTypeCd);
							reqOomBulletinboardAlarmNoticeSmsDto.setBulletinNum(bulletinNum);
							reqOomBulletinboardAlarmNoticeSmsDto.setTransSeq(transSeq);
							reqOomBulletinboardAlarmNoticeSmsDto.setAuditId(registerId);
							oomBulletinboardAlarmNoticeSmsMapper.createOomBulletinboardAlarmNoticeSms(reqOomBulletinboardAlarmNoticeSmsDto);
						}
					}
				}
				
				List<OomBulletinboardAlarmNoticeTenantDto> reqOomBulletinboardAlarmNoticeTenantDtoList = reqBulletinboardProcessingDto.getTenantList();
				if (!CollectionUtils.isEmpty(reqOomBulletinboardAlarmNoticeTenantDtoList)) {
					for (OomBulletinboardAlarmNoticeTenantDto reqOomBulletinboardAlarmNoticeTenantDto : reqOomBulletinboardAlarmNoticeTenantDtoList) {
						String rcvTenantId = StringUtils.defaultString(reqOomBulletinboardAlarmNoticeTenantDto.getRcvTenantId());
						if ("0001".equals(rcvTenantId)) {
							// ToDo : 나중에 이 if문은 걷어내야 함....
							// 해당 테넌트의 서비스운용사용자 조회
							String orgRegisterId = StringUtils.defaultString(reqBulletinboardProcessingDto.getBoardInfo().getRegisterId());
							OomUserDto reqOomUserDto = new OomUserDto();
							reqOomUserDto.setTenantId(rcvTenantId);
							OomUserDto rsltOomUserDto = userService.readServiceOperUserInfoForTenantId(reqOomUserDto);
							if (rsltOomUserDto != null) {
								String serviceOperUserId = StringUtils.defaultString(rsltOomUserDto.getUserId());
								if (!"".equals(serviceOperUserId)) {
									OomBulletinboardDto oomBulletinboardDto = reqBulletinboardProcessingDto.getBoardInfo();
									// 해당 테넌트의 서비스운용사용자로 변경
									oomBulletinboardDto.setRegisterId(serviceOperUserId);
									reqBulletinboardProcessingDto.setBoardInfo(oomBulletinboardDto);
								} else {
									OomBulletinboardDto oomBulletinboardDto = reqBulletinboardProcessingDto.getBoardInfo();
									// 원래 등록자로 변경
									oomBulletinboardDto.setRegisterId(orgRegisterId);
									reqBulletinboardProcessingDto.setBoardInfo(oomBulletinboardDto);
								}
							} else {
								OomBulletinboardDto oomBulletinboardDto = reqBulletinboardProcessingDto.getBoardInfo();
								// 원래 등록자로 변경
								oomBulletinboardDto.setRegisterId(orgRegisterId);
								reqBulletinboardProcessingDto.setBoardInfo(oomBulletinboardDto);
							}
							
							// Remote Call 처리...
							String actionYn = StringUtils.defaultString(tenantConfig.getTenantSktServerInfo().getActionYn());
							if ("Y".equals(actionYn)) {
								String key = tenantConfig.getTenantSktServerInfo().getKey();
								String portalWasUrl = tenantConfig.getTenantSktServerInfo().getUrl();
								
								StringBuilder urlBuilder = new StringBuilder();
								urlBuilder.append(portalWasUrl);
								urlBuilder.append("/api/portal/callees/create-bulletin");
								
								Gson gson = new Gson();
					    	    String requestJsonString = gson.toJson(reqBulletinboardProcessingDto);
								
								OkHttpClient client = new OkHttpClient();
								Request request = new Request.Builder()
										.addHeader("Call-Key", key)
										.url(urlBuilder.toString())
					    	            .post(RequestBody.create(MediaType.parse(org.springframework.http.MediaType.APPLICATION_JSON.toString()), requestJsonString))
					    	            .build();
					    	    
					    	    Response response = null;
								try {
					    	    	response = client.newCall(request).execute();
					    	    } catch (ConnectException e) {
					    	    	resultDto = new ResultDto(Const.Common.RESULT_CODE.FAIL, ERR_MSG_REMOTE_CALL_CONNECTION_FAIL);
					    	    	return resultDto;
					    	    } catch (ConnectTimeoutException e) {
					    	    	resultDto = new ResultDto(Const.Common.RESULT_CODE.FAIL, ERR_MSG_REMOTE_CALL_TIMEOUT);
					    	    	return resultDto;
					    	    }
					    	    
					    	    String responseJsonString = StringUtils.defaultString(response.body().string());
								if ("".equals(responseJsonString)) {
									resultDto = new ResultDto(Const.Common.RESULT_CODE.FAIL, ERR_MSG_REMOTE_EXECUTION_FAIL);
									return resultDto;
								} else {
									JsonObject responseJsonObject = JsonParser.parseString(responseJsonString).getAsJsonObject();
									
									ObjectMapper objectMapper = new ObjectMapper();
									resultDto = objectMapper.readValue(responseJsonObject.toString(), ResultDto.class);
								}
							}
						}
						reqOomBulletinboardAlarmNoticeTenantDto.setBulletinTypeCd(bulletinTypeCd);
						reqOomBulletinboardAlarmNoticeTenantDto.setBulletinNum(bulletinNum);
						reqOomBulletinboardAlarmNoticeTenantDto.setTransSeq(1);
						reqOomBulletinboardAlarmNoticeTenantDto.setAuditId(registerId);
						oomBulletinboardAlarmNoticeTenantMapper.createOomBulletinboardAlarmNoticeTenant(reqOomBulletinboardAlarmNoticeTenantDto);
					}
				} else {
					resultDto = new ResultDto(Const.Common.RESULT_CODE.SUCCESS, "");
				}
			} else {
				resultDto = new ResultDto(Const.Common.RESULT_CODE.SUCCESS, "");
			}
		} catch (Exception e) {
			throw e;
		}
		
		return resultDto;
	}
	
	/**
	 * 
	 * readBulletinboard
	 *
	 * @param reqOomBulletinboardDto
	 * @return BulletinboardDetailResultDto
	 * @throws Exception 
	 */
	@Override
	public BulletinboardDetailResultDto readBulletinboard(OomBulletinboardDto reqOomBulletinboardDto) throws Exception {
		
		BulletinboardDetailResultDto bulletinboardDetailResultDto = null;
		try {
			// 게시물 정보 조회
			bulletinboardDetailResultDto = oomBulletinboardMapper.readOomBulletinboard(reqOomBulletinboardDto);
			if (bulletinboardDetailResultDto != null) {
				String bulletinTypeCd = bulletinboardDetailResultDto.getBulletinTypeCd();
				// 공지사항 처리...
				if (Const.Code.BULLETIN_TYPE_CD.NOTICE.equals(bulletinTypeCd)) {
					String smsAlarmNoticeYn = bulletinboardDetailResultDto.getSmsAlarmNoticeYn();
					if ("Y".equals(smsAlarmNoticeYn)) {
						// 게시판알람통지SMS대상상세 조회
						List<BulletinboardAlarmNoticeSmsGridResultDto> bulletinboardAlarmNoticeSmsGridResultDtoList = oomBulletinboardAlarmNoticeSmsMapper.listBulletinboardAlarmNoticeSms(reqOomBulletinboardDto);
						bulletinboardDetailResultDto.setSmsUserList(bulletinboardAlarmNoticeSmsGridResultDtoList);
					}
					List<BulletinboardAlarmNoticeTenantGridResultDto> bulletinboardAlarmNoticeTenantGridResultDtoList = oomBulletinboardAlarmNoticeTenantMapper.listBulletinboardAlarmNoticeTenant(reqOomBulletinboardDto);
					bulletinboardDetailResultDto.setTenantList(bulletinboardAlarmNoticeTenantGridResultDtoList);
				}
				// 조회 수 업데이트...
				oomBulletinboardMapper.updateBrowseCnt(reqOomBulletinboardDto);
			}
		} catch (Exception e) {
			throw e;
		}
		return bulletinboardDetailResultDto;
	}
	
	/**
	 * 
	 * deleteBulletinboardAttachFile
	 *
	 * @param deleteBulletinboardRequestDto
	 * @return ResultDto
	 * @throws Exception 
	 */
	@Override
	public ResultDto deleteBulletinboardAttachFile(DeleteBulletinboardRequestDto deleteBulletinboardRequestDto) throws Exception {
		
		ResultDto resultDto = null;
		
		try {
			int attachFileNum = deleteBulletinboardRequestDto.getAttachFileNum();
			// 첨부파일 삭제
			fileService.deleteAttachFile(Const.Definition.BLOB_CONTAINER.FILE, attachFileNum);
			// 게시물의 첨부파일번호 Null update
			OomBulletinboardDto reqOomBulletinboardDto = new OomBulletinboardDto();
			BeanUtils.copyProperties(deleteBulletinboardRequestDto, reqOomBulletinboardDto);
			reqOomBulletinboardDto.setAttachFileNum(null);
			oomBulletinboardMapper.updateBulletinboardAttachFileNum(reqOomBulletinboardDto);
			
			// 공지사항 처리...
			String bulletinTypeCd = reqOomBulletinboardDto.getBulletinTypeCd();
			if (Const.Code.BULLETIN_TYPE_CD.NOTICE.equals(bulletinTypeCd)) {
				// Remote Call 처리...
				List<OomBulletinboardAlarmNoticeTenantDto> reqOomBulletinboardAlarmNoticeTenantDtoList = deleteBulletinboardRequestDto.getTenantList();
				if (!CollectionUtils.isEmpty(reqOomBulletinboardAlarmNoticeTenantDtoList)) {
					for (OomBulletinboardAlarmNoticeTenantDto reqOomBulletinboardAlarmNoticeTenantDto : reqOomBulletinboardAlarmNoticeTenantDtoList) {
						String rcvTenantId = StringUtils.defaultString(reqOomBulletinboardAlarmNoticeTenantDto.getRcvTenantId());
						if ("0001".equals(rcvTenantId)) {
							// ToDo : 나중에 이 if문은 걷어내야 함....
							String key = tenantConfig.getTenantSktServerInfo().getKey();
							String portalWasUrl = tenantConfig.getTenantSktServerInfo().getUrl();
							
							StringBuilder urlBuilder = new StringBuilder();
							urlBuilder.append(portalWasUrl);
							urlBuilder.append("/api/portal/callees/delete-bulletin-attach-file");
							
							Gson gson = new Gson();
				    	    String requestJsonString = gson.toJson(reqOomBulletinboardDto);
							
							OkHttpClient client = new OkHttpClient();
							Request request = new Request.Builder()
									.addHeader("Call-Key", key)
									.url(urlBuilder.toString())
				    	            .post(RequestBody.create(MediaType.parse(org.springframework.http.MediaType.APPLICATION_JSON.toString()), requestJsonString))
				    	            .build();
				    	    
				    	    Response response = null;
							try {
				    	    	response = client.newCall(request).execute();
				    	    } catch (ConnectException e) {
				    	    	resultDto = new ResultDto(Const.Common.RESULT_CODE.FAIL, ERR_MSG_REMOTE_CALL_CONNECTION_FAIL);
				    	    	return resultDto;
				    	    } catch (ConnectTimeoutException e) {
				    	    	resultDto = new ResultDto(Const.Common.RESULT_CODE.FAIL, ERR_MSG_REMOTE_CALL_TIMEOUT);
				    	    	return resultDto;
				    	    }
				    	    
				    	    String responseJsonString = StringUtils.defaultString(response.body().string());
							if ("".equals(responseJsonString)) {
								resultDto = new ResultDto(Const.Common.RESULT_CODE.FAIL, ERR_MSG_REMOTE_EXECUTION_FAIL);
								return resultDto;
							} else {
								JsonObject responseJsonObject = JsonParser.parseString(responseJsonString).getAsJsonObject();
								
								ObjectMapper objectMapper = new ObjectMapper();
								resultDto = objectMapper.readValue(responseJsonObject.toString(), ResultDto.class);
							}
						}
					}
				} else {
					resultDto = new ResultDto(Const.Common.RESULT_CODE.SUCCESS, "");
				}
			} else {
				resultDto = new ResultDto(Const.Common.RESULT_CODE.SUCCESS, "");
			}
		} catch (Exception e) {
			throw e;
		}
		return resultDto;
	}
	
	/**
	 * 
	 * updateBulletinboard
	 *
	 * @param reqBulletinboardProcessingDto
	 * @return ResultDto
	 * @throws Exception 
	 */
	@Override
	public ResultDto updateBulletinboard(BulletinboardProcessingDto reqBulletinboardProcessingDto) throws Exception {
		
		ResultDto resultDto = null;
		
		try {
			OomBulletinboardDto reqOomBulletinboardDto = reqBulletinboardProcessingDto.getBoardInfo();
			BlobRequestDto blobRequestDto = reqBulletinboardProcessingDto.getAttachFile();
			if (blobRequestDto != null) {
				// 기존 첨부파일이 존재하는 지 확인...
				BulletinboardDetailResultDto bulletinboardDetailResultDto = oomBulletinboardMapper.readOomBulletinboardAttachFile(reqOomBulletinboardDto);
				if (bulletinboardDetailResultDto != null) {
					int oldAttachFileNum = CommonObjectUtil.defaultNumber(bulletinboardDetailResultDto.getAttachFileNum());
					if (oldAttachFileNum > 0) {
						// 기존 첨부파일 삭제
						fileService.deleteAttachFile(Const.Definition.BLOB_CONTAINER.FILE, oldAttachFileNum);
					}
				}
				// 신규 첨부파일 등록..
				blobRequestDto.setContainerName(Const.Definition.BLOB_CONTAINER.FILE);
				blobRequestDto.setBlobBaseDir(Const.Definition.BLOB_BASEDIR.BOARD);
				int attachFileNum = fileService.createAttachFile(blobRequestDto);
				if (attachFileNum > 0) {
					reqOomBulletinboardDto.setAttachFileNum(attachFileNum);
				}
			}
			
			// 게시물 수정
			String bulletinTypeCd = reqOomBulletinboardDto.getBulletinTypeCd();
			if (Const.Code.BULLETIN_TYPE_CD.NOTICE.equals(bulletinTypeCd)) {
				String bulletinStartDatetime = reqOomBulletinboardDto.getBulletinStartDatetime();
        		String bulletinEndDatetime = reqOomBulletinboardDto.getBulletinEndDatetime();
        		bulletinStartDatetime = CommonDateUtil.makeFromDatetime(bulletinStartDatetime);
        		bulletinEndDatetime = CommonDateUtil.makeToDatetime(bulletinEndDatetime);
        		reqOomBulletinboardDto.setBulletinStartDatetime(bulletinStartDatetime);
        		reqOomBulletinboardDto.setBulletinEndDatetime(bulletinEndDatetime);
			}
			oomBulletinboardMapper.updateOomBulletinboard(reqOomBulletinboardDto);
			
			int bulletinNum = reqOomBulletinboardDto.getBulletinNum();
			String auditId = reqOomBulletinboardDto.getAuditId();
			String smsAlarmNoticeYn = reqOomBulletinboardDto.getSmsAlarmNoticeYn();
			
			if (Const.Code.BULLETIN_TYPE_CD.NOTICE.equals(bulletinTypeCd)) {
				// 게시판알람통지내역 삭제
				oomBulletinboardAlarmNoticeMapper.deleteOomBulletinboardAlarmNotice(reqOomBulletinboardDto);
				// 게시판알람통지SMS대상상세 삭제
				oomBulletinboardAlarmNoticeSmsMapper.deleteOomBulletinboardAlarmNoticeSms(reqOomBulletinboardDto);
			}
			
			// 공지사항 처리...
			if (Const.Code.BULLETIN_TYPE_CD.NOTICE.equals(bulletinTypeCd)) {
				if ("Y".equals(smsAlarmNoticeYn)) {
					String alarmNoticeResultCd = "1";
					OomKakaoAlimTalkDto reqOomKakaoAlimTalkDto = new OomKakaoAlimTalkDto();
					reqOomKakaoAlimTalkDto.setTmpltCode(Const.Definition.MSG_TEMPLATE_CODE.TSOP_002);
					reqOomKakaoAlimTalkDto.setSmsCreateCd(Const.Code.SMS_CREATE_CD.BOARD);
					OomKakaoAlimTalkDto oomKakaoAlimTalkDto = oomKakaoAlimTalkMapper.readKakaoAlimTalk(reqOomKakaoAlimTalkDto);
					if (oomKakaoAlimTalkDto != null) {
						List<AlimTalkDetailDto> alimTalkDetailDtoList = new ArrayList<AlimTalkDetailDto>();
						List<OomBulletinboardAlarmNoticeSmsDto> reqOomBulletinboardAlarmNoticeSmsDtoList = reqBulletinboardProcessingDto.getSmsUserList();
						StringBuilder rcvPhoneNumBuilder = new StringBuilder();
						for (int idx = 0; idx < reqOomBulletinboardAlarmNoticeSmsDtoList.size(); idx++) {
							OomBulletinboardAlarmNoticeSmsDto reqOomBulletinboardAlarmNoticeSmsDto = reqOomBulletinboardAlarmNoticeSmsDtoList.get(idx);
							String rcvPhoneNum = StringUtils.defaultString(reqOomBulletinboardAlarmNoticeSmsDto.getRcvPhoneNum());
							if (rcvPhoneNumBuilder.toString().indexOf(rcvPhoneNum) < 0) {
								String rcverId = StringUtils.defaultString(reqOomBulletinboardAlarmNoticeSmsDto.getRcverId());
								String rcverName = StringUtils.defaultString(reqOomBulletinboardAlarmNoticeSmsDto.getRcverName());
								
								AlimTalkDetailDto alimTalkDetailDto = new AlimTalkDetailDto();
								alimTalkDetailDto.setRcverId(rcverId);
								alimTalkDetailDto.setRcverName(rcverName);
								alimTalkDetailDto.setRcvPhoneNum(rcvPhoneNum);
								alimTalkDetailDtoList.add(alimTalkDetailDto);
								
								if (rcvPhoneNumBuilder.length() == 0) {
									rcvPhoneNumBuilder.append(rcvPhoneNum);
								} else {
									rcvPhoneNumBuilder.append(",");
									rcvPhoneNumBuilder.append(rcvPhoneNum);
								}
							}
						}
						
						String bulletinTitleName = StringUtils.defaultString(reqOomBulletinboardDto.getBulletinTitleName());
						String message = oomKakaoAlimTalkDto.getMessage();
						message = message.replaceAll("#\\{\"등록\"\\}", "수정");
						message = message.replaceAll("#\\{\"\"HVAC 전층 화재 알람 2등급 => 1등급으로 6/3일자 변경\"\"\\}", "\"" + bulletinTitleName + "\"");
						// 카카오 알림톡 발송 처리..
						AlimTalkRequestDto alimTalkRequestDto = new AlimTalkRequestDto();
						alimTalkRequestDto.setTmpltCode(Const.Definition.MSG_TEMPLATE_CODE.TSOP_002);
						alimTalkRequestDto.setRecipient(rcvPhoneNumBuilder.toString());
						alimTalkRequestDto.setMessage(message);
						alimTalkRequestDto.setSmsCreateCd(Const.Code.SMS_CREATE_CD.BOARD);
						alimTalkRequestDto.setBulletinTypeCd(bulletinTypeCd);
						alimTalkRequestDto.setBulletinNum(bulletinNum);
						alimTalkRequestDto.setAuditId(auditId);
						alimTalkRequestDto.setDetailList(alimTalkDetailDtoList);
						alarmNoticeResultCd = alimTalkService.sendOnmAlimTalk(alimTalkRequestDto);
						if (!"1".equals(alarmNoticeResultCd)) {
							// 성공이 아니면.. 모두 실패 처리...
							alarmNoticeResultCd = "2";
						}
						
						// 게시판알람통지내역 등록
						String alarmNoticeMethodClCd = Const.Code.ALARM_NOTICE_METHOD_CL_CD.SMS;
						OomBulletinboardAlarmNoticeDto reqOomBulletinboardAlarmNoticeDto = new OomBulletinboardAlarmNoticeDto();
						reqOomBulletinboardAlarmNoticeDto.setBulletinTypeCd(bulletinTypeCd);
						reqOomBulletinboardAlarmNoticeDto.setBulletinNum(bulletinNum);
						reqOomBulletinboardAlarmNoticeDto.setAuditId(auditId);
						reqOomBulletinboardAlarmNoticeDto.setAlarmNoticeMethodClCd(alarmNoticeMethodClCd);
						reqOomBulletinboardAlarmNoticeDto.setAlarmNoticeResultCd(alarmNoticeResultCd);
						oomBulletinboardAlarmNoticeMapper.createOomBulletinboardAlarmNotice(reqOomBulletinboardAlarmNoticeDto);
						
						// 게시판알람통지SMS대상상세 등록
						int transSeq = reqOomBulletinboardAlarmNoticeDto.getTransSeq();
						List<OomBulletinboardAlarmNoticeSmsDto> oomBulletinboardAlarmNoticeSmsDtoList = reqBulletinboardProcessingDto.getSmsUserList();
						for (OomBulletinboardAlarmNoticeSmsDto reqOomBulletinboardAlarmNoticeSmsDto : oomBulletinboardAlarmNoticeSmsDtoList) {
							reqOomBulletinboardAlarmNoticeSmsDto.setBulletinTypeCd(bulletinTypeCd);
							reqOomBulletinboardAlarmNoticeSmsDto.setBulletinNum(bulletinNum);
							reqOomBulletinboardAlarmNoticeSmsDto.setTransSeq(transSeq);
							reqOomBulletinboardAlarmNoticeSmsDto.setAuditId(auditId);
							oomBulletinboardAlarmNoticeSmsMapper.createOomBulletinboardAlarmNoticeSms(reqOomBulletinboardAlarmNoticeSmsDto);
						}
					}
				}
				
				List<OomBulletinboardAlarmNoticeTenantDto> reqOomBulletinboardAlarmNoticeTenantDtoList = reqBulletinboardProcessingDto.getTenantList();
				if (!CollectionUtils.isEmpty(reqOomBulletinboardAlarmNoticeTenantDtoList)) {
					for (OomBulletinboardAlarmNoticeTenantDto reqOomBulletinboardAlarmNoticeTenantDto : reqOomBulletinboardAlarmNoticeTenantDtoList) {
						String rcvTenantId = StringUtils.defaultString(reqOomBulletinboardAlarmNoticeTenantDto.getRcvTenantId());
						if ("0001".equals(rcvTenantId)) {
							// ToDo : 나중에 이 if문은 걷어내야 함....
							// Remote Call 처리...
							String actionYn = StringUtils.defaultString(tenantConfig.getTenantSktServerInfo().getActionYn());
							if ("Y".equals(actionYn)) {
								String key = tenantConfig.getTenantSktServerInfo().getKey();
								String portalWasUrl = tenantConfig.getTenantSktServerInfo().getUrl();
								
								StringBuilder urlBuilder = new StringBuilder();
								urlBuilder.append(portalWasUrl);
								urlBuilder.append("/api/portal/callees/update-bulletin");
								
								Gson gson = new Gson();
					    	    String requestJsonString = gson.toJson(reqBulletinboardProcessingDto);
								
								OkHttpClient client = new OkHttpClient();
								Request request = new Request.Builder()
										.addHeader("Call-Key", key)
										.url(urlBuilder.toString())
					    	            .post(RequestBody.create(MediaType.parse(org.springframework.http.MediaType.APPLICATION_JSON.toString()), requestJsonString))
					    	            .build();
					    	    
								Response response = null;
								try {
					    	    	response = client.newCall(request).execute();
					    	    } catch (ConnectException e) {
					    	    	resultDto = new ResultDto(Const.Common.RESULT_CODE.FAIL, ERR_MSG_REMOTE_CALL_CONNECTION_FAIL);
					    	    	return resultDto;
					    	    } catch (ConnectTimeoutException e) {
					    	    	resultDto = new ResultDto(Const.Common.RESULT_CODE.FAIL, ERR_MSG_REMOTE_CALL_TIMEOUT);
					    	    	return resultDto;
					    	    }
								
					    	    String responseJsonString = StringUtils.defaultString(response.body().string());
								if ("".equals(responseJsonString)) {
									resultDto = new ResultDto(Const.Common.RESULT_CODE.FAIL, ERR_MSG_REMOTE_EXECUTION_FAIL);
									return resultDto;
								} else {
									JsonObject responseJsonObject = JsonParser.parseString(responseJsonString).getAsJsonObject();
									
									ObjectMapper objectMapper = new ObjectMapper();
									resultDto = objectMapper.readValue(responseJsonObject.toString(), ResultDto.class);
								}
							}
						}
					}
				} else {
					resultDto = new ResultDto(Const.Common.RESULT_CODE.SUCCESS, "");
				}
			} else {
				resultDto = new ResultDto(Const.Common.RESULT_CODE.SUCCESS, "");
			}
		} catch (Exception e) {
			throw e;
		}
		
		return resultDto;
	}
	
	/**
	 * 
	 * deleteBulletinboard
	 *
	 * @param deleteBulletinboardRequestDto
	 * @return ResultDto
	 * @throws Exception 
	 */
	@Override
	public ResultDto deleteBulletinboard(DeleteBulletinboardRequestDto deleteBulletinboardRequestDto) throws Exception {
		
		ResultDto resultDto = null;
		
		try {
			OomBulletinboardDto reqOomBulletinboardDto = new OomBulletinboardDto();
			BeanUtils.copyProperties(deleteBulletinboardRequestDto, reqOomBulletinboardDto);
			
			// 공지사항 처리...
			String bulletinTypeCd = reqOomBulletinboardDto.getBulletinTypeCd();
			if (Const.Code.BULLETIN_TYPE_CD.NOTICE.equals(bulletinTypeCd)) {
				// Remote Call 처리...
				List<OomBulletinboardAlarmNoticeTenantDto> reqOomBulletinboardAlarmNoticeTenantDtoList = deleteBulletinboardRequestDto.getTenantList();
				if (!CollectionUtils.isEmpty(reqOomBulletinboardAlarmNoticeTenantDtoList)) {
					for (OomBulletinboardAlarmNoticeTenantDto reqOomBulletinboardAlarmNoticeTenantDto : reqOomBulletinboardAlarmNoticeTenantDtoList) {
						String rcvTenantId = StringUtils.defaultString(reqOomBulletinboardAlarmNoticeTenantDto.getRcvTenantId());
						if ("0001".equals(rcvTenantId)) {
							// ToDo : 나중에 이 if문은 걷어내야 함....
							String key = tenantConfig.getTenantSktServerInfo().getKey();
							String portalWasUrl = tenantConfig.getTenantSktServerInfo().getUrl();
							
							StringBuilder urlBuilder = new StringBuilder();
							urlBuilder.append(portalWasUrl);
							urlBuilder.append("/api/portal/callees/delete-bulletin");
							
							Gson gson = new Gson();
				    	    String requestJsonString = gson.toJson(reqOomBulletinboardDto);
							
							OkHttpClient client = new OkHttpClient();
							Request request = new Request.Builder()
									.addHeader("Call-Key", key)
									.url(urlBuilder.toString())
				    	            .post(RequestBody.create(MediaType.parse(org.springframework.http.MediaType.APPLICATION_JSON.toString()), requestJsonString))
				    	            .build();
				    	    
				    	    Response response = null;
							try {
				    	    	response = client.newCall(request).execute();
				    	    } catch (ConnectException e) {
				    	    	resultDto = new ResultDto(Const.Common.RESULT_CODE.FAIL, ERR_MSG_REMOTE_CALL_CONNECTION_FAIL);
				    	    	return resultDto;
				    	    } catch (ConnectTimeoutException e) {
				    	    	resultDto = new ResultDto(Const.Common.RESULT_CODE.FAIL, ERR_MSG_REMOTE_CALL_TIMEOUT);
				    	    	return resultDto;
				    	    }
				    	    
				    	    String responseJsonString = StringUtils.defaultString(response.body().string());
							if ("".equals(responseJsonString)) {
								resultDto = new ResultDto(Const.Common.RESULT_CODE.FAIL, ERR_MSG_REMOTE_EXECUTION_FAIL);
								return resultDto;
							} else {
								JsonObject responseJsonObject = JsonParser.parseString(responseJsonString).getAsJsonObject();
								
								ObjectMapper objectMapper = new ObjectMapper();
								resultDto = objectMapper.readValue(responseJsonObject.toString(), ResultDto.class);
							}
						}
					}
				}
			}
			oomBulletinboardMapper.deleteOomBulletinboard(reqOomBulletinboardDto);
			resultDto = new ResultDto(Const.Common.RESULT_CODE.SUCCESS, "");
			
		} catch (Exception e) {
			throw e;
		}
		return resultDto;
	}

}
