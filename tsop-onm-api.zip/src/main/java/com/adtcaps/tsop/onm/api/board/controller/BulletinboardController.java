package com.adtcaps.tsop.onm.api.board.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.util.CollectionUtils;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.adtcaps.tsop.onm.api.authentication.domain.JwtAuthResultDto;
import com.adtcaps.tsop.onm.api.board.domain.BulletinboardDetailResultDto;
import com.adtcaps.tsop.onm.api.board.domain.BulletinboardGridRequestDto;
import com.adtcaps.tsop.onm.api.board.domain.BulletinboardGridResultDto;
import com.adtcaps.tsop.onm.api.board.domain.BulletinboardProcessingDto;
import com.adtcaps.tsop.onm.api.board.domain.DeleteBulletinboardRequestDto;
import com.adtcaps.tsop.onm.api.board.service.BulletinboardService;
import com.adtcaps.tsop.onm.api.domain.OomBulletinboardAlarmNoticeSmsDto;
import com.adtcaps.tsop.onm.api.domain.OomBulletinboardDto;
import com.adtcaps.tsop.onm.api.file.domain.BlobRequestDto;
import com.adtcaps.tsop.onm.api.helper.constant.Const;
import com.adtcaps.tsop.onm.api.helper.domain.ResultDto;
import com.adtcaps.tsop.onm.api.helper.util.CommonObjectUtil;
import com.adtcaps.tsop.onm.api.helper.util.PageUtil;

import lombok.extern.slf4j.Slf4j;

/**
 * 
 * <ul>
 * <li>업무 그룹명 : tsop-onm-api</li>
 * <li>서브 업무명 : com.adtcaps.tsop.onm.api.board.controller</li>
 * <li>설  명 : BulletinboardController.java</li>
 * <li>작성일 : 2021. 1. 8.</li>
 * <li>작성자 : jeonyb4</li>
 * </ul>
 */
@Slf4j
@RestController
@RequestMapping("/api/boards")
public class BulletinboardController {
	
	private final String ERR_MSG_NULL_LOGIN_USER_ID = "로그인 사용자ID가 없습니다.";
	private final String ERR_MSG_NULL_MGR_YN = "관리자여부가 없습니다.";
	private final String ERR_MSG_NULL_PAGE_NUMBER = "페이지 번호가 없습니다.";
	private final String ERR_MSG_NULL_SEARCH_DATE = "조회기간(From or To)이 없습니다.";
	private final String ERR_MSG_NULL_BULLETIN_START_END_DATE = "게시기간(Start or End)이 없습니다.";
	
	private final String ERR_MSG_NULL_BULLETIN_INFO = "게시물 등록정보가 없습니다.";
	private final String ERR_MSG_NULL_BULLETIN_TYPE_CD = "게시물유형코드가 없습니다.";
	private final String ERR_MSG_NULL_BULLETIN_TITLE_NAME = "게시제목명이 없습니다.";
	private final String ERR_MSG_NULL_BULLETIN_CL_CD = "게시구분코드가 없습니다.";
	private final String ERR_MSG_NULL_SMS_USER_LIST = "SMS 발송대상 정보가 없습니다.";
	private final String ERR_MSG_NULL_LOCAL_FILE_PATH = "로컬파일경로가 없습니다.";
	private final String ERR_MSG_NULL_ATTACH_FILE_NUM = "첨부파일번호가 없습니다.";
	private final String ERR_MSG_NULL_BULLETIN_NUM = "게시번호가 없습니다.";
	private final String ERR_MSG_NULL_REGISTER_ID = "등록자ID가 없습니다.";
	
	private final String ERR_MSG_ABNORMAL_AUTH = "현재 사용자는 권한이 없습니다.";
	private final String ERR_MSG_CANNOT_FIND = "현재 게시물 정보를 찾을 수 없습니다.";
	
	private final String ERR_MSG_NULL_SEARCH_RESULT_LIST = "조회 결과가 없습니다.";
	
	private final String ERR_MSG_CREATE_FAIL = "등록에 실패하였습니다.";
	private final String ERR_MSG_ATTACH_FILE_DELETE_FAIL = "첨부파일 삭제에 실패하였습니다.";
	private final String ERR_MSG_READ_FAIL = "조회에 실패하였습니다.";
	private final String ERR_MSG_UPDATE_FAIL = "수정에 실패하였습니다.";
	private final String ERR_MSG_DELETE_FAIL = "삭제에 실패하였습니다.";
	
	@Autowired
	private BulletinboardService bulletinboardService;
	
	/**
	 * 
	 * listPageBulletinboard
	 *
	 * @param bulletinboardGridRequestDto
	 * @return ResponseEntity
	 */
	@SuppressWarnings("rawtypes")
    @GetMapping(value="/bulletin-types/{bulletinTypeCd}/bulletins", produces="application/json; charset=UTF-8")
    public ResponseEntity listPageBulletinboard(@PathVariable("bulletinTypeCd") String bulletinTypeCd, BulletinboardGridRequestDto bulletinboardGridRequestDto) throws Exception {
        
    	ResponseEntity<ResultDto> resEntity = null;
		String returnString = "";
    	
		int pageNumber = CommonObjectUtil.defaultNumber(bulletinboardGridRequestDto.getPageNumber());
		if (pageNumber < 1) {
			log.error(">>>>>> pageNumber ERROR:{}", ERR_MSG_NULL_PAGE_NUMBER);
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_PAGE_NUMBER));
			return resEntity;
		}
		String fromDate = bulletinboardGridRequestDto.getFromDate();
		String toDate = bulletinboardGridRequestDto.getToDate();
		if ("".equals(fromDate) || "".equals(toDate)) {
			log.error(">>>>>> fromDate or toDate ERROR:{}", ERR_MSG_NULL_SEARCH_DATE);
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_SEARCH_DATE));
			return resEntity;
		}
		
		// 게시물 목록 조회....
		bulletinboardGridRequestDto.setBulletinTypeCd(bulletinTypeCd);
		Map<String, Object> bulletinboardGridResultDtoListMap = new HashMap<String, Object>();
		List<BulletinboardGridResultDto> bulletinboardGridResultDtoList = bulletinboardService.listPageBulletinboard(bulletinboardGridRequestDto);
		if (CollectionUtils.isEmpty(bulletinboardGridResultDtoList)) {
			returnString = Const.Common.RESULT_CODE.SUCCESS;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_SEARCH_RESULT_LIST, bulletinboardGridResultDtoListMap));
		} else {
			returnString = Const.Common.RESULT_CODE.SUCCESS;
			bulletinboardGridResultDtoListMap.put(Const.Definition.PAGE.PAGER, PageUtil.getPageInfo(bulletinboardGridResultDtoList));
			bulletinboardGridResultDtoListMap.put(Const.Definition.PAGE.LISTS, bulletinboardGridResultDtoList);
			resEntity = ResponseEntity.ok(new ResultDto(returnString, "", bulletinboardGridResultDtoListMap));
		}
    	
    	return resEntity;
    }
	
	/**
	 * 
	 * createBulletinboard
	 *
	 * @param bulletinTypeCd
	 * @param reqBulletinboardProcessingDto
	 * @return ResponseEntity
	 */
	@SuppressWarnings("rawtypes")
    @PostMapping(value="/bulletin-types/{bulletinTypeCd}/bulletins", produces="application/json; charset=UTF-8")
    public ResponseEntity createBulletinboard(@AuthenticationPrincipal JwtAuthResultDto authResultDto, 
    		@PathVariable("bulletinTypeCd") String bulletinTypeCd, @RequestBody BulletinboardProcessingDto reqBulletinboardProcessingDto) throws Exception {
        
    	ResponseEntity<ResultDto> resEntity = null;
		String returnString = "";
    	
		String loginUserId = StringUtils.defaultString(authResultDto.getUserId());
		if ("".equals(loginUserId)) {
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_LOGIN_USER_ID));
			return resEntity;
		}
		//String loginUserId = "admin"; // 이후 세션에서 얻어올 값...
		
		OomBulletinboardDto oomBulletinboardDto = reqBulletinboardProcessingDto.getBoardInfo();
		if (oomBulletinboardDto == null) {
			log.error(">>>>>> oomBulletinboardDto ERROR:{}", ERR_MSG_NULL_BULLETIN_INFO);
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_BULLETIN_INFO));
			return resEntity;
		}
		String bulletinTitleName = StringUtils.defaultString(oomBulletinboardDto.getBulletinTitleName());
		if ("".equals(bulletinTitleName)) {
			log.error(">>>>>> bulletinTitleName ERROR:{}", ERR_MSG_NULL_BULLETIN_TITLE_NAME);
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_BULLETIN_TITLE_NAME));
			return resEntity;
		}
		if (Const.Code.BULLETIN_TYPE_CD.NOTICE.equals(bulletinTypeCd)) {
			String bulletinClCd = StringUtils.defaultString(oomBulletinboardDto.getBulletinClCd());
    		if ("".equals(bulletinClCd)) {
    			log.error(">>>>>> bulletinClCd ERROR:{}", ERR_MSG_NULL_BULLETIN_CL_CD);
				returnString = Const.Common.RESULT_CODE.FAIL;
    			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_BULLETIN_CL_CD));
    			return resEntity;
    		}
    		String bulletinStartDatetime = oomBulletinboardDto.getBulletinStartDatetime();
    		String bulletinEndDatetime = oomBulletinboardDto.getBulletinEndDatetime();
    		if ("".equals(bulletinStartDatetime) || "".equals(bulletinEndDatetime)) {
    			log.error(">>>>>> bulletinStartDatetime or bulletinEndDatetime ERROR:{}", ERR_MSG_NULL_BULLETIN_START_END_DATE);
				returnString = Const.Common.RESULT_CODE.FAIL;
    			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_BULLETIN_START_END_DATE));
    			return resEntity;
    		}
		}
		
		String pushAlarmNoticeYn = StringUtils.defaultString(oomBulletinboardDto.getPushAlarmNoticeYn());
		String smsAlarmNoticeYn = StringUtils.defaultString(oomBulletinboardDto.getSmsAlarmNoticeYn());
		if ("".equals(pushAlarmNoticeYn)) {
			oomBulletinboardDto.setPushAlarmNoticeYn("N");
		}
		if ("".equals(smsAlarmNoticeYn)) {
			oomBulletinboardDto.setSmsAlarmNoticeYn("N");
		}
		if ("Y".equals(smsAlarmNoticeYn)) {
			List<OomBulletinboardAlarmNoticeSmsDto> reqOomBulletinboardAlarmNoticeSmsDtoList = reqBulletinboardProcessingDto.getSmsUserList();
			if (CollectionUtils.isEmpty(reqOomBulletinboardAlarmNoticeSmsDtoList)) {
				log.error(">>>>>> reqOomBulletinboardAlarmNoticeSmsDtoList ERROR:{}", ERR_MSG_NULL_SMS_USER_LIST);
				returnString = Const.Common.RESULT_CODE.FAIL;
    			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_SMS_USER_LIST));
    			return resEntity;
			}
		}
		BlobRequestDto blobRequestDto = reqBulletinboardProcessingDto.getAttachFile();
		if (blobRequestDto != null) {
			String localFilePath = StringUtils.defaultString(blobRequestDto.getLocalFilePath());
			if ("".equals(localFilePath)) {
    			log.error(">>>>>> localFilePath ERROR:{}", ERR_MSG_NULL_LOCAL_FILE_PATH);
				returnString = Const.Common.RESULT_CODE.FAIL;
    			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_LOCAL_FILE_PATH));
    			return resEntity;
    		}
		}
		
		oomBulletinboardDto.setRegisterId(loginUserId);
		oomBulletinboardDto.setAuditId(loginUserId);
		oomBulletinboardDto.setBulletinTypeCd(bulletinTypeCd);
		reqBulletinboardProcessingDto.setBoardInfo(oomBulletinboardDto);
		
		// 게시물 등록...
		ResultDto resultDto = bulletinboardService.createBulletinboard(reqBulletinboardProcessingDto);
		if (resultDto == null) {
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_CREATE_FAIL, resultDto));
		} else {
			resEntity = ResponseEntity.ok(resultDto);
		}
    	
    	return resEntity;
    }
	
	/**
	 * 
	 * readBulletinboard
	 *
	 * @param bulletinTypeCd
	 * @param bulletinNum
	 * @return ResponseEntity
	 */
	@SuppressWarnings("rawtypes")
    @GetMapping(value="/bulletin-types/{bulletinTypeCd}/bulletins/{bulletinNum}", produces="application/json; charset=UTF-8")
    public ResponseEntity readBulletinboard(@PathVariable("bulletinTypeCd") String bulletinTypeCd, @PathVariable("bulletinNum") int bulletinNum) throws Exception {
        
    	ResponseEntity<ResultDto> resEntity = null;
		String returnString = "";
    	
		OomBulletinboardDto reqOomBulletinboardDto = new OomBulletinboardDto();
		reqOomBulletinboardDto.setBulletinTypeCd(bulletinTypeCd);
		reqOomBulletinboardDto.setBulletinNum(bulletinNum);
		
		BulletinboardDetailResultDto bulletinboardDetailResultDto = bulletinboardService.readBulletinboard(reqOomBulletinboardDto);
		if (bulletinboardDetailResultDto == null) {
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_READ_FAIL, bulletinboardDetailResultDto));
		} else {
			returnString = Const.Common.RESULT_CODE.SUCCESS;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, "", bulletinboardDetailResultDto));
		}
    	
    	return resEntity;
    }
	
	/**
	 * 
	 * deleteBulletinboardAttachFile
	 *
	 * @param bulletinTypeCd
	 * @param bulletinNum
	 * @param attachFileNum
	 * @return ResponseEntity
	 */
	@SuppressWarnings("rawtypes")
    @DeleteMapping(value="/bulletin-types/{bulletinTypeCd}/bulletins/{bulletinNum}/attach-files/{attachFileNum}", produces="application/json; charset=UTF-8")
    public ResponseEntity deleteBulletinboardAttachFile(@AuthenticationPrincipal JwtAuthResultDto authResultDto, 
    		@PathVariable("bulletinTypeCd") String bulletinTypeCd, @PathVariable("bulletinNum") int bulletinNum, @PathVariable("attachFileNum") int attachFileNum, 
    		@RequestBody DeleteBulletinboardRequestDto deleteBulletinboardRequestDto) throws Exception {
        
    	ResponseEntity<ResultDto> resEntity = null;
		String returnString = "";
    	
		String loginUserId = StringUtils.defaultString(authResultDto.getUserId());
		if ("".equals(loginUserId)) {
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_LOGIN_USER_ID));
			return resEntity;
		}
		String mgrYn = StringUtils.defaultString(authResultDto.getMgrYn());
		if ("".equals(mgrYn)) {
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_MGR_YN));
			return resEntity;
		}
		String registerId = StringUtils.defaultString(deleteBulletinboardRequestDto.getRegisterId());
		if ("".equals(registerId)) {
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_REGISTER_ID));
			return resEntity;
		}
		
		bulletinTypeCd = StringUtils.defaultString(bulletinTypeCd);
		if ("".equals(bulletinTypeCd)) {
			throw new Exception(ERR_MSG_NULL_BULLETIN_TYPE_CD);
		}
		bulletinNum = CommonObjectUtil.defaultNumber(bulletinNum);
		if (bulletinNum < 1) {
			throw new Exception(ERR_MSG_NULL_BULLETIN_NUM);
		}
		attachFileNum = CommonObjectUtil.defaultNumber(attachFileNum);
		if (attachFileNum < 1) {
			throw new Exception(ERR_MSG_NULL_ATTACH_FILE_NUM);
		}
		
		// 삭제할 권한이 있는지 체크...
		if (!"Y".equals(mgrYn)) {
			// 등록자 확인...
			OomBulletinboardDto reqOomBulletinboardDto = new OomBulletinboardDto();
			reqOomBulletinboardDto.setBulletinTypeCd(bulletinTypeCd);
			reqOomBulletinboardDto.setBulletinNum(bulletinNum);
			BulletinboardDetailResultDto bulletinboardDetailResultDto = bulletinboardService.readBulletinboard(reqOomBulletinboardDto);
			if (bulletinboardDetailResultDto == null) {
				returnString = Const.Common.RESULT_CODE.FAIL;
				resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_CANNOT_FIND));
				return resEntity;
			}
			if (!registerId.equals(loginUserId)) {
				returnString = Const.Common.RESULT_CODE.FAIL;
				resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_ABNORMAL_AUTH));
				return resEntity;
			}
		}
		
		deleteBulletinboardRequestDto.setBulletinTypeCd(bulletinTypeCd);
		deleteBulletinboardRequestDto.setBulletinNum(bulletinNum);
		deleteBulletinboardRequestDto.setAttachFileNum(attachFileNum);
		ResultDto resultDto = bulletinboardService.deleteBulletinboardAttachFile(deleteBulletinboardRequestDto);
		if (resultDto == null) {
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_ATTACH_FILE_DELETE_FAIL, resultDto));
		} else {
			resEntity = ResponseEntity.ok(resultDto);
		}
    	
    	return resEntity;
    }
	
	/**
	 * 
	 * updateBulletinboard
	 *
	 * @param bulletinTypeCd
	 * @param bulletinNum
	 * @param reqBulletinboardProcessingDto
	 * @return ResponseEntity
	 */
	@SuppressWarnings("rawtypes")
    @PutMapping(value="/bulletin-types/{bulletinTypeCd}/bulletins/{bulletinNum}", produces="application/json; charset=UTF-8")
    public ResponseEntity updateBulletinboard(@AuthenticationPrincipal JwtAuthResultDto authResultDto, 
    		@PathVariable("bulletinTypeCd") String bulletinTypeCd, @PathVariable("bulletinNum") int bulletinNum, @RequestBody BulletinboardProcessingDto reqBulletinboardProcessingDto) throws Exception {
        
    	ResponseEntity<ResultDto> resEntity = null;
		String returnString = "";
    	
		String loginUserId = StringUtils.defaultString(authResultDto.getUserId());
		if ("".equals(loginUserId)) {
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_LOGIN_USER_ID));
			return resEntity;
		}
		String mgrYn = StringUtils.defaultString(authResultDto.getMgrYn());
		if ("".equals(mgrYn)) {
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_MGR_YN));
			return resEntity;
		}
		//String loginUserId = "tsop-admin"; // 이후 세션에서 얻어올 값...
		
		OomBulletinboardDto oomBulletinboardDto = reqBulletinboardProcessingDto.getBoardInfo();
		if (oomBulletinboardDto == null) {
			log.error(">>>>>> oomBulletinboardDto ERROR:{}", ERR_MSG_NULL_BULLETIN_INFO);
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_BULLETIN_INFO));
			return resEntity;
		}
		String bulletinTitleName = StringUtils.defaultString(oomBulletinboardDto.getBulletinTitleName());
		if ("".equals(bulletinTitleName)) {
			log.error(">>>>>> bulletinTitleName ERROR:{}", ERR_MSG_NULL_BULLETIN_TITLE_NAME);
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_BULLETIN_TITLE_NAME));
			return resEntity;
		}
		if (Const.Code.BULLETIN_TYPE_CD.NOTICE.equals(bulletinTypeCd)) {
			String bulletinClCd = StringUtils.defaultString(oomBulletinboardDto.getBulletinClCd());
    		if ("".equals(bulletinClCd)) {
    			log.error(">>>>>> bulletinClCd ERROR:{}", ERR_MSG_NULL_BULLETIN_CL_CD);
				returnString = Const.Common.RESULT_CODE.FAIL;
    			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_BULLETIN_CL_CD));
    			return resEntity;
    		}
    		String bulletinStartDatetime = oomBulletinboardDto.getBulletinStartDatetime();
    		String bulletinEndDatetime = oomBulletinboardDto.getBulletinEndDatetime();
    		if ("".equals(bulletinStartDatetime) || "".equals(bulletinEndDatetime)) {
    			log.error(">>>>>> bulletinStartDatetime or bulletinEndDatetime ERROR:{}", ERR_MSG_NULL_BULLETIN_START_END_DATE);
				returnString = Const.Common.RESULT_CODE.FAIL;
    			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_BULLETIN_START_END_DATE));
    			return resEntity;
    		}
		}

		oomBulletinboardDto.setBulletinTypeCd(bulletinTypeCd);
		oomBulletinboardDto.setBulletinNum(bulletinNum);
		
		// 수정할 권한이 있는지 체크...
		if (!"Y".equals(mgrYn)) {
			// 등록자 확인...
			BulletinboardDetailResultDto bulletinboardDetailResultDto = bulletinboardService.readBulletinboard(oomBulletinboardDto);
			if (bulletinboardDetailResultDto == null) {
				returnString = Const.Common.RESULT_CODE.FAIL;
				resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_CANNOT_FIND));
				return resEntity;
			}
			String registerId = StringUtils.defaultString(bulletinboardDetailResultDto.getRegisterId());
			if (!registerId.equals(loginUserId)) {
				returnString = Const.Common.RESULT_CODE.FAIL;
				resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_ABNORMAL_AUTH));
				return resEntity;
			}
		}
		
		String pushAlarmNoticeYn = StringUtils.defaultString(oomBulletinboardDto.getPushAlarmNoticeYn());
		String smsAlarmNoticeYn = StringUtils.defaultString(oomBulletinboardDto.getSmsAlarmNoticeYn());
		if ("".equals(pushAlarmNoticeYn)) {
			oomBulletinboardDto.setPushAlarmNoticeYn("N");
		}
		if ("".equals(smsAlarmNoticeYn)) {
			oomBulletinboardDto.setSmsAlarmNoticeYn("N");
		}
		if ("Y".equals(smsAlarmNoticeYn)) {
			List<OomBulletinboardAlarmNoticeSmsDto> reqOomBulletinboardAlarmNoticeSmsDtoList = reqBulletinboardProcessingDto.getSmsUserList();
			if (CollectionUtils.isEmpty(reqOomBulletinboardAlarmNoticeSmsDtoList)) {
				log.error(">>>>>> reqOomBulletinboardAlarmNoticeSmsDtoList ERROR:{}", ERR_MSG_NULL_SMS_USER_LIST);
				returnString = Const.Common.RESULT_CODE.FAIL;
    			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_SMS_USER_LIST));
    			return resEntity;
			}
		}
		BlobRequestDto blobRequestDto = reqBulletinboardProcessingDto.getAttachFile();
		if (blobRequestDto != null) {
			String localFilePath = StringUtils.defaultString(blobRequestDto.getLocalFilePath());
			if ("".equals(localFilePath)) {
    			log.error(">>>>>> localFilePath ERROR:{}", ERR_MSG_NULL_LOCAL_FILE_PATH);
				returnString = Const.Common.RESULT_CODE.FAIL;
    			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_LOCAL_FILE_PATH));
    			return resEntity;
    		}
		}
		
		oomBulletinboardDto.setAuditId(loginUserId);
		reqBulletinboardProcessingDto.setBoardInfo(oomBulletinboardDto);
		
		// 게시물 수정...
		ResultDto resultDto = bulletinboardService.updateBulletinboard(reqBulletinboardProcessingDto);
		if (resultDto == null) {
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_UPDATE_FAIL, resultDto));
		} else {
			resEntity = ResponseEntity.ok(resultDto);
		}
    	
    	return resEntity;
    }
	
	/**
	 * 
	 * deleteBulletinboard
	 *
	 * @param bulletinTypeCd
	 * @param bulletinNum
	 * @return ResponseEntity
	 */
	@SuppressWarnings("rawtypes")
    @DeleteMapping(value="/bulletin-types/{bulletinTypeCd}/bulletins/{bulletinNum}", produces="application/json; charset=UTF-8")
    public ResponseEntity deleteBulletinboard(@AuthenticationPrincipal JwtAuthResultDto authResultDto, 
    		@PathVariable("bulletinTypeCd") String bulletinTypeCd, @PathVariable("bulletinNum") int bulletinNum, @RequestBody DeleteBulletinboardRequestDto deleteBulletinboardRequestDto) throws Exception {
        
    	ResponseEntity<ResultDto> resEntity = null;
		String returnString = "";
    	
		String loginUserId = StringUtils.defaultString(authResultDto.getUserId());
		if ("".equals(loginUserId)) {
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_LOGIN_USER_ID));
			return resEntity;
		}
		String mgrYn = StringUtils.defaultString(authResultDto.getMgrYn());
		if ("".equals(mgrYn)) {
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_MGR_YN));
			return resEntity;
		}
		//String loginUserId = "tsop-admin"; // 이후 세션에서 얻어올 값...
		
		// 삭제할 권한이 있는지 체크...
		if (!"Y".equals(mgrYn)) {
			// 등록자 확인...
			OomBulletinboardDto reqOomBulletinboardDto = new OomBulletinboardDto();
			reqOomBulletinboardDto.setBulletinTypeCd(bulletinTypeCd);
			reqOomBulletinboardDto.setBulletinNum(bulletinNum);
			BulletinboardDetailResultDto bulletinboardDetailResultDto = bulletinboardService.readBulletinboard(reqOomBulletinboardDto);
			if (bulletinboardDetailResultDto == null) {
				returnString = Const.Common.RESULT_CODE.FAIL;
				resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_CANNOT_FIND));
				return resEntity;
			}
			String registerId = StringUtils.defaultString(bulletinboardDetailResultDto.getRegisterId());
			if (!registerId.equals(loginUserId)) {
				returnString = Const.Common.RESULT_CODE.FAIL;
				resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_ABNORMAL_AUTH));
				return resEntity;
			}
		}
		
		deleteBulletinboardRequestDto.setBulletinTypeCd(bulletinTypeCd);
		deleteBulletinboardRequestDto.setBulletinNum(bulletinNum);
		deleteBulletinboardRequestDto.setAuditId(loginUserId);
		
		// 게시물 삭제...
		ResultDto resultDto = bulletinboardService.deleteBulletinboard(deleteBulletinboardRequestDto);
		if (resultDto == null) {
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_DELETE_FAIL, resultDto));
		} else {
			resEntity = ResponseEntity.ok(resultDto);
		}
    	
    	return resEntity;
    }

}
