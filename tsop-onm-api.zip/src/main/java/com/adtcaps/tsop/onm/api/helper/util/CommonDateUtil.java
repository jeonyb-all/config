package com.adtcaps.tsop.onm.api.helper.util;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

import org.apache.commons.lang3.StringUtils;

/**
 * 
 * <ul>
 * <li>업무 그룹명 : tsop-onm-api</li>
 * <li>서브 업무명 : com.adtcaps.tsop.onm.api.helper.util</li>
 * <li>설  명 : CommonDateUtil.java</li>
 * <li>작성일 : 2021. 1. 2.</li>
 * <li>작성자 : jeonyb4</li>
 * </ul>
 */
public class CommonDateUtil {
	/**
	 * 
	 * makeFromDatetime
	 *
	 * @param fromDate
	 * @return String
	 */
	public static String makeFromDatetime(String fromDate) {
		StringBuilder fromDatetimeBuilder = new StringBuilder();
		fromDatetimeBuilder.append(fromDate);
		fromDatetimeBuilder.append("000000");
		
		return fromDatetimeBuilder.toString();
	}
	
	/**
	 * 
	 * makeToDatetime
	 *
	 * @param toDate
	 * @return String
	 */
	public static String makeToDatetime(String toDate) {
		StringBuilder toDatetimeBuilder = new StringBuilder();
		toDatetimeBuilder.append(toDate);
		toDatetimeBuilder.append("235959");
		
		return toDatetimeBuilder.toString();
	}
	
	/**
	 * 
	 * makeFromDatetimeForCompareDatetime
	 *
	 * @param fromDate
	 * @return String
	 */
	public static String makeFromDatetimeForCompareDatetime(String fromDate) {
		StringBuilder fromDatetimeBuilder = new StringBuilder();
		fromDatetimeBuilder.append(fromDate);
		fromDatetimeBuilder.append(" 00:00:00");
		
		return fromDatetimeBuilder.toString();
	}
	
	/**
	 * 
	 * makeToDatetimeForCompareDatetime
	 *
	 * @param toDate
	 * @return String
	 */
	public static String makeToDatetimeForCompareDatetime(String toDate) {
		StringBuilder toDatetimeBuilder = new StringBuilder();
		toDatetimeBuilder.append(toDate);
		toDatetimeBuilder.append(" 23:59:59");
		
		return toDatetimeBuilder.toString();
	}
	
	/**
	 * 
	 * makeFromDateHourminute
	 *
	 * @param fromDate
	 * @return String
	 */
	public static String makeFromDateHourminute(String fromDate) {
		StringBuilder fromDateHourminuteBuilder = new StringBuilder();
		fromDateHourminuteBuilder.append(fromDate);
		fromDateHourminuteBuilder.append("0000");
		
		return fromDateHourminuteBuilder.toString();
	}
	
	/**
	 * 
	 * makeToDateHourminute
	 *
	 * @param toDate
	 * @return String
	 */
	public static String makeToDateHourminute(String toDate) {
		StringBuilder toDateHourminuteBuilder = new StringBuilder();
		toDateHourminuteBuilder.append(toDate);
		toDateHourminuteBuilder.append("2359");
		
		return toDateHourminuteBuilder.toString();
	}
	
	/**
	 * 
	 * makeDatetimeFormat
	 *
	 * @param date
	 * @param time
	 * @return String
	 * @throws ParseException 
	 */
	public static String makeDatetimeFormat(String date, String time) throws ParseException {
		
		if ("".equals(StringUtils.defaultString(date)) || "".equals(StringUtils.defaultString(time))) {
			return "";
		}
		
		StringBuilder datetimeBuilder = new StringBuilder();
		datetimeBuilder.append(date);
		datetimeBuilder.append(time);
		
		SimpleDateFormat orginFormat = new SimpleDateFormat("yyyyMMddHHmmss");
		Date orginDatetime = orginFormat.parse(datetimeBuilder.toString());
		
		SimpleDateFormat transFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		String transDatetime = transFormat.format(orginDatetime);
		
		return transDatetime;
	}
	
	/**
	 * 
	 * makeDatetimeFormat
	 *
	 * @param datetime
	 * @return String
	 * @throws ParseException 
	 */
	public static String makeDatetimeFormat(String datetime) throws ParseException {
		
		if ("".equals(StringUtils.defaultString(datetime))) {
			return "";
		}
		
		SimpleDateFormat orginFormat = new SimpleDateFormat("yyyyMMddHHmmss");
		Date orginDatetime = orginFormat.parse(datetime);
		
		SimpleDateFormat transFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		String transDatetime = transFormat.format(orginDatetime);
		
		return transDatetime;
	}
	
	/**
	 * 
	 * makeTimeFormat
	 *
	 * @param time
	 * @return String
	 * @throws ParseException 
	 */
	public static String makeTimeFormat(String time) throws ParseException {
		
		if ("".equals(StringUtils.defaultString(time))) {
			return "";
		}
		
		SimpleDateFormat orginFormat = new SimpleDateFormat("HHmmss");
		Date orginTime = orginFormat.parse(time);
		
		SimpleDateFormat transFormat = new SimpleDateFormat("HH:mm:ss");
		String transTime = transFormat.format(orginTime);
		
		return transTime;
	}
	
	/**
	 * 
	 * makeDateHourminuteFormat
	 *
	 * @param dateHourminute
	 * @return String
	 * @throws ParseException 
	 */
	public static String makeDateHourminuteFormat(String dateHourminute) throws ParseException {
		
		if ("".equals(StringUtils.defaultString(dateHourminute))) {
			return "";
		}
		
		SimpleDateFormat orginFormat = new SimpleDateFormat("yyyyMMddHHmm");
		Date orginDateHourminute = orginFormat.parse(dateHourminute);
		
		SimpleDateFormat transFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm");
		String transDateHourminute = transFormat.format(orginDateHourminute);
		
		return transDateHourminute;
	}
	
	/**
	 * 
	 * makeDatetimeToDateFormat
	 *
	 * @param datetime
	 * @return String
	 * @throws ParseException 
	 */
	public static String makeDatetimeToDateFormat(String datetime) throws ParseException {
		
		if ("".equals(StringUtils.defaultString(datetime))) {
			return "";
		}
		
		SimpleDateFormat orginFormat = new SimpleDateFormat("yyyyMMddHHmmss");
		Date orginDatetime = orginFormat.parse(datetime);
		
		SimpleDateFormat transFormat = new SimpleDateFormat("yyyy-MM-dd");
		String transDate = transFormat.format(orginDatetime);
		
		return transDate;
	}
	
	/**
	 * 
	 * makeDateToDateFormat
	 *
	 * @param date
	 * @return String
	 * @throws ParseException 
	 */
	public static String makeDateToDateFormat(String date) throws ParseException {
		
		if ("".equals(StringUtils.defaultString(date))) {
			return "";
		}
		
		SimpleDateFormat orginFormat = new SimpleDateFormat("yyyyMMdd");
		Date orginDate = orginFormat.parse(date);
		
		SimpleDateFormat transFormat = new SimpleDateFormat("yyyy-MM-dd");
		String transDate = transFormat.format(orginDate);
		
		return transDate;
	}
	
	/**
	 * 
	 * makeTimeGap
	 *
	 * @param startDatetime
	 * @param endDatetime
	 * @return String
	 * @throws ParseException 
	 */
	public static String makeTimeGap(String startDatetime, String endDatetime) throws ParseException {
		
		if ("".equals(StringUtils.defaultString(startDatetime)) || "".equals(StringUtils.defaultString(endDatetime))) {
			return "";
		}
		
		SimpleDateFormat inputTimeFormat = new SimpleDateFormat("yyyyMMddHHmmss", Locale.KOREA);
		Date dateStartDatetime = inputTimeFormat.parse(startDatetime);
		Date dateEndDatetime = inputTimeFormat.parse(endDatetime);
		
		long diff = dateEndDatetime.getTime() - dateStartDatetime.getTime();
		long sec = diff / 1000;
		long hour, min;
		min = sec / 60;
		hour = min / 60;
		sec = sec % 60;
		min = min % 60;
		
		StringBuilder timeBuilder = new StringBuilder();
		timeBuilder.append(String.format("%02d", hour));
		timeBuilder.append(":");
		timeBuilder.append(String.format("%02d", min));
		timeBuilder.append(":");
		timeBuilder.append(String.format("%02d", sec));
		
		return timeBuilder.toString();
	}

}
