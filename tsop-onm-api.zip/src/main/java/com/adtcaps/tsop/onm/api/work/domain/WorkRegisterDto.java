package com.adtcaps.tsop.onm.api.work.domain;

import com.adtcaps.tsop.onm.api.domain.OomWorkDto;

import lombok.Getter;
import lombok.Setter;

/**
 * 
 * <ul>
 * <li>업무 그룹명 : tsop-onm-api</li>
 * <li>서브 업무명 : com.adtcaps.tsop.onm.api.work.domain</li>
 * <li>설  명 : WorkRegisterDto.java</li>
 * <li>작성일 : 2021. 1. 27.</li>
 * <li>작성자 : jeonyb4</li>
 * </ul>
 */
@Getter
@Setter
public class WorkRegisterDto extends OomWorkDto {
	private String bldId;
	private String serviceClCd;
	
	public WorkRegisterDto() {
		this.bldId = "";
		this.serviceClCd = "";
	}

}
