package com.adtcaps.tsop.onm.api.fault.service.impl;

import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.CollectionUtils;

import com.adtcaps.tsop.onm.api.domain.OomFaultActionDto;
import com.adtcaps.tsop.onm.api.fault.domain.FaultActionGridResultDto;
import com.adtcaps.tsop.onm.api.fault.domain.FaultActionProcessingDto;
import com.adtcaps.tsop.onm.api.fault.mapper.OomFaultActionMapper;
import com.adtcaps.tsop.onm.api.fault.service.FaultActionService;
import com.adtcaps.tsop.onm.api.file.domain.BlobRequestDto;
import com.adtcaps.tsop.onm.api.file.service.FileService;
import com.adtcaps.tsop.onm.api.helper.constant.Const;
import com.adtcaps.tsop.onm.api.helper.util.CommonDateUtil;
import com.adtcaps.tsop.onm.api.helper.util.CommonObjectUtil;

/**
 * 
 * <ul>
 * <li>업무 그룹명 : tsop-onm-api</li>
 * <li>서브 업무명 : com.adtcaps.tsop.onm.api.fault.service.impl</li>
 * <li>설  명 : FaultActionServiceImpl.java</li>
 * <li>작성일 : 2021. 1. 17.</li>
 * <li>작성자 : jeonyb4</li>
 * </ul>
 */
@Transactional
@Service
public class FaultActionServiceImpl implements FaultActionService {
	
	@Autowired
	private OomFaultActionMapper oomFaultActionMapper;
	
	@Autowired
	private FileService fileService;
	
	/**
	 * 
	 * listFaultAction
	 *
	 * @param reqOomFaultActionDto
	 * @return List<FaultActionGridResultDto>
	 * @throws Exception 
	 */
	@Override
	public List<FaultActionGridResultDto> listFaultAction(OomFaultActionDto reqOomFaultActionDto) throws Exception {
		
		List<FaultActionGridResultDto> faultActionGridResultDtoList = null;
		try {
			faultActionGridResultDtoList = oomFaultActionMapper.listFaultAction(reqOomFaultActionDto);
			if (!CollectionUtils.isEmpty(faultActionGridResultDtoList)) {
    			for (int idx = 0; idx < faultActionGridResultDtoList.size(); idx++) {
    				
    				FaultActionGridResultDto faultActionGridResultDto = faultActionGridResultDtoList.get(idx);
    				
    				String faultOccrActionDatetime = StringUtils.defaultString(faultActionGridResultDto.getFaultOccrActionDatetime());
    				faultOccrActionDatetime = CommonDateUtil.makeDatetimeFormat(faultOccrActionDatetime);
    				faultActionGridResultDto.setFaultOccrActionDatetime(faultOccrActionDatetime);
    				
    				faultActionGridResultDtoList.set(idx, faultActionGridResultDto);
    			}
    		}
			
		} catch (Exception e) {
			throw e;
		}
		return faultActionGridResultDtoList;
	}
	
	/**
	 * 
	 * createFaultAction
	 *
	 * @param reqFaultActionProcessingDto
	 * @return int
	 * @throws Exception 
	 */
	@Override
	public int createFaultAction(FaultActionProcessingDto reqFaultActionProcessingDto) throws Exception {
		
		int affectRowCount = 0;
		
		try {
			OomFaultActionDto reqOomFaultActionDto = reqFaultActionProcessingDto.getFaultActionInfo();
			BlobRequestDto blobRequestDto = reqFaultActionProcessingDto.getAttachFile();
			if (blobRequestDto != null) {
				blobRequestDto.setContainerName(Const.Definition.BLOB_CONTAINER.FILE);
				blobRequestDto.setBlobBaseDir(Const.Definition.BLOB_BASEDIR.FAULT);
				int attachFileNum = fileService.createAttachFile(blobRequestDto);
				if (attachFileNum > 0) {
					reqOomFaultActionDto.setAttachFileNum(attachFileNum);
				}
			}
			
			// 장애조치내역 등록...
			int insertRow = oomFaultActionMapper.createOomFaultAction(reqOomFaultActionDto);
			affectRowCount = affectRowCount + insertRow;
			
		} catch (Exception e) {
			throw e;
		}
		
		return affectRowCount;
	}
	
	/**
	 * 
	 * deleteFaultActionAttachFile
	 *
	 * @param reqOomFaultActionDto
	 * @return int
	 * @throws Exception 
	 */
	@Override
	public int deleteFaultActionAttachFile(OomFaultActionDto reqOomFaultActionDto) throws Exception {
		
		int affectRowCount = 0;
		
		try {
			int attachFileNum = reqOomFaultActionDto.getAttachFileNum();
			// 첨부파일 삭제
			int deleteRow = fileService.deleteAttachFile(Const.Definition.BLOB_CONTAINER.FILE, attachFileNum);
			affectRowCount = affectRowCount + deleteRow;
			// 장애조치내역의 첨부파일번호 Null update
			reqOomFaultActionDto.setAttachFileNum(null);
			int updateRow = oomFaultActionMapper.updateFaultActionAttachFileNum(reqOomFaultActionDto);
			affectRowCount = affectRowCount + updateRow;
			
		} catch (Exception e) {
			throw e;
		}
		return affectRowCount;
	}
	
	/**
	 * 
	 * deleteFaultAction
	 *
	 * @param reqOomFaultActionDto
	 * @return int
	 * @throws Exception 
	 */
	@Override
	public int deleteFaultAction(OomFaultActionDto reqOomFaultActionDto) throws Exception {
		
		int affectRowCount = 0;
		
		try {
			int attachFileNum = CommonObjectUtil.defaultNumber(reqOomFaultActionDto.getAttachFileNum());
			if (attachFileNum > 0) {
				// 첨부파일 삭제
				int deleteRow = fileService.deleteAttachFile(Const.Definition.BLOB_CONTAINER.FILE, attachFileNum);
				affectRowCount = affectRowCount + deleteRow;
			}
			// 장애조치내역 삭제...
			int deleteRow = oomFaultActionMapper.deleteOomFaultAction(reqOomFaultActionDto);
			affectRowCount = affectRowCount + deleteRow;
			
		} catch (Exception e) {
			throw e;
		}
		
		return affectRowCount;
	}

}
