package com.adtcaps.tsop.onm.api.alimTalk.domain;

import java.util.List;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class AlimTalkRequestDto {
	private String tenantId;
	private String message;
	private String tmpltCode;
	private String recipient;
	private String rcverName;
	private String smsCreateCd;
	private Integer alarmNoticeGroupId;
	private String bulletinTypeCd;
	private Integer bulletinNum;
	private String auditId;
	private String attach;
	private String attachName;
	private String tenantName;
	private List<AlimTalkDetailDto> detailList;
}
