package com.adtcaps.tsop.onm.api.card.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;

import com.adtcaps.tsop.onm.api.card.domain.TenantDashboardCardDetailResultDto;
import com.adtcaps.tsop.onm.api.card.domain.TenantDashboardCardGridRequestDto;
import com.adtcaps.tsop.onm.api.card.domain.TenantDashboardCardGridResultDto;
import com.adtcaps.tsop.onm.api.domain.OomTenantDashboardCardDto;

/**
 * 
 * <ul>
 * <li>업무 그룹명 : tsop-onm-api</li>
 * <li>서브 업무명 : com.adtcaps.tsop.onm.api.card.mapper</li>
 * <li>설  명 : OomTenantDashboardCardMapper.java</li>
 * <li>작성일 : 2021. 1. 11.</li>
 * <li>작성자 : jeonyb4</li>
 * </ul>
 */
@Mapper
public interface OomTenantDashboardCardMapper {
	/**
	 * 
	 * listPageTenantDashboardCard
	 *
	 * @param tenantDashboardCardGridRequestDto
	 * @return List<TenantDashboardCardGridResultDto>
	 */
	public List<TenantDashboardCardGridResultDto> listPageTenantDashboardCard(TenantDashboardCardGridRequestDto tenantDashboardCardGridRequestDto);
	
	/**
	 * 
	 * createOomTenantDashboardCard
	 *
	 * @param reqOomTenantDashboardCardDto
	 * @return int
	 */
	public int createOomTenantDashboardCard(OomTenantDashboardCardDto reqOomTenantDashboardCardDto);
	
	/**
	 * 
	 * readOomTenantDashboardCard
	 *
	 * @param reqOomTenantDashboardCardDto
	 * @return TenantDashboardCardDetailResultDto
	 */
	public TenantDashboardCardDetailResultDto readOomTenantDashboardCard(OomTenantDashboardCardDto reqOomTenantDashboardCardDto);
	
	/**
	 * 
	 * updateOomTenantDashboardCard
	 *
	 * @param reqOomTenantDashboardCardDto
	 * @return int
	 */
	public int updateOomTenantDashboardCard(OomTenantDashboardCardDto reqOomTenantDashboardCardDto);
	
	/**
	 * 
	 * deleteOomTenantDashboardCard
	 *
	 * @param reqOomTenantDashboardCardDto
	 * @return int
	 */
	public int deleteOomTenantDashboardCard(OomTenantDashboardCardDto reqOomTenantDashboardCardDto);
	
	/**
	 * 
	 * readTTenantDashboardCardSameCardNameCount
	 *
	 * @param reqOomTenantDashboardCardDto
	 * @return int
	 */
	public int readTTenantDashboardCardSameCardNameCount(OomTenantDashboardCardDto reqOomTenantDashboardCardDto);

}
