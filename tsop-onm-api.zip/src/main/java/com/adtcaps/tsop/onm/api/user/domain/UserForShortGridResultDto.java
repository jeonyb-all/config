package com.adtcaps.tsop.onm.api.user.domain;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

import lombok.Getter;
import lombok.Setter;

/**
 * 
 * <ul>
 * <li>업무 그룹명 : tsop-onm-api</li>
 * <li>서브 업무명 : com.adtcaps.tsop.onm.api.user.domain</li>
 * <li>설  명 : UserForShortGridResultDto.java</li>
 * <li>작성일 : 2021. 1. 4.</li>
 * <li>작성자 : jeonyb4</li>
 * </ul>
 */
@Getter
@Setter
@JsonInclude(Include.NON_EMPTY)
public class UserForShortGridResultDto {
	private String userId;
	private String userName;
	private String contactPhoneNum;
	private String emailAddr;
	private String mgrYn;
	private String serviceOperYn;
	private String tenantId;
	private String tenantName;

}
