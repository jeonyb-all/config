package com.adtcaps.tsop.onm.api.sms.controller;

import com.adtcaps.tsop.onm.api.sms.service.SmsAccessInformationService;
import com.adtcaps.tsop.onm.api.sms.service.SmsService;

import com.adtcaps.tsop.onm.api.config.TenantConfig;
import com.adtcaps.tsop.onm.api.helper.constant.Const;
import com.adtcaps.tsop.onm.api.helper.domain.ResultDto;
import com.adtcaps.tsop.onm.api.sms.domain.SmsApiResponse;
import com.adtcaps.tsop.onm.api.sms.domain.SmsRequestDto;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;

import java.util.HashMap;
import java.util.Map;

import javax.annotation.PostConstruct;

/**
 * Command API Controller
 *
 * @author zeal77@sk.com
 */
@RestController
@RequestMapping("/api/server/sms")
public class SmsController {
	
	private final String ERR_MSG_NULL_KEY = "Key값이 없습니다.";
	private final String ERR_MSG_NULL_SMS_SEND_INFO = "SMS발송정보가 없습니다.";
	
	private final String ERR_MSG_KEY_AUTH_FAIL = "Key 인증에 실패하였습니다.";
	private final String ERR_MSG_SMS_SEND_FAIL = "SMS 발송에 실패하였습니다. 잠시 후 다시 시도해주세요";
	
    /**
     * AuthenticationService.
     */
    @Autowired
    SmsAccessInformationService smsAccessInformationService;

    /**
     * SMS Service
     */
    @Autowired
    SmsService smsService;
    
    @Autowired
	private TenantConfig tenantConfig;

    @PostConstruct
    public void init() {
        smsAccessInformationService.initAccessInformation();
    }

    /**
     * SMS 전송
     *
     * @param command 제어 명령 값
     * @param request HttpServletRequest 객체
     * @return TsoEventResponse
     */
    @SuppressWarnings("rawtypes")
    @PostMapping(value = "/notices", produces="application/json; charset=UTF-8")
    public ResponseEntity sendSms(@RequestBody SmsRequestDto smsRequestDto, HttpServletRequest request) throws Exception {
    	
    	ResponseEntity<ResultDto> resEntity = null;
		String returnString = "";
		
		String callKey = StringUtils.defaultString(request.getHeader("Call-Key"));
		String key = StringUtils.defaultString(tenantConfig.getMyServerInfo().getKey());
		if ("".equals(callKey) || "".equals(key)) {
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_KEY));
			return resEntity;
		}
		if (!callKey.equals(key)) {
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_KEY_AUTH_FAIL));
			return resEntity;
		}
		if (smsRequestDto == null) {
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_SMS_SEND_INFO));
			return resEntity;
		}
		
		String recvNo = StringUtils.defaultString(smsRequestDto.getRecvNo());
		String msg = StringUtils.defaultString(smsRequestDto.getMsg());
		
		Map<String, Object> smsContent = new HashMap<String, Object>();
		smsContent.put("recv_no", recvNo);
		smsContent.put("msg", msg);
		SmsApiResponse smsApiResponse = smsService.sendSms(smsContent);
		if (smsApiResponse == null) {
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_SMS_SEND_FAIL, smsApiResponse));
		} else {
			String returnCode = smsApiResponse.getReturnCode();
			String errorCode = smsApiResponse.getErrorCode();
			if ("01".equals(returnCode)) {
				returnString = Const.Common.RESULT_CODE.SUCCESS;
    			resEntity = ResponseEntity.ok(new ResultDto(returnString, "", smsApiResponse));
			} else {
				if( "80".equals(errorCode) ) {	// error_msg=No user information, error_code=80
					returnString = Const.Common.RESULT_CODE.FAIL;
					resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_SMS_SEND_FAIL, smsApiResponse));
				} else if( "99".equals(errorCode) ) {	// error_msg=Authentication failed, error_code=99
					returnString = Const.Common.RESULT_CODE.FAIL;
					resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_SMS_SEND_FAIL, smsApiResponse));
				} else {
					returnString = Const.Common.RESULT_CODE.FAIL;
					resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_SMS_SEND_FAIL, smsApiResponse));
				}
			}
		}
    	
    	return resEntity;
    }

}
