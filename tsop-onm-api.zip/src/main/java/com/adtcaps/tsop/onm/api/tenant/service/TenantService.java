package com.adtcaps.tsop.onm.api.tenant.service;

import java.util.List;

import com.adtcaps.tsop.onm.api.domain.OomTenantDto;
import com.adtcaps.tsop.onm.api.helper.domain.BasePageDto;
import com.adtcaps.tsop.onm.api.tenant.domain.TenantDetailResultDto;
import com.adtcaps.tsop.onm.api.tenant.domain.TenantForComboResultDto;
import com.adtcaps.tsop.onm.api.tenant.domain.TenantForShortGridResultDto;
import com.adtcaps.tsop.onm.api.tenant.domain.TenantGridResultDto;

/**
 * 
 * <ul>
 * <li>업무 그룹명 : tsop-onm-api</li>
 * <li>서브 업무명 : com.adtcaps.tsop.onm.api.tenant.service</li>
 * <li>설  명 : TenantService.java</li>
 * <li>작성일 : 2021. 1. 6.</li>
 * <li>작성자 : jeonyb4</li>
 * </ul>
 */
public interface TenantService {
	/**
	 * 
	 * listTenantForCombo
	 *
	 * @return List<TenantForComboResultDto>
	 * @throws Exception 
	 */
	public List<TenantForComboResultDto> listTenantForCombo() throws Exception;
	
	/**
	 * 
	 * listTenantForWorkForCombo
	 *
	 * @return List<TenantForComboResultDto>
	 * @throws Exception 
	 */
	public List<TenantForComboResultDto> listTenantForWorkForCombo() throws Exception;
	
	/**
	 * 
	 * listTenantForShortGrid
	 *
	 * @param reqBasePageDto
	 * @return List<TenantForShortGridResultDto>
	 * @throws Exception 
	 */
	public List<TenantForShortGridResultDto> listTenantForShortGrid(BasePageDto reqBasePageDto) throws Exception;
	
	/**
	 * 
	 * listPageTenant
	 *
	 * @param reqBasePageDto
	 * @return List<TenantGridResultDto>
	 * @throws Exception 
	 */
	public List<TenantGridResultDto> listPageTenant(BasePageDto reqBasePageDto) throws Exception;
	
	/**
	 * 
	 * readTenant
	 *
	 * @param reqOomTenantDto
	 * @return TenantDetailResultDto
	 * @throws Exception 
	 */
	public TenantDetailResultDto readTenant(OomTenantDto reqOomTenantDto) throws Exception;
	
	/**
	 * 
	 * readTenantForWork
	 *
	 * @param reqOomTenantDto
	 * @return OomTenantDto
	 * @throws Exception 
	 */
	public OomTenantDto readTenantForWork(OomTenantDto reqOomTenantDto) throws Exception;

}
