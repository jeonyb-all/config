package com.adtcaps.tsop.onm.api.file.service;

import com.adtcaps.tsop.onm.api.domain.OomAttachFileDto;
import com.adtcaps.tsop.onm.api.file.domain.BlobRequestDto;
import com.adtcaps.tsop.onm.api.file.domain.BlobResultDto;

/**
 * 
 * <ul>
 * <li>업무 그룹명 : tsop-onm-api</li>
 * <li>서브 업무명 : com.adtcaps.tsop.onm.api.file.service</li>
 * <li>설  명 : FileService.java</li>
 * <li>작성일 : 2021. 1. 2.</li>
 * <li>작성자 : jeonyb4</li>
 * </ul>
 */
public interface FileService {
	/**
	 * 
	 * readAttachFile
	 *
	 * @param reqOomAttachFileDto
	 * @return OomAttachFileDto
	 * @throws Exception 
	 */
	public OomAttachFileDto readAttachFile(OomAttachFileDto reqOomAttachFileDto) throws Exception;
	
	/**
	 * 
	 * createAttachFile
	 *
	 * @param blobRequestDto
	 * @return int
	 * @throws Exception 
	 */
	public int createAttachFile(BlobRequestDto blobRequestDto) throws Exception;
	
	/**
	 * 
	 * createRemoteAttachFile
	 *
	 * @param blobRequestDto
	 * @return int
	 * @throws Exception 
	 */
	public int createRemoteAttachFile(BlobRequestDto blobRequestDto) throws Exception;
	
	/**
	 * 
	 * uploadFile
	 *
	 * @param blobRequestDto
	 * @return BlobResultDto
	 * @throws Exception 
	 */
	public BlobResultDto uploadFile(BlobRequestDto blobRequestDto) throws Exception;
	
	/**
	 * 
	 * deleteAttachFile
	 *
	 * @param containerName
	 * @param attachFileNum
	 * @return int
	 * @throws Exception 
	 */
	public int deleteAttachFile(String containerName, int attachFileNum) throws Exception;
	
	/**
	 * 
	 * downloadFile
	 *
	 * @param blobRequestDto
	 * @return BlobResultDto
	 * @throws Exception 
	 */
	public BlobResultDto downloadFile(BlobRequestDto blobRequestDto) throws Exception;

}
