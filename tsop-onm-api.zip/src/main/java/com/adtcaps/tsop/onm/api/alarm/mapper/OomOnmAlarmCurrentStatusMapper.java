package com.adtcaps.tsop.onm.api.alarm.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;

import com.adtcaps.tsop.onm.api.alarm.domain.AlarmCurrentStatusDetailResultDto;
import com.adtcaps.tsop.onm.api.alarm.domain.AlarmCurrentStatusGridRequestDto;
import com.adtcaps.tsop.onm.api.alarm.domain.AlarmCurrentStatusGridResultDto;
import com.adtcaps.tsop.onm.api.dashboard.domain.DashboardAlarmCountResultDto;
import com.adtcaps.tsop.onm.api.dashboard.domain.DashboardRequestDto;
import com.adtcaps.tsop.onm.api.domain.OomOnmAlarmCurrentStatusDto;

/**
 * 
 * <ul>
 * <li>업무 그룹명 : tsop-onm-api</li>
 * <li>서브 업무명 : com.adtcaps.tsop.onm.api.alarm.mapper</li>
 * <li>설  명 : OomOnmAlarmCurrentStatusMapper.java</li>
 * <li>작성일 : 2021. 2. 6.</li>
 * <li>작성자 : jeonyb4</li>
 * </ul>
 */
@Mapper
public interface OomOnmAlarmCurrentStatusMapper {
	/**
	 * 
	 * listPageAlarmCurrentStatus
	 *
	 * @param alarmNoticeConditionGridRequestDto
	 * @return List<AlarmCurrentStatusGridResultDto>
	 */
	public List<AlarmCurrentStatusGridResultDto> listPageAlarmCurrentStatus(AlarmCurrentStatusGridRequestDto alarmNoticeConditionGridRequestDto);
	
	/**
	 * 
	 * readAlarmCurrentStatus
	 *
	 * @param reqOomOnmAlarmCurrentStatusDto
	 * @return AlarmCurrentStatusDetailResultDto
	 */
	public AlarmCurrentStatusDetailResultDto readAlarmCurrentStatus(OomOnmAlarmCurrentStatusDto reqOomOnmAlarmCurrentStatusDto);
	
	/**
	 * 
	 * updateOomOnmAlarmCurrentStatus
	 *
	 * @param updateOomOnmAlarmCurrentStatus
	 * @return int
	 */
	public int updateOomOnmAlarmCurrentStatus(OomOnmAlarmCurrentStatusDto reqOomOnmAlarmCurrentStatusDto);
	
	/*************************** Dashboard ********************************/
	public List<DashboardAlarmCountResultDto> listDashboardTenantAlarm(DashboardRequestDto reqDashboardDto);
	public List<DashboardAlarmCountResultDto> listDashboardResourceAlarm(DashboardRequestDto reqDashboardDto);
	public List<DashboardAlarmCountResultDto> listDashboardBuildingAlarm(DashboardRequestDto reqDashboardDto);
	public List<DashboardAlarmCountResultDto> listDashboardServiceAlarm(DashboardRequestDto reqDashboardDto);

}
