package com.adtcaps.tsop.onm.api.alarm.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.util.CollectionUtils;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.adtcaps.tsop.onm.api.alarm.domain.AlarmNoticeConditionDetailResultDto;
import com.adtcaps.tsop.onm.api.alarm.domain.AlarmNoticeConditionGridRequestDto;
import com.adtcaps.tsop.onm.api.alarm.domain.AlarmNoticeConditionGridResultDto;
import com.adtcaps.tsop.onm.api.alarm.service.AlarmNoticeService;
import com.adtcaps.tsop.onm.api.authentication.domain.JwtAuthResultDto;
import com.adtcaps.tsop.onm.api.domain.OomAlarmNoticeConditionDto;
import com.adtcaps.tsop.onm.api.domain.OomUserRoleAuthorityDetailDto;
import com.adtcaps.tsop.onm.api.helper.constant.Const;
import com.adtcaps.tsop.onm.api.helper.domain.ResultDto;
import com.adtcaps.tsop.onm.api.helper.util.CommonObjectUtil;
import com.adtcaps.tsop.onm.api.helper.util.PageUtil;
import com.adtcaps.tsop.onm.api.user.domain.UserRoleMenuAuthorityRequestDto;
import com.adtcaps.tsop.onm.api.user.service.UserRoleService;

import lombok.extern.slf4j.Slf4j;

/**
 * 
 * <ul>
 * <li>업무 그룹명 : tsop-onm-api</li>
 * <li>서브 업무명 : com.adtcaps.tsop.onm.api.alarm.controller</li>
 * <li>설  명 : AlarmNoticeController.java</li>
 * <li>작성일 : 2021. 1. 17.</li>
 * <li>작성자 : jeonyb4</li>
 * </ul>
 */
@Slf4j
@RestController
@RequestMapping("/api/alarm-notices")
public class AlarmNoticeController {
	
	private final String MENU_ID = "ONM0011";
	
	private final String ERR_MSG_NULL_LOGIN_USER_ID = "로그인 사용자ID가 없습니다.";
	private final String ERR_MSG_NULL_PAGE_NUMBER = "페이지 번호가 없습니다.";
	private final String ERR_MSG_NULL_TENANT_ID = "테넌트ID가 없습니다.";
	private final String ERR_MSG_NULL_RESOURCE_CATEGORY_CD = "자원분류코드가 없습니다.";
	private final String ERR_MSG_NULL_ALARM_CD = "알람코드가 없습니다.";
	private final String ERR_MSG_NULL_ALARM_GRADE_CD = "알람등급코드가 없습니다.";
	private final String ERR_MSG_NULL_ALARM_NOTICE_GROUP_ID = "알람통지그룹ID가 없습니다.";
	private final String ERR_MSG_NULL_MGR_YN = "관리자여부가 없습니다.";
	
	private final String ERR_MSG_ALREADY_EXIST_ALARM_NOTICE_CONDITION = "해당 빌딩의 서비스에 대한 알람등급에 이미 등록된 정보가 있습니다.";
	
	private final String ERR_MSG_NO_AUTH = "권한이 없는 사용자 입니다.";
	private final String ERR_MSG_NULL_SEARCH_RESULT_LIST = "조회 결과가 없습니다.";
	private final String ERR_MSG_CREATE_FAIL = "등록에 실패하였습니다.";
	private final String ERR_MSG_READ_FAIL = "조회에 실패하였습니다.";
	private final String ERR_MSG_UPDATE_FAIL = "수정에 실패하였습니다.";
	private final String ERR_MSG_DELETE_FAIL = "삭제에 실패하였습니다.";
	
	@Autowired
	private AlarmNoticeService alarmNoticeService;
	
	@Autowired
	private UserRoleService userRoleService;
	
	/**
	 * 
	 * listPageAlarmNoticeCondition
	 *
	 * @param alarmNoticeConditionGridRequestDto
	 * @return ResponseEntity
	 */
	@SuppressWarnings("rawtypes")
    @GetMapping(value="", produces="application/json; charset=UTF-8")
    public ResponseEntity listPageAlarmNoticeCondition(AlarmNoticeConditionGridRequestDto alarmNoticeConditionGridRequestDto) throws Exception {
        
    	ResponseEntity<ResultDto> resEntity = null;
		String returnString = "";
    	
		int pageNumber = alarmNoticeConditionGridRequestDto.getPageNumber();
		if (pageNumber < 1) {
			log.error(">>>>>> pageNumber ERROR:{}", ERR_MSG_NULL_PAGE_NUMBER);
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_PAGE_NUMBER));
			return resEntity;
		}
		// 알람통지조건 목록 조회....
		Map<String, Object> alarmNoticeConditionGridResultDtoListMap = new HashMap<String, Object>();
		List<AlarmNoticeConditionGridResultDto> alarmNoticeConditionGridResultDtoList = alarmNoticeService.listPageAlarmNoticeCondition(alarmNoticeConditionGridRequestDto);
		if (CollectionUtils.isEmpty(alarmNoticeConditionGridResultDtoList)) {
			returnString = Const.Common.RESULT_CODE.SUCCESS;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_SEARCH_RESULT_LIST, alarmNoticeConditionGridResultDtoListMap));
		} else {
			returnString = Const.Common.RESULT_CODE.SUCCESS;
			alarmNoticeConditionGridResultDtoListMap.put(Const.Definition.PAGE.PAGER, PageUtil.getPageInfo(alarmNoticeConditionGridResultDtoList));
			alarmNoticeConditionGridResultDtoListMap.put(Const.Definition.PAGE.LISTS, alarmNoticeConditionGridResultDtoList);
			resEntity = ResponseEntity.ok(new ResultDto(returnString, "", alarmNoticeConditionGridResultDtoListMap));
		}
    	
    	return resEntity;
    }
	
	/**
	 * 
	 * createAlarmNoticeCondition
	 *
	 * @param reqOomAlarmNoticeConditionDto
	 * @return ResponseEntity
	 */
	@SuppressWarnings("rawtypes")
    @PostMapping(value="", produces="application/json; charset=UTF-8")
    public ResponseEntity createAlarmNoticeCondition(@AuthenticationPrincipal JwtAuthResultDto authResultDto, 
    		@RequestBody OomAlarmNoticeConditionDto reqOomAlarmNoticeConditionDto) throws Exception {
        
    	ResponseEntity<ResultDto> resEntity = null;
		String returnString = "";
    	
		String loginUserId = StringUtils.defaultString(authResultDto.getUserId());
		if ("".equals(loginUserId)) {
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_LOGIN_USER_ID));
			return resEntity;
		}
		String mgrYn = StringUtils.defaultString(authResultDto.getMgrYn());
		if ("".equals(mgrYn)) {
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_MGR_YN));
			return resEntity;
		}
		//String loginUserId = "tsop-admin"; // 이후 세션에서 얻어올 값...
		
		if (!"Y".equals(mgrYn)) {
			String authorityTypeCd = "";
			UserRoleMenuAuthorityRequestDto userRoleMenuAuthorityRequestDto = new UserRoleMenuAuthorityRequestDto();
			userRoleMenuAuthorityRequestDto.setUserId(loginUserId);
			userRoleMenuAuthorityRequestDto.setMenuId(MENU_ID);
			OomUserRoleAuthorityDetailDto rsltOomUserRoleAuthorityDetailDto = userRoleService.readMenuAuthority(userRoleMenuAuthorityRequestDto);
			if (rsltOomUserRoleAuthorityDetailDto != null) {
				authorityTypeCd = StringUtils.defaultString(rsltOomUserRoleAuthorityDetailDto.getAuthorityTypeCd());
			}
			if (!"W".equals(authorityTypeCd)) {
				returnString = Const.Common.RESULT_CODE.FAIL;
				resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NO_AUTH));
				return resEntity;
			}
		}
		
		String tenantId = StringUtils.defaultString(reqOomAlarmNoticeConditionDto.getTenantId());
		if ("".equals(tenantId)) {
			log.error(">>>>>> tenantId ERROR:{}", ERR_MSG_NULL_TENANT_ID);
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_TENANT_ID));
			return resEntity;
		}
		String onmResourceCategoryCd = StringUtils.defaultString(reqOomAlarmNoticeConditionDto.getOnmResourceCategoryCd());
		if ("".equals(onmResourceCategoryCd)) {
			log.error(">>>>>> onmResourceCategoryCd ERROR:{}", ERR_MSG_NULL_RESOURCE_CATEGORY_CD);
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_RESOURCE_CATEGORY_CD));
			return resEntity;
		}
		String onmAlarmCd = StringUtils.defaultString(reqOomAlarmNoticeConditionDto.getOnmAlarmCd());
		if ("".equals(onmAlarmCd)) {
			log.error(">>>>>> onmAlarmCd ERROR:{}", ERR_MSG_NULL_ALARM_CD);
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_ALARM_CD));
			return resEntity;
		}
		String onmAlarmGradeCd = StringUtils.defaultString(reqOomAlarmNoticeConditionDto.getOnmAlarmGradeCd());
		if ("".equals(onmAlarmGradeCd)) {
			log.error(">>>>>> onmAlarmGradeCd ERROR:{}", ERR_MSG_NULL_ALARM_GRADE_CD);
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_ALARM_GRADE_CD));
			return resEntity;
		}
		int alarmNoticeGroupId = CommonObjectUtil.defaultNumber(reqOomAlarmNoticeConditionDto.getAlarmNoticeGroupId());
		if (alarmNoticeGroupId < 1) {
			log.error(">>>>>> alarmNoticeGroupId ERROR:{}", ERR_MSG_NULL_ALARM_NOTICE_GROUP_ID);
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_ALARM_NOTICE_GROUP_ID));
			return resEntity;
		}
		
		reqOomAlarmNoticeConditionDto.setRegisterId(loginUserId);
		reqOomAlarmNoticeConditionDto.setAuditId(loginUserId);
		
		// 중복 등록 체크...
		OomAlarmNoticeConditionDto rsltOomAlarmNoticeConditionDto = alarmNoticeService.readAlarmNoticeDuplicationCheck(reqOomAlarmNoticeConditionDto);
		if (rsltOomAlarmNoticeConditionDto != null) {
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_ALREADY_EXIST_ALARM_NOTICE_CONDITION));
			return resEntity;
		}
		
		// 알람통지조건목록 등록...
		int affectRowCount = alarmNoticeService.createAlarmNoticeCondition(reqOomAlarmNoticeConditionDto);
		if (affectRowCount < 1) {
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_CREATE_FAIL, affectRowCount));
		} else {
			returnString = Const.Common.RESULT_CODE.SUCCESS;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, "", affectRowCount));
		}
    	
    	return resEntity;
    }
	
	/**
	 * 
	 * readAlarmNoticeCondition
	 *
	 * @param alarmNoticeCondSeq
	 * @param reqOomAlarmNoticeConditionDto
	 * @return ResponseEntity
	 */
	@SuppressWarnings("rawtypes")
    @GetMapping(value="/{alarmNoticeCondSeq}", produces="application/json; charset=UTF-8")
    public ResponseEntity readAlarmNoticeCondition(@PathVariable("alarmNoticeCondSeq") int alarmNoticeCondSeq, OomAlarmNoticeConditionDto reqOomAlarmNoticeConditionDto) throws Exception {
        
    	ResponseEntity<ResultDto> resEntity = null;
		String returnString = "";
    	
		String tenantId = StringUtils.defaultString(reqOomAlarmNoticeConditionDto.getTenantId());
		if ("".equals(tenantId)) {
			log.error(">>>>>> tenantId ERROR:{}", ERR_MSG_NULL_TENANT_ID);
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_TENANT_ID));
			return resEntity;
		}
		
		reqOomAlarmNoticeConditionDto.setAlarmNoticeCondSeq(alarmNoticeCondSeq);
		
		AlarmNoticeConditionDetailResultDto alarmNoticeConditionDetailResultDto = alarmNoticeService.readAlarmNoticeCondition(reqOomAlarmNoticeConditionDto);
		if (alarmNoticeConditionDetailResultDto == null) {
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_READ_FAIL, alarmNoticeConditionDetailResultDto));
		} else {
			returnString = Const.Common.RESULT_CODE.SUCCESS;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, "", alarmNoticeConditionDetailResultDto));
		}
    	
    	return resEntity;
    }
	
	/**
	 * 
	 * updateAlarmNoticeCondition
	 *
	 * @param alarmNoticeCondSeq
	 * @param reqOomAlarmNoticeConditionDto
	 * @return ResponseEntity
	 */
	@SuppressWarnings("rawtypes")
    @PutMapping(value="/{alarmNoticeCondSeq}", produces="application/json; charset=UTF-8")
    public ResponseEntity updateAlarmNoticeCondition(@AuthenticationPrincipal JwtAuthResultDto authResultDto, 
    		@PathVariable("alarmNoticeCondSeq") int alarmNoticeCondSeq, @RequestBody OomAlarmNoticeConditionDto reqOomAlarmNoticeConditionDto) throws Exception {
        
    	ResponseEntity<ResultDto> resEntity = null;
		String returnString = "";
    	
		String loginUserId = StringUtils.defaultString(authResultDto.getUserId());
		if ("".equals(loginUserId)) {
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_LOGIN_USER_ID));
			return resEntity;
		}
		String mgrYn = StringUtils.defaultString(authResultDto.getMgrYn());
		if ("".equals(mgrYn)) {
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_MGR_YN));
			return resEntity;
		}
		//String loginUserId = "tsop-admin"; // 이후 세션에서 얻어올 값...
		
		if (!"Y".equals(mgrYn)) {
			String authorityTypeCd = "";
			UserRoleMenuAuthorityRequestDto userRoleMenuAuthorityRequestDto = new UserRoleMenuAuthorityRequestDto();
			userRoleMenuAuthorityRequestDto.setUserId(loginUserId);
			userRoleMenuAuthorityRequestDto.setMenuId(MENU_ID);
			OomUserRoleAuthorityDetailDto rsltOomUserRoleAuthorityDetailDto = userRoleService.readMenuAuthority(userRoleMenuAuthorityRequestDto);
			if (rsltOomUserRoleAuthorityDetailDto != null) {
				authorityTypeCd = StringUtils.defaultString(rsltOomUserRoleAuthorityDetailDto.getAuthorityTypeCd());
			}
			if (!"W".equals(authorityTypeCd)) {
				returnString = Const.Common.RESULT_CODE.FAIL;
				resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NO_AUTH));
				return resEntity;
			}
		}
		
		String tenantId = StringUtils.defaultString(reqOomAlarmNoticeConditionDto.getTenantId());
		if ("".equals(tenantId)) {
			log.error(">>>>>> tenantId ERROR:{}", ERR_MSG_NULL_TENANT_ID);
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_TENANT_ID));
			return resEntity;
		}
		String onmResourceCategoryCd = StringUtils.defaultString(reqOomAlarmNoticeConditionDto.getOnmResourceCategoryCd());
		if ("".equals(onmResourceCategoryCd)) {
			log.error(">>>>>> onmResourceCategoryCd ERROR:{}", ERR_MSG_NULL_RESOURCE_CATEGORY_CD);
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_RESOURCE_CATEGORY_CD));
			return resEntity;
		}
		String onmAlarmCd = StringUtils.defaultString(reqOomAlarmNoticeConditionDto.getOnmAlarmCd());
		if ("".equals(onmAlarmCd)) {
			log.error(">>>>>> onmAlarmCd ERROR:{}", ERR_MSG_NULL_ALARM_CD);
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_ALARM_CD));
			return resEntity;
		}
		String onmAlarmGradeCd = StringUtils.defaultString(reqOomAlarmNoticeConditionDto.getOnmAlarmGradeCd());
		if ("".equals(onmAlarmGradeCd)) {
			log.error(">>>>>> onmAlarmGradeCd ERROR:{}", ERR_MSG_NULL_ALARM_GRADE_CD);
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_ALARM_GRADE_CD));
			return resEntity;
		}
		int alarmNoticeGroupId = CommonObjectUtil.defaultNumber(reqOomAlarmNoticeConditionDto.getAlarmNoticeGroupId());
		if (alarmNoticeGroupId < 1) {
			log.error(">>>>>> alarmNoticeGroupId ERROR:{}", ERR_MSG_NULL_ALARM_NOTICE_GROUP_ID);
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_ALARM_NOTICE_GROUP_ID));
			return resEntity;
		}
		
		reqOomAlarmNoticeConditionDto.setAlarmNoticeCondSeq(alarmNoticeCondSeq);
		reqOomAlarmNoticeConditionDto.setAuditId(loginUserId);
		
		// 중복 등록 체크...
		OomAlarmNoticeConditionDto rsltOomAlarmNoticeConditionDto = alarmNoticeService.readAlarmNoticeDuplicationCheck(reqOomAlarmNoticeConditionDto);
		if (rsltOomAlarmNoticeConditionDto != null) {
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_ALREADY_EXIST_ALARM_NOTICE_CONDITION));
			return resEntity;
		}
		
		// 알람통지조건목록 수정...
		int affectRowCount = alarmNoticeService.updateAlarmNoticeCondition(reqOomAlarmNoticeConditionDto);
		if (affectRowCount < 1) {
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_UPDATE_FAIL, affectRowCount));
		} else {
			returnString = Const.Common.RESULT_CODE.SUCCESS;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, "", affectRowCount));
		}
    	
    	return resEntity;
    }
	
	/**
	 * 
	 * deleteAlarmNoticeCondition
	 *
	 * @param alarmNoticeCondSeq
	 * @param reqOomAlarmNoticeConditionDto
	 * @return ResponseEntity
	 */
	@SuppressWarnings("rawtypes")
    @DeleteMapping(value="/{alarmNoticeCondSeq}", produces="application/json; charset=UTF-8")
    public ResponseEntity deleteAlarmNoticeCondition(@AuthenticationPrincipal JwtAuthResultDto authResultDto, 
    		@PathVariable("alarmNoticeCondSeq") int alarmNoticeCondSeq, @RequestBody OomAlarmNoticeConditionDto reqOomAlarmNoticeConditionDto) throws Exception {
        
    	ResponseEntity<ResultDto> resEntity = null;
		String returnString = "";
    	
		String loginUserId = StringUtils.defaultString(authResultDto.getUserId());
		if ("".equals(loginUserId)) {
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_LOGIN_USER_ID));
			return resEntity;
		}
		String mgrYn = StringUtils.defaultString(authResultDto.getMgrYn());
		if ("".equals(mgrYn)) {
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_MGR_YN));
			return resEntity;
		}
		//String loginUserId = "tsop-admin"; // 이후 세션에서 얻어올 값...
		
		if (!"Y".equals(mgrYn)) {
			String authorityTypeCd = "";
			UserRoleMenuAuthorityRequestDto userRoleMenuAuthorityRequestDto = new UserRoleMenuAuthorityRequestDto();
			userRoleMenuAuthorityRequestDto.setUserId(loginUserId);
			userRoleMenuAuthorityRequestDto.setMenuId(MENU_ID);
			OomUserRoleAuthorityDetailDto rsltOomUserRoleAuthorityDetailDto = userRoleService.readMenuAuthority(userRoleMenuAuthorityRequestDto);
			if (rsltOomUserRoleAuthorityDetailDto != null) {
				authorityTypeCd = StringUtils.defaultString(rsltOomUserRoleAuthorityDetailDto.getAuthorityTypeCd());
			}
			if (!"W".equals(authorityTypeCd)) {
				returnString = Const.Common.RESULT_CODE.FAIL;
				resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NO_AUTH));
				return resEntity;
			}
		}
		
		String tenantId = StringUtils.defaultString(reqOomAlarmNoticeConditionDto.getTenantId());
		if ("".equals(tenantId)) {
			log.error(">>>>>> tenantId ERROR:{}", ERR_MSG_NULL_TENANT_ID);
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_TENANT_ID));
			return resEntity;
		}
		
		reqOomAlarmNoticeConditionDto.setAlarmNoticeCondSeq(alarmNoticeCondSeq);
		reqOomAlarmNoticeConditionDto.setAuditId(loginUserId);
		
		// 알람통지조건목록 삭제...
		int affectRowCount = alarmNoticeService.deleteAlarmNoticeCondition(reqOomAlarmNoticeConditionDto);
		if (affectRowCount < 1) {
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_DELETE_FAIL, affectRowCount));
		} else {
			returnString = Const.Common.RESULT_CODE.SUCCESS;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, "", affectRowCount));
		}
    	
    	return resEntity;
    }
	
	/**
	 * 
	 * updateAlarmNoticeConditionReuse
	 *
	 * @param authResultDto
	 * @param alarmNoticeCondSeq
	 * @param reqOomAlarmNoticeConditionDto
	 * @return ResponseEntity
	 * @throws Exception 
	 */
	@SuppressWarnings("rawtypes")
    @PutMapping(value="/{alarmNoticeCondSeq}/reuse", produces="application/json; charset=UTF-8")
    public ResponseEntity updateAlarmNoticeConditionReuse(@AuthenticationPrincipal JwtAuthResultDto authResultDto, 
    		@PathVariable("alarmNoticeCondSeq") int alarmNoticeCondSeq, @RequestBody OomAlarmNoticeConditionDto reqOomAlarmNoticeConditionDto) throws Exception {
        
    	ResponseEntity<ResultDto> resEntity = null;
		String returnString = "";
    	
		String loginUserId = StringUtils.defaultString(authResultDto.getUserId());
		if ("".equals(loginUserId)) {
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_LOGIN_USER_ID));
			return resEntity;
		}
		String mgrYn = StringUtils.defaultString(authResultDto.getMgrYn());
		if ("".equals(mgrYn)) {
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_MGR_YN));
			return resEntity;
		}
		//String loginUserId = "tsop-admin"; // 이후 세션에서 얻어올 값...
		
		if (!"Y".equals(mgrYn)) {
			String authorityTypeCd = "";
			UserRoleMenuAuthorityRequestDto userRoleMenuAuthorityRequestDto = new UserRoleMenuAuthorityRequestDto();
			userRoleMenuAuthorityRequestDto.setUserId(loginUserId);
			userRoleMenuAuthorityRequestDto.setMenuId(MENU_ID);
			OomUserRoleAuthorityDetailDto rsltOomUserRoleAuthorityDetailDto = userRoleService.readMenuAuthority(userRoleMenuAuthorityRequestDto);
			if (rsltOomUserRoleAuthorityDetailDto != null) {
				authorityTypeCd = StringUtils.defaultString(rsltOomUserRoleAuthorityDetailDto.getAuthorityTypeCd());
			}
			if (!"W".equals(authorityTypeCd)) {
				returnString = Const.Common.RESULT_CODE.FAIL;
				resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NO_AUTH));
				return resEntity;
			}
		}
		
		String tenantId = StringUtils.defaultString(reqOomAlarmNoticeConditionDto.getTenantId());
		if ("".equals(tenantId)) {
			log.error(">>>>>> tenantId ERROR:{}", ERR_MSG_NULL_TENANT_ID);
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_TENANT_ID));
			return resEntity;
		}
		
		reqOomAlarmNoticeConditionDto.setAlarmNoticeCondSeq(alarmNoticeCondSeq);
		reqOomAlarmNoticeConditionDto.setAuditId(loginUserId);
		
		// 중복 등록 체크...
		OomAlarmNoticeConditionDto rsltOomAlarmNoticeConditionDto = alarmNoticeService.readAlarmNoticeDuplicationCheck(reqOomAlarmNoticeConditionDto);
		if (rsltOomAlarmNoticeConditionDto != null) {
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_ALREADY_EXIST_ALARM_NOTICE_CONDITION));
			return resEntity;
		}
		
		int affectRowCount = alarmNoticeService.updateAlarmNoticeConditionReuse(reqOomAlarmNoticeConditionDto);
		if (affectRowCount < 1) {
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_UPDATE_FAIL, affectRowCount));
		} else {
			returnString = Const.Common.RESULT_CODE.SUCCESS;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, "", affectRowCount));
		}
    	
    	return resEntity;
    }

}
