package com.adtcaps.tsop.onm.api.fault.service.impl;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.CollectionUtils;

import com.adtcaps.tsop.onm.api.alarm.domain.AlarmNoticeReceiveGroupDetailDetailResultDto;
import com.adtcaps.tsop.onm.api.alarm.domain.AlarmNoticeReceiveGroupDetailResultDto;
import com.adtcaps.tsop.onm.api.alarm.service.AlarmEventService;
import com.adtcaps.tsop.onm.api.alarm.service.AlarmNoticeReceiveGroupService;
import com.adtcaps.tsop.onm.api.alimTalk.domain.AlimTalkDetailDto;
import com.adtcaps.tsop.onm.api.alimTalk.domain.AlimTalkRequestDto;
import com.adtcaps.tsop.onm.api.alimTalk.mapper.OomKakaoAlimTalkMapper;
import com.adtcaps.tsop.onm.api.alimTalk.service.AlimTalkService;
import com.adtcaps.tsop.onm.api.domain.OomAlarmNoticeReceiveGroupDto;
import com.adtcaps.tsop.onm.api.domain.OomFaultDto;
import com.adtcaps.tsop.onm.api.domain.OomKakaoAlimTalkDto;
import com.adtcaps.tsop.onm.api.fault.domain.FaultDetailResultDto;
import com.adtcaps.tsop.onm.api.fault.domain.FaultGridRequestDto;
import com.adtcaps.tsop.onm.api.fault.domain.FaultGridResultDto;
import com.adtcaps.tsop.onm.api.fault.domain.FaultProcessingDto;
import com.adtcaps.tsop.onm.api.fault.mapper.OomFaultMapper;
import com.adtcaps.tsop.onm.api.fault.service.FaultService;
import com.adtcaps.tsop.onm.api.file.domain.BlobRequestDto;
import com.adtcaps.tsop.onm.api.file.service.FileService;
import com.adtcaps.tsop.onm.api.helper.constant.Const;
import com.adtcaps.tsop.onm.api.helper.util.CommonDateUtil;
import com.adtcaps.tsop.onm.api.helper.util.CommonObjectUtil;

/**
 * 
 * <ul>
 * <li>업무 그룹명 : tsop-onm-api</li>
 * <li>서브 업무명 : com.adtcaps.tsop.onm.api.fault.service.impl</li>
 * <li>설  명 : FaultServiceImpl.java</li>
 * <li>작성일 : 2021. 1. 17.</li>
 * <li>작성자 : jeonyb4</li>
 * </ul>
 */
@Transactional
@Service
public class FaultServiceImpl implements FaultService {
	
	@Autowired
	private OomFaultMapper oomFaultMapper;
	
	@Autowired
	private FileService fileService;
	
	@Autowired
	private AlarmEventService alarmEventService;
	
	@Autowired
	private AlarmNoticeReceiveGroupService alarmNoticeReceiveGroupService;
	
	@Autowired
	private OomKakaoAlimTalkMapper oomKakaoAlimTalkMapper;
	
	@Autowired
	private AlimTalkService alimTalkService;
	
	/**
	 * 
	 * listPageFault
	 *
	 * @param faultGridRequestDto
	 * @return List<FaultGridResultDto>
	 * @throws Exception 
	 */
	@Override
	public List<FaultGridResultDto> listPageFault(FaultGridRequestDto faultGridRequestDto) throws Exception {
		
		List<FaultGridResultDto> faultGridResultDtoList = null;
		try {
			String fromDate = faultGridRequestDto.getFromDate();
    		String toDate = faultGridRequestDto.getToDate();
    		
    		fromDate = CommonDateUtil.makeFromDatetime(fromDate);
    		toDate = CommonDateUtil.makeToDatetime(toDate);
    		
    		faultGridRequestDto.setFromDate(fromDate);
    		faultGridRequestDto.setToDate(toDate);
    		
    		faultGridResultDtoList = oomFaultMapper.listPageFault(faultGridRequestDto);
    		if (!CollectionUtils.isEmpty(faultGridResultDtoList)) {
    			for (int idx = 0; idx < faultGridResultDtoList.size(); idx++) {
    				
    				FaultGridResultDto faultGridResultDto = faultGridResultDtoList.get(idx);
    				
    				String faultOccrDatetime = StringUtils.defaultString(faultGridResultDto.getFaultOccrDatetime());
    				faultOccrDatetime = CommonDateUtil.makeDatetimeFormat(faultOccrDatetime);
    				faultGridResultDto.setFaultOccrDatetime(faultOccrDatetime);
    				
    				faultGridResultDtoList.set(idx, faultGridResultDto);
    			}
    		}
    		
		} catch (Exception e) {
			throw e;
		}
		return faultGridResultDtoList;
	}
	
	/**
	 * 
	 * createFault
	 *
	 * @param reqOomFaultDto
	 * @return int
	 * @throws Exception 
	 */
	@Override
	public int createFault(FaultProcessingDto reqFaultProcessingDto) throws Exception {
		
		int affectRowCount = 0;
		
		try {
			OomFaultDto reqOomFaultDto = reqFaultProcessingDto.getFaultInfo();
			BlobRequestDto blobRequestDto = reqFaultProcessingDto.getAttachFile();
			if (blobRequestDto != null) {
				blobRequestDto.setContainerName(Const.Definition.BLOB_CONTAINER.FILE);
				blobRequestDto.setBlobBaseDir(Const.Definition.BLOB_BASEDIR.FAULT);
				int attachFileNum = fileService.createAttachFile(blobRequestDto);
				if (attachFileNum > 0) {
					reqOomFaultDto.setAttachFileNum(attachFileNum);
				}
			}
			
			String tenantId = StringUtils.defaultString(reqOomFaultDto.getTenantId());
			String auditId = StringUtils.defaultString(reqOomFaultDto.getAuditId());
			
			// 장애 등록...
			int insertRow = oomFaultMapper.createOomFault(reqOomFaultDto);
			affectRowCount = affectRowCount + insertRow;
			
			// 알림톡 처리...
			int alarmNoticeGroupId = CommonObjectUtil.defaultNumber(reqOomFaultDto.getAlarmNoticeGroupId());
			if (alarmNoticeGroupId > 0) {
				FaultDetailResultDto faultDetailResultDto = alarmEventService.readAlarmForFaultSmsMessage(reqOomFaultDto);
				if (faultDetailResultDto != null) {
					OomKakaoAlimTalkDto reqOomKakaoAlimTalkDto = new OomKakaoAlimTalkDto();
					reqOomKakaoAlimTalkDto.setTmpltCode(Const.Definition.MSG_TEMPLATE_CODE.TSOP_007);
					reqOomKakaoAlimTalkDto.setSmsCreateCd(Const.Code.SMS_CREATE_CD.FAULT);
					OomKakaoAlimTalkDto oomKakaoAlimTalkDto = oomKakaoAlimTalkMapper.readKakaoAlimTalk(reqOomKakaoAlimTalkDto);
					if (oomKakaoAlimTalkDto != null) {
						List<AlimTalkDetailDto> alimTalkDetailDtoList = new ArrayList<AlimTalkDetailDto>();
						OomAlarmNoticeReceiveGroupDto reqOomAlarmNoticeReceiveGroupDto = new OomAlarmNoticeReceiveGroupDto();
						reqOomAlarmNoticeReceiveGroupDto.setAlarmNoticeGroupId(alarmNoticeGroupId);
						AlarmNoticeReceiveGroupDetailResultDto rsltAlarmNoticeReceiveGroupDetailResultDto = alarmNoticeReceiveGroupService.readAlarmNoticeReceiveGroup(reqOomAlarmNoticeReceiveGroupDto);
						if (rsltAlarmNoticeReceiveGroupDetailResultDto != null) {
							List<AlarmNoticeReceiveGroupDetailDetailResultDto> alarmNoticeReceiveGroupDetailDetailResultDtoList = rsltAlarmNoticeReceiveGroupDetailResultDto.getReceiveGroupDetailList();
							if (!CollectionUtils.isEmpty(alarmNoticeReceiveGroupDetailDetailResultDtoList)) {
								StringBuilder rcvPhoneNumBuilder = new StringBuilder();
								for (int idx = 0; idx < alarmNoticeReceiveGroupDetailDetailResultDtoList.size(); idx++) {
									AlarmNoticeReceiveGroupDetailDetailResultDto alarmNoticeReceiveGroupDetailDetailResultDto = alarmNoticeReceiveGroupDetailDetailResultDtoList.get(idx);
									String rcvPhoneNum = StringUtils.defaultString(alarmNoticeReceiveGroupDetailDetailResultDto.getRcvPhoneNum());
									if (rcvPhoneNumBuilder.toString().indexOf(rcvPhoneNum) < 0) {
										String rcverId = StringUtils.defaultString(alarmNoticeReceiveGroupDetailDetailResultDto.getRcverId());
										String rcverName = StringUtils.defaultString(alarmNoticeReceiveGroupDetailDetailResultDto.getRcverName());
										
										AlimTalkDetailDto alimTalkDetailDto = new AlimTalkDetailDto();
										alimTalkDetailDto.setRcverId(rcverId);
										alimTalkDetailDto.setRcverName(rcverName);
										alimTalkDetailDto.setRcvPhoneNum(rcvPhoneNum);
										alimTalkDetailDtoList.add(alimTalkDetailDto);
										
										if (rcvPhoneNumBuilder.length() == 0) {
											rcvPhoneNumBuilder.append(rcvPhoneNum);
										} else {
											rcvPhoneNumBuilder.append(",");
											rcvPhoneNumBuilder.append(rcvPhoneNum);
										}
									}
								}
								
								String onmAlarmGradeName = StringUtils.defaultString(faultDetailResultDto.getOnmAlarmGradeName());
								String tenantName = StringUtils.defaultString(faultDetailResultDto.getTenantName());
								String onmResourceName = StringUtils.defaultString(faultDetailResultDto.getOnmResourceName());
								String onmAlarmTypeName = StringUtils.defaultString(faultDetailResultDto.getOnmAlarmTypeName());
								String onmAlarmCdName = StringUtils.defaultString(faultDetailResultDto.getOnmAlarmCdName());
								
								String message = oomKakaoAlimTalkDto.getMessage();
								message = message.replaceAll("#\\{\"Major\"\\}", onmAlarmGradeName);
								message = message.replaceAll("#\\{\"알람\"\\}", "장애");
								message = message.replaceAll("#\\{\"발생\"\\}", "발생");
								message = message.replaceAll("#\\{\"SK 텔레콤\"\\}", tenantName);
								message = message.replaceAll("#\\{\"skt-opr-kc-connect3-plan\"\\}", onmResourceName);
								message = message.replaceAll("#\\{\"Memory\"\\}", onmAlarmTypeName);
								message = message.replaceAll("#\\{\"App Plan MEMORY 알람\"\\}", onmAlarmCdName);
								
								// 카카오 알림톡 발송 처리..
								AlimTalkRequestDto alimTalkRequestDto = new AlimTalkRequestDto();
								alimTalkRequestDto.setTenantId(tenantId);
								alimTalkRequestDto.setTmpltCode(Const.Definition.MSG_TEMPLATE_CODE.TSOP_007);
								alimTalkRequestDto.setRecipient(rcvPhoneNumBuilder.toString());
								alimTalkRequestDto.setMessage(message);
								alimTalkRequestDto.setSmsCreateCd(Const.Code.SMS_CREATE_CD.FAULT);
								alimTalkRequestDto.setAlarmNoticeGroupId(alarmNoticeGroupId);
								alimTalkRequestDto.setAuditId(auditId);
								alimTalkRequestDto.setDetailList(alimTalkDetailDtoList);
								String alarmNoticeResultCd = alimTalkService.sendOnmAlimTalk(alimTalkRequestDto);
								if (!"1".equals(alarmNoticeResultCd)) {
									// 성공이 아니면.. 모두 실패 처리...
									affectRowCount = -9999;
								}
							}
						}
					}
				}
			}
			
		} catch (Exception e) {
			throw e;
		}
		
		return affectRowCount;
	}
	
	/**
	 * 
	 * readFault
	 *
	 * @param reqOomFaultDto
	 * @return FaultDetailResultDto
	 * @throws Exception 
	 */
	@Override
	public FaultDetailResultDto readFault(OomFaultDto reqOomFaultDto) throws Exception {
		
		FaultDetailResultDto faultDetailResultDto = null;
		try {
			// 장애 상세조회...
			faultDetailResultDto = oomFaultMapper.readOomFault(reqOomFaultDto);
			if (faultDetailResultDto != null) {
				String eventDatetime = StringUtils.defaultString(faultDetailResultDto.getEventDatetime());
				String eventDatetimeFormat = CommonDateUtil.makeDatetimeFormat(eventDatetime);
				faultDetailResultDto.setEventDatetimeFormat(eventDatetimeFormat);
				
				String faultOccrDatetime = StringUtils.defaultString(faultDetailResultDto.getFaultOccrDatetime());
				faultOccrDatetime = CommonDateUtil.makeDatetimeFormat(faultOccrDatetime);
				faultDetailResultDto.setFaultOccrDatetime(faultOccrDatetime);
			}
			
		} catch (Exception e) {
			throw e;
		}
		return faultDetailResultDto;
	}
	
	/**
	 * 
	 * deleteFaultAttachFile
	 *
	 * @param reqOomFaultDto
	 * @return int
	 * @throws Exception 
	 */
	@Override
	public int deleteFaultAttachFile(OomFaultDto reqOomFaultDto) throws Exception {
		
		int affectRowCount = 0;
		
		try {
			int attachFileNum = reqOomFaultDto.getAttachFileNum();
			// 첨부파일 삭제
			int deleteRow = fileService.deleteAttachFile(Const.Definition.BLOB_CONTAINER.FILE, attachFileNum);
			affectRowCount = affectRowCount + deleteRow;
			// 장애내역의 첨부파일번호 Null update
			reqOomFaultDto.setAttachFileNum(null);
			int updateRow = oomFaultMapper.updateFaultAttachFileNum(reqOomFaultDto);
			affectRowCount = affectRowCount + updateRow;
			
		} catch (Exception e) {
			throw e;
		}
		return affectRowCount;
	}
	
	/**
	 * 
	 * updateFault
	 *
	 * @param reqFaultProcessingDto
	 * @return
	 * @throws Exception int
	 */
	@Override
	public int updateFault(FaultProcessingDto reqFaultProcessingDto) throws Exception {
		
		int affectRowCount = 0;
		
		try {
			OomFaultDto reqOomFaultDto = reqFaultProcessingDto.getFaultInfo();
			BlobRequestDto blobRequestDto = reqFaultProcessingDto.getAttachFile();
			if (blobRequestDto != null) {
				// 기존 첨부파일이 존재하는 지 확인...
				FaultDetailResultDto faultDetailResultDto = oomFaultMapper.readOomFaultAttachFile(reqOomFaultDto);
				if (faultDetailResultDto != null) {
					int oldAttachFileNum = CommonObjectUtil.defaultNumber(faultDetailResultDto.getAttachFileNum());
					if (oldAttachFileNum > 0) {
						// 기존 첨부파일 삭제
						int deleteRow = fileService.deleteAttachFile(Const.Definition.BLOB_CONTAINER.FILE, oldAttachFileNum);
						affectRowCount = affectRowCount + deleteRow;
					}
				}
				// 신규 첨부파일 등록..
				blobRequestDto.setContainerName(Const.Definition.BLOB_CONTAINER.FILE);
				blobRequestDto.setBlobBaseDir(Const.Definition.BLOB_BASEDIR.FAULT);
				int attachFileNum = fileService.createAttachFile(blobRequestDto);
				if (attachFileNum > 0) {
					reqOomFaultDto.setAttachFileNum(attachFileNum);
				}
			}
			
			// 장애 수정...
			int updateRow = oomFaultMapper.updateOomFault(reqOomFaultDto);
			affectRowCount = affectRowCount + updateRow;
			
			String auditId = StringUtils.defaultString(reqOomFaultDto.getAuditId());
			
			// 알림톡 처리...
			int alarmNoticeGroupId = CommonObjectUtil.defaultNumber(reqOomFaultDto.getAlarmNoticeGroupId());
			if (alarmNoticeGroupId > 0) {
				// 상태  및 알람관련 정보 조회...
				FaultDetailResultDto afterFaultDetailResultDto = oomFaultMapper.readOomFault(reqOomFaultDto);
				String eventDatetime = StringUtils.defaultString(afterFaultDetailResultDto.getEventDatetime());
				int onmAlarmEventId = afterFaultDetailResultDto.getOnmAlarmEventId();
				String tenantId = StringUtils.defaultString(afterFaultDetailResultDto.getTenantId());
				
				reqOomFaultDto.setOnmAlarmEventId(onmAlarmEventId);
				reqOomFaultDto.setEventDatetime(eventDatetime);
				
				FaultDetailResultDto faultDetailResultDto = alarmEventService.readAlarmForFaultSmsMessage(reqOomFaultDto);
				if (faultDetailResultDto != null) {
					OomKakaoAlimTalkDto reqOomKakaoAlimTalkDto = new OomKakaoAlimTalkDto();
					reqOomKakaoAlimTalkDto.setTmpltCode(Const.Definition.MSG_TEMPLATE_CODE.TSOP_007);
					reqOomKakaoAlimTalkDto.setSmsCreateCd(Const.Code.SMS_CREATE_CD.FAULT);
					OomKakaoAlimTalkDto oomKakaoAlimTalkDto = oomKakaoAlimTalkMapper.readKakaoAlimTalk(reqOomKakaoAlimTalkDto);
					if (oomKakaoAlimTalkDto != null) {
						List<AlimTalkDetailDto> alimTalkDetailDtoList = new ArrayList<AlimTalkDetailDto>();
						OomAlarmNoticeReceiveGroupDto reqOomAlarmNoticeReceiveGroupDto = new OomAlarmNoticeReceiveGroupDto();
						reqOomAlarmNoticeReceiveGroupDto.setAlarmNoticeGroupId(alarmNoticeGroupId);
						AlarmNoticeReceiveGroupDetailResultDto rsltAlarmNoticeReceiveGroupDetailResultDto = alarmNoticeReceiveGroupService.readAlarmNoticeReceiveGroup(reqOomAlarmNoticeReceiveGroupDto);
						if (rsltAlarmNoticeReceiveGroupDetailResultDto != null) {
							List<AlarmNoticeReceiveGroupDetailDetailResultDto> alarmNoticeReceiveGroupDetailDetailResultDtoList = rsltAlarmNoticeReceiveGroupDetailResultDto.getReceiveGroupDetailList();
							if (!CollectionUtils.isEmpty(alarmNoticeReceiveGroupDetailDetailResultDtoList)) {
								StringBuilder rcvPhoneNumBuilder = new StringBuilder();
								for (int idx = 0; idx < alarmNoticeReceiveGroupDetailDetailResultDtoList.size(); idx++) {
									AlarmNoticeReceiveGroupDetailDetailResultDto alarmNoticeReceiveGroupDetailDetailResultDto = alarmNoticeReceiveGroupDetailDetailResultDtoList.get(idx);
									String rcvPhoneNum = StringUtils.defaultString(alarmNoticeReceiveGroupDetailDetailResultDto.getRcvPhoneNum());
									if (rcvPhoneNumBuilder.toString().indexOf(rcvPhoneNum) < 0) {
										String rcverId = StringUtils.defaultString(alarmNoticeReceiveGroupDetailDetailResultDto.getRcverId());
										String rcverName = StringUtils.defaultString(alarmNoticeReceiveGroupDetailDetailResultDto.getRcverName());
										
										AlimTalkDetailDto alimTalkDetailDto = new AlimTalkDetailDto();
										alimTalkDetailDto.setRcverId(rcverId);
										alimTalkDetailDto.setRcverName(rcverName);
										alimTalkDetailDto.setRcvPhoneNum(rcvPhoneNum);
										alimTalkDetailDtoList.add(alimTalkDetailDto);
										
										if (rcvPhoneNumBuilder.length() == 0) {
											rcvPhoneNumBuilder.append(rcvPhoneNum);
										} else {
											rcvPhoneNumBuilder.append(",");
											rcvPhoneNumBuilder.append(rcvPhoneNum);
										}
									}
								}
								
								String onmAlarmGradeName = StringUtils.defaultString(faultDetailResultDto.getOnmAlarmGradeName());
								String tenantName = StringUtils.defaultString(faultDetailResultDto.getTenantName());
								String onmResourceName = StringUtils.defaultString(faultDetailResultDto.getOnmResourceName());
								String onmAlarmTypeName = StringUtils.defaultString(faultDetailResultDto.getOnmAlarmTypeName());
								String onmAlarmCdName = StringUtils.defaultString(faultDetailResultDto.getOnmAlarmCdName());
								
								String message = oomKakaoAlimTalkDto.getMessage();
								message = message.replaceAll("#\\{\"Major\"\\}", onmAlarmGradeName);
								message = message.replaceAll("#\\{\"알람\"\\}", "장애");
								message = message.replaceAll("#\\{\"발생\"\\}", "수정");
								message = message.replaceAll("#\\{\"SK 텔레콤\"\\}", tenantName);
								message = message.replaceAll("#\\{\"skt-opr-kc-connect3-plan\"\\}", onmResourceName);
								message = message.replaceAll("#\\{\"Memory\"\\}", onmAlarmTypeName);
								message = message.replaceAll("#\\{\"App Plan MEMORY 알람\"\\}", onmAlarmCdName);
								
								// 카카오 알림톡 발송 처리..
								AlimTalkRequestDto alimTalkRequestDto = new AlimTalkRequestDto();
								alimTalkRequestDto.setTenantId(tenantId);
								alimTalkRequestDto.setTmpltCode(Const.Definition.MSG_TEMPLATE_CODE.TSOP_007);
								alimTalkRequestDto.setRecipient(rcvPhoneNumBuilder.toString());
								alimTalkRequestDto.setMessage(message);
								alimTalkRequestDto.setSmsCreateCd(Const.Code.SMS_CREATE_CD.FAULT);
								alimTalkRequestDto.setAlarmNoticeGroupId(alarmNoticeGroupId);
								alimTalkRequestDto.setAuditId(auditId);
								alimTalkRequestDto.setDetailList(alimTalkDetailDtoList);
								String alarmNoticeResultCd = alimTalkService.sendOnmAlimTalk(alimTalkRequestDto);
								if (!"1".equals(alarmNoticeResultCd)) {
									// 성공이 아니면.. 모두 실패 처리...
									affectRowCount = -9999;
								}
							}
						}
					}
				}
			}
			
		} catch (Exception e) {
			throw e;
		}
		
		return affectRowCount;
	}
	
	/**
	 * 
	 * readOomFaultDuplicationCheck
	 *
	 * @param reqOomFaultDto
	 * @return FaultDetailResultDto
	 * @throws Exception 
	 */
	@Override
	public FaultDetailResultDto readOomFaultDuplicationCheck(OomFaultDto reqOomFaultDto) throws Exception {
		
		FaultDetailResultDto faultDetailResultDto = null;
		try {
			// 장애 상세조회...
			faultDetailResultDto = oomFaultMapper.readOomFaultDuplicationCheck(reqOomFaultDto);
			if (faultDetailResultDto == null) {
				faultDetailResultDto = alarmEventService.readAlarmForFault(reqOomFaultDto);
			}
			
			if (faultDetailResultDto != null) {
				String eventDatetime = StringUtils.defaultString(faultDetailResultDto.getEventDatetime());
				String eventDatetimeFormat = CommonDateUtil.makeDatetimeFormat(eventDatetime);
				faultDetailResultDto.setEventDatetimeFormat(eventDatetimeFormat);
				
				String faultOccrDatetime = StringUtils.defaultString(faultDetailResultDto.getFaultOccrDatetime());
				if (!"".equals(faultOccrDatetime)) {
					faultOccrDatetime = CommonDateUtil.makeDatetimeFormat(faultOccrDatetime);
					faultDetailResultDto.setFaultOccrDatetime(faultOccrDatetime);
				}
			}
			
		} catch (Exception e) {
			throw e;
		}
		return faultDetailResultDto;
	}
	
	/**
	 * 
	 * readFalutCountForAlarm
	 *
	 * @param reqOomFaultDto
	 * @return int
	 * @throws Exception 
	 */
	@Override
	public int readFalutCountForAlarm(OomFaultDto reqOomFaultDto) throws Exception {
		
		int faultCount = 0;
		try {
			faultCount = oomFaultMapper.readFalutCountForAlarm(reqOomFaultDto);
			
		} catch (Exception e) {
			throw e;
		}
		return faultCount;
	}
	
}
