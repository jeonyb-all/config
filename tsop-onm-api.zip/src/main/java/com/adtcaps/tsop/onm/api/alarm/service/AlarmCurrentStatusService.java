package com.adtcaps.tsop.onm.api.alarm.service;

import java.util.List;

import com.adtcaps.tsop.onm.api.alarm.domain.AlarmCurrentStatusDetailResultDto;
import com.adtcaps.tsop.onm.api.alarm.domain.AlarmCurrentStatusGridRequestDto;
import com.adtcaps.tsop.onm.api.alarm.domain.AlarmCurrentStatusGridResultDto;
import com.adtcaps.tsop.onm.api.domain.OomOnmAlarmCurrentStatusDto;

/**
 * 
 * <ul>
 * <li>업무 그룹명 : tsop-onm-api</li>
 * <li>서브 업무명 : com.adtcaps.tsop.onm.api.alarm.service</li>
 * <li>설  명 : AlarmCurrentStatusService.java</li>
 * <li>작성일 : 2021. 2. 6.</li>
 * <li>작성자 : jeonyb4</li>
 * </ul>
 */
public interface AlarmCurrentStatusService {
	/**
	 * 
	 * listPageAlarmCurrentStatus
	 *
	 * @param alarmNoticeConditionGridRequestDto
	 * @return List<AlarmCurrentStatusGridResultDto>
	 * @throws Exception 
	 */
	public List<AlarmCurrentStatusGridResultDto> listPageAlarmCurrentStatus(AlarmCurrentStatusGridRequestDto alarmNoticeConditionGridRequestDto) throws Exception;
	
	/**
	 * 
	 * readAlarmCurrentStatus
	 *
	 * @param reqOomOnmAlarmCurrentStatusDto
	 * @return AlarmCurrentStatusDetailResultDto
	 * @throws Exception 
	 */
	public AlarmCurrentStatusDetailResultDto readAlarmCurrentStatus(OomOnmAlarmCurrentStatusDto reqOomOnmAlarmCurrentStatusDto) throws Exception;
	
	/**
	 * 
	 * updateAlarmCurrentStatus
	 *
	 * @param reqOomOnmAlarmCurrentStatusDto
	 * @return int
	 * @throws Exception 
	 */
	public int updateAlarmCurrentStatus(OomOnmAlarmCurrentStatusDto reqOomOnmAlarmCurrentStatusDto) throws Exception;

}
