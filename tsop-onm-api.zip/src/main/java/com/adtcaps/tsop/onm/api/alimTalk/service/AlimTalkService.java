package com.adtcaps.tsop.onm.api.alimTalk.service;

import com.adtcaps.tsop.onm.api.alimTalk.domain.AlimTalkBatchResultDto;
import com.adtcaps.tsop.onm.api.alimTalk.domain.AlimTalkRequestDto;

/**
 *
 * <ul>
 * <li>업무 그룹명 : tsop-onm-api</li>
 * <li>서브 업무명 : com.adtcaps.tsop.onm.api.alimTalk.service</li>
 * <li>설  명 : AlimTalkService.java</li>
 * <li>작성일 : 2021. 12. 24.</li>
 * <li>작성자 : vader</li>
 * </ul>
 */
public interface AlimTalkService {
	/**
	 *
	 * sendOnmAlimTalk
	 *
	 * @param alimTalkRequestDto
	 * @return String
	 * @throws Exception
	 */
	public String sendOnmAlimTalk(AlimTalkRequestDto alimTalkRequestDto) throws Exception;

	/**
	 * sendAlimTalk
	 * @param alimTalkRequestDto
	 * @return AlimTalkBatchResultDto
	 * @throws Exception
	 */
	public AlimTalkBatchResultDto sendAlimTalk(AlimTalkRequestDto alimTalkRequestDto) throws Exception;

	/**
	 * getAlimTalkResult
	 * @throws Exception
	 */
	public void getAlimTalkResult() throws Exception;
}
