package com.adtcaps.tsop.onm.api.alarm.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.adtcaps.tsop.onm.api.alarm.domain.AlarmCodeForComboResultDto;
import com.adtcaps.tsop.onm.api.alarm.domain.AlarmCodeForShortGridResultDto;
import com.adtcaps.tsop.onm.api.alarm.mapper.OomOnmAlarmCodeMapper;
import com.adtcaps.tsop.onm.api.alarm.service.AlarmCodeService;
import com.adtcaps.tsop.onm.api.domain.OomOnmAlarmCodeDto;
import com.adtcaps.tsop.onm.api.helper.domain.BasePageDto;

/**
 * 
 * <ul>
 * <li>업무 그룹명 : tsop-onm-api</li>
 * <li>서브 업무명 : com.adtcaps.tsop.onm.api.alarm.service.impl</li>
 * <li>설  명 : AlarmCodeServiceImpl.java</li>
 * <li>작성일 : 2021. 1. 21.</li>
 * <li>작성자 : jeonyb4</li>
 * </ul>
 */
@Service
public class AlarmCodeServiceImpl implements AlarmCodeService {
	
	@Autowired
	private OomOnmAlarmCodeMapper oomOnmResourceMapper;
	
	/**
	 * 
	 * listAlarmCodeForCombo
	 *
	 * @param reqOomOnmAlarmCodeDto
	 * @return List<AlarmCodeForComboResultDto>
	 * @throws Exception 
	 */
	@Override
	public List<AlarmCodeForComboResultDto> listAlarmCodeForCombo(OomOnmAlarmCodeDto reqOomOnmAlarmCodeDto) throws Exception {
		
		List<AlarmCodeForComboResultDto> alarmCodeForComboResultDtoList = null;
		try {
			alarmCodeForComboResultDtoList = oomOnmResourceMapper.listAlarmCodeForCombo(reqOomOnmAlarmCodeDto);
		} catch (Exception e) {
			throw e;
		}
		return alarmCodeForComboResultDtoList;
	}
	
	/**
	 * 
	 * listAlarmCodeForThresholdCombo
	 *
	 * @param reqOomOnmAlarmCodeDto
	 * @return List<AlarmCodeForComboResultDto>
	 * @throws Exception 
	 */
	@Override
	public List<AlarmCodeForComboResultDto> listAlarmCodeForThresholdCombo(OomOnmAlarmCodeDto reqOomOnmAlarmCodeDto) throws Exception {
		
		List<AlarmCodeForComboResultDto> alarmCodeForComboResultDtoList = null;
		try {
			alarmCodeForComboResultDtoList = oomOnmResourceMapper.listAlarmCodeForThresholdCombo(reqOomOnmAlarmCodeDto);
		} catch (Exception e) {
			throw e;
		}
		return alarmCodeForComboResultDtoList;
	}
	
	/**
	 * 
	 * listAlarmCodeForShortGrid
	 *
	 * @param reqBasePageDto
	 * @return List<AlarmCodeForShortGridResultDto>
	 * @throws Exception 
	 */
	@Override
	public List<AlarmCodeForShortGridResultDto> listAlarmCodeForShortGrid(BasePageDto reqBasePageDto) throws Exception {
		
		List<AlarmCodeForShortGridResultDto> alarmCodeForShortGridResultDtoList = null;
		try {
			alarmCodeForShortGridResultDtoList = oomOnmResourceMapper.listAlarmCodeForShortGrid(reqBasePageDto);
		} catch (Exception e) {
			throw e;
		}
		return alarmCodeForShortGridResultDtoList;
	}
	
	/**
	 * 
	 * listAlarmCodeForThresholdShortGrid
	 *
	 * @param reqBasePageDto
	 * @return List<AlarmCodeForShortGridResultDto>
	 * @throws Exception 
	 */
	@Override
	public List<AlarmCodeForShortGridResultDto> listAlarmCodeForThresholdShortGrid(BasePageDto reqBasePageDto) throws Exception {
		
		List<AlarmCodeForShortGridResultDto> alarmCodeForShortGridResultDtoList = null;
		try {
			alarmCodeForShortGridResultDtoList = oomOnmResourceMapper.listAlarmCodeForThresholdShortGrid(reqBasePageDto);
		} catch (Exception e) {
			throw e;
		}
		return alarmCodeForShortGridResultDtoList;
	}

}
