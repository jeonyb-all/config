package com.adtcaps.tsop.onm.api.tenant.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.util.CollectionUtils;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.adtcaps.tsop.onm.api.domain.OomTenantDto;
import com.adtcaps.tsop.onm.api.helper.constant.Const;
import com.adtcaps.tsop.onm.api.helper.domain.BasePageDto;
import com.adtcaps.tsop.onm.api.helper.domain.ResultDto;
import com.adtcaps.tsop.onm.api.helper.util.PageUtil;
import com.adtcaps.tsop.onm.api.tenant.domain.TenantDetailResultDto;
import com.adtcaps.tsop.onm.api.tenant.domain.TenantForComboResultDto;
import com.adtcaps.tsop.onm.api.tenant.domain.TenantForShortGridResultDto;
import com.adtcaps.tsop.onm.api.tenant.domain.TenantGridResultDto;
import com.adtcaps.tsop.onm.api.tenant.service.TenantService;

import lombok.extern.slf4j.Slf4j;

/**
 * 
 * <ul>
 * <li>업무 그룹명 : tsop-onm-api</li>
 * <li>서브 업무명 : com.adtcaps.tsop.onm.api.tenant.controller</li>
 * <li>설  명 : TenantController.java</li>
 * <li>작성일 : 2021. 1. 6.</li>
 * <li>작성자 : jeonyb4</li>
 * </ul>
 */
@Slf4j
@RestController
@RequestMapping("/api/tenants")
public class TenantController {
	
	private final String ERR_MSG_NULL_PAGE_NUMBER = "페이지 번호가 없습니다.";
	
	private final String ERR_MSG_NULL_SEARCH_RESULT_LIST = "조회 결과가 없습니다.";
	private final String ERR_MSG_READ_FAIL = "조회에 실패하였습니다.";
	
	@Autowired
	private TenantService tenantService;
	
	/**
	 * 
	 * listTenantForCombo
	 *
	 * @return ResponseEntity
	 */
	@SuppressWarnings("rawtypes")
	@GetMapping(value="/combobox", produces="application/json; charset=UTF-8")
	public ResponseEntity listTenantForCombo() throws Exception {
		
		ResponseEntity<ResultDto> resEntity = null;
		String returnString = "";
		
		// 콤보박스용 테넌트 목록조회
		List<TenantForComboResultDto> tenantForComboResultDtoList = tenantService.listTenantForCombo();
		if (CollectionUtils.isEmpty(tenantForComboResultDtoList)) {
			returnString = Const.Common.RESULT_CODE.SUCCESS;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_SEARCH_RESULT_LIST, tenantForComboResultDtoList));
        } else {
        	returnString = Const.Common.RESULT_CODE.SUCCESS;
        	resEntity = ResponseEntity.ok(new ResultDto(returnString, "", tenantForComboResultDtoList));
		}
		
		return resEntity;
	}
	
	/**
	 * 
	 * listTenantForWorkForCombo
	 *
	 * @return ResponseEntity
	 */
	@SuppressWarnings("rawtypes")
	@GetMapping(value="/work-tenants/combobox", produces="application/json; charset=UTF-8")
	public ResponseEntity listTenantForWorkForCombo() throws Exception {
		
		ResponseEntity<ResultDto> resEntity = null;
		String returnString = "";
		
		// 콤보박스용 테넌트(작업포함) 목록조회
		List<TenantForComboResultDto> tenantForComboResultDtoList = tenantService.listTenantForWorkForCombo();
		if (CollectionUtils.isEmpty(tenantForComboResultDtoList)) {
			returnString = Const.Common.RESULT_CODE.SUCCESS;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_SEARCH_RESULT_LIST, tenantForComboResultDtoList));
        } else {
        	returnString = Const.Common.RESULT_CODE.SUCCESS;
        	resEntity = ResponseEntity.ok(new ResultDto(returnString, "", tenantForComboResultDtoList));
		}

		return resEntity;
	}
	
	/**
	 * 
	 * listTenantForShortGrid
	 *
	 * @param reqBasePageDto
	 * @return ResponseEntity
	 */
	@SuppressWarnings("rawtypes")
	@GetMapping(value="/short-grid", produces="application/json; charset=UTF-8")
	public ResponseEntity listTenantForShortGrid(BasePageDto reqBasePageDto) throws Exception {
		
		ResponseEntity<ResultDto> resEntity = null;
		String returnString = "";
		
		// 팝업제공용 테넌트 목록조회
		Map<String, Object> tenantForShortGridResultDtoListMap = new HashMap<String, Object>();
		List<TenantForShortGridResultDto> tenantForShortGridResultDtoList = tenantService.listTenantForShortGrid(reqBasePageDto);
		if (CollectionUtils.isEmpty(tenantForShortGridResultDtoList)) {
			returnString = Const.Common.RESULT_CODE.SUCCESS;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_SEARCH_RESULT_LIST, tenantForShortGridResultDtoListMap));
        } else {
        	returnString = Const.Common.RESULT_CODE.SUCCESS;
        	int totalCount = tenantForShortGridResultDtoList.size();
			Map<String, Object> totalCountMap = new HashMap<String, Object>();
			totalCountMap.put("totalCount", totalCount);
			
        	tenantForShortGridResultDtoListMap.put(Const.Definition.PAGE.PAGER, totalCountMap);
        	tenantForShortGridResultDtoListMap.put(Const.Definition.PAGE.LISTS, tenantForShortGridResultDtoList);
			resEntity = ResponseEntity.ok(new ResultDto(returnString, "", tenantForShortGridResultDtoListMap));
		}

		return resEntity;
	}
	
	/**
	 * 
	 * listPageTenant
	 *
	 * @param reqBasePageDto
	 * @return ResponseEntity
	 */
	@SuppressWarnings("rawtypes")
	@GetMapping(value="", produces="application/json; charset=UTF-8")
	public ResponseEntity listPageTenant(BasePageDto reqBasePageDto) throws Exception {
		
		ResponseEntity<ResultDto> resEntity = null;
		String returnString = "";
		
		int pageNumber = reqBasePageDto.getPageNumber();
		if (pageNumber < 1) {
			log.error(">>>>>> pageNumber ERROR:{}", ERR_MSG_NULL_PAGE_NUMBER);
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_PAGE_NUMBER));
			return resEntity;
		}
		
		// 테넌트 목록조회
		Map<String, Object> tenantGridResultDtoListMap = new HashMap<String, Object>();
		List<TenantGridResultDto> tenantGridResultDtoList = tenantService.listPageTenant(reqBasePageDto);
		if (CollectionUtils.isEmpty(tenantGridResultDtoList)) {
			returnString = Const.Common.RESULT_CODE.SUCCESS;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_SEARCH_RESULT_LIST, tenantGridResultDtoListMap));
        } else {
        	returnString = Const.Common.RESULT_CODE.SUCCESS;
        	tenantGridResultDtoListMap.put(Const.Definition.PAGE.PAGER, PageUtil.getPageInfo(tenantGridResultDtoList));
        	tenantGridResultDtoListMap.put(Const.Definition.PAGE.LISTS, tenantGridResultDtoList);
			resEntity = ResponseEntity.ok(new ResultDto(returnString, "", tenantGridResultDtoListMap));
		}

		return resEntity;
	}
	
	/**
	 * 
	 * readTenant
	 *
	 * @param tenantId
	 * @return ResponseEntity
	 */
	@SuppressWarnings("rawtypes")
	@GetMapping(value="/{tenantId}", produces="application/json; charset=UTF-8")
	public ResponseEntity readTenant(@PathVariable("tenantId") String tenantId) throws Exception {
		
		ResponseEntity<ResultDto> resEntity = null;
		String returnString = "";
		
		OomTenantDto reqOomTenantDto = new OomTenantDto();
		reqOomTenantDto.setTenantId(tenantId);
		
		// 테넌트 상세조회
		TenantDetailResultDto tenantDetailResultDto = tenantService.readTenant(reqOomTenantDto);
		if (tenantDetailResultDto == null) {
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_READ_FAIL, tenantDetailResultDto));
        } else {
        	returnString = Const.Common.RESULT_CODE.SUCCESS;
        	resEntity = ResponseEntity.ok(new ResultDto(returnString, "", tenantDetailResultDto));
		}

		return resEntity;
	}

}
