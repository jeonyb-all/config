package com.adtcaps.tsop.onm.api.user.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.util.CollectionUtils;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.adtcaps.tsop.onm.api.authentication.domain.JwtAuthResultDto;
import com.adtcaps.tsop.onm.api.domain.OomUserDto;
import com.adtcaps.tsop.onm.api.helper.constant.Const;
import com.adtcaps.tsop.onm.api.helper.domain.ResultDto;
import com.adtcaps.tsop.onm.api.helper.util.CommonObjectUtil;
import com.adtcaps.tsop.onm.api.helper.util.PageUtil;
import com.adtcaps.tsop.onm.api.user.domain.UserProcessingDto;
import com.adtcaps.tsop.onm.api.user.domain.UserDetailResultDto;
import com.adtcaps.tsop.onm.api.user.domain.UserForShortGridRequestDto;
import com.adtcaps.tsop.onm.api.user.domain.UserForShortGridResultDto;
import com.adtcaps.tsop.onm.api.user.domain.UserGridRequestDto;
import com.adtcaps.tsop.onm.api.user.domain.UserGridResultDto;
import com.adtcaps.tsop.onm.api.user.domain.UserPasswordChangeRequestDto;
import com.adtcaps.tsop.onm.api.user.service.UserService;

import lombok.extern.slf4j.Slf4j;

/**
 * 
 * <ul>
 * <li>업무 그룹명 : tsop-backend-api</li>
 * <li>서브 업무명 : com.adtcaps.tsop.portal.api.user.controller</li>
 * <li>설  명 : UserController.java</li>
 * <li>작성일 : 2020. 12. 21.</li>
 * <li>작성자 : jeonyb4</li>
 * </ul>
 */
@Slf4j
@RestController
@RequestMapping("/api/users")
public class UserController {
	
	private final String ERR_MSG_NULL_LOGIN_USER_ID = "로그인 사용자ID가 없습니다.";
	private final String ERR_MSG_NULL_PAGE_NUMBER = "페이지 번호가 없습니다.";
	private final String ERR_MSG_NULL_USER_ID = "운영자ID가 없습니다.";
	private final String ERR_MSG_NULL_USER_NAME = "운영자명이 없습니다.";
	private final String ERR_MSG_NULL_CONTACT_PHONE_NUM = "연락전화번호가 없습니다.";
	private final String ERR_MSG_NULL_MENU_GROUP_ID = "메뉴그룹ID가 없습니다.";
	private final String ERR_MSG_NULL_MGR_YN = "관리자여부가 없습니다.";
	private final String ERR_MSG_NULL_SERVICE_OPER_YN = "서비스운영여부가 없습니다.";
	private final String ERR_MSG_NULL_TENANT_ID = "테넌트ID가 없습니다.";
	private final String ERR_MSG_NULL_LOGIN_PWRD = "사용자 비밀번호가 없습니다.";
	private final String ERR_MSG_NULL_BEFORE_PWRD = "이전 비밀번호가 없습니다.";
	
	private final String ERR_MSG_ABNORMAL_AUTH = "현재 사용자는 권한이 없습니다.";
	
	private final String ERR_MSG_ALREADY_EXIST_USER_ID = "해당 운영자ID는 이미 존재하므로 사용할 수 없습니다.";
	private final String ERR_MSG_ALREADY_SERVICE_OPER_USER = "해당 테넌트는 서비스운영자가 이미 존재합니다.";
	private final String ERR_MSG_CANNOT_EQUAL_PWRD = "이전 비밀번호와 동일한 비밀번호는 사용할 수 없습니다.";
	private final String ERR_MSG_NOT_EQUAL_BEFORE_PWRD = "이전 비밀번호가 맞지 않습니다.";
	private final String ERR_MSG_NULL_SEARCH_RESULT_LIST = "조회 결과가 없습니다.";
	private final String ERR_MSG_CREATE_FAIL = "등록에 실패하였습니다.";
	private final String ERR_MSG_READ_FAIL = "조회에 실패하였습니다.";
	private final String ERR_MSG_UPDATE_FAIL = "수정에 실패하였습니다.";
	private final String ERR_MSG_DELETE_FAIL = "삭제에 실패하였습니다.";
	private final String ERR_MSG_SMS_SEND_FAIL = "알림톡 발송에 실패하였습니다.";
	
	@Autowired
	private UserService userService;
	
	/**
	 * 
	 * readMyInfo
	 *
	 * @return ResponseEntity
	 */
	@SuppressWarnings("rawtypes")
    @GetMapping(value="/myinfo", produces="application/json; charset=UTF-8")
    public ResponseEntity readMyInfo(@AuthenticationPrincipal JwtAuthResultDto authResultDto) throws Exception {
        
    	ResponseEntity<ResultDto> resEntity = null;
		String returnString = "";
    	
		String loginUserId = StringUtils.defaultString(authResultDto.getUserId());
		if ("".equals(loginUserId)) {
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_LOGIN_USER_ID));
			return resEntity;
		}
		//String loginUserId = "TEST02"; // 이후 세션에서 얻어올 값...
		
		OomUserDto reqOomUserDto = new OomUserDto();
		reqOomUserDto.setUserId(loginUserId);
		
		UserDetailResultDto userDetailResultDto = userService.readUser(reqOomUserDto);
		if (userDetailResultDto == null) {
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_READ_FAIL, userDetailResultDto));
		} else {
			returnString = Const.Common.RESULT_CODE.SUCCESS;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, "", userDetailResultDto));
		}
    	
    	return resEntity;
    }
	
	/**
	 * 
	 * updateMyInfo
	 *
	 * @param reqOomUserDto
	 * @return ResponseEntity
	 */
	@SuppressWarnings("rawtypes")
    @PutMapping(value="/myinfo", produces="application/json; charset=UTF-8")
	public ResponseEntity updateMyInfo(@AuthenticationPrincipal JwtAuthResultDto authResultDto, 
			@RequestBody OomUserDto reqOomUserDto) throws Exception {
        
    	ResponseEntity<ResultDto> resEntity = null;
		String returnString = "";
    	
		String loginUserId = StringUtils.defaultString(authResultDto.getUserId());
		if ("".equals(loginUserId)) {
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_LOGIN_USER_ID));
			return resEntity;
		}
		//String loginUserId = "TEST02"; // 이후 세션에서 얻어올 값...
		
		String userName = StringUtils.defaultString(reqOomUserDto.getUserName());
		if ("".equals(userName)) {
			log.error(">>>>>> userName ERROR:{}", ERR_MSG_NULL_USER_NAME);
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_USER_NAME));
			return resEntity;
		}
		String contactPhoneNum = StringUtils.defaultString(reqOomUserDto.getContactPhoneNum());
		if ("".equals(contactPhoneNum)) {
			log.error(">>>>>> contactPhoneNum ERROR:{}", ERR_MSG_NULL_CONTACT_PHONE_NUM);
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_CONTACT_PHONE_NUM));
			return resEntity;
		}
		
		reqOomUserDto.setUserId(loginUserId);
		reqOomUserDto.setAuditId(loginUserId);
		
		// 사용자 수정...
		int affectRowCount = userService.updateMyInfo(reqOomUserDto);
		if (affectRowCount < 1) {
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_UPDATE_FAIL, affectRowCount));
		} else {
			returnString = Const.Common.RESULT_CODE.SUCCESS;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, "", affectRowCount));
		}
    	
    	return resEntity;
    }
	
	/**
	 * 
	 * updateUserPassword
	 *
	 * @param authResultDto
	 * @param reqOomUserDto
	 * @return ResponseEntity
	 */
	@SuppressWarnings("rawtypes")
    @PutMapping(value="/password", produces="application/json; charset=UTF-8")
	public ResponseEntity updateUserPassword(@AuthenticationPrincipal JwtAuthResultDto authResultDto, 
			@RequestBody UserPasswordChangeRequestDto userPasswordChangeRequestDto) throws Exception {
        
    	ResponseEntity<ResultDto> resEntity = null;
		String returnString = "";
    	
		String loginUserId = StringUtils.defaultString(authResultDto.getUserId());
		if ("".equals(loginUserId)) {
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_LOGIN_USER_ID));
			return resEntity;
		}
		//String loginUserId = "TEST02"; // 이후 세션에서 얻어올 값...
		
		userPasswordChangeRequestDto.setUserId(loginUserId);
		userPasswordChangeRequestDto.setAuditId(loginUserId);
		
		String beforePassword = StringUtils.defaultString(userPasswordChangeRequestDto.getBeforePassword());
		if ("".equals(beforePassword)) {
			log.error(">>>>>> beforePassword ERROR:{}", ERR_MSG_NULL_BEFORE_PWRD);
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_BEFORE_PWRD));
			return resEntity;
		} else {
			OomUserDto reqOomUserDto = new OomUserDto();
			reqOomUserDto.setUserId(loginUserId);
			reqOomUserDto.setLoginPassword(beforePassword);
			int compareResult = userService.readUserPasswordEqualCheck(reqOomUserDto);
    		if (compareResult < 1) {
    			log.error(">>>>>> compareResult ERROR:{}", ERR_MSG_NOT_EQUAL_BEFORE_PWRD);
				returnString = Const.Common.RESULT_CODE.FAIL;
    			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NOT_EQUAL_BEFORE_PWRD));
    			return resEntity;
    		}
		}
		
		OomUserDto reqOomUserDto = new OomUserDto();
		BeanUtils.copyProperties(userPasswordChangeRequestDto, reqOomUserDto);
		
		String loginPassword = StringUtils.defaultString(reqOomUserDto.getLoginPassword());
		if ("".equals(loginPassword)) {
			log.error(">>>>>> loginPassword ERROR:{}", ERR_MSG_NULL_LOGIN_PWRD);
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_LOGIN_PWRD));
			return resEntity;
		} else {
			int compareResult = userService.readUserPasswordEqualCheck(reqOomUserDto);
    		if (compareResult > 0) {
    			log.error(">>>>>> compareResult ERROR:{}", ERR_MSG_CANNOT_EQUAL_PWRD);
				returnString = Const.Common.RESULT_CODE.FAIL;
    			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_CANNOT_EQUAL_PWRD));
    			return resEntity;
    		}
			
			String errorMsg = CommonObjectUtil.checkPasswordPattern(loginUserId, loginPassword);
			if (!"".equals(errorMsg)) {
				log.error(">>>>>> loginPassword ERROR:{}", errorMsg);
				returnString = Const.Common.RESULT_CODE.FAIL;
    			resEntity = ResponseEntity.ok(new ResultDto(returnString, errorMsg));
    			return resEntity;
			}
		}
		
		// 사용자 비밀번호 수정...
		int affectRowCount = userService.updateUserPassword(reqOomUserDto);
		if (affectRowCount < 1) {
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_UPDATE_FAIL, affectRowCount));
		} else {
			returnString = Const.Common.RESULT_CODE.SUCCESS;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, "", affectRowCount));
		}
    	
    	return resEntity;
    }
	
	/**
	 * 
	 * listUserForShortGrid
	 *
	 * @param reqBasePageDto
	 * @return ResponseEntity
	 */
	@SuppressWarnings("rawtypes")
    @GetMapping(value="/short-grid", produces="application/json; charset=UTF-8")
    public ResponseEntity listUserForShortGrid(UserForShortGridRequestDto userForShortGridRequestDto) throws Exception {
        
    	ResponseEntity<ResultDto> resEntity = null;
		String returnString = "";
    	
		// 팝업 제공용 사용자 목록 조회....
		Map<String, Object> userForShortGridResultDtoListMap = new HashMap<String, Object>();
		List<UserForShortGridResultDto> userForShortGridResultDtoList = userService.listUserForShortGrid(userForShortGridRequestDto);
		if (CollectionUtils.isEmpty(userForShortGridResultDtoList)) {
			returnString = Const.Common.RESULT_CODE.SUCCESS;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_SEARCH_RESULT_LIST, userForShortGridResultDtoListMap));
		} else {
			returnString = Const.Common.RESULT_CODE.SUCCESS;
			int totalCount = userForShortGridResultDtoList.size();
			Map<String, Object> totalCountMap = new HashMap<String, Object>();
			totalCountMap.put("totalCount", totalCount);
			
			userForShortGridResultDtoListMap.put(Const.Definition.PAGE.PAGER, totalCountMap);
			userForShortGridResultDtoListMap.put(Const.Definition.PAGE.LISTS, userForShortGridResultDtoList);
			resEntity = ResponseEntity.ok(new ResultDto(returnString, "", userForShortGridResultDtoListMap));
		}
    	
    	return resEntity;
    }
	
	/**
	 * 
	 * listPageUser
	 *
	 * @param userGridRequestDto
	 * @return ResponseEntity
	 */
	@SuppressWarnings("rawtypes")
    @GetMapping(value="", produces="application/json; charset=UTF-8")
    public ResponseEntity listPageUser(@AuthenticationPrincipal JwtAuthResultDto authResultDto, 
    		UserGridRequestDto userGridRequestDto) throws Exception {
        
    	ResponseEntity<ResultDto> resEntity = null;
		String returnString = "";
    	
		String mgrYn = StringUtils.defaultString(authResultDto.getMgrYn());
		if ("".equals(mgrYn)) {
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_MGR_YN));
			return resEntity;
		}
		
		int pageNumber = userGridRequestDto.getPageNumber();
		if (pageNumber < 1) {
			log.error(">>>>>> pageNumber ERROR:{}", ERR_MSG_NULL_PAGE_NUMBER);
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_PAGE_NUMBER));
			return resEntity;
		}
		
		// 권한이 있는지 체크...
		if (!"Y".equals(mgrYn)) {
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_ABNORMAL_AUTH));
			return resEntity;
		}
		
		// 사용자 목록 조회....
		Map<String, Object> userGridResultDtoListMap = new HashMap<String, Object>();
		List<UserGridResultDto> userGridResultDtoList = userService.listPageUser(userGridRequestDto);
		if (CollectionUtils.isEmpty(userGridResultDtoList)) {
			returnString = Const.Common.RESULT_CODE.SUCCESS;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_SEARCH_RESULT_LIST, userGridResultDtoListMap));
		} else {
			returnString = Const.Common.RESULT_CODE.SUCCESS;
			userGridResultDtoListMap.put(Const.Definition.PAGE.PAGER, PageUtil.getPageInfo(userGridResultDtoList));
			userGridResultDtoListMap.put(Const.Definition.PAGE.LISTS, userGridResultDtoList);
			resEntity = ResponseEntity.ok(new ResultDto(returnString, "", userGridResultDtoListMap));
		}
    	
    	return resEntity;
    }
	
	/**
	 * 
	 * updateUserInitialPassword
	 *
	 * @param userId
	 * @param reqOomUserDto
	 * @return ResponseEntity
	 */
	@SuppressWarnings("rawtypes")
    @PutMapping(value="/init-password/{userId:.+}", produces="application/json; charset=UTF-8")
    public ResponseEntity updateUserInitialPassword(@AuthenticationPrincipal JwtAuthResultDto authResultDto, 
    		@PathVariable("userId") String userId, @RequestBody OomUserDto reqOomUserDto) throws Exception {
        
    	ResponseEntity<ResultDto> resEntity = null;
		String returnString = "";
    	
		String loginUserId = StringUtils.defaultString(authResultDto.getUserId());
		if ("".equals(loginUserId)) {
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_LOGIN_USER_ID));
			return resEntity;
		}
		//String loginUserId = "tsop-admin"; // 이후 세션에서 얻어올 값...
		
		String contactPhoneNum = StringUtils.defaultString(reqOomUserDto.getContactPhoneNum());
		if ("".equals(contactPhoneNum)) {
			log.error(">>>>>> contactPhoneNum ERROR:{}", ERR_MSG_NULL_CONTACT_PHONE_NUM);
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_CONTACT_PHONE_NUM));
			return resEntity;
		}
		
		reqOomUserDto.setUserId(userId);
		reqOomUserDto.setAuditId(loginUserId);
		
		// 사용자 패스워드 초기화...
		int affectRowCount = userService.updateUserInitialPassword(reqOomUserDto);
		if (affectRowCount < 1) {
			if (affectRowCount < 0) {
				returnString = Const.Common.RESULT_CODE.FAIL;
    			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_SMS_SEND_FAIL, affectRowCount));
			} else {
				returnString = Const.Common.RESULT_CODE.FAIL;
    			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_UPDATE_FAIL, affectRowCount));
			}
		} else {
			returnString = Const.Common.RESULT_CODE.SUCCESS;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, "", affectRowCount));
		}
		
    	return resEntity;
    }
	
	/**
	 * 
	 * readUserDuplicationCheck
	 *
	 * @param reqOomUserDto
	 * @return ResponseEntity
	 */
	@SuppressWarnings("rawtypes")
    @GetMapping(value="/dup-check/{userId:.+}", produces="application/json; charset=UTF-8")
    public ResponseEntity readUserDuplicationCheck(@PathVariable("userId") String userId) throws Exception {
        
    	ResponseEntity<ResultDto> resEntity = null;
		String returnString = "";
    	
		OomUserDto reqOomUserDto = new OomUserDto();
		reqOomUserDto.setUserId(userId);
		
		// 사용자ID 중복체크...
		int userCount = CommonObjectUtil.defaultNumber(userService.readUserDuplicationCheck(reqOomUserDto));
		if (userCount > 0) {
			returnString = Const.Common.RESULT_CODE.SUCCESS;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_ALREADY_EXIST_USER_ID, userCount));
		} else {
			returnString = Const.Common.RESULT_CODE.SUCCESS;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, "", userCount));
		}
    	
    	return resEntity;
    }
	
	/**
	 * 
	 * createUser
	 *
	 * @param reqOomUserDto
	 * @return ResponseEntity
	 */
	@SuppressWarnings("rawtypes")
    @PostMapping(value="", produces="application/json; charset=UTF-8")
    public ResponseEntity createUser(@AuthenticationPrincipal JwtAuthResultDto authResultDto, 
    		@RequestBody UserProcessingDto reqUserProcessingDto) throws Exception {
        
    	ResponseEntity<ResultDto> resEntity = null;
		String returnString = "";
    	
		String loginUserId = StringUtils.defaultString(authResultDto.getUserId());
		if ("".equals(loginUserId)) {
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_LOGIN_USER_ID));
			return resEntity;
		}
		String mgrYn = StringUtils.defaultString(authResultDto.getMgrYn());
		if ("".equals(mgrYn)) {
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_MGR_YN));
			return resEntity;
		}
		//String loginUserId = "tsop-admin"; // 이후 세션에서 얻어올 값...
		
		String userId = StringUtils.defaultString(reqUserProcessingDto.getUserId());
		if ("".equals(userId)) {
			log.error(">>>>>> userId ERROR:{}", ERR_MSG_NULL_USER_ID);
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_USER_ID));
			return resEntity;
		}
		String userName = StringUtils.defaultString(reqUserProcessingDto.getUserName());
		if ("".equals(userName)) {
			log.error(">>>>>> userName ERROR:{}", ERR_MSG_NULL_USER_NAME);
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_USER_NAME));
			return resEntity;
		}
		String contactPhoneNum = StringUtils.defaultString(reqUserProcessingDto.getContactPhoneNum());
		if ("".equals(contactPhoneNum)) {
			log.error(">>>>>> contactPhoneNum ERROR:{}", ERR_MSG_NULL_CONTACT_PHONE_NUM);
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_CONTACT_PHONE_NUM));
			return resEntity;
		}
		String roleId = StringUtils.defaultString(reqUserProcessingDto.getRoleId());
		if ("".equals(roleId)) {
			log.error(">>>>>> roleId ERROR:{}", ERR_MSG_NULL_MENU_GROUP_ID);
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_MENU_GROUP_ID));
			return resEntity;
		}
		String getMgrYn = StringUtils.defaultString(reqUserProcessingDto.getMgrYn());
		if ("".equals(getMgrYn)) {
			log.error(">>>>>> getMgrYn ERROR:{}", ERR_MSG_NULL_MGR_YN);
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_MGR_YN));
			return resEntity;
		}
		String serviceOperYn = StringUtils.defaultString(reqUserProcessingDto.getServiceOperYn());
		if ("".equals(serviceOperYn)) {
			log.error(">>>>>> serviceOperYn ERROR:{}", ERR_MSG_NULL_SERVICE_OPER_YN);
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_SERVICE_OPER_YN));
			return resEntity;
		}
		if ("Y".equals(serviceOperYn)) {
			String tenantId = StringUtils.defaultString(reqUserProcessingDto.getTenantId());
			if ("".equals(tenantId)) {
    			log.error(">>>>>> tenantId ERROR:{}", ERR_MSG_NULL_TENANT_ID);
				returnString = Const.Common.RESULT_CODE.FAIL;
    			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_TENANT_ID));
    			return resEntity;
    		}
			// 서비스포털운영자가 2명이상인지 체크...
			OomUserDto reqOomUserDto = new OomUserDto();
    		reqOomUserDto.setUserId(userId);
    		reqOomUserDto.setTenantId(tenantId);
    		int serviceOperUserCount = userService.readUserDuplicationServiceOper(reqOomUserDto);
    		if (serviceOperUserCount > 0) {
    			returnString = Const.Common.RESULT_CODE.FAIL;
    			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_ALREADY_SERVICE_OPER_USER));
    			return resEntity;
    		}
		}
		
		reqUserProcessingDto.setAuditId(loginUserId);
		
		// 권한이 있는지 체크...
		if (!"Y".equals(mgrYn)) {
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_ABNORMAL_AUTH));
			return resEntity;
		}
		
		// 사용자 등록...
		int affectRowCount = userService.createUser(reqUserProcessingDto);
		if (affectRowCount < 1) {
			if (affectRowCount < 0) {
				returnString = Const.Common.RESULT_CODE.FAIL;
    			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_SMS_SEND_FAIL, affectRowCount));
			} else {
				returnString = Const.Common.RESULT_CODE.FAIL;
    			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_CREATE_FAIL, affectRowCount));
			}
		} else {
			returnString = Const.Common.RESULT_CODE.SUCCESS;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, "", affectRowCount));
		}
		
    	return resEntity;
    }
	
	/**
	 * 
	 * readUser
	 *
	 * @param userId
	 * @return ResponseEntity
	 */
	@SuppressWarnings("rawtypes")
    @GetMapping(value="/{userId:.+}", produces="application/json; charset=UTF-8")
    public ResponseEntity readUser(@PathVariable("userId") String userId) throws Exception {
        
    	ResponseEntity<ResultDto> resEntity = null;
		String returnString = "";
    	
		OomUserDto reqOomUserDto = new OomUserDto();
		reqOomUserDto.setUserId(userId);
		
		UserDetailResultDto userDetailResultDto = userService.readUser(reqOomUserDto);
		if (userDetailResultDto == null) {
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_READ_FAIL, userDetailResultDto));
		} else {
			returnString = Const.Common.RESULT_CODE.SUCCESS;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, "", userDetailResultDto));
		}
    	
    	return resEntity;
    }
	
	/**
	 * 
	 * updateUser
	 *
	 * @param userId
	 * @param reqOomUserDto
	 * @return ResponseEntity
	 */
	@SuppressWarnings("rawtypes")
    @PutMapping(value="/{userId:.+}", produces="application/json; charset=UTF-8")
    public ResponseEntity updateUser(@AuthenticationPrincipal JwtAuthResultDto authResultDto, 
    		@PathVariable("userId") String userId, @RequestBody UserProcessingDto reqUserProcessingDto) throws Exception {
        
    	ResponseEntity<ResultDto> resEntity = null;
		String returnString = "";
    	
		String loginUserId = StringUtils.defaultString(authResultDto.getUserId());
		if ("".equals(loginUserId)) {
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_LOGIN_USER_ID));
			return resEntity;
		}
		String mgrYn = StringUtils.defaultString(authResultDto.getMgrYn());
		if ("".equals(mgrYn)) {
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_MGR_YN));
			return resEntity;
		}
		//String loginUserId = "tsop-admin"; // 이후 세션에서 얻어올 값...
		
		String userName = StringUtils.defaultString(reqUserProcessingDto.getUserName());
		if ("".equals(userName)) {
			log.error(">>>>>> userName ERROR:{}", ERR_MSG_NULL_USER_NAME);
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_USER_NAME));
			return resEntity;
		}
		String contactPhoneNum = StringUtils.defaultString(reqUserProcessingDto.getContactPhoneNum());
		if ("".equals(contactPhoneNum)) {
			log.error(">>>>>> contactPhoneNum ERROR:{}", ERR_MSG_NULL_CONTACT_PHONE_NUM);
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_CONTACT_PHONE_NUM));
			return resEntity;
		}
		String roleId = StringUtils.defaultString(reqUserProcessingDto.getRoleId());
		if ("".equals(roleId)) {
			log.error(">>>>>> roleId ERROR:{}", ERR_MSG_NULL_MENU_GROUP_ID);
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_MENU_GROUP_ID));
			return resEntity;
		}
		String getMgrYn = StringUtils.defaultString(reqUserProcessingDto.getMgrYn());
		if ("".equals(getMgrYn)) {
			log.error(">>>>>> mgrYn ERROR:{}", ERR_MSG_NULL_MGR_YN);
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_MGR_YN));
			return resEntity;
		}
		String serviceOperYn = StringUtils.defaultString(reqUserProcessingDto.getServiceOperYn());
		if ("".equals(serviceOperYn)) {
			log.error(">>>>>> serviceOperYn ERROR:{}", ERR_MSG_NULL_SERVICE_OPER_YN);
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_SERVICE_OPER_YN));
			return resEntity;
		}
		if ("Y".equals(serviceOperYn)) {
			String tenantId = StringUtils.defaultString(reqUserProcessingDto.getTenantId());
			if ("".equals(tenantId)) {
    			log.error(">>>>>> tenantId ERROR:{}", ERR_MSG_NULL_TENANT_ID);
				returnString = Const.Common.RESULT_CODE.FAIL;
    			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_TENANT_ID));
    			return resEntity;
    		}
			// 서비스포털운영자가 2명이상인지 체크...
			OomUserDto reqOomUserDto = new OomUserDto();
    		reqOomUserDto.setUserId(userId);
    		reqOomUserDto.setTenantId(tenantId);
    		int serviceOperUserCount = userService.readUserDuplicationServiceOper(reqOomUserDto);
    		if (serviceOperUserCount > 0) {
    			returnString = Const.Common.RESULT_CODE.FAIL;
    			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_ALREADY_SERVICE_OPER_USER));
    			return resEntity;
    		}
		}
		
		reqUserProcessingDto.setUserId(userId);
		reqUserProcessingDto.setAuditId(loginUserId);
		
		// 권한이 있는지 체크...
		if (!"Y".equals(mgrYn)) {
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_ABNORMAL_AUTH));
			return resEntity;
		}
		
		// 사용자 수정...
		int affectRowCount = userService.updateUser(reqUserProcessingDto);
		if (affectRowCount < 1) {
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_UPDATE_FAIL, affectRowCount));
		} else {
			returnString = Const.Common.RESULT_CODE.SUCCESS;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, "", affectRowCount));
		}
    	
    	return resEntity;
    }
	
	/**
	 * 
	 * deleteUser
	 *
	 * @param userId
	 * @return ResponseEntity
	 */
	@SuppressWarnings("rawtypes")
    @DeleteMapping(value="/{userId:.+}", produces="application/json; charset=UTF-8")
    public ResponseEntity deleteUser(@AuthenticationPrincipal JwtAuthResultDto authResultDto, 
    		@PathVariable("userId") String userId) throws Exception {
        
    	ResponseEntity<ResultDto> resEntity = null;
		String returnString = "";
    	
		String loginUserId = StringUtils.defaultString(authResultDto.getUserId());
		if ("".equals(loginUserId)) {
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_LOGIN_USER_ID));
			return resEntity;
		}
		String mgrYn = StringUtils.defaultString(authResultDto.getMgrYn());
		if ("".equals(mgrYn)) {
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_MGR_YN));
			return resEntity;
		}
		//String loginUserId = "tsop-admin"; // 이후 세션에서 얻어올 값...
		
		OomUserDto reqOomUserDto = new OomUserDto();
		reqOomUserDto.setUserId(userId);
		reqOomUserDto.setAuditId(loginUserId);
		
		// 권한이 있는지 체크...
		if (!"Y".equals(mgrYn)) {
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_ABNORMAL_AUTH));
			return resEntity;
		}
		
		// 사용자 삭제...
		int affectRowCount = userService.deleteUser(reqOomUserDto);
		if (affectRowCount < 1) {
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_DELETE_FAIL, affectRowCount));
		} else {
			returnString = Const.Common.RESULT_CODE.SUCCESS;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, "", affectRowCount));
		}
    	
    	return resEntity;
    }

}
