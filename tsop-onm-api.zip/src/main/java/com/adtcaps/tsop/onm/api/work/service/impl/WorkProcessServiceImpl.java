package com.adtcaps.tsop.onm.api.work.service.impl;

import java.io.File;
import java.io.FileOutputStream;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.io.FileUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.poi.hssf.util.HSSFColor.HSSFColorPredefined;
import org.apache.poi.ss.usermodel.BorderStyle;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.FillPatternType;
import org.apache.poi.ss.usermodel.HorizontalAlignment;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.VerticalAlignment;
import org.apache.poi.ss.util.CellRangeAddress;
import org.apache.poi.xssf.streaming.SXSSFWorkbook;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.CollectionUtils;

import com.adtcaps.tsop.onm.api.building.service.BuildingService;
import com.adtcaps.tsop.onm.api.config.AzureBlobConfig;
import com.adtcaps.tsop.onm.api.deploy.domain.PackageDeployJobDetailResultDto;
import com.adtcaps.tsop.onm.api.deploy.service.PackageDeployJobService;
import com.adtcaps.tsop.onm.api.domain.OomBuildingDto;
import com.adtcaps.tsop.onm.api.domain.OomOnmResourceDto;
import com.adtcaps.tsop.onm.api.domain.OomPackageDeployJobDto;
import com.adtcaps.tsop.onm.api.domain.OomTechSupportRequestDto;
import com.adtcaps.tsop.onm.api.domain.OomWorkBuildingDto;
import com.adtcaps.tsop.onm.api.domain.OomWorkBuildingServiceConenctionDto;
import com.adtcaps.tsop.onm.api.domain.OomWorkBuildingServiceConnectionIpDto;
import com.adtcaps.tsop.onm.api.domain.OomWorkDto;
import com.adtcaps.tsop.onm.api.domain.OomWorkStatusDto;
import com.adtcaps.tsop.onm.api.domain.OomWorkTenantDto;
import com.adtcaps.tsop.onm.api.domain.OomWorkTenantResourceDetailDto;
import com.adtcaps.tsop.onm.api.domain.OomWorkTenantResourceDto;
import com.adtcaps.tsop.onm.api.file.domain.BlobRequestDto;
import com.adtcaps.tsop.onm.api.file.service.FileService;
import com.adtcaps.tsop.onm.api.helper.constant.Const;
import com.adtcaps.tsop.onm.api.helper.service.HelperService;
import com.adtcaps.tsop.onm.api.helper.util.CommonDateUtil;
import com.adtcaps.tsop.onm.api.helper.util.CommonObjectUtil;
import com.adtcaps.tsop.onm.api.resource.domain.ResourceCategoryForComboResultDto;
import com.adtcaps.tsop.onm.api.resource.service.ResourceService;
import com.adtcaps.tsop.onm.api.support.service.SupportService;
import com.adtcaps.tsop.onm.api.work.domain.CurrentWorkDetailResultDto;
import com.adtcaps.tsop.onm.api.work.domain.InterfaceWorkDetailResultDto;
import com.adtcaps.tsop.onm.api.work.domain.InterfaceWorkProcessDto;
import com.adtcaps.tsop.onm.api.work.domain.VerifyWorkProcessDto;
import com.adtcaps.tsop.onm.api.work.domain.SearchWorkConenctionDto;
import com.adtcaps.tsop.onm.api.work.domain.WorkBuildingServiceConnectionIpDto;
import com.adtcaps.tsop.onm.api.work.domain.SearchWorkConnectionIpDto;
import com.adtcaps.tsop.onm.api.work.domain.WorkBuildingServiceUseYnDto;
import com.adtcaps.tsop.onm.api.work.domain.WorkPackageDeployJobDto;
import com.adtcaps.tsop.onm.api.work.domain.WorkProcessingRequestDto;
import com.adtcaps.tsop.onm.api.work.domain.WorkProcessingResultDto;
import com.adtcaps.tsop.onm.api.work.domain.WorkServiceUseYnDto;
import com.adtcaps.tsop.onm.api.work.domain.WorkStatusDetailResultDto;
import com.adtcaps.tsop.onm.api.work.domain.WorkTenantResourceDetailDto;
import com.adtcaps.tsop.onm.api.work.domain.WorkTenantResourceDto;
import com.adtcaps.tsop.onm.api.work.mapper.OomWorkBuildingMapper;
import com.adtcaps.tsop.onm.api.work.mapper.OomWorkBuildingServiceConenctionMapper;
import com.adtcaps.tsop.onm.api.work.mapper.OomWorkBuildingServiceConnectionIpMapper;
import com.adtcaps.tsop.onm.api.work.mapper.OomWorkMapper;
import com.adtcaps.tsop.onm.api.work.mapper.OomWorkStatusMapper;
import com.adtcaps.tsop.onm.api.work.mapper.OomWorkTenantMapper;
import com.adtcaps.tsop.onm.api.work.mapper.OomWorkTenantResourceDetailMapper;
import com.adtcaps.tsop.onm.api.work.mapper.OomWorkTenantResourceMapper;
import com.adtcaps.tsop.onm.api.work.service.WorkFinishService;
import com.adtcaps.tsop.onm.api.work.service.WorkProcessService;
import com.adtcaps.tsop.onm.api.work.service.WorkService;

/**
 * 
 * <ul>
 * <li>업무 그룹명 : tsop-onm-api</li>
 * <li>서브 업무명 : com.adtcaps.tsop.onm.api.work.service.impl</li>
 * <li>설  명 : WorkProcessServiceImpl.java</li>
 * <li>작성일 : 2021. 1. 30.</li>
 * <li>작성자 : jeonyb4</li>
 * </ul>
 */
@Transactional
@Service
public class WorkProcessServiceImpl implements WorkProcessService {
	
	@Autowired
	private AzureBlobConfig azureBlobConfig;
	
	@Autowired
	private OomWorkMapper oomWorkMapper;
	
	@Autowired
	private OomWorkStatusMapper oomWorkStatusMapper;
	
	@Autowired
	private OomWorkTenantMapper oomWorkTenantMapper;
	
	@Autowired
	private OomWorkBuildingMapper oomWorkBuildingMapper;
	
	@Autowired
	private OomWorkBuildingServiceConenctionMapper oomWorkBuildingServiceConenctionMapper;
	
	@Autowired
	private OomWorkBuildingServiceConnectionIpMapper oomWorkBuildingServiceConnectionIpMapper;
	
	@Autowired
	private OomWorkTenantResourceMapper oomWorkTenantResourceMapper;
	
	@Autowired
	private OomWorkTenantResourceDetailMapper oomWorkTenantResourceDetailMapper;
	
	@Autowired
	private FileService fileService;
	
	@Autowired
	private HelperService helperService;
	
	@Autowired
	private WorkService workService;
	
	@Autowired
	private SupportService supportService;
	
	@Autowired
	private PackageDeployJobService packageDeployJobService;
	
	@Autowired
	private ResourceService resourceService;
	
	@Autowired
	private BuildingService buildingService;
	
	@Autowired
	private WorkFinishService workFinishService;
	
	/**
	 * 
	 * processWork
	 *
	 * @param reqWorkProcessingRequestDto
	 * @return WorkProcessingResultDto
	 * @throws Exception 
	 */
	@Transactional(rollbackFor={Exception.class, DataIntegrityViolationException.class})
	@Override
	public WorkProcessingResultDto processWork(WorkProcessingRequestDto reqWorkProcessingRequestDto) throws Exception {
		
		WorkProcessingResultDto workProcessingResultDto = null;
		
		try {
			int onmWorkId = reqWorkProcessingRequestDto.getOnmWorkId();
			String onmWorkTypeCd = StringUtils.defaultString(reqWorkProcessingRequestDto.getOnmWorkTypeCd());
			String currentWorkStatusCd = StringUtils.defaultString(reqWorkProcessingRequestDto.getCurrentWorkStatusCd());
			String currentWorkStatusDetailCd = StringUtils.defaultString(reqWorkProcessingRequestDto.getCurrentWorkStatusDetailCd());
			String currentWorkStatusFinishCd = StringUtils.defaultString(reqWorkProcessingRequestDto.getCurrentWorkStatusFinishCd());
			String nextWorkStatusCd = StringUtils.defaultString(reqWorkProcessingRequestDto.getNextWorkStatusCd());
			String currentTenantId = StringUtils.defaultString(reqWorkProcessingRequestDto.getCurrentTenantId());
			int techSupportReqId = CommonObjectUtil.defaultNumber(reqWorkProcessingRequestDto.getTechSupportReqId());
			
			String auditId = reqWorkProcessingRequestDto.getAuditId();
			
			// 현재 메뉴CD와 다음 메뉴CD
			String prefixOneWorkStatusCd = StringUtils.substring(currentWorkStatusCd, 0, 1);
			String prefixTwoWorkStatusCd = StringUtils.substring(currentWorkStatusCd, 0, 2);
			
			if ("R".equals(prefixOneWorkStatusCd) || "C".equals(prefixOneWorkStatusCd) || "DP".equals(prefixTwoWorkStatusCd)) {
				// 등록/수정/배포 작업에 대한 현재 메뉴 처리
				String postfixWorkStatusCd = StringUtils.substring(currentWorkStatusCd, 2);
				if ("VF".equals(postfixWorkStatusCd)) {
					List<VerifyWorkProcessDto> reqVerifyWorkProcessDtoList = reqWorkProcessingRequestDto.getVerifyWorkList();
					if (!CollectionUtils.isEmpty(reqVerifyWorkProcessDtoList)) {
						for (VerifyWorkProcessDto reqVerifyWorkProcessDto : reqVerifyWorkProcessDtoList) {
							OomWorkStatusDto reqOomWorkStatusDto = new OomWorkStatusDto();
							BeanUtils.copyProperties(reqVerifyWorkProcessDto, reqOomWorkStatusDto);
							BlobRequestDto blobRequestDto = reqVerifyWorkProcessDto.getAttachFile();
							if (blobRequestDto != null) {
								// 기존 첨부파일이 존재하는 지 확인...
								WorkStatusDetailResultDto workStatusDetailResultDto = oomWorkStatusMapper.readOomWorkStatusAttachFile(reqOomWorkStatusDto);
								if (workStatusDetailResultDto != null) {
									int oldAttachFileNum = CommonObjectUtil.defaultNumber(workStatusDetailResultDto.getAttachFileNum());
									if (oldAttachFileNum > 0) {
										// 기존 첨부파일 삭제
										fileService.deleteAttachFile(Const.Definition.BLOB_CONTAINER.FILE, oldAttachFileNum);
									}
								}
								// 신규 첨부파일 등록
								blobRequestDto.setContainerName(Const.Definition.BLOB_CONTAINER.FILE);
								blobRequestDto.setBlobBaseDir(Const.Definition.BLOB_BASEDIR.WORK);
								int attachFileNum = fileService.createAttachFile(blobRequestDto);
								if (attachFileNum > 0) {
									reqOomWorkStatusDto.setAttachFileNum(attachFileNum);
								}
							}
							// onmWorkStatusDetailCd와 onmWorkStatusFinishCd는 각각 들어 있으므로...
							reqOomWorkStatusDto.setOnmWorkId(onmWorkId);
							reqOomWorkStatusDto.setOnmWorkTypeCd(onmWorkTypeCd);
							reqOomWorkStatusDto.setOnmWorkStatusCd(currentWorkStatusCd);
							//reqOomWorkStatusDto.setOnmWorkStatusFinishCd(currentWorkStatusFinishCd);
							reqOomWorkStatusDto.setAuditId(auditId);
							oomWorkStatusMapper.mergeOomWorkStatus(reqOomWorkStatusDto);
						}
					}
				} else {
					if (Const.Code.WORK_STATUS_DETAIL_CD.TN01.equals(currentWorkStatusDetailCd)) {
						// 테넌트 작업 처리...
						OomWorkTenantDto reqOomWorkTenantDto = reqWorkProcessingRequestDto.getTenantInfo();
						if (reqOomWorkTenantDto != null) {
							reqOomWorkTenantDto.setOnmWorkId(onmWorkId);
							reqOomWorkTenantDto.setOnmWorkStatusFinishCd(currentWorkStatusFinishCd);
							reqOomWorkTenantDto.setAuditId(auditId);
							reqOomWorkTenantDto.setUseYn("Y");
							oomWorkTenantMapper.mergeOomWorkTenant(reqOomWorkTenantDto);
							// 작업 테이블에 새로 생성된 tenant_id를 업데이트 하자.. (나중에 운영환경 등에서 쓰인다...)
							OomWorkTenantDto rsltOomWorkTenantDto = oomWorkTenantMapper.readOomWorkTenant(reqOomWorkTenantDto);
							if (rsltOomWorkTenantDto != null) {
								String newTenantId = rsltOomWorkTenantDto.getTenantId();
								OomWorkDto reqOomWorkDto = new OomWorkDto();
								reqOomWorkDto.setOnmWorkId(onmWorkId);
								reqOomWorkDto.setAuditId(auditId);
								reqOomWorkDto.setTenantId(newTenantId);
								oomWorkMapper.updateOomWorkTenantId(reqOomWorkDto);
							}
						}
					} else if (Const.Code.WORK_STATUS_DETAIL_CD.BD01.equals(currentWorkStatusDetailCd)) {
						// 빌딩 작업 처리...
						if ("C".equals(prefixOneWorkStatusCd)) {
							List<OomWorkBuildingDto> reqOomWorkBuildingDtoList = reqWorkProcessingRequestDto.getBuildingList();
							if (!CollectionUtils.isEmpty(reqOomWorkBuildingDtoList)) {
								for (OomWorkBuildingDto reqOomWorkBuildingDto : reqOomWorkBuildingDtoList) {
									reqOomWorkBuildingDto.setOnmWorkId(onmWorkId);
									reqOomWorkBuildingDto.setOnmWorkStatusFinishCd(currentWorkStatusFinishCd);
									reqOomWorkBuildingDto.setAuditId(auditId);
									reqOomWorkBuildingDto.setUseYn("Y");
									oomWorkBuildingMapper.mergeOomWorkBuilding(reqOomWorkBuildingDto);
									break;
								}
							}
						} else {
							// 기존 작업 빌딩 삭제...
							OomWorkBuildingDto delOomWorkBuildingDto = new OomWorkBuildingDto();
							delOomWorkBuildingDto.setOnmWorkId(onmWorkId);
							oomWorkBuildingMapper.deleteOomWorkBuilding(delOomWorkBuildingDto);
							// 빌딩 등록...
							List<OomWorkBuildingDto> reqOomWorkBuildingDtoList = reqWorkProcessingRequestDto.getBuildingList();
							if (!CollectionUtils.isEmpty(reqOomWorkBuildingDtoList)) {
								for (OomWorkBuildingDto reqOomWorkBuildingDto : reqOomWorkBuildingDtoList) {
									reqOomWorkBuildingDto.setOnmWorkId(onmWorkId);
									reqOomWorkBuildingDto.setOnmWorkStatusFinishCd(currentWorkStatusFinishCd);
									reqOomWorkBuildingDto.setAuditId(auditId);
									reqOomWorkBuildingDto.setUseYn("Y");
									oomWorkBuildingMapper.insertOomWorkBuilding(reqOomWorkBuildingDto);
								}
							}
						}
					} else if (Const.Code.WORK_STATUS_DETAIL_CD.SV01.equals(currentWorkStatusDetailCd)) {
						// 서비스 (연동) 작업 처리 (서비스구분코드만)...
						// 기존 작업 서비스 삭제...
						OomWorkBuildingServiceConenctionDto delOomWorkBuildingServiceConenctionDto = new OomWorkBuildingServiceConenctionDto();
						delOomWorkBuildingServiceConenctionDto.setOnmWorkId(onmWorkId);
						oomWorkBuildingServiceConenctionMapper.deleteOomWorkBuildingServiceConenction(delOomWorkBuildingServiceConenctionDto);
						// 서비스 등록...
						List<OomWorkBuildingServiceConenctionDto> reqOomWorkBuildingServiceConenctionDtoList = reqWorkProcessingRequestDto.getServiceList();
						if (!CollectionUtils.isEmpty(reqOomWorkBuildingServiceConenctionDtoList)) {
							for (OomWorkBuildingServiceConenctionDto reqOomWorkBuildingServiceConenctionDto : reqOomWorkBuildingServiceConenctionDtoList) {
								reqOomWorkBuildingServiceConenctionDto.setOnmWorkId(onmWorkId);
								reqOomWorkBuildingServiceConenctionDto.setAuditId(auditId);
								reqOomWorkBuildingServiceConenctionDto.setWebAppUseYn("Y");
								reqOomWorkBuildingServiceConenctionDto.setUseYn("Y");
								oomWorkBuildingServiceConenctionMapper.insertOomWorkBuildingServiceConenction(reqOomWorkBuildingServiceConenctionDto);
							}
						}
					} else if (Const.Code.WORK_STATUS_DETAIL_CD.SI01.equals(currentWorkStatusDetailCd)) {
						// 서비스 연동 작업 처리...
						List<WorkBuildingServiceConnectionIpDto> reqWorkBuildingServiceConnectionIpDtoList = reqWorkProcessingRequestDto.getServiceConnectionIpList();
						if (!CollectionUtils.isEmpty(reqWorkBuildingServiceConnectionIpDtoList)) {
							// 기존 연동IP 삭제...
							OomWorkBuildingServiceConnectionIpDto delOomWorkBuildingServiceConnectionIpDto = new OomWorkBuildingServiceConnectionIpDto();
							delOomWorkBuildingServiceConnectionIpDto.setOnmWorkId(onmWorkId);
							oomWorkBuildingServiceConnectionIpMapper.deleteOomWorkBuildingServiceConnectionIp(delOomWorkBuildingServiceConnectionIpDto);
							for (WorkBuildingServiceConnectionIpDto reqWorkBuildingServiceConnectionIpDto : reqWorkBuildingServiceConnectionIpDtoList) {
								OomWorkBuildingServiceConenctionDto reqOomWorkBuildingServiceConenctionDto = new OomWorkBuildingServiceConenctionDto();
								BeanUtils.copyProperties(reqWorkBuildingServiceConnectionIpDto, reqOomWorkBuildingServiceConenctionDto);
								
								List<OomWorkBuildingServiceConnectionIpDto> reqOomWorkBuildingServiceConnectionIpDtoList = reqWorkBuildingServiceConnectionIpDto.getServiceConnectionIpList();
								if (reqOomWorkBuildingServiceConenctionDto != null) {
									reqOomWorkBuildingServiceConenctionDto.setOnmWorkId(onmWorkId);
									reqOomWorkBuildingServiceConenctionDto.setAuditId(auditId);
									reqOomWorkBuildingServiceConenctionDto.setUseYn("Y");
									oomWorkBuildingServiceConenctionMapper.mergeOomWorkBuildingServiceConenction(reqOomWorkBuildingServiceConenctionDto);
									
									String bldId = reqOomWorkBuildingServiceConenctionDto.getBldId();
									String serviceClCd = reqOomWorkBuildingServiceConenctionDto.getServiceClCd();
									if (!CollectionUtils.isEmpty(reqOomWorkBuildingServiceConnectionIpDtoList)) {
										for (OomWorkBuildingServiceConnectionIpDto reqOomWorkBuildingServiceConnectionIpDto : reqOomWorkBuildingServiceConnectionIpDtoList) {
											reqOomWorkBuildingServiceConnectionIpDto.setOnmWorkId(onmWorkId);
											reqOomWorkBuildingServiceConnectionIpDto.setBldId(bldId);
											reqOomWorkBuildingServiceConnectionIpDto.setServiceClCd(serviceClCd);
											reqOomWorkBuildingServiceConnectionIpDto.setAuditId(auditId);
											oomWorkBuildingServiceConnectionIpMapper.insertOomWorkBuildingServiceConnectionIp(reqOomWorkBuildingServiceConnectionIpDto);
										}
									}
								}
							}
						}
					} else if (Const.Code.WORK_STATUS_DETAIL_CD.IF01.equals(currentWorkStatusDetailCd)) {
						// 인터페이스 작업 처리...
						List<InterfaceWorkProcessDto> reqInterfaceWorkProcessDtoList = reqWorkProcessingRequestDto.getInterfaceList();
						if (!CollectionUtils.isEmpty(reqInterfaceWorkProcessDtoList)) {
							for (InterfaceWorkProcessDto reqInterfaceWorkProcessDto : reqInterfaceWorkProcessDtoList) {
								OomWorkBuildingServiceConenctionDto reqOomWorkBuildingServiceConenctionDto = new OomWorkBuildingServiceConenctionDto();
								BeanUtils.copyProperties(reqInterfaceWorkProcessDto, reqOomWorkBuildingServiceConenctionDto);
								reqOomWorkBuildingServiceConenctionDto.setOnmWorkId(onmWorkId);
								BlobRequestDto blobRequestDto = reqInterfaceWorkProcessDto.getAttachFile();
								if (blobRequestDto != null) {
									// 기존 첨부파일이 존재하는 지 확인...
									InterfaceWorkDetailResultDto interfaceWorkDetailResultDto = oomWorkBuildingServiceConenctionMapper.readInterfaceWorkDetailAttachFile(reqOomWorkBuildingServiceConenctionDto);
									if (interfaceWorkDetailResultDto != null) {
										int oldAttachFileNum = CommonObjectUtil.defaultNumber(interfaceWorkDetailResultDto.getAttachFileNum());
										if (oldAttachFileNum > 0) {
											// 기존 첨부파일 삭제
											fileService.deleteAttachFile(Const.Definition.BLOB_CONTAINER.FILE, oldAttachFileNum);
										}
									}
									// 신규 첨부파일 등록
									blobRequestDto.setContainerName(Const.Definition.BLOB_CONTAINER.FILE);
									blobRequestDto.setBlobBaseDir(Const.Definition.BLOB_BASEDIR.WORK);
									int attachFileNum = fileService.createAttachFile(blobRequestDto);
									if (attachFileNum > 0) {
										reqOomWorkBuildingServiceConenctionDto.setAttachFileNum(attachFileNum);
									}
								}
								reqOomWorkBuildingServiceConenctionDto.setAuditId(auditId);
								reqOomWorkBuildingServiceConenctionDto.setUseYn("Y");
								oomWorkBuildingServiceConenctionMapper.updateOomWorkBuildingServiceConenctionInterface(reqOomWorkBuildingServiceConenctionDto);
							}
						}
					} else if (Const.Code.WORK_STATUS_DETAIL_CD.RS01.equals(currentWorkStatusDetailCd)) {
						// 운영환경 작업 처리...
						WorkTenantResourceDto reqWorkTenantResourceDto = reqWorkProcessingRequestDto.getTenantResourceInfo();
						if (reqWorkTenantResourceDto != null) {
							List<WorkTenantResourceDetailDto> reqWorkTenantResourceDetailDtoList = reqWorkTenantResourceDto.getResourceDetailList();
							if (!CollectionUtils.isEmpty(reqWorkTenantResourceDetailDtoList)) {
								// 데이터 검증 작업...
								for (int idx = 0; idx < reqWorkTenantResourceDetailDtoList.size(); idx++) {
									WorkTenantResourceDetailDto reqWorkTenantResourceDetailDto = reqWorkTenantResourceDetailDtoList.get(idx);
									String onmResourceCategoryCdName = StringUtils.defaultString(reqWorkTenantResourceDetailDto.getOnmResourceCategoryCdName());
									if ("".equals(onmResourceCategoryCdName)) {
										workProcessingResultDto = new WorkProcessingResultDto();
										workProcessingResultDto.setErrorMessage("구분명은 필수입력 사항입니다.");
										return workProcessingResultDto;
									} else {
										if (Const.Definition.COMMON_VAL.SUPER_RESOURCE_CATEGORY_CD_NAME.equals(onmResourceCategoryCdName)) {
											String superOnmResourceName = StringUtils.defaultString(reqWorkTenantResourceDetailDto.getSuperOnmResourceName());
											if (!"".equals(superOnmResourceName)) {
												workProcessingResultDto = new WorkProcessingResultDto();
												workProcessingResultDto.setErrorMessage("App Plan에 대한 App Plan은 존재할 수 없습니다.");
												return workProcessingResultDto;
											}
										}
										OomOnmResourceDto reqOomOnmResourceDto = new OomOnmResourceDto();
										reqOomOnmResourceDto.setOnmResourceCategoryCdName(onmResourceCategoryCdName);
										ResourceCategoryForComboResultDto resourceCategoryForComboResultDto = resourceService.readResourceCategoryIdByName(reqOomOnmResourceDto);
										if (resourceCategoryForComboResultDto == null) {
											workProcessingResultDto = new WorkProcessingResultDto();
											workProcessingResultDto.setErrorMessage("잘못된 구분명이 존재합니다.");
											return workProcessingResultDto;
										}
										String onmResourceCategoryCd = StringUtils.defaultString(resourceCategoryForComboResultDto.getOnmResourceCategoryCd());
										reqWorkTenantResourceDetailDto.setOnmResourceCategoryCd(onmResourceCategoryCd);
										reqWorkTenantResourceDetailDtoList.set(idx, reqWorkTenantResourceDetailDto);
									}
									
									String superOnmResourceName = StringUtils.defaultString(reqWorkTenantResourceDetailDto.getSuperOnmResourceName());
									if (!"".equals(superOnmResourceName)) {
										boolean findFlag = false;
										for (WorkTenantResourceDetailDto verifyWorkTenantResourceDetailDto : reqWorkTenantResourceDetailDtoList) {
											String onmResourceName = StringUtils.defaultString(verifyWorkTenantResourceDetailDto.getOnmResourceName());
											if (superOnmResourceName.equals(onmResourceName)) {
												findFlag = true;
												break;
											}
										}
										if (!findFlag) {
											workProcessingResultDto = new WorkProcessingResultDto();
											workProcessingResultDto.setErrorMessage("App Plan에 대한 리소스명이 없습니다.");
											return workProcessingResultDto;
										}
									}
									
									String onmResourceName = StringUtils.defaultString(reqWorkTenantResourceDetailDto.getOnmResourceName());
									for (int compIdx = 0; compIdx < reqWorkTenantResourceDetailDtoList.size(); compIdx++) {
										if (idx == compIdx) {
											continue;
										}
										WorkTenantResourceDetailDto verifyWorkTenantResourceDetailDto = reqWorkTenantResourceDetailDtoList.get(compIdx);
										String compOnmResourceName = StringUtils.defaultString(verifyWorkTenantResourceDetailDto.getOnmResourceName());
										if (onmResourceName.equals(compOnmResourceName)) {
											workProcessingResultDto = new WorkProcessingResultDto();
											workProcessingResultDto.setErrorMessage("동일한 리소스명은 사용할 수 없습니다.");
											return workProcessingResultDto;
										}
									}
								}
							}
							
							reqWorkTenantResourceDto.setOnmWorkId(onmWorkId);
							reqWorkTenantResourceDto.setAuditId(auditId);
							reqWorkTenantResourceDto.setOnmWorkStatusFinishCd(currentWorkStatusFinishCd);
							reqWorkTenantResourceDto.setUseYn("Y");
							
							OomWorkTenantResourceDto reqOomWorkTenantResourceDto = new OomWorkTenantResourceDto();
							BeanUtils.copyProperties(reqWorkTenantResourceDto, reqOomWorkTenantResourceDto);
							
							oomWorkTenantResourceMapper.mergeOomWorkTenantResource(reqOomWorkTenantResourceDto);
							
							// 기존 데이터 삭제...
							OomWorkTenantResourceDetailDto delOomWorkTenantResourceDetailDto = new OomWorkTenantResourceDetailDto();
							delOomWorkTenantResourceDetailDto.setOnmWorkId(onmWorkId);
							oomWorkTenantResourceDetailMapper.deleteOomWorkTenantResourceDetail(delOomWorkTenantResourceDetailDto);
							
							if (!CollectionUtils.isEmpty(reqWorkTenantResourceDetailDtoList)) {
								String rscTenantId = StringUtils.defaultString(reqWorkTenantResourceDto.getTenantId());
								for (WorkTenantResourceDetailDto reqWorkTenantResourceDetailDto : reqWorkTenantResourceDetailDtoList) {
									// 신규 데이터 등록...
									OomWorkTenantResourceDetailDto reqOomWorkTenantResourceDetailDto = new OomWorkTenantResourceDetailDto();
									BeanUtils.copyProperties(reqWorkTenantResourceDetailDto, reqOomWorkTenantResourceDetailDto);
									
									reqOomWorkTenantResourceDetailDto.setOnmWorkId(onmWorkId);
									reqOomWorkTenantResourceDetailDto.setTenantId(rscTenantId);
									reqOomWorkTenantResourceDetailDto.setAuditId(auditId);
									reqOomWorkTenantResourceDetailDto.setRegisterId(auditId);
									oomWorkTenantResourceDetailMapper.createOomWorkTenantResourceDetail(reqOomWorkTenantResourceDetailDto);
								}
								
								// super_onm_resource_id 업데이트를 위해 한번더 loop
								for (WorkTenantResourceDetailDto reqWorkTenantResourceDetailDto : reqWorkTenantResourceDetailDtoList) {
									String superOnmResourceName = StringUtils.defaultString(reqWorkTenantResourceDetailDto.getSuperOnmResourceName());
									if (!"".equals(superOnmResourceName)) {
										for (WorkTenantResourceDetailDto verifyWorkTenantResourceDetailDto : reqWorkTenantResourceDetailDtoList) {
											String onmResourceName = StringUtils.defaultString(verifyWorkTenantResourceDetailDto.getOnmResourceName());
											if (superOnmResourceName.equals(onmResourceName)) {
												OomWorkTenantResourceDetailDto modiOomWorkTenantResourceDetailDto = new OomWorkTenantResourceDetailDto();
												modiOomWorkTenantResourceDetailDto.setOnmWorkId(onmWorkId);
												modiOomWorkTenantResourceDetailDto.setSuperOnmResourceName(superOnmResourceName);
												oomWorkTenantResourceDetailMapper.updateWorkTenantResourceDetailSuperResourceIdByName(modiOomWorkTenantResourceDetailDto);
												break;
											}
										}
									}
								}
							}
						}
					}
					// 현재 작업상태 수정...
					OomWorkStatusDto reqOomWorkStatusDto = new OomWorkStatusDto();
					reqOomWorkStatusDto.setOnmWorkId(onmWorkId);
					reqOomWorkStatusDto.setOnmWorkTypeCd(onmWorkTypeCd);
					reqOomWorkStatusDto.setOnmWorkStatusCd(currentWorkStatusCd);
					reqOomWorkStatusDto.setOnmWorkStatusDetailCd(currentWorkStatusDetailCd);
					reqOomWorkStatusDto.setOnmWorkStatusFinishCd(currentWorkStatusFinishCd);
					reqOomWorkStatusDto.setAuditId(auditId);
					oomWorkStatusMapper.updateOomWorkStatusFinishCode(reqOomWorkStatusDto);
				}
				
			} else {
				// 삭제 작업에 대한 현재 메뉴 처리
				if (Const.Code.WORK_STATUS_DETAIL_CD.TN01.equals(currentWorkStatusDetailCd)) {
					// 테넌트 작업 처리...
					OomWorkTenantDto reqOomWorkTenantDto = reqWorkProcessingRequestDto.getTenantInfo();
					if (reqOomWorkTenantDto != null) {
						reqOomWorkTenantDto.setOnmWorkId(onmWorkId);
						reqOomWorkTenantDto.setOnmWorkStatusFinishCd(currentWorkStatusFinishCd);
						reqOomWorkTenantDto.setAuditId(auditId);
						reqOomWorkTenantDto.setUseYn("N");
						oomWorkTenantMapper.updateOomWorkTenantUseYn(reqOomWorkTenantDto);
					}
				} else if (Const.Code.WORK_STATUS_DETAIL_CD.BD01.equals(currentWorkStatusDetailCd)) {
					// 빌딩 작업 처리...
					List<OomWorkBuildingDto> reqOomWorkBuildingDtoList = reqWorkProcessingRequestDto.getBuildingList();
					if (!CollectionUtils.isEmpty(reqOomWorkBuildingDtoList)) {
						for (OomWorkBuildingDto reqOomWorkBuildingDto : reqOomWorkBuildingDtoList) {
							reqOomWorkBuildingDto.setOnmWorkId(onmWorkId);
							reqOomWorkBuildingDto.setOnmWorkStatusFinishCd(currentWorkStatusFinishCd);
							reqOomWorkBuildingDto.setAuditId(auditId);
							reqOomWorkBuildingDto.setUseYn("N");
							oomWorkBuildingMapper.updateOomWorkBuildingUseYn(reqOomWorkBuildingDto);
						}
					}
				} else if (Const.Code.WORK_STATUS_DETAIL_CD.SV01.equals(currentWorkStatusDetailCd)) {
					// 서비스 (연동) 작업 처리 (서비스구분코드만)...
					List<OomWorkBuildingServiceConenctionDto> reqOomWorkBuildingServiceConenctionDtoList = reqWorkProcessingRequestDto.getServiceList();
					if (!CollectionUtils.isEmpty(reqOomWorkBuildingServiceConenctionDtoList)) {
						for (OomWorkBuildingServiceConenctionDto reqOomWorkBuildingServiceConenctionDto : reqOomWorkBuildingServiceConenctionDtoList) {
							reqOomWorkBuildingServiceConenctionDto.setOnmWorkId(onmWorkId);
							reqOomWorkBuildingServiceConenctionDto.setAuditId(auditId);
							reqOomWorkBuildingServiceConenctionDto.setUseYn("N");
							oomWorkBuildingServiceConenctionMapper.updateOomWorkBuildingServiceConenctionUseYn(reqOomWorkBuildingServiceConenctionDto);
						}
					}
				} else if (Const.Code.WORK_STATUS_DETAIL_CD.SI01.equals(currentWorkStatusDetailCd)) {
					// 서비스 연동 작업 처리...
					List<WorkBuildingServiceConnectionIpDto> reqWorkBuildingServiceConnectionIpDtoList = reqWorkProcessingRequestDto.getServiceConnectionIpList();
					if (!CollectionUtils.isEmpty(reqWorkBuildingServiceConnectionIpDtoList)) {
						for (WorkBuildingServiceConnectionIpDto reqWorkBuildingServiceConnectionIpDto : reqWorkBuildingServiceConnectionIpDtoList) {
							OomWorkBuildingServiceConenctionDto reqOomWorkBuildingServiceConenctionDto = new OomWorkBuildingServiceConenctionDto();
							BeanUtils.copyProperties(reqWorkBuildingServiceConnectionIpDto, reqOomWorkBuildingServiceConenctionDto);
							if (reqOomWorkBuildingServiceConenctionDto != null) {
								reqOomWorkBuildingServiceConenctionDto.setOnmWorkId(onmWorkId);
								reqOomWorkBuildingServiceConenctionDto.setAuditId(auditId);
								reqOomWorkBuildingServiceConenctionDto.setUseYn("N");
								oomWorkBuildingServiceConenctionMapper.updateOomWorkBuildingServiceConenctionUseYn(reqOomWorkBuildingServiceConenctionDto);
							}
						}
					}
				} else if (Const.Code.WORK_STATUS_DETAIL_CD.RS01.equals(currentWorkStatusDetailCd)) {
					// 운영환경 작업 처리...
					WorkTenantResourceDto reqWorkTenantResourceDto = reqWorkProcessingRequestDto.getTenantResourceInfo();
					if (reqWorkTenantResourceDto != null) {
						reqWorkTenantResourceDto.setOnmWorkId(onmWorkId);
						reqWorkTenantResourceDto.setAuditId(auditId);
						reqWorkTenantResourceDto.setUseYn("N");
						
						OomWorkTenantResourceDto reqOomWorkTenantResourceDto = new OomWorkTenantResourceDto();
						BeanUtils.copyProperties(reqWorkTenantResourceDto, reqOomWorkTenantResourceDto);
						
						oomWorkTenantResourceMapper.updateOomWorkTenantResourceUseYn(reqOomWorkTenantResourceDto);
					}
				}
				
				OomWorkStatusDto reqOomWorkStatusDto = new OomWorkStatusDto();
				reqOomWorkStatusDto.setOnmWorkId(onmWorkId);
				reqOomWorkStatusDto.setOnmWorkTypeCd(onmWorkTypeCd);
				reqOomWorkStatusDto.setOnmWorkStatusCd(currentWorkStatusCd);
				reqOomWorkStatusDto.setOnmWorkStatusDetailCd(currentWorkStatusDetailCd);
				reqOomWorkStatusDto.setOnmWorkStatusFinishCd(currentWorkStatusFinishCd);
				reqOomWorkStatusDto.setAuditId(auditId);
				oomWorkStatusMapper.updateOomWorkStatusFinishCode(reqOomWorkStatusDto);
			}
			
			if (Const.Code.WORK_STATUS_DETAIL_CD.DP01.equals(currentWorkStatusDetailCd)) {
				// 운영배포 작업 처리는 등록/수정/삭제 공통...
				WorkPackageDeployJobDto reqWorkPackageDeployJobDto = reqWorkProcessingRequestDto.getPackageDeployInfo();
				if (reqWorkPackageDeployJobDto != null) {
					OomPackageDeployJobDto reqOomPackageDeployJobDto = new OomPackageDeployJobDto();
					BeanUtils.copyProperties(reqWorkPackageDeployJobDto, reqOomPackageDeployJobDto);
					BlobRequestDto verifyProcedureBlobRequestDto = reqWorkPackageDeployJobDto.getVerifyProcedureAttachFile();
					BlobRequestDto workProcedureBlobRequestDto = reqWorkPackageDeployJobDto.getWorkProcedureAttachFile();
					BlobRequestDto inspectionProcedureBlobRequestDto = reqWorkPackageDeployJobDto.getInspectionProcedureAttachFile();
					BlobRequestDto dbScriptBlobRequestDto = reqWorkPackageDeployJobDto.getDbScriptAttachFile();
					BlobRequestDto inspectionResultBlobRequestDto = reqWorkPackageDeployJobDto.getInspectionResultAttachFile();
					
					String workScheduleDatetime = StringUtils.defaultString(reqOomPackageDeployJobDto.getWorkScheduleDatetime());
					if (!"".equals(workScheduleDatetime)) {
						workScheduleDatetime = CommonDateUtil.makeFromDatetime(workScheduleDatetime);
						reqOomPackageDeployJobDto.setWorkScheduleDatetime(workScheduleDatetime);
					}
					String reexecDatetime = StringUtils.defaultString(reqOomPackageDeployJobDto.getReexecDatetime());
					if (!"".equals(reexecDatetime)) {
						reexecDatetime = CommonDateUtil.makeFromDatetime(reexecDatetime);
						reqOomPackageDeployJobDto.setReexecDatetime(reexecDatetime);
					}
					
					// 기존 첨부파일들이 존재하는지 확인하기 위해 등록정보 조회...
					if (verifyProcedureBlobRequestDto != null) {
						PackageDeployJobDetailResultDto verifyProcedureAttachFileDto = packageDeployJobService.readVerifyProcedureAttachFile(reqOomPackageDeployJobDto);
						if (verifyProcedureAttachFileDto != null) {
							// 기존 첨부파일 삭제
							int oldVerifyProcedureAttachFileNum = CommonObjectUtil.defaultNumber(verifyProcedureAttachFileDto.getVerifyProcedureAttachFileNum());
							if (oldVerifyProcedureAttachFileNum > 0) {
								fileService.deleteAttachFile(Const.Definition.BLOB_CONTAINER.FILE, oldVerifyProcedureAttachFileNum);
							}
						}
					}
					if (workProcedureBlobRequestDto != null) {
						PackageDeployJobDetailResultDto workProcedureAttachFileDto = packageDeployJobService.readWorkProcedureAttachFile(reqOomPackageDeployJobDto);
						if (workProcedureAttachFileDto != null) {
							// 기존 첨부파일 삭제
							int oldWorkProcedureAttachFileNum = CommonObjectUtil.defaultNumber(workProcedureAttachFileDto.getWorkProcedureAttachFileNum());
							if (oldWorkProcedureAttachFileNum > 0) {
								fileService.deleteAttachFile(Const.Definition.BLOB_CONTAINER.FILE, oldWorkProcedureAttachFileNum);
							}
						}
					}
					if (inspectionProcedureBlobRequestDto != null) {
						PackageDeployJobDetailResultDto inspectionProcedureAttachFileDto = packageDeployJobService.readInspectionProcedureAttachFile(reqOomPackageDeployJobDto);
						if (inspectionProcedureAttachFileDto != null) {
							// 기존 첨부파일 삭제
							int oldInspectionProcedureAttachFileNum = CommonObjectUtil.defaultNumber(inspectionProcedureAttachFileDto.getInspectionProcedureAttachFileNum());
							if (oldInspectionProcedureAttachFileNum > 0) {
								fileService.deleteAttachFile(Const.Definition.BLOB_CONTAINER.FILE, oldInspectionProcedureAttachFileNum);
							}
						}
					}
					if (dbScriptBlobRequestDto != null) {
						PackageDeployJobDetailResultDto dbScriptAttachFileDto = packageDeployJobService.readDbScriptAttachFile(reqOomPackageDeployJobDto);
						if (dbScriptAttachFileDto != null) {
							// 기존 첨부파일 삭제
							int oldDbScriptAttachFileNum = CommonObjectUtil.defaultNumber(dbScriptAttachFileDto.getDbScriptAttachFileNum());
							if (oldDbScriptAttachFileNum > 0) {
								fileService.deleteAttachFile(Const.Definition.BLOB_CONTAINER.FILE, oldDbScriptAttachFileNum);
							}
						}
					}
					if (inspectionResultBlobRequestDto != null) {
						PackageDeployJobDetailResultDto inspectionResultAttachFileDto = packageDeployJobService.readInspectionResultAttachFile(reqOomPackageDeployJobDto);
						if (inspectionResultAttachFileDto != null) {
							// 기존 첨부파일 삭제
							int oldInspectionResultAttachFileNum = CommonObjectUtil.defaultNumber(inspectionResultAttachFileDto.getInspectionResultAttachFileNum());
							if (oldInspectionResultAttachFileNum > 0) {
								fileService.deleteAttachFile(Const.Definition.BLOB_CONTAINER.FILE, oldInspectionResultAttachFileNum);
							}
						}
					}
					// 신규 첨부파일들 등록
					if (verifyProcedureBlobRequestDto != null) {
						verifyProcedureBlobRequestDto.setContainerName(Const.Definition.BLOB_CONTAINER.FILE);
						verifyProcedureBlobRequestDto.setBlobBaseDir(Const.Definition.BLOB_BASEDIR.DEPLOY);
						int verifyProcedureAttachFileNum = fileService.createAttachFile(verifyProcedureBlobRequestDto);
						if (verifyProcedureAttachFileNum > 0) {
							reqOomPackageDeployJobDto.setVerifyProcedureAttachFileNum(verifyProcedureAttachFileNum);
						}
					}
					if (workProcedureBlobRequestDto != null) {
						workProcedureBlobRequestDto.setContainerName(Const.Definition.BLOB_CONTAINER.FILE);
						workProcedureBlobRequestDto.setBlobBaseDir(Const.Definition.BLOB_BASEDIR.DEPLOY);
						int workProcedureAttachFileNum = fileService.createAttachFile(workProcedureBlobRequestDto);
						if (workProcedureAttachFileNum > 0) {
							reqOomPackageDeployJobDto.setWorkProcedureAttachFileNum(workProcedureAttachFileNum);
						}
					}
					if (inspectionProcedureBlobRequestDto != null) {
						inspectionProcedureBlobRequestDto.setContainerName(Const.Definition.BLOB_CONTAINER.FILE);
						inspectionProcedureBlobRequestDto.setBlobBaseDir(Const.Definition.BLOB_BASEDIR.DEPLOY);
						int inspectionProcedureAttachFileNum = fileService.createAttachFile(inspectionProcedureBlobRequestDto);
						if (inspectionProcedureAttachFileNum > 0) {
							reqOomPackageDeployJobDto.setInspectionProcedureAttachFileNum(inspectionProcedureAttachFileNum);
						}
					}
					if (dbScriptBlobRequestDto != null) {
						dbScriptBlobRequestDto.setContainerName(Const.Definition.BLOB_CONTAINER.FILE);
						dbScriptBlobRequestDto.setBlobBaseDir(Const.Definition.BLOB_BASEDIR.DEPLOY);
						int dbScriptAttachFileNum = fileService.createAttachFile(dbScriptBlobRequestDto);
						if (dbScriptAttachFileNum > 0) {
							reqOomPackageDeployJobDto.setDbScriptAttachFileNum(dbScriptAttachFileNum);
						}
					}
					if (inspectionResultBlobRequestDto != null) {
						inspectionResultBlobRequestDto.setContainerName(Const.Definition.BLOB_CONTAINER.FILE);
						inspectionResultBlobRequestDto.setBlobBaseDir(Const.Definition.BLOB_BASEDIR.DEPLOY);
						int inspectionResultAttachFileNum = fileService.createAttachFile(inspectionResultBlobRequestDto);
						if (inspectionResultAttachFileNum > 0) {
							reqOomPackageDeployJobDto.setInspectionResultAttachFileNum(inspectionResultAttachFileNum);
						}
					}
					reqOomPackageDeployJobDto.setOnmWorkId(onmWorkId);
					reqOomPackageDeployJobDto.setTenantId(currentTenantId);
					reqOomPackageDeployJobDto.setAuditId(auditId);
					packageDeployJobService.mergePackageDeployJob(reqOomPackageDeployJobDto);
				}
			}
			
			// 현재 작업 완료 시..
			if (Const.Code.WORK_STATUS_FINISH_CD.FINISH.equals(currentWorkStatusFinishCd)) {
				if (Const.Code.WORK_STATUS_DETAIL_CD.DP01.equals(currentWorkStatusDetailCd)) {
					// 배포종료일시 업데이트
					OomPackageDeployJobDto reqOomPackageDeployJobDto = new OomPackageDeployJobDto();
					reqOomPackageDeployJobDto.setOnmWorkId(onmWorkId);
					reqOomPackageDeployJobDto.setTenantId(currentTenantId);
					reqOomPackageDeployJobDto.setAuditId(auditId);
					packageDeployJobService.updateDeployWorkEndDatetime(reqOomPackageDeployJobDto);
				}
				// next 진행코드가 없으면.. 작업 전체 종료로 간주...
				if ("".equals(nextWorkStatusCd)) {
					OomWorkDto reqOomWorkDto = new OomWorkDto();
					reqOomWorkDto.setOnmWorkId(onmWorkId);
					reqOomWorkDto.setAuditId(auditId);
					workService.updateWorkEndDate(reqOomWorkDto);
					
					// 관련 테이블들에 Copy...
					workFinishService.copyWork(reqOomWorkDto);
					
					if (techSupportReqId > 0) {
						// 기술지원요청 상태 종료 처리...
						OomTechSupportRequestDto reqOomTechSupportRequestDto = new OomTechSupportRequestDto();
						reqOomTechSupportRequestDto.setTenantId(currentTenantId);
						reqOomTechSupportRequestDto.setTechSupportReqId(techSupportReqId);
						reqOomTechSupportRequestDto.setTechSupportStatusCd(Const.Code.TECH_SUPPORT_STATUS_CD.FINISH);
						reqOomTechSupportRequestDto.setAuditId(auditId);
						supportService.updateTechSupportStatus(reqOomTechSupportRequestDto);
					}
					
				} else {
					// 다음 메뉴 진행중으로 수정..
					OomWorkStatusDto reqOomWorkStatusDto = new OomWorkStatusDto();
					reqOomWorkStatusDto.setOnmWorkId(onmWorkId);
					reqOomWorkStatusDto.setOnmWorkTypeCd(onmWorkTypeCd);
					reqOomWorkStatusDto.setOnmWorkStatusCd(nextWorkStatusCd);
					reqOomWorkStatusDto.setOnmWorkStatusFinishCd(Const.Code.WORK_STATUS_FINISH_CD.PROCESSING);
					reqOomWorkStatusDto.setAuditId(auditId);
					oomWorkStatusMapper.updateOomWorkStatusFinishCode(reqOomWorkStatusDto);
					// 작업 현재상태코드 수정
					OomWorkDto reqOomWorkDto = new OomWorkDto();
					reqOomWorkDto.setOnmWorkId(onmWorkId);
					reqOomWorkDto.setOnmWorkStatusCd(nextWorkStatusCd);
					reqOomWorkDto.setAuditId(auditId);
					workService.updateWorkCurrentStatus(reqOomWorkDto);
				}
			}
			
			workProcessingResultDto = new WorkProcessingResultDto();
			workProcessingResultDto.setOnmWorkId(onmWorkId);
			workProcessingResultDto.setOnmWorkTypeCd(onmWorkTypeCd);
			workProcessingResultDto.setCurrentWorkStatusCd(currentWorkStatusCd);
			
		} catch (Exception e) {
			throw e;
		}
		
		return workProcessingResultDto;
	}
	
	
	/**
	 * 
	 * readCurrentWorkStatus
	 *
	 * @param reqOomWorkStatusDto
	 * @return CurrentWorkDetailResultDto
	 * @throws Exception 
	 */
	@Override
	public CurrentWorkDetailResultDto readCurrentWorkStatus(OomWorkStatusDto reqOomWorkStatusDto) throws Exception {
		
		CurrentWorkDetailResultDto currentWorkDetailResultDto = null;
		try {
			// 작업의 현재 상태조회...
			currentWorkDetailResultDto = oomWorkStatusMapper.readCurrentWorkStatus(reqOomWorkStatusDto);
			if (currentWorkDetailResultDto != null) {
				int onmWorkId = currentWorkDetailResultDto.getOnmWorkId();
				String currentTenantId = StringUtils.defaultString(currentWorkDetailResultDto.getCurrentTenantId());
				String currentBldId = StringUtils.defaultString(currentWorkDetailResultDto.getCurrentBldId());
				String onmWorkTypeCd = StringUtils.defaultString(currentWorkDetailResultDto.getOnmWorkTypeCd());
				String currentWorkStatusCd = StringUtils.defaultString(currentWorkDetailResultDto.getCurrentWorkStatusCd());
				String currentWorkStatusDetailCd = StringUtils.defaultString(currentWorkDetailResultDto.getCurrentWorkStatusDetailCd());
				
				String postfixWorkStatusCd = StringUtils.substring(currentWorkStatusCd, 2);
				if ("VF".equals(postfixWorkStatusCd)) {
					// 검증 작업 조회...
					OomWorkStatusDto oomWorkStatusDto = new OomWorkStatusDto();
					oomWorkStatusDto.setOnmWorkId(onmWorkId);
					oomWorkStatusDto.setOnmWorkTypeCd(onmWorkTypeCd);
					oomWorkStatusDto.setOnmWorkStatusCd(currentWorkStatusCd);
					List<WorkStatusDetailResultDto> workStatusDetailResultDtoList = oomWorkStatusMapper.listOomWorkStatus(oomWorkStatusDto);
					
					currentWorkDetailResultDto.setVerifyWorkList(workStatusDetailResultDtoList);
					
				} else {
					if (Const.Code.WORK_STATUS_DETAIL_CD.TN01.equals(currentWorkStatusDetailCd)) {
						// 테넌트 작업 조회...
						OomWorkTenantDto reqOomWorkTenantDto = new OomWorkTenantDto();
						reqOomWorkTenantDto.setOnmWorkId(onmWorkId);
						OomWorkTenantDto rsltOomWorkTenantDto = oomWorkTenantMapper.readOomWorkTenant(reqOomWorkTenantDto);
						if (rsltOomWorkTenantDto != null) {
							String serviceStartDate = StringUtils.defaultString(rsltOomWorkTenantDto.getServiceStartDate());
							String serviceEndDate = StringUtils.defaultString(rsltOomWorkTenantDto.getServiceEndDate());
							serviceStartDate = CommonDateUtil.makeDateToDateFormat(serviceStartDate);
							serviceEndDate = CommonDateUtil.makeDateToDateFormat(serviceEndDate);
							rsltOomWorkTenantDto.setServiceStartDate(serviceStartDate);
							rsltOomWorkTenantDto.setServiceEndDate(serviceEndDate);
						}
						currentWorkDetailResultDto.setTenantInfo(rsltOomWorkTenantDto);
					} else if (Const.Code.WORK_STATUS_DETAIL_CD.BD01.equals(currentWorkStatusDetailCd)) {
						// 빌딩 작업 조회...
						OomWorkBuildingDto reqOomWorkBuildingDto = new OomWorkBuildingDto();
						reqOomWorkBuildingDto.setOnmWorkId(onmWorkId);
						List<OomWorkBuildingDto> rsltOomWorkBuildingDtoList = oomWorkBuildingMapper.listOomWorkBuilding(reqOomWorkBuildingDto);
						if (!CollectionUtils.isEmpty(rsltOomWorkBuildingDtoList)) {
							for (int idx = 0; idx < rsltOomWorkBuildingDtoList.size(); idx++) {
								OomWorkBuildingDto rsltOomWorkBuildingDto = rsltOomWorkBuildingDtoList.get(idx);
								String completDate = StringUtils.defaultString(rsltOomWorkBuildingDto.getCompletDate());
								completDate = CommonDateUtil.makeDateToDateFormat(completDate);
								rsltOomWorkBuildingDto.setCompletDate(completDate);
								rsltOomWorkBuildingDtoList.set(idx, rsltOomWorkBuildingDto);
							}
						}
						currentWorkDetailResultDto.setBuildingList(rsltOomWorkBuildingDtoList);
					} else if (Const.Code.WORK_STATUS_DETAIL_CD.SV01.equals(currentWorkStatusDetailCd)) {
						// 서비스 (연동) 작업 조회 (서비스구분코드만)...
						List<WorkBuildingServiceUseYnDto> rsltWorkBuildingServiceUseYnDtoList = new ArrayList<WorkBuildingServiceUseYnDto>();
						
						String postfixWorkTypeCd = StringUtils.substring(onmWorkTypeCd, 1);
						if ("T".equals(postfixWorkTypeCd) || "B".equals(postfixWorkTypeCd)) {
							// 반드시 work 빌딩 정보가 있다...
							OomWorkBuildingDto reqOomWorkBuildingDto = new OomWorkBuildingDto();
							reqOomWorkBuildingDto.setOnmWorkId(onmWorkId);
							List<OomWorkBuildingDto> rsltOomWorkBuildingDtoList = oomWorkBuildingMapper.listOomWorkBuilding(reqOomWorkBuildingDto);
							if (!CollectionUtils.isEmpty(rsltOomWorkBuildingDtoList)) {
								for (OomWorkBuildingDto rsltOomWorkBuildingDto : rsltOomWorkBuildingDtoList) {
									String bldId = StringUtils.defaultString(rsltOomWorkBuildingDto.getBldId());
									String bldName = StringUtils.defaultString(rsltOomWorkBuildingDto.getBldName());
									
									WorkBuildingServiceUseYnDto rsltWorkBuildingServiceUseYnDto = new WorkBuildingServiceUseYnDto();
									rsltWorkBuildingServiceUseYnDto.setBldId(bldId);
									rsltWorkBuildingServiceUseYnDto.setBldName(bldName);
									
									OomWorkBuildingServiceConenctionDto reqOomWorkBuildingServiceConenctionDto = new OomWorkBuildingServiceConenctionDto();
									reqOomWorkBuildingServiceConenctionDto.setOnmWorkId(onmWorkId);
									reqOomWorkBuildingServiceConenctionDto.setBldId(bldId);
									List<WorkServiceUseYnDto> rsltWorkServiceUseYnDtoList = oomWorkBuildingServiceConenctionMapper.listWorkBuildingService(reqOomWorkBuildingServiceConenctionDto);
									rsltWorkBuildingServiceUseYnDto.setWorkServiceList(rsltWorkServiceUseYnDtoList);
									
									rsltWorkBuildingServiceUseYnDtoList.add(rsltWorkBuildingServiceUseYnDto);
								}
							}
						} else {
							if (Const.Code.WORK_TYPE_CD.RS.equals(onmWorkTypeCd)) {
								OomBuildingDto reqOomBuildingDto = new OomBuildingDto();
								reqOomBuildingDto.setTenantId(currentTenantId);
								reqOomBuildingDto.setBldId(currentBldId);
								OomBuildingDto rsltOomBuildingDto = buildingService.readBuilding(reqOomBuildingDto);
								String bldName = "";
								if (rsltOomBuildingDto != null) {
									bldName = rsltOomBuildingDto.getBldName();
								}
								
								WorkBuildingServiceUseYnDto rsltWorkBuildingServiceUseYnDto = new WorkBuildingServiceUseYnDto();
								rsltWorkBuildingServiceUseYnDto.setBldId(currentBldId);
								rsltWorkBuildingServiceUseYnDto.setBldName(bldName);
								
								OomWorkBuildingServiceConenctionDto oomWorkBuildingServiceConenctionDto = new OomWorkBuildingServiceConenctionDto();
								oomWorkBuildingServiceConenctionDto.setOnmWorkId(onmWorkId);
								oomWorkBuildingServiceConenctionDto.setBldId(currentBldId);
								List<WorkServiceUseYnDto> rsltWorkServiceUseYnDtoList = oomWorkBuildingServiceConenctionMapper.listWorkBuildingNotService(oomWorkBuildingServiceConenctionDto);
								rsltWorkBuildingServiceUseYnDto.setWorkServiceList(rsltWorkServiceUseYnDtoList);
								
								rsltWorkBuildingServiceUseYnDtoList.add(rsltWorkBuildingServiceUseYnDto);
							} else {
								// work 빌딩 정보가 없는 CI, DS는 work service connection에서 읽어온다..
								OomWorkBuildingServiceConenctionDto reqOomWorkBuildingServiceConenctionDto = new OomWorkBuildingServiceConenctionDto();
								reqOomWorkBuildingServiceConenctionDto.setOnmWorkId(onmWorkId);
								List<SearchWorkConenctionDto> rsltSearchWorkConenctionDtoList = oomWorkBuildingServiceConenctionMapper.listOomWorkBuildingServiceConenction(reqOomWorkBuildingServiceConenctionDto);
								if (!CollectionUtils.isEmpty(rsltSearchWorkConenctionDtoList)) {
									for (SearchWorkConenctionDto rsltSearchWorkConenctionDto : rsltSearchWorkConenctionDtoList) {
										
										String bldId = StringUtils.defaultString(rsltSearchWorkConenctionDto.getBldId());
										String bldName = StringUtils.defaultString(rsltSearchWorkConenctionDto.getBldName());
										
										WorkBuildingServiceUseYnDto rsltWorkBuildingServiceUseYnDto = new WorkBuildingServiceUseYnDto();
										rsltWorkBuildingServiceUseYnDto.setBldId(bldId);
										rsltWorkBuildingServiceUseYnDto.setBldName(bldName);
										
										OomWorkBuildingServiceConenctionDto oomWorkBuildingServiceConenctionDto = new OomWorkBuildingServiceConenctionDto();
										oomWorkBuildingServiceConenctionDto.setOnmWorkId(onmWorkId);
										oomWorkBuildingServiceConenctionDto.setBldId(bldId);
										List<WorkServiceUseYnDto> rsltWorkServiceUseYnDtoList = oomWorkBuildingServiceConenctionMapper.listWorkBuildingService(oomWorkBuildingServiceConenctionDto);
										rsltWorkBuildingServiceUseYnDto.setWorkServiceList(rsltWorkServiceUseYnDtoList);
										
										rsltWorkBuildingServiceUseYnDtoList.add(rsltWorkBuildingServiceUseYnDto);
									}
								}
							}
						}
						currentWorkDetailResultDto.setServiceList(rsltWorkBuildingServiceUseYnDtoList);
						
					} else if (Const.Code.WORK_STATUS_DETAIL_CD.SI01.equals(currentWorkStatusDetailCd)) {
						// 서비스 연동 작업 조회...
						List<SearchWorkConnectionIpDto> rsltSearchWorkConnectionIpDtoList = new ArrayList<SearchWorkConnectionIpDto>();
						
						String postfixWorkTypeCd = StringUtils.substring(onmWorkTypeCd, 1);
						if ("T".equals(postfixWorkTypeCd) || "B".equals(postfixWorkTypeCd)) {
							// 반드시 work 빌딩 정보가 있다...
							OomWorkBuildingDto reqOomWorkBuildingDto = new OomWorkBuildingDto();
							reqOomWorkBuildingDto.setOnmWorkId(onmWorkId);
							List<OomWorkBuildingDto> rsltOomWorkBuildingDtoList = oomWorkBuildingMapper.listOomWorkBuilding(reqOomWorkBuildingDto);
							if (!CollectionUtils.isEmpty(rsltOomWorkBuildingDtoList)) {
								for (OomWorkBuildingDto rsltOomWorkBuildingDto : rsltOomWorkBuildingDtoList) {
									String bldId = StringUtils.defaultString(rsltOomWorkBuildingDto.getBldId());
									OomWorkBuildingServiceConenctionDto reqOomWorkBuildingServiceConenctionDto = new OomWorkBuildingServiceConenctionDto();
									reqOomWorkBuildingServiceConenctionDto.setOnmWorkId(onmWorkId);
									reqOomWorkBuildingServiceConenctionDto.setBldId(bldId);
									List<SearchWorkConenctionDto> rsltSearchWorkConenctionDtoList = oomWorkBuildingServiceConenctionMapper.listOomWorkBuildingServiceConenction(reqOomWorkBuildingServiceConenctionDto);
									if (!CollectionUtils.isEmpty(rsltSearchWorkConenctionDtoList)) {
										for (SearchWorkConenctionDto rsltSearchWorkConenctionDto : rsltSearchWorkConenctionDtoList) {
											SearchWorkConnectionIpDto searchWorkConnectionIpDto = new SearchWorkConnectionIpDto();
											BeanUtils.copyProperties(rsltSearchWorkConenctionDto, searchWorkConnectionIpDto);
											
											String serviceClCd = StringUtils.defaultString(searchWorkConnectionIpDto.getServiceClCd());
											OomWorkBuildingServiceConnectionIpDto reqOomWorkBuildingServiceConnectionIpDto = new OomWorkBuildingServiceConnectionIpDto();
											reqOomWorkBuildingServiceConnectionIpDto.setOnmWorkId(onmWorkId);
											reqOomWorkBuildingServiceConnectionIpDto.setBldId(bldId);
											reqOomWorkBuildingServiceConnectionIpDto.setServiceClCd(serviceClCd);
											List<OomWorkBuildingServiceConnectionIpDto> rsltOomWorkBuildingServiceConnectionIpDtoList = oomWorkBuildingServiceConnectionIpMapper.listOomWorkBuildingServiceConnectionIp(reqOomWorkBuildingServiceConnectionIpDto);
											searchWorkConnectionIpDto.setServiceConnectionIpList(rsltOomWorkBuildingServiceConnectionIpDtoList);
											
											rsltSearchWorkConnectionIpDtoList.add(searchWorkConnectionIpDto);
										}
									}
								}
							}
						} else {
							// work 빌딩 정보가 없는 RS, CI, DS는 work service connection에서 읽어온다..
							OomWorkBuildingServiceConenctionDto reqOomWorkBuildingServiceConenctionDto = new OomWorkBuildingServiceConenctionDto();
							reqOomWorkBuildingServiceConenctionDto.setOnmWorkId(onmWorkId);
							List<SearchWorkConenctionDto> rsltSearchWorkConenctionDtoList = oomWorkBuildingServiceConenctionMapper.listOomWorkBuildingServiceConenction(reqOomWorkBuildingServiceConenctionDto);
							if (!CollectionUtils.isEmpty(rsltSearchWorkConenctionDtoList)) {
								for (SearchWorkConenctionDto rsltSearchWorkConenctionDto : rsltSearchWorkConenctionDtoList) {
									SearchWorkConnectionIpDto searchWorkConnectionIpDto = new SearchWorkConnectionIpDto();
									BeanUtils.copyProperties(rsltSearchWorkConenctionDto, searchWorkConnectionIpDto);
									
									String bldId = StringUtils.defaultString(searchWorkConnectionIpDto.getBldId());
									String serviceClCd = StringUtils.defaultString(searchWorkConnectionIpDto.getServiceClCd());
									OomWorkBuildingServiceConnectionIpDto reqOomWorkBuildingServiceConnectionIpDto = new OomWorkBuildingServiceConnectionIpDto();
									reqOomWorkBuildingServiceConnectionIpDto.setOnmWorkId(onmWorkId);
									reqOomWorkBuildingServiceConnectionIpDto.setBldId(bldId);
									reqOomWorkBuildingServiceConnectionIpDto.setServiceClCd(serviceClCd);
									List<OomWorkBuildingServiceConnectionIpDto> rsltOomWorkBuildingServiceConnectionIpDtoList = oomWorkBuildingServiceConnectionIpMapper.listOomWorkBuildingServiceConnectionIp(reqOomWorkBuildingServiceConnectionIpDto);
									searchWorkConnectionIpDto.setServiceConnectionIpList(rsltOomWorkBuildingServiceConnectionIpDtoList);
									
									rsltSearchWorkConnectionIpDtoList.add(searchWorkConnectionIpDto);
								}
							}
						}
						currentWorkDetailResultDto.setServiceConnectionIpList(rsltSearchWorkConnectionIpDtoList);
						
					} else if (Const.Code.WORK_STATUS_DETAIL_CD.IF01.equals(currentWorkStatusDetailCd)) {
						// 인터페이스 작업 조회...
						List<InterfaceWorkDetailResultDto> lastInterfaceWorkDetailResultDtoList = new ArrayList<InterfaceWorkDetailResultDto>();
						
						String postfixWorkTypeCd = StringUtils.substring(onmWorkTypeCd, 1);
						if ("T".equals(postfixWorkTypeCd) || "B".equals(postfixWorkTypeCd)) {
							// 반드시 work 빌딩 정보가 있다...
							OomWorkBuildingDto reqOomWorkBuildingDto = new OomWorkBuildingDto();
							reqOomWorkBuildingDto.setOnmWorkId(onmWorkId);
							List<OomWorkBuildingDto> rsltOomWorkBuildingDtoList = oomWorkBuildingMapper.listOomWorkBuilding(reqOomWorkBuildingDto);
							if (!CollectionUtils.isEmpty(rsltOomWorkBuildingDtoList)) {
								for (OomWorkBuildingDto rsltOomWorkBuildingDto : rsltOomWorkBuildingDtoList) {
									String bldId = StringUtils.defaultString(rsltOomWorkBuildingDto.getBldId());
									OomWorkBuildingServiceConenctionDto reqOomWorkBuildingServiceConenctionDto = new OomWorkBuildingServiceConenctionDto();
									reqOomWorkBuildingServiceConenctionDto.setOnmWorkId(onmWorkId);
									reqOomWorkBuildingServiceConenctionDto.setBldId(bldId);
									List<InterfaceWorkDetailResultDto> interfaceWorkDetailResultDtoList = oomWorkBuildingServiceConenctionMapper.listInterfaceWorkDetail(reqOomWorkBuildingServiceConenctionDto);
									if (!CollectionUtils.isEmpty(interfaceWorkDetailResultDtoList)) {
										for (InterfaceWorkDetailResultDto interfaceWorkDetailResultDto : interfaceWorkDetailResultDtoList) {
											lastInterfaceWorkDetailResultDtoList.add(interfaceWorkDetailResultDto);
										}
									}
								}
							}
						} else {
							// work 빌딩 정보가 없는 RS, CI, DS는 work service connection에서 읽어온다..
							OomWorkBuildingServiceConenctionDto reqOomWorkBuildingServiceConenctionDto = new OomWorkBuildingServiceConenctionDto();
							reqOomWorkBuildingServiceConenctionDto.setOnmWorkId(onmWorkId);
							List<SearchWorkConenctionDto> rsltSearchWorkConenctionDtoList = oomWorkBuildingServiceConenctionMapper.listOomWorkBuildingServiceConenction(reqOomWorkBuildingServiceConenctionDto);
							if (!CollectionUtils.isEmpty(rsltSearchWorkConenctionDtoList)) {
								for (SearchWorkConenctionDto rsltSearchWorkConenctionDto : rsltSearchWorkConenctionDtoList) {
									SearchWorkConnectionIpDto searchWorkConnectionIpDto = new SearchWorkConnectionIpDto();
									BeanUtils.copyProperties(rsltSearchWorkConenctionDto, searchWorkConnectionIpDto);
									
									String bldId = StringUtils.defaultString(searchWorkConnectionIpDto.getBldId());
									String serviceClCd = StringUtils.defaultString(searchWorkConnectionIpDto.getServiceClCd());
									reqOomWorkBuildingServiceConenctionDto.setBldId(bldId);
									reqOomWorkBuildingServiceConenctionDto.setServiceClCd(serviceClCd);
									InterfaceWorkDetailResultDto interfaceWorkDetailResultDto = oomWorkBuildingServiceConenctionMapper.readInterfaceWorkDetail(reqOomWorkBuildingServiceConenctionDto);
									lastInterfaceWorkDetailResultDtoList.add(interfaceWorkDetailResultDto);
								}
							}
						}
						
						currentWorkDetailResultDto.setInterfaceList(lastInterfaceWorkDetailResultDtoList);
						
					} else if (Const.Code.WORK_STATUS_DETAIL_CD.RS01.equals(currentWorkStatusDetailCd)) {
						// 운영환경 작업 조회...
						OomWorkTenantResourceDto reqOomWorkTenantResourceDto = new OomWorkTenantResourceDto();
						reqOomWorkTenantResourceDto.setOnmWorkId(onmWorkId);
						OomWorkTenantResourceDto rsltOomWorkTenantResourceDto = oomWorkTenantResourceMapper.readOomWorkTenantResource(reqOomWorkTenantResourceDto);
						if (rsltOomWorkTenantResourceDto != null) {
							WorkTenantResourceDto workTenantResourceDto = new WorkTenantResourceDto();
							BeanUtils.copyProperties(rsltOomWorkTenantResourceDto, workTenantResourceDto);
							
							OomWorkTenantResourceDetailDto reqOomWorkTenantResourceDetailDto = new OomWorkTenantResourceDetailDto();
							reqOomWorkTenantResourceDetailDto.setOnmWorkId(onmWorkId);
							List<WorkTenantResourceDetailDto> workTenantResourceDetailDtoList = oomWorkTenantResourceDetailMapper.listWorkTenantResourceDetailExcel(reqOomWorkTenantResourceDetailDto);
							workTenantResourceDto.setResourceDetailList(workTenantResourceDetailDtoList);
							currentWorkDetailResultDto.setTenantResourceInfo(workTenantResourceDto);
						}
					}
				}
				
				if (Const.Code.WORK_STATUS_DETAIL_CD.DP01.equals(currentWorkStatusDetailCd)) {
					// 운영배포 작업 조회는 등록/수정/삭제 공통...
					OomPackageDeployJobDto reqOomPackageDeployJobDto = new OomPackageDeployJobDto();
					reqOomPackageDeployJobDto.setTenantId(currentTenantId);
					reqOomPackageDeployJobDto.setOnmWorkId(onmWorkId);
					PackageDeployJobDetailResultDto packageDeployJobDetailResultDto = packageDeployJobService.readPackageDeployJob(reqOomPackageDeployJobDto);
					if (packageDeployJobDetailResultDto != null) {
						String workScheduleDatetime = StringUtils.defaultString(packageDeployJobDetailResultDto.getWorkScheduleDatetime());
						String reexecDatetime = StringUtils.defaultString(packageDeployJobDetailResultDto.getReexecDatetime());
						workScheduleDatetime = CommonDateUtil.makeDatetimeToDateFormat(workScheduleDatetime);
						reexecDatetime = CommonDateUtil.makeDatetimeToDateFormat(reexecDatetime);
						packageDeployJobDetailResultDto.setWorkScheduleDatetime(workScheduleDatetime);
						packageDeployJobDetailResultDto.setReexecDatetime(reexecDatetime);
					}
					currentWorkDetailResultDto.setPackageDeployInfo(packageDeployJobDetailResultDto);
				}
			}
			
		} catch (Exception e) {
			throw e;
		}
		return currentWorkDetailResultDto;
	}
	
	/**
	 * 
	 * deleteWorkStatusAttachFile
	 *
	 * @param reqOomWorkStatusDto
	 * @return int
	 * @throws Exception 
	 */
	@Override
	public int deleteWorkStatusAttachFile(OomWorkStatusDto reqOomWorkStatusDto) throws Exception {
		
		int affectRowCount = 0;
		
		try {
			int attachFileNum = reqOomWorkStatusDto.getAttachFileNum();
			// 첨부파일 삭제
			int deleteRow = fileService.deleteAttachFile(Const.Definition.BLOB_CONTAINER.FILE, attachFileNum);
			affectRowCount = affectRowCount + deleteRow;
			// 작업상태의 첨부파일번호 Null update
			reqOomWorkStatusDto.setAttachFileNum(null);
			int updateRow = oomWorkStatusMapper.updateWorkStatusAttachFileNum(reqOomWorkStatusDto);
			affectRowCount = affectRowCount + updateRow;
			
		} catch (Exception e) {
			throw e;
		}
		return affectRowCount;
	}
	
	/**
	 * 
	 * deleteWorkInterfaceAttachFile
	 *
	 * @param reqOomWorkBuildingServiceConenctionDto
	 * @return int
	 * @throws Exception 
	 */
	@Override
	public int deleteWorkInterfaceAttachFile(OomWorkBuildingServiceConenctionDto reqOomWorkBuildingServiceConenctionDto) throws Exception {
		
		int affectRowCount = 0;
		
		try {
			int attachFileNum = reqOomWorkBuildingServiceConenctionDto.getAttachFileNum();
			// 첨부파일 삭제
			int deleteRow = fileService.deleteAttachFile(Const.Definition.BLOB_CONTAINER.FILE, attachFileNum);
			affectRowCount = affectRowCount + deleteRow;
			// 인터페이스 작업 상태의 첨부파일번호 Null update
			reqOomWorkBuildingServiceConenctionDto.setAttachFileNum(null);
			int updateRow = oomWorkBuildingServiceConenctionMapper.updateWorkInterfaceAttachFileNum(reqOomWorkBuildingServiceConenctionDto);
			affectRowCount = affectRowCount + updateRow;
			
		} catch (Exception e) {
			throw e;
		}
		return affectRowCount;
	}
	
	/**
	 * 
	 * listWorkTenantResourceDetailExcel
	 *
	 * @param reqOomWorkTenantResourceDetailDto
	 * @param fileName
	 * @return String
	 * @throws Exception 
	 */
	@Override
	public String listWorkTenantResourceDetailExcel(OomWorkTenantResourceDetailDto reqOomWorkTenantResourceDetailDto, String fileName) throws Exception {
		
		SXSSFWorkbook wb = null;
		FileOutputStream fileOut = null;
		String fileFullPathName = "";
		
		try {
			
			String downloadTempBasePath = azureBlobConfig.getAzureBlobInfo().getDownloadTempBasePath();
    		String currentMilliSeconds = helperService.readCurrentMilliSeconds();
			
    		// 디렉토리 생성
    		StringBuilder downloadPathBuilder = new StringBuilder();
    		downloadPathBuilder.append(downloadTempBasePath);
    		downloadPathBuilder.append("/");
    		downloadPathBuilder.append(currentMilliSeconds);
            
            File downloadTempDirectory = new File(downloadPathBuilder.toString());
            if (!downloadTempDirectory.isDirectory()) {
            	FileUtils.forceMkdir(downloadTempDirectory);
            }
            
            StringBuilder fileFullPathNameBuilder = new StringBuilder();
            fileFullPathNameBuilder.append(downloadPathBuilder.toString());
            fileFullPathNameBuilder.append("/");
            fileFullPathNameBuilder.append(fileName);
            
            // 파일명 (FullPath)
            fileFullPathName = fileFullPathNameBuilder.toString();
            
            // 워크북 생성
            wb = new SXSSFWorkbook();
            
            // 타이틀용 경계 스타일 테두리만 지정
            CellStyle titleStyle = wb.createCellStyle();
            titleStyle.setBorderTop(BorderStyle.THIN);
            titleStyle.setBorderBottom(BorderStyle.THIN);
            titleStyle.setBorderLeft(BorderStyle.THIN);
            titleStyle.setBorderRight(BorderStyle.THIN);
            titleStyle.setVerticalAlignment(VerticalAlignment.CENTER);
            titleStyle.setWrapText(true);
            
            // 테이블 헤더용 스타일
            CellStyle headStyle = wb.createCellStyle();
            // 가는 경계선을 가집니다.
            headStyle.setBorderTop(BorderStyle.THIN);
            headStyle.setBorderBottom(BorderStyle.THIN);
            headStyle.setBorderLeft(BorderStyle.THIN);
            headStyle.setBorderRight(BorderStyle.THIN);
            // 배경색은 노란색입니다.
            headStyle.setFillForegroundColor(HSSFColorPredefined.YELLOW.getIndex());
            headStyle.setFillPattern(FillPatternType.SOLID_FOREGROUND);
            headStyle.setAlignment(HorizontalAlignment.CENTER);
            
            // 데이터용 경계 스타일 테두리만 지정
            CellStyle bodyStyle = wb.createCellStyle();
            bodyStyle.setBorderTop(BorderStyle.THIN);
            bodyStyle.setBorderBottom(BorderStyle.THIN);
            bodyStyle.setBorderLeft(BorderStyle.THIN);
            bodyStyle.setBorderRight(BorderStyle.THIN);
            
            Sheet sheet = wb.createSheet("resource List");
			
			Row row = null;
	        Cell cell = null;
	        int rowNo = 0;
	        
	        // Title 생성
	        StringBuilder titleBuilder = new StringBuilder();
	        titleBuilder.append("※ 엑셀 업로드 시 반드시 이 양식을 사용하시기 바랍니다.\n");
	        titleBuilder.append("※ 임의로 컬럼을 추가 및 삭제하면 데이터가 잘못 등록될 수 있으므로 주의하시기 바랍니다.\n");
	        titleBuilder.append("※ Cell에 : 과 | 특수문자는 사용할 수 없습니다. \n");
	        titleBuilder.append("※ 행 별로 [구분] 컬럼에는 [App Service / Event Hubs / IoT Hub / App Plan / Azure SQL / 스토리지 계정 / 가상머신] 중\n");
	        titleBuilder.append("  1개만 사용할 수 있으며, 필수입력 입니다.");
	        
	        row = sheet.createRow(rowNo++);
	        row.setHeight((short)1800);
	        for(int i=0; i < 5; i++) {
	        	cell = row.createCell(i);
	            cell.setCellStyle(titleStyle);
	            if (i == 0) {
	        		cell.setCellValue(titleBuilder.toString());
	        	}
	        }
	        sheet.addMergedRegion(new CellRangeAddress(0, 0, 0, 4));	// 행시작, 행끝, 열시작, 열끝
	        
			// 헤더 생성
            row = sheet.createRow(rowNo++);
            
            sheet.setColumnWidth(0, 3500);
            cell = row.createCell(0);
            cell.setCellStyle(headStyle);
            cell.setCellValue("구분");
            
            sheet.setColumnWidth(1, 12000);
            cell = row.createCell(1);
            cell.setCellStyle(headStyle);
            cell.setCellValue("리소스명");
            
            sheet.setColumnWidth(2, 3500);
            cell = row.createCell(2);
            cell.setCellStyle(headStyle);
            cell.setCellValue("별칭");
            
            sheet.setColumnWidth(3, 12000);
            cell = row.createCell(3);
            cell.setCellStyle(headStyle);
            cell.setCellValue("App Plan");
            
            sheet.setColumnWidth(4, 18000);
            cell = row.createCell(4);
            cell.setCellStyle(headStyle);
            cell.setCellValue("AZURE 리소스 ID");
            
			// 리소스 상세 목록조회
            List<WorkTenantResourceDetailDto> rsltWorkTenantResourceDetailDtoList = oomWorkTenantResourceDetailMapper.listWorkTenantResourceDetailExcel(reqOomWorkTenantResourceDetailDto);
    		if (!CollectionUtils.isEmpty(rsltWorkTenantResourceDetailDtoList)) {
				for (WorkTenantResourceDetailDto rsltWorkTenantResourceDetailDto : rsltWorkTenantResourceDetailDtoList) {
					String onmResourceCategoryCdName = StringUtils.defaultString(rsltWorkTenantResourceDetailDto.getOnmResourceCategoryCdName());
					String onmResourceName = StringUtils.defaultString(rsltWorkTenantResourceDetailDto.getOnmResourceName());
					String onmResourceAbbrName = StringUtils.defaultString(rsltWorkTenantResourceDetailDto.getOnmResourceAbbrName());
					String superOnmResourceName = StringUtils.defaultString(rsltWorkTenantResourceDetailDto.getSuperOnmResourceName());
					String azureResourceId = StringUtils.defaultString(rsltWorkTenantResourceDetailDto.getAzureResourceId());
					
					row = sheet.createRow(rowNo++);
					cell = row.createCell(0);
	                cell.setCellStyle(bodyStyle);
	                cell.setCellValue(onmResourceCategoryCdName);
	                cell = row.createCell(1);
	                cell.setCellStyle(bodyStyle);
	                cell.setCellValue(onmResourceName);
	                cell = row.createCell(2);
	                cell.setCellStyle(bodyStyle);
	                cell.setCellValue(onmResourceAbbrName);
	                cell = row.createCell(3);
	                cell.setCellStyle(bodyStyle);
	                cell.setCellValue(superOnmResourceName);
	                cell = row.createCell(4);
	                cell.setCellStyle(bodyStyle);
	                cell.setCellValue(azureResourceId);
				}
			}
			
			fileOut = new FileOutputStream(fileFullPathName);
			wb.write(fileOut);
    		
		} catch (Exception e) {
			throw e;
		} finally {
			if (wb != null) {
				wb.close();
			}
			if (fileOut != null) {
				fileOut.close();
			}
		}
		
		return fileFullPathName;
	}

}
