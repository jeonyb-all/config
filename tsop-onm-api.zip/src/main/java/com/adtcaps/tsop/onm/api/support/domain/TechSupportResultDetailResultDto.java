package com.adtcaps.tsop.onm.api.support.domain;

import com.adtcaps.tsop.onm.api.domain.OomTechSupportRequestBuildingDto;
import com.adtcaps.tsop.onm.api.domain.OomTechSupportRequestBuildingServiceDto;

import lombok.Getter;
import lombok.Setter;

/**
 * 
 * <ul>
 * <li>업무 그룹명 : tsop-onm-api</li>
 * <li>서브 업무명 : com.adtcaps.tsop.onm.api.support.domain</li>
 * <li>설  명 : TechSupportResultDetailResultDto.java</li>
 * <li>작성일 : 2021. 1. 10.</li>
 * <li>작성자 : jeonyb4</li>
 * </ul>
 */
@Getter
@Setter
public class TechSupportResultDetailResultDto {
	private String tenantId;
	private String tenantName;
	private Integer techSupportReqId;
	private String reqerName;
	private String techSupportReqTypeCd;
	private String techSupportReqTypeName;
	private String reqTitleName;
	private String reqContent;
	private String techSupportStatusCd;
	private String techSupportStatusName;
	private Integer attachFileNum;
	private String attachFileName;
	private OomTechSupportRequestBuildingDto buildingInfo;
	private OomTechSupportRequestBuildingServiceDto serviceInfo;

}
