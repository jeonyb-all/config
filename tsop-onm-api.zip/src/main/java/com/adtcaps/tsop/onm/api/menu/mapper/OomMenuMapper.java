package com.adtcaps.tsop.onm.api.menu.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;

import com.adtcaps.tsop.onm.api.menu.domain.MenuRequestDto;
import com.adtcaps.tsop.onm.api.menu.domain.MenuResultDto;
import com.adtcaps.tsop.onm.api.menu.domain.MenuTreeResultDto;

/**
 * 
 * <ul>
 * <li>업무 그룹명 : tsop-onm-api</li>
 * <li>서브 업무명 : com.adtcaps.tsop.onm.api.menu.mapper</li>
 * <li>설  명 : OomMenuMapper.java</li>
 * <li>작성일 : 2021. 1. 4.</li>
 * <li>작성자 : jeonyb4</li>
 * </ul>
 */
@Mapper
public interface OomMenuMapper {
	/**
	 * 
	 * listMenu
	 *
	 * @param menuRequestDto
	 * @return List<MenuResultDto>
	 */
	public List<MenuResultDto> listMenu(MenuRequestDto menuRequestDto);
	
	/**
	 * 
	 * listAdminMenu
	 *
	 * @param menuRequestDto
	 * @return List<MenuResultDto>
	 */
	public List<MenuResultDto> listAdminMenu(MenuRequestDto menuRequestDto);
	
	/**
	 * 
	 * listHiddenMenu
	 *
	 * @param menuRequestDto
	 * @return List<MenuResultDto>
	 */
	public List<MenuResultDto> listHiddenMenu(MenuRequestDto menuRequestDto);
	
	/**
	 * 
	 * listMenuTree
	 *
	 * @return List<MenuTreeResultDto>
	 */
	public List<MenuTreeResultDto> listMenuTree();

}
