package com.adtcaps.tsop.onm.api.service.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;

import com.adtcaps.tsop.onm.api.domain.OomServiceConnectionDto;
import com.adtcaps.tsop.onm.api.service.domain.LinkageStandardVersionForComboResultDto;
import com.adtcaps.tsop.onm.api.service.domain.ServiceConnectionDetailResultDto;
import com.adtcaps.tsop.onm.api.service.domain.ServiceConnectionGridRequestDto;
import com.adtcaps.tsop.onm.api.service.domain.ServiceConnectionGridResultDto;
import com.adtcaps.tsop.onm.api.service.domain.ServiceSysLinkageMethodForComboResultDto;
import com.adtcaps.tsop.onm.api.service.domain.ServiceSysNameForComboResultDto;

/**
 * 
 * <ul>
 * <li>업무 그룹명 : tsop-onm-api</li>
 * <li>서브 업무명 : com.adtcaps.tsop.onm.api.service.mapper</li>
 * <li>설  명 : OomServiceConnectionMapper.java</li>
 * <li>작성일 : 2021. 1. 24.</li>
 * <li>작성자 : jeonyb4</li>
 * </ul>
 */
@Mapper
public interface OomServiceConnectionMapper {
	/**
	 * 
	 * listServiceSysLinkageMethodForCombo
	 *
	 * @param reqOomServiceConnectionDto
	 * @return List<ServiceSysLinkageMethodForComboResultDto>
	 */
	public List<ServiceSysLinkageMethodForComboResultDto> listServiceSysLinkageMethodForCombo(OomServiceConnectionDto reqOomServiceConnectionDto);
	
	/**
	 * 
	 * listServiceSysNameForCombo
	 *
	 * @param reqOomServiceConnectionDto
	 * @return List<ServiceSysNameForComboResultDto>
	 */
	public List<ServiceSysNameForComboResultDto> listServiceSysNameForCombo(OomServiceConnectionDto reqOomServiceConnectionDto);
	
	/**
	 * 
	 * listLinkageStandardVersionForCombo
	 *
	 * @param reqOomServiceConnectionDto
	 * @return List<LinkageStandardVersionForComboResultDto>
	 */
	public List<LinkageStandardVersionForComboResultDto> listLinkageStandardVersionForCombo(OomServiceConnectionDto reqOomServiceConnectionDto);
	
	/**
	 * 
	 * listPageServiceConnection
	 *
	 * @param serviceConnectionGridRequestDto
	 * @return List<ServiceConnectionGridResultDto>
	 */
	public List<ServiceConnectionGridResultDto> listPageServiceConnection(ServiceConnectionGridRequestDto serviceConnectionGridRequestDto);
	
	/**
	 * 
	 * createOomServiceConnection
	 *
	 * @param reqOomServiceConnectionDto
	 * @return int
	 */
	public int createOomServiceConnection(OomServiceConnectionDto reqOomServiceConnectionDto);
	
	/**
	 * 
	 * readOomServiceConnection
	 *
	 * @param reqOomServiceConnectionDto
	 * @return ServiceConnectionDetailResultDto
	 */
	public ServiceConnectionDetailResultDto readOomServiceConnection(OomServiceConnectionDto reqOomServiceConnectionDto);
	
	/**
	 * 
	 * readOomServiceConnectionAttachFile
	 *
	 * @param reqOomServiceConnectionDto
	 * @return ServiceConnectionDetailResultDto
	 */
	public ServiceConnectionDetailResultDto readOomServiceConnectionAttachFile(OomServiceConnectionDto reqOomServiceConnectionDto);
	
	/**
	 * 
	 * updateServiceConnectionAttachFileNum
	 *
	 * @param reqOomServiceConnectionDto
	 * @return int
	 */
	public int updateServiceConnectionAttachFileNum(OomServiceConnectionDto reqOomServiceConnectionDto);
	
	/**
	 * 
	 * updateOomServiceConnection
	 *
	 * @param reqOomServiceConnectionDto
	 * @return int
	 */
	public int updateOomServiceConnection(OomServiceConnectionDto reqOomServiceConnectionDto);
	
	/**
	 * 
	 * deleteOomServiceConnection
	 *
	 * @param reqOomServiceConnectionDto
	 * @return int
	 */
	public int deleteOomServiceConnection(OomServiceConnectionDto reqOomServiceConnectionDto);

}
