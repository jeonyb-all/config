package com.adtcaps.tsop.onm.api.send.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.util.CollectionUtils;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.adtcaps.tsop.onm.api.authentication.domain.JwtAuthResultDto;
import com.adtcaps.tsop.onm.api.domain.OomSmsHistDto;
import com.adtcaps.tsop.onm.api.domain.OomUserRoleAuthorityDetailDto;
import com.adtcaps.tsop.onm.api.helper.constant.Const;
import com.adtcaps.tsop.onm.api.helper.domain.ResultDto;
import com.adtcaps.tsop.onm.api.helper.util.PageUtil;
import com.adtcaps.tsop.onm.api.send.domain.SmsHistDetailResultDto;
import com.adtcaps.tsop.onm.api.send.domain.SmsHistGridRequestDto;
import com.adtcaps.tsop.onm.api.send.domain.SmsHistGridResultDto;
import com.adtcaps.tsop.onm.api.send.service.SendService;
import com.adtcaps.tsop.onm.api.user.domain.UserRoleMenuAuthorityRequestDto;
import com.adtcaps.tsop.onm.api.user.service.UserRoleService;

import lombok.extern.slf4j.Slf4j;

/**
 * 
 * <ul>
 * <li>업무 그룹명 : tsop-onm-api</li>
 * <li>서브 업무명 : com.adtcaps.tsop.onm.api.send.controller</li>
 * <li>설  명 : SendController.java</li>
 * <li>작성일 : 2021. 1. 30.</li>
 * <li>작성자 : jeonyb4</li>
 * </ul>
 */
@Slf4j
@RestController
@RequestMapping("/api/sends")
public class SendController {
	
	private final String MENU_ID = "ONM0026";
	
	private final String ERR_MSG_NULL_LOGIN_USER_ID = "로그인 사용자ID가 없습니다.";
	private final String ERR_MSG_NULL_MGR_YN = "관리자여부가 없습니다.";
	private final String ERR_MSG_NULL_PAGE_NUMBER = "페이지 번호가 없습니다.";
	private final String ERR_MSG_NULL_SERACH_DATE = "조회기간(From or To)이 없습니다.";
	
	private final String ERR_MSG_NO_AUTH = "권한이 없는 사용자 입니다.";
	private final String ERR_MSG_NULL_SEARCH_RESULT_LIST = "조회 결과가 없습니다.";
	private final String ERR_MSG_READ_FAIL = "조회에 실패하였습니다.";
	private final String ERR_MSG_RESEND_FAIL = "재전송에 실패하였습니다.";
	
	@Autowired
	private SendService sendService;
	
	@Autowired
	private UserRoleService userRoleService;
	
	/**
	 * 
	 * listPageAlarmNoticeSend
	 *
	 * @param alarmNoticeSendGridRequestDto
	 * @return ResponseEntity
	 */
	@SuppressWarnings("rawtypes")
    @GetMapping(value="", produces="application/json; charset=UTF-8")
    public ResponseEntity listPageSmsHist(SmsHistGridRequestDto reqSmsHistGridRequestDto) throws Exception {
        
    	ResponseEntity<ResultDto> resEntity = null;
		String returnString = "";
    	
		int pageNumber = reqSmsHistGridRequestDto.getPageNumber();
		if (pageNumber < 1) {
			log.error(">>>>>> pageNumber ERROR:{}", ERR_MSG_NULL_PAGE_NUMBER);
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_PAGE_NUMBER));
			return resEntity;
		}
		String fromDate = reqSmsHistGridRequestDto.getFromDate();
		String toDate = reqSmsHistGridRequestDto.getToDate();
		if ("".equals(fromDate) || "".equals(toDate)) {
			log.error(">>>>>> fromDate or toDate ERROR:{}", ERR_MSG_NULL_SERACH_DATE);
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_SERACH_DATE));
			return resEntity;
		}
		
		// 발송내역 목록 조회....
		Map<String, Object> smsHistGridResultDtoListMap = new HashMap<String, Object>();
		List<SmsHistGridResultDto> smsHistGridResultDtoList = sendService.listPageSmsHist(reqSmsHistGridRequestDto);
		if (CollectionUtils.isEmpty(smsHistGridResultDtoList)) {
			returnString = Const.Common.RESULT_CODE.SUCCESS;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_SEARCH_RESULT_LIST, smsHistGridResultDtoListMap));
		} else {
			returnString = Const.Common.RESULT_CODE.SUCCESS;
			smsHistGridResultDtoListMap.put(Const.Definition.PAGE.PAGER, PageUtil.getPageInfo(smsHistGridResultDtoList));
			smsHistGridResultDtoListMap.put(Const.Definition.PAGE.LISTS, smsHistGridResultDtoList);
			resEntity = ResponseEntity.ok(new ResultDto(returnString, "", smsHistGridResultDtoListMap));
		}
    	
    	return resEntity;
    }
	
	/**
	 * 
	 * readSmsHist
	 *
	 * @param smsTransSeq
	 * @return ResponseEntity
	 * @throws Exception 
	 */
	@SuppressWarnings("rawtypes")
    @GetMapping(value="/{smsTransSeq}", produces="application/json; charset=UTF-8")
    public ResponseEntity readSmsHist(@PathVariable("smsTransSeq") int smsTransSeq) throws Exception {
        
    	ResponseEntity<ResultDto> resEntity = null;
		String returnString = "";
		
		OomSmsHistDto reqOomSmsHistDto = new OomSmsHistDto();
		reqOomSmsHistDto.setSmsTransSeq(smsTransSeq);
    	
		// 발송내역 상세조회....
		SmsHistDetailResultDto smsHistDetailResultDto = sendService.readSmsHist(reqOomSmsHistDto);
		if (smsHistDetailResultDto == null) {
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_READ_FAIL, smsHistDetailResultDto));
		} else {
			returnString = Const.Common.RESULT_CODE.SUCCESS;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, "", smsHistDetailResultDto));
		}
    	
    	return resEntity;
    }
	
	/**
	 * 
	 * resendAlarmNotice
	 *
	 * @param reqAlarmNoticeSendDetailResultDto
	 * @return ResponseEntity
	 */
	@SuppressWarnings("rawtypes")
    @PostMapping(value="/resends/{smsTransSeq}", produces="application/json; charset=UTF-8")
    public ResponseEntity resendSmsHist(@AuthenticationPrincipal JwtAuthResultDto authResultDto, 
    		@PathVariable("smsTransSeq") int smsTransSeq) throws Exception {
        
    	ResponseEntity<ResultDto> resEntity = null;
		String returnString = "";
		
		String loginUserId = StringUtils.defaultString(authResultDto.getUserId());
		if ("".equals(loginUserId)) {
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_LOGIN_USER_ID));
			return resEntity;
		}
		String mgrYn = StringUtils.defaultString(authResultDto.getMgrYn());
		if ("".equals(mgrYn)) {
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_MGR_YN));
			return resEntity;
		}
		//String loginUserId = "admin"; // 이후 세션에서 얻어올 값...
    	
		if (!"Y".equals(mgrYn)) {
			String authorityTypeCd = "";
			UserRoleMenuAuthorityRequestDto userRoleMenuAuthorityRequestDto = new UserRoleMenuAuthorityRequestDto();
			userRoleMenuAuthorityRequestDto.setUserId(loginUserId);
			userRoleMenuAuthorityRequestDto.setMenuId(MENU_ID);
			OomUserRoleAuthorityDetailDto rsltOomUserRoleAuthorityDetailDto = userRoleService.readMenuAuthority(userRoleMenuAuthorityRequestDto);
			if (rsltOomUserRoleAuthorityDetailDto != null) {
				authorityTypeCd = StringUtils.defaultString(rsltOomUserRoleAuthorityDetailDto.getAuthorityTypeCd());
			}
			if (!"W".equals(authorityTypeCd)) {
				returnString = Const.Common.RESULT_CODE.FAIL;
				resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NO_AUTH));
				return resEntity;
			}
		}
		
		OomSmsHistDto reqOomSmsHistDto = new OomSmsHistDto();
		reqOomSmsHistDto.setSmsTransSeq(smsTransSeq);
		reqOomSmsHistDto.setAuditId(loginUserId);
		
		// 알림톡 재전송...
		String alarmNoticeResultCd = sendService.resendSmsHistDto(reqOomSmsHistDto);
		if (!"1".equals(alarmNoticeResultCd)) {
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_RESEND_FAIL, alarmNoticeResultCd));
		} else {
			returnString = Const.Common.RESULT_CODE.SUCCESS;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, "", alarmNoticeResultCd));
		}
    	
    	return resEntity;
    }

}
