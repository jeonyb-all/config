package com.adtcaps.tsop.onm.api.fault.service;

import java.util.List;

import com.adtcaps.tsop.onm.api.domain.OomFaultDto;
import com.adtcaps.tsop.onm.api.fault.domain.FaultDetailResultDto;
import com.adtcaps.tsop.onm.api.fault.domain.FaultGridRequestDto;
import com.adtcaps.tsop.onm.api.fault.domain.FaultGridResultDto;
import com.adtcaps.tsop.onm.api.fault.domain.FaultProcessingDto;

/**
 * 
 * <ul>
 * <li>업무 그룹명 : tsop-onm-api</li>
 * <li>서브 업무명 : com.adtcaps.tsop.onm.api.fault.service</li>
 * <li>설  명 : FaultService.java</li>
 * <li>작성일 : 2021. 1. 17.</li>
 * <li>작성자 : jeonyb4</li>
 * </ul>
 */
public interface FaultService {
	/**
	 * 
	 * listPageFault
	 *
	 * @param faultGridRequestDto
	 * @return List<FaultGridResultDto>
	 * @throws Exception 
	 */
	public List<FaultGridResultDto> listPageFault(FaultGridRequestDto faultGridRequestDto) throws Exception;
	
	/**
	 * 
	 * createFault
	 *
	 * @param reqFaultProcessingDto
	 * @return int
	 * @throws Exception 
	 */
	public int createFault(FaultProcessingDto reqFaultProcessingDto) throws Exception;
	
	/**
	 * 
	 * readFault
	 *
	 * @param reqOomFaultDto
	 * @return FaultDetailResultDto
	 * @throws Exception 
	 */
	public FaultDetailResultDto readFault(OomFaultDto reqOomFaultDto) throws Exception;
	
	/**
	 * 
	 * deleteFaultAttachFile
	 *
	 * @param reqOomFaultDto
	 * @return int
	 * @throws Exception 
	 */
	public int deleteFaultAttachFile(OomFaultDto reqOomFaultDto) throws Exception;
	
	/**
	 * 
	 * updateFault
	 *
	 * @param reqFaultProcessingDto
	 * @return int
	 * @throws Exception 
	 */
	public int updateFault(FaultProcessingDto reqFaultProcessingDto) throws Exception;
	
	/**
	 * 
	 * readOomFaultDuplicationCheck
	 *
	 * @param reqOomFaultDto
	 * @return FaultDetailResultDto
	 * @throws Exception 
	 */
	public FaultDetailResultDto readOomFaultDuplicationCheck(OomFaultDto reqOomFaultDto) throws Exception;
	
	/**
	 * 
	 * readFalutCountForAlarm
	 *
	 * @param reqOomFaultDto
	 * @return int
	 * @throws Exception 
	 */
	public int readFalutCountForAlarm(OomFaultDto reqOomFaultDto) throws Exception;
	
}
