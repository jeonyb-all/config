package com.adtcaps.tsop.onm.api.helper.mapper;

import org.apache.ibatis.annotations.Mapper;

import com.adtcaps.tsop.onm.api.helper.domain.DateCalculateRequestDto;
import com.adtcaps.tsop.onm.api.helper.domain.WeekMinMaxDateDto;

/**
 * 
 * <ul>
 * <li>업무 그룹명 : tsop-onm-api</li>
 * <li>서브 업무명 : com.adtcaps.tsop.onm.api.helper.mapper</li>
 * <li>설  명 : HelperMapper.java</li>
 * <li>작성일 : 2021. 1. 2.</li>
 * <li>작성자 : jeonyb4</li>
 * </ul>
 */
@Mapper
public interface HelperMapper {
	
	/**
	 * 
	 * readCurrentDate
	 *
	 * @return String
	 */
	public String readCurrentDate();
	
	/**
	 * 
	 * readCurrentTime
	 *
	 * @return String
	 */
	public String readCurrentTime();
	
	/**
	 * 
	 * readCalculateSomeDate
	 *
	 * @param dateCalculateRequestDto
	 * @return String
	 */
	public String readCalculateSomeDate(DateCalculateRequestDto dateCalculateRequestDto);
	
	/**
	 * 
	 * readCurrentDatetimeRoundupHour
	 *
	 * @return String
	 */
	public String readCurrentDatetimeRoundupHour();
	
	/**
	 * 
	 * readBeforeWeekDate
	 *
	 * @return String
	 */
	public String readBeforeWeekDate();
	
	/**
	 * 
	 * readBeforeMonthDate
	 *
	 * @return String
	 */
	public String readBeforeMonthDate();
	
	/**
	 * 
	 * readBeforeYearDate
	 *
	 * @return String
	 */
	public String readBeforeYearDate();
	
	/**
	 * 
	 * readCurrentDatetime
	 *
	 * @return String
	 */
	public String readCurrentDatetime();
	
	/**
	 * 
	 * readCurrentMilliSeconds
	 *
	 * @return String
	 */
	public String readCurrentMilliSeconds();
	
	/**
	 * 
	 * readCurrentWeek
	 *
	 * @param currentYyyymmdd
	 * @return Integer
	 */
	public Integer readCurrentWeek(String currentYyyymmdd);
	
	/**
	 * 
	 * readMaxWeek
	 *
	 * @param firstYyyymmdd
	 * @return Integer
	 */
	public Integer readMaxWeek(String firstYyyymmdd);
	
	/**
	 * 
	 * readWeekMinMaxDate
	 *
	 * @param inputYyyyMmWeek
	 * @return WeekMinMaxDateDto
	 */
	public WeekMinMaxDateDto readWeekMinMaxDate(String inputYyyyMmWeek);

}
