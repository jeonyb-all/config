package com.adtcaps.tsop.onm.api.helper.constant;

/**
 *
 * <ul>
 * <li>업무 그룹명 : tsop-onm-api</li>
 * <li>서브 업무명 : com.adtcaps.tsop.onm.api.helper.constant</li>
 * <li>설  명 : Const.java</li>
 * <li>작성일 : 2020. 11. 16.</li>
 * <li>작성자 : jeonyb4</li>
 * </ul>
 */
public class Const {

	public static class Common {
                // 서비스 모드
        public static final String TEST = "TB";
        public static final String SERVICE = "AS";

        // 공통 Y,N 벨류
        public static final String VALUE_Y = "Y";
        public static final String VALUE_N = "N";
        public static final String VALUE_ALL = "ALL";

        // 기본 페이지 사이즈
        public static final int VALUE_DEFUALT_PAGE_SIZE = 10;

        // 통신 결과 코드
        public static class HTTP_RESPONSE_CODE {
            public static final String SUCCESS = "200";
            public static final String INVALID_REQUEST = "400";
            public static final String UNAUTORIZED = "401";
            public static final String REQUEST_TIMEOUT = "408";
            public static final String SERVER_ERROR = "500";
            public static final String FAIL = "-1";
        }
        // RESEULT CODE
        public static class RESULT_CODE {
            public static final String SUCCESS = "C0000";
            public static final String FAIL = "C9999";
            public static final String NOT_LOGIN = "NOT_LOGIN";
            public static final String UNAUTORIZED = "UNAUTORIZED";
            public static final String NOTAVAILABLE = "NOTAVAILABLE";
            public static final String UNAUTHORIZEDSMS = "UNAUTHORIZEDSMS";
            public static final String EXCESSSENDSMS = "EXCESSSENDSMS";
            public static final String EXPIREDSMS = "EXPIREDSMSSMS";
            public static final String SERVER_ERROR = "Server Error";
        }
    }

	// 각종 정의
	public static class Definition {

		public static class HIDDEN_SUPER_MENU_ID {
			public static final String SERVICE_NOTI = "ONM0007";
		}

		public static class ADMIN_MENU_ID {
			public static final String USER_MGMT = "ONM0021";
		}

		public static class ACCEPT_CONTENT_TYPE {
			public static final String GIF = "image/gif";
			public static final String PNG = "image/png";
			public static final String JPG = "image/jpeg";
			public static final String PDF = "application/pdf";
			public static final String XLS = "application/vnd.ms-excel";
			public static final String XLS1 = "application/x-msexcel";
			public static final String XLS2 = "application/x-dos_ms_excel";
			public static final String XLS3 = "application/haansoftxlsx";
			public static final String PPT = "application/vnd.ms-powerpoint";
			public static final String DOC = "application/msword";
			public static final String PPTX = "application/vnd.openxmlformats-officedocument.presentationml.presentation";
			public static final String XLSX = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";
			public static final String DOCX = "application/vnd.openxmlformats-officedocument.wordprocessingml.document";
			public static final String ZIP1 = "application/zip";
			public static final String ZIP2 = "multipart/x-zip";
			public static final String ZIP3 = "application/zip-compressed";
			public static final String ZIP4 = "application/x-zip-compressed";
		}

		public static class USE_YN {
			public static final String USE = "사용";
			public static final String NO_USE = "미사용";
		}

		public static class COMMON_VAL {
			public static final String DUMMY = "dummy";
			public static final String SYSTEM_USER_ID = "SYSTEM";
			public static final String SMS_BYTE_LENGTH = "90";
			public static final String SUPER_RESOURCE_CATEGORY_CD_NAME = "App Plan";
		}

		public static class PAGE {
            public static final String PAGER = "pager";
            public static final String LISTS = "lists";
		}

		public static class BLOB_CONTAINER {
            public static final String FILE = "file";
		}

		public static class BOARD_STATUS_VAL {
            public static final String POST = "게시";
            public static final String DELETE = "삭제";
		}

		public static class BLOB_BASEDIR {
            public static final String BOARD = "board";
            public static final String FAULT = "fault";
            public static final String SUPPORT = "support";
            public static final String CONNECT = "connect";
            public static final String WORK = "work";
            public static final String DEPLOY = "deploy";
		}

		public static class FILE_EXTENTION {
            public static final String EXCEL = "xlsx";
		}

		public static class TENANT_SEARCH_KIND_VAL {
            public static final String BUILDING = "B";
            public static final String RESOURCE = "R";
            public static final String ALARM = "A";
		}

		// 메시지 템플릿코드
        public static class MSG_TEMPLATE_CODE {
        	public static final String TSOP_007 = "TSOP_007";		// ONM 알람/장애 공지
        	public static final String TSOP_002 = "TSOP_002";		// 공지사항 등록/변경 공지
        	public static final String TSOP_003 = "TSOP_003";		// 로그인 2차 인증 번호 발송
        	public static final String TSOP_004 = "TSOP_004";		// 비밀번호 최초/초기화 발송
        }

        // 발송구분
        public static class MSG_SENDER_CODE {
        	public static final String SMS = "sms";
        	public static final String ALIMTALK = "alimtalk";
        }

	}

	/**
	 *
	 * <ul>
	 * <li>업무 그룹명 : tsop-onm-api</li>
	 * <li>서브 업무명 : com.adtcaps.tsop.onm.api.helper.constant</li>
	 * <li>설  명 : Const.java</li>
	 * <li>작성일 : 2021. 1. 2.</li>
	 * <li>작성자 : jeonyb4</li>
	 * </ul>
	 */
	public static class Code {
		// 공통코드
        public static class COMMON_CD {
            public static final String API_TYPE_CL_CD = "api_type_cl_cd";		// API유형구분코드
            public static final String API_METHOD_CL_CD = "api_method_cl_cd";	// API방식구분코드
        }

		// 게시유형코드
        public static class BULLETIN_TYPE_CD {
            public static final String NOTICE = "1";		// 공지사항
            public static final String REFERENCE = "2";		// 자료실
        }

        // 게시구분코드
        public static class BULLETIN_CL_CD {
            public static final String NORMAL = "1";		// 일반
            public static final String EMERGENCY = "2";		// 긴급
        }

        // 알람통지방법구분코드
        public static class ALARM_NOTICE_METHOD_CL_CD {
            public static final String SMS = "1";
            public static final String PUSH = "2";
            public static final String ALL = "9";
        }

        // 알람통지결과코드
        public static class ALARM_NOTICE_RESULT_CD {
        	public static final String SMS = "1";
            public static final String FAIL = "2";
            public static final String ALIMTALK = "3";
        }

		// 기술지원요청유형코드
        public static class TECH_SUPPORT_REQ_TYPE_CD {
            public static final String BLD_ADD = "11";		// 빌딩추가
            public static final String BLD_MOD = "12";		// 빌딩변경
            public static final String BLD_DEL = "13";		// 빌딩삭제
            public static final String SVC_ADD = "21";		// 빌딩서비스추가
            public static final String SVC_DEL = "22";		// 빌딩서비스삭제
            public static final String ETC = "99";			// 기타
        }

        // 기술지원상태코드
        public static class TECH_SUPPORT_STATUS_CD {
            public static final String REQUEST = "1";		// 신청
            public static final String APPROVAL = "2";		// 승인
            public static final String PROCESSING = "3";	// 진행중
            public static final String FINISH = "4";		// 완료
            public static final String RETURN = "5";		// 반려
        }

        // 작업유형코드
        public static class WORK_TYPE_CD {
        	public static final String RT = "RT";			// 테넌트추가
        	public static final String RB = "RB";			// 빌딩추가
            public static final String RS = "RS";			// 서비스추가
            public static final String CI = "CI";			// 연동정보변경
            public static final String CB = "CB";			// 빌딩변경
            public static final String DP = "DP";			// 검증
            public static final String DT = "DT";			// 테넌트삭제
            public static final String DB = "DB";			// 빌딩삭제
            public static final String DS = "DS";			// 서비스삭제
        }

        // 작업상태코드
        public static class WORK_STATUS_CD {
        	public static final String RTTN = "RTTN";		// 테넌트추가 시 테넌트등록
        	public static final String RBBD = "RBBD";		// 빌딩추가 시 빌딩등록
        	public static final String RSSV = "RSSV";		// 서비스추가 시 사용서비스등록
        	public static final String RSSI = "RSSI";		// 서비스추가 시 서비스연동정보등록
        	public static final String CBBD = "CBBD";		// 빌딩변경 시 빌딩등록
        	public static final String CISI = "CISI";		// 연동정보변경 시 서비스연동정보등록
        	public static final String DPVF = "DPVF";		// 검증 시 검증
        	public static final String DTSI = "DTSI";		// 테넌트삭제 시  전체서비스연동종료
        	public static final String DBSI = "DBSI";		// 빌딩삭제 시  전체서비스연동종료
        	public static final String DSSI = "DSSI";		// 서비스삭제 시 서비스연동정보등록
        }

        // 작업상태상세코드
        public static class WORK_STATUS_DETAIL_CD {
        	public static final String TN01 = "TN01";		// 테넌트 작업
        	public static final String BD01 = "BD01";		// 빌딩 작업
        	public static final String SI01 = "SI01";		// 서비스연동 작업
        	public static final String SV01 = "SV01";		// 서비스작업
        	public static final String IF01 = "IF01";		// 인터페이스작업
        	public static final String RS01 = "RS01";		// 운영환경작업
        	public static final String DP01 = "DP01";		// 운영배포작업
        }

        // 작업상태완료코드
        public static class WORK_STATUS_FINISH_CD {
        	public static final String READY = "1";			// 대기
        	public static final String PROCESSING = "2";	// 진행중
        	public static final String FINISH = "3";		// 완료
        	public static final String BYPASS = "9";		// bypass
        }

        // SMS생성코드
        public static class SMS_CREATE_CD {
        	public static final String ALARM = "1";
        	public static final String FAULT = "2";
        	public static final String BOARD = "3";
        	public static final String AUTH = "4";
        	public static final String PASSWORD = "5";
        }

	}

}
