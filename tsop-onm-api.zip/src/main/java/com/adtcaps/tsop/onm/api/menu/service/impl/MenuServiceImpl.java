package com.adtcaps.tsop.onm.api.menu.service.impl;

import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import com.adtcaps.tsop.onm.api.helper.util.CommonObjectUtil;
import com.adtcaps.tsop.onm.api.menu.domain.MenuRequestDto;
import com.adtcaps.tsop.onm.api.menu.domain.MenuResultDto;
import com.adtcaps.tsop.onm.api.menu.domain.MenuTreeResultDto;
import com.adtcaps.tsop.onm.api.menu.mapper.OomMenuMapper;
import com.adtcaps.tsop.onm.api.menu.service.MenuService;

/**
 * 
 * <ul>
 * <li>업무 그룹명 : tsop-onm-api</li>
 * <li>서브 업무명 : com.adtcaps.tsop.onm.api.menu.service.impl</li>
 * <li>설  명 : MenuServiceImpl.java</li>
 * <li>작성일 : 2021. 1. 4.</li>
 * <li>작성자 : jeonyb4</li>
 * </ul>
 */
@Service
public class MenuServiceImpl implements MenuService {
	
	@Autowired
	private OomMenuMapper oomMenuMapper;
	
	/**
	 * 
	 * listMenu
	 *
	 * @param menuRequestDto
	 * @return List<MenuResultDto>
	 * @throws Exception 
	 */
	@Override
	public List<MenuResultDto> listMenu(MenuRequestDto menuRequestDto) throws Exception {
		
		List<MenuResultDto> menuResultDtoList = null;
		try {
			menuResultDtoList = oomMenuMapper.listMenu(menuRequestDto);
			String superMenuId = StringUtils.defaultString(menuRequestDto.getSuperMenuId());
			if ("".equals(superMenuId)) {
				// 1 Depth 메뉴에 대하여...
				if (!CollectionUtils.isEmpty(menuResultDtoList)) {
					for (int idx = menuResultDtoList.size()-1; idx >= 0; idx--) {
						MenuResultDto menuResultDto = menuResultDtoList.get(idx);
						String menuId = StringUtils.defaultString(menuResultDto.getMenuId());
						if (!"".equals(menuId)) {
							menuRequestDto.setSuperMenuId(menuId);
							List<MenuResultDto> childMenuResultDtoList = oomMenuMapper.listMenu(menuRequestDto);
							if (CollectionUtils.isEmpty(childMenuResultDtoList)) {
								menuResultDtoList.remove(idx);
							}
						}
					}
				}
			}
		} catch (Exception e) {
			throw e;
		}
		return menuResultDtoList;
	}
	
	/**
	 * 
	 * listHiddenMenu
	 *
	 * @param menuRequestDto
	 * @return List<MenuResultDto>
	 * @throws Exception 
	 */
	@Override
	public List<MenuResultDto> listHiddenMenu(MenuRequestDto menuRequestDto) throws Exception {
		
		List<MenuResultDto> menuResultDtoList = null;
		try {
			menuResultDtoList = oomMenuMapper.listHiddenMenu(menuRequestDto);
		} catch (Exception e) {
			throw e;
		}
		return menuResultDtoList;
	}
	
	/**
	 * 
	 * listMenuTree
	 *
	 * @return List<MenuTreeResultDto>
	 * @throws Exception 
	 */
	@Override
	public List<MenuTreeResultDto> listMenuTree() throws Exception {
		
		List<MenuTreeResultDto> menuTreeResultDtoList = null;
		try {
			menuTreeResultDtoList = oomMenuMapper.listMenuTree();
			if (!CollectionUtils.isEmpty(menuTreeResultDtoList)) {
				for (int idx = 0; idx < menuTreeResultDtoList.size(); idx++) {
					MenuTreeResultDto menuTreeResultDto = menuTreeResultDtoList.get(idx);
					String fullMenuName = StringUtils.defaultString(menuTreeResultDto.getFullMenuName());
					fullMenuName = CommonObjectUtil.replaceAllCertainSection(fullMenuName, '>', "    ");
					menuTreeResultDto.setFullMenuName(fullMenuName);
					menuTreeResultDtoList.set(idx, menuTreeResultDto);
				}
			}
		} catch (Exception e) {
			throw e;
		}
		return menuTreeResultDtoList;
	}

}
