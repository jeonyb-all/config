package com.adtcaps.tsop.onm.api.deploy.service.impl;

import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.CollectionUtils;

import com.adtcaps.tsop.onm.api.deploy.domain.PackageDeployJobDetailResultDto;
import com.adtcaps.tsop.onm.api.deploy.domain.PackageDeployJobGridRequestDto;
import com.adtcaps.tsop.onm.api.deploy.domain.PackageDeployJobGridResultDto;
import com.adtcaps.tsop.onm.api.deploy.mapper.OomPackageDeployJobMapper;
import com.adtcaps.tsop.onm.api.deploy.service.PackageDeployJobService;
import com.adtcaps.tsop.onm.api.domain.OomPackageDeployJobDto;
import com.adtcaps.tsop.onm.api.file.service.FileService;
import com.adtcaps.tsop.onm.api.helper.constant.Const;
import com.adtcaps.tsop.onm.api.helper.util.CommonDateUtil;

/**
 * 
 * <ul>
 * <li>업무 그룹명 : tsop-onm-api</li>
 * <li>서브 업무명 : com.adtcaps.tsop.onm.api.deploy.service.impl</li>
 * <li>설  명 : PackageDeployJobServiceImpl.java</li>
 * <li>작성일 : 2021. 1. 31.</li>
 * <li>작성자 : jeonyb4</li>
 * </ul>
 */
@Transactional
@Service
public class PackageDeployJobServiceImpl implements PackageDeployJobService {
	
	@Autowired
	private OomPackageDeployJobMapper oomPackageDeployJobMapper;
	
	@Autowired
	private FileService fileService;
	
	
	/**
	 * 
	 * mergePackageDeployJob
	 *
	 * @param reqOomPackageDeployJobDto
	 * @return int
	 * @throws Exception 
	 */
	@Override
	public int mergePackageDeployJob(OomPackageDeployJobDto reqOomPackageDeployJobDto) throws Exception {
		
		int affectRowCount = 0;
		
		try {
			int updateRow = oomPackageDeployJobMapper.mergeOomPackageDeployJob(reqOomPackageDeployJobDto);
			affectRowCount = affectRowCount + updateRow;
			
		} catch (Exception e) {
			throw e;
		}
		
		return affectRowCount;
	}
	
	/**
	 * 
	 * readPackageDeployJob
	 *
	 * @param reqOomPackageDeployJobDto
	 * @return PackageDeployJobDetailResultDto
	 * @throws Exception 
	 */
	@Override
	public PackageDeployJobDetailResultDto readPackageDeployJob(OomPackageDeployJobDto reqOomPackageDeployJobDto) throws Exception {
		
		PackageDeployJobDetailResultDto packageDeployJobDetailResultDto = null;
		
		try {
			packageDeployJobDetailResultDto = oomPackageDeployJobMapper.readOomPackageDeployJob(reqOomPackageDeployJobDto);
			
			String pkgWorkId = StringUtils.defaultString(reqOomPackageDeployJobDto.getPkgWorkId());
			if (!"".equals(pkgWorkId)) {
				// 작업에서 요청한 내용이 아니라.. 배포관리에서 요청한 내용이면...
				String workScheduleDatetime = StringUtils.defaultString(packageDeployJobDetailResultDto.getWorkScheduleDatetime());
				String reexecDatetime = StringUtils.defaultString(packageDeployJobDetailResultDto.getReexecDatetime());
				workScheduleDatetime = CommonDateUtil.makeDatetimeToDateFormat(workScheduleDatetime);
				reexecDatetime = CommonDateUtil.makeDatetimeFormat(reexecDatetime);
				packageDeployJobDetailResultDto.setWorkScheduleDatetime(workScheduleDatetime);
				packageDeployJobDetailResultDto.setReexecDatetime(reexecDatetime);
			}
			
		} catch (Exception e) {
			throw e;
		}
		
		return packageDeployJobDetailResultDto;
	}
	
	/**
	 * 
	 * readVerifyProcedureAttachFile
	 *
	 * @param reqOomPackageDeployJobDto
	 * @return PackageDeployJobDetailResultDto
	 * @throws Exception 
	 */
	@Override
	public PackageDeployJobDetailResultDto readVerifyProcedureAttachFile(OomPackageDeployJobDto reqOomPackageDeployJobDto) throws Exception {
		
		PackageDeployJobDetailResultDto packageDeployJobDetailResultDto = null;
		
		try {
			packageDeployJobDetailResultDto = oomPackageDeployJobMapper.readVerifyProcedureAttachFile(reqOomPackageDeployJobDto);
			
		} catch (Exception e) {
			throw e;
		}
		
		return packageDeployJobDetailResultDto;
	}
	
	/**
	 * 
	 * readWorkProcedureAttachFile
	 *
	 * @param reqOomPackageDeployJobDto
	 * @return PackageDeployJobDetailResultDto
	 * @throws Exception 
	 */
	@Override
	public PackageDeployJobDetailResultDto readWorkProcedureAttachFile(OomPackageDeployJobDto reqOomPackageDeployJobDto) throws Exception {
		
		PackageDeployJobDetailResultDto packageDeployJobDetailResultDto = null;
		
		try {
			packageDeployJobDetailResultDto = oomPackageDeployJobMapper.readWorkProcedureAttachFile(reqOomPackageDeployJobDto);
			
		} catch (Exception e) {
			throw e;
		}
		
		return packageDeployJobDetailResultDto;
	}
	
	/**
	 * 
	 * readInspectionProcedureAttachFile
	 *
	 * @param reqOomPackageDeployJobDto
	 * @return PackageDeployJobDetailResultDto
	 * @throws Exception 
	 */
	@Override
	public PackageDeployJobDetailResultDto readInspectionProcedureAttachFile(OomPackageDeployJobDto reqOomPackageDeployJobDto) throws Exception {
		
		PackageDeployJobDetailResultDto packageDeployJobDetailResultDto = null;
		
		try {
			packageDeployJobDetailResultDto = oomPackageDeployJobMapper.readInspectionProcedureAttachFile(reqOomPackageDeployJobDto);
			
		} catch (Exception e) {
			throw e;
		}
		
		return packageDeployJobDetailResultDto;
	}
	
	/**
	 * 
	 * readDbScriptAttachFile
	 *
	 * @param reqOomPackageDeployJobDto
	 * @return PackageDeployJobDetailResultDto
	 * @throws Exception 
	 */
	@Override
	public PackageDeployJobDetailResultDto readDbScriptAttachFile(OomPackageDeployJobDto reqOomPackageDeployJobDto) throws Exception {
		
		PackageDeployJobDetailResultDto packageDeployJobDetailResultDto = null;
		
		try {
			packageDeployJobDetailResultDto = oomPackageDeployJobMapper.readDbScriptAttachFile(reqOomPackageDeployJobDto);
			
		} catch (Exception e) {
			throw e;
		}
		
		return packageDeployJobDetailResultDto;
	}
	
	/**
	 * 
	 * readInspectionResultAttachFile
	 *
	 * @param reqOomPackageDeployJobDto
	 * @return PackageDeployJobDetailResultDto
	 * @throws Exception 
	 */
	@Override
	public PackageDeployJobDetailResultDto readInspectionResultAttachFile(OomPackageDeployJobDto reqOomPackageDeployJobDto) throws Exception {
		
		PackageDeployJobDetailResultDto packageDeployJobDetailResultDto = null;
		
		try {
			packageDeployJobDetailResultDto = oomPackageDeployJobMapper.readInspectionResultAttachFile(reqOomPackageDeployJobDto);
			
		} catch (Exception e) {
			throw e;
		}
		
		return packageDeployJobDetailResultDto;
	}
	
	/**
	 * 
	 * updateDeployWorkEndDatetime
	 *
	 * @param reqOomPackageDeployJobDto
	 * @return int
	 * @throws Exception 
	 */
	@Override
	public int updateDeployWorkEndDatetime(OomPackageDeployJobDto reqOomPackageDeployJobDto) throws Exception {
		
		int affectRowCount = 0;
		
		try {
			int updateRow = oomPackageDeployJobMapper.updateDeployWorkEndDatetime(reqOomPackageDeployJobDto);
			affectRowCount = affectRowCount + updateRow;
			
		} catch (Exception e) {
			throw e;
		}
		return affectRowCount;
	}
	
	/**
	 * 
	 * deleteDeployVerifyProcedureAttachFile
	 *
	 * @param reqOomPackageDeployJobDto
	 * @return int
	 * @throws Exception 
	 */
	@Override
	public int deleteDeployVerifyProcedureAttachFile(OomPackageDeployJobDto reqOomPackageDeployJobDto) throws Exception {
		
		int affectRowCount = 0;
		
		try {
			int verifyProcedureAttachFileNum = reqOomPackageDeployJobDto.getVerifyProcedureAttachFileNum();
			// 첨부파일 삭제
			int deleteRow = fileService.deleteAttachFile(Const.Definition.BLOB_CONTAINER.FILE, verifyProcedureAttachFileNum);
			affectRowCount = affectRowCount + deleteRow;
			// 배포작업의 첨부파일번호 Null update
			reqOomPackageDeployJobDto.setVerifyProcedureAttachFileNum(null);
			int updateRow = oomPackageDeployJobMapper.updateDeployVerifyProcedureAttachFileNum(reqOomPackageDeployJobDto);
			affectRowCount = affectRowCount + updateRow;
			
		} catch (Exception e) {
			throw e;
		}
		return affectRowCount;
	}
	
	/**
	 * 
	 * deleteDeployWorkProcedureAttachFile
	 *
	 * @param reqOomPackageDeployJobDto
	 * @return int
	 * @throws Exception 
	 */
	@Override
	public int deleteDeployWorkProcedureAttachFile(OomPackageDeployJobDto reqOomPackageDeployJobDto) throws Exception {
		
		int affectRowCount = 0;
		
		try {
			int workProcedureAttachFileNum = reqOomPackageDeployJobDto.getWorkProcedureAttachFileNum();
			// 첨부파일 삭제
			int deleteRow = fileService.deleteAttachFile(Const.Definition.BLOB_CONTAINER.FILE, workProcedureAttachFileNum);
			affectRowCount = affectRowCount + deleteRow;
			// 배포작업의 첨부파일번호 Null update
			reqOomPackageDeployJobDto.setWorkProcedureAttachFileNum(null);
			int updateRow = oomPackageDeployJobMapper.updateDeployWorkProcedureAttachFileNum(reqOomPackageDeployJobDto);
			affectRowCount = affectRowCount + updateRow;
			
		} catch (Exception e) {
			throw e;
		}
		return affectRowCount;
	}
	
	/**
	 * 
	 * deleteDeployInspectionProcedureAttachFile
	 *
	 * @param reqOomPackageDeployJobDto
	 * @return int
	 * @throws Exception 
	 */
	@Override
	public int deleteDeployInspectionProcedureAttachFile(OomPackageDeployJobDto reqOomPackageDeployJobDto) throws Exception {
		
		int affectRowCount = 0;
		
		try {
			int inspectionProcedureAttachFileNum = reqOomPackageDeployJobDto.getInspectionProcedureAttachFileNum();
			// 첨부파일 삭제
			int deleteRow = fileService.deleteAttachFile(Const.Definition.BLOB_CONTAINER.FILE, inspectionProcedureAttachFileNum);
			affectRowCount = affectRowCount + deleteRow;
			// 배포작업의 첨부파일번호 Null update
			reqOomPackageDeployJobDto.setInspectionProcedureAttachFileNum(null);
			int updateRow = oomPackageDeployJobMapper.updateDeployInspectionProcedureAttachFileNum(reqOomPackageDeployJobDto);
			affectRowCount = affectRowCount + updateRow;
			
		} catch (Exception e) {
			throw e;
		}
		return affectRowCount;
	}
	
	/**
	 * 
	 * deleteDeployDbScriptAttachFile
	 *
	 * @param reqOomPackageDeployJobDto
	 * @return int
	 * @throws Exception 
	 */
	@Override
	public int deleteDeployDbScriptAttachFile(OomPackageDeployJobDto reqOomPackageDeployJobDto) throws Exception {
		
		int affectRowCount = 0;
		
		try {
			int dbScriptAttachFileNum = reqOomPackageDeployJobDto.getDbScriptAttachFileNum();
			// 첨부파일 삭제
			int deleteRow = fileService.deleteAttachFile(Const.Definition.BLOB_CONTAINER.FILE, dbScriptAttachFileNum);
			affectRowCount = affectRowCount + deleteRow;
			// 배포작업의 첨부파일번호 Null update
			reqOomPackageDeployJobDto.setDbScriptAttachFileNum(null);
			int updateRow = oomPackageDeployJobMapper.updateDeployDbScriptAttachFileNum(reqOomPackageDeployJobDto);
			affectRowCount = affectRowCount + updateRow;
			
		} catch (Exception e) {
			throw e;
		}
		return affectRowCount;
	}
	
	/**
	 * 
	 * deleteDeployInspectionResultAttachFile
	 *
	 * @param reqOomPackageDeployJobDto
	 * @return int
	 * @throws Exception 
	 */
	@Override
	public int deleteDeployInspectionResultAttachFile(OomPackageDeployJobDto reqOomPackageDeployJobDto) throws Exception {
		
		int affectRowCount = 0;
		
		try {
			int inspectionResultAttachFileNum = reqOomPackageDeployJobDto.getInspectionResultAttachFileNum();
			// 첨부파일 삭제
			int deleteRow = fileService.deleteAttachFile(Const.Definition.BLOB_CONTAINER.FILE, inspectionResultAttachFileNum);
			affectRowCount = affectRowCount + deleteRow;
			// 배포작업의 첨부파일번호 Null update
			reqOomPackageDeployJobDto.setInspectionResultAttachFileNum(null);
			int updateRow = oomPackageDeployJobMapper.updateDeployInspectionResultAttachFileNum(reqOomPackageDeployJobDto);
			affectRowCount = affectRowCount + updateRow;
			
		} catch (Exception e) {
			throw e;
		}
		return affectRowCount;
	}
	
	/**
	 * 
	 * deleteOomPackageDeployJob
	 *
	 * @param reqOomPackageDeployJobDto
	 * @return int
	 * @throws Exception 
	 */
	@Override
	public int deleteOomPackageDeployJob(OomPackageDeployJobDto reqOomPackageDeployJobDto) throws Exception {
		
		int affectRowCount = 0;
		
		try {
			int deleteRow = oomPackageDeployJobMapper.deleteOomPackageDeployJob(reqOomPackageDeployJobDto);
			affectRowCount = affectRowCount + deleteRow;
			
		} catch (Exception e) {
			throw e;
		}
		return affectRowCount;
	}
	
	
	/**
	 * 
	 * listPagePackageDeployJob
	 *
	 * @param packageDeployJobGridRequestDto
	 * @return List<PackageDeployJobGridResultDto>
	 * @throws Exception 
	 */
	@Override
	public List<PackageDeployJobGridResultDto> listPagePackageDeployJob(PackageDeployJobGridRequestDto packageDeployJobGridRequestDto) throws Exception {
		
		List<PackageDeployJobGridResultDto> packageDeployJobGridResultDtoList = null;
		try {
			String fromDate = packageDeployJobGridRequestDto.getFromDate();
    		String toDate = packageDeployJobGridRequestDto.getToDate();
    		
    		fromDate = CommonDateUtil.makeFromDatetime(fromDate);
    		toDate = CommonDateUtil.makeToDatetime(toDate);
    		
    		packageDeployJobGridRequestDto.setFromDate(fromDate);
    		packageDeployJobGridRequestDto.setToDate(toDate);
    		
    		packageDeployJobGridResultDtoList = oomPackageDeployJobMapper.listPagePackageDeployJob(packageDeployJobGridRequestDto);
    		if (!CollectionUtils.isEmpty(packageDeployJobGridResultDtoList)) {
    			for (int idx = 0; idx < packageDeployJobGridResultDtoList.size(); idx++) {
    				
    				PackageDeployJobGridResultDto packageDeployJobGridResultDto = packageDeployJobGridResultDtoList.get(idx);
    				
    				String workStartDatetime = StringUtils.defaultString(packageDeployJobGridResultDto.getWorkStartDatetime());
    				workStartDatetime = CommonDateUtil.makeDatetimeFormat(workStartDatetime);
    				packageDeployJobGridResultDto.setWorkStartDatetime(workStartDatetime);
    				
    				String workEndDatetime = StringUtils.defaultString(packageDeployJobGridResultDto.getWorkEndDatetime());
    				workEndDatetime = CommonDateUtil.makeDatetimeFormat(workEndDatetime);
    				packageDeployJobGridResultDto.setWorkEndDatetime(workEndDatetime);
    				
    				packageDeployJobGridResultDtoList.set(idx, packageDeployJobGridResultDto);
    			}
    		}
    		
		} catch (Exception e) {
			throw e;
		}
		return packageDeployJobGridResultDtoList;
	}

}
