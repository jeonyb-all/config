package com.adtcaps.tsop.onm.api.alimTalk.domain;

import java.util.List;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class AlimTalkBatchRequestDto {
	private List<AlimTalkRequestDto> msgList;
}
