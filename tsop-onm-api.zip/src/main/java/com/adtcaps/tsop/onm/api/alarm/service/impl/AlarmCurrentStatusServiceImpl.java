package com.adtcaps.tsop.onm.api.alarm.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.adtcaps.tsop.onm.api.alarm.domain.AlarmCurrentStatusDetailResultDto;
import com.adtcaps.tsop.onm.api.alarm.domain.AlarmCurrentStatusGridRequestDto;
import com.adtcaps.tsop.onm.api.alarm.domain.AlarmCurrentStatusGridResultDto;
import com.adtcaps.tsop.onm.api.alarm.mapper.OomOnmAlarmCurrentStatusMapper;
import com.adtcaps.tsop.onm.api.alarm.service.AlarmCurrentStatusService;
import com.adtcaps.tsop.onm.api.domain.OomOnmAlarmCurrentStatusDto;

/**
 * 
 * <ul>
 * <li>업무 그룹명 : tsop-onm-api</li>
 * <li>서브 업무명 : com.adtcaps.tsop.onm.api.alarm.service.impl</li>
 * <li>설  명 : AlarmCurrentStatusServiceImpl.java</li>
 * <li>작성일 : 2021. 2. 6.</li>
 * <li>작성자 : jeonyb4</li>
 * </ul>
 */
@Transactional
@Service
public class AlarmCurrentStatusServiceImpl implements AlarmCurrentStatusService {
	
	@Autowired
	private OomOnmAlarmCurrentStatusMapper oomOnmAlarmCurrentStatusMapper;
	
	/**
	 * 
	 * listPageAlarmCurrentStatus
	 *
	 * @param alarmNoticeConditionGridRequestDto
	 * @return List<AlarmCurrentStatusGridResultDto>
	 * @throws Exception 
	 */
	@Override
	public List<AlarmCurrentStatusGridResultDto> listPageAlarmCurrentStatus(AlarmCurrentStatusGridRequestDto alarmNoticeConditionGridRequestDto) throws Exception {
		
		List<AlarmCurrentStatusGridResultDto> alarmNoticeConditionGridResultDtoList = null;
		try {
			alarmNoticeConditionGridResultDtoList = oomOnmAlarmCurrentStatusMapper.listPageAlarmCurrentStatus(alarmNoticeConditionGridRequestDto);
			
		} catch (Exception e) {
			throw e;
		}
		return alarmNoticeConditionGridResultDtoList;
	}
	
	/**
	 * 
	 * readAlarmCurrentStatus
	 *
	 * @param reqOomOnmAlarmCurrentStatusDto
	 * @return AlarmCurrentStatusDetailResultDto
	 * @throws Exception 
	 */
	@Override
	public AlarmCurrentStatusDetailResultDto readAlarmCurrentStatus(OomOnmAlarmCurrentStatusDto reqOomOnmAlarmCurrentStatusDto) throws Exception {
		
		AlarmCurrentStatusDetailResultDto alarmNoticeConditionDetailResultDto = null;
		try {
			alarmNoticeConditionDetailResultDto = oomOnmAlarmCurrentStatusMapper.readAlarmCurrentStatus(reqOomOnmAlarmCurrentStatusDto);
		} catch (Exception e) {
			throw e;
		}
		return alarmNoticeConditionDetailResultDto;
	}
	
	/**
	 * 
	 * updateAlarmCurrentStatus
	 *
	 * @param reqOomOnmAlarmCurrentStatusDto
	 * @return int
	 * @throws Exception 
	 */
	@Override
	public int updateAlarmCurrentStatus(OomOnmAlarmCurrentStatusDto reqOomOnmAlarmCurrentStatusDto) throws Exception {
		
		int affectRowCount = 0;
		
		try {
			int updateRow = oomOnmAlarmCurrentStatusMapper.updateOomOnmAlarmCurrentStatus(reqOomOnmAlarmCurrentStatusDto);
			affectRowCount = affectRowCount + updateRow;
			
		} catch (Exception e) {
			throw e;
		}
		
		return affectRowCount;
	}

}
