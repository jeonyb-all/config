package com.adtcaps.tsop.onm.api.send.domain;

import lombok.Getter;
import lombok.Setter;

/**
 *
 * <ul>
 * <li>업무 그룹명 : tsop-onm-api</li>
 * <li>서브 업무명 : com.adtcaps.tsop.onm.api.send.domain</li>
 * <li>설  명 : NoticeSendReceiverDto.java</li>
 * <li>작성일 : 2021. 1. 30.</li>
 * <li>작성자 : jeonyb4</li>
 * </ul>
 */
@Getter
@Setter
public class NoticeSendReceiverDto {
	private String rcverId;
	private String rcverName;
	private String rcvPhoneNum;
	private String tenantId;
	private String resultCode;
	private String sender;

}
