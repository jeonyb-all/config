package com.adtcaps.tsop.onm.api.helper.util;

/**
 * 
 * <ul>
 * <li>업무 그룹명 : tsop-onm-api</li>
 * <li>서브 업무명 : com.adtcaps.tsop.onm.api.helper.util</li>
 * <li>설  명 : CommonJsonUtil.java</li>
 * <li>작성일 : 2020. 11. 16.</li>
 * <li>작성자 : jeonyb4</li>
 * </ul>
 */
public class CommonJsonUtil {
	
	public static String getPretty(String jsonString) {
		final String INDENT = "  ";
		StringBuffer prettyJsonSb = new StringBuffer();
		int indentDepth = 0;
		String targetString = null;
		
		for (int i=0; i<jsonString.length(); i++) {
			targetString = jsonString.substring(i, i+1);
			if (targetString.equals("{") || targetString.equals("[")) {
				prettyJsonSb.append(targetString).append("\n");
				indentDepth++;
				for (int j=0; j<indentDepth; j++) {
					prettyJsonSb.append(INDENT);
				}
			} else if (targetString.equals("}") || targetString.equals("]")) {
				prettyJsonSb.append("\n");
				indentDepth--;
				for (int j=0; j<indentDepth; j++) {
					prettyJsonSb.append(INDENT);
				}
				prettyJsonSb.append(targetString);
			} else if (targetString.equals(",")) {
				prettyJsonSb.append(targetString);
				prettyJsonSb.append("\n");
				for (int j=0; j<indentDepth; j++) {
					prettyJsonSb.append(INDENT);
				}
			} else {
				prettyJsonSb.append(targetString);
			}
		}
		
		return prettyJsonSb.toString();
	}

}
