package com.adtcaps.tsop.onm.api.file.service.impl;

import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.URLDecoder;
import java.util.UUID;

import org.apache.commons.io.FileUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.tika.Tika;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.adtcaps.tsop.onm.api.config.AzureBlobConfig;
import com.adtcaps.tsop.onm.api.domain.OomAttachFileDto;
import com.adtcaps.tsop.onm.api.file.domain.BlobRequestDto;
import com.adtcaps.tsop.onm.api.file.domain.BlobResultDto;
import com.adtcaps.tsop.onm.api.file.mapper.OomAttachFileMapper;
import com.adtcaps.tsop.onm.api.file.service.FileService;
import com.adtcaps.tsop.onm.api.helper.service.HelperService;
import com.adtcaps.tsop.onm.api.helper.util.CommonObjectUtil;
import com.azure.storage.blob.BlobServiceClient;
import com.azure.storage.blob.models.BlobHttpHeaders;
import com.azure.storage.blob.specialized.BlockBlobClient;
import com.squareup.okhttp.OkHttpClient;
import com.squareup.okhttp.Request;
import com.squareup.okhttp.Response;


/**
 * 
 * <ul>
 * <li>업무 그룹명 : tsop-backend-api</li>
 * <li>서브 업무명 : com.adtcaps.tsop.portal.api.file.service.impl</li>
 * <li>설  명 : FileServiceImpl.java</li>
 * <li>작성일 : 2020. 12. 16.</li>
 * <li>작성자 : jeonyb4</li>
 * </ul>
 */
@Service
public class FileServiceImpl implements FileService {
	
	private final String ERR_MSG_NULL_CONTAINER_NAME = "컨테이너명이 없습니다.";
	
	private final String ERR_MSG_NULL_ATTACH_FILE_NUM = "첨부파일번호가 없습니다.";
	private final String ERR_MSG_NULL_BLOB_BASE_DIR = "Blob 기본경로가 없습니다.";
	private final String ERR_MSG_NULL_BLOB_FILE_PATH = "Blob 파일경로가 없습니다.";
	private final String ERR_MSG_NULL_BLOB_FILE_NAME = "Blob 파일명이 없습니다.";
	private final String ERR_MSG_NULL_LOCAL_FILE_PATH = "로컬(WAS) 파일경로가 없습니다.";
	private final String ERR_MSG_NULL_REMOTE_FILE_URL = "원격파일RUL이 없습니다.";
	private final String ERR_MSG_NULL_REMOTE_FILE_NAME = "원격파일명이 없습니다.";
	
	@Autowired
	private AzureBlobConfig azureBlobConfig;
	
	@Autowired
	private OomAttachFileMapper oomAttachFileMapper;
	
	@Autowired
	private HelperService helperService;
	
	private BlobServiceClient blobServiceClient;
	
	/**
	 * 
	 * readAttachFile
	 *
	 * @param reqOomAttachFileDto
	 * @return OomAttachFileDto
	 * @throws Exception 
	 */
	@Override
	public OomAttachFileDto readAttachFile(OomAttachFileDto reqOomAttachFileDto) throws Exception {
		
		OomAttachFileDto rsltOomAttachFileDto = null;
		try {
			rsltOomAttachFileDto = oomAttachFileMapper.readOomAttachFile(reqOomAttachFileDto);
		} catch (Exception e) {
			throw e;
		}
		return rsltOomAttachFileDto;
	}
	
	/**
	 * 
	 * createAttachFile
	 *
	 * @param blobRequestDto
	 * @return int
	 * @throws Exception 
	 */
	@Override
	public int createAttachFile(BlobRequestDto blobRequestDto) throws Exception {
		
		int attachFileNum = 0;
		
		try {
			if (blobRequestDto != null) {
				String localFilePath = StringUtils.defaultString(blobRequestDto.getLocalFilePath());
				String containerName = StringUtils.defaultString(blobRequestDto.getContainerName());
				String blobBaseDir = StringUtils.defaultString(blobRequestDto.getBlobBaseDir());
				if ("".equals(localFilePath)) {
					throw new Exception(ERR_MSG_NULL_LOCAL_FILE_PATH);
				}
				if ("".equals(containerName)) {
					throw new Exception(ERR_MSG_NULL_CONTAINER_NAME);
				}
	    		if ("".equals(blobBaseDir)) {
					throw new Exception(ERR_MSG_NULL_BLOB_BASE_DIR);
				}
				
				int lastSlashIndexVal = StringUtils.lastIndexOf(localFilePath, "/");
				String userFileName = StringUtils.substring(localFilePath, lastSlashIndexVal+1);
				
				String uuId = UUID.randomUUID().toString();
				String currentDate = helperService.readCurrentDate();
	    		String yyyy = StringUtils.substring(currentDate, 0, 4);
				String mm = StringUtils.substring(currentDate, 4, 6);
				String dd = StringUtils.substring(currentDate, 6, 8);
				
	    		int lastDotIndexVal = StringUtils.lastIndexOf(localFilePath, ".");
	    		String fileExtension = StringUtils.substring(localFilePath, lastDotIndexVal+1);
	    		
	    		StringBuilder blobFilePathBuilder = new StringBuilder();
	    		blobFilePathBuilder.append(blobBaseDir);
	    		blobFilePathBuilder.append("/");
	    		blobFilePathBuilder.append(yyyy);
	    		blobFilePathBuilder.append("/");
	    		blobFilePathBuilder.append(mm);
	    		blobFilePathBuilder.append("/");
	    		blobFilePathBuilder.append(dd);
	    		
	    		StringBuilder blobFileNameBuilder = new StringBuilder();
	    		blobFileNameBuilder.append(uuId);
	    		blobFileNameBuilder.append(".");
	    		blobFileNameBuilder.append(fileExtension);
				
				blobRequestDto.setContainerName(containerName);
				blobRequestDto.setBlobFilePath(blobFilePathBuilder.toString());
				blobRequestDto.setBlobFileName(blobFileNameBuilder.toString());
				
				// Azure Blob Storage Upload...
				BlobResultDto blobResultDto = uploadFile(blobRequestDto);
				
	    		long fileByteSize = CommonObjectUtil.defaultNumber(blobResultDto.getFileSize());
	    		double fileKiloSize = Math.round(fileByteSize / (double)1024 * 100) / 100.0;
				
	    		OomAttachFileDto reqOomAttachFileDto = new OomAttachFileDto();
	    		reqOomAttachFileDto.setAttachFileId(blobFileNameBuilder.toString());
	    		reqOomAttachFileDto.setAttachFileName(userFileName);
	    		reqOomAttachFileDto.setAttachFileSize(fileKiloSize);
	    		reqOomAttachFileDto.setAttachFileTypeVal(blobResultDto.getContentType());
	    		reqOomAttachFileDto.setAttachFilePathName(blobFilePathBuilder.toString());
	    		reqOomAttachFileDto.setAttachFileLocUrlAddr(blobResultDto.getFileUrl());
	    		
	    		// 첨부파일 등록...
	    		oomAttachFileMapper.createOomAttachFile(reqOomAttachFileDto);
				attachFileNum = reqOomAttachFileDto.getAttachFileNum();
			}
			
		} catch (Exception e) {
			throw e;
		}
		
		return attachFileNum;
	}
	
	/**
	 * 
	 * createRemoteAttachFile
	 *
	 * @param blobRequestDto
	 * @return int
	 * @throws Exception 
	 */
	@Override
	public int createRemoteAttachFile(BlobRequestDto blobRequestDto) throws Exception {
		
		int attachFileNum = 0;
		
		try {
			if (blobRequestDto != null) {
				String remoteFileUrl = StringUtils.defaultString(blobRequestDto.getRemoteFileUrl());
				String remoteFileName = StringUtils.defaultString(blobRequestDto.getRemoteFileName());
				String containerName = StringUtils.defaultString(blobRequestDto.getContainerName());
				String blobFilePath = StringUtils.defaultString(blobRequestDto.getBlobFilePath());
				String blobFileName = StringUtils.defaultString(blobRequestDto.getBlobFileName());
				if ("".equals(remoteFileUrl)) {
					throw new Exception(ERR_MSG_NULL_REMOTE_FILE_URL);
				}
				if ("".equals(remoteFileName)) {
					throw new Exception(ERR_MSG_NULL_REMOTE_FILE_NAME);
				}
				if ("".equals(containerName)) {
					throw new Exception(ERR_MSG_NULL_CONTAINER_NAME);
				}
	    		if ("".equals(blobFilePath)) {
					throw new Exception(ERR_MSG_NULL_BLOB_FILE_PATH);
				}
	    		if ("".equals(blobFileName)) {
					throw new Exception(ERR_MSG_NULL_BLOB_FILE_NAME);
				}
	    		
				// HTTP File Download & Azure Blob Storage Upload...
				BlobResultDto blobResultDto = uploadUrlFile(blobRequestDto);
				
	    		long fileByteSize = CommonObjectUtil.defaultNumber(blobResultDto.getFileSize());
	    		double fileKiloSize = Math.round(fileByteSize / (double)1024 * 100) / 100.0;
				
	    		OomAttachFileDto reqOomAttachFileDto = new OomAttachFileDto();
	    		reqOomAttachFileDto.setAttachFileId(blobFileName);
	    		reqOomAttachFileDto.setAttachFileName(remoteFileName);
	    		reqOomAttachFileDto.setAttachFileSize(fileKiloSize);
	    		reqOomAttachFileDto.setAttachFileTypeVal(blobResultDto.getContentType());
	    		reqOomAttachFileDto.setAttachFilePathName(blobFilePath);
	    		reqOomAttachFileDto.setAttachFileLocUrlAddr(blobResultDto.getFileUrl());
	    		
	    		// 첨부파일 등록...
	    		oomAttachFileMapper.createOomAttachFile(reqOomAttachFileDto);
				attachFileNum = reqOomAttachFileDto.getAttachFileNum();
			}
			
		} catch (Exception e) {
			throw e;
		}
		
		return attachFileNum;
	}
	
	/**
	 * 
	 * uploadFile
	 *
	 * @param blobRequestDto
	 * @return BlobResultDto
	 * @throws Exception 
	 */
	@Override
	public BlobResultDto uploadFile(BlobRequestDto blobRequestDto) throws Exception {
		
		BlobResultDto blobResultDto = null;
		
		try {
			String containerName = StringUtils.defaultString(blobRequestDto.getContainerName());
			String blobFilePath = StringUtils.defaultString(blobRequestDto.getBlobFilePath());
			String blobFileName = StringUtils.defaultString(blobRequestDto.getBlobFileName());
			String localFilePath = StringUtils.defaultString(blobRequestDto.getLocalFilePath());
			if ("".equals(containerName)) {
				throw new Exception(ERR_MSG_NULL_CONTAINER_NAME);
			}
			if ("".equals(blobFilePath)) {
				throw new Exception(ERR_MSG_NULL_BLOB_FILE_PATH);
			}
			if ("".equals(blobFileName)) {
				throw new Exception(ERR_MSG_NULL_BLOB_FILE_NAME);
			}
			if ("".equals(localFilePath)) {
				throw new Exception(ERR_MSG_NULL_LOCAL_FILE_PATH);
			}
			// 파일업로드 및 해당 파일 Clinet 정의
			BlockBlobClient blockBlobClient = uploadAzureFile(blobRequestDto);
			blobResultDto = makeReturnFileResult(blockBlobClient);
			
			// Remote에 전달용으로 파일URL을 넣어준다.
			String fileUrl = blobResultDto.getFileUrl();
			blobRequestDto.setRemoteFileUrl(fileUrl);
			
			// Remote에 전달용으로 사용자파일명을 넣어준다.
			int lastSlashIndexVal = StringUtils.lastIndexOf(localFilePath, "/");
			String userFileName = StringUtils.substring(localFilePath, lastSlashIndexVal+1);
			blobRequestDto.setRemoteFileName(userFileName);
			
		} catch (Exception e) {
			throw e;
		}
		
		return blobResultDto;
	}
	
	/**
	 * 
	 * uploadUrlFile
	 *
	 * @param blobRequestDto
	 * @return BlobResultDto
	 * @throws Exception 
	 */
	private BlobResultDto uploadUrlFile(BlobRequestDto blobRequestDto) throws Exception {
		
		BlobResultDto blobResultDto = null;
		
		try {
			// URL에 대한 파일을 로컬(temp)로 다운로드...
			blobRequestDto = readOkHttpFile(blobRequestDto);
			
			// 파일업로드 및 해당 파일 Clinet 정의
			BlockBlobClient blockBlobClient = uploadAzureFile(blobRequestDto);
			blobResultDto = makeReturnFileResult(blockBlobClient);
			
		} catch (Exception e) {
			throw e;
		}
		
		return blobResultDto;
	}
	
	/**
	 * 
	 * deleteAttachFile
	 *
	 * @param containerName
	 * @param attachFileNum
	 * @return int
	 * @throws Exception 
	 */
	@Override
	public int deleteAttachFile(String containerName, int attachFileNum) throws Exception {
		
		int deleteRow = 0;
		
		try {
			containerName = StringUtils.defaultString(containerName);
			if ("".equals(containerName)) {
				throw new Exception(ERR_MSG_NULL_CONTAINER_NAME);
			}
			if (attachFileNum < 1) {
				throw new Exception(ERR_MSG_NULL_ATTACH_FILE_NUM);
			}
			
			OomAttachFileDto reqOomAttachFileDto = new OomAttachFileDto();
			reqOomAttachFileDto.setAttachFileNum(attachFileNum);
			OomAttachFileDto rsltOomAttachFileDto = readAttachFile(reqOomAttachFileDto);
			
			String blobFilePath = StringUtils.defaultString(rsltOomAttachFileDto.getAttachFilePathName());
			String blobFileName = StringUtils.defaultString(rsltOomAttachFileDto.getAttachFileId());
			if ("".equals(blobFilePath)) {
				throw new Exception(ERR_MSG_NULL_BLOB_FILE_PATH);
			}
			if ("".equals(blobFileName)) {
				throw new Exception(ERR_MSG_NULL_BLOB_FILE_NAME);
			}
			
			BlobRequestDto blobRequestDto = new BlobRequestDto();
			blobRequestDto.setContainerName(containerName);
			blobRequestDto.setBlobFilePath(blobFilePath);
			blobRequestDto.setBlobFileName(blobFileName);
			
			// 디렉터리 삭제 및 해당 디렉터리 Clinet 정의
			deleteAzureFile(blobRequestDto);
			
			// 첨부파일내역 삭제...
			deleteRow = oomAttachFileMapper.deleteOomAttachFile(reqOomAttachFileDto);
			
		} catch (Exception e) {
			throw e;
		}
		
		return deleteRow;
	}
	
	/**
	 * 
	 * downloadFile
	 *
	 * @param blobRequestDto
	 * @return BlobResultDto
	 * @throws Exception 
	 */
	@Override
	public BlobResultDto downloadFile(BlobRequestDto blobRequestDto) throws Exception {
		
		BlobResultDto blobResultDto = null;
		
		try {
			String containerName = blobRequestDto.getContainerName();
			String blobFilePath = blobRequestDto.getBlobFilePath();
			String blobFileName = blobRequestDto.getBlobFileName();
			String localFilePath = blobRequestDto.getLocalFilePath();
			if ("".equals(containerName)) {
				throw new Exception(ERR_MSG_NULL_CONTAINER_NAME);
			}
			if ("".equals(blobFilePath)) {
				throw new Exception(ERR_MSG_NULL_BLOB_FILE_PATH);
			}
			if ("".equals(blobFileName)) {
				throw new Exception(ERR_MSG_NULL_BLOB_FILE_NAME);
			}
			if ("".equals(localFilePath)) {
				throw new Exception(ERR_MSG_NULL_LOCAL_FILE_PATH);
			}
			// 파일다운로드 및 해당 파일 Clinet 정의
			BlockBlobClient blockBlobClient = downloadAzureFile(blobRequestDto);
			blobResultDto = makeReturnFileResult(blockBlobClient);
			blobResultDto.setLocalFilePath(localFilePath);
			
		} catch (Exception e) {
			throw e;
		}
		
		return blobResultDto;
	}
	
	/***************************************************************************************/
	
	/**
	 * 
	 * makeReturnFileResult
	 *
	 * @param blockBlobClient
	 * @return BlobResultDto
	 * @throws Exception 
	 */
	private BlobResultDto makeReturnFileResult(BlockBlobClient blockBlobClient) throws Exception {
		
		BlobResultDto blobResultDto = new BlobResultDto();
		
		String containerName = blockBlobClient.getContainerName();
		String blobFullFilePath = blockBlobClient.getBlobName();
		long fileSize = blockBlobClient.getProperties().getBlobSize();
		String fileUrl = blockBlobClient.getBlobUrl();
		String contentType = blockBlobClient.getProperties().getContentType();
		
		int lastSlashIndexVal = StringUtils.lastIndexOf(blobFullFilePath, "/");
		String blobFilePath = StringUtils.substring(blobFullFilePath, 0, lastSlashIndexVal);
		String blobFileName = StringUtils.substring(blobFullFilePath, lastSlashIndexVal+1);
		
		String decFileUrl = URLDecoder.decode(fileUrl, "UTF-8");
		
		blobResultDto = new BlobResultDto();
		blobResultDto.setContainerName(containerName);
		blobResultDto.setBlobFilePath(blobFilePath);
		blobResultDto.setFileName(blobFileName);
		blobResultDto.setFileUrl(decFileUrl);
		blobResultDto.setFileSize(fileSize);
		blobResultDto.setContentType(contentType);
		
		return blobResultDto;
	}
	
	/**
	 * 
	 * readOkHttpFile
	 *
	 * @param blobRequestDto
	 * @return BlobRequestDto
	 * @throws Exception 
	 */
	private BlobRequestDto readOkHttpFile(BlobRequestDto blobRequestDto) throws Exception {
		
		String localFilePath = "";
		
		try {
			String remoteFileUrl = StringUtils.defaultString(blobRequestDto.getRemoteFileUrl());
			String remoteFileName = StringUtils.defaultString(blobRequestDto.getRemoteFileName());
			
			String currentMilliSeconds = helperService.readCurrentMilliSeconds();
			String uploadTempBasePath = azureBlobConfig.getAzureBlobConfig().getUploadTempBasePath();
			StringBuilder uploadPathBuilder = new StringBuilder();
            uploadPathBuilder.append(uploadTempBasePath);
            uploadPathBuilder.append("/system/");
            uploadPathBuilder.append(currentMilliSeconds);
            
            File uploadTempDirectory = new File(uploadPathBuilder.toString());
            if (!uploadTempDirectory.isDirectory()) {
            	FileUtils.forceMkdir(uploadTempDirectory);
            }
            
			// URL 파일 다운로드...
			StringBuilder localFilePathBuilder = new StringBuilder();
			localFilePathBuilder.append(uploadPathBuilder.toString());
			localFilePathBuilder.append("/");
			localFilePathBuilder.append(remoteFileName);
			localFilePath = localFilePathBuilder.toString();
			
			File dstFile = new File(localFilePath);
			OkHttpClient client = new OkHttpClient();
			Request request = new Request.Builder().url(remoteFileUrl).build();
			
			Response response = client.newCall(request).execute();
			FileUtils.copyInputStreamToFile(response.body().byteStream(), dstFile);
			
			// WAS 경로..
			blobRequestDto.setLocalFilePath(localFilePath);
			
		} catch (Exception e) {
			throw e;
		}
		
		return blobRequestDto;	
	}
	
	/**
	 * 
	 * uploadAzureFile
	 *
	 * @param blobRequestDto
	 * @return BlockBlobClient
	 * @throws Exception 
	 */
	private BlockBlobClient uploadAzureFile(BlobRequestDto blobRequestDto) throws Exception {
		
		BlockBlobClient blockBlobClient = null;
		File file = null;
		InputStream dataStream = null;
		
		try {
			String containerName = blobRequestDto.getContainerName();
			String blobFilePath = blobRequestDto.getBlobFilePath();
			String blobFileName = blobRequestDto.getBlobFileName();
			String localFilePath = blobRequestDto.getLocalFilePath();
			int lastSlashIndexVal = StringUtils.lastIndexOf(localFilePath, "/");
			String uploadTempDirPath = StringUtils.substring(localFilePath, 0, lastSlashIndexVal);
			
			StringBuilder blobFileFullPathBuilder = new StringBuilder();
			blobFileFullPathBuilder.append(blobFilePath);
			blobFileFullPathBuilder.append("/");
			blobFileFullPathBuilder.append(blobFileName);
			String blobFileFullPath = blobFileFullPathBuilder.toString();
			
			file = new File(localFilePath);
    		byte[] fileBytes = FileUtils.readFileToByteArray(new File(localFilePath));
    		dataStream = new ByteArrayInputStream(fileBytes);
    		
    		blobServiceClient = azureBlobConfig.getAzureBlobInfo().getBlobServiceClient();
    		blockBlobClient = blobServiceClient.getBlobContainerClient(containerName).getBlobClient(blobFileFullPath).getBlockBlobClient();
    		blockBlobClient.upload(dataStream, file.length());
            
            // Content-Type Check...
			String mimeType = new Tika().detect(file);
//			if (StringUtils.indexOf(mimeType, "image/") > -1 || StringUtils.indexOf(mimeType, "audio/") > -1 || StringUtils.indexOf(mimeType, "video/") > -1) {
//				BlobHttpHeaders headers = new BlobHttpHeaders();
//				headers.setContentType(mimeType);
//				blockBlobClient.setHttpHeaders(headers);
//			}
			BlobHttpHeaders headers = new BlobHttpHeaders();
			headers.setContentType(mimeType);
			blockBlobClient.setHttpHeaders(headers);
			
			// Local Temp Directory 삭제...
			File uploadTempDirectory = new File(uploadTempDirPath);
			if (uploadTempDirectory.isDirectory()) {
				FileUtils.deleteDirectory(uploadTempDirectory);
			}
			
		} catch (Exception e) {
			throw e;
		} finally {
			if (dataStream != null) {
				dataStream.close();
			}
		}
		
		return blockBlobClient;
	}
	
	/**
	 * 
	 * deleteAzureFile
	 *
	 * @param blobRequestDto
	 * @return BlockBlobClient
	 */
	private BlockBlobClient deleteAzureFile(BlobRequestDto blobRequestDto) {
        
		BlockBlobClient blockBlobClient = null;
		
		try {
			String containerName = blobRequestDto.getContainerName();
			String blobFilePath = blobRequestDto.getBlobFilePath();
			String blobFileName = blobRequestDto.getBlobFileName();
			
			StringBuilder blobFileFullPathBuilder = new StringBuilder();
			blobFileFullPathBuilder.append(blobFilePath);
			blobFileFullPathBuilder.append("/");
			blobFileFullPathBuilder.append(blobFileName);
			String blobFileFullPath = blobFileFullPathBuilder.toString();
			
			blobServiceClient = azureBlobConfig.getAzureBlobInfo().getBlobServiceClient();
			blockBlobClient = blobServiceClient.getBlobContainerClient(containerName).getBlobClient(blobFileFullPath).getBlockBlobClient();
			blockBlobClient.delete();
			
		} catch (Exception e) {
			throw e;
		}
		
		return blockBlobClient;
	}
	
	/**
	 * 
	 * downloadAzureFile
	 *
	 * @param blobRequestDto
	 * @return BlockBlobClient
	 * @throws Exception 
	 */
	private BlockBlobClient downloadAzureFile(BlobRequestDto blobRequestDto) throws Exception {
		
		BlockBlobClient blockBlobClient = null;
		File file = null;
		OutputStream targetStream = null;
		
		try {
			String containerName = blobRequestDto.getContainerName();
			String blobFilePath = blobRequestDto.getBlobFilePath();
			String blobFileName = blobRequestDto.getBlobFileName();
			String localFilePath = blobRequestDto.getLocalFilePath();
			int lastSlashIndexVal = StringUtils.lastIndexOf(localFilePath, "/");
			String downloadTempDirPath = StringUtils.substring(localFilePath, 0, lastSlashIndexVal);
			
			StringBuilder blobFileFullPathBuilder = new StringBuilder();
			blobFileFullPathBuilder.append(blobFilePath);
			blobFileFullPathBuilder.append("/");
			blobFileFullPathBuilder.append(blobFileName);
			String blobFileFullPath = blobFileFullPathBuilder.toString();
			
			blobServiceClient = azureBlobConfig.getAzureBlobInfo().getBlobServiceClient();
    		blockBlobClient = blobServiceClient.getBlobContainerClient(containerName).getBlobClient(blobFileFullPath).getBlockBlobClient();
    		
    		File downloadTempDirectory = new File(downloadTempDirPath);
    		if (!downloadTempDirectory.isDirectory()) {
    			FileUtils.forceMkdir(downloadTempDirectory);
    		}
			
    		file = new File(localFilePath);
			targetStream = new FileOutputStream(file);
			blockBlobClient.download(targetStream);
            
			targetStream.close();
			
		} catch (Exception e) {
			throw e;
		} finally {
			if (targetStream != null) {
				targetStream.close();
			}
		}
		
		return blockBlobClient;
	}

}
