package com.adtcaps.tsop.onm.api.code.domain;

import java.util.List;

import lombok.Getter;
import lombok.Setter;

/**
 * 
 * <ul>
 * <li>업무 그룹명 : tsop-onm-api</li>
 * <li>서브 업무명 : com.adtcaps.tsop.onm.api.code.domain</li>
 * <li>설  명 : CommonCodeRequestDto.java</li>
 * <li>작성일 : 2021. 1. 5.</li>
 * <li>작성자 : jeonyb4</li>
 * </ul>
 */
@Getter
@Setter
public class CommonCodeRequestDto {
	private String commonCd;
	private String serviceClCd;
	private String commonCdLike;
	private String commonCdIn;
	private String commonCdNotIn;
	private List<String> commonCdInList;
	private List<String> commonCdNotInList;
	
	public CommonCodeRequestDto() {
		this.commonCd = "";
		this.serviceClCd = "";
		this.commonCdLike = "";
		this.commonCdIn = "";
		this.commonCdNotIn = "";
	}

}
