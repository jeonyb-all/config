package com.adtcaps.tsop.onm.api.sms.service;

import com.adtcaps.tsop.onm.api.sms.domain.SmsAccessInformation;

/**
 * SmsAccessInformationService.
 * @author zeal77@sk.com
 */
public interface SmsAccessInformationService {
    /**
     * 접속 정보 초기 설정.
     * @return 결과
     */
    SmsAccessInformation initAccessInformation();
    /**
     * 접속 정보
     * @param building_id 빌딩 아이디.
     * @return 접속 정보 결과
     */
    SmsAccessInformation getAccessInfo();
        /**
     * 접속 정보 업데이트.
     * @param smsAccessInformation 업데이트 할 접속 정보
     */
    void updateAccessInfo(SmsAccessInformation smsAccessInformation);
}
