package com.adtcaps.tsop.onm.api.deploy.domain;

import com.adtcaps.tsop.onm.api.helper.domain.BasePageDto;

import lombok.Getter;
import lombok.Setter;

/**
 * 
 * <ul>
 * <li>업무 그룹명 : tsop-onm-api</li>
 * <li>서브 업무명 : com.adtcaps.tsop.onm.api.deploy.domain</li>
 * <li>설  명 : PackageDeployJobGridRequestDto.java</li>
 * <li>작성일 : 2021. 2. 4.</li>
 * <li>작성자 : jeonyb4</li>
 * </ul>
 */
@Getter
@Setter
public class PackageDeployJobGridRequestDto extends BasePageDto {
	private String pkgReleaseTypeCd;
	private String workExecResultCd;
	
	public PackageDeployJobGridRequestDto() {
		this.pkgReleaseTypeCd = "";
		this.workExecResultCd = "";
	}
	
}
