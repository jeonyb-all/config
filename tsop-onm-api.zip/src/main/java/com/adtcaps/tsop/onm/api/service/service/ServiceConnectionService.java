package com.adtcaps.tsop.onm.api.service.service;

import java.util.List;

import com.adtcaps.tsop.onm.api.domain.OomServiceConnectionApiListDto;
import com.adtcaps.tsop.onm.api.domain.OomServiceConnectionDto;
import com.adtcaps.tsop.onm.api.service.domain.LinkageStandardVersionForComboResultDto;
import com.adtcaps.tsop.onm.api.service.domain.ServiceConnectionDetailResultDto;
import com.adtcaps.tsop.onm.api.service.domain.ServiceConnectionGridRequestDto;
import com.adtcaps.tsop.onm.api.service.domain.ServiceConnectionGridResultDto;
import com.adtcaps.tsop.onm.api.service.domain.ServiceConnectionProcessingDto;
import com.adtcaps.tsop.onm.api.service.domain.ServiceSysLinkageMethodForComboResultDto;
import com.adtcaps.tsop.onm.api.service.domain.ServiceSysNameForComboResultDto;

/**
 * 
 * <ul>
 * <li>업무 그룹명 : tsop-onm-api</li>
 * <li>서브 업무명 : com.adtcaps.tsop.onm.api.service.service</li>
 * <li>설  명 : ServiceConnectionService.java</li>
 * <li>작성일 : 2021. 1. 24.</li>
 * <li>작성자 : jeonyb4</li>
 * </ul>
 */
public interface ServiceConnectionService {
	/**
	 * 
	 * listServiceSysLinkageMethodForCombo
	 *
	 * @param reqOomServiceConnectionDto
	 * @return List<ServiceSysLinkageMethodForComboResultDto>
	 * @throws Exception 
	 */
	public List<ServiceSysLinkageMethodForComboResultDto> listServiceSysLinkageMethodForCombo(OomServiceConnectionDto reqOomServiceConnectionDto) throws Exception;
	
	/**
	 * 
	 * listServiceSysNameForCombo
	 *
	 * @param reqOomServiceConnectionDto
	 * @return List<ServiceSysNameForComboResultDto>
	 * @throws Exception 
	 */
	public List<ServiceSysNameForComboResultDto> listServiceSysNameForCombo(OomServiceConnectionDto reqOomServiceConnectionDto) throws Exception;
	
	/**
	 * 
	 * listLinkageStandardVersionForCombo
	 *
	 * @param reqOomServiceConnectionDto
	 * @return List<LinkageStandardVersionForComboResultDto>
	 * @throws Exception 
	 */
	public List<LinkageStandardVersionForComboResultDto> listLinkageStandardVersionForCombo(OomServiceConnectionDto reqOomServiceConnectionDto) throws Exception;
	
	/**
	 * 
	 * listPageServiceConnection
	 *
	 * @param alarmConditionGridRequestDto
	 * @return List<ServiceConnectionGridResultDto>
	 * @throws Exception 
	 */
	public List<ServiceConnectionGridResultDto> listPageServiceConnection(ServiceConnectionGridRequestDto serviceConnectionGridRequestDto) throws Exception;
	
	/**
	 * 
	 * listConnectionApiListExcel
	 *
	 * @param reqOomServiceConnectionApiListDto
	 * @param fileName
	 * @return String
	 * @throws Exception 
	 */
	public String listConnectionApiListExcel(OomServiceConnectionApiListDto reqOomServiceConnectionApiListDto, String fileName) throws Exception;
	
	/**
	 * 
	 * createServiceConnection
	 *
	 * @param serviceConnectionProcessingDto
	 * @return String
	 * @throws Exception 
	 */
	public String createServiceConnection(ServiceConnectionProcessingDto serviceConnectionProcessingDto) throws Exception;
	
	/**
	 * 
	 * readServiceConnection
	 *
	 * @param reqOomServiceConnectionDto
	 * @return ServiceConnectionDetailResultDto
	 * @throws Exception 
	 */
	public ServiceConnectionDetailResultDto readServiceConnection(OomServiceConnectionDto reqOomServiceConnectionDto) throws Exception;
	
	/**
	 * 
	 * deleteServiceConnectionAttachFile
	 *
	 * @param reqOomServiceConnectionDto
	 * @return int
	 * @throws Exception 
	 */
	public int deleteServiceConnectionAttachFile(OomServiceConnectionDto reqOomServiceConnectionDto) throws Exception;
	
	/**
	 * 
	 * updateServiceConnection
	 *
	 * @param reqServiceConnectionProcessingDto
	 * @return String
	 * @throws Exception 
	 */
	public String updateServiceConnection(ServiceConnectionProcessingDto reqServiceConnectionProcessingDto) throws Exception;
	
	/**
	 * 
	 * deleteServiceConnection
	 *
	 * @param reqOomServiceConnectionDto
	 * @return int
	 * @throws Exception 
	 */
	public int deleteServiceConnection(OomServiceConnectionDto reqOomServiceConnectionDto) throws Exception;

}
