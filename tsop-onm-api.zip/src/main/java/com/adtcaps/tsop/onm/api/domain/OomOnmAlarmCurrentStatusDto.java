package com.adtcaps.tsop.onm.api.domain;

import lombok.Getter;
import lombok.Setter;

/**
 * 
 * <ul>
 * <li>업무 그룹명 : tsop-onm-api</li>
 * <li>서브 업무명 : com.adtcaps.tsop.onm.api.domain</li>
 * <li>설  명 : OomOnmAlarmCurrentStatusDto.java</li>
 * <li>작성일 : 2021. 2. 6.</li>
 * <li>작성자 : jeonyb4</li>
 * </ul>
 */
@Getter
@Setter
public class OomOnmAlarmCurrentStatusDto {
	private String tenantId;
	private String onmResourceId;
	private String onmAlarmCd;
	private String eventDatetime;
	private String auditDatetime;
	private String auditId;
	private String onmAlarmYn;
	private String onmAlarmMaskYn;

}
