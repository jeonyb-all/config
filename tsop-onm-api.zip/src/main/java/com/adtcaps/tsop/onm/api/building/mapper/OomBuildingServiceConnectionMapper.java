package com.adtcaps.tsop.onm.api.building.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;

import com.adtcaps.tsop.onm.api.building.domain.BuildingServiceConnectionDetailResultDto;
import com.adtcaps.tsop.onm.api.building.domain.BuildingServiceConnectionGridRequestDto;
import com.adtcaps.tsop.onm.api.building.domain.BuildingServiceConnectionGridResultDto;
import com.adtcaps.tsop.onm.api.domain.OomBuildingServiceConnectionDto;

/**
 * 
 * <ul>
 * <li>업무 그룹명 : tsop-onm-api</li>
 * <li>서브 업무명 : com.adtcaps.tsop.onm.api.building.mapper</li>
 * <li>설  명 : OomBuildingServiceConnectionMapper.java</li>
 * <li>작성일 : 2021. 1. 6.</li>
 * <li>작성자 : jeonyb4</li>
 * </ul>
 */
@Mapper
public interface OomBuildingServiceConnectionMapper {
	/**
	 * 
	 * readBuildingServiceConnection
	 *
	 * @param reqOomBuildingServiceConnectionDto
	 * @return OomBuildingServiceConnectionDto
	 */
	public OomBuildingServiceConnectionDto readBuildingServiceConnection(OomBuildingServiceConnectionDto reqOomBuildingServiceConnectionDto);
	
	/**
	 * 
	 * readBuildingServiceConnectionCount
	 *
	 * @param reqOomBuildingServiceConnectionDto
	 * @return int
	 */
	public int readBuildingServiceConnectionCount(OomBuildingServiceConnectionDto reqOomBuildingServiceConnectionDto);
	
	/**
	 * 
	 * listBuildingServiceConnection
	 *
	 * @param reqOomBuildingServiceConnectionDto
	 * @return List<OomBuildingServiceConnectionDto>
	 */
	public List<OomBuildingServiceConnectionDto> listBuildingServiceConnection(OomBuildingServiceConnectionDto reqOomBuildingServiceConnectionDto);
	
	/**
	 * 
	 * listPageBuildingServiceConnection
	 *
	 * @param buildingServiceConnectionGridRequestDto
	 * @return List<BuildingServiceConnectionGridResultDto>
	 */
	public List<BuildingServiceConnectionGridResultDto> listPageBuildingServiceConnection(BuildingServiceConnectionGridRequestDto buildingServiceConnectionGridRequestDto);
	
	/**
	 * 
	 * readOomBuildingServiceConnectionInfo
	 *
	 * @param reqOomBuildingServiceConnectionDto
	 * @return BuildingServiceConnectionDetailResultDto
	 */
	public BuildingServiceConnectionDetailResultDto readOomBuildingServiceConnectionInfo(OomBuildingServiceConnectionDto reqOomBuildingServiceConnectionDto);

}
