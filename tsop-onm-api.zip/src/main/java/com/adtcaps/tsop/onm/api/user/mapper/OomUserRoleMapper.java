package com.adtcaps.tsop.onm.api.user.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;

import com.adtcaps.tsop.onm.api.domain.OomUserRoleDto;
import com.adtcaps.tsop.onm.api.helper.domain.BasePageDto;
import com.adtcaps.tsop.onm.api.user.domain.UserRoleForComboResultDto;
import com.adtcaps.tsop.onm.api.user.domain.UserRoleGridResultDto;

/**
 * 
 * <ul>
 * <li>업무 그룹명 : tsop-onm-api</li>
 * <li>서브 업무명 : com.adtcaps.tsop.onm.api.user.mapper</li>
 * <li>설  명 : OomUserRoleMapper.java</li>
 * <li>작성일 : 2021. 1. 4.</li>
 * <li>작성자 : jeonyb4</li>
 * </ul>
 */
@Mapper
public interface OomUserRoleMapper {
	/**
	 * 
	 * listUserRoleForCombo
	 *
	 * @return List<UserRoleForComboResultDto>
	 */
	public List<UserRoleForComboResultDto> listUserRoleForCombo();
	
	/**
	 * 
	 * listPageUserRole
	 *
	 * @param reqBasePageDto
	 * @return List<UserRoleGridResultDto>
	 */
	public List<UserRoleGridResultDto> listPageUserRole(BasePageDto reqBasePageDto);
	
	/**
	 * 
	 * readUserRoleDuplicationByName
	 *
	 * @param reqOomUserRoleDto
	 * @return int
	 */
	public int readUserRoleDuplicationByName(OomUserRoleDto reqOomUserRoleDto);
	
	/**
	 * 
	 * createOomUserRole
	 *
	 * @param reqOomUserRoleDto
	 * @return int
	 */
	public int createOomUserRole(OomUserRoleDto reqOomUserRoleDto);
	
	/**
	 * 
	 * readOomUserRole
	 *
	 * @param reqOomUserRoleDto
	 * @return OomUserRoleDto
	 */
	public OomUserRoleDto readOomUserRole(OomUserRoleDto reqOomUserRoleDto);
	
	/**
	 * 
	 * updateOomUserRole
	 *
	 * @param reqOomUserRoleDto
	 * @return int
	 */
	public int updateOomUserRole(OomUserRoleDto reqOomUserRoleDto);
	
	/**
	 * 
	 * deleteOomUserRole
	 *
	 * @param reqOomUserRoleDto
	 * @return int
	 */
	public int deleteOomUserRole(OomUserRoleDto reqOomUserRoleDto);

}
