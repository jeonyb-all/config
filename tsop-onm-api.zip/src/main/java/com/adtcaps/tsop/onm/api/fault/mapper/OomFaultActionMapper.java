package com.adtcaps.tsop.onm.api.fault.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;

import com.adtcaps.tsop.onm.api.domain.OomFaultActionDto;
import com.adtcaps.tsop.onm.api.fault.domain.FaultActionGridResultDto;

/**
 * 
 * <ul>
 * <li>업무 그룹명 : tsop-onm-api</li>
 * <li>서브 업무명 : com.adtcaps.tsop.onm.api.fault.mapper</li>
 * <li>설  명 : OomFaultActionMapper.java</li>
 * <li>작성일 : 2021. 1. 17.</li>
 * <li>작성자 : jeonyb4</li>
 * </ul>
 */
@Mapper
public interface OomFaultActionMapper {
	/**
	 * 
	 * listFaultAction
	 *
	 * @param reqOomFaultActionDto
	 * @return List<FaultActionGridResultDto>
	 */
	public List<FaultActionGridResultDto> listFaultAction(OomFaultActionDto reqOomFaultActionDto);
	
	/**
	 * 
	 * createOomFaultAction
	 *
	 * @param reqOomFaultActionDto
	 * @return int
	 */
	public int createOomFaultAction(OomFaultActionDto reqOomFaultActionDto);
	
	/**
	 * 
	 * updateFaultActionAttachFileNum
	 *
	 * @param reqOomFaultActionDto
	 * @return int
	 */
	public int updateFaultActionAttachFileNum(OomFaultActionDto reqOomFaultActionDto);
	
	/**
	 * 
	 * deleteOomFaultAction
	 *
	 * @param reqOomFaultActionDto
	 * @return int
	 */
	public int deleteOomFaultAction(OomFaultActionDto reqOomFaultActionDto);
	
}
