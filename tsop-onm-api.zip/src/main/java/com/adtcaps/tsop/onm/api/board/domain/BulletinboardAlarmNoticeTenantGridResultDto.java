package com.adtcaps.tsop.onm.api.board.domain;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

import lombok.Getter;
import lombok.Setter;

/**
 * 
 * <ul>
 * <li>업무 그룹명 : tsop-onm-api</li>
 * <li>서브 업무명 : com.adtcaps.tsop.onm.api.board.domain</li>
 * <li>설  명 : BulletinboardAlarmNoticeTenantGridResultDto.java</li>
 * <li>작성일 : 2021. 2. 5.</li>
 * <li>작성자 : jeonyb4</li>
 * </ul>
 */
@Getter
@Setter
@JsonInclude(Include.NON_EMPTY)
public class BulletinboardAlarmNoticeTenantGridResultDto {
	private Integer rowNum;
	private String rcvTenantId;
	private String rcvTenantName;

}
