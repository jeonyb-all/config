package com.adtcaps.tsop.onm.api.table.domain;

import com.adtcaps.tsop.onm.api.helper.domain.BasePageDto;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

import lombok.Getter;
import lombok.Setter;

/**
 * 
 * <ul>
 * <li>업무 그룹명 : tsop-onm-api</li>
 * <li>서브 업무명 : com.adtcaps.tsop.onm.api.table.domain</li>
 * <li>설  명 : DbTableGridResultDto.java</li>
 * <li>작성일 : 2021. 1. 7.</li>
 * <li>작성자 : jeonyb4</li>
 * </ul>
 */
@Getter
@Setter
@JsonInclude(Include.NON_EMPTY)
public class DbTableGridResultDto extends BasePageDto {
	private Integer rowNum;
	private String tableId;
	private String tableName;
	private String registDate;
	private String serviceClCd;
	private Integer dayUnitKeepCycleVal;
	private String initialDataReleaseYn;
	private String serviceClName;

}
