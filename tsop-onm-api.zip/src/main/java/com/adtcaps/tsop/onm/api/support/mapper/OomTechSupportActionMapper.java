package com.adtcaps.tsop.onm.api.support.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;

import com.adtcaps.tsop.onm.api.domain.OomTechSupportActionDto;
import com.adtcaps.tsop.onm.api.support.domain.TechSupportActionGridResultDto;

/**
 * 
 * <ul>
 * <li>업무 그룹명 : tsop-onm-api</li>
 * <li>서브 업무명 : com.adtcaps.tsop.onm.api.support.mapper</li>
 * <li>설  명 : OomTechSupportActionMapper.java</li>
 * <li>작성일 : 2021. 1. 3.</li>
 * <li>작성자 : jeonyb4</li>
 * </ul>
 */
@Mapper
public interface OomTechSupportActionMapper {
	/**
	 * 
	 * listTechSupportAction
	 *
	 * @param reqOomTechSupportActionDto
	 * @return List<TechSupportActionGridResultDto>
	 */
	public List<TechSupportActionGridResultDto> listTechSupportAction(OomTechSupportActionDto reqOomTechSupportActionDto);
	
	/**
	 * 
	 * createOomTechSupportAction
	 *
	 * @param reqOomTechSupportActionDto
	 * @return int
	 */
	public int createOomTechSupportAction(OomTechSupportActionDto reqOomTechSupportActionDto);
	
	/**
	 * 
	 * updateTechSupportActionAttachFileNum
	 *
	 * @param reqOomTechSupportActionDto
	 * @return int
	 */
	public int updateTechSupportActionAttachFileNum(OomTechSupportActionDto reqOomTechSupportActionDto);
	
	/**
	 * 
	 * deleteOomTechSupportAction
	 *
	 * @param reqOomTechSupportActionDto
	 * @return int
	 */
	public int deleteOomTechSupportAction(OomTechSupportActionDto reqOomTechSupportActionDto);

}
