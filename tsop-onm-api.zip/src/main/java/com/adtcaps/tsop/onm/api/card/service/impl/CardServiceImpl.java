package com.adtcaps.tsop.onm.api.card.service.impl;

import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.CollectionUtils;

import com.adtcaps.tsop.onm.api.card.domain.TenantDashboardCardDetailResultDto;
import com.adtcaps.tsop.onm.api.card.domain.TenantDashboardCardGridRequestDto;
import com.adtcaps.tsop.onm.api.card.domain.TenantDashboardCardGridResultDto;
import com.adtcaps.tsop.onm.api.card.mapper.OomTenantDashboardCardMapper;
import com.adtcaps.tsop.onm.api.card.service.CardService;
import com.adtcaps.tsop.onm.api.domain.OomTenantDashboardCardDto;
import com.adtcaps.tsop.onm.api.helper.util.CommonDateUtil;
import com.adtcaps.tsop.onm.api.helper.util.CommonObjectUtil;

/**
 * 
 * <ul>
 * <li>업무 그룹명 : tsop-onm-api</li>
 * <li>서브 업무명 : com.adtcaps.tsop.onm.api.card.service.impl</li>
 * <li>설  명 : CardServiceImpl.java</li>
 * <li>작성일 : 2021. 1. 11.</li>
 * <li>작성자 : jeonyb4</li>
 * </ul>
 */
@Transactional
@Service
public class CardServiceImpl implements CardService {
	
	@Autowired
	private OomTenantDashboardCardMapper oomTenantDashboardCardMapper;
	
	/**
	 * 
	 * listPageTenantDashboardCard
	 *
	 * @param tenantDashboardCardGridRequestDto
	 * @return List<TenantDashboardCardGridResultDto>
	 * @throws Exception 
	 */
	@Override
	public List<TenantDashboardCardGridResultDto> listPageTenantDashboardCard(TenantDashboardCardGridRequestDto tenantDashboardCardGridRequestDto) throws Exception {
		
		List<TenantDashboardCardGridResultDto> tenantDashboardCardGridResultDtoList = null;
		try {
			tenantDashboardCardGridResultDtoList = oomTenantDashboardCardMapper.listPageTenantDashboardCard(tenantDashboardCardGridRequestDto);
    		if (!CollectionUtils.isEmpty(tenantDashboardCardGridResultDtoList)) {
    			for (int idx = 0; idx < tenantDashboardCardGridResultDtoList.size(); idx++) {
    				
    				TenantDashboardCardGridResultDto tenantDashboardCardGridResultDto = tenantDashboardCardGridResultDtoList.get(idx);
    				
    				String popupSize = "";
    				String popupWidthSizeStr = "";
    				String popupLengthSizeStr = "";
    				double popupWidthSize = CommonObjectUtil.defaultNumber(tenantDashboardCardGridResultDto.getPopupWidthSize());
    				double popupLengthSize = CommonObjectUtil.defaultNumber(tenantDashboardCardGridResultDto.getPopupLengthSize());
    				if (popupWidthSize > 0) {
    					popupWidthSizeStr = String.valueOf(popupWidthSize);
    				}
    				if (popupWidthSize > 0) {
    					popupLengthSizeStr = String.valueOf(popupLengthSize);
    				}
    				if (!"".equals(popupWidthSizeStr) && !"".equals(popupLengthSizeStr)) {
    					StringBuilder popupSizeBuilder = new StringBuilder();
    					popupSizeBuilder.append(popupWidthSizeStr);
    					popupSizeBuilder.append(" X ");
    					popupSizeBuilder.append(popupLengthSizeStr);
    					popupSize = popupSizeBuilder.toString();
    				} else {
    					if (!"".equals(popupWidthSizeStr)) {
    						popupSize = popupWidthSizeStr;
    					} else if (!"".equals(popupLengthSizeStr)) {
    						popupSize = popupLengthSizeStr;
    					}
    				}
    				tenantDashboardCardGridResultDto.setPopupSize(popupSize);
    				
    				String registDatetime = StringUtils.defaultString(tenantDashboardCardGridResultDto.getRegistDatetime());
    				registDatetime = CommonDateUtil.makeDatetimeFormat(registDatetime);
    				tenantDashboardCardGridResultDto.setRegistDatetime(registDatetime);
    				
    				tenantDashboardCardGridResultDtoList.set(idx, tenantDashboardCardGridResultDto);
    			}
    		}
    		
		} catch (Exception e) {
			throw e;
		}
		return tenantDashboardCardGridResultDtoList;
	}
	
	/**
	 * 
	 * createTenantDashboardCard
	 *
	 * @param reqOomTenantDashboardCardDto
	 * @return int
	 * @throws Exception 
	 */
	@Override
	public int createTenantDashboardCard(OomTenantDashboardCardDto reqOomTenantDashboardCardDto) throws Exception {
		
		int affectRowCount = 0;
		
		try {
			// 테넌트별대시보드카드 등록...
			int insertRow = oomTenantDashboardCardMapper.createOomTenantDashboardCard(reqOomTenantDashboardCardDto);
			affectRowCount = affectRowCount + insertRow;
			
		} catch (Exception e) {
			throw e;
		}
		
		return affectRowCount;
	}
	
	/**
	 * 
	 * readTenantDashboardCard
	 *
	 * @param reqOomTenantDashboardCardDto
	 * @return TenantDashboardCardDetailResultDto
	 * @throws Exception 
	 */
	@Override
	public TenantDashboardCardDetailResultDto readTenantDashboardCard(OomTenantDashboardCardDto reqOomTenantDashboardCardDto) throws Exception {
		
		TenantDashboardCardDetailResultDto tenantDashboardCardDetailResultDto = null;
		
		try {
			// 테넌트별대시보드카드 상세조회...
			tenantDashboardCardDetailResultDto = oomTenantDashboardCardMapper.readOomTenantDashboardCard(reqOomTenantDashboardCardDto);
			if (tenantDashboardCardDetailResultDto != null) {
				String registDatetime = StringUtils.defaultString(tenantDashboardCardDetailResultDto.getRegistDatetime());
				registDatetime = CommonDateUtil.makeDatetimeFormat(registDatetime);
				tenantDashboardCardDetailResultDto.setRegistDatetime(registDatetime);
			}
			
		} catch (Exception e) {
			throw e;
		}
		
		return tenantDashboardCardDetailResultDto;
	}
	
	/**
	 * 
	 * updateTenantDashboardCard
	 *
	 * @param reqOomTenantDashboardCardDto
	 * @return int
	 * @throws Exception 
	 */
	@Override
	public int updateTenantDashboardCard(OomTenantDashboardCardDto reqOomTenantDashboardCardDto) throws Exception {
		
		int affectRowCount = 0;
		
		try {
			// 테넌트별대시보드카드 수정...
			int updateRow = oomTenantDashboardCardMapper.updateOomTenantDashboardCard(reqOomTenantDashboardCardDto);
			affectRowCount = affectRowCount + updateRow;
			
		} catch (Exception e) {
			throw e;
		}
		
		return affectRowCount;
	}
	
	/**
	 * 
	 * deleteTenantDashboardCard
	 *
	 * @param reqOomTenantDashboardCardDto
	 * @return int
	 * @throws Exception 
	 */
	@Override
	public int deleteTenantDashboardCard(OomTenantDashboardCardDto reqOomTenantDashboardCardDto) throws Exception {
		
		int affectRowCount = 0;
		
		try {
			// 테넌트별대시보드카드 삭제...
			int deleteRow = oomTenantDashboardCardMapper.deleteOomTenantDashboardCard(reqOomTenantDashboardCardDto);
			affectRowCount = affectRowCount + deleteRow;
			
		} catch (Exception e) {
			throw e;
		}
		
		return affectRowCount;
	}
	
	/**
	 * 
	 * readTTenantDashboardCardSameCardNameCount
	 *
	 * @param reqOomTenantDashboardCardDto
	 * @return int
	 * @throws Exception 
	 */
	@Override
	public int readTTenantDashboardCardSameCardNameCount(OomTenantDashboardCardDto reqOomTenantDashboardCardDto) throws Exception {
		
		int cardCount = 0;
		
		try {
			cardCount = oomTenantDashboardCardMapper.readTTenantDashboardCardSameCardNameCount(reqOomTenantDashboardCardDto);
			
		} catch (Exception e) {
			throw e;
		}
		
		return cardCount;
	}

}
