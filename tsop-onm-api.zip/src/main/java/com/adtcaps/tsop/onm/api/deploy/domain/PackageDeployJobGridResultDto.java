package com.adtcaps.tsop.onm.api.deploy.domain;

import com.adtcaps.tsop.onm.api.helper.domain.BasePageDto;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

import lombok.Getter;
import lombok.Setter;

/**
 * 
 * <ul>
 * <li>업무 그룹명 : tsop-onm-api</li>
 * <li>서브 업무명 : com.adtcaps.tsop.onm.api.deploy.domain</li>
 * <li>설  명 : PackageDeployJobGridResultDto.java</li>
 * <li>작성일 : 2021. 2. 4.</li>
 * <li>작성자 : jeonyb4</li>
 * </ul>
 */
@Getter
@Setter
@JsonInclude(Include.NON_EMPTY)
public class PackageDeployJobGridResultDto extends BasePageDto {
	private Integer rowNum;
	private String tenantId;
	private String pkgWorkId;
	private String tenantName;
	private String pkgReleaseTypeCd;
	private String pkgReleaseTypeName;
	private String pkgName;
	private String workStartDatetime;
	private String workEndDatetime;
	private String workExecResultCd;
	private String workExecResultName;

}
