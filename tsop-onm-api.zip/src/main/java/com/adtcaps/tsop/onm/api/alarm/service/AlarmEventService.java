package com.adtcaps.tsop.onm.api.alarm.service;

import java.util.List;

import com.adtcaps.tsop.onm.api.alarm.domain.AlarmEventGridRequestDto;
import com.adtcaps.tsop.onm.api.alarm.domain.AlarmEventGridResultDto;
import com.adtcaps.tsop.onm.api.alarm.domain.SendAlarmRequestDto;
import com.adtcaps.tsop.onm.api.domain.OomFaultDto;
import com.adtcaps.tsop.onm.api.fault.domain.FaultDetailResultDto;

/**
 * 
 * <ul>
 * <li>업무 그룹명 : tsop-onm-api</li>
 * <li>서브 업무명 : com.adtcaps.tsop.onm.api.alarm.service</li>
 * <li>설  명 : AlarmEventService.java</li>
 * <li>작성일 : 2021. 1. 8.</li>
 * <li>작성자 : jeonyb4</li>
 * </ul>
 */
public interface AlarmEventService {
	/**
	 * 
	 * listPageAlarmEvent
	 *
	 * @param alarmEventGridRequestDto
	 * @return List<AlarmEventGridResultDto>
	 * @throws Exception 
	 */
	public List<AlarmEventGridResultDto> listPageAlarmEvent(AlarmEventGridRequestDto alarmEventGridRequestDto) throws Exception;
	
	/**
	 * 
	 * sendSmsAlarm
	 *
	 * @param sendAlarmRequestDto
	 * @return int
	 * @throws Exception 
	 */
	public int sendSmsAlarm(SendAlarmRequestDto sendAlarmRequestDto) throws Exception;
	
	/**
	 * 
	 * readAlarmForFault
	 *
	 * @param reqOomFaultDto
	 * @return FaultDetailResultDto
	 * @throws Exception 
	 */
	public FaultDetailResultDto readAlarmForFault(OomFaultDto reqOomFaultDto) throws Exception;
	
	/**
	 * 
	 * readAlarmForFaultSmsMessage
	 *
	 * @param reqOomFaultDto
	 * @return FaultDetailResultDto
	 * @throws Exception 
	 */
	public FaultDetailResultDto readAlarmForFaultSmsMessage(OomFaultDto reqOomFaultDto) throws Exception;

}
