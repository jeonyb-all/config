package com.adtcaps.tsop.onm.api.menu.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.util.CollectionUtils;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.adtcaps.tsop.onm.api.authentication.domain.JwtAuthResultDto;
import com.adtcaps.tsop.onm.api.domain.OomTenantServicePortalMenuDto;
import com.adtcaps.tsop.onm.api.domain.OomUserRoleAuthorityDetailDto;
import com.adtcaps.tsop.onm.api.helper.constant.Const;
import com.adtcaps.tsop.onm.api.helper.domain.BasePageDto;
import com.adtcaps.tsop.onm.api.helper.domain.ResultDto;
import com.adtcaps.tsop.onm.api.helper.util.CommonObjectUtil;
import com.adtcaps.tsop.onm.api.helper.util.PageUtil;
import com.adtcaps.tsop.onm.api.menu.domain.TenantServicePortalMenuDetailResultDto;
import com.adtcaps.tsop.onm.api.menu.domain.TenantServicePortalMenuForComboResultDto;
import com.adtcaps.tsop.onm.api.menu.domain.TenantServicePortalMenuForShortGridResultDto;
import com.adtcaps.tsop.onm.api.menu.domain.TenantServicePortalMenuGridRequestDto;
import com.adtcaps.tsop.onm.api.menu.domain.TenantServicePortalMenuGridResultDto;
import com.adtcaps.tsop.onm.api.menu.service.PortalMenuService;
import com.adtcaps.tsop.onm.api.user.domain.UserRoleMenuAuthorityRequestDto;
import com.adtcaps.tsop.onm.api.user.service.UserRoleService;

import lombok.extern.slf4j.Slf4j;

/**
 * 
 * <ul>
 * <li>업무 그룹명 : tsop-onm-api</li>
 * <li>서브 업무명 : com.adtcaps.tsop.onm.api.menu.controller</li>
 * <li>설  명 : PortalMenuController.java</li>
 * <li>작성일 : 2021. 1. 11.</li>
 * <li>작성자 : jeonyb4</li>
 * </ul>
 */
@Slf4j
@RestController
@RequestMapping("/api/portal-menus")
public class PortalMenuController {
	
	private final String MENU_ID = "ONM0024";
	
	private final String ERR_MSG_NULL_LOGIN_USER_ID = "로그인 사용자ID가 없습니다.";
	private final String ERR_MSG_NULL_MGR_YN = "관리자여부가 없습니다.";
	private final String ERR_MSG_NULL_TENANT_ID = "테넌트ID가 없습니다.";
	private final String ERR_MSG_NULL_PAGE_NUMBER = "페이지 번호가 없습니다.";
	private final String ERR_MSG_NULL_MENU_NAME = "메뉴명이 없습니다.";
	private final String ERR_MSG_NULL_GROUPMGMT_PAGE_YN = "군관리페이지여부가 없습니다.";
	private final String ERR_MSG_NULL_MENU_EXPOSE_YN = "메뉴노출여부가 없습니다.";
	private final String ERR_MSG_NULL_MENU_LEVEL_VAL = "메뉴레벨값이 없습니다.";
	
	private final String ERR_MSG_CANNOT_USE_SUPER_MENU = "해당 레벨은 상위메뉴를 지정할 수 없습니다.";
	private final String ERR_MSG_ALREADY_EXIST_CHILD_MENU = "해당 메뉴에 대한 하위 메뉴가 존재하므로 삭제할 수 없습니다.";
	private final String ERR_MSG_ALREADY_EXIST_MENU_NAME = "해당 메뉴에 대한 메뉴명이 존재하므로 저장할 수 없습니다.";
	
	private final String ERR_MSG_NO_AUTH = "권한이 없는 사용자 입니다.";
	private final String ERR_MSG_NULL_SEARCH_RESULT_LIST = "조회 결과가 없습니다.";
	private final String ERR_MSG_CREATE_FAIL = "등록에 실패하였습니다.";
	private final String ERR_MSG_SEARCH_FAIL = "조회에 실패하였습니다.";
	private final String ERR_MSG_UPDATE_FAIL = "수정에 실패하였습니다.";
	private final String ERR_MSG_DELETE_FAIL = "삭제에 실패하였습니다.";
	
	@Autowired
	private PortalMenuService portalMenuService;
	
	@Autowired
	private UserRoleService userRoleService;
	
	/**
	 * 
	 * listTenantServicePortalMenuForCombo
	 *
	 * @param reqOomTenantServicePortalMenuDto
	 * @return ResponseEntity
	 * @throws Exception 
	 */
	@SuppressWarnings("rawtypes")
    @GetMapping(value="/super-menus/combobox", produces="application/json; charset=UTF-8")
    public ResponseEntity listTenantServicePortalMenuForCombo(OomTenantServicePortalMenuDto reqOomTenantServicePortalMenuDto) throws Exception {
        
    	ResponseEntity<ResultDto> resEntity = null;
		String returnString = "";
    	
		String tenantId = StringUtils.defaultString(reqOomTenantServicePortalMenuDto.getTenantId());
		if ("".equals(tenantId)) {
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_TENANT_ID));
			return resEntity;
		}
		int menuLevelVal = CommonObjectUtil.defaultNumber(reqOomTenantServicePortalMenuDto.getMenuLevelVal());
		if (menuLevelVal < 1) {
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_MENU_LEVEL_VAL));
			return resEntity;
		}
		if (menuLevelVal < 2) {
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_CANNOT_USE_SUPER_MENU));
			return resEntity;
		}
		
		// 콤보박스 제공용  테넌트별서비스포털메뉴 상위메뉴 목록조회....
		List<TenantServicePortalMenuForComboResultDto> tenantServicePortalMenuForComboResultDtoList = portalMenuService.listTenantServicePortalMenuForCombo(reqOomTenantServicePortalMenuDto);
		if (CollectionUtils.isEmpty(tenantServicePortalMenuForComboResultDtoList)) {
			returnString = Const.Common.RESULT_CODE.SUCCESS;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_SEARCH_RESULT_LIST, tenantServicePortalMenuForComboResultDtoList));
		} else {
			returnString = Const.Common.RESULT_CODE.SUCCESS;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, "", tenantServicePortalMenuForComboResultDtoList));
		}
    	
    	return resEntity;
    }
	
	/**
	 * 
	 * listTenantServicePortalMenuForShortGrid
	 *
	 * @param reqBasePageDto
	 * @return ResponseEntity
	 */
	@SuppressWarnings("rawtypes")
    @GetMapping(value="/short-grid", produces="application/json; charset=UTF-8")
    public ResponseEntity listTenantServicePortalMenuForShortGrid(BasePageDto reqBasePageDto) throws Exception {
        
    	ResponseEntity<ResultDto> resEntity = null;
		String returnString = "";
    	
		String tenantId = StringUtils.defaultString(reqBasePageDto.getTenantId());
		if ("".equals(tenantId)) {
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_TENANT_ID));
			return resEntity;
		}
		
		// 팝업 제공용  테넌트별서비스포털메뉴 목록조회....
		Map<String, Object> tenantServicePortalMenuForShortGridResultDtoListMap = new HashMap<String, Object>();
		List<TenantServicePortalMenuForShortGridResultDto> tenantServicePortalMenuForShortGridResultDtoList = portalMenuService.listTenantServicePortalMenuForShortGrid(reqBasePageDto);
		if (CollectionUtils.isEmpty(tenantServicePortalMenuForShortGridResultDtoList)) {
			returnString = Const.Common.RESULT_CODE.SUCCESS;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_SEARCH_RESULT_LIST, tenantServicePortalMenuForShortGridResultDtoListMap));
		} else {
			returnString = Const.Common.RESULT_CODE.SUCCESS;
			int totalCount = tenantServicePortalMenuForShortGridResultDtoList.size();
			Map<String, Object> totalCountMap = new HashMap<String, Object>();
			totalCountMap.put("totalCount", totalCount);
			
			tenantServicePortalMenuForShortGridResultDtoListMap.put(Const.Definition.PAGE.PAGER, totalCountMap);
			tenantServicePortalMenuForShortGridResultDtoListMap.put(Const.Definition.PAGE.LISTS, tenantServicePortalMenuForShortGridResultDtoList);
			resEntity = ResponseEntity.ok(new ResultDto(returnString, "", tenantServicePortalMenuForShortGridResultDtoListMap));
		}
    	
    	return resEntity;
    }
	
	/**
	 * 
	 * listPageTenantServicePortalMenu
	 *
	 * @param tenantServicePortalMenuGridRequestDto
	 * @return ResponseEntity
	 */
	@SuppressWarnings("rawtypes")
    @GetMapping(value="", produces="application/json; charset=UTF-8")
    public ResponseEntity listPageTenantServicePortalMenu(TenantServicePortalMenuGridRequestDto tenantServicePortalMenuGridRequestDto) throws Exception {
        
    	ResponseEntity<ResultDto> resEntity = null;
		String returnString = "";
    	
		int pageNumber = tenantServicePortalMenuGridRequestDto.getPageNumber();
		if (pageNumber < 1) {
			log.error(">>>>>> pageNumber ERROR:{}", ERR_MSG_NULL_PAGE_NUMBER);
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_PAGE_NUMBER));
			return resEntity;
		}
		
		// 테넌트별서비스포털메뉴 목록조회....
		Map<String, Object> tenantServicePortalMenuGridResultDtoListMap = new HashMap<String, Object>();
		List<TenantServicePortalMenuGridResultDto> tenantServicePortalMenuGridResultDtoList = portalMenuService.listPageTenantServicePortalMenu(tenantServicePortalMenuGridRequestDto);
		if (CollectionUtils.isEmpty(tenantServicePortalMenuGridResultDtoList)) {
			returnString = Const.Common.RESULT_CODE.SUCCESS;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_SEARCH_RESULT_LIST, tenantServicePortalMenuGridResultDtoListMap));
		} else {
			returnString = Const.Common.RESULT_CODE.SUCCESS;
			tenantServicePortalMenuGridResultDtoListMap.put(Const.Definition.PAGE.PAGER, PageUtil.getPageInfo(tenantServicePortalMenuGridResultDtoList));
			tenantServicePortalMenuGridResultDtoListMap.put(Const.Definition.PAGE.LISTS, tenantServicePortalMenuGridResultDtoList);
			resEntity = ResponseEntity.ok(new ResultDto(returnString, "", tenantServicePortalMenuGridResultDtoListMap));
		}
    	
    	return resEntity;
    }
	
	/**
	 * 
	 * createTenantServicePortalMenu
	 *
	 * @param authResultDto
	 * @param reqOomTenantServicePortalMenuDto
	 * @return ResponseEntity
	 */
	@SuppressWarnings("rawtypes")
    @PostMapping(value="", produces="application/json; charset=UTF-8")
    public ResponseEntity createTenantServicePortalMenu(@AuthenticationPrincipal JwtAuthResultDto authResultDto, 
    		@RequestBody OomTenantServicePortalMenuDto reqOomTenantServicePortalMenuDto) throws Exception {
        
    	ResponseEntity<ResultDto> resEntity = null;
		String returnString = "";
    	
		String loginUserId = StringUtils.defaultString(authResultDto.getUserId());
		if ("".equals(loginUserId)) {
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_LOGIN_USER_ID));
			return resEntity;
		}
		String mgrYn = StringUtils.defaultString(authResultDto.getMgrYn());
		if ("".equals(mgrYn)) {
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_MGR_YN));
			return resEntity;
		}
		//String loginUserId = "tsop-admin"; // 이후 세션에서 얻어올 값...
		
		if (!"Y".equals(mgrYn)) {
			String authorityTypeCd = "";
			UserRoleMenuAuthorityRequestDto userRoleMenuAuthorityRequestDto = new UserRoleMenuAuthorityRequestDto();
			userRoleMenuAuthorityRequestDto.setUserId(loginUserId);
			userRoleMenuAuthorityRequestDto.setMenuId(MENU_ID);
			OomUserRoleAuthorityDetailDto rsltOomUserRoleAuthorityDetailDto = userRoleService.readMenuAuthority(userRoleMenuAuthorityRequestDto);
			if (rsltOomUserRoleAuthorityDetailDto != null) {
				authorityTypeCd = StringUtils.defaultString(rsltOomUserRoleAuthorityDetailDto.getAuthorityTypeCd());
			}
			if (!"W".equals(authorityTypeCd)) {
				returnString = Const.Common.RESULT_CODE.FAIL;
				resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NO_AUTH));
				return resEntity;
			}
		}
		
		String tenantId = StringUtils.defaultString(reqOomTenantServicePortalMenuDto.getTenantId());
		if ("".equals(tenantId)) {
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_TENANT_ID));
			return resEntity;
		}
		String menuName = StringUtils.defaultString(reqOomTenantServicePortalMenuDto.getMenuName());
		if ("".equals(menuName)) {
			log.error(">>>>>> menuName ERROR:{}", ERR_MSG_NULL_MENU_NAME);
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_MENU_NAME));
			return resEntity;
		}
		String groupmgmtPageYn = StringUtils.defaultString(reqOomTenantServicePortalMenuDto.getGroupmgmtPageYn());
		if ("".equals(groupmgmtPageYn)) {
			log.error(">>>>>> groupmgmtPageYn ERROR:{}", ERR_MSG_NULL_GROUPMGMT_PAGE_YN);
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_GROUPMGMT_PAGE_YN));
			return resEntity;
		}
		String menuExposeYn = StringUtils.defaultString(reqOomTenantServicePortalMenuDto.getMenuExposeYn());
		if ("".equals(menuExposeYn)) {
			log.error(">>>>>> menuExposeYn ERROR:{}", ERR_MSG_NULL_MENU_EXPOSE_YN);
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_MENU_EXPOSE_YN));
			return resEntity;
		}
		
		reqOomTenantServicePortalMenuDto.setAuditId(loginUserId);
		reqOomTenantServicePortalMenuDto.setRegisterId(loginUserId);
		
		// 같은 메뉴명이 존재하는지 확인
		int menuCount = portalMenuService.readTenantServicePortalMenuSameMenuNameCount(reqOomTenantServicePortalMenuDto);
		if (menuCount > 0) {
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_ALREADY_EXIST_MENU_NAME));
			return resEntity;
		}
		
		// 테넌트별서비스포털메뉴 등록...
		int affectRowCount = portalMenuService.createTenantServicePortalMenu(reqOomTenantServicePortalMenuDto);
		if (affectRowCount < 1) {
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_CREATE_FAIL, affectRowCount));
		} else {
			returnString = Const.Common.RESULT_CODE.SUCCESS;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, "", affectRowCount));
		}
    	
    	return resEntity;
    }
	
	/**
	 * 
	 * readTenantServicePortalMenu
	 *
	 * @param menuId
	 * @param reqOomTenantServicePortalMenuDto
	 * @return ResponseEntity
	 */
	@SuppressWarnings("rawtypes")
    @GetMapping(value="/{menuId}", produces="application/json; charset=UTF-8")
    public ResponseEntity readTenantServicePortalMenu(@PathVariable("menuId") String menuId, OomTenantServicePortalMenuDto reqOomTenantServicePortalMenuDto) throws Exception {
        
    	ResponseEntity<ResultDto> resEntity = null;
		String returnString = "";
    	
		String tenantId = StringUtils.defaultString(reqOomTenantServicePortalMenuDto.getTenantId());
		if ("".equals(tenantId)) {
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_TENANT_ID));
			return resEntity;
		}
		
		reqOomTenantServicePortalMenuDto.setMenuId(menuId);
		
		// 테넌트별서비스포털메뉴 상세조회....
		TenantServicePortalMenuDetailResultDto tenantServicePortalMenuDetailResultDto = portalMenuService.readTenantServicePortalMenu(reqOomTenantServicePortalMenuDto);
		if (tenantServicePortalMenuDetailResultDto == null) {
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_SEARCH_FAIL, tenantServicePortalMenuDetailResultDto));
		} else {
			returnString = Const.Common.RESULT_CODE.SUCCESS;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, "", tenantServicePortalMenuDetailResultDto));
		}
    	
    	return resEntity;
    }
	
	/**
	 * 
	 * updateTenantServicePortalMenu
	 *
	 * @param authResultDto
	 * @param menuId
	 * @param reqOomTenantServicePortalMenuDto
	 * @return ResponseEntity
	 */
	@SuppressWarnings("rawtypes")
    @PutMapping(value="/{menuId}", produces="application/json; charset=UTF-8")
    public ResponseEntity updateTenantServicePortalMenu(@AuthenticationPrincipal JwtAuthResultDto authResultDto, 
    		@PathVariable("menuId") String menuId, @RequestBody OomTenantServicePortalMenuDto reqOomTenantServicePortalMenuDto) throws Exception {
        
    	ResponseEntity<ResultDto> resEntity = null;
		String returnString = "";
    	
		String loginUserId = StringUtils.defaultString(authResultDto.getUserId());
		if ("".equals(loginUserId)) {
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_LOGIN_USER_ID));
			return resEntity;
		}
		String mgrYn = StringUtils.defaultString(authResultDto.getMgrYn());
		if ("".equals(mgrYn)) {
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_MGR_YN));
			return resEntity;
		}
		//String loginUserId = "tsop-admin"; // 이후 세션에서 얻어올 값...
		
		if (!"Y".equals(mgrYn)) {
			String authorityTypeCd = "";
			UserRoleMenuAuthorityRequestDto userRoleMenuAuthorityRequestDto = new UserRoleMenuAuthorityRequestDto();
			userRoleMenuAuthorityRequestDto.setUserId(loginUserId);
			userRoleMenuAuthorityRequestDto.setMenuId(MENU_ID);
			OomUserRoleAuthorityDetailDto rsltOomUserRoleAuthorityDetailDto = userRoleService.readMenuAuthority(userRoleMenuAuthorityRequestDto);
			if (rsltOomUserRoleAuthorityDetailDto != null) {
				authorityTypeCd = StringUtils.defaultString(rsltOomUserRoleAuthorityDetailDto.getAuthorityTypeCd());
			}
			if (!"W".equals(authorityTypeCd)) {
				returnString = Const.Common.RESULT_CODE.FAIL;
				resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NO_AUTH));
				return resEntity;
			}
		}
		
		String tenantId = StringUtils.defaultString(reqOomTenantServicePortalMenuDto.getTenantId());
		if ("".equals(tenantId)) {
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_TENANT_ID));
			return resEntity;
		}
		String menuName = StringUtils.defaultString(reqOomTenantServicePortalMenuDto.getMenuName());
		if ("".equals(menuName)) {
			log.error(">>>>>> menuName ERROR:{}", ERR_MSG_NULL_MENU_NAME);
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_MENU_NAME));
			return resEntity;
		}
		String groupmgmtPageYn = StringUtils.defaultString(reqOomTenantServicePortalMenuDto.getGroupmgmtPageYn());
		if ("".equals(groupmgmtPageYn)) {
			log.error(">>>>>> groupmgmtPageYn ERROR:{}", ERR_MSG_NULL_GROUPMGMT_PAGE_YN);
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_GROUPMGMT_PAGE_YN));
			return resEntity;
		}
		String menuExposeYn = StringUtils.defaultString(reqOomTenantServicePortalMenuDto.getMenuExposeYn());
		if ("".equals(menuExposeYn)) {
			log.error(">>>>>> menuExposeYn ERROR:{}", ERR_MSG_NULL_MENU_EXPOSE_YN);
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_MENU_EXPOSE_YN));
			return resEntity;
		}
		
		reqOomTenantServicePortalMenuDto.setMenuId(menuId);
		reqOomTenantServicePortalMenuDto.setAuditId(loginUserId);
		
		// 같은 메뉴명이 존재하는지 확인
		int menuCount = portalMenuService.readTenantServicePortalMenuSameMenuNameCount(reqOomTenantServicePortalMenuDto);
		if (menuCount > 0) {
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_ALREADY_EXIST_MENU_NAME));
			return resEntity;
		}
		
		// 테넌트별서비스포털메뉴 수정...
		int affectRowCount = portalMenuService.updateTenantServicePortalMenu(reqOomTenantServicePortalMenuDto);
		if (affectRowCount < 1) {
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_UPDATE_FAIL, affectRowCount));
		} else {
			returnString = Const.Common.RESULT_CODE.SUCCESS;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, "", affectRowCount));
		}
    	
    	return resEntity;
    }
	
	/**
	 * 
	 * deleteTenantServicePortalMenu
	 *
	 * @param menuId
	 * @param reqOomTenantServicePortalMenuDto
	 * @return ResponseEntity
	 */
	@SuppressWarnings("rawtypes")
    @DeleteMapping(value="/{menuId}", produces="application/json; charset=UTF-8")
    public ResponseEntity deleteTenantServicePortalMenu(@AuthenticationPrincipal JwtAuthResultDto authResultDto, 
    		@PathVariable("menuId") String menuId, @RequestBody OomTenantServicePortalMenuDto reqOomTenantServicePortalMenuDto) throws Exception {
        
    	ResponseEntity<ResultDto> resEntity = null;
		String returnString = "";
    	
		String loginUserId = StringUtils.defaultString(authResultDto.getUserId());
		if ("".equals(loginUserId)) {
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_LOGIN_USER_ID));
			return resEntity;
		}
		String mgrYn = StringUtils.defaultString(authResultDto.getMgrYn());
		if ("".equals(mgrYn)) {
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_MGR_YN));
			return resEntity;
		}
		//String loginUserId = "tsop-admin"; // 이후 세션에서 얻어올 값...
		
		if (!"Y".equals(mgrYn)) {
			String authorityTypeCd = "";
			UserRoleMenuAuthorityRequestDto userRoleMenuAuthorityRequestDto = new UserRoleMenuAuthorityRequestDto();
			userRoleMenuAuthorityRequestDto.setUserId(loginUserId);
			userRoleMenuAuthorityRequestDto.setMenuId(MENU_ID);
			OomUserRoleAuthorityDetailDto rsltOomUserRoleAuthorityDetailDto = userRoleService.readMenuAuthority(userRoleMenuAuthorityRequestDto);
			if (rsltOomUserRoleAuthorityDetailDto != null) {
				authorityTypeCd = StringUtils.defaultString(rsltOomUserRoleAuthorityDetailDto.getAuthorityTypeCd());
			}
			if (!"W".equals(authorityTypeCd)) {
				returnString = Const.Common.RESULT_CODE.FAIL;
				resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NO_AUTH));
				return resEntity;
			}
		}
		
		String tenantId = StringUtils.defaultString(reqOomTenantServicePortalMenuDto.getTenantId());
		if ("".equals(tenantId)) {
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_TENANT_ID));
			return resEntity;
		}
		
		reqOomTenantServicePortalMenuDto.setMenuId(menuId);
		
		// 해당 메뉴의 자식메뉴가 있는지 확인...
		int childMenuCount = portalMenuService.readTenantServicePortalChildMenuCount(reqOomTenantServicePortalMenuDto);
		if (childMenuCount > 0) {
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_ALREADY_EXIST_CHILD_MENU));
			return resEntity;
		}
		
		// 테넌트별서비스포털메뉴 삭제...
		int affectRowCount = portalMenuService.deleteTenantServicePortalMenu(reqOomTenantServicePortalMenuDto);
		if (affectRowCount < 1) {
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_DELETE_FAIL, affectRowCount));
		} else {
			returnString = Const.Common.RESULT_CODE.SUCCESS;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, "", affectRowCount));
		}
    	
    	return resEntity;
    }

}
