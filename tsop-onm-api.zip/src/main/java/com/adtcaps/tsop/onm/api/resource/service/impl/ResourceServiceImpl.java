package com.adtcaps.tsop.onm.api.resource.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.adtcaps.tsop.onm.api.domain.OomOnmResourceDto;
import com.adtcaps.tsop.onm.api.resource.domain.ResourceCategoryForComboResultDto;
import com.adtcaps.tsop.onm.api.resource.mapper.OomOnmResourceMapper;
import com.adtcaps.tsop.onm.api.resource.service.ResourceService;

/**
 * 
 * <ul>
 * <li>업무 그룹명 : tsop-onm-api</li>
 * <li>서브 업무명 : com.adtcaps.tsop.onm.api.resource.service.impl</li>
 * <li>설  명 : ResourceServiceImpl.java</li>
 * <li>작성일 : 2021. 1. 8.</li>
 * <li>작성자 : jeonyb4</li>
 * </ul>
 */
@Service
public class ResourceServiceImpl implements ResourceService {
	
	@Autowired
	private OomOnmResourceMapper oomOnmResourceMapper;
	
	/**
	 * 
	 * listResourceCategoryForCombo
	 *
	 * @return List<ResourceCategoryForComboResultDto>
	 * @throws Exception 
	 */
	@Override
	public List<ResourceCategoryForComboResultDto> listResourceCategoryForCombo() throws Exception {
		
		List<ResourceCategoryForComboResultDto> resourceCategoryForComboResultDtoList = null;
		try {
			resourceCategoryForComboResultDtoList = oomOnmResourceMapper.listResourceCategoryForCombo();
		} catch (Exception e) {
			throw e;
		}
		return resourceCategoryForComboResultDtoList;
	}
	
	/**
	 * 
	 * readResourceCategoryIdByName
	 *
	 * @param reqOomOnmResourceDto
	 * @return List<ResourceCategoryForComboResultDto>
	 * @throws Exception 
	 */
	@Override
	public ResourceCategoryForComboResultDto readResourceCategoryIdByName(OomOnmResourceDto reqOomOnmResourceDto) throws Exception {
		
		ResourceCategoryForComboResultDto resourceCategoryForComboResultDto = null;
		try {
			resourceCategoryForComboResultDto = oomOnmResourceMapper.readResourceCategoryIdByName(reqOomOnmResourceDto);
		} catch (Exception e) {
			throw e;
		}
		return resourceCategoryForComboResultDto;
	}

}
