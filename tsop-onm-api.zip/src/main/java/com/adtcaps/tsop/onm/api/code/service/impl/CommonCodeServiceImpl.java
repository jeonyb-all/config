package com.adtcaps.tsop.onm.api.code.service.impl;

import java.io.File;
import java.io.FileOutputStream;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.io.FileUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.poi.hssf.util.HSSFColor.HSSFColorPredefined;
import org.apache.poi.ss.usermodel.BorderStyle;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.FillPatternType;
import org.apache.poi.ss.usermodel.HorizontalAlignment;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.xssf.streaming.SXSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.CollectionUtils;

import com.adtcaps.tsop.onm.api.code.domain.CommonCodeGridRequestDto;
import com.adtcaps.tsop.onm.api.code.domain.CommonCodeGridResultDto;
import com.adtcaps.tsop.onm.api.code.domain.CommonCodeRequestDto;
import com.adtcaps.tsop.onm.api.code.mapper.OomCommonCodeMapper;
import com.adtcaps.tsop.onm.api.code.service.CommonCodeService;
import com.adtcaps.tsop.onm.api.config.AzureBlobConfig;
import com.adtcaps.tsop.onm.api.domain.OomCommonCodeDto;
import com.adtcaps.tsop.onm.api.helper.constant.Const;
import com.adtcaps.tsop.onm.api.helper.service.HelperService;
import com.adtcaps.tsop.onm.api.helper.util.CommonDateUtil;

/**
 * 
 * <ul>
 * <li>업무 그룹명 : tsop-onm-api</li>
 * <li>서브 업무명 : com.adtcaps.tsop.onm.api.code.service.impl</li>
 * <li>설  명 : CommonCodeServiceImpl.java</li>
 * <li>작성일 : 2021. 1. 4.</li>
 * <li>작성자 : jeonyb4</li>
 * </ul>
 */
@Transactional
@Service
public class CommonCodeServiceImpl implements CommonCodeService {
	
	@Autowired
	private OomCommonCodeMapper oomCommonCodeMapper;
	
	@Autowired
	private AzureBlobConfig azureBlobConfig;
	
	@Autowired
	private HelperService helperService;
	
	/**
	 * 
	 * listPageCommonCode
	 *
	 * @param commonCodeGridRequestDto
	 * @return List<CommonCodeGridResultDto>
	 * @throws Exception 
	 */
	@Override
	public List<CommonCodeGridResultDto> listPageCommonCode(CommonCodeGridRequestDto commonCodeGridRequestDto) throws Exception {
		
		List<CommonCodeGridResultDto> commonCodeGridResultDtoList = null;
		try {
			commonCodeGridResultDtoList = oomCommonCodeMapper.listPageCommonCode(commonCodeGridRequestDto);
			if (!CollectionUtils.isEmpty(commonCodeGridResultDtoList)) {
				for (int idx=0; idx < commonCodeGridResultDtoList.size(); idx ++) {
					
					CommonCodeGridResultDto commonCodeGridResultDto = commonCodeGridResultDtoList.get(idx);
					
					String effectStartDatetime = StringUtils.defaultString(commonCodeGridResultDto.getEffectStartDatetime());
					String effectEndDatetime = StringUtils.defaultString(commonCodeGridResultDto.getEffectEndDatetime());
					effectStartDatetime = CommonDateUtil.makeDatetimeToDateFormat(effectStartDatetime);
					effectEndDatetime = CommonDateUtil.makeDatetimeToDateFormat(effectEndDatetime);
					
					commonCodeGridResultDto.setEffectStartDatetime(effectStartDatetime);
					commonCodeGridResultDto.setEffectEndDatetime(effectEndDatetime);
					
					String useYn = StringUtils.defaultString(commonCodeGridResultDto.getUseYn());
    				if ("Y".equals(useYn)) {
    					commonCodeGridResultDto.setUseYn(Const.Definition.USE_YN.USE);
    				} else {
    					commonCodeGridResultDto.setUseYn(Const.Definition.USE_YN.NO_USE);
    				}
					
					commonCodeGridResultDtoList.set(idx, commonCodeGridResultDto);
				}
			}
    		
		} catch (Exception e) {
			throw e;
		}
		return commonCodeGridResultDtoList;
	}
	
	/**
	 * 
	 * listCommonCodeExcel
	 *
	 * @param commonCodeGridRequestDto
	 * @param fileName
	 * @return String
	 * @throws Exception 
	 */
	@Override
	public String listCommonCodeExcel(CommonCodeGridRequestDto commonCodeGridRequestDto, String fileName) throws Exception {
		
		SXSSFWorkbook wb = null;
		String fileFullPathName = "";
		FileOutputStream fileOut = null;
		
		try {
			
			String downloadTempBasePath = azureBlobConfig.getAzureBlobInfo().getDownloadTempBasePath();
    		String currentMilliSeconds = helperService.readCurrentMilliSeconds();
			
    		// 디렉토리 생성
    		StringBuilder downloadPathBuilder = new StringBuilder();
    		downloadPathBuilder.append(downloadTempBasePath);
    		downloadPathBuilder.append("/");
    		downloadPathBuilder.append(currentMilliSeconds);
            
            File downloadTempDirectory = new File(downloadPathBuilder.toString());
            if (!downloadTempDirectory.isDirectory()) {
            	FileUtils.forceMkdir(downloadTempDirectory);
            }
            
            StringBuilder fileFullPathNameBuilder = new StringBuilder();
            fileFullPathNameBuilder.append(downloadPathBuilder.toString());
            fileFullPathNameBuilder.append("/");
            fileFullPathNameBuilder.append(fileName);
            
            // 파일명 (FullPath)
            fileFullPathName = fileFullPathNameBuilder.toString();
            
            // 워크북 생성
            wb = new SXSSFWorkbook();
            
            // 테이블 헤더용 스타일
            CellStyle headStyle = wb.createCellStyle();
            // 가는 경계선을 가집니다.
            headStyle.setBorderTop(BorderStyle.THIN);
            headStyle.setBorderBottom(BorderStyle.THIN);
            headStyle.setBorderLeft(BorderStyle.THIN);
            headStyle.setBorderRight(BorderStyle.THIN);
            // 배경색은 노란색입니다.
            headStyle.setFillForegroundColor(HSSFColorPredefined.YELLOW.getIndex());
            headStyle.setFillPattern(FillPatternType.SOLID_FOREGROUND);
            headStyle.setAlignment(HorizontalAlignment.CENTER);
            
            // 데이터용 경계 스타일 테두리만 지정
            CellStyle bodyStyle = wb.createCellStyle();
            bodyStyle.setBorderTop(BorderStyle.THIN);
            bodyStyle.setBorderBottom(BorderStyle.THIN);
            bodyStyle.setBorderLeft(BorderStyle.THIN);
            bodyStyle.setBorderRight(BorderStyle.THIN);
            
            Sheet sheet = wb.createSheet("코드정보");
			
			Row row = null;
	        Cell cell = null;
	        int rowNo = 0;
			
			// 헤더 생성
            row = sheet.createRow(rowNo++);
            
            sheet.setColumnWidth(0, 5500);
            cell = row.createCell(0);
            cell.setCellStyle(headStyle);
            cell.setCellValue("공통코드명");
            
            sheet.setColumnWidth(1, 5500);
            cell = row.createCell(1);
            cell.setCellStyle(headStyle);
            cell.setCellValue("공통코드");
            
            sheet.setColumnWidth(2, 9500);
            cell = row.createCell(2);
            cell.setCellStyle(headStyle);
            cell.setCellValue("공통코드설명");
            
            sheet.setColumnWidth(3, 2500);
            cell = row.createCell(3);
            cell.setCellStyle(headStyle);
            cell.setCellValue("사용여부");
            
            sheet.setColumnWidth(4, 3500);
            cell = row.createCell(4);
            cell.setCellStyle(headStyle);
            cell.setCellValue("서비스유형");
            
            sheet.setColumnWidth(5, 4500);
            cell = row.createCell(5);
            cell.setCellStyle(headStyle);
            cell.setCellValue("시작일자");
            
            List<CommonCodeGridResultDto> commonCodeGridResultDtoList = oomCommonCodeMapper.listPageCommonCode(commonCodeGridRequestDto);;
			if (!CollectionUtils.isEmpty(commonCodeGridResultDtoList)) {
				for (CommonCodeGridResultDto commonCodeGridResultDto : commonCodeGridResultDtoList) {
					String commonCdName = StringUtils.defaultString(commonCodeGridResultDto.getCommonCdName());
					String commonCd = StringUtils.defaultString(commonCodeGridResultDto.getCommonCd());
					String commonCdDesc = StringUtils.defaultString(commonCodeGridResultDto.getCommonCdDesc());
					String useYn = StringUtils.defaultString(commonCodeGridResultDto.getUseYn());
					String serviceClName = StringUtils.defaultString(commonCodeGridResultDto.getServiceClName());
					String effectStartDatetime = StringUtils.defaultString(commonCodeGridResultDto.getEffectStartDatetime());
					
					effectStartDatetime = CommonDateUtil.makeDatetimeToDateFormat(effectStartDatetime);
					
					if ("Y".equals(useYn)) {
						useYn = Const.Definition.USE_YN.USE;
    				} else {
    					useYn = Const.Definition.USE_YN.NO_USE;
    				}
					
					row = sheet.createRow(rowNo++);
	                cell = row.createCell(0);
	                cell.setCellStyle(bodyStyle);
	                cell.setCellValue(commonCdName);
	                
	                cell = row.createCell(1);
	                cell.setCellStyle(bodyStyle);
	                cell.setCellValue(commonCd);
	                
	                cell = row.createCell(2);
	                cell.setCellStyle(bodyStyle);
	                cell.setCellValue(commonCdDesc);
	                
	                cell = row.createCell(3);
	                cell.setCellStyle(bodyStyle);
	                cell.setCellValue(useYn);
	                
	                cell = row.createCell(4);
	                cell.setCellStyle(bodyStyle);
	                cell.setCellValue(serviceClName);
	                
	                cell = row.createCell(5);
	                cell.setCellStyle(bodyStyle);
	                cell.setCellValue(effectStartDatetime);
				}
			}
			
			fileOut = new FileOutputStream(fileFullPathName);
			wb.write(fileOut);
    		
		} catch (Exception e) {
			throw e;
		} finally {
			if (wb != null) {
				wb.close();
			}
			if (fileOut != null) {
				fileOut.close();
			}
		}
		
		return fileFullPathName;
	}
	
	/**
	 * 
	 * readCommonCodeDuplicationCheck
	 *
	 * @param reqOomCommonCodeDto
	 * @return int
	 * @throws Exception 
	 */
	@Override
	public int readCommonCodeDuplicationCheck(OomCommonCodeDto reqOomCommonCodeDto) throws Exception {
		
		int commonCdCount = 1;
		try {
			commonCdCount = oomCommonCodeMapper.readCommonCodeDuplicationCheck(reqOomCommonCodeDto);
		} catch (Exception e) {
			throw e;
		}
		return commonCdCount;
	}
	
	/**
	 * 
	 * createCommonCode
	 *
	 * @param reqOomCommonCodeDto
	 * @return int
	 * @throws Exception 
	 */
	@Override
	public int createCommonCode(OomCommonCodeDto reqOomCommonCodeDto) throws Exception {
		
		int affectRowCount = 0;
		
		try {
			String effectStartDatetime = StringUtils.defaultString(reqOomCommonCodeDto.getEffectStartDatetime());
    		String effectEndDatetime = StringUtils.defaultString(reqOomCommonCodeDto.getEffectEndDatetime());
    		effectStartDatetime = CommonDateUtil.makeFromDatetime(effectStartDatetime);
    		effectEndDatetime = CommonDateUtil.makeToDatetime(effectEndDatetime);
    		reqOomCommonCodeDto.setEffectStartDatetime(effectStartDatetime);
    		reqOomCommonCodeDto.setEffectEndDatetime(effectEndDatetime);
    		
			int insertRow = oomCommonCodeMapper.createOomCommonCode(reqOomCommonCodeDto);
			affectRowCount = affectRowCount + insertRow;
			
		} catch (Exception e) {
			throw e;
		}
		
		return affectRowCount;
	}
	
	/**
	 * 
	 * readCommonCode
	 *
	 * @param reqOomCommonCodeDto
	 * @return OomCommonCodeDto
	 * @throws Exception 
	 */
	@Override
	public OomCommonCodeDto readCommonCode(OomCommonCodeDto reqOomCommonCodeDto) throws Exception {
		
		OomCommonCodeDto rsltOomCommonCodeDto = null;
		try {
			rsltOomCommonCodeDto = oomCommonCodeMapper.readOomCommonCode(reqOomCommonCodeDto);
			if (rsltOomCommonCodeDto != null) {
				String effectStartDatetime = StringUtils.defaultString(rsltOomCommonCodeDto.getEffectStartDatetime());
				String effectEndDatetime = StringUtils.defaultString(rsltOomCommonCodeDto.getEffectEndDatetime());
				effectStartDatetime = CommonDateUtil.makeDatetimeToDateFormat(effectStartDatetime);
				effectEndDatetime = CommonDateUtil.makeDatetimeToDateFormat(effectEndDatetime);
				rsltOomCommonCodeDto.setEffectStartDatetime(effectStartDatetime);
				rsltOomCommonCodeDto.setEffectEndDatetime(effectEndDatetime);
			}
		} catch (Exception e) {
			throw e;
		}
		return rsltOomCommonCodeDto;
	}
	
	/**
	 * 
	 * updateCommonCode
	 *
	 * @param reqOomCommonCodeDto
	 * @return int
	 * @throws Exception 
	 */
	@Override
	public int updateCommonCode(OomCommonCodeDto reqOomCommonCodeDto) throws Exception {
		
		int affectRowCount = 0;
		
		try {
			String effectStartDatetime = StringUtils.defaultString(reqOomCommonCodeDto.getEffectStartDatetime());
    		String effectEndDatetime = StringUtils.defaultString(reqOomCommonCodeDto.getEffectEndDatetime());
    		effectStartDatetime = CommonDateUtil.makeFromDatetime(effectStartDatetime);
    		effectEndDatetime = CommonDateUtil.makeToDatetime(effectEndDatetime);
    		reqOomCommonCodeDto.setEffectStartDatetime(effectStartDatetime);
    		reqOomCommonCodeDto.setEffectEndDatetime(effectEndDatetime);
			
			int updateRow = oomCommonCodeMapper.updateOomCommonCode(reqOomCommonCodeDto);
			affectRowCount = affectRowCount + updateRow;
			
		} catch (Exception e) {
			throw e;
		}
		
		return affectRowCount;
	}
	
	/**
	 * 
	 * deleteCommonCode
	 *
	 * @param reqOomCommonCodeDto
	 * @return int
	 * @throws Exception 
	 */
	@Override
	public int deleteCommonCode(OomCommonCodeDto reqOomCommonCodeDto) throws Exception {
		
		int affectRowCount = 0;
		
		try {
			int deleteRow = oomCommonCodeMapper.deleteOomCommonCode(reqOomCommonCodeDto);
			affectRowCount = affectRowCount + deleteRow;
			
		} catch (Exception e) {
			throw e;
		}
		
		return affectRowCount;
	}
	
	
	/**
	 * 
	 * listCommonCodeForCombo
	 *
	 * @param commonCodeRequestDto
	 * @return List<OomCommonCodeDto>
	 * @throws Exception 
	 */
	@Override
	public List<OomCommonCodeDto> listCommonCodeForCombo(CommonCodeRequestDto commonCodeRequestDto) throws Exception {
		
		List<OomCommonCodeDto> rsltOomCommonCodeDtoList = null;
		try {
			String commonCdIn = StringUtils.defaultString(commonCodeRequestDto.getCommonCdIn());
			String commonCdNotIn = StringUtils.defaultString(commonCodeRequestDto.getCommonCdNotIn());
			if (!"".equals(commonCdIn)) {
				List<String> commonCdInList = new ArrayList<String>();
				String[] commonCdInArr = StringUtils.split(commonCdIn, ",");
				for (int idx=0; idx < commonCdInArr.length; idx++) {
					commonCdInList.add(commonCdInArr[idx]);
				}
				commonCodeRequestDto.setCommonCdInList(commonCdInList);
			}
			if (!"".equals(commonCdNotIn)) {
				List<String> commonCdNotInList = new ArrayList<String>();
				String[] commonCdNotInArr = StringUtils.split(commonCdNotIn, ",");
				for (int idx=0; idx < commonCdNotInArr.length; idx++) {
					commonCdNotInList.add(commonCdNotInArr[idx]);
				}
				commonCodeRequestDto.setCommonCdNotInList(commonCdNotInList);
			}
			rsltOomCommonCodeDtoList = oomCommonCodeMapper.listCommonCodeForCombo(commonCodeRequestDto);
			
		} catch (Exception e) {
			throw e;
		}
		return rsltOomCommonCodeDtoList;
	}
	
	/**
	 * 
	 * updateCommonCodeReuse
	 *
	 * @param reqOomCommonCodeDto
	 * @return int
	 * @throws Exception 
	 */
	@Override
	public int updateCommonCodeReuse(OomCommonCodeDto reqOomCommonCodeDto) throws Exception {
		
		int affectRowCount = 0;
		
		try {
			int updateRow = oomCommonCodeMapper.updateCommonCodeReuse(reqOomCommonCodeDto);
			affectRowCount = affectRowCount + updateRow;
			
		} catch (Exception e) {
			throw e;
		}
		
		return affectRowCount;
	}

}
