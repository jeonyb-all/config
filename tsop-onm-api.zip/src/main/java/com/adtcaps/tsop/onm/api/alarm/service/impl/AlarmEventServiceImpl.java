package com.adtcaps.tsop.onm.api.alarm.service.impl;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import com.adtcaps.tsop.onm.api.alarm.domain.AlarmEventGridRequestDto;
import com.adtcaps.tsop.onm.api.alarm.domain.AlarmEventGridResultDto;
import com.adtcaps.tsop.onm.api.alarm.domain.AlarmNoticeReceiveGroupDetailDetailResultDto;
import com.adtcaps.tsop.onm.api.alarm.domain.SendAlarmRequestDto;
import com.adtcaps.tsop.onm.api.alarm.mapper.OomAlarmNoticeReceiveGroupDetailMapper;
import com.adtcaps.tsop.onm.api.alarm.mapper.OomOnmAlarmEventMapper;
import com.adtcaps.tsop.onm.api.alarm.service.AlarmEventService;
import com.adtcaps.tsop.onm.api.alarm.service.AlarmNoticeService;
import com.adtcaps.tsop.onm.api.alimTalk.domain.AlimTalkDetailDto;
import com.adtcaps.tsop.onm.api.alimTalk.domain.AlimTalkRequestDto;
import com.adtcaps.tsop.onm.api.alimTalk.mapper.OomKakaoAlimTalkMapper;
import com.adtcaps.tsop.onm.api.alimTalk.service.AlimTalkService;
import com.adtcaps.tsop.onm.api.domain.OomAlarmNoticeConditionDto;
import com.adtcaps.tsop.onm.api.domain.OomAlarmNoticeReceiveGroupDetailDto;
import com.adtcaps.tsop.onm.api.domain.OomFaultDto;
import com.adtcaps.tsop.onm.api.domain.OomKakaoAlimTalkDto;
import com.adtcaps.tsop.onm.api.fault.domain.FaultDetailResultDto;
import com.adtcaps.tsop.onm.api.helper.constant.Const;
import com.adtcaps.tsop.onm.api.helper.util.CommonDateUtil;

/**
 * 
 * <ul>
 * <li>업무 그룹명 : tsop-onm-api</li>
 * <li>서브 업무명 : com.adtcaps.tsop.onm.api.alarm.service.impl</li>
 * <li>설  명 : AlarmEventServiceImpl.java</li>
 * <li>작성일 : 2021. 1. 8.</li>
 * <li>작성자 : jeonyb4</li>
 * </ul>
 */
@Service
public class AlarmEventServiceImpl implements AlarmEventService {
	
	@Autowired
	private OomOnmAlarmEventMapper oomOnmAlarmEventMapper;
	
	@Autowired
	private OomAlarmNoticeReceiveGroupDetailMapper oomAlarmNoticeReceiveGroupDetailMapper;
	
	@Autowired
	private AlarmNoticeService alarmNoticeService;
	
	@Autowired
	private OomKakaoAlimTalkMapper oomKakaoAlimTalkMapper;
	
	@Autowired
	private AlimTalkService alimTalkService;
	
	/**
	 * 
	 * listPageAlarmEvent
	 *
	 * @param alarmEventGridRequestDto
	 * @return List<AlarmEventGridResultDto>
	 * @throws Exception 
	 */
	@Override
	public List<AlarmEventGridResultDto> listPageAlarmEvent(AlarmEventGridRequestDto alarmEventGridRequestDto) throws Exception {
		
		List<AlarmEventGridResultDto> alarmEventGridResultDtoList = null;
		try {
			String fromDate = alarmEventGridRequestDto.getFromDate();
    		String toDate = alarmEventGridRequestDto.getToDate();
    		
    		fromDate = CommonDateUtil.makeFromDatetime(fromDate);
    		toDate = CommonDateUtil.makeToDatetime(toDate);
    		
    		alarmEventGridRequestDto.setFromDate(fromDate);
    		alarmEventGridRequestDto.setToDate(toDate);
			
			alarmEventGridResultDtoList = oomOnmAlarmEventMapper.listPageAlarmEvent(alarmEventGridRequestDto);
			if (!CollectionUtils.isEmpty(alarmEventGridResultDtoList)) {
    			for (int idx = 0; idx < alarmEventGridResultDtoList.size(); idx++) {
    				
    				AlarmEventGridResultDto alarmEventGridResultDto = alarmEventGridResultDtoList.get(idx);
    				
    				String eventDatetime = StringUtils.defaultString(alarmEventGridResultDto.getEventDatetime());
    				String eventDatetimeFormat = CommonDateUtil.makeDatetimeFormat(eventDatetime);
    				alarmEventGridResultDto.setEventDatetimeFormat(eventDatetimeFormat);
    				
    				String alarmReleaseDatetime = StringUtils.defaultString(alarmEventGridResultDto.getAlarmReleaseDatetime());
    				alarmReleaseDatetime = CommonDateUtil.makeDatetimeFormat(alarmReleaseDatetime);
    				alarmEventGridResultDto.setAlarmReleaseDatetime(alarmReleaseDatetime);
    				
    				alarmEventGridResultDtoList.set(idx, alarmEventGridResultDto);
    			}
			}
		} catch (Exception e) {
			throw e;
		}
		return alarmEventGridResultDtoList;
	}
	
	/**
	 * 
	 * readAlarmForFault
	 *
	 * @param reqOomFaultDto
	 * @return FaultDetailResultDto
	 * @throws Exception 
	 */
	@Override
	public FaultDetailResultDto readAlarmForFault(OomFaultDto reqOomFaultDto) throws Exception {
		
		FaultDetailResultDto faultDetailResultDto = null;
		
		try {
			faultDetailResultDto = oomOnmAlarmEventMapper.readAlarmForFault(reqOomFaultDto);
		} catch (Exception e) {
			throw e;
		}
		return faultDetailResultDto;
	}
	
	/**
	 * 
	 * readAlarmForFaultSmsMessage
	 *
	 * @param reqOomFaultDto
	 * @return FaultDetailResultDto
	 * @throws Exception 
	 */
	@Override
	public FaultDetailResultDto readAlarmForFaultSmsMessage(OomFaultDto reqOomFaultDto) throws Exception {
		
		FaultDetailResultDto faultDetailResultDto = null;
		
		try {
			faultDetailResultDto = oomOnmAlarmEventMapper.readAlarmForFaultSmsMessage(reqOomFaultDto);
		} catch (Exception e) {
			throw e;
		}
		return faultDetailResultDto;
	}
	
	/**
	 * 
	 * sendSmsAlarm
	 *
	 * @param sendAlarmRequestDto
	 * @return int
	 * @throws Exception 
	 */
	@Override
	public int sendSmsAlarm(SendAlarmRequestDto sendAlarmRequestDto) throws Exception {
		
		int affectRowCount = 1;
		
		try {
			int onmAlarmEventId = sendAlarmRequestDto.getOnmAlarmEventId();
			String eventDatetime = sendAlarmRequestDto.getEventDatetime();
			String tenantId = sendAlarmRequestDto.getTenantId();
			String onmAlarmCd = sendAlarmRequestDto.getOnmAlarmCd();
			String onmAlarmGradeCd = sendAlarmRequestDto.getOnmAlarmGradeCd();
			
			OomAlarmNoticeConditionDto reqOomAlarmNoticeConditionDto = new OomAlarmNoticeConditionDto();
			reqOomAlarmNoticeConditionDto.setTenantId(tenantId);
			reqOomAlarmNoticeConditionDto.setOnmAlarmCd(onmAlarmCd);
			reqOomAlarmNoticeConditionDto.setOnmAlarmGradeCd(onmAlarmGradeCd);
			OomAlarmNoticeConditionDto rsltOomAlarmNoticeConditionDto = alarmNoticeService.readAlarmNoticeDuplicationCheck(reqOomAlarmNoticeConditionDto);
			if (rsltOomAlarmNoticeConditionDto != null) {
				int alarmNoticeGroupId = rsltOomAlarmNoticeConditionDto.getAlarmNoticeGroupId();
				
				OomFaultDto reqOomFaultDto = new OomFaultDto();
				reqOomFaultDto.setOnmAlarmEventId(onmAlarmEventId);
				reqOomFaultDto.setEventDatetime(eventDatetime);
				FaultDetailResultDto faultDetailResultDto = readAlarmForFaultSmsMessage(reqOomFaultDto);
				if (faultDetailResultDto != null) {
					OomKakaoAlimTalkDto reqOomKakaoAlimTalkDto = new OomKakaoAlimTalkDto();
					reqOomKakaoAlimTalkDto.setTmpltCode(Const.Definition.MSG_TEMPLATE_CODE.TSOP_007);
					reqOomKakaoAlimTalkDto.setSmsCreateCd(Const.Code.SMS_CREATE_CD.ALARM);
					OomKakaoAlimTalkDto oomKakaoAlimTalkDto = oomKakaoAlimTalkMapper.readKakaoAlimTalk(reqOomKakaoAlimTalkDto);
					if (oomKakaoAlimTalkDto != null) {
						List<AlimTalkDetailDto> alimTalkDetailDtoList = new ArrayList<AlimTalkDetailDto>();
						OomAlarmNoticeReceiveGroupDetailDto reqOomAlarmNoticeReceiveGroupDetailDto = new OomAlarmNoticeReceiveGroupDetailDto();
						reqOomAlarmNoticeReceiveGroupDetailDto.setAlarmNoticeGroupId(alarmNoticeGroupId);
						List<AlarmNoticeReceiveGroupDetailDetailResultDto> alarmNoticeReceiveGroupDetailDetailResultDtoList = oomAlarmNoticeReceiveGroupDetailMapper.listAlarmNoticeReceiveGroupDetail(reqOomAlarmNoticeReceiveGroupDetailDto);
						if (!CollectionUtils.isEmpty(alarmNoticeReceiveGroupDetailDetailResultDtoList)) {
							StringBuilder rcvPhoneNumBuilder = new StringBuilder();
							for (int idx = 0; idx < alarmNoticeReceiveGroupDetailDetailResultDtoList.size(); idx++) {
								AlarmNoticeReceiveGroupDetailDetailResultDto alarmNoticeReceiveGroupDetailDetailResultDto = alarmNoticeReceiveGroupDetailDetailResultDtoList.get(idx);
								String rcvPhoneNum = StringUtils.defaultString(alarmNoticeReceiveGroupDetailDetailResultDto.getRcvPhoneNum());
								if (rcvPhoneNumBuilder.toString().indexOf(rcvPhoneNum) < 0) {
									String rcverId = StringUtils.defaultString(alarmNoticeReceiveGroupDetailDetailResultDto.getRcverId());
									String rcverName = StringUtils.defaultString(alarmNoticeReceiveGroupDetailDetailResultDto.getRcverName());
									
									AlimTalkDetailDto alimTalkDetailDto = new AlimTalkDetailDto();
									alimTalkDetailDto.setRcverId(rcverId);
									alimTalkDetailDto.setRcverName(rcverName);
									alimTalkDetailDto.setRcvPhoneNum(rcvPhoneNum);
									alimTalkDetailDtoList.add(alimTalkDetailDto);
									
									if (rcvPhoneNumBuilder.length() == 0) {
										rcvPhoneNumBuilder.append(rcvPhoneNum);
									} else {
										rcvPhoneNumBuilder.append(",");
										rcvPhoneNumBuilder.append(rcvPhoneNum);
									}
								}
							}
							
							String tenantName = StringUtils.defaultString(faultDetailResultDto.getTenantName());
							String onmAlarmGradeName = StringUtils.defaultString(faultDetailResultDto.getOnmAlarmGradeName());
							String onmResourceName = StringUtils.defaultString(faultDetailResultDto.getOnmResourceName());
							String onmAlarmTypeName = StringUtils.defaultString(faultDetailResultDto.getOnmAlarmTypeName());
							String onmAlarmCdName = StringUtils.defaultString(faultDetailResultDto.getOnmAlarmCdName());
							
							String message = oomKakaoAlimTalkDto.getMessage();
							message = message.replaceAll("#\\{\"Major\"\\}", onmAlarmGradeName);
							message = message.replaceAll("#\\{\"알람\"\\}", "알람");
							message = message.replaceAll("#\\{\"발생\"\\}", "발생");
							message = message.replaceAll("#\\{\"SK 텔레콤\"\\}", tenantName);
							message = message.replaceAll("#\\{\"skt-opr-kc-connect3-plan\"\\}", onmResourceName);
							message = message.replaceAll("#\\{\"Memory\"\\}", onmAlarmTypeName);
							message = message.replaceAll("#\\{\"App Plan MEMORY 알람\"\\}", onmAlarmCdName);
							
							// 카카오 알림톡 발송 처리..
							AlimTalkRequestDto alimTalkRequestDto = new AlimTalkRequestDto();
							alimTalkRequestDto.setTenantId(tenantId);
							alimTalkRequestDto.setTmpltCode(Const.Definition.MSG_TEMPLATE_CODE.TSOP_007);
							alimTalkRequestDto.setRecipient(rcvPhoneNumBuilder.toString());
							alimTalkRequestDto.setMessage(message);
							alimTalkRequestDto.setSmsCreateCd(Const.Code.SMS_CREATE_CD.ALARM);
							alimTalkRequestDto.setAlarmNoticeGroupId(alarmNoticeGroupId);
							alimTalkRequestDto.setAuditId(Const.Definition.COMMON_VAL.SYSTEM_USER_ID);
							alimTalkRequestDto.setDetailList(alimTalkDetailDtoList);
							String alarmNoticeResultCd = alimTalkService.sendOnmAlimTalk(alimTalkRequestDto);
							if (!"1".equals(alarmNoticeResultCd)) {
								// 성공이 아니면.. 모두 실패 처리...
								affectRowCount = -9999;
							}
						}
					}
				}
			}
			
		} catch (Exception e) {
			throw e;
		}
		
		return affectRowCount;
	}

}
