package com.adtcaps.tsop.onm.api.threshold.domain;

import lombok.Getter;
import lombok.Setter;

/**
 * 
 * <ul>
 * <li>업무 그룹명 : tsop-onm-api</li>
 * <li>서브 업무명 : com.adtcaps.tsop.onm.api.threshold.domain</li>
 * <li>설  명 : ThresholdDetailResultDto.java</li>
 * <li>작성일 : 2021. 1. 17.</li>
 * <li>작성자 : jeonyb4</li>
 * </ul>
 */
@Getter
@Setter
public class ThresholdDetailResultDto {
	private String tenantId;
	private String onmAlarmCd;
	private String onmResourceId;
	private String tenantName;
	private String onmResourceCategoryCd;
	private String onmResourceCategoryCdName;
	private String onmResourceName;
	private String onmAlarmCdName;
	private String onmMetricUnit;
	private Integer criticalgStandardVal;
	private Integer majorgStandardVal;
	private Integer minorgStandardVal;
	private String registerId;
	private String registerName;
	private String registDatetime;
	
}
