package com.adtcaps.tsop.onm.api.code.service;

import java.util.List;

import com.adtcaps.tsop.onm.api.code.domain.CommonCodeGridRequestDto;
import com.adtcaps.tsop.onm.api.code.domain.CommonCodeGridResultDto;
import com.adtcaps.tsop.onm.api.code.domain.CommonCodeRequestDto;
import com.adtcaps.tsop.onm.api.domain.OomCommonCodeDto;

/**
 * 
 * <ul>
 * <li>업무 그룹명 : tsop-onm-api</li>
 * <li>서브 업무명 : com.adtcaps.tsop.onm.api.code.service</li>
 * <li>설  명 : CommonCodeService.java</li>
 * <li>작성일 : 2021. 1. 4.</li>
 * <li>작성자 : jeonyb4</li>
 * </ul>
 */
public interface CommonCodeService {
	/**
	 * 
	 * listPageCommonCode
	 *
	 * @param commonCodeGridRequestDto
	 * @return List<CommonCodeGridResultDto>
	 * @throws Exception 
	 */
	public List<CommonCodeGridResultDto> listPageCommonCode(CommonCodeGridRequestDto commonCodeGridRequestDto) throws Exception;
	
	/**
	 * 
	 * listCommonCodeExcel
	 *
	 * @param commonCodeGridRequestDto
	 * @param fileName
	 * @return String
	 * @throws Exception 
	 */
	public String listCommonCodeExcel(CommonCodeGridRequestDto commonCodeGridRequestDto, String fileName) throws Exception;
	
	/**
	 * 
	 * readCommonCodeDuplicationCheck
	 *
	 * @param reqOomCommonCodeDto
	 * @return int
	 * @throws Exception 
	 */
	public int readCommonCodeDuplicationCheck(OomCommonCodeDto reqOomCommonCodeDto) throws Exception;
	
	/**
	 * 
	 * createCommonCode
	 *
	 * @param reqOomCommonCodeDto
	 * @return int
	 * @throws Exception 
	 */
	public int createCommonCode(OomCommonCodeDto reqOomCommonCodeDto) throws Exception;
	
	/**
	 * 
	 * readCommonCode
	 *
	 * @param reqOomCommonCodeDto
	 * @return OomCommonCodeDto
	 * @throws Exception 
	 */
	public OomCommonCodeDto readCommonCode(OomCommonCodeDto reqOomCommonCodeDto) throws Exception;
	
	/**
	 * 
	 * updateCommonCode
	 *
	 * @param reqOomCommonCodeDto
	 * @return int
	 * @throws Exception 
	 */
	public int updateCommonCode(OomCommonCodeDto reqOomCommonCodeDto) throws Exception;
	
	/**
	 * 
	 * deleteCommonCode
	 *
	 * @param reqOomCommonCodeDto
	 * @return int
	 * @throws Exception 
	 */
	public int deleteCommonCode(OomCommonCodeDto reqOomCommonCodeDto) throws Exception;
	
	/**
	 * 
	 * listCommonCodeForCombo
	 *
	 * @param commonCodeRequestDto
	 * @return List<OomCommonCodeDto>
	 * @throws Exception 
	 */
	public List<OomCommonCodeDto> listCommonCodeForCombo(CommonCodeRequestDto commonCodeRequestDto) throws Exception;
	
	/**
	 * 
	 * updateCommonCodeReuse
	 *
	 * @param reqOomCommonCodeDto
	 * @return int
	 * @throws Exception 
	 */
	public int updateCommonCodeReuse(OomCommonCodeDto reqOomCommonCodeDto) throws Exception;

}
