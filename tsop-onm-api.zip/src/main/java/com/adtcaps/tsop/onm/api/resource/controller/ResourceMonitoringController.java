package com.adtcaps.tsop.onm.api.resource.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.util.CollectionUtils;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.adtcaps.tsop.onm.api.authentication.domain.JwtAuthResultDto;
import com.adtcaps.tsop.onm.api.domain.OomTenantResourceMonitoringAlarmConditionDto;
import com.adtcaps.tsop.onm.api.domain.OomUserRoleAuthorityDetailDto;
import com.adtcaps.tsop.onm.api.helper.constant.Const;
import com.adtcaps.tsop.onm.api.helper.domain.ResultDto;
import com.adtcaps.tsop.onm.api.helper.util.PageUtil;
import com.adtcaps.tsop.onm.api.resource.domain.ResourceMonitoringAlarmDetailResultDto;
import com.adtcaps.tsop.onm.api.resource.domain.ResourceMonitoringAlarmGridRequestDto;
import com.adtcaps.tsop.onm.api.resource.domain.ResourceMonitoringAlarmGridResultDto;
import com.adtcaps.tsop.onm.api.resource.service.ResourceMonitoringAlarmService;
import com.adtcaps.tsop.onm.api.user.domain.UserRoleMenuAuthorityRequestDto;
import com.adtcaps.tsop.onm.api.user.service.UserRoleService;

import lombok.extern.slf4j.Slf4j;

/**
 * 
 * <ul>
 * <li>업무 그룹명 : tsop-onm-api</li>
 * <li>서브 업무명 : com.adtcaps.tsop.onm.api.resource.controller</li>
 * <li>설  명 : ResourceMonitoringController.java</li>
 * <li>작성일 : 2021. 1. 21.</li>
 * <li>작성자 : jeonyb4</li>
 * </ul>
 */
@Slf4j
@RestController
@RequestMapping("/api/resource-monitoring-alarms")
public class ResourceMonitoringController {
	
	private final String MENU_ID = "ONM0014";
	
	private final String ERR_MSG_NULL_LOGIN_USER_ID = "로그인 사용자ID가 없습니다.";
	private final String ERR_MSG_NULL_MGR_YN = "관리자여부가 없습니다.";
	private final String ERR_MSG_NULL_PAGE_NUMBER = "페이지 번호가 없습니다.";
	private final String ERR_MSG_NULL_TENANT_ID = "테넌트ID가 없습니다.";
	private final String ERR_MSG_NULL_ALARM_GROUP_CD = "알람그룹코드가 없습니다.";
	private final String ERR_MSG_NULL_ALARM_CD = "알람코드가 없습니다.";
	private final String ERR_MSG_NULL_ALARM_TYPE_CD = "알람유형코드가 없습니다.";
	private final String ERR_MSG_NULL_ALARM_GRADE_CD = "알람등급코드가 없습니다.";
	
	private final String ERR_MSG_NO_AUTH = "권한이 없는 사용자 입니다.";
	private final String ERR_MSG_ALREADY_EXIST_RESOURCE_MONITORING_ALARM = "해당 테넌트자원감시알람조건 정보가 이미 존재하므로 등록할 수 없습니다.";
	private final String ERR_MSG_NULL_SEARCH_RESULT_LIST = "조회 결과가 없습니다.";
	private final String ERR_MSG_CREATE_FAIL = "등록에 실패하였습니다.";
	private final String ERR_MSG_READ_FAIL = "조회에 실패하였습니다.";
	private final String ERR_MSG_UPDATE_FAIL = "수정에 실패하였습니다.";
	private final String ERR_MSG_DELETE_FAIL = "삭제에 실패하였습니다.";
	
	@Autowired
	private ResourceMonitoringAlarmService resourceMonitoringAlarmService;
	
	@Autowired
	private UserRoleService userRoleService;
	
	/**
	 * 
	 * listPageTenantResourceMonitoringAlarmCondition
	 *
	 * @param resourceMonitoringAlarmGridRequestDto
	 * @return ResponseEntity
	 */
	@SuppressWarnings("rawtypes")
    @GetMapping(value="", produces="application/json; charset=UTF-8")
    public ResponseEntity listPageTenantResourceMonitoringAlarmCondition(ResourceMonitoringAlarmGridRequestDto resourceMonitoringAlarmGridRequestDto) throws Exception {
        
    	ResponseEntity<ResultDto> resEntity = null;
		String returnString = "";
    	
		int pageNumber = resourceMonitoringAlarmGridRequestDto.getPageNumber();
		if (pageNumber < 1) {
			log.error(">>>>>> pageNumber ERROR:{}", ERR_MSG_NULL_PAGE_NUMBER);
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_PAGE_NUMBER));
			return resEntity;
		}
		// 테넌트자원감시알람조건 목록 조회....
		Map<String, Object> resourceMonitoringAlarmGridResultDtoListMap = new HashMap<String, Object>();
		List<ResourceMonitoringAlarmGridResultDto> resourceMonitoringAlarmGridResultDtoList = resourceMonitoringAlarmService.listPageTenantResourceMonitoringAlarmCondition(resourceMonitoringAlarmGridRequestDto);
		if (CollectionUtils.isEmpty(resourceMonitoringAlarmGridResultDtoList)) {
			returnString = Const.Common.RESULT_CODE.SUCCESS;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_SEARCH_RESULT_LIST, resourceMonitoringAlarmGridResultDtoListMap));
		} else {
			returnString = Const.Common.RESULT_CODE.SUCCESS;
			resourceMonitoringAlarmGridResultDtoListMap.put(Const.Definition.PAGE.PAGER, PageUtil.getPageInfo(resourceMonitoringAlarmGridResultDtoList));
			resourceMonitoringAlarmGridResultDtoListMap.put(Const.Definition.PAGE.LISTS, resourceMonitoringAlarmGridResultDtoList);
			resEntity = ResponseEntity.ok(new ResultDto(returnString, "", resourceMonitoringAlarmGridResultDtoListMap));
		}
    	
    	return resEntity;
    }
	
	/**
	 * 
	 * createTenantResourceMonitoringAlarmCondition
	 *
	 * @param authResultDto
	 * @param reqOomTenantResourceMonitoringAlarmConditionDto
	 * @return ResponseEntity
	 */
	@SuppressWarnings("rawtypes")
    @PostMapping(value="", produces="application/json; charset=UTF-8")
    public ResponseEntity createTenantResourceMonitoringAlarmCondition(@AuthenticationPrincipal JwtAuthResultDto authResultDto, 
    		@RequestBody OomTenantResourceMonitoringAlarmConditionDto reqOomTenantResourceMonitoringAlarmConditionDto) throws Exception {
        
    	ResponseEntity<ResultDto> resEntity = null;
		String returnString = "";
    	
		String loginUserId = StringUtils.defaultString(authResultDto.getUserId());
		if ("".equals(loginUserId)) {
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_LOGIN_USER_ID));
			return resEntity;
		}
		String mgrYn = StringUtils.defaultString(authResultDto.getMgrYn());
		if ("".equals(mgrYn)) {
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_MGR_YN));
			return resEntity;
		}
		//String loginUserId = "tsop-admin"; // 이후 세션에서 얻어올 값...
		
		if (!"Y".equals(mgrYn)) {
			String authorityTypeCd = "";
			UserRoleMenuAuthorityRequestDto userRoleMenuAuthorityRequestDto = new UserRoleMenuAuthorityRequestDto();
			userRoleMenuAuthorityRequestDto.setUserId(loginUserId);
			userRoleMenuAuthorityRequestDto.setMenuId(MENU_ID);
			OomUserRoleAuthorityDetailDto rsltOomUserRoleAuthorityDetailDto = userRoleService.readMenuAuthority(userRoleMenuAuthorityRequestDto);
			if (rsltOomUserRoleAuthorityDetailDto != null) {
				authorityTypeCd = StringUtils.defaultString(rsltOomUserRoleAuthorityDetailDto.getAuthorityTypeCd());
			}
			if (!"W".equals(authorityTypeCd)) {
				returnString = Const.Common.RESULT_CODE.FAIL;
				resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NO_AUTH));
				return resEntity;
			}
		}
		
		String tenantId = StringUtils.defaultString(reqOomTenantResourceMonitoringAlarmConditionDto.getTenantId());
		if ("".equals(tenantId)) {
			log.error(">>>>>> tenantId ERROR:{}", ERR_MSG_NULL_TENANT_ID);
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_TENANT_ID));
			return resEntity;
		}
		String onmAlarmGroupCd = StringUtils.defaultString(reqOomTenantResourceMonitoringAlarmConditionDto.getOnmAlarmGroupCd());
		if ("".equals(onmAlarmGroupCd)) {
			log.error(">>>>>> onmAlarmGroupCd ERROR:{}", ERR_MSG_NULL_ALARM_GROUP_CD);
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_ALARM_GROUP_CD));
			return resEntity;
		}
		String onmAlarmTypeCd = StringUtils.defaultString(reqOomTenantResourceMonitoringAlarmConditionDto.getOnmAlarmTypeCd());
		if ("".equals(onmAlarmTypeCd)) {
			log.error(">>>>>> onmAlarmTypeCd ERROR:{}", ERR_MSG_NULL_ALARM_TYPE_CD);
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_ALARM_TYPE_CD));
			return resEntity;
		}
		String onmAlarmCd = StringUtils.defaultString(reqOomTenantResourceMonitoringAlarmConditionDto.getOnmAlarmCd());
		if ("".equals(onmAlarmCd)) {
			log.error(">>>>>> onmAlarmCd ERROR:{}", ERR_MSG_NULL_ALARM_CD);
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_ALARM_CD));
			return resEntity;
		}
		String onmAlarmGradeCd = StringUtils.defaultString(reqOomTenantResourceMonitoringAlarmConditionDto.getOnmAlarmGradeCd());
		if ("".equals(onmAlarmGradeCd)) {
			log.error(">>>>>> onmAlarmGradeCd ERROR:{}", ERR_MSG_NULL_ALARM_GRADE_CD);
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_ALARM_GRADE_CD));
			return resEntity;
		}
		
		// 테넌트자원감시알람조건 중복 체크
		ResourceMonitoringAlarmDetailResultDto resourceMonitoringAlarmDetailResultDto = resourceMonitoringAlarmService.readTenantResourceMonitoringAlarmCondition(reqOomTenantResourceMonitoringAlarmConditionDto);
		if (resourceMonitoringAlarmDetailResultDto != null) {
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_ALREADY_EXIST_RESOURCE_MONITORING_ALARM));
			return resEntity;
		}
		
		// 테넌트자원감시알람조건 등록...
		reqOomTenantResourceMonitoringAlarmConditionDto.setAuditId(loginUserId);
		reqOomTenantResourceMonitoringAlarmConditionDto.setRegisterId(loginUserId);
		int affectRowCount = resourceMonitoringAlarmService.createTenantResourceMonitoringAlarmCondition(reqOomTenantResourceMonitoringAlarmConditionDto);
		if (affectRowCount < 1) {
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_CREATE_FAIL, affectRowCount));
		} else {
			returnString = Const.Common.RESULT_CODE.SUCCESS;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, "", affectRowCount));
		}
    	
    	return resEntity;
    }
	
	/**
	 * 
	 * readTenantResourceMonitoringAlarmCondition
	 *
	 * @param onmAlarmCd
	 * @param reqOomTenantResourceMonitoringAlarmConditionDto
	 * @return ResponseEntity
	 */
	@SuppressWarnings("rawtypes")
    @GetMapping(value="/{onmAlarmCd}", produces="application/json; charset=UTF-8")
    public ResponseEntity readTenantResourceMonitoringAlarmCondition(@PathVariable("onmAlarmCd") String onmAlarmCd, OomTenantResourceMonitoringAlarmConditionDto reqOomTenantResourceMonitoringAlarmConditionDto) throws Exception {
        
    	ResponseEntity<ResultDto> resEntity = null;
		String returnString = "";
    	
		String tenantId = StringUtils.defaultString(reqOomTenantResourceMonitoringAlarmConditionDto.getTenantId());
		if ("".equals(tenantId)) {
			log.error(">>>>>> tenantId ERROR:{}", ERR_MSG_NULL_TENANT_ID);
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_TENANT_ID));
			return resEntity;
		}
		String onmAlarmGroupCd = StringUtils.defaultString(reqOomTenantResourceMonitoringAlarmConditionDto.getOnmAlarmGroupCd());
		if ("".equals(onmAlarmGroupCd)) {
			log.error(">>>>>> onmAlarmGroupCd ERROR:{}", ERR_MSG_NULL_ALARM_GROUP_CD);
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_ALARM_GROUP_CD));
			return resEntity;
		}
		
		reqOomTenantResourceMonitoringAlarmConditionDto.setOnmAlarmCd(onmAlarmCd);
		
		ResourceMonitoringAlarmDetailResultDto resourceMonitoringAlarmDetailResultDto = resourceMonitoringAlarmService.readTenantResourceMonitoringAlarmCondition(reqOomTenantResourceMonitoringAlarmConditionDto);
		if (resourceMonitoringAlarmDetailResultDto == null) {
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_READ_FAIL, resourceMonitoringAlarmDetailResultDto));
		} else {
			returnString = Const.Common.RESULT_CODE.SUCCESS;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, "", resourceMonitoringAlarmDetailResultDto));
		}
    	
    	return resEntity;
    }
	
	/**
	 * 
	 * updateTenantResourceMonitoringAlarmCondition
	 *
	 * @param authResultDto
	 * @param onmAlarmCd
	 * @param reqOomTenantResourceMonitoringAlarmConditionDto
	 * @return ResponseEntity
	 */
	@SuppressWarnings("rawtypes")
    @PutMapping(value="/{onmAlarmCd}", produces="application/json; charset=UTF-8")
    public ResponseEntity updateTenantResourceMonitoringAlarmCondition(@AuthenticationPrincipal JwtAuthResultDto authResultDto, 
    		@PathVariable("onmAlarmCd") String onmAlarmCd, @RequestBody OomTenantResourceMonitoringAlarmConditionDto reqOomTenantResourceMonitoringAlarmConditionDto) throws Exception {
        
    	ResponseEntity<ResultDto> resEntity = null;
		String returnString = "";
    	
		String loginUserId = StringUtils.defaultString(authResultDto.getUserId());
		if ("".equals(loginUserId)) {
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_LOGIN_USER_ID));
			return resEntity;
		}
		String mgrYn = StringUtils.defaultString(authResultDto.getMgrYn());
		if ("".equals(mgrYn)) {
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_MGR_YN));
			return resEntity;
		}
		//String loginUserId = "tsop-admin"; // 이후 세션에서 얻어올 값...
		
		if (!"Y".equals(mgrYn)) {
			String authorityTypeCd = "";
			UserRoleMenuAuthorityRequestDto userRoleMenuAuthorityRequestDto = new UserRoleMenuAuthorityRequestDto();
			userRoleMenuAuthorityRequestDto.setUserId(loginUserId);
			userRoleMenuAuthorityRequestDto.setMenuId(MENU_ID);
			OomUserRoleAuthorityDetailDto rsltOomUserRoleAuthorityDetailDto = userRoleService.readMenuAuthority(userRoleMenuAuthorityRequestDto);
			if (rsltOomUserRoleAuthorityDetailDto != null) {
				authorityTypeCd = StringUtils.defaultString(rsltOomUserRoleAuthorityDetailDto.getAuthorityTypeCd());
			}
			if (!"W".equals(authorityTypeCd)) {
				returnString = Const.Common.RESULT_CODE.FAIL;
				resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NO_AUTH));
				return resEntity;
			}
		}
		
		String tenantId = StringUtils.defaultString(reqOomTenantResourceMonitoringAlarmConditionDto.getTenantId());
		if ("".equals(tenantId)) {
			log.error(">>>>>> tenantId ERROR:{}", ERR_MSG_NULL_TENANT_ID);
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_TENANT_ID));
			return resEntity;
		}
		String onmAlarmGroupCd = StringUtils.defaultString(reqOomTenantResourceMonitoringAlarmConditionDto.getOnmAlarmGroupCd());
		if ("".equals(onmAlarmGroupCd)) {
			log.error(">>>>>> onmAlarmGroupCd ERROR:{}", ERR_MSG_NULL_ALARM_GROUP_CD);
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_ALARM_GROUP_CD));
			return resEntity;
		}
		String onmAlarmGradeCd = StringUtils.defaultString(reqOomTenantResourceMonitoringAlarmConditionDto.getOnmAlarmGradeCd());
		if ("".equals(onmAlarmGradeCd)) {
			log.error(">>>>>> onmAlarmGradeCd ERROR:{}", ERR_MSG_NULL_ALARM_GRADE_CD);
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_ALARM_GRADE_CD));
			return resEntity;
		}
		
		reqOomTenantResourceMonitoringAlarmConditionDto.setOnmAlarmCd(onmAlarmCd);
		reqOomTenantResourceMonitoringAlarmConditionDto.setAuditId(loginUserId);
		
		// 테넌트자원감시알람조건 수정...
		int affectRowCount = resourceMonitoringAlarmService.updateTenantResourceMonitoringAlarmCondition(reqOomTenantResourceMonitoringAlarmConditionDto);
		if (affectRowCount < 1) {
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_UPDATE_FAIL, affectRowCount));
		} else {
			returnString = Const.Common.RESULT_CODE.SUCCESS;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, "", affectRowCount));
		}
    	
    	return resEntity;
    }
	
	/**
	 * 
	 * deleteTenantResourceMonitoringAlarmCondition
	 *
	 * @param onmAlarmCd
	 * @param reqOomTenantResourceMonitoringAlarmConditionDto
	 * @return ResponseEntity
	 */
	@SuppressWarnings("rawtypes")
    @DeleteMapping(value="/{onmAlarmCd}", produces="application/json; charset=UTF-8")
    public ResponseEntity deleteTenantResourceMonitoringAlarmCondition(@AuthenticationPrincipal JwtAuthResultDto authResultDto, 
    		@PathVariable("onmAlarmCd") String onmAlarmCd, @RequestBody OomTenantResourceMonitoringAlarmConditionDto reqOomTenantResourceMonitoringAlarmConditionDto) throws Exception {
        
    	ResponseEntity<ResultDto> resEntity = null;
		String returnString = "";
    	
		String loginUserId = StringUtils.defaultString(authResultDto.getUserId());
		if ("".equals(loginUserId)) {
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_LOGIN_USER_ID));
			return resEntity;
		}
		String mgrYn = StringUtils.defaultString(authResultDto.getMgrYn());
		if ("".equals(mgrYn)) {
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_MGR_YN));
			return resEntity;
		}
		//String loginUserId = "tsop-admin"; // 이후 세션에서 얻어올 값...
		
		if (!"Y".equals(mgrYn)) {
			String authorityTypeCd = "";
			UserRoleMenuAuthorityRequestDto userRoleMenuAuthorityRequestDto = new UserRoleMenuAuthorityRequestDto();
			userRoleMenuAuthorityRequestDto.setUserId(loginUserId);
			userRoleMenuAuthorityRequestDto.setMenuId(MENU_ID);
			OomUserRoleAuthorityDetailDto rsltOomUserRoleAuthorityDetailDto = userRoleService.readMenuAuthority(userRoleMenuAuthorityRequestDto);
			if (rsltOomUserRoleAuthorityDetailDto != null) {
				authorityTypeCd = StringUtils.defaultString(rsltOomUserRoleAuthorityDetailDto.getAuthorityTypeCd());
			}
			if (!"W".equals(authorityTypeCd)) {
				returnString = Const.Common.RESULT_CODE.FAIL;
				resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NO_AUTH));
				return resEntity;
			}
		}
		
		String tenantId = StringUtils.defaultString(reqOomTenantResourceMonitoringAlarmConditionDto.getTenantId());
		if ("".equals(tenantId)) {
			log.error(">>>>>> tenantId ERROR:{}", ERR_MSG_NULL_TENANT_ID);
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_TENANT_ID));
			return resEntity;
		}
		String onmAlarmGroupCd = StringUtils.defaultString(reqOomTenantResourceMonitoringAlarmConditionDto.getOnmAlarmGroupCd());
		if ("".equals(onmAlarmGroupCd)) {
			log.error(">>>>>> onmAlarmGroupCd ERROR:{}", ERR_MSG_NULL_ALARM_GROUP_CD);
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_ALARM_GROUP_CD));
			return resEntity;
		}
		
		reqOomTenantResourceMonitoringAlarmConditionDto.setOnmAlarmCd(onmAlarmCd);
		
		// 테넌트자원감시알람조건 삭제...
		int affectRowCount = resourceMonitoringAlarmService.deleteTenantResourceMonitoringAlarmCondition(reqOomTenantResourceMonitoringAlarmConditionDto);
		if (affectRowCount < 1) {
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_DELETE_FAIL, affectRowCount));
		} else {
			returnString = Const.Common.RESULT_CODE.SUCCESS;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, "", affectRowCount));
		}
    	
    	return resEntity;
    }

}
