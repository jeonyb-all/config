package com.adtcaps.tsop.onm.api.dashboard.domain;

import lombok.Getter;
import lombok.Setter;

/**
 * 
 * <ul>
 * <li>업무 그룹명 : tsop-onm-api</li>
 * <li>서브 업무명 : com.adtcaps.tsop.onm.api.dashboard.domain</li>
 * <li>설  명 : DashboardAlarmGridResultDto.java</li>
 * <li>작성일 : 2021. 2. 1.</li>
 * <li>작성자 : song</li>
 * </ul>
 */
@Getter
@Setter
public class DashboardAlarmGridResultDto {
	private String onmAlarmGradeCd;
	private String eventDatetime;
	private String tenantId;
	private String tenantName;
	private String onmResourceId;
	private String onmResourceAbbrName;
	private String onmAlarmCd;
	private String onmAlarmTypeCd;
	private String onmAlarmTypeCdName;
	private String onmAlarmEventId;
	private String onmAlarmMaskYn;
	private String onmAlarmAckYn;
}
