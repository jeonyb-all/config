package com.adtcaps.tsop.onm.api.deploy.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.util.CollectionUtils;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.adtcaps.tsop.onm.api.authentication.domain.JwtAuthResultDto;
import com.adtcaps.tsop.onm.api.deploy.domain.PackageDeployJobDetailResultDto;
import com.adtcaps.tsop.onm.api.deploy.domain.PackageDeployJobGridRequestDto;
import com.adtcaps.tsop.onm.api.deploy.domain.PackageDeployJobGridResultDto;
import com.adtcaps.tsop.onm.api.deploy.service.PackageDeployJobService;
import com.adtcaps.tsop.onm.api.domain.OomPackageDeployJobDto;
import com.adtcaps.tsop.onm.api.domain.OomUserRoleAuthorityDetailDto;
import com.adtcaps.tsop.onm.api.helper.constant.Const;
import com.adtcaps.tsop.onm.api.helper.domain.ResultDto;
import com.adtcaps.tsop.onm.api.helper.util.PageUtil;
import com.adtcaps.tsop.onm.api.user.domain.UserRoleMenuAuthorityRequestDto;
import com.adtcaps.tsop.onm.api.user.service.UserRoleService;

import lombok.extern.slf4j.Slf4j;

/**
 * 
 * <ul>
 * <li>업무 그룹명 : tsop-onm-api</li>
 * <li>서브 업무명 : com.adtcaps.tsop.onm.api.deploy.controller</li>
 * <li>설  명 : PackageDeployJobController.java</li>
 * <li>작성일 : 2021. 2. 2.</li>
 * <li>작성자 : jeonyb4</li>
 * </ul>
 */
@Slf4j
@RestController
@RequestMapping("/api/deploys")
public class PackageDeployJobController {
	
	private final String MENU_ID = "ONM0019";
	
	private final String ERR_MSG_NULL_LOGIN_USER_ID = "로그인 사용자ID가 없습니다.";
	private final String ERR_MSG_NULL_MGR_YN = "관리자여부가 없습니다.";
	private final String ERR_MSG_NULL_TENANT_ID = "테넌트ID가 없습니다.";
	private final String ERR_MSG_NULL_PAGE_NUMBER = "페이지 번호가 없습니다.";
	private final String ERR_MSG_NULL_SERACH_DATE = "조회기간(From or To)이 없습니다.";
	
	private final String ERR_MSG_ATTACH_FILE_DELETE_FAIL = "첨부파일 삭제에 실패하였습니다.";
	
	private final String ERR_MSG_NO_AUTH = "권한이 없는 사용자 입니다.";
	private final String ERR_MSG_NULL_SEARCH_RESULT_LIST = "조회 결과가 없습니다.";
	private final String ERR_MSG_READ_FAIL = "조회에 실패하였습니다.";
	
	@Autowired
	private PackageDeployJobService packageDeployJobService;
	
	@Autowired
	private UserRoleService userRoleService;
	
	/**
	 * 
	 * deleteDeployVerifyProcedureAttachFile
	 *
	 * @param onmWorkId
	 * @param attachFileNum
	 * @param reqOomPackageDeployJobDto
	 * @return ResponseEntity
	 */
	@SuppressWarnings("rawtypes")
    @DeleteMapping(value="/works/{onmWorkId}/verify-procedure-attach-files/{attachFileNum}", produces="application/json; charset=UTF-8")
    public ResponseEntity deleteDeployVerifyProcedureAttachFile(@AuthenticationPrincipal JwtAuthResultDto authResultDto, 
    		@PathVariable("onmWorkId") int onmWorkId, @PathVariable("attachFileNum") int attachFileNum, 
    		@RequestBody OomPackageDeployJobDto reqOomPackageDeployJobDto) throws Exception {
        
    	ResponseEntity<ResultDto> resEntity = null;
		String returnString = "";
    	
		String loginUserId = StringUtils.defaultString(authResultDto.getUserId());
		if ("".equals(loginUserId)) {
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_LOGIN_USER_ID));
			return resEntity;
		}
		String mgrYn = StringUtils.defaultString(authResultDto.getMgrYn());
		if ("".equals(mgrYn)) {
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_MGR_YN));
			return resEntity;
		}
		//String loginUserId = "tsop-admin"; // 이후 세션에서 얻어올 값...
		
		if (!"Y".equals(mgrYn)) {
			String authorityTypeCd = "";
			UserRoleMenuAuthorityRequestDto userRoleMenuAuthorityRequestDto = new UserRoleMenuAuthorityRequestDto();
			userRoleMenuAuthorityRequestDto.setUserId(loginUserId);
			userRoleMenuAuthorityRequestDto.setMenuId(MENU_ID);
			OomUserRoleAuthorityDetailDto rsltOomUserRoleAuthorityDetailDto = userRoleService.readMenuAuthority(userRoleMenuAuthorityRequestDto);
			if (rsltOomUserRoleAuthorityDetailDto != null) {
				authorityTypeCd = StringUtils.defaultString(rsltOomUserRoleAuthorityDetailDto.getAuthorityTypeCd());
			}
			if (!"W".equals(authorityTypeCd)) {
				returnString = Const.Common.RESULT_CODE.FAIL;
				resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NO_AUTH));
				return resEntity;
			}
		}
		
		String tenantId = StringUtils.defaultString(reqOomPackageDeployJobDto.getTenantId());
		if ("".equals(tenantId)) {
			log.error(">>>>>> tenantId ERROR:{}", ERR_MSG_NULL_TENANT_ID);
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_TENANT_ID));
			return resEntity;
		}
		
		reqOomPackageDeployJobDto.setOnmWorkId(onmWorkId);
		reqOomPackageDeployJobDto.setVerifyProcedureAttachFileNum(attachFileNum);
		
		int affectRowCount = packageDeployJobService.deleteDeployVerifyProcedureAttachFile(reqOomPackageDeployJobDto);
		if (affectRowCount < 1) {
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_ATTACH_FILE_DELETE_FAIL, affectRowCount));
		} else {
			returnString = Const.Common.RESULT_CODE.SUCCESS;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, "", affectRowCount));
		}
    	
    	return resEntity;
    }
	
	/**
	 * 
	 * deleteDeployWorkProcedureAttachFile
	 *
	 * @param onmWorkId
	 * @param attachFileNum
	 * @param reqOomPackageDeployJobDto
	 * @return ResponseEntity
	 */
	@SuppressWarnings("rawtypes")
    @DeleteMapping(value="/works/{onmWorkId}/work-procedure-attach-files/{attachFileNum}", produces="application/json; charset=UTF-8")
    public ResponseEntity deleteDeployWorkProcedureAttachFile(@AuthenticationPrincipal JwtAuthResultDto authResultDto, 
    		@PathVariable("onmWorkId") int onmWorkId, @PathVariable("attachFileNum") int attachFileNum, 
    		@RequestBody OomPackageDeployJobDto reqOomPackageDeployJobDto) throws Exception {
        
    	ResponseEntity<ResultDto> resEntity = null;
		String returnString = "";
    	
		String loginUserId = StringUtils.defaultString(authResultDto.getUserId());
		if ("".equals(loginUserId)) {
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_LOGIN_USER_ID));
			return resEntity;
		}
		String mgrYn = StringUtils.defaultString(authResultDto.getMgrYn());
		if ("".equals(mgrYn)) {
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_MGR_YN));
			return resEntity;
		}
		//String loginUserId = "tsop-admin"; // 이후 세션에서 얻어올 값...
		
		if (!"Y".equals(mgrYn)) {
			String authorityTypeCd = "";
			UserRoleMenuAuthorityRequestDto userRoleMenuAuthorityRequestDto = new UserRoleMenuAuthorityRequestDto();
			userRoleMenuAuthorityRequestDto.setUserId(loginUserId);
			userRoleMenuAuthorityRequestDto.setMenuId(MENU_ID);
			OomUserRoleAuthorityDetailDto rsltOomUserRoleAuthorityDetailDto = userRoleService.readMenuAuthority(userRoleMenuAuthorityRequestDto);
			if (rsltOomUserRoleAuthorityDetailDto != null) {
				authorityTypeCd = StringUtils.defaultString(rsltOomUserRoleAuthorityDetailDto.getAuthorityTypeCd());
			}
			if (!"W".equals(authorityTypeCd)) {
				returnString = Const.Common.RESULT_CODE.FAIL;
				resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NO_AUTH));
				return resEntity;
			}
		}
		
		String tenantId = StringUtils.defaultString(reqOomPackageDeployJobDto.getTenantId());
		if ("".equals(tenantId)) {
			log.error(">>>>>> tenantId ERROR:{}", ERR_MSG_NULL_TENANT_ID);
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_TENANT_ID));
			return resEntity;
		}
		
		reqOomPackageDeployJobDto.setOnmWorkId(onmWorkId);
		reqOomPackageDeployJobDto.setWorkProcedureAttachFileNum(attachFileNum);
		
		int affectRowCount = packageDeployJobService.deleteDeployWorkProcedureAttachFile(reqOomPackageDeployJobDto);
		if (affectRowCount < 1) {
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_ATTACH_FILE_DELETE_FAIL, affectRowCount));
		} else {
			returnString = Const.Common.RESULT_CODE.SUCCESS;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, "", affectRowCount));
		}
    	
    	return resEntity;
    }
	
	/**
	 * 
	 * deleteDeployInspectionProcedureAttachFile
	 *
	 * @param onmWorkId
	 * @param attachFileNum
	 * @param reqOomPackageDeployJobDto
	 * @return ResponseEntity
	 */
	@SuppressWarnings("rawtypes")
    @DeleteMapping(value="/works/{onmWorkId}/inspection-procedure-attach-files/{attachFileNum}", produces="application/json; charset=UTF-8")
    public ResponseEntity deleteDeployInspectionProcedureAttachFile(@AuthenticationPrincipal JwtAuthResultDto authResultDto, 
    		@PathVariable("onmWorkId") int onmWorkId, @PathVariable("attachFileNum") int attachFileNum, 
    		@RequestBody OomPackageDeployJobDto reqOomPackageDeployJobDto) throws Exception {
        
    	ResponseEntity<ResultDto> resEntity = null;
		String returnString = "";
    	
		String loginUserId = StringUtils.defaultString(authResultDto.getUserId());
		if ("".equals(loginUserId)) {
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_LOGIN_USER_ID));
			return resEntity;
		}
		String mgrYn = StringUtils.defaultString(authResultDto.getMgrYn());
		if ("".equals(mgrYn)) {
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_MGR_YN));
			return resEntity;
		}
		//String loginUserId = "tsop-admin"; // 이후 세션에서 얻어올 값...
		
		if (!"Y".equals(mgrYn)) {
			String authorityTypeCd = "";
			UserRoleMenuAuthorityRequestDto userRoleMenuAuthorityRequestDto = new UserRoleMenuAuthorityRequestDto();
			userRoleMenuAuthorityRequestDto.setUserId(loginUserId);
			userRoleMenuAuthorityRequestDto.setMenuId(MENU_ID);
			OomUserRoleAuthorityDetailDto rsltOomUserRoleAuthorityDetailDto = userRoleService.readMenuAuthority(userRoleMenuAuthorityRequestDto);
			if (rsltOomUserRoleAuthorityDetailDto != null) {
				authorityTypeCd = StringUtils.defaultString(rsltOomUserRoleAuthorityDetailDto.getAuthorityTypeCd());
			}
			if (!"W".equals(authorityTypeCd)) {
				returnString = Const.Common.RESULT_CODE.FAIL;
				resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NO_AUTH));
				return resEntity;
			}
		}
		
		String tenantId = StringUtils.defaultString(reqOomPackageDeployJobDto.getTenantId());
		if ("".equals(tenantId)) {
			log.error(">>>>>> tenantId ERROR:{}", ERR_MSG_NULL_TENANT_ID);
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_TENANT_ID));
			return resEntity;
		}
		
		reqOomPackageDeployJobDto.setOnmWorkId(onmWorkId);
		reqOomPackageDeployJobDto.setInspectionProcedureAttachFileNum(attachFileNum);
		
		int affectRowCount = packageDeployJobService.deleteDeployInspectionProcedureAttachFile(reqOomPackageDeployJobDto);
		if (affectRowCount < 1) {
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_ATTACH_FILE_DELETE_FAIL, affectRowCount));
		} else {
			returnString = Const.Common.RESULT_CODE.SUCCESS;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, "", affectRowCount));
		}
    	
    	return resEntity;
    }
	
	/**
	 * 
	 * deleteDeployDbScriptAttachFile
	 *
	 * @param onmWorkId
	 * @param attachFileNum
	 * @param reqOomPackageDeployJobDto
	 * @return ResponseEntity
	 */
	@SuppressWarnings("rawtypes")
    @DeleteMapping(value="/works/{onmWorkId}/db-script-attach-files/{attachFileNum}", produces="application/json; charset=UTF-8")
    public ResponseEntity deleteDeployDbScriptAttachFile(@AuthenticationPrincipal JwtAuthResultDto authResultDto, 
    		@PathVariable("onmWorkId") int onmWorkId, @PathVariable("attachFileNum") int attachFileNum, 
    		@RequestBody OomPackageDeployJobDto reqOomPackageDeployJobDto) throws Exception {
        
    	ResponseEntity<ResultDto> resEntity = null;
		String returnString = "";
    	
		String loginUserId = StringUtils.defaultString(authResultDto.getUserId());
		if ("".equals(loginUserId)) {
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_LOGIN_USER_ID));
			return resEntity;
		}
		String mgrYn = StringUtils.defaultString(authResultDto.getMgrYn());
		if ("".equals(mgrYn)) {
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_MGR_YN));
			return resEntity;
		}
		//String loginUserId = "tsop-admin"; // 이후 세션에서 얻어올 값...
		
		if (!"Y".equals(mgrYn)) {
			String authorityTypeCd = "";
			UserRoleMenuAuthorityRequestDto userRoleMenuAuthorityRequestDto = new UserRoleMenuAuthorityRequestDto();
			userRoleMenuAuthorityRequestDto.setUserId(loginUserId);
			userRoleMenuAuthorityRequestDto.setMenuId(MENU_ID);
			OomUserRoleAuthorityDetailDto rsltOomUserRoleAuthorityDetailDto = userRoleService.readMenuAuthority(userRoleMenuAuthorityRequestDto);
			if (rsltOomUserRoleAuthorityDetailDto != null) {
				authorityTypeCd = StringUtils.defaultString(rsltOomUserRoleAuthorityDetailDto.getAuthorityTypeCd());
			}
			if (!"W".equals(authorityTypeCd)) {
				returnString = Const.Common.RESULT_CODE.FAIL;
				resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NO_AUTH));
				return resEntity;
			}
		}
		
		String tenantId = StringUtils.defaultString(reqOomPackageDeployJobDto.getTenantId());
		if ("".equals(tenantId)) {
			log.error(">>>>>> tenantId ERROR:{}", ERR_MSG_NULL_TENANT_ID);
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_TENANT_ID));
			return resEntity;
		}
		
		reqOomPackageDeployJobDto.setOnmWorkId(onmWorkId);
		reqOomPackageDeployJobDto.setDbScriptAttachFileNum(attachFileNum);
		
		int affectRowCount = packageDeployJobService.deleteDeployDbScriptAttachFile(reqOomPackageDeployJobDto);
		if (affectRowCount < 1) {
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_ATTACH_FILE_DELETE_FAIL, affectRowCount));
		} else {
			returnString = Const.Common.RESULT_CODE.SUCCESS;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, "", affectRowCount));
		}
    	
    	return resEntity;
    }
	
	/**
	 * 
	 * deleteDeployInspectionResultAttachFile
	 *
	 * @param onmWorkId
	 * @param attachFileNum
	 * @param reqOomPackageDeployJobDto
	 * @return ResponseEntity
	 */
	@SuppressWarnings("rawtypes")
    @DeleteMapping(value="/works/{onmWorkId}/inspection-result-attach-files/{attachFileNum}", produces="application/json; charset=UTF-8")
    public ResponseEntity deleteDeployInspectionResultAttachFile(@AuthenticationPrincipal JwtAuthResultDto authResultDto, 
    		@PathVariable("onmWorkId") int onmWorkId, @PathVariable("attachFileNum") int attachFileNum, 
    		@RequestBody OomPackageDeployJobDto reqOomPackageDeployJobDto) throws Exception {
        
    	ResponseEntity<ResultDto> resEntity = null;
		String returnString = "";
    	
		String loginUserId = StringUtils.defaultString(authResultDto.getUserId());
		if ("".equals(loginUserId)) {
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_LOGIN_USER_ID));
			return resEntity;
		}
		String mgrYn = StringUtils.defaultString(authResultDto.getMgrYn());
		if ("".equals(mgrYn)) {
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_MGR_YN));
			return resEntity;
		}
		//String loginUserId = "tsop-admin"; // 이후 세션에서 얻어올 값...
		
		if (!"Y".equals(mgrYn)) {
			String authorityTypeCd = "";
			UserRoleMenuAuthorityRequestDto userRoleMenuAuthorityRequestDto = new UserRoleMenuAuthorityRequestDto();
			userRoleMenuAuthorityRequestDto.setUserId(loginUserId);
			userRoleMenuAuthorityRequestDto.setMenuId(MENU_ID);
			OomUserRoleAuthorityDetailDto rsltOomUserRoleAuthorityDetailDto = userRoleService.readMenuAuthority(userRoleMenuAuthorityRequestDto);
			if (rsltOomUserRoleAuthorityDetailDto != null) {
				authorityTypeCd = StringUtils.defaultString(rsltOomUserRoleAuthorityDetailDto.getAuthorityTypeCd());
			}
			if (!"W".equals(authorityTypeCd)) {
				returnString = Const.Common.RESULT_CODE.FAIL;
				resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NO_AUTH));
				return resEntity;
			}
		}
		
		String tenantId = StringUtils.defaultString(reqOomPackageDeployJobDto.getTenantId());
		if ("".equals(tenantId)) {
			log.error(">>>>>> tenantId ERROR:{}", ERR_MSG_NULL_TENANT_ID);
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_TENANT_ID));
			return resEntity;
		}
		
		reqOomPackageDeployJobDto.setOnmWorkId(onmWorkId);
		reqOomPackageDeployJobDto.setInspectionResultAttachFileNum(attachFileNum);
		
		int affectRowCount = packageDeployJobService.deleteDeployInspectionResultAttachFile(reqOomPackageDeployJobDto);
		if (affectRowCount < 1) {
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_ATTACH_FILE_DELETE_FAIL, affectRowCount));
		} else {
			returnString = Const.Common.RESULT_CODE.SUCCESS;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, "", affectRowCount));
		}
    	
    	return resEntity;
    }
	
	/**
	 * 
	 * listPagePackageDeployJob
	 *
	 * @param packageDeployJobGridRequestDto
	 * @return ResponseEntity
	 */
	@SuppressWarnings("rawtypes")
    @GetMapping(value="", produces="application/json; charset=UTF-8")
    public ResponseEntity listPagePackageDeployJob(PackageDeployJobGridRequestDto packageDeployJobGridRequestDto) throws Exception {
        
    	ResponseEntity<ResultDto> resEntity = null;
		String returnString = "";
    	
		int pageNumber = packageDeployJobGridRequestDto.getPageNumber();
		if (pageNumber < 1) {
			log.error(">>>>>> pageNumber ERROR:{}", ERR_MSG_NULL_PAGE_NUMBER);
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_PAGE_NUMBER));
			return resEntity;
		}
		String fromDate = packageDeployJobGridRequestDto.getFromDate();
		String toDate = packageDeployJobGridRequestDto.getToDate();
		if ("".equals(fromDate) || "".equals(toDate)) {
			log.error(">>>>>> fromDate or toDate ERROR:{}", ERR_MSG_NULL_SERACH_DATE);
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_SERACH_DATE));
			return resEntity;
		}
		
		// 배포 목록 조회....
		Map<String, Object> packageDeployJobGridResultDtoListMap = new HashMap<String, Object>();
		List<PackageDeployJobGridResultDto> packageDeployJobGridResultDtoList = packageDeployJobService.listPagePackageDeployJob(packageDeployJobGridRequestDto);
		if (CollectionUtils.isEmpty(packageDeployJobGridResultDtoList)) {
			returnString = Const.Common.RESULT_CODE.SUCCESS;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_SEARCH_RESULT_LIST, packageDeployJobGridResultDtoListMap));
		} else {
			returnString = Const.Common.RESULT_CODE.SUCCESS;
			packageDeployJobGridResultDtoListMap.put(Const.Definition.PAGE.PAGER, PageUtil.getPageInfo(packageDeployJobGridResultDtoList));
			packageDeployJobGridResultDtoListMap.put(Const.Definition.PAGE.LISTS, packageDeployJobGridResultDtoList);
			resEntity = ResponseEntity.ok(new ResultDto(returnString, "", packageDeployJobGridResultDtoListMap));
		}
    	
    	return resEntity;
    }
	
	/**
	 * 
	 * readPackageDeployJob
	 *
	 * @param pkgWorkId
	 * @param reqOomPackageDeployJobDto
	 * @return ResponseEntity
	 */
	@SuppressWarnings("rawtypes")
    @GetMapping(value="/{pkgWorkId}", produces="application/json; charset=UTF-8")
    public ResponseEntity readPackageDeployJob(@PathVariable("pkgWorkId") String pkgWorkId, OomPackageDeployJobDto reqOomPackageDeployJobDto) throws Exception {
        
    	ResponseEntity<ResultDto> resEntity = null;
		String returnString = "";
    	
		String tenantId = StringUtils.defaultString(reqOomPackageDeployJobDto.getTenantId());
		if ("".equals(tenantId)) {
			log.error(">>>>>> tenantId ERROR:{}", ERR_MSG_NULL_TENANT_ID);
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_TENANT_ID));
			return resEntity;
		}
		
		reqOomPackageDeployJobDto.setPkgWorkId(pkgWorkId);
		
		// 배포 상세 조회....
		PackageDeployJobDetailResultDto packageDeployJobDetailResultDto = packageDeployJobService.readPackageDeployJob(reqOomPackageDeployJobDto);
		if (packageDeployJobDetailResultDto == null) {
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_READ_FAIL, packageDeployJobDetailResultDto));
		} else {
			returnString = Const.Common.RESULT_CODE.SUCCESS;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, "", packageDeployJobDetailResultDto));
		}
    	
    	return resEntity;
    }

}
