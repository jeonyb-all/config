package com.adtcaps.tsop.onm.api.authentication.domain;

import java.util.Collection;

import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;

public class JwtAuthResultDto implements UserDetails {
    
    private static final long serialVersionUID = 3504042155966107697L;

    private String userId;
    private String userName;
    private String password;
    private String passwordYn;
	private String useYn;
	private String lockYn;
    private String tenantId;
	private String tenantName;
	private String roleClCd;
    private String mgrYn;
	private String serviceOperYn;
	private String phoneNm;

    
    public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}

	@Override
    public String getUsername() {
        return userName;
    }        
	
	public void setUserName(String userName) {
		this.userName = userName;
	}
	
	@Override
    public String getPassword() {
        return password;
    }
    public void setPassword(String password) {
        this.password = password;
    }
	
	public String getPasswordYn() {
		return passwordYn;
	}
	public void setPasswordYn(String passwordYn) {
		this.passwordYn = passwordYn;
	}
	
	public String getUseYn() {
		return useYn;
	}
	public void setUseYn(String useYn) {
		this.useYn = useYn;
	}
	
	public String getTenantId() {
		return tenantId;
	}
	public void setTenantId(String tenantId) {
		this.tenantId = tenantId;
	}
	
	public String getTenantName() {
		return tenantName;
	}
	public void setTenantName(String tenantName) {
		this.tenantName = tenantName;
	}
	
	public String getMgrYn() {
		return mgrYn;
	}
	public void setMgrYn(String mgrYn) {
		this.mgrYn = mgrYn;
	}
	public Object getRoleClCd() {
		return this.roleClCd;
	}

	public void setRoleClCd(String roleClCd) {
		this.roleClCd = roleClCd;
	};
	public String getServiceOperYn() {
		return serviceOperYn;
	}
	public void setServiceOperYn(String serviceOperYn) {
		this.serviceOperYn = serviceOperYn;
	}

	public String getPhoneNm() {
		return this.phoneNm;
	}

	public void setPhoneNm(String phoneNm) {
		this.phoneNm = phoneNm;
	}
	
	public String getLockYn() {
		return this.lockYn;
	}

	public void setLockYn(String lockYn) {
		this.lockYn = lockYn;
	}
	

    @Override
    public boolean isAccountNonExpired() {
        return false;
    }

    @Override
    public boolean isAccountNonLocked() {
        return false;
    }

    @Override
    public boolean isEnabled() {
        if(this.useYn== null ) return false;
        return this.useYn.equalsIgnoreCase("y");
    }

    @Override
    public boolean isCredentialsNonExpired() {
        return false;
    }

    @Override
    public Collection<? extends GrantedAuthority> getAuthorities() {
        return null;
    }
}
