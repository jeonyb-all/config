package com.adtcaps.tsop.onm.api.alarm.service;

import java.util.List;

import com.adtcaps.tsop.onm.api.alarm.domain.AlarmNoticeConditionDetailResultDto;
import com.adtcaps.tsop.onm.api.alarm.domain.AlarmNoticeConditionGridRequestDto;
import com.adtcaps.tsop.onm.api.alarm.domain.AlarmNoticeConditionGridResultDto;
import com.adtcaps.tsop.onm.api.domain.OomAlarmNoticeConditionDto;

/**
 * 
 * <ul>
 * <li>업무 그룹명 : tsop-onm-api</li>
 * <li>서브 업무명 : com.adtcaps.tsop.onm.api.alarm.service</li>
 * <li>설  명 : AlarmNoticeService.java</li>
 * <li>작성일 : 2021. 1. 17.</li>
 * <li>작성자 : jeonyb4</li>
 * </ul>
 */
public interface AlarmNoticeService {
	/**
	 * 
	 * listPageAlarmNoticeCondition
	 *
	 * @param alarmNoticeConditionGridRequestDto
	 * @return List<AlarmNoticeConditionGridResultDto>
	 * @throws Exception 
	 */
	public List<AlarmNoticeConditionGridResultDto> listPageAlarmNoticeCondition(AlarmNoticeConditionGridRequestDto alarmNoticeConditionGridRequestDto) throws Exception;
	
	/**
	 * 
	 * readAlarmNoticeDuplicationCheck
	 *
	 * @param reqOomAlarmNoticeConditionDto
	 * @return OomAlarmNoticeConditionDto
	 * @throws Exception 
	 */
	public OomAlarmNoticeConditionDto readAlarmNoticeDuplicationCheck(OomAlarmNoticeConditionDto reqOomAlarmNoticeConditionDto) throws Exception;
	
	/**
	 * 
	 * createAlarmNoticeCondition
	 *
	 * @param reqOomAlarmNoticeConditionDto
	 * @return int
	 * @throws Exception 
	 */
	public int createAlarmNoticeCondition(OomAlarmNoticeConditionDto reqOomAlarmNoticeConditionDto) throws Exception;
	
	/**
	 * 
	 * readAlarmNoticeCondition
	 *
	 * @param reqOomAlarmNoticeConditionDto
	 * @return AlarmNoticeConditionDetailResultDto
	 * @throws Exception 
	 */
	public AlarmNoticeConditionDetailResultDto readAlarmNoticeCondition(OomAlarmNoticeConditionDto reqOomAlarmNoticeConditionDto) throws Exception;
	
	/**
	 * 
	 * updateAlarmNoticeCondition
	 *
	 * @param reqOomAlarmNoticeConditionDto
	 * @return int
	 * @throws Exception 
	 */
	public int updateAlarmNoticeCondition(OomAlarmNoticeConditionDto reqOomAlarmNoticeConditionDto) throws Exception;
	
	/**
	 * 
	 * deleteAlarmNoticeCondition
	 *
	 * @param reqOomAlarmNoticeConditionDto
	 * @return int
	 * @throws Exception 
	 */
	public int deleteAlarmNoticeCondition(OomAlarmNoticeConditionDto reqOomAlarmNoticeConditionDto) throws Exception;
	
	/**
	 * 
	 * readAlarmNoticeCountForReceiveGroup
	 *
	 * @param reqOomAlarmNoticeConditionDto
	 * @return int
	 * @throws Exception 
	 */
	public int readAlarmNoticeCountForReceiveGroup(OomAlarmNoticeConditionDto reqOomAlarmNoticeConditionDto) throws Exception;
	
	/**
	 * 
	 * updateAlarmNoticeConditionReuse
	 *
	 * @param reqOomAlarmNoticeConditionDto
	 * @return int
	 * @throws Exception 
	 */
	public int updateAlarmNoticeConditionReuse(OomAlarmNoticeConditionDto reqOomAlarmNoticeConditionDto) throws Exception;

}
