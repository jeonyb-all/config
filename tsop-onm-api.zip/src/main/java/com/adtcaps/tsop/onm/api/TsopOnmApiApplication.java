package com.adtcaps.tsop.onm.api;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.MessageSource;
import org.springframework.context.annotation.Bean;
import org.springframework.context.support.ReloadableResourceBundleMessageSource;
import org.springframework.scheduling.annotation.EnableScheduling;

/**
 * 
 * <ul>
 * <li>업무 그룹명 : tsop-onm-api</li>
 * <li>서브 업무명 : com.adtcaps.tsop.onm.api</li>
 * <li>설  명 : TsopOnmApiApplication.java</li>
 * <li>작성일 : 2020. 12. 7.</li>
 * <li>작성자 : jeonyb4</li>
 * </ul>
 */
@EnableScheduling
@SpringBootApplication
public class TsopOnmApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(TsopOnmApiApplication.class, args);
	}
	
	@Bean
    public MessageSource messageSource() {
        ReloadableResourceBundleMessageSource messageSource = new ReloadableResourceBundleMessageSource();
        messageSource.setBasename("classpath:/messages");
        messageSource.setDefaultEncoding("UTF-8");
        messageSource.setCacheSeconds(300);
        return messageSource;
    }

}
