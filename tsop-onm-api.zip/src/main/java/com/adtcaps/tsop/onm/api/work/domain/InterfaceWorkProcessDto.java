package com.adtcaps.tsop.onm.api.work.domain;

import com.adtcaps.tsop.onm.api.domain.OomWorkBuildingServiceConenctionDto;
import com.adtcaps.tsop.onm.api.file.domain.BlobRequestDto;

import lombok.Getter;
import lombok.Setter;

/**
 * 
 * <ul>
 * <li>업무 그룹명 : tsop-onm-api</li>
 * <li>서브 업무명 : com.adtcaps.tsop.onm.api.work.domain</li>
 * <li>설  명 : InterfaceWorkProcessDto.java</li>
 * <li>작성일 : 2021. 2. 1.</li>
 * <li>작성자 : jeonyb4</li>
 * </ul>
 */
@Getter
@Setter
public class InterfaceWorkProcessDto extends OomWorkBuildingServiceConenctionDto {
	private BlobRequestDto attachFile;

}
