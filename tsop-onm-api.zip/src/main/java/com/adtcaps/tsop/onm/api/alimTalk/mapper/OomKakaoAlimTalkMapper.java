package com.adtcaps.tsop.onm.api.alimTalk.mapper;

import org.apache.ibatis.annotations.Mapper;

import com.adtcaps.tsop.onm.api.domain.OomKakaoAlimTalkDto;

/**
 * 
 * <ul>
 * <li>업무 그룹명 : tsop-onm-api</li>
 * <li>서브 업무명 : com.adtcaps.tsop.onm.api.alimTalk.mapper</li>
 * <li>설  명 : OomKakaoAlimTalkMapper.java</li>
 * <li>작성일 : 2022. 1. 8.</li>
 * <li>작성자 : jeonyb4</li>
 * </ul>
 */
@Mapper
public interface OomKakaoAlimTalkMapper {
	/**
	 * 
	 * readKakaoAlimTalk
	 * 
	 * @param reqOomKakaoAlimTalkDto
	 * @return OomKakaoAlimTalkDto
	 */
	public OomKakaoAlimTalkDto readKakaoAlimTalk(OomKakaoAlimTalkDto reqOomKakaoAlimTalkDto);

}
