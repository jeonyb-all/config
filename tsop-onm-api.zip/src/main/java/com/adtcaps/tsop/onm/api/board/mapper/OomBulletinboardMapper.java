package com.adtcaps.tsop.onm.api.board.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;

import com.adtcaps.tsop.onm.api.board.domain.BulletinboardDetailResultDto;
import com.adtcaps.tsop.onm.api.board.domain.BulletinboardGridRequestDto;
import com.adtcaps.tsop.onm.api.board.domain.BulletinboardGridResultDto;
import com.adtcaps.tsop.onm.api.domain.OomBulletinboardDto;

/**
 * 
 * <ul>
 * <li>업무 그룹명 : tsop-onm-api</li>
 * <li>서브 업무명 : com.adtcaps.tsop.onm.api.board.mapper</li>
 * <li>설  명 : OomBulletinboardMapper.java</li>
 * <li>작성일 : 2021. 1. 8.</li>
 * <li>작성자 : jeonyb4</li>
 * </ul>
 */
@Mapper
public interface OomBulletinboardMapper {
	/**
	 * 
	 * listPageBulletinboard
	 *
	 * @param bulletinboardGridRequestDto
	 * @return List<BulletinboardGridResultDto>
	 */
	public List<BulletinboardGridResultDto> listPageBulletinboard(BulletinboardGridRequestDto bulletinboardGridRequestDto);
	
	/**
	 * 
	 * createOomBulletinboard
	 *
	 * @param reqOomBulletinboardDto
	 * @return int
	 */
	public int createOomBulletinboard(OomBulletinboardDto reqOomBulletinboardDto);
	
	/**
	 * 
	 * readOomBulletinboard
	 *
	 * @param reqOomBulletinboardDto
	 * @return BulletinboardDetailResultDto
	 */
	public BulletinboardDetailResultDto readOomBulletinboard(OomBulletinboardDto reqOomBulletinboardDto);
	
	/**
	 * 
	 * readOomBulletinboardAttachFile
	 *
	 * @param reqOomBulletinboardDto
	 * @return BulletinboardDetailResultDto
	 */
	public BulletinboardDetailResultDto readOomBulletinboardAttachFile(OomBulletinboardDto reqOomBulletinboardDto);
	
	/**
	 * 
	 * updateBrowseCnt
	 *
	 * @param reqOomBulletinboardDto
	 * @return int
	 */
	public int updateBrowseCnt(OomBulletinboardDto reqOomBulletinboardDto);
	
	/**
	 * 
	 * updateBulletinboardAttachFileNum
	 *
	 * @param reqOomBulletinboardDto
	 * @return int
	 */
	public int updateBulletinboardAttachFileNum(OomBulletinboardDto reqOomBulletinboardDto);
	
	/**
	 * 
	 * updateOomBulletinboard
	 *
	 * @param reqOomBulletinboardDto
	 * @return int
	 */
	public int updateOomBulletinboard(OomBulletinboardDto reqOomBulletinboardDto);
	
	/**
	 * 
	 * deleteOomBulletinboard
	 *
	 * @param reqOomBulletinboardDto
	 * @return int
	 */
	public int deleteOomBulletinboard(OomBulletinboardDto reqOomBulletinboardDto);
	

}
