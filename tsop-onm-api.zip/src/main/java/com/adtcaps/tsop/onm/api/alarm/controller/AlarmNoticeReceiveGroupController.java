package com.adtcaps.tsop.onm.api.alarm.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.util.CollectionUtils;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.adtcaps.tsop.onm.api.alarm.domain.AlarmNoticeReceiveGroupDetailResultDto;
import com.adtcaps.tsop.onm.api.alarm.domain.AlarmNoticeReceiveGroupForComboResultDto;
import com.adtcaps.tsop.onm.api.alarm.domain.AlarmNoticeReceiveGroupGridRequestDto;
import com.adtcaps.tsop.onm.api.alarm.domain.AlarmNoticeReceiveGroupGridResultDto;
import com.adtcaps.tsop.onm.api.alarm.domain.AlarmNoticeReceiveGroupProcessingDto;
import com.adtcaps.tsop.onm.api.alarm.service.AlarmNoticeReceiveGroupService;
import com.adtcaps.tsop.onm.api.alarm.service.AlarmNoticeService;
import com.adtcaps.tsop.onm.api.authentication.domain.JwtAuthResultDto;
import com.adtcaps.tsop.onm.api.domain.OomAlarmNoticeConditionDto;
import com.adtcaps.tsop.onm.api.domain.OomAlarmNoticeReceiveGroupDetailDto;
import com.adtcaps.tsop.onm.api.domain.OomAlarmNoticeReceiveGroupDto;
import com.adtcaps.tsop.onm.api.domain.OomUserRoleAuthorityDetailDto;
import com.adtcaps.tsop.onm.api.helper.constant.Const;
import com.adtcaps.tsop.onm.api.helper.domain.ResultDto;
import com.adtcaps.tsop.onm.api.helper.util.PageUtil;
import com.adtcaps.tsop.onm.api.user.domain.UserRoleMenuAuthorityRequestDto;
import com.adtcaps.tsop.onm.api.user.service.UserRoleService;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@RestController
@RequestMapping("/api/alarm-receive-groups")
public class AlarmNoticeReceiveGroupController {
	
	private final String MENU_ID = "ONM0012";
	
	private final String ERR_MSG_NULL_LOGIN_USER_ID = "로그인 사용자ID가 없습니다.";
	private final String ERR_MSG_NULL_MGR_YN = "관리자여부가 없습니다.";
	private final String ERR_MSG_NULL_PAGE_NUMBER = "페이지 번호가 없습니다.";
	private final String ERR_MSG_NULL_RECEIVE_GROUP_INFO = "수신그룹정보가 없습니다.";
	private final String ERR_MSG_NULL_RECEIVE_GROUP_DETAIL_LIST = "수신그룹상세 목록이 없습니다.";
	
	private final String ERR_MSG_DUPLICATE_GROUP_NAME = "대상그룹명이 중복되었습니다.";
	private final String ERR_MSG_ALREADY_EXIST_ALARM_NOTICE = "해당 대상그룹은 이미 알람설정에 매핑되어 있으므로 삭제할 수 없습니다.";
	
	private final String ERR_MSG_NO_AUTH = "권한이 없는 사용자 입니다.";
	private final String ERR_MSG_NULL_SEARCH_RESULT_LIST = "조회 결과가 없습니다.";
	private final String ERR_MSG_CREATE_FAIL = "등록에 실패하였습니다.";
	private final String ERR_MSG_READ_FAIL = "조회에 실패하였습니다.";
	private final String ERR_MSG_UPDATE_FAIL = "수정에 실패하였습니다.";
	private final String ERR_MSG_DELETE_FAIL = "삭제에 실패하였습니다.";
	
	@Autowired
	private AlarmNoticeReceiveGroupService alarmNoticeReceiveGroupService;
	
	@Autowired
	private AlarmNoticeService alarmNoticeService;
	
	@Autowired
	private UserRoleService userRoleService;
	
	/**
	 * 
	 * listBuildingAlarmNoticeReceiveGroupForCombo
	 *
	 * @param reqOomAlarmNoticeReceiveGroupDto
	 * @return ResponseEntity
	 */
	@SuppressWarnings("rawtypes")
	@GetMapping(value="/combobox", produces="application/json; charset=UTF-8")
	public ResponseEntity listBuildingAlarmNoticeReceiveGroupForCombo() throws Exception {
		
		ResponseEntity<ResultDto> resEntity = null;
		String returnString = "";
		
		// 콤보박스 제공용 빌딩별 알람통지수신그룹 목록 조회...
		List<AlarmNoticeReceiveGroupForComboResultDto> alarmNoticeReceiveGroupForComboResultDtoList = alarmNoticeReceiveGroupService.listAlarmNoticeReceiveGroupForCombo();
		if (CollectionUtils.isEmpty(alarmNoticeReceiveGroupForComboResultDtoList)) {
			returnString = Const.Common.RESULT_CODE.SUCCESS;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_SEARCH_RESULT_LIST, alarmNoticeReceiveGroupForComboResultDtoList));
		} else {
			returnString = Const.Common.RESULT_CODE.SUCCESS;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, "", alarmNoticeReceiveGroupForComboResultDtoList));
		}

		return resEntity;
	}
	
	/**
	 * 
	 * listPageAlarmNoticeReceiveGroup
	 *
	 * @param alarmNoticeReceiveGroupGridRequestDto
	 * @return ResponseEntity
	 */
	@SuppressWarnings("rawtypes")
    @GetMapping(value="", produces="application/json; charset=UTF-8")
    public ResponseEntity listPageAlarmNoticeReceiveGroup(AlarmNoticeReceiveGroupGridRequestDto alarmNoticeReceiveGroupGridRequestDto) throws Exception {
        
    	ResponseEntity<ResultDto> resEntity = null;
		String returnString = "";
    	
		int pageNumber = alarmNoticeReceiveGroupGridRequestDto.getPageNumber();
		if (pageNumber < 1) {
			log.error(">>>>>> pageNumber ERROR:{}", ERR_MSG_NULL_PAGE_NUMBER);
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_PAGE_NUMBER));
			return resEntity;
		}
		// 알람통지수신그룹 목록 조회....
		Map<String, Object> alarmNoticeReceiveGroupGridResultDtoListMap = new HashMap<String, Object>();
		List<AlarmNoticeReceiveGroupGridResultDto> alarmNoticeReceiveGroupGridResultDtoList = alarmNoticeReceiveGroupService.listPageAlarmNoticeReceiveGroup(alarmNoticeReceiveGroupGridRequestDto);
		if (CollectionUtils.isEmpty(alarmNoticeReceiveGroupGridResultDtoList)) {
			returnString = Const.Common.RESULT_CODE.SUCCESS;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_SEARCH_RESULT_LIST, alarmNoticeReceiveGroupGridResultDtoListMap));
		} else {
			returnString = Const.Common.RESULT_CODE.SUCCESS;
			alarmNoticeReceiveGroupGridResultDtoListMap.put(Const.Definition.PAGE.PAGER, PageUtil.getPageInfo(alarmNoticeReceiveGroupGridResultDtoList));
			alarmNoticeReceiveGroupGridResultDtoListMap.put(Const.Definition.PAGE.LISTS, alarmNoticeReceiveGroupGridResultDtoList);
			resEntity = ResponseEntity.ok(new ResultDto(returnString, "", alarmNoticeReceiveGroupGridResultDtoListMap));
		}
    	
    	return resEntity;
    }
	
	/**
	 * 
	 * createAlarmNoticeReceiveGroup
	 *
	 * @param reqOomAlarmNoticeReceiveGroupDto
	 * @return ResponseEntity
	 */
	@SuppressWarnings("rawtypes")
    @PostMapping(value="", produces="application/json; charset=UTF-8")
    public ResponseEntity createAlarmNoticeReceiveGroup(@AuthenticationPrincipal JwtAuthResultDto authResultDto, 
    		@RequestBody AlarmNoticeReceiveGroupProcessingDto reqAlarmNoticeReceiveGroupProcessingDto) throws Exception {
        
    	ResponseEntity<ResultDto> resEntity = null;
		String returnString = "";
    	
		String loginUserId = StringUtils.defaultString(authResultDto.getUserId());
		if ("".equals(loginUserId)) {
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_LOGIN_USER_ID));
			return resEntity;
		}
		String mgrYn = StringUtils.defaultString(authResultDto.getMgrYn());
		if ("".equals(mgrYn)) {
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_MGR_YN));
			return resEntity;
		}
		//String loginUserId = "tsop-admin"; // 이후 세션에서 얻어올 값...
		
		if (!"Y".equals(mgrYn)) {
			String authorityTypeCd = "";
			UserRoleMenuAuthorityRequestDto userRoleMenuAuthorityRequestDto = new UserRoleMenuAuthorityRequestDto();
			userRoleMenuAuthorityRequestDto.setUserId(loginUserId);
			userRoleMenuAuthorityRequestDto.setMenuId(MENU_ID);
			OomUserRoleAuthorityDetailDto rsltOomUserRoleAuthorityDetailDto = userRoleService.readMenuAuthority(userRoleMenuAuthorityRequestDto);
			if (rsltOomUserRoleAuthorityDetailDto != null) {
				authorityTypeCd = StringUtils.defaultString(rsltOomUserRoleAuthorityDetailDto.getAuthorityTypeCd());
			}
			if (!"W".equals(authorityTypeCd)) {
				returnString = Const.Common.RESULT_CODE.FAIL;
				resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NO_AUTH));
				return resEntity;
			}
		}
		
		OomAlarmNoticeReceiveGroupDto reqOomAlarmNoticeReceiveGroupDto = reqAlarmNoticeReceiveGroupProcessingDto.getReceiveGroupInfo();
		if (reqOomAlarmNoticeReceiveGroupDto == null) {
			log.error(">>>>>> reqOomAlarmNoticeReceiveGroupDto ERROR:{}", ERR_MSG_NULL_RECEIVE_GROUP_INFO);
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_RECEIVE_GROUP_INFO));
			return resEntity;
		}
		List<OomAlarmNoticeReceiveGroupDetailDto> reqOomAlarmNoticeReceiveGroupDetailDtoList = reqAlarmNoticeReceiveGroupProcessingDto.getReceiveGroupDetailList();
		if (CollectionUtils.isEmpty(reqOomAlarmNoticeReceiveGroupDetailDtoList)) {
			log.error(">>>>>> reqOomAlarmNoticeReceiveGroupDetailDtoList ERROR:{}", ERR_MSG_NULL_RECEIVE_GROUP_DETAIL_LIST);
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_RECEIVE_GROUP_DETAIL_LIST));
			return resEntity;
		}
		for (int idx = 0; idx < reqOomAlarmNoticeReceiveGroupDetailDtoList.size(); idx++) {
			OomAlarmNoticeReceiveGroupDetailDto reqOomAlarmNoticeReceiveGroupDetailDto = reqOomAlarmNoticeReceiveGroupDetailDtoList.get(idx);
			reqOomAlarmNoticeReceiveGroupDetailDto.setAuditId(loginUserId);
			reqOomAlarmNoticeReceiveGroupDetailDtoList.set(idx, reqOomAlarmNoticeReceiveGroupDetailDto);
		}
		String useYn = StringUtils.defaultString(reqOomAlarmNoticeReceiveGroupDto.getUseYn());
		if ("".equals(useYn)) {
			reqOomAlarmNoticeReceiveGroupDto.setUseYn("Y");
		}
		
		// 그룹명 중복체크
		int groupNameCount = alarmNoticeReceiveGroupService.getAlarmReceiveGroupCount(reqOomAlarmNoticeReceiveGroupDto);
		if (groupNameCount > 0) {
			log.error(">>>>>> alarmNoticeGroupName ERROR:{}", ERR_MSG_DUPLICATE_GROUP_NAME);
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_DUPLICATE_GROUP_NAME));
			return resEntity;
		}
		
		reqOomAlarmNoticeReceiveGroupDto.setRegisterId(loginUserId);
		reqOomAlarmNoticeReceiveGroupDto.setAuditId(loginUserId);
		reqAlarmNoticeReceiveGroupProcessingDto.setReceiveGroupInfo(reqOomAlarmNoticeReceiveGroupDto);
		
		// 알람통지수신그룹 등록...
		int affectRowCount = alarmNoticeReceiveGroupService.createAlarmNoticeReceiveGroup(reqAlarmNoticeReceiveGroupProcessingDto);
		if (affectRowCount < 1) {
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_CREATE_FAIL, affectRowCount));
		} else {
			returnString = Const.Common.RESULT_CODE.SUCCESS;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, "", affectRowCount));
		}
    	
    	return resEntity;
    }
	
	/**
	 * 
	 * readAlarmNoticeReceiveGroup
	 *
	 * @param alarmNoticeGroupId
	 * @param reqOomAlarmNoticeReceiveGroupDto
	 * @return ResponseEntity
	 */
	@SuppressWarnings("rawtypes")
    @GetMapping(value="/{alarmNoticeGroupId}", produces="application/json; charset=UTF-8")
    public ResponseEntity readAlarmNoticeReceiveGroup(@PathVariable("alarmNoticeGroupId") int alarmNoticeGroupId, OomAlarmNoticeReceiveGroupDto reqOomAlarmNoticeReceiveGroupDto) throws Exception {
        
    	ResponseEntity<ResultDto> resEntity = null;
		String returnString = "";
    	
		reqOomAlarmNoticeReceiveGroupDto.setAlarmNoticeGroupId(alarmNoticeGroupId);
		
		// 알람통지수신그룹 상세조회
		AlarmNoticeReceiveGroupDetailResultDto alarmNoticeReceiveGroupDetailResultDto = alarmNoticeReceiveGroupService.readAlarmNoticeReceiveGroup(reqOomAlarmNoticeReceiveGroupDto);
		if (alarmNoticeReceiveGroupDetailResultDto == null) {
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_READ_FAIL, alarmNoticeReceiveGroupDetailResultDto));
		} else {
			returnString = Const.Common.RESULT_CODE.SUCCESS;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, "", alarmNoticeReceiveGroupDetailResultDto));
		}
    	
    	return resEntity;
    }
	
	/**
	 * 
	 * updateAlarmNoticeReceiveGroup
	 *
	 * @param alarmNoticeGroupId
	 * @param reqOomAlarmNoticeReceiveGroupDto
	 * @return ResponseEntity
	 */
	@SuppressWarnings("rawtypes")
    @PutMapping(value="/{alarmNoticeGroupId}", produces="application/json; charset=UTF-8")
    public ResponseEntity updateAlarmNoticeReceiveGroup(@AuthenticationPrincipal JwtAuthResultDto authResultDto, 
    		@PathVariable("alarmNoticeGroupId") int alarmNoticeGroupId, @RequestBody AlarmNoticeReceiveGroupProcessingDto reqAlarmNoticeReceiveGroupProcessingDto) throws Exception {
        
    	ResponseEntity<ResultDto> resEntity = null;
		String returnString = "";
    	
		String loginUserId = StringUtils.defaultString(authResultDto.getUserId());
		if ("".equals(loginUserId)) {
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_LOGIN_USER_ID));
			return resEntity;
		}
		String mgrYn = StringUtils.defaultString(authResultDto.getMgrYn());
		if ("".equals(mgrYn)) {
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_MGR_YN));
			return resEntity;
		}
		//String loginUserId = "tsop-admin"; // 이후 세션에서 얻어올 값...
		
		if (!"Y".equals(mgrYn)) {
			String authorityTypeCd = "";
			UserRoleMenuAuthorityRequestDto userRoleMenuAuthorityRequestDto = new UserRoleMenuAuthorityRequestDto();
			userRoleMenuAuthorityRequestDto.setUserId(loginUserId);
			userRoleMenuAuthorityRequestDto.setMenuId(MENU_ID);
			OomUserRoleAuthorityDetailDto rsltOomUserRoleAuthorityDetailDto = userRoleService.readMenuAuthority(userRoleMenuAuthorityRequestDto);
			if (rsltOomUserRoleAuthorityDetailDto != null) {
				authorityTypeCd = StringUtils.defaultString(rsltOomUserRoleAuthorityDetailDto.getAuthorityTypeCd());
			}
			if (!"W".equals(authorityTypeCd)) {
				returnString = Const.Common.RESULT_CODE.FAIL;
				resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NO_AUTH));
				return resEntity;
			}
		}
		
		OomAlarmNoticeReceiveGroupDto reqOomAlarmNoticeReceiveGroupDto = reqAlarmNoticeReceiveGroupProcessingDto.getReceiveGroupInfo();
		if (reqOomAlarmNoticeReceiveGroupDto == null) {
			log.error(">>>>>> reqOomAlarmNoticeReceiveGroupDto ERROR:{}", ERR_MSG_NULL_RECEIVE_GROUP_INFO);
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_RECEIVE_GROUP_INFO));
			return resEntity;
		}
		List<OomAlarmNoticeReceiveGroupDetailDto> reqOomAlarmNoticeReceiveGroupDetailDtoList = reqAlarmNoticeReceiveGroupProcessingDto.getReceiveGroupDetailList();
		if (CollectionUtils.isEmpty(reqOomAlarmNoticeReceiveGroupDetailDtoList)) {
			log.error(">>>>>> reqOomAlarmNoticeReceiveGroupDetailDtoList ERROR:{}", ERR_MSG_NULL_RECEIVE_GROUP_DETAIL_LIST);
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_RECEIVE_GROUP_DETAIL_LIST));
			return resEntity;
		}
		for (int idx = 0; idx < reqOomAlarmNoticeReceiveGroupDetailDtoList.size(); idx++) {
			OomAlarmNoticeReceiveGroupDetailDto reqOomAlarmNoticeReceiveGroupDetailDto = reqOomAlarmNoticeReceiveGroupDetailDtoList.get(idx);
			reqOomAlarmNoticeReceiveGroupDetailDto.setAuditId(loginUserId);
			reqOomAlarmNoticeReceiveGroupDetailDtoList.set(idx, reqOomAlarmNoticeReceiveGroupDetailDto);
		}
		
		reqOomAlarmNoticeReceiveGroupDto.setAuditId(loginUserId);
		reqOomAlarmNoticeReceiveGroupDto.setAlarmNoticeGroupId(alarmNoticeGroupId);
		reqAlarmNoticeReceiveGroupProcessingDto.setReceiveGroupInfo(reqOomAlarmNoticeReceiveGroupDto);
		
		// 그룹명 중복체크
		int groupNameCount = alarmNoticeReceiveGroupService.getAlarmReceiveGroupCount(reqOomAlarmNoticeReceiveGroupDto);
		if (groupNameCount > 0) {
			log.error(">>>>>> alarmNoticeGroupName ERROR:{}", ERR_MSG_DUPLICATE_GROUP_NAME);
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_DUPLICATE_GROUP_NAME));
			return resEntity;
		}
		
		// 알람통지수신그룹 수정...
		int affectRowCount = alarmNoticeReceiveGroupService.updateAlarmNoticeReceiveGroup(reqAlarmNoticeReceiveGroupProcessingDto);
		if (affectRowCount < 1) {
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_UPDATE_FAIL, affectRowCount));
		} else {
			returnString = Const.Common.RESULT_CODE.SUCCESS;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, "", affectRowCount));
		}
    	
    	return resEntity;
    }
	
	/**
	 * 
	 * deleteAlarmNoticeReceiveGroup
	 *
	 * @param alarmNoticeGroupId
	 * @return ResponseEntity
	 */
	@SuppressWarnings("rawtypes")
    @DeleteMapping(value="/{alarmNoticeGroupId}", produces="application/json; charset=UTF-8")
	public ResponseEntity deleteAlarmNoticeReceiveGroup(@AuthenticationPrincipal JwtAuthResultDto authResultDto, 
			@PathVariable("alarmNoticeGroupId") int alarmNoticeGroupId) throws Exception {
        
    	ResponseEntity<ResultDto> resEntity = null;
		String returnString = "";
    	
		String loginUserId = StringUtils.defaultString(authResultDto.getUserId());
		if ("".equals(loginUserId)) {
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_LOGIN_USER_ID));
			return resEntity;
		}
		String mgrYn = StringUtils.defaultString(authResultDto.getMgrYn());
		if ("".equals(mgrYn)) {
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_MGR_YN));
			return resEntity;
		}
		//String loginUserId = "tsop-admin"; // 이후 세션에서 얻어올 값...
		
		if (!"Y".equals(mgrYn)) {
			String authorityTypeCd = "";
			UserRoleMenuAuthorityRequestDto userRoleMenuAuthorityRequestDto = new UserRoleMenuAuthorityRequestDto();
			userRoleMenuAuthorityRequestDto.setUserId(loginUserId);
			userRoleMenuAuthorityRequestDto.setMenuId(MENU_ID);
			OomUserRoleAuthorityDetailDto rsltOomUserRoleAuthorityDetailDto = userRoleService.readMenuAuthority(userRoleMenuAuthorityRequestDto);
			if (rsltOomUserRoleAuthorityDetailDto != null) {
				authorityTypeCd = StringUtils.defaultString(rsltOomUserRoleAuthorityDetailDto.getAuthorityTypeCd());
			}
			if (!"W".equals(authorityTypeCd)) {
				returnString = Const.Common.RESULT_CODE.FAIL;
				resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NO_AUTH));
				return resEntity;
			}
		}
		
		OomAlarmNoticeReceiveGroupDto reqOomAlarmNoticeReceiveGroupDto = new OomAlarmNoticeReceiveGroupDto();
		reqOomAlarmNoticeReceiveGroupDto.setAuditId(loginUserId);
		reqOomAlarmNoticeReceiveGroupDto.setAlarmNoticeGroupId(alarmNoticeGroupId);
		
		// 알람설정에 적용되었는지 확인...
		OomAlarmNoticeConditionDto reqOomAlarmNoticeConditionDto = new OomAlarmNoticeConditionDto();
		reqOomAlarmNoticeConditionDto.setAlarmNoticeGroupId(alarmNoticeGroupId);
		int conditionCount = alarmNoticeService.readAlarmNoticeCountForReceiveGroup(reqOomAlarmNoticeConditionDto);
		if (conditionCount > 0) {
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_ALREADY_EXIST_ALARM_NOTICE));
			return resEntity;
		}
		
		// 알람통지수신그룹 삭제...
		int affectRowCount = alarmNoticeReceiveGroupService.deleteAlarmNoticeReceiveGroup(reqOomAlarmNoticeReceiveGroupDto);
		if (affectRowCount < 1) {
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_DELETE_FAIL, affectRowCount));
		} else {
			returnString = Const.Common.RESULT_CODE.SUCCESS;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, "", affectRowCount));
		}
    	
    	return resEntity;
    }
	
	/**
	 * 
	 * updateAlarmReceiveGroupReuse
	 *
	 * @param authResultDto
	 * @param alarmNoticeGroupId
	 * @return
	 * @throws Exception ResponseEntity
	 */
	@SuppressWarnings("rawtypes")
    @PutMapping(value="/{alarmNoticeGroupId}/reuse", produces="application/json; charset=UTF-8")
    public ResponseEntity updateAlarmReceiveGroupReuse(@AuthenticationPrincipal JwtAuthResultDto authResultDto, 
    		@PathVariable("alarmNoticeGroupId") int alarmNoticeGroupId) throws Exception {
        
    	ResponseEntity<ResultDto> resEntity = null;
		String returnString = "";
    	
		String loginUserId = StringUtils.defaultString(authResultDto.getUserId());
		if ("".equals(loginUserId)) {
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_LOGIN_USER_ID));
			return resEntity;
		}
		String mgrYn = StringUtils.defaultString(authResultDto.getMgrYn());
		if ("".equals(mgrYn)) {
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_MGR_YN));
			return resEntity;
		}
		//String loginUserId = "tsop-admin"; // 이후 세션에서 얻어올 값...
		
		if (!"Y".equals(mgrYn)) {
			String authorityTypeCd = "";
			UserRoleMenuAuthorityRequestDto userRoleMenuAuthorityRequestDto = new UserRoleMenuAuthorityRequestDto();
			userRoleMenuAuthorityRequestDto.setUserId(loginUserId);
			userRoleMenuAuthorityRequestDto.setMenuId(MENU_ID);
			OomUserRoleAuthorityDetailDto rsltOomUserRoleAuthorityDetailDto = userRoleService.readMenuAuthority(userRoleMenuAuthorityRequestDto);
			if (rsltOomUserRoleAuthorityDetailDto != null) {
				authorityTypeCd = StringUtils.defaultString(rsltOomUserRoleAuthorityDetailDto.getAuthorityTypeCd());
			}
			if (!"W".equals(authorityTypeCd)) {
				returnString = Const.Common.RESULT_CODE.FAIL;
				resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NO_AUTH));
				return resEntity;
			}
		}
		
		OomAlarmNoticeReceiveGroupDto reqOomAlarmNoticeReceiveGroupDto = new OomAlarmNoticeReceiveGroupDto();
		reqOomAlarmNoticeReceiveGroupDto.setAuditId(loginUserId);
		reqOomAlarmNoticeReceiveGroupDto.setAlarmNoticeGroupId(alarmNoticeGroupId);
		
		int affectRowCount = alarmNoticeReceiveGroupService.updateAlarmReceiveGroupReuse(reqOomAlarmNoticeReceiveGroupDto);
		if (affectRowCount < 1) {
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_UPDATE_FAIL, affectRowCount));
		} else {
			returnString = Const.Common.RESULT_CODE.SUCCESS;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, "", affectRowCount));
		}
    	
    	return resEntity;
    }
	

}
