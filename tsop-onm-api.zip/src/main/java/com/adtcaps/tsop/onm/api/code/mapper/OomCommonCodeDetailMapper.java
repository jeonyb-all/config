package com.adtcaps.tsop.onm.api.code.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;

import com.adtcaps.tsop.onm.api.code.domain.CommonCodeDetailDetailResultDto;
import com.adtcaps.tsop.onm.api.code.domain.CommonCodeDetailForShortGridResultDto;
import com.adtcaps.tsop.onm.api.code.domain.CommonCodeDetailGridResultDto;
import com.adtcaps.tsop.onm.api.code.domain.CommonCodeDetailRequestDto;
import com.adtcaps.tsop.onm.api.domain.OomCommonCodeDetailDto;
import com.adtcaps.tsop.onm.api.helper.domain.BasePageDto;

/**
 * 
 * <ul>
 * <li>업무 그룹명 : tsop-onm-api</li>
 * <li>서브 업무명 : com.adtcaps.tsop.onm.api.code.mapper</li>
 * <li>설  명 : OomCommonCodeDetailMapper.java</li>
 * <li>작성일 : 2021. 1. 5.</li>
 * <li>작성자 : jeonyb4</li>
 * </ul>
 */
@Mapper
public interface OomCommonCodeDetailMapper {
	/**
	 * 
	 * listCommonCodeDetail
	 *
	 * @param reqOomCommonCodeDetailDto
	 * @return List<CommonCodeDetailGridResultDto>
	 */
	public List<CommonCodeDetailGridResultDto> listCommonCodeDetail(OomCommonCodeDetailDto reqOomCommonCodeDetailDto);
	
	/**
	 * 
	 * readCommonCodeDetailDuplicationCheck
	 *
	 * @param reqOomCommonCodeDetailDto
	 * @return int
	 */
	public int readCommonCodeDetailDuplicationCheck(OomCommonCodeDetailDto reqOomCommonCodeDetailDto);
	
	/**
	 * 
	 * createOomCommonCodeDetail
	 *
	 * @param reqOomCommonCodeDetailDto
	 * @return int
	 */
	public int createOomCommonCodeDetail(OomCommonCodeDetailDto reqOomCommonCodeDetailDto);
	
	/**
	 * 
	 * readOomCommonCodeDetail
	 *
	 * @param reqOomCommonCodeDetailDto
	 * @return CommonCodeDetailDetailResultDto
	 */
	public CommonCodeDetailDetailResultDto readOomCommonCodeDetail(OomCommonCodeDetailDto reqOomCommonCodeDetailDto);
	
	/**
	 * 
	 * updateOomCommonCodeDetail
	 *
	 * @param reqOomCommonCodeDetailDto
	 * @return int
	 */
	public int updateOomCommonCodeDetail(OomCommonCodeDetailDto reqOomCommonCodeDetailDto);
	
	/**
	 * 
	 * deleteOomCommonCodeDetail
	 *
	 * @param reqOomCommonCodeDetailDto
	 * @return int
	 */
	public int deleteOomCommonCodeDetail(OomCommonCodeDetailDto reqOomCommonCodeDetailDto);
	
	
	/**
	 * 
	 * listCommonCodeDetailForCombo
	 *
	 * @param commonCodeDetailRequestDto
	 * @return List<OomCommonCodeDetailDto>
	 */
	public List<OomCommonCodeDetailDto> listCommonCodeDetailForCombo(CommonCodeDetailRequestDto commonCodeDetailRequestDto);
	
	/**
	 * 
	 * listCommonCodeDetailForShortGrid
	 *
	 * @param reqBasePageDto
	 * @return List<CommonCodeDetailForShortGridResultDto>
	 */
	public List<CommonCodeDetailForShortGridResultDto> listCommonCodeDetailForShortGrid(BasePageDto reqBasePageDto);
	
	/**
	 * 
	 * readCommonCodeDetailByName
	 *
	 * @param commonCodeDetailRequestDto
	 * @return OomCommonCodeDetailDto
	 */
	public OomCommonCodeDetailDto readCommonCodeDetailByName(CommonCodeDetailRequestDto commonCodeDetailRequestDto);

}
