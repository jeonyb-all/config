package com.adtcaps.tsop.onm.api.tenant.service.impl;

import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import com.adtcaps.tsop.onm.api.domain.OomTenantDto;
import com.adtcaps.tsop.onm.api.helper.domain.BasePageDto;
import com.adtcaps.tsop.onm.api.helper.util.CommonDateUtil;
import com.adtcaps.tsop.onm.api.tenant.domain.TenantDetailResultDto;
import com.adtcaps.tsop.onm.api.tenant.domain.TenantForComboResultDto;
import com.adtcaps.tsop.onm.api.tenant.domain.TenantForShortGridResultDto;
import com.adtcaps.tsop.onm.api.tenant.domain.TenantGridResultDto;
import com.adtcaps.tsop.onm.api.tenant.mapper.OomTenantMapper;
import com.adtcaps.tsop.onm.api.tenant.service.TenantService;

/**
 * 
 * <ul>
 * <li>업무 그룹명 : tsop-onm-api</li>
 * <li>서브 업무명 : com.adtcaps.tsop.onm.api.tenant.service.impl</li>
 * <li>설  명 : TenantServiceImpl.java</li>
 * <li>작성일 : 2021. 1. 6.</li>
 * <li>작성자 : jeonyb4</li>
 * </ul>
 */
@Service
public class TenantServiceImpl implements TenantService {
	
	@Autowired
	private OomTenantMapper oomTenantMapper;
	
	/**
	 * 
	 * listTenantForCombo
	 *
	 * @return List<TenantForComboResultDto>
	 * @throws Exception 
	 */
	@Override
	public List<TenantForComboResultDto> listTenantForCombo() throws Exception {
		
		List<TenantForComboResultDto> tenantForComboResultDtoList = null;
		try {
			tenantForComboResultDtoList = oomTenantMapper.listTenantForCombo();
		} catch (Exception e) {
			throw e;
		}
		return tenantForComboResultDtoList;
	}
	
	/**
	 * 
	 * listTenantForWorkForCombo
	 *
	 * @return List<TenantForComboResultDto>
	 * @throws Exception 
	 */
	@Override
	public List<TenantForComboResultDto> listTenantForWorkForCombo() throws Exception {
		
		List<TenantForComboResultDto> tenantForComboResultDtoList = null;
		try {
			tenantForComboResultDtoList = oomTenantMapper.listTenantForWorkForCombo();
		} catch (Exception e) {
			throw e;
		}
		return tenantForComboResultDtoList;
	}
	
	/**
	 * 
	 * listTenantForShortGrid
	 *
	 * @param reqBasePageDto
	 * @return List<TenantForShortGridResultDto>
	 * @throws Exception 
	 */
	@Override
	public List<TenantForShortGridResultDto> listTenantForShortGrid(BasePageDto reqBasePageDto) throws Exception {
		
		List<TenantForShortGridResultDto> tenantForShortGridResultDtoList = null;
		try {
			tenantForShortGridResultDtoList = oomTenantMapper.listTenantForShortGrid(reqBasePageDto);
		} catch (Exception e) {
			throw e;
		}
		return tenantForShortGridResultDtoList;
	}
	
	/**
	 * 
	 * listPageTenant
	 *
	 * @param reqBasePageDto
	 * @return List<TenantGridResultDto>
	 * @throws Exception 
	 */
	@Override
	public List<TenantGridResultDto> listPageTenant(BasePageDto reqBasePageDto) throws Exception {
		
		List<TenantGridResultDto> tenantGridResultDtoList = null;
		try {
			tenantGridResultDtoList = oomTenantMapper.listPageTenant(reqBasePageDto);
			if (!CollectionUtils.isEmpty(tenantGridResultDtoList)) {
				for (int idx = 0; idx < tenantGridResultDtoList.size(); idx++) {
    				
					TenantGridResultDto tenantGridResultDto = tenantGridResultDtoList.get(idx);
    				
    				String registDate = StringUtils.defaultString(tenantGridResultDto.getRegistDate());
    				registDate = CommonDateUtil.makeDateToDateFormat(registDate);
    				tenantGridResultDto.setRegistDate(registDate);
    				
    				tenantGridResultDtoList.set(idx, tenantGridResultDto);
    			}
			}
		} catch (Exception e) {
			throw e;
		}
		return tenantGridResultDtoList;
	}
	
	/**
	 * 
	 * readTenant
	 *
	 * @param reqOomTenantDto
	 * @return TenantDetailResultDto
	 * @throws Exception 
	 */
	@Override
	public TenantDetailResultDto readTenant(OomTenantDto reqOomTenantDto) throws Exception {
		
		TenantDetailResultDto tenantDetailResultDto = null;
		try {
			tenantDetailResultDto = oomTenantMapper.readOomTenant(reqOomTenantDto);
		} catch (Exception e) {
			throw e;
		}
		return tenantDetailResultDto;
	}
	
	/**
	 * 
	 * readTenantForWork
	 *
	 * @param reqOomTenantDto
	 * @return OomTenantDto
	 * @throws Exception 
	 */
	@Override
	public OomTenantDto readTenantForWork(OomTenantDto reqOomTenantDto) throws Exception {
		
		OomTenantDto rsltOomTenantDto = null;
		try {
			rsltOomTenantDto = oomTenantMapper.readOomTenantForWork(reqOomTenantDto);
		} catch (Exception e) {
			throw e;
		}
		return rsltOomTenantDto;
	}

}
