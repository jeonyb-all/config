package com.adtcaps.tsop.onm.api.sms.domain;

import com.fasterxml.jackson.annotation.JsonInclude;

/**
 * AccessInformation 모델.
 *
 * @author zeal77@sk.com
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
public class SmsAccessInformation {
    /**
     * SKB SMS 서버 URL.
     */
    private String url;
    /**
     * USER ID.
     */
    private String id;
    /**
     * 접속 비밀번호.
     */
    private String pw;
    /**
     * callback번호.
     */
    private String sendNo;
    /**
     * 인증 토큰.
     */
    private String accessToken;
    

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public String getUserId() {
        return id;
    }

    public void setUserId(String id) {
        this.id = id;
    }

    public String getPw() {
        return pw;
    }

    public void setPw(String pw) {
        this.pw = pw;
    }

    public String getSendNo() {
        return sendNo;
    }

    public void setSendNo(String sendNo) {
        this.sendNo = sendNo;
    }

    public String getAccessToken() {
        return accessToken;
    }

    public void setAccessToken(String accessToken) {
        this.accessToken = accessToken;
    }
    
	@Override
    public String toString() {
        return "SmsAccessInformation{" +
                "url='" + url + '\'' +
                ", id='" + id + '\'' +
                ", pw='" + pw + '\'' +
                ", accessToken='" + accessToken + '\'' +
                ", sendNo=" + sendNo +
                '}';
    }
}
