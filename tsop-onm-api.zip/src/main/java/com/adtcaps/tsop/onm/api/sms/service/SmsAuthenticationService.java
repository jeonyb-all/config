package com.adtcaps.tsop.onm.api.sms.service;

import com.adtcaps.tsop.onm.api.sms.domain.SmsAccessInformation;

/**
 * SmsAuthenticationService.
 * @author zeal77@sk.com
 */
public interface SmsAuthenticationService {
    /**
     * 로그인.
     * @param accessInformation 로그인 접속 정보.
     * @return 로그인 결과
     */
    SmsAccessInformation getAuth(SmsAccessInformation smsAccessInformation);
    /**
     * API 호출에 필요한 KEEP ALIVE.
     * @param accessInformation 접속 정보
     */
    void getKeepAlive(SmsAccessInformation smsAccessInformation);
    /**
     * Token KEEP ALIVE.
     * @param accessInformation 접속 정보
     */
    void getTokenKeepAlive(SmsAccessInformation smsAccessInformation);
}
