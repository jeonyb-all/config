package com.adtcaps.tsop.onm.api.code.domain;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

import lombok.Getter;
import lombok.Setter;

/**
 * 
 * <ul>
 * <li>업무 그룹명 : tsop-onm-api</li>
 * <li>서브 업무명 : com.adtcaps.tsop.onm.api.code.domain</li>
 * <li>설  명 : CommonCodeDetailForShortGridResultDto.java</li>
 * <li>작성일 : 2021. 1. 5.</li>
 * <li>작성자 : jeonyb4</li>
 * </ul>
 */
@Getter
@Setter
@JsonInclude(Include.NON_EMPTY)
public class CommonCodeDetailForShortGridResultDto {
	private String commonCd;
	private String commonCdName;
	private String commonCdVal;
	private String commonCdValName;

}
