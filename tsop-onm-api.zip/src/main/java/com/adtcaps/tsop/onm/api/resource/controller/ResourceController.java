package com.adtcaps.tsop.onm.api.resource.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.util.CollectionUtils;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.adtcaps.tsop.onm.api.helper.constant.Const;
import com.adtcaps.tsop.onm.api.helper.domain.ResultDto;
import com.adtcaps.tsop.onm.api.resource.domain.ResourceCategoryForComboResultDto;
import com.adtcaps.tsop.onm.api.resource.service.ResourceService;

/**
 * 
 * <ul>
 * <li>업무 그룹명 : tsop-onm-api</li>
 * <li>서브 업무명 : com.adtcaps.tsop.onm.api.resource.controller</li>
 * <li>설  명 : ResourceController.java</li>
 * <li>작성일 : 2021. 1. 8.</li>
 * <li>작성자 : jeonyb4</li>
 * </ul>
 */
@RestController
@RequestMapping("/api/resources")
public class ResourceController {
	
	private final String ERR_MSG_NULL_SEARCH_RESULT_LIST = "조회 결과가 없습니다.";
	
	@Autowired
	private ResourceService resourceService;
	
	/**
	 * 
	 * listResourceCategoryForCombo
	 *
	 * @return ResponseEntity
	 */
	@SuppressWarnings("rawtypes")
	@GetMapping(value="/categories/combobox", produces="application/json; charset=UTF-8")
	public ResponseEntity listResourceCategoryForCombo() throws Exception {
		
		ResponseEntity<ResultDto> resEntity = null;
		String returnString = "";
		
		// 콤보박스용 리소스 카테고리 목록조회
		List<ResourceCategoryForComboResultDto> resourceCategoryForComboResultDtoList = resourceService.listResourceCategoryForCombo();
		if (CollectionUtils.isEmpty(resourceCategoryForComboResultDtoList)) {
			returnString = Const.Common.RESULT_CODE.SUCCESS;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_SEARCH_RESULT_LIST, resourceCategoryForComboResultDtoList));
        } else {
        	returnString = Const.Common.RESULT_CODE.SUCCESS;
        	resEntity = ResponseEntity.ok(new ResultDto(returnString, "", resourceCategoryForComboResultDtoList));
		}

		return resEntity;
	}

}
