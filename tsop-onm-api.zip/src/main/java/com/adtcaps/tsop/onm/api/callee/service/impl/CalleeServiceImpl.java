package com.adtcaps.tsop.onm.api.callee.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.adtcaps.tsop.onm.api.callee.domain.TechSupportRequestProcessingDto;
import com.adtcaps.tsop.onm.api.callee.service.CalleeService;
import com.adtcaps.tsop.onm.api.domain.OomTechSupportRequestBuildingDto;
import com.adtcaps.tsop.onm.api.domain.OomTechSupportRequestBuildingServiceDto;
import com.adtcaps.tsop.onm.api.domain.OomTechSupportRequestDto;
import com.adtcaps.tsop.onm.api.file.domain.BlobRequestDto;
import com.adtcaps.tsop.onm.api.file.service.FileService;
import com.adtcaps.tsop.onm.api.helper.constant.Const;
import com.adtcaps.tsop.onm.api.support.mapper.OomTechSupportRequestBuildingMapper;
import com.adtcaps.tsop.onm.api.support.mapper.OomTechSupportRequestBuildingServiceMapper;
import com.adtcaps.tsop.onm.api.support.mapper.OomTechSupportRequestMapper;

/**
 * 
 * <ul>
 * <li>업무 그룹명 : tsop-onm-api</li>
 * <li>서브 업무명 : com.adtcaps.tsop.onm.api.callee.service.impl</li>
 * <li>설  명 : CalleeServiceImpl.java</li>
 * <li>작성일 : 2021. 1. 3.</li>
 * <li>작성자 : jeonyb4</li>
 * </ul>
 */
@Transactional
@Service
public class CalleeServiceImpl implements CalleeService {
	
	@Autowired
	private FileService fileService;
	
	@Autowired
	private OomTechSupportRequestMapper oomTechSupportRequestMapper;
	
	@Autowired
	private OomTechSupportRequestBuildingMapper oomTechSupportRequestBuildingMapper;
	
	@Autowired
	private OomTechSupportRequestBuildingServiceMapper oomTechSupportRequestBuildingServiceMapper;
	
	/**
	 * 
	 * createRemoteBulletinboard
	 *
	 * @param reqBulletinboardProcessingDto
	 * @return int
	 * @throws Exception 
	 */
	@Override
	public int createRemoteTechSupportRequest(TechSupportRequestProcessingDto techSupportRequestProcessingDto) throws Exception {
		
		int affectRowCount = 0;
		
		try {
			String tenantId = techSupportRequestProcessingDto.getTenantId(); 
			
			OomTechSupportRequestDto reqOomTechSupportRequestDto = techSupportRequestProcessingDto.getTechSupportRequestInfo();
			BlobRequestDto blobRequestDto = techSupportRequestProcessingDto.getAttachFile();
			if (blobRequestDto != null) {
				blobRequestDto.setContainerName(Const.Definition.BLOB_CONTAINER.FILE);
				blobRequestDto.setBlobBaseDir(Const.Definition.BLOB_BASEDIR.SUPPORT);
				int attachFileNum = fileService.createRemoteAttachFile(blobRequestDto);
				if (attachFileNum > 0) {
					reqOomTechSupportRequestDto.setAttachFileNum(attachFileNum);
				}
			}
			
			String techSupportReqTypeCd = reqOomTechSupportRequestDto.getTechSupportReqTypeCd();
			if (Const.Code.TECH_SUPPORT_REQ_TYPE_CD.ETC.equals(techSupportReqTypeCd)) {
				reqOomTechSupportRequestDto.setWorkMgmtApplyYn("N");
    		} else {
    			reqOomTechSupportRequestDto.setWorkMgmtApplyYn("Y");
    		}
			
			// 기술지원요청(기타 포함) 등록...
			reqOomTechSupportRequestDto.setTenantId(tenantId);
			int insertRow = oomTechSupportRequestMapper.createOomTechSupportRequest(reqOomTechSupportRequestDto);
			affectRowCount = affectRowCount + insertRow;
			
			// 건물변경요청 등록...
			if (Const.Code.TECH_SUPPORT_REQ_TYPE_CD.BLD_ADD.equals(techSupportReqTypeCd)) {
				OomTechSupportRequestBuildingDto reqOomTechSupportRequestBuildingDto = techSupportRequestProcessingDto.getBuildingInfo();
				reqOomTechSupportRequestBuildingDto.setTenantId(tenantId);
				insertRow = oomTechSupportRequestBuildingMapper.createOomTechSupportRequestAddBuilding(reqOomTechSupportRequestBuildingDto);
			} else if (Const.Code.TECH_SUPPORT_REQ_TYPE_CD.BLD_MOD.equals(techSupportReqTypeCd) || Const.Code.TECH_SUPPORT_REQ_TYPE_CD.BLD_DEL.equals(techSupportReqTypeCd)) {
				OomTechSupportRequestBuildingDto reqOomTechSupportRequestBuildingDto = techSupportRequestProcessingDto.getBuildingInfo();
				reqOomTechSupportRequestBuildingDto.setTenantId(tenantId);
				insertRow = oomTechSupportRequestBuildingMapper.createOomTechSupportRequestModifyBuilding(reqOomTechSupportRequestBuildingDto);
			// 서비스변경요청 등록...
			} else if (Const.Code.TECH_SUPPORT_REQ_TYPE_CD.SVC_ADD.equals(techSupportReqTypeCd) || Const.Code.TECH_SUPPORT_REQ_TYPE_CD.SVC_DEL.equals(techSupportReqTypeCd)) {
				OomTechSupportRequestBuildingServiceDto reqOomTechSupportRequestBuildingServiceDto = techSupportRequestProcessingDto.getServiceInfo();
				reqOomTechSupportRequestBuildingServiceDto.setTenantId(tenantId);
				insertRow = oomTechSupportRequestBuildingServiceMapper.createOomTechSupportRequestBuildingService(reqOomTechSupportRequestBuildingServiceDto);
    		}
			affectRowCount = affectRowCount + insertRow;
			
		} catch (Exception e) {
			throw e;
		}
		
		return affectRowCount;
	}

}
