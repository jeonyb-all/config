package com.adtcaps.tsop.onm.api.helper.domain;

import lombok.Data;

/**
 * 
 * <ul>
 * <li>업무 그룹명 : tsop-onm-api</li>
 * <li>서브 업무명 : com.adtcaps.tsop.onm.api.helper.domain</li>
 * <li>설  명 : WeekMinMaxDateDto.java</li>
 * <li>작성일 : 2020. 11. 16.</li>
 * <li>작성자 : jeonyb4</li>
 * </ul>
 */
@Data
public class WeekMinMaxDateDto {
	private String startWeekDate;
	private String endWeekDate;

}
