package com.adtcaps.tsop.onm.api.alarm.domain;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

import lombok.Getter;
import lombok.Setter;

/**
 * 
 * <ul>
 * <li>업무 그룹명 : tsop-onm-api</li>
 * <li>서브 업무명 : com.adtcaps.tsop.onm.api.alarm.domain</li>
 * <li>설  명 : AlarmNoticeConditionDetailResultDto.java</li>
 * <li>작성일 : 2021. 1. 17.</li>
 * <li>작성자 : jeonyb4</li>
 * </ul>
 */
@Getter
@Setter
@JsonInclude(Include.NON_EMPTY)
public class AlarmNoticeConditionDetailResultDto {
	private String tenantId;
	private Integer alarmNoticeCondSeq;
	private String onmResourceCategoryCd;
	private String onmAlarmCd;
	private String onmAlarmGradeCd;
	private Integer alarmNoticeGroupId;
	private String msgContent;
	private String useYn;
	private String auditName;
	private String auditDatetime;
	
}
