package com.adtcaps.tsop.onm.api.support.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;

import com.adtcaps.tsop.onm.api.domain.OomTechSupportRequestDto;
import com.adtcaps.tsop.onm.api.support.domain.TechSupportRequestGridRequestDto;
import com.adtcaps.tsop.onm.api.support.domain.TechSupportRequestGridResultDto;
import com.adtcaps.tsop.onm.api.support.domain.TechSupportResultDetailResultDto;

/**
 * 
 * <ul>
 * <li>업무 그룹명 : tsop-onm-api</li>
 * <li>서브 업무명 : com.adtcaps.tsop.onm.api.support.mapper</li>
 * <li>설  명 : OomTechSupportRequestMapper.java</li>
 * <li>작성일 : 2021. 1. 2.</li>
 * <li>작성자 : jeonyb4</li>
 * </ul>
 */
@Mapper
public interface OomTechSupportRequestMapper {
	/**
	 * 
	 * listPageTechSupportRequest
	 *
	 * @param techSupportRequestGridRequestDto
	 * @return List<TechSupportRequestGridResultDto>
	 */
	public List<TechSupportRequestGridResultDto> listPageTechSupportRequest(TechSupportRequestGridRequestDto techSupportRequestGridRequestDto);
	
	/**
	 * 
	 * createOomTechSupportRequest
	 *
	 * @param reqOomTechSupportRequestDto
	 * @return int
	 */
	public int createOomTechSupportRequest(OomTechSupportRequestDto reqOomTechSupportRequestDto);
	
	/**
	 * 
	 * readOomTechSupportRequest
	 *
	 * @param reqOomTechSupportRequestDto
	 * @return TechSupportResultDetailResultDto
	 */
	public TechSupportResultDetailResultDto readOomTechSupportRequest(OomTechSupportRequestDto reqOomTechSupportRequestDto);
	
	/**
	 * 
	 * updateTechSupportStatus
	 *
	 * @param reqOomTechSupportRequestDto
	 * @return int
	 */
	public int updateTechSupportStatus(OomTechSupportRequestDto reqOomTechSupportRequestDto);

}
