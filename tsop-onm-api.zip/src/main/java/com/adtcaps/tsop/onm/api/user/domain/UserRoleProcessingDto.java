package com.adtcaps.tsop.onm.api.user.domain;

import java.util.List;

import com.adtcaps.tsop.onm.api.domain.OomUserRoleAuthorityDetailDto;
import com.adtcaps.tsop.onm.api.domain.OomUserRoleDto;

import lombok.Getter;
import lombok.Setter;

/**
 * 
 * <ul>
 * <li>업무 그룹명 : tsop-backend-api</li>
 * <li>서브 업무명 : com.adtcaps.tsop.portal.api.user.domain</li>
 * <li>설  명 : UserRoleProcessingDto.java</li>
 * <li>작성일 : 2020. 12. 24.</li>
 * <li>작성자 : jeonyb4</li>
 * </ul>
 */
@Getter
@Setter
public class UserRoleProcessingDto {
	private OomUserRoleDto roleInfo;
	private List<OomUserRoleAuthorityDetailDto> menuAuthList;

}
