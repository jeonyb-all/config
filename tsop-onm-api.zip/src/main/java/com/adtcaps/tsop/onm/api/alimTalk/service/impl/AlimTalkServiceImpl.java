package com.adtcaps.tsop.onm.api.alimTalk.service.impl;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.TimeUnit;

import org.apache.commons.lang3.StringUtils;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.util.EntityUtils;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.CollectionUtils;

import com.adtcaps.tsop.onm.api.alimTalk.domain.AlimTalkBatchResultDto;
import com.adtcaps.tsop.onm.api.alimTalk.domain.AlimTalkDetailDto;
import com.adtcaps.tsop.onm.api.alimTalk.domain.AlimTalkRequestDto;
import com.adtcaps.tsop.onm.api.alimTalk.domain.AlimTalkResponseDto;
import com.adtcaps.tsop.onm.api.alimTalk.domain.AlimTalkResultDto;
import com.adtcaps.tsop.onm.api.alimTalk.mapper.OomKakaoAlimTalkMapper;
import com.adtcaps.tsop.onm.api.alimTalk.mapper.OomKakaoSendHistMapper;
import com.adtcaps.tsop.onm.api.alimTalk.mapper.OomKakaoTokenMapper;
import com.adtcaps.tsop.onm.api.alimTalk.service.AlimTalkService;
import com.adtcaps.tsop.onm.api.config.TenantConfig;
import com.adtcaps.tsop.onm.api.domain.OomKakaoAlimTalkDto;
import com.adtcaps.tsop.onm.api.domain.OomKakaoSendHistDto;
import com.adtcaps.tsop.onm.api.domain.OomKakaoTokenDto;
import com.adtcaps.tsop.onm.api.domain.OomSmsHistDetailDto;
import com.adtcaps.tsop.onm.api.domain.OomSmsHistDto;
import com.adtcaps.tsop.onm.api.helper.constant.Const;
import com.adtcaps.tsop.onm.api.helper.domain.ResultDto;
import com.adtcaps.tsop.onm.api.helper.util.CommonObjectUtil;
import com.adtcaps.tsop.onm.api.send.mapper.OomSmsHistDetailMapper;
import com.adtcaps.tsop.onm.api.send.mapper.OomSmsHistMapper;
import com.adtcaps.tsop.onm.api.sms.domain.SmsApiResponse;
import com.adtcaps.tsop.onm.api.sms.service.SmsService;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.squareup.okhttp.MediaType;
import com.squareup.okhttp.OkHttpClient;
import com.squareup.okhttp.Request;
import com.squareup.okhttp.RequestBody;
import com.squareup.okhttp.Response;

@Transactional
@Service
public class AlimTalkServiceImpl implements AlimTalkService {
	@Autowired
	private OomKakaoTokenMapper oomKakaoTokenMapper;

	@Autowired
    private OomKakaoAlimTalkMapper oomKakaoAlimTalkMapper;

	@Autowired
	private OomSmsHistMapper oomSmsHistMapper;

	@Autowired
	private OomKakaoSendHistMapper oomKakaoSendHistMapper;

	@Autowired
	private OomSmsHistDetailMapper oomSmsHistDetailMapper;

	@Autowired
    private SmsService smsService;

	private static final Logger LOGGER = LoggerFactory.getLogger(AlimTalkServiceImpl.class);

	private final String ALIM_TALK_TOKEN_FAIL = "알림톡 토큰 오류";
	private final String ALIM_TALK_RETURN_CD_FAIL = "00";
	private final String ALIM_TALK_RETURN_MSG_FAIL = "알림톡 발송에 실패하였습니다. 잠시 후 다시 시도해주세요";
	private final String ALIM_TALK_BATCH_LIMIT_ERROR = "1회 최대 500건까지 발송할 수 있습니다.";
	//private final String ALIM_TALK_GET_RESULT_ERROR = "알림톡 수신결과 오류";

	@Value("${alim-talk.use_yn}")
	private String useYn;

	@Value("${alim-talk.token-api}")
	private String tokenApi;

	@Value("${alim-talk.send-api}")
	private String sendApi;

	@Value("${alim-talk.batch-send-api}")
	private String batchSendApi;

	@Value("${alim-talk.result-api}")
	private String resultApi;

	@Value("${alim-talk.bsid}")
	private String bsid;

	@Value("${alim-talk.passwd}")
	private String passwd;

	@Value("${alim-talk.sender-key}")
	private String senderKey;

	@Autowired
	private TenantConfig tenantConfig;

	/**
	 *
	 * sendOnmAlimTalk
	 *
	 * @param alimTalkRequestDto
	 * @return String
	 * @throws Exception
	 */
	@Override
	public String sendOnmAlimTalk(AlimTalkRequestDto alimTalkRequestDto) throws Exception {
		String alarmNoticeResultCd = "";
		try {
			String tenantId = StringUtils.defaultString(alimTalkRequestDto.getTenantId());
			String tmpltCode = alimTalkRequestDto.getTmpltCode();
			String smsCreateCd = StringUtils.defaultString(alimTalkRequestDto.getSmsCreateCd());
			String recipient = alimTalkRequestDto.getRecipient();
			String message = alimTalkRequestDto.getMessage();
			String msgIdx = "";

			if ("".equals(tmpltCode) || "".equals(recipient) || "".equals(message)) {
				alarmNoticeResultCd = "9";
				return alarmNoticeResultCd;
			}

			OomKakaoAlimTalkDto reqOomKakaoAlimTalkDto = new OomKakaoAlimTalkDto();
			reqOomKakaoAlimTalkDto.setTmpltCode(tmpltCode);
			reqOomKakaoAlimTalkDto.setSmsCreateCd(smsCreateCd);
			OomKakaoAlimTalkDto oomKakaoAlimTalkDto = oomKakaoAlimTalkMapper.readKakaoAlimTalk(reqOomKakaoAlimTalkDto);

			AlimTalkRequestDto sendAlimTalkRequestDto = new AlimTalkRequestDto();

			if (oomKakaoAlimTalkDto.getAttach() != null && oomKakaoAlimTalkDto.getAttachName() != null) {
				sendAlimTalkRequestDto.setAttach(oomKakaoAlimTalkDto.getAttach());
				sendAlimTalkRequestDto.setAttachName(oomKakaoAlimTalkDto.getAttachName());
			}

			sendAlimTalkRequestDto.setRecipient(recipient);
			sendAlimTalkRequestDto.setTmpltCode(tmpltCode);
			sendAlimTalkRequestDto.setMessage(message);

			for (AlimTalkDetailDto alimTalkDetailDto : alimTalkRequestDto.getDetailList()) {
				msgIdx = UUID.randomUUID().toString().replaceAll("-", "");
				alimTalkDetailDto.setMsgIdx(msgIdx);
			}

			sendAlimTalkRequestDto.setDetailList(alimTalkRequestDto.getDetailList());

			// 알림톡 발송...
			AlimTalkBatchResultDto alimTalkBatchResultDto = sendAlimTalk(sendAlimTalkRequestDto);

			String responseCode = alimTalkBatchResultDto.getResponseCode();
			//LOGGER.error("AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA : {}", responseCode);

			if ("1000".equals(responseCode)) {
				// 알림톡 발송 성공
				String auditId = StringUtils.defaultString(alimTalkRequestDto.getAuditId());

				String sender = alimTalkBatchResultDto.getSender();
				if ("sms".equals(sender)) {
					alarmNoticeResultCd = Const.Code.ALARM_NOTICE_RESULT_CD.SMS;
				} else if ("alimtalk".equals(sender)) {
					alarmNoticeResultCd = Const.Code.ALARM_NOTICE_RESULT_CD.ALIMTALK;
				}

				if (!smsCreateCd.equals(Const.Code.SMS_CREATE_CD.AUTH) && !smsCreateCd.equals(Const.Code.SMS_CREATE_CD.PASSWORD)) {
					// 발송내역 등록...
					OomSmsHistDto reqOomSmsHistDto = new OomSmsHistDto();
					reqOomSmsHistDto.setSmsCreateCd(alimTalkRequestDto.getSmsCreateCd());
					reqOomSmsHistDto.setAlarmNoticeGroupId(alimTalkRequestDto.getAlarmNoticeGroupId());
					reqOomSmsHistDto.setBulletinTypeCd(alimTalkRequestDto.getBulletinTypeCd());
					reqOomSmsHistDto.setBulletinNum(alimTalkRequestDto.getBulletinNum());
					reqOomSmsHistDto.setAuditId(alimTalkRequestDto.getAuditId());
					reqOomSmsHistDto.setMsgContent(alimTalkRequestDto.getMessage());
					reqOomSmsHistDto.setAlarmNoticeResultCd(alarmNoticeResultCd);
					reqOomSmsHistDto.setTenantId(tenantId);
					reqOomSmsHistDto.setTmpltCode(tmpltCode);
					oomSmsHistMapper.createOomSmsHist(reqOomSmsHistDto);

					// 발송내역 상세 등록...
					int smsTransSeq = CommonObjectUtil.defaultNumber(reqOomSmsHistDto.getSmsTransSeq());
					for (AlimTalkDetailDto alimTalkDetailDto : alimTalkRequestDto.getDetailList()) {
						String rcverId = StringUtils.defaultString(alimTalkDetailDto.getRcverId());
						String rcverName = StringUtils.defaultString(alimTalkDetailDto.getRcverName());
						String rcvPhoneNum = StringUtils.defaultString(alimTalkDetailDto.getRcvPhoneNum());

						OomSmsHistDetailDto oomSmsHistDetailDto = new OomSmsHistDetailDto();
						oomSmsHistDetailDto.setSmsTransSeq(smsTransSeq);
						oomSmsHistDetailDto.setRcverId(rcverId);
						oomSmsHistDetailDto.setRcverName(rcverName);
						oomSmsHistDetailDto.setRcvPhoneNum(rcvPhoneNum);
						oomSmsHistDetailDto.setTenantId(tenantId);
						oomSmsHistDetailDto.setAuditId(auditId);
						oomSmsHistDetailDto.setMsgIdx(alimTalkDetailDto.getMsgIdx());
						oomSmsHistDetailMapper.createOomSmsHistDetail(oomSmsHistDetailDto);
					}
				}

			} else {
				alarmNoticeResultCd = Const.Code.ALARM_NOTICE_RESULT_CD.FAIL;
			}

			if (Const.Code.ALARM_NOTICE_RESULT_CD.SMS.equals(alarmNoticeResultCd) || Const.Code.ALARM_NOTICE_RESULT_CD.ALIMTALK.equals(alarmNoticeResultCd) ) {
				alarmNoticeResultCd = Const.Code.ALARM_NOTICE_RESULT_CD.SMS;
			}

		} catch (Exception e) {
			throw e;
		}

		return alarmNoticeResultCd;
	}

	/**
	 * sendAlimTalk
	 * @param alimTalkRequestDto
	 * @return AlimTalkBatchResultDto
	 * @throws Exception
	 */
	@Override
	public AlimTalkBatchResultDto sendAlimTalk(AlimTalkRequestDto alimTalkRequestDto) throws Exception {
		try {
			SimpleDateFormat dateFormat = new SimpleDateFormat("yyyyMMddHHmmss");
			Date time = new Date();
			String transDatetime = dateFormat.format(time);

			for (AlimTalkDetailDto alimTalkDetailDto: alimTalkRequestDto.getDetailList()) {
				OomKakaoSendHistDto oomKakaoSendHistDto = new OomKakaoSendHistDto();
				oomKakaoSendHistDto.setMsgIdx(alimTalkDetailDto.getMsgIdx());
				oomKakaoSendHistDto.setTransDatetime(transDatetime);
				oomKakaoSendHistDto.setRcvPhoneNum(alimTalkDetailDto.getRcvPhoneNum().replaceAll("-", ""));
				oomKakaoSendHistDto.setMsgContent(StringUtils.defaultString(alimTalkRequestDto.getMessage()));
				oomKakaoSendHistDto.setTenantName(alimTalkRequestDto.getTenantName());
				oomKakaoSendHistMapper.createOomKakaoSendHist(oomKakaoSendHistDto);
			}

			if (useYn.equals("Y")) {
				String btToken = getToken();
				if (!btToken.equals("")) {
					/*String recipient = CommonObjectUtil.duplicateRecvNoCheck(alimTalkRequestDto.getRecipient());
					String[] recipientList = recipient.split(",");
					JsonArray jsonArray = new JsonArray();

					if (recipientList.length > 500) {
						LOGGER.error("SEND ALIMTALK EXCEPTION : {}", ALIM_TALK_BATCH_LIMIT_ERROR);
						return makeErrAlimTalkApiResponse();
					}*/

					if (alimTalkRequestDto.getDetailList().size() > 500) {
						LOGGER.error("SEND ALIMTALK EXCEPTION : {}", ALIM_TALK_BATCH_LIMIT_ERROR);
						return makeErrAlimTalkApiResponse();
					}

					JsonArray jsonArray = new JsonArray();
					JsonArray buttons = new JsonArray();

					if (alimTalkRequestDto.getAttach() != null && alimTalkRequestDto.getAttachName() != null) {
						JsonObject button = new JsonObject();
						button.addProperty("name", alimTalkRequestDto.getAttachName());
						button.addProperty("type", "WL");
						button.addProperty("url_mobile", alimTalkRequestDto.getAttach());
						button.addProperty("url_pc", alimTalkRequestDto.getAttach());
						buttons.add(button);
					}

					for (AlimTalkDetailDto alimTalkDetailDto: alimTalkRequestDto.getDetailList()) {
						JsonObject jsonObject = new JsonObject();
						jsonObject.addProperty("msgIdx", alimTalkDetailDto.getMsgIdx());
						jsonObject.addProperty("countryCode", "82");
						jsonObject.addProperty("recipient", alimTalkDetailDto.getRcvPhoneNum().replaceAll("-", ""));
						jsonObject.addProperty("senderKey", senderKey);
						jsonObject.addProperty("message", StringUtils.defaultString(alimTalkRequestDto.getMessage()));
						jsonObject.addProperty("tmpltCode", StringUtils.defaultString(alimTalkRequestDto.getTmpltCode()));
						jsonObject.addProperty("resMethod", "PUSH");

						if (alimTalkRequestDto.getAttach() != null && alimTalkRequestDto.getAttachName() != null) {
							JsonObject addBtn = new JsonObject();
							addBtn.add("button", buttons);
							jsonObject.add("attach", addBtn);
						}

						jsonArray.add(jsonObject);
					}

					JsonObject alimTalkJson = new JsonObject();
					alimTalkJson.add("msgList", jsonArray);

					String apiResult = postBgmsApi(alimTalkJson, batchSendApi, btToken);

					/*LOGGER.error("### apiResult : {}", apiResult);*/

					JSONParser parser = new JSONParser();
					Object resultObj = parser.parse(apiResult);
					JSONObject sendObj = (JSONObject)resultObj;

					String responseCode = (String)sendObj.get("responseCode");

					if ("1000".equals(responseCode)) {
						return processAlimTalkResult(apiResult, sendObj);
					} else if ("B199".equals(responseCode)) {
						//토큰 재발급
						btToken = requestToken();
						apiResult = postBgmsApi(alimTalkJson, batchSendApi, btToken);
						resultObj = parser.parse(apiResult);
						sendObj = (JSONObject)resultObj;
						responseCode = (String)sendObj.get("responseCode");
						if ("1000".equals(responseCode)) {
							return processAlimTalkResult(apiResult, sendObj);
						} else {
							return sendSms(alimTalkRequestDto);
						}
					} else {
						return sendSms(alimTalkRequestDto);
					}
				} else {
					return sendSms(alimTalkRequestDto);
				}
			} else {
				//sms
				return sendSms(alimTalkRequestDto);
			}
		} catch (Exception e) {
			LOGGER.error("### SEND ALIMTALK EXCEPTION : {}", e);
			//sms
			//return sendSms(alimTalkRequestDto);
			return makeErrAlimTalkApiResponse();
		}
	}

	private AlimTalkBatchResultDto processAlimTalkResult(String apiResult, JSONObject sendObj) throws Exception {
		AlimTalkBatchResultDto alimTalkBatchResultDto = new AlimTalkBatchResultDto();
		List<AlimTalkResponseDto> msgList = new ArrayList<AlimTalkResponseDto>();

		alimTalkBatchResultDto.setResponseCode((String)sendObj.get("responseCode"));
		alimTalkBatchResultDto.setMsg((String)sendObj.get("msg"));

		//발송요청리스트
		JSONArray responseJsonArray = (JSONArray)sendObj.get("msgList");

		for (Object jsonMsg : responseJsonArray) {
			JSONObject msg = (JSONObject)jsonMsg;
			AlimTalkResponseDto alimTalkResponseDto = new AlimTalkResponseDto();
			alimTalkResponseDto.setMsgIdx((String)msg.get("msgIdx"));
			alimTalkResponseDto.setResponseCode((String)msg.get("responseCode"));
			msgList.add(alimTalkResponseDto);
		}

		alimTalkBatchResultDto.setResponseCode((String)sendObj.get("responseCode"));
		alimTalkBatchResultDto.setMsg((String)sendObj.get("responseCode"));
		alimTalkBatchResultDto.setMsgList(msgList);
		alimTalkBatchResultDto.setSender("alimtalk");

		return alimTalkBatchResultDto;
	}

	@Override
	public void getAlimTalkResult() throws Exception {
		SimpleDateFormat dateFormat = new SimpleDateFormat("yyyyMMddHHmmss");
		Date time = new Date();
		String toDate = dateFormat.format(time);
		Calendar cal = Calendar.getInstance();
		cal.setTime(time);
		cal.add(Calendar.HOUR, -10);
		String fromDate = dateFormat.format(cal.getTime());

		OomKakaoSendHistDto reqOomKakaoSendHistDto = new OomKakaoSendHistDto();
		reqOomKakaoSendHistDto.setFromDate(fromDate);
		reqOomKakaoSendHistDto.setToDate(toDate);

		try {
			/* 알림톡 전송 결과 업데이트 */
			int chkCnt = oomKakaoSendHistMapper.readRequestResultCnt(reqOomKakaoSendHistDto);
			//LOGGER.debug("### alimtalk result check count : {}", chkCnt);
			if (chkCnt > 0) {
				String btToken = getToken();
				int updateCnt = 0;
				if (!btToken.equals("")) {
					String apiResult = getBgmsApi(resultApi, btToken);
					JSONParser parser = new JSONParser();
					Object resultObj = parser.parse(apiResult);
					resultObj = parser.parse(apiResult);
					JSONObject kakaoResultObj = (JSONObject)resultObj;

					if ("1000".equals((String)kakaoResultObj.get("responseCode"))) {
						//발송결과리스트
						JSONArray resultJsonArray = (JSONArray)kakaoResultObj.get("response");

						for (Object jsonResult : resultJsonArray) {
							JSONObject rslt = (JSONObject)jsonResult;
							OomKakaoSendHistDto oomKakaoSendHistDto = new OomKakaoSendHistDto();
							oomKakaoSendHistDto.setMsgIdx((String)rslt.get("msgIdx"));
							oomKakaoSendHistDto.setResultCode((String)rslt.get("resultCode"));
							oomKakaoSendHistDto.setReceivedAt((String)rslt.get("receivedAt"));
							oomKakaoSendHistDto.setRequestAt((String)rslt.get("requestAt"));
							oomKakaoSendHistDto.setSender(Const.Definition.MSG_SENDER_CODE.ALIMTALK);
							updateCnt = updateCnt + oomKakaoSendHistMapper.updateOomKakaoSendHist(oomKakaoSendHistDto);
						}
					}
					//LOGGER.debug("### alimtalk result update : {}", updateCnt);
				} else {
					LOGGER.error("### ALIMTALK EXCEPTION : {}", ALIM_TALK_TOKEN_FAIL);
				}
			}
		} catch (Exception e) {
			LOGGER.error("### EXCEPTION : {}", e);
		}

		/* sms 재전송건 조회 */
		try {
			List<OomKakaoSendHistDto> resendSmsList = oomKakaoSendHistMapper.listResendSms(reqOomKakaoSendHistDto);
			//LOGGER.debug("### reSend SMS : {}", resendSmsList.size());
			if (resendSmsList.size() > 0) {
				int resendSmsCnt = 0;
				for (OomKakaoSendHistDto resendSms : resendSmsList) {
					Map<String, Object> smsContent = new HashMap<>();
					smsContent.put("recv_no", resendSms.getRcvPhoneNum());
					smsContent.put("msg", resendSms.getMsgContent());
					SmsApiResponse resSmsApiResponse = smsService.sendSms(smsContent);

					OomKakaoSendHistDto oomKakaoSendHistDto = new OomKakaoSendHistDto();
					oomKakaoSendHistDto.setMsgIdx(resendSms.getMsgIdx());
					oomKakaoSendHistDto.setResultCode(resSmsApiResponse.getReturnCode());
					oomKakaoSendHistDto.setSender(Const.Definition.MSG_SENDER_CODE.SMS);
					resendSmsCnt = resendSmsCnt + oomKakaoSendHistMapper.updateOomKakaoSendHist(oomKakaoSendHistDto);
				}
			}
		} catch (Exception e) {
			LOGGER.error("### EXCEPTION : {}", e);
		}

		/* 전송결과미전송건조회 */
		/**
		 * 추후 테넌트별 조회 필요.
		 * ONM application.yml  tenant.skt
		 */
		int resultSendCnt = 0;
		reqOomKakaoSendHistDto.setTenantName("skt");
		List<OomKakaoSendHistDto> resendResultList = oomKakaoSendHistMapper.listAlimTalkResult(reqOomKakaoSendHistDto);
		if (resendResultList.size() > 0) {
			Gson gson = new Gson();
			String resultJsonString = gson.toJson(resendResultList);
			OkHttpClient client = new OkHttpClient();
			client.setConnectTimeout(30, TimeUnit.SECONDS);
			StringBuilder urlBuilder = new StringBuilder();
			urlBuilder.append(tenantConfig.getTenantSktConfig().getUrl());
			urlBuilder.append("/api/portal/alimTalk/set-alimtalk-result");
			Request request = new Request.Builder()
					.addHeader("Call-Key", tenantConfig.getTenantSktConfig().getKey())
					.url(urlBuilder.toString())
    	            .post(RequestBody.create(MediaType.parse(org.springframework.http.MediaType.APPLICATION_JSON.toString()), resultJsonString))
    	            .build();
			Response response = null;

			try {
    	    	response = client.newCall(request).execute();
    	    	String responseJsonString = StringUtils.defaultString(response.body().string());
    	    	if (!"".equals(responseJsonString)) {
    	    		JsonObject responseJsonObject;
    	    		responseJsonObject = JsonParser.parseString(responseJsonString).getAsJsonObject();
    	    		ObjectMapper objectMapper = new ObjectMapper();
    				ResultDto resultDto = objectMapper.readValue(responseJsonObject.toString(), ResultDto.class);
    				String resultCode = StringUtils.defaultString(resultDto.getResultCode());
    				if (Const.Common.RESULT_CODE.SUCCESS.equals(resultCode)) {
        	    		for (OomKakaoSendHistDto sendResultDto : resendResultList) {
            	    		OomKakaoSendHistDto oomKakaoSendHistDto = new OomKakaoSendHistDto();
            	    		oomKakaoSendHistDto.setMsgIdx(sendResultDto.getMsgIdx());
            	    		oomKakaoSendHistDto.setResultCode(sendResultDto.getResultCode());
            	    		oomKakaoSendHistDto.setResultSendYn("Y");
            	    		resultSendCnt = resultSendCnt + oomKakaoSendHistMapper.updateOomKakaoSendHist(oomKakaoSendHistDto);
            	    	}
        	    	}
    	    	}

    	    	LOGGER.debug("### send {}", resultSendCnt);
    	    } catch (Exception e) {
    	    	LOGGER.error("### EXCEPTION : {}", e);
    		}
		}

		/* OOM_SMS_HIST_DETAIL Update */
		OomKakaoSendHistDto onmOomKakaoSendHistDto = new OomKakaoSendHistDto();
		onmOomKakaoSendHistDto.setFromDate(fromDate);
		onmOomKakaoSendHistDto.setToDate(toDate);
		List<OomKakaoSendHistDto> onmResultList = oomKakaoSendHistMapper.listAlimTalkResult(onmOomKakaoSendHistDto);
		if (onmResultList.size() > 0) {
			for (OomKakaoSendHistDto onmResult : onmResultList) {
				OomSmsHistDetailDto oomSmsHistDetailDto = new OomSmsHistDetailDto();
				oomSmsHistDetailDto.setResultCode(onmResult.getResultCode());
				oomSmsHistDetailDto.setSender(onmResult.getSender());
				oomSmsHistDetailDto.setMsgIdx(onmResult.getMsgIdx());
				oomSmsHistDetailMapper.updateSmsHistDetail(oomSmsHistDetailDto);

				OomKakaoSendHistDto oomKakaoSendHistDto = new OomKakaoSendHistDto();
				oomKakaoSendHistDto.setMsgIdx(onmResult.getMsgIdx());
				oomKakaoSendHistDto.setResultSendYn("Y");
				oomKakaoSendHistDto.setResultCode(onmResult.getResultCode());
				oomKakaoSendHistMapper.updateOomKakaoSendHist(oomKakaoSendHistDto);
			}
		}

		/* 완료건삭제 */
		try {
			int deleteCnt = oomKakaoSendHistMapper.deleteOomKakaoSendHist(fromDate);
			LOGGER.debug("### deleteCnt : {}", deleteCnt);
		} catch (Exception e) {
			LOGGER.error("### EXCEPTION : {}", e);
		}
	}

	private AlimTalkBatchResultDto makeErrAlimTalkApiResponse() {
		AlimTalkBatchResultDto alimTalkBatchResultDto = new AlimTalkBatchResultDto();
		alimTalkBatchResultDto.setResponseCode(ALIM_TALK_RETURN_CD_FAIL);
		alimTalkBatchResultDto.setMsg(ALIM_TALK_RETURN_MSG_FAIL);
		return alimTalkBatchResultDto;
    }

	/**
	 * sendSms
	 * @param alimTalkRequestDto
	 * @return AlimTalkBatchResultDto
	 * @throws Exception
	 */
	private AlimTalkBatchResultDto sendSms(AlimTalkRequestDto alimTalkRequestDto) throws Exception {
		//sms
		Map<String, Object> smsContent = new HashMap<>();
		smsContent.put("recv_no", alimTalkRequestDto.getRecipient());
		smsContent.put("msg", alimTalkRequestDto.getMessage());
		SmsApiResponse resSmsApiResponse = smsService.sendSms(smsContent);

		String returnCode = resSmsApiResponse.getReturnCode();

		if ("01".equals(returnCode)) {
			//SMS 발송성공
			returnCode = "1000";
		}

		AlimTalkBatchResultDto alimTalkBatchResultDto = new AlimTalkBatchResultDto();
		alimTalkBatchResultDto.setSender("sms");
		alimTalkBatchResultDto.setResponseCode(returnCode);

		List<AlimTalkResultDto> resultList = new ArrayList<AlimTalkResultDto>();
		for (AlimTalkDetailDto alimTalkDetailDto: alimTalkRequestDto.getDetailList()) {
			AlimTalkResultDto alimTalkResultDto = new AlimTalkResultDto();
			alimTalkResultDto.setMsgIdx(alimTalkDetailDto.getMsgIdx());
			alimTalkResultDto.setResultCode(resSmsApiResponse.getReturnCode());
			resultList.add(alimTalkResultDto);

			OomKakaoSendHistDto oomKakaoSendHistDto = new OomKakaoSendHistDto();
			oomKakaoSendHistDto.setMsgIdx(alimTalkDetailDto.getMsgIdx());
			oomKakaoSendHistDto.setResultCode(resSmsApiResponse.getReturnCode());
			oomKakaoSendHistMapper.updateOomKakaoSendHist(oomKakaoSendHistDto);
		}

		List<AlimTalkResponseDto> msgList = new ArrayList<AlimTalkResponseDto>();

		for (AlimTalkDetailDto alimTalkDetailDto: alimTalkRequestDto.getDetailList()) {
			AlimTalkResponseDto alimTalkResponseDto = new AlimTalkResponseDto();
			alimTalkResponseDto.setMsgIdx(alimTalkDetailDto.getMsgIdx());
			alimTalkResponseDto.setResponseCode(resSmsApiResponse.getReturnCode());
			msgList.add(alimTalkResponseDto);
		}

		alimTalkBatchResultDto.setSender("sms");
		alimTalkBatchResultDto.setMsgList(msgList);

		return alimTalkBatchResultDto;
	}

	/**
	 * getToken : 토큰조회
	 * @return String
	 */
	private String getToken() {
		String btToken = "";
		try {
			List<OomKakaoTokenDto> oomKakaoTokenDtoList = oomKakaoTokenMapper.listOomKakaoToken();
			if (CollectionUtils.isEmpty(oomKakaoTokenDtoList)) {
				String apiResult = requestToken();
				if (!apiResult.equals("")) {
					btToken = saveToken(apiResult, false);
				}
			} else {
				OomKakaoTokenDto oomKakaoTokenDto = oomKakaoTokenDtoList.get(0);
				if (oomKakaoTokenDto.getTokenExpire().equals("EXPIRED")) {
					String apiResult = requestToken();
					if (!apiResult.equals("")) {
						btToken = saveToken(apiResult, true);
					}
				} else {
					btToken = oomKakaoTokenDto.getToken();
				}
			}
		} catch (Exception e) {
			LOGGER.error("ALIMTALK GET TOKEN EXCEPTION : {}", e);
		}
		return btToken;
	}

	/**
	 * requestToken : 토큰요청
	 * @return String
	 */
	private String requestToken() {
		String apiResult = "";
		try {
			JsonObject jsonObject = new JsonObject();
			jsonObject.addProperty("bsid", bsid);
			jsonObject.addProperty("passwd", passwd);
			apiResult = postBgmsApi(jsonObject, tokenApi, "");
		} catch (Exception e) {
			LOGGER.error("ALIMTALK REQUEST TOKEN EXCEPTION : {}", e);
		}
		return apiResult;
	}

	/**
	 * saveToken : 토큰저장
	 * @param apiResult
	 * @param update
	 * @return String
	 */
	private String saveToken(String apiResult, boolean update) {
		String btToken = "";
		try {
			JSONParser parser = new JSONParser();
			Object resultObj = parser.parse(apiResult);
			JSONObject tokenObj = (JSONObject)resultObj;
			String responseCode = (String)tokenObj.get("responseCode");
			OomKakaoTokenDto oomKakaoTokenDto = new OomKakaoTokenDto();
			oomKakaoTokenDto.setBgmsResponseCode(responseCode);
			if (responseCode.equals("1000")) {
				btToken = (String)tokenObj.get("token");
				oomKakaoTokenDto.setToken(btToken);
				oomKakaoTokenDto.setBgmsResponseMsg("SUCCESS");
			} else {
				oomKakaoTokenDto.setBgmsResponseMsg((String)tokenObj.get("msg"));
			}

			if (update) {
				oomKakaoTokenMapper.updateOomKakaoToken(oomKakaoTokenDto);
			} else {
				oomKakaoTokenMapper.createOomKakaoToken(oomKakaoTokenDto);
			}
		} catch (Exception e) {
			LOGGER.error("ALIMTALK SAVE TOKEN EXCEPTION : {}", e);
		}
		return btToken;
	}

	/**
	 * postBgmsApi : BGMS API 호출
	 * @param jsonObject
	 * @param apiUrl
	 * @param btToken
	 * @return String
	 * @throws IOException
	 */
	private String postBgmsApi(JsonObject jsonObject, String apiUrl, String btToken) throws IOException {
		String apiResult = "";
		CloseableHttpClient httpClient = null;
		try {
			httpClient = HttpClients.createDefault();
			HttpPost httpPost = new HttpPost(apiUrl);
			httpPost.setEntity(new StringEntity(String.valueOf(jsonObject), "UTF-8"));
			httpPost.addHeader("Content-type", "application/json");
			httpPost.addHeader("x-use-proxy", "Y");

			if (!btToken.equals("")) {
				httpPost.addHeader("bt-token", btToken);
			}

			CloseableHttpResponse response = httpClient.execute(httpPost);
			apiResult = EntityUtils.toString(response.getEntity());
			//LOGGER.debug("### apiResult {}", apiResult);
		} catch (Exception e) {
			apiResult = "ERROR";
			LOGGER.error("ALIMTALK_API Url : {}", apiUrl);
			LOGGER.error("ALIMTALK_API Param : {}", jsonObject.toString());
			LOGGER.error("ALIMTALK_API Exception : {}", e);
		} finally {
			if (httpClient != null) httpClient.close();
		}
		return apiResult;
	}

	/**
	 * getBgmsApi
	 * @param apiUrl
	 * @param btToken
	 * @return String
	 * @throws IOException
	 */
	private String getBgmsApi(String apiUrl, String btToken) throws IOException {
		String apiResult = "";
		CloseableHttpClient httpClient = null;
		try {
			httpClient = HttpClients.createDefault();
			HttpGet httpGet = new HttpGet(apiUrl);
			httpGet.addHeader("Content-type", "application/json");

			if (!btToken.equals("")) {
				httpGet.addHeader("bt-token", btToken);
			}

			CloseableHttpResponse response = httpClient.execute(httpGet);
			apiResult = EntityUtils.toString(response.getEntity());
			LOGGER.debug("### apiResult {}", apiResult);
		} catch (Exception e) {
			apiResult = "ERROR";
			LOGGER.error("ALIMTALK_API Url : {}", apiUrl);
			LOGGER.error("ALIMTALK_API Exception : {}", e);
		} finally {
			if (httpClient != null) httpClient.close();
		}
		return apiResult;
	}
}