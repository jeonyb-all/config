package com.adtcaps.tsop.onm.api.fault.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.util.CollectionUtils;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.adtcaps.tsop.onm.api.authentication.domain.JwtAuthResultDto;
import com.adtcaps.tsop.onm.api.domain.OomFaultActionDto;
import com.adtcaps.tsop.onm.api.domain.OomUserRoleAuthorityDetailDto;
import com.adtcaps.tsop.onm.api.fault.domain.FaultActionGridResultDto;
import com.adtcaps.tsop.onm.api.fault.domain.FaultActionProcessingDto;
import com.adtcaps.tsop.onm.api.fault.service.FaultActionService;
import com.adtcaps.tsop.onm.api.file.domain.BlobRequestDto;
import com.adtcaps.tsop.onm.api.helper.constant.Const;
import com.adtcaps.tsop.onm.api.helper.domain.ResultDto;
import com.adtcaps.tsop.onm.api.helper.util.CommonObjectUtil;
import com.adtcaps.tsop.onm.api.user.domain.UserRoleMenuAuthorityRequestDto;
import com.adtcaps.tsop.onm.api.user.service.UserRoleService;

import lombok.extern.slf4j.Slf4j;

/**
 * 
 * <ul>
 * <li>업무 그룹명 : tsop-onm-api</li>
 * <li>서브 업무명 : com.adtcaps.tsop.onm.api.fault.controller</li>
 * <li>설  명 : FaultActionController.java</li>
 * <li>작성일 : 2021. 1. 18.</li>
 * <li>작성자 : jeonyb4</li>
 * </ul>
 */
@Slf4j
@RestController
@RequestMapping("/api/fault-actions")
public class FaultActionController {
	
	private final String MENU_ID = "ONM0010";
	
	private final String ERR_MSG_NULL_LOGIN_USER_ID = "로그인 사용자ID가 없습니다.";
	private final String ERR_MSG_NULL_MGR_YN = "관리자여부가 없습니다.";
	private final String ERR_MSG_NULL_FAULT_ID = "장애ID가 없습니다.";
	private final String ERR_MSG_NULL_AUDIT_ID = "최종수정자ID가 없습니다.";
	private final String ERR_MSG_NULL_FAULT_ACTION_INFO = "장애조치내역 등록정보가 없습니다.";
	private final String ERR_MSG_NULL_LOCAL_FILE_PATH = "로컬파일경로가 없습니다.";
	
	private final String ERR_MSG_NULL_CANNOT_DELETE = "현재 사용자는 최종수정자와 다르므로 삭제할 수 없습니다.";
	
	private final String ERR_MSG_NO_AUTH = "권한이 없는 사용자 입니다.";
	private final String ERR_MSG_ATTACH_FILE_DELETE_FAIL = "첨부파일 삭제에 실패하였습니다.";
	private final String ERR_MSG_NULL_SEARCH_RESULT_LIST = "조회 결과가 없습니다.";
	private final String ERR_MSG_CREATE_FAIL = "등록에 실패하였습니다.";
	private final String ERR_MSG_DELETE_FAIL = "삭제에 실패하였습니다.";
	
	@Autowired
	private FaultActionService faultActionService;
	
	@Autowired
	private UserRoleService userRoleService;
	
	/**
	 * 
	 * listFaultAction
	 *
	 * @param reqOomFaultActionDto
	 * @return ResponseEntity
	 */
	@SuppressWarnings("rawtypes")
    @GetMapping(value="", produces="application/json; charset=UTF-8")
    public ResponseEntity listFaultAction(OomFaultActionDto reqOomFaultActionDto) throws Exception {
        
    	ResponseEntity<ResultDto> resEntity = null;
		String returnString = "";
    	
		int onmFaultId = CommonObjectUtil.defaultNumber(reqOomFaultActionDto.getOnmFaultId());
		if (onmFaultId < 1) {
			log.error(">>>>>> onmFaultId ERROR:{}", ERR_MSG_NULL_FAULT_ID);
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_FAULT_ID));
			return resEntity;
		}
		// 장애조치내역 목록조회....
		Map<String, Object> faultActionGridResultDtoListMap = new HashMap<String, Object>();
		List<FaultActionGridResultDto> faultActionGridResultDtoList = faultActionService.listFaultAction(reqOomFaultActionDto);
		if (CollectionUtils.isEmpty(faultActionGridResultDtoList)) {
			returnString = Const.Common.RESULT_CODE.SUCCESS;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_SEARCH_RESULT_LIST, faultActionGridResultDtoListMap));
		} else {
			returnString = Const.Common.RESULT_CODE.SUCCESS;
			int totalCount = faultActionGridResultDtoList.size();
			Map<String, Object> totalCountMap = new HashMap<String, Object>();
			totalCountMap.put("totalCount", totalCount);
			
			faultActionGridResultDtoListMap.put(Const.Definition.PAGE.PAGER, totalCountMap);
			faultActionGridResultDtoListMap.put(Const.Definition.PAGE.LISTS, faultActionGridResultDtoList);
			resEntity = ResponseEntity.ok(new ResultDto(returnString, "", faultActionGridResultDtoListMap));
		}
    	
    	return resEntity;
    }
	
	/**
	 * 
	 * createFaultAction
	 *
	 * @param reqFaultActionProcessingDto
	 * @return ResponseEntity
	 */
	@SuppressWarnings("rawtypes")
    @PostMapping(value="", produces="application/json; charset=UTF-8")
    public ResponseEntity createFaultAction(@AuthenticationPrincipal JwtAuthResultDto authResultDto, 
    		@RequestBody FaultActionProcessingDto reqFaultActionProcessingDto) throws Exception {
        
    	ResponseEntity<ResultDto> resEntity = null;
		String returnString = "";
    	
		String loginUserId = StringUtils.defaultString(authResultDto.getUserId());
		if ("".equals(loginUserId)) {
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_LOGIN_USER_ID));
			return resEntity;
		}
		String mgrYn = StringUtils.defaultString(authResultDto.getMgrYn());
		if ("".equals(mgrYn)) {
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_MGR_YN));
			return resEntity;
		}
		//String loginUserId = "tsop-admin"; // 이후 세션에서 얻어올 값...
		
		if (!"Y".equals(mgrYn)) {
			String authorityTypeCd = "";
			UserRoleMenuAuthorityRequestDto userRoleMenuAuthorityRequestDto = new UserRoleMenuAuthorityRequestDto();
			userRoleMenuAuthorityRequestDto.setUserId(loginUserId);
			userRoleMenuAuthorityRequestDto.setMenuId(MENU_ID);
			OomUserRoleAuthorityDetailDto rsltOomUserRoleAuthorityDetailDto = userRoleService.readMenuAuthority(userRoleMenuAuthorityRequestDto);
			if (rsltOomUserRoleAuthorityDetailDto != null) {
				authorityTypeCd = StringUtils.defaultString(rsltOomUserRoleAuthorityDetailDto.getAuthorityTypeCd());
			}
			if (!"W".equals(authorityTypeCd)) {
				returnString = Const.Common.RESULT_CODE.FAIL;
				resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NO_AUTH));
				return resEntity;
			}
		}
		
		OomFaultActionDto reqOomFaultActionDto = reqFaultActionProcessingDto.getFaultActionInfo();
		if (reqOomFaultActionDto == null) {
			log.error(">>>>>> reqOomFaultActionDto ERROR:{}", ERR_MSG_NULL_FAULT_ACTION_INFO);
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_FAULT_ACTION_INFO));
			return resEntity;
		}
		int onmFaultId = CommonObjectUtil.defaultNumber(reqOomFaultActionDto.getOnmFaultId());
		if (onmFaultId < 1) {
			log.error(">>>>>> onmFaultId ERROR:{}", ERR_MSG_NULL_FAULT_ID);
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_FAULT_ID));
			return resEntity;
		}
		BlobRequestDto blobRequestDto = reqFaultActionProcessingDto.getAttachFile();
		if (blobRequestDto != null) {
			String localFilePath = StringUtils.defaultString(blobRequestDto.getLocalFilePath());
			if ("".equals(localFilePath)) {
    			log.error(">>>>>> localFilePath ERROR:{}", ERR_MSG_NULL_LOCAL_FILE_PATH);
				returnString = Const.Common.RESULT_CODE.FAIL;
    			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_LOCAL_FILE_PATH));
    			return resEntity;
    		}
		}
		
		reqOomFaultActionDto.setAuditId(loginUserId);
		reqFaultActionProcessingDto.setFaultActionInfo(reqOomFaultActionDto);
		
		// 장애조치내역 등록...
		int affectRowCount = faultActionService.createFaultAction(reqFaultActionProcessingDto);
		if (affectRowCount < 1) {
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_CREATE_FAIL, affectRowCount));
		} else {
			returnString = Const.Common.RESULT_CODE.SUCCESS;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, "", affectRowCount));
		}
    	
    	return resEntity;
    }
	
	/**
	 * 
	 * deleteFaultActionAttachFile
	 *
	 * @param faultActionDatetime
	 * @param attachFileNum
	 * @param reqOomFaultActionDto
	 * @return ResponseEntity
	 */
	@SuppressWarnings("rawtypes")
    @DeleteMapping(value="/{faultOccrActionDatetime}/attach-files/{attachFileNum}", produces="application/json; charset=UTF-8")
    public ResponseEntity deleteFaultActionAttachFile(@AuthenticationPrincipal JwtAuthResultDto authResultDto, 
    		@PathVariable("faultOccrActionDatetime") String faultOccrActionDatetime, @PathVariable("attachFileNum") int attachFileNum, @RequestBody OomFaultActionDto reqOomFaultActionDto) throws Exception {
        
    	ResponseEntity<ResultDto> resEntity = null;
		String returnString = "";
    	
		String loginUserId = StringUtils.defaultString(authResultDto.getUserId());
		if ("".equals(loginUserId)) {
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_LOGIN_USER_ID));
			return resEntity;
		}
		String mgrYn = StringUtils.defaultString(authResultDto.getMgrYn());
		if ("".equals(mgrYn)) {
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_MGR_YN));
			return resEntity;
		}
		//String loginUserId = "tsop-admin"; // 이후 세션에서 얻어올 값...
		
		if (!"Y".equals(mgrYn)) {
			String authorityTypeCd = "";
			UserRoleMenuAuthorityRequestDto userRoleMenuAuthorityRequestDto = new UserRoleMenuAuthorityRequestDto();
			userRoleMenuAuthorityRequestDto.setUserId(loginUserId);
			userRoleMenuAuthorityRequestDto.setMenuId(MENU_ID);
			OomUserRoleAuthorityDetailDto rsltOomUserRoleAuthorityDetailDto = userRoleService.readMenuAuthority(userRoleMenuAuthorityRequestDto);
			if (rsltOomUserRoleAuthorityDetailDto != null) {
				authorityTypeCd = StringUtils.defaultString(rsltOomUserRoleAuthorityDetailDto.getAuthorityTypeCd());
			}
			if (!"W".equals(authorityTypeCd)) {
				returnString = Const.Common.RESULT_CODE.FAIL;
				resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NO_AUTH));
				return resEntity;
			}
		}
		
		int onmFaultId = CommonObjectUtil.defaultNumber(reqOomFaultActionDto.getOnmFaultId());
		if (onmFaultId < 1) {
			log.error(">>>>>> onmFaultId ERROR:{}", ERR_MSG_NULL_FAULT_ID);
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_FAULT_ID));
			return resEntity;
		}
		
		reqOomFaultActionDto.setFaultOccrActionDatetime(faultOccrActionDatetime);
		reqOomFaultActionDto.setAttachFileNum(attachFileNum);
		int affectRowCount = faultActionService.deleteFaultActionAttachFile(reqOomFaultActionDto);
		if (affectRowCount < 1) {
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_ATTACH_FILE_DELETE_FAIL, affectRowCount));
		} else {
			returnString = Const.Common.RESULT_CODE.SUCCESS;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, "", affectRowCount));
		}
    	
    	return resEntity;
    }
	
	/**
	 * 
	 * deleteFaultAction
	 *
	 * @param reqOomFaultActionDto
	 * @return ResponseEntity
	 */
	@SuppressWarnings("rawtypes")
    @DeleteMapping(value="/{faultOccrActionDatetime}", produces="application/json; charset=UTF-8")
    public ResponseEntity deleteFaultAction(@AuthenticationPrincipal JwtAuthResultDto authResultDto, 
    		@PathVariable("faultOccrActionDatetime") String faultOccrActionDatetime, @RequestBody OomFaultActionDto reqOomFaultActionDto) throws Exception {
        
    	ResponseEntity<ResultDto> resEntity = null;
		String returnString = "";
    	
		String loginUserId = StringUtils.defaultString(authResultDto.getUserId());
		if ("".equals(loginUserId)) {
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_LOGIN_USER_ID));
			return resEntity;
		}
		String mgrYn = StringUtils.defaultString(authResultDto.getMgrYn());
		if ("".equals(mgrYn)) {
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_MGR_YN));
			return resEntity;
		}
		//String loginUserId = "tsop-admin"; // 이후 세션에서 얻어올 값...
		
		if (!"Y".equals(mgrYn)) {
			String authorityTypeCd = "";
			UserRoleMenuAuthorityRequestDto userRoleMenuAuthorityRequestDto = new UserRoleMenuAuthorityRequestDto();
			userRoleMenuAuthorityRequestDto.setUserId(loginUserId);
			userRoleMenuAuthorityRequestDto.setMenuId(MENU_ID);
			OomUserRoleAuthorityDetailDto rsltOomUserRoleAuthorityDetailDto = userRoleService.readMenuAuthority(userRoleMenuAuthorityRequestDto);
			if (rsltOomUserRoleAuthorityDetailDto != null) {
				authorityTypeCd = StringUtils.defaultString(rsltOomUserRoleAuthorityDetailDto.getAuthorityTypeCd());
			}
			if (!"W".equals(authorityTypeCd)) {
				returnString = Const.Common.RESULT_CODE.FAIL;
				resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NO_AUTH));
				return resEntity;
			}
		}
		
		int onmFaultId = CommonObjectUtil.defaultNumber(reqOomFaultActionDto.getOnmFaultId());
		if (onmFaultId < 1) {
			log.error(">>>>>> onmFaultId ERROR:{}", ERR_MSG_NULL_FAULT_ID);
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_FAULT_ID));
			return resEntity;
		}
		String auditId = StringUtils.defaultString(reqOomFaultActionDto.getAuditId());
		if ("".equals(auditId)) {
			log.error(">>>>>> auditId ERROR:{}", ERR_MSG_NULL_AUDIT_ID);
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_AUDIT_ID));
			return resEntity;
		}
		if (!auditId.equals(loginUserId)) {
			log.error(">>>>>> auditId ERROR:{}", ERR_MSG_NULL_CANNOT_DELETE);
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_CANNOT_DELETE));
			return resEntity;
		}
		reqOomFaultActionDto.setFaultOccrActionDatetime(faultOccrActionDatetime);
		
		// 장애조치내역 삭제...
		int affectRowCount = faultActionService.deleteFaultAction(reqOomFaultActionDto);
		if (affectRowCount < 1) {
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_DELETE_FAIL, affectRowCount));
		} else {
			returnString = Const.Common.RESULT_CODE.SUCCESS;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, "", affectRowCount));
		}
    	
    	return resEntity;
    }

}
