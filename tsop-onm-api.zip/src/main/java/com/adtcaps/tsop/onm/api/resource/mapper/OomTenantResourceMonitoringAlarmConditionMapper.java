package com.adtcaps.tsop.onm.api.resource.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;

import com.adtcaps.tsop.onm.api.domain.OomTenantResourceMonitoringAlarmConditionDto;
import com.adtcaps.tsop.onm.api.resource.domain.ResourceMonitoringAlarmDetailResultDto;
import com.adtcaps.tsop.onm.api.resource.domain.ResourceMonitoringAlarmGridRequestDto;
import com.adtcaps.tsop.onm.api.resource.domain.ResourceMonitoringAlarmGridResultDto;

/**
 * 
 * <ul>
 * <li>업무 그룹명 : tsop-onm-api</li>
 * <li>서브 업무명 : com.adtcaps.tsop.onm.api.resource.mapper</li>
 * <li>설  명 : OomTenantResourceMonitoringAlarmConditionMapper.java</li>
 * <li>작성일 : 2021. 1. 21.</li>
 * <li>작성자 : jeonyb4</li>
 * </ul>
 */
@Mapper
public interface OomTenantResourceMonitoringAlarmConditionMapper {
	/**
	 * 
	 * listPageTenantResourceMonitoringAlarmCondition
	 *
	 * @param alarmConditionGridRequestDto
	 * @return List<AlarmcodeMappingGridResultDto>
	 */
	public List<ResourceMonitoringAlarmGridResultDto> listPageTenantResourceMonitoringAlarmCondition(ResourceMonitoringAlarmGridRequestDto alarmConditionGridRequestDto);
	
	/**
	 * 
	 * createOomTenantResourceMonitoringAlarmCondition
	 *
	 * @param reqOomTenantResourceMonitoringAlarmConditionDto
	 * @return int
	 */
	public int createOomTenantResourceMonitoringAlarmCondition(OomTenantResourceMonitoringAlarmConditionDto reqOomTenantResourceMonitoringAlarmConditionDto);
	
	/**
	 * 
	 * readOomTenantResourceMonitoringAlarmCondition
	 *
	 * @param reqOomTenantResourceMonitoringAlarmConditionDto
	 * @return AlarmConditionDetailResultDto
	 */
	public ResourceMonitoringAlarmDetailResultDto readOomTenantResourceMonitoringAlarmCondition(OomTenantResourceMonitoringAlarmConditionDto reqOomTenantResourceMonitoringAlarmConditionDto);
	
	/**
	 * 
	 * updateOomTenantResourceMonitoringAlarmCondition
	 *
	 * @param reqOomTenantResourceMonitoringAlarmConditionDto
	 * @return int
	 */
	public int updateOomTenantResourceMonitoringAlarmCondition(OomTenantResourceMonitoringAlarmConditionDto reqOomTenantResourceMonitoringAlarmConditionDto);
	
	/**
	 * 
	 * deleteOomTenantResourceMonitoringAlarmCondition
	 *
	 * @param reqOomTenantResourceMonitoringAlarmConditionDto
	 * @return int
	 */
	public int deleteOomTenantResourceMonitoringAlarmCondition(OomTenantResourceMonitoringAlarmConditionDto reqOomTenantResourceMonitoringAlarmConditionDto);
	
	/**
	 * 
	 * readOomTenantResourceMonitoringAlarmConditionCount
	 *
	 * @param reqOomTenantResourceMonitoringAlarmConditionDto
	 * @return int
	 */
	public int readOomTenantResourceMonitoringAlarmConditionCount(OomTenantResourceMonitoringAlarmConditionDto reqOomTenantResourceMonitoringAlarmConditionDto);
	
}
