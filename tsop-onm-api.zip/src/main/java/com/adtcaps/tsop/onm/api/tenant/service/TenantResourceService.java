package com.adtcaps.tsop.onm.api.tenant.service;

import java.util.List;

import com.adtcaps.tsop.onm.api.domain.OomTenantResourceDetailDto;
import com.adtcaps.tsop.onm.api.domain.OomTenantResourceDto;
import com.adtcaps.tsop.onm.api.tenant.domain.TenantResourceDetailGridResultDto;
import com.adtcaps.tsop.onm.api.tenant.domain.TenantResourceForComboResultDto;

/**
 * 
 * <ul>
 * <li>업무 그룹명 : tsop-onm-api</li>
 * <li>서브 업무명 : com.adtcaps.tsop.onm.api.tenant.service</li>
 * <li>설  명 : TenantResourceService.java</li>
 * <li>작성일 : 2021. 1. 6.</li>
 * <li>작성자 : jeonyb4</li>
 * </ul>
 */
public interface TenantResourceService {
	/**
	 * 
	 * listTenantResourceForThresholdCombo
	 *
	 * @param reqOomTenantResourceDetailDto
	 * @return List<TenantResourceForComboResultDto>
	 * @throws Exception 
	 */
	public List<TenantResourceForComboResultDto> listTenantResourceForThresholdCombo(OomTenantResourceDetailDto reqOomTenantResourceDetailDto) throws Exception;
	
	/**
	 * 
	 * readTenantResource
	 *
	 * @param reqOomTenantResourceDto
	 * @return OomTenantResourceDto
	 * @throws Exception 
	 */
	public OomTenantResourceDto readTenantResource(OomTenantResourceDto reqOomTenantResourceDto) throws Exception;
	
	/**
	 * 
	 * listTenantResourceDetail
	 *
	 * @param reqOomTenantResourceDetailDto
	 * @return List<TenantResourceDetailGridResultDto>
	 * @throws Exception 
	 */
	public List<TenantResourceDetailGridResultDto> listTenantResourceDetail(OomTenantResourceDetailDto reqOomTenantResourceDetailDto) throws Exception;
	
	/**
	 * 
	 * readTenantResourceForWork
	 *
	 * @param reqOomTenantResourceDto
	 * @return OomTenantResourceDto
	 * @throws Exception
	 */
	public OomTenantResourceDto readTenantResourceForWork(OomTenantResourceDto reqOomTenantResourceDto) throws Exception;
	
	/**
	 * 
	 * listTenantResourceDetailForWork
	 *
	 * @param reqOomTenantResourceDetailDto
	 * @return List<OomTenantResourceDetailDto>
	 * @throws Exception 
	 */
	public List<OomTenantResourceDetailDto> listTenantResourceDetailForWork(OomTenantResourceDetailDto reqOomTenantResourceDetailDto) throws Exception;

}
