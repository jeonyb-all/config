package com.adtcaps.tsop.onm.api.fault.domain;

import com.adtcaps.tsop.onm.api.domain.OomFaultDto;
import com.adtcaps.tsop.onm.api.file.domain.BlobRequestDto;

import lombok.Getter;
import lombok.Setter;

/**
 * 
 * <ul>
 * <li>업무 그룹명 : tsop-onm-api</li>
 * <li>서브 업무명 : com.adtcaps.tsop.onm.api.fault.domain</li>
 * <li>설  명 : FaultProcessingDto.java</li>
 * <li>작성일 : 2021. 1. 17.</li>
 * <li>작성자 : jeonyb4</li>
 * </ul>
 */
@Getter
@Setter
public class FaultProcessingDto {
	private OomFaultDto faultInfo;
	private BlobRequestDto attachFile;

}
