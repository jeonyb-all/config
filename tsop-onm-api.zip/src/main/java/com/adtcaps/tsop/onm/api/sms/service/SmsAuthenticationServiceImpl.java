package com.adtcaps.tsop.onm.api.sms.service;

import com.adtcaps.tsop.onm.api.sms.domain.SmsAccessInformation;
import com.adtcaps.tsop.onm.api.sms.util.RestTemplateUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpMethod;
import org.springframework.stereotype.Service;
import java.util.Map;

/**
 * SmsAuthenticationServiceImpl.
 *
 * @author sjlee@sk.com
 */
@Service
public class SmsAuthenticationServiceImpl implements SmsAuthenticationService {
    /**
     * Logger.
     */
    private static final Logger LOGGER = LoggerFactory.getLogger(SmsAuthenticationServiceImpl.class);
    /**
     * RestTemplateUtil.
     */
    @Autowired
    RestTemplateUtil restTemplateUtil;

    @Override
    public SmsAccessInformation getAuth(SmsAccessInformation smsAccessInformation) {

        String fullUrl = smsAccessInformation.getUrl() + "/auth/token";
        fullUrl += "?" ;
        fullUrl += "enc_yn" + "=" + "N" + "&" ;
        fullUrl += "user_id" + "=" + smsAccessInformation.getUserId() + "&" ;
        fullUrl += "password" + "=" + smsAccessInformation.getPw() ;

        LOGGER.debug("SKB_SMS_URL : url={}", fullUrl) ;

        Map<String, Object> authMap = restTemplateUtil.restTemplate(fullUrl, HttpMethod.POST, null, null,
                "SMS_LOGIN", smsAccessInformation, Map.class);
        if( authMap != null ) {
            smsAccessInformation.setAccessToken((String) authMap.get("access_token"));
        }
        return smsAccessInformation;
    }

    @Override
    public void getKeepAlive(SmsAccessInformation smsAccessInformation) {
        String fullUrl = smsAccessInformation.getUrl() + "/auth/token";
        fullUrl += "?" ;
        fullUrl += "enc_yn" + "=" + "N" + "&" ;
        fullUrl += "user_id" + "=" + smsAccessInformation.getUserId() + "&" ;
        fullUrl += "password" + "=" + smsAccessInformation.getPw() ;

        LOGGER.debug("KEEP_ALIVE : url={}, access_token={}", fullUrl, smsAccessInformation.getAccessToken());
        Map<String, Object> authMap = restTemplateUtil.restTemplate(fullUrl, HttpMethod.POST, null, null, "KEEP_ALIVE",
        smsAccessInformation, Map.class);

        if( authMap != null ) {
            smsAccessInformation.setAccessToken((String) authMap.get("access_token"));
        }

    }

    @Override
    public void getTokenKeepAlive(SmsAccessInformation smsAccessInformation) {
        String fullUrl = smsAccessInformation.getUrl() + "/auth/token";
        fullUrl += "?" ;
        fullUrl += "enc_yn" + "=" + "N" + "&" ;
        fullUrl += "user_id" + "=" + smsAccessInformation.getUserId() + "&" ;
        fullUrl += "password" + "=" + smsAccessInformation.getPw() ;

        LOGGER.debug("TOKEN_KEEP_ALIVE : url={}, access_token={}", fullUrl, smsAccessInformation.getAccessToken());
        Map<String, Object> authMap = restTemplateUtil.restTemplate(fullUrl, HttpMethod.POST, null, null, "TOKEN_KEEP_ALIVE",
        smsAccessInformation, Map.class);

        if( authMap != null ) {
            smsAccessInformation.setAccessToken((String) authMap.get("access_token"));
        }
    }
}
