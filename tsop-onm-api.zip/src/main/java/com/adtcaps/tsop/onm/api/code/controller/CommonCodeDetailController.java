package com.adtcaps.tsop.onm.api.code.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.util.CollectionUtils;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.adtcaps.tsop.onm.api.authentication.domain.JwtAuthResultDto;
import com.adtcaps.tsop.onm.api.code.domain.CommonCodeDetailDetailResultDto;
import com.adtcaps.tsop.onm.api.code.domain.CommonCodeDetailForShortGridResultDto;
import com.adtcaps.tsop.onm.api.code.domain.CommonCodeDetailGridResultDto;
import com.adtcaps.tsop.onm.api.code.domain.CommonCodeDetailRequestDto;
import com.adtcaps.tsop.onm.api.code.service.CommonCodeDetailService;
import com.adtcaps.tsop.onm.api.domain.OomCommonCodeDetailDto;
import com.adtcaps.tsop.onm.api.domain.OomUserRoleAuthorityDetailDto;
import com.adtcaps.tsop.onm.api.helper.constant.Const;
import com.adtcaps.tsop.onm.api.helper.domain.BasePageDto;
import com.adtcaps.tsop.onm.api.helper.domain.ResultDto;
import com.adtcaps.tsop.onm.api.helper.util.CommonObjectUtil;
import com.adtcaps.tsop.onm.api.helper.util.PageUtil;
import com.adtcaps.tsop.onm.api.user.domain.UserRoleMenuAuthorityRequestDto;
import com.adtcaps.tsop.onm.api.user.service.UserRoleService;

import lombok.extern.slf4j.Slf4j;

/**
 * 
 * <ul>
 * <li>업무 그룹명 : tsop-onm-api</li>
 * <li>서브 업무명 : com.adtcaps.tsop.onm.api.code.controller</li>
 * <li>설  명 : CommonCodeDetailController.java</li>
 * <li>작성일 : 2021. 1. 5.</li>
 * <li>작성자 : jeonyb4</li>
 * </ul>
 */
@Slf4j
@RestController
@RequestMapping("/api/codes")
public class CommonCodeDetailController {
	
	private final String MENU_ID = "ONM0022";
	
	private final String ERR_MSG_NULL_LOGIN_USER_ID = "로그인 사용자ID가 없습니다.";
	private final String ERR_MSG_NULL_MGR_YN = "관리자여부가 없습니다.";
	private final String ERR_MSG_NULL_COMMON_CD_VAL = "공통코드값이 없습니다.";
	private final String ERR_MSG_NULL_COMMON_CD_VAL_NAME = "공통코드값명이 없습니다.";
	private final String ERR_MSG_NULL_SORT_SEQ = "정렬순번이 없습니다.";
	
	private final String ERR_MSG_ALREADY_EXIST_COMMAND_CD_VAL = "해당 공통코드값은 이미 존재하므로 사용할 수 없습니다.";
	
	private final String ERR_MSG_NO_AUTH = "권한이 없는 사용자 입니다.";
	private final String ERR_MSG_NULL_SEARCH_RESULT_LIST = "조회 결과가 없습니다.";
	private final String ERR_MSG_CREATE_FAIL = "등록에 실패하였습니다.";
	private final String ERR_MSG_READ_FAIL = "조회에 실패하였습니다.";
	private final String ERR_MSG_UPDATE_FAIL = "수정에 실패하였습니다.";
	private final String ERR_MSG_DELETE_FAIL = "삭제에 실패하였습니다.";
	
	@Autowired
	private CommonCodeDetailService commonCodeDetailService;
	
	@Autowired
	private UserRoleService userRoleService;
	
	/**
	 * 
	 * listPageCommonCodeDetail
	 *
	 * @param commonCodeGridRequestDto
	 * @return ResponseEntity
	 */
	@SuppressWarnings("rawtypes")
    @GetMapping(value="/{commonCd}/code-details", produces="application/json; charset=UTF-8")
    public ResponseEntity listCommonCodeDetail(@PathVariable("commonCd") String commonCd) throws Exception {
        
    	ResponseEntity<ResultDto> resEntity = null;
		String returnString = "";
    	
		OomCommonCodeDetailDto reqOomCommonCodeDetailDto = new OomCommonCodeDetailDto();
		reqOomCommonCodeDetailDto.setCommonCd(commonCd);
		// 코드상세 목록 조회....
		Map<String, Object> commonCodeGridResultDtoListMap = new HashMap<String, Object>();
		List<CommonCodeDetailGridResultDto> commonCodeGridResultDtoList = commonCodeDetailService.listCommonCodeDetail(reqOomCommonCodeDetailDto);
		if (CollectionUtils.isEmpty(commonCodeGridResultDtoList)) {
			returnString = Const.Common.RESULT_CODE.SUCCESS;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_SEARCH_RESULT_LIST, commonCodeGridResultDtoListMap));
		} else {
			returnString = Const.Common.RESULT_CODE.SUCCESS;
			commonCodeGridResultDtoListMap.put(Const.Definition.PAGE.PAGER, PageUtil.getPageInfo(commonCodeGridResultDtoList));
			commonCodeGridResultDtoListMap.put(Const.Definition.PAGE.LISTS, commonCodeGridResultDtoList);
			resEntity = ResponseEntity.ok(new ResultDto(returnString, "", commonCodeGridResultDtoListMap));
		}
    	
    	return resEntity;
    }
	
	/**
	 * 
	 * readCommonCodeDetailDuplicationCheck
	 *
	 * @param commonCd
	 * @return ResponseEntity
	 */
	@SuppressWarnings("rawtypes")
    @GetMapping(value="/{commonCd}/code-details/dup-check/{commonCdVal}", produces="application/json; charset=UTF-8")
    public ResponseEntity readCommonCodeDetailDuplicationCheck(@PathVariable("commonCd") String commonCd, @PathVariable("commonCdVal") String commonCdVal) throws Exception {
        
    	ResponseEntity<ResultDto> resEntity = null;
		String returnString = "";
    	
		OomCommonCodeDetailDto reqOomCommonCodeDetailDto = new OomCommonCodeDetailDto();
		reqOomCommonCodeDetailDto.setCommonCd(commonCd);
		reqOomCommonCodeDetailDto.setCommonCdVal(commonCdVal);
		
		// 공통코드상세 중복체크...
		int commonCdCount = CommonObjectUtil.defaultNumber(commonCodeDetailService.readCommonCodeDetailDuplicationCheck(reqOomCommonCodeDetailDto));
		if (commonCdCount > 0) {
			returnString = Const.Common.RESULT_CODE.SUCCESS;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_ALREADY_EXIST_COMMAND_CD_VAL, commonCdCount));
		} else {
			returnString = Const.Common.RESULT_CODE.SUCCESS;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, "", commonCdCount));
		}
    	
    	return resEntity;
    }
	
	/**
	 * 
	 * createCommonCodeDetail
	 *
	 * @param reqOomCommonCodeDetailDto
	 * @return ResponseEntity
	 */
	@SuppressWarnings("rawtypes")
    @PostMapping(value="/{commonCd}/code-details", produces="application/json; charset=UTF-8")
    public ResponseEntity createCommonCodeDetail(@AuthenticationPrincipal JwtAuthResultDto authResultDto, 
    		@PathVariable("commonCd") String commonCd, @RequestBody OomCommonCodeDetailDto reqOomCommonCodeDetailDto) throws Exception {
        
    	ResponseEntity<ResultDto> resEntity = null;
		String returnString = "";
    	
		String loginUserId = StringUtils.defaultString(authResultDto.getUserId());
		if ("".equals(loginUserId)) {
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_LOGIN_USER_ID));
			return resEntity;
		}
		String mgrYn = StringUtils.defaultString(authResultDto.getMgrYn());
		if ("".equals(mgrYn)) {
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_MGR_YN));
			return resEntity;
		}
		//String loginUserId = "tsop-admin"; // 이후 세션에서 얻어올 값...
		
		if (!"Y".equals(mgrYn)) {
			String authorityTypeCd = "";
			UserRoleMenuAuthorityRequestDto userRoleMenuAuthorityRequestDto = new UserRoleMenuAuthorityRequestDto();
			userRoleMenuAuthorityRequestDto.setUserId(loginUserId);
			userRoleMenuAuthorityRequestDto.setMenuId(MENU_ID);
			OomUserRoleAuthorityDetailDto rsltOomUserRoleAuthorityDetailDto = userRoleService.readMenuAuthority(userRoleMenuAuthorityRequestDto);
			if (rsltOomUserRoleAuthorityDetailDto != null) {
				authorityTypeCd = StringUtils.defaultString(rsltOomUserRoleAuthorityDetailDto.getAuthorityTypeCd());
			}
			if (!"W".equals(authorityTypeCd)) {
				returnString = Const.Common.RESULT_CODE.FAIL;
				resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NO_AUTH));
				return resEntity;
			}
		}
		
		String commonCdVal = StringUtils.defaultString(reqOomCommonCodeDetailDto.getCommonCdVal());
		if ("".equals(commonCdVal)) {
			log.error(">>>>>> commonCdVal ERROR:{}", ERR_MSG_NULL_COMMON_CD_VAL);
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_COMMON_CD_VAL));
			return resEntity;
		}
		String commonCdValName = StringUtils.defaultString(reqOomCommonCodeDetailDto.getCommonCdValName());
		if ("".equals(commonCdValName)) {
			log.error(">>>>>> commonCdValName ERROR:{}", ERR_MSG_NULL_COMMON_CD_VAL_NAME);
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_COMMON_CD_VAL_NAME));
			return resEntity;
		}
		int sortSeq = CommonObjectUtil.defaultNumber(reqOomCommonCodeDetailDto.getSortSeq());
		if (sortSeq < 1) {
			log.error(">>>>>> sortSeq ERROR:{}", ERR_MSG_NULL_SORT_SEQ);
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_SORT_SEQ));
			return resEntity;
		}
		
		reqOomCommonCodeDetailDto.setAuditId(loginUserId);
		reqOomCommonCodeDetailDto.setCommonCd(commonCd);
		
		// 공통코드상세 등록...
		int affectRowCount = commonCodeDetailService.createCommonCodeDetail(reqOomCommonCodeDetailDto);
		if (affectRowCount < 1) {
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_CREATE_FAIL, affectRowCount));
		} else {
			returnString = Const.Common.RESULT_CODE.SUCCESS;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, "", affectRowCount));
		}
    	
    	return resEntity;
    }
	
	/**
	 * 
	 * readCommonCodeDetail
	 *
	 * @param commonCd
	 * @return ResponseEntity
	 */
	@SuppressWarnings("rawtypes")
    @GetMapping(value="/{commonCd}/code-details/{commonCdVal}", produces="application/json; charset=UTF-8")
    public ResponseEntity readCommonCodeDetail(@PathVariable("commonCd") String commonCd, @PathVariable("commonCdVal") String commonCdVal) throws Exception {
        
    	ResponseEntity<ResultDto> resEntity = null;
		String returnString = "";
    	
		OomCommonCodeDetailDto reqOomCommonCodeDetailDto = new OomCommonCodeDetailDto();
		reqOomCommonCodeDetailDto.setCommonCd(commonCd);
		reqOomCommonCodeDetailDto.setCommonCdVal(commonCdVal);
		
		CommonCodeDetailDetailResultDto commonCodeDetailDetailResultDto = commonCodeDetailService.readCommonCodeDetail(reqOomCommonCodeDetailDto);
		if (commonCodeDetailDetailResultDto == null) {
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_READ_FAIL, commonCodeDetailDetailResultDto));
		} else {
			returnString = Const.Common.RESULT_CODE.SUCCESS;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, "", commonCodeDetailDetailResultDto));
		}
    	
    	return resEntity;
    }
	
	/**
	 * 
	 * updateCommonCodeDetail
	 *
	 * @param commonCd
	 * @param reqOomCommonCodeDetailDto
	 * @return ResponseEntity
	 */
	@SuppressWarnings("rawtypes")
    @PutMapping(value="/{commonCd}/code-details/{commonCdVal}", produces="application/json; charset=UTF-8")
    public ResponseEntity updateCommonCodeDetail(@AuthenticationPrincipal JwtAuthResultDto authResultDto, 
    		@PathVariable("commonCd") String commonCd, @PathVariable("commonCdVal") String commonCdVal, @RequestBody OomCommonCodeDetailDto reqOomCommonCodeDetailDto) throws Exception {
        
    	ResponseEntity<ResultDto> resEntity = null;
		String returnString = "";
    	
		String loginUserId = StringUtils.defaultString(authResultDto.getUserId());
		if ("".equals(loginUserId)) {
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_LOGIN_USER_ID));
			return resEntity;
		}
		String mgrYn = StringUtils.defaultString(authResultDto.getMgrYn());
		if ("".equals(mgrYn)) {
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_MGR_YN));
			return resEntity;
		}
		//String loginUserId = "tsop-admin"; // 이후 세션에서 얻어올 값...
		
		if (!"Y".equals(mgrYn)) {
			String authorityTypeCd = "";
			UserRoleMenuAuthorityRequestDto userRoleMenuAuthorityRequestDto = new UserRoleMenuAuthorityRequestDto();
			userRoleMenuAuthorityRequestDto.setUserId(loginUserId);
			userRoleMenuAuthorityRequestDto.setMenuId(MENU_ID);
			OomUserRoleAuthorityDetailDto rsltOomUserRoleAuthorityDetailDto = userRoleService.readMenuAuthority(userRoleMenuAuthorityRequestDto);
			if (rsltOomUserRoleAuthorityDetailDto != null) {
				authorityTypeCd = StringUtils.defaultString(rsltOomUserRoleAuthorityDetailDto.getAuthorityTypeCd());
			}
			if (!"W".equals(authorityTypeCd)) {
				returnString = Const.Common.RESULT_CODE.FAIL;
				resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NO_AUTH));
				return resEntity;
			}
		}
		
		String commonCdValName = StringUtils.defaultString(reqOomCommonCodeDetailDto.getCommonCdValName());
		if ("".equals(commonCdValName)) {
			log.error(">>>>>> commonCdValName ERROR:{}", ERR_MSG_NULL_COMMON_CD_VAL_NAME);
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_COMMON_CD_VAL_NAME));
			return resEntity;
		}
		int sortSeq = CommonObjectUtil.defaultNumber(reqOomCommonCodeDetailDto.getSortSeq());
		if (sortSeq < 1) {
			log.error(">>>>>> sortSeq ERROR:{}", ERR_MSG_NULL_SORT_SEQ);
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_SORT_SEQ));
			return resEntity;
		}
		
		reqOomCommonCodeDetailDto.setAuditId(loginUserId);
		reqOomCommonCodeDetailDto.setCommonCd(commonCd);
		reqOomCommonCodeDetailDto.setCommonCdVal(commonCdVal);
		
		// 공통코드상세 수정...
		int affectRowCount = commonCodeDetailService.updateCommonCodeDetail(reqOomCommonCodeDetailDto);
		if (affectRowCount < 1) {
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_UPDATE_FAIL, affectRowCount));
		} else {
			returnString = Const.Common.RESULT_CODE.SUCCESS;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, "", affectRowCount));
		}
    	
    	return resEntity;
    }
	
	/**
	 * 
	 * deleteCommonCodeDetail
	 *
	 * @param commonCd
	 * @return ResponseEntity
	 */
	@SuppressWarnings("rawtypes")
    @DeleteMapping(value="/{commonCd}/code-details/{commonCdVal}", produces="application/json; charset=UTF-8")
    public ResponseEntity deleteCommonCodeDetail(@AuthenticationPrincipal JwtAuthResultDto authResultDto, 
    		@PathVariable("commonCd") String commonCd, @PathVariable("commonCdVal") String commonCdVal) throws Exception {
        
    	ResponseEntity<ResultDto> resEntity = null;
		String returnString = "";
    	
		String loginUserId = StringUtils.defaultString(authResultDto.getUserId());
		if ("".equals(loginUserId)) {
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_LOGIN_USER_ID));
			return resEntity;
		}
		String mgrYn = StringUtils.defaultString(authResultDto.getMgrYn());
		if ("".equals(mgrYn)) {
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_MGR_YN));
			return resEntity;
		}
		//String loginUserId = "tsop-admin"; // 이후 세션에서 얻어올 값...
		
		if (!"Y".equals(mgrYn)) {
			String authorityTypeCd = "";
			UserRoleMenuAuthorityRequestDto userRoleMenuAuthorityRequestDto = new UserRoleMenuAuthorityRequestDto();
			userRoleMenuAuthorityRequestDto.setUserId(loginUserId);
			userRoleMenuAuthorityRequestDto.setMenuId(MENU_ID);
			OomUserRoleAuthorityDetailDto rsltOomUserRoleAuthorityDetailDto = userRoleService.readMenuAuthority(userRoleMenuAuthorityRequestDto);
			if (rsltOomUserRoleAuthorityDetailDto != null) {
				authorityTypeCd = StringUtils.defaultString(rsltOomUserRoleAuthorityDetailDto.getAuthorityTypeCd());
			}
			if (!"W".equals(authorityTypeCd)) {
				returnString = Const.Common.RESULT_CODE.FAIL;
				resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NO_AUTH));
				return resEntity;
			}
		}
		
		OomCommonCodeDetailDto reqOomCommonCodeDetailDto = new OomCommonCodeDetailDto();
		reqOomCommonCodeDetailDto.setCommonCd(commonCd);
		reqOomCommonCodeDetailDto.setCommonCdVal(commonCdVal);
		
		// 공통코드 삭제...
		int affectRowCount = commonCodeDetailService.deleteCommonCodeDetail(reqOomCommonCodeDetailDto);
		if (affectRowCount < 1) {
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_DELETE_FAIL, affectRowCount));
		} else {
			returnString = Const.Common.RESULT_CODE.SUCCESS;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, "", affectRowCount));
		}
    	
    	return resEntity;
    }
	
	
	/**
	 * 
	 * listCommonCodeDetailForCombo
	 *
	 * @param commonCd
	 * @param commonCodeDetailRequestDto
	 * @return ResponseEntity
	 */
	@SuppressWarnings("rawtypes")
    @GetMapping(value="/{commonCd}/code-details/combobox", produces="application/json; charset=UTF-8")
    public ResponseEntity listCommonCodeDetailForCombo(@PathVariable("commonCd") String commonCd, CommonCodeDetailRequestDto commonCodeDetailRequestDto) throws Exception {
        
    	ResponseEntity<ResultDto> resEntity = null;
		String returnString = "";
    	
		commonCodeDetailRequestDto.setCommonCd(commonCd);
		// 코드상세 콤보박스용 목록조회....
		List<OomCommonCodeDetailDto> rsltOomCommonCodeDetailDtoList = commonCodeDetailService.listCommonCodeDetailForCombo(commonCodeDetailRequestDto);
		if (CollectionUtils.isEmpty(rsltOomCommonCodeDetailDtoList)) {
			returnString = Const.Common.RESULT_CODE.SUCCESS;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_SEARCH_RESULT_LIST, rsltOomCommonCodeDetailDtoList));
		} else {
			returnString = Const.Common.RESULT_CODE.SUCCESS;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, "", rsltOomCommonCodeDetailDtoList));
		}
    	
    	return resEntity;
    }
	
	/**
	 * 
	 * listCommonCodeDetailForShortGrid
	 *
	 * @param reqBasePageDto
	 * @return ResponseEntity
	 */
	@SuppressWarnings("rawtypes")
    @GetMapping(value="/code-details/short-grid", produces="application/json; charset=UTF-8")
    public ResponseEntity listCommonCodeDetailForShortGrid(BasePageDto reqBasePageDto) throws Exception {
        
    	ResponseEntity<ResultDto> resEntity = null;
		String returnString = "";
    	
		// 코드상세 팝업용 목록조회....
		Map<String, Object> commonCodeDetailForShortGridResultDtoListMap = new HashMap<String, Object>();
		List<CommonCodeDetailForShortGridResultDto> commonCodeDetailForShortGridResultDtoList = commonCodeDetailService.listCommonCodeDetailForShortGrid(reqBasePageDto);
		if (CollectionUtils.isEmpty(commonCodeDetailForShortGridResultDtoList)) {
			returnString = Const.Common.RESULT_CODE.SUCCESS;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_SEARCH_RESULT_LIST, commonCodeDetailForShortGridResultDtoListMap));
		} else {
			returnString = Const.Common.RESULT_CODE.SUCCESS;
			int totalCount = commonCodeDetailForShortGridResultDtoList.size();
			Map<String, Object> totalCountMap = new HashMap<String, Object>();
			totalCountMap.put("totalCount", totalCount);
			
			commonCodeDetailForShortGridResultDtoListMap.put(Const.Definition.PAGE.PAGER, totalCountMap);
			commonCodeDetailForShortGridResultDtoListMap.put(Const.Definition.PAGE.LISTS, commonCodeDetailForShortGridResultDtoList);
			resEntity = ResponseEntity.ok(new ResultDto(returnString, "", commonCodeDetailForShortGridResultDtoListMap));
		}
    	
    	return resEntity;
    }

}
