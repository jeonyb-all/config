package com.adtcaps.tsop.onm.api.work.domain;

import lombok.Getter;
import lombok.Setter;

/**
 * 
 * <ul>
 * <li>업무 그룹명 : tsop-onm-api</li>
 * <li>서브 업무명 : com.adtcaps.tsop.onm.api.work.domain</li>
 * <li>설  명 : WorkStatusCodeForComboResultDto.java</li>
 * <li>작성일 : 2021. 2. 1.</li>
 * <li>작성자 : jeonyb4</li>
 * </ul>
 */
@Getter
@Setter
public class WorkStatusCodeForComboResultDto {
	private String onmWorkStatusCd;
	private String onmWorkStatusCdName;
	
}
