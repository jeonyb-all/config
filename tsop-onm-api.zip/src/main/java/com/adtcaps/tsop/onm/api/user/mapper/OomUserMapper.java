package com.adtcaps.tsop.onm.api.user.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;

import com.adtcaps.tsop.onm.api.domain.OomUserDto;
import com.adtcaps.tsop.onm.api.user.domain.UserDetailResultDto;
import com.adtcaps.tsop.onm.api.user.domain.UserForShortGridRequestDto;
import com.adtcaps.tsop.onm.api.user.domain.UserForShortGridResultDto;
import com.adtcaps.tsop.onm.api.user.domain.UserGridRequestDto;
import com.adtcaps.tsop.onm.api.user.domain.UserGridResultDto;

/**
 * 
 * <ul>
 * <li>업무 그룹명 : tsop-onm-api</li>
 * <li>서브 업무명 : com.adtcaps.tsop.onm.api.user.mapper</li>
 * <li>설  명 : OomUserMapper.java</li>
 * <li>작성일 : 2021. 1. 4.</li>
 * <li>작성자 : jeonyb4</li>
 * </ul>
 */
@Mapper
public interface OomUserMapper {
	/**
	 * 
	 * listUserForShortGrid
	 *
	 * @param userForShortGridRequestDto
	 * @return List<UserForShortGridResultDto>
	 */
	public List<UserForShortGridResultDto> listUserForShortGrid(UserForShortGridRequestDto userForShortGridRequestDto);
	
	/**
	 * 
	 * listPageUser
	 *
	 * @param userGridRequestDto
	 * @return List<UserGridResultDto>
	 */
	public List<UserGridResultDto> listPageUser(UserGridRequestDto userGridRequestDto);
	
	/**
	 * 
	 * createOomUser
	 *
	 * @param reqOomUserDto
	 * @return int
	 */
	public int createOomUser(OomUserDto reqOomUserDto);
	
	/**
	 * 
	 * readUserDuplicationCheck
	 *
	 * @param reqOomUserDto
	 * @return int
	 */
	public int readUserDuplicationCheck(OomUserDto reqOomUserDto);
	
	/**
	 * 
	 * readUserDuplicationServiceOper
	 *
	 * @param reqOomUserDto
	 * @return int
	 */
	public int readUserDuplicationServiceOper(OomUserDto reqOomUserDto);
	
	/**
	 * 
	 * readUserPasswordEqualCheck
	 *
	 * @param reqOomUserDto
	 * @return int
	 */
	public int readUserPasswordEqualCheck(OomUserDto reqOomUserDto);
	
	/**
	 * 
	 * updateUserPassword
	 *
	 * @param reqOomUserDto
	 * @return int
	 */
	public int updateUserPassword(OomUserDto reqOomUserDto);
	
	/**
	 * 
	 * readOomUser
	 *
	 * @param reqOomUserDto
	 * @return UserDetailResultDto
	 */
	public UserDetailResultDto readOomUser(OomUserDto reqOomUserDto);
	
	/**
	 * 
	 * updateMyProfile
	 * 
	 * @param reqOomUserDto
	 * @return int
	 */
	public int updateMyProfile(OomUserDto reqOomUserDto);
	
	/**
	 * 
	 * updateOomUser
	 *
	 * @param reqOomUserDto
	 * @return int
	 */
	public int updateOomUser(OomUserDto reqOomUserDto);
	
	/**
	 * 
	 * deleteOomUser
	 *
	 * @param reqOomUserDto
	 * @return int
	 */
	public int deleteOomUser(OomUserDto reqOomUserDto);
	
	/**
	 * 
	 * readServiceOperUserInfoForTenantId
	 *
	 * @param reqOomUserDto
	 * @return OomUserDto
	 */
	public OomUserDto readServiceOperUserInfoForTenantId(OomUserDto reqOomUserDto);
	
	
	
	/**
	 * 
	 * updateOomUserLockYn (scheduler)
	 * 
	 * @return int
	 */
	public int updateOomUserLockYn();

}
