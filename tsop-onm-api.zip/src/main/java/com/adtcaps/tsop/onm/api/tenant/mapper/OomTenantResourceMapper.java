package com.adtcaps.tsop.onm.api.tenant.mapper;

import org.apache.ibatis.annotations.Mapper;

import com.adtcaps.tsop.onm.api.domain.OomTenantResourceDto;

/**
 * 
 * <ul>
 * <li>업무 그룹명 : tsop-onm-api</li>
 * <li>서브 업무명 : com.adtcaps.tsop.onm.api.tenant.mapper</li>
 * <li>설  명 : OomTenantResourceMapper.java</li>
 * <li>작성일 : 2021. 1. 6.</li>
 * <li>작성자 : jeonyb4</li>
 * </ul>
 */
@Mapper
public interface OomTenantResourceMapper {
	/**
	 * 
	 * readTenantResource
	 *
	 * @param reqOomTenantResourceDto
	 * @return OomTenantResourceDto
	 */
	public OomTenantResourceDto readTenantResource(OomTenantResourceDto reqOomTenantResourceDto);
	
	/**
	 * 
	 * readTenantResourceForWork
	 *
	 * @param reqOomTenantResourceDto
	 * @return OomTenantResourceDto
	 */
	public OomTenantResourceDto readTenantResourceForWork(OomTenantResourceDto reqOomTenantResourceDto);

}
