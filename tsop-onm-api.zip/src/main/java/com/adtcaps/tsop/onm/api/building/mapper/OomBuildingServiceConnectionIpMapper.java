package com.adtcaps.tsop.onm.api.building.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;

import com.adtcaps.tsop.onm.api.building.domain.BuildingServiceConnectionIpDetailDto;
import com.adtcaps.tsop.onm.api.domain.OomBuildingServiceConnectionIpDto;

/**
 * 
 * <ul>
 * <li>업무 그룹명 : tsop-onm-api</li>
 * <li>서브 업무명 : com.adtcaps.tsop.onm.api.building.mapper</li>
 * <li>설  명 : OomBuildingServiceConnectionIpMapper.java</li>
 * <li>작성일 : 2021. 1. 31.</li>
 * <li>작성자 : jeonyb4</li>
 * </ul>
 */
@Mapper
public interface OomBuildingServiceConnectionIpMapper {
	/**
	 * 
	 * listBuildingServiceConnectionIp
	 *
	 * @param reqOomBuildingServiceConnectionIpDto
	 * @return List<OomBuildingServiceConnectionIpDto>
	 */
	public List<OomBuildingServiceConnectionIpDto> listBuildingServiceConnectionIp(OomBuildingServiceConnectionIpDto reqOomBuildingServiceConnectionIpDto);
	
	/**
	 * 
	 * listBuildingServiceConnectionIpDetail
	 *
	 * @param reqOomBuildingServiceConnectionIpDto
	 * @return List<BuildingServiceConnectionIpDetailDto>
	 */
	public List<BuildingServiceConnectionIpDetailDto> listBuildingServiceConnectionIpDetail(OomBuildingServiceConnectionIpDto reqOomBuildingServiceConnectionIpDto);
	
	/**
	 * 
	 * deleteOomBuildingServiceConnectionIp
	 *
	 * @param reqOomBuildingServiceConnectionIpDto
	 * @return int
	 */
	public int deleteOomBuildingServiceConnectionIp(OomBuildingServiceConnectionIpDto reqOomBuildingServiceConnectionIpDto);

}
