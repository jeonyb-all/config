package com.adtcaps.tsop.onm.api.authentication.domain;



public class JwtAuthSmsDto {
    
    
    private String userId;
    private String token;
    private String authSms;
    private String ip;
    private String expirYn;
    private String phoneNm;
    private String password;
    private String passwordYn;

  


    public JwtAuthSmsDto()
	{
		
	}

    public JwtAuthSmsDto(String userId, String token, String authSms, String ip){
        this.userId = userId;
        this.token = token;
        this.authSms =  authSms;
        this.ip =  ip;
    }

    public String getUserId() {
        return this.userId;
    }

    public void setUserId(String userid) {
        this.userId = userid;
    }

    public String getToken() {
        return this.token;
    }

    public void setToken(String token) {
        this.token = token;
    }

    public String getAuthSms() {
        return this.authSms;
    }

    public void setAuthSms(String authSms) {
        this.authSms = authSms;
    }

    public String getIp() {
        return this.ip;
    }

    public void setIp(String ip) {
        this.ip = ip;
    }

    public String getExpirYn() {
        return this.expirYn;
    }

    public void setExpirYn(String expirYn) {
        this.expirYn = expirYn;
    }

    public String getPhoneNm() {
        return this.phoneNm;
    }

    public void setPhoneNm(String phoneNm) {
        this.phoneNm = phoneNm;
    }

    public String getPassword() {
        return this.password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getPasswordYn() {
        return this.passwordYn;
    }

    public void setPasswordYn(String passwordYn) {
        this.passwordYn = passwordYn;
    }



}

