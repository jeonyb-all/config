package com.adtcaps.tsop.onm.api.code.controller;

import java.io.File;
import java.io.FileInputStream;
import java.io.OutputStream;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.io.FileUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.util.CollectionUtils;
import org.springframework.util.FileCopyUtils;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.adtcaps.tsop.onm.api.authentication.domain.JwtAuthResultDto;
import com.adtcaps.tsop.onm.api.code.domain.CommonCodeGridRequestDto;
import com.adtcaps.tsop.onm.api.code.domain.CommonCodeGridResultDto;
import com.adtcaps.tsop.onm.api.code.domain.CommonCodeRequestDto;
import com.adtcaps.tsop.onm.api.code.service.CommonCodeService;
import com.adtcaps.tsop.onm.api.domain.OomCommonCodeDto;
import com.adtcaps.tsop.onm.api.domain.OomUserRoleAuthorityDetailDto;
import com.adtcaps.tsop.onm.api.helper.constant.Const;
import com.adtcaps.tsop.onm.api.helper.domain.ResultDto;
import com.adtcaps.tsop.onm.api.helper.util.CommonObjectUtil;
import com.adtcaps.tsop.onm.api.helper.util.PageUtil;
import com.adtcaps.tsop.onm.api.user.domain.UserRoleMenuAuthorityRequestDto;
import com.adtcaps.tsop.onm.api.user.service.UserRoleService;

import lombok.extern.slf4j.Slf4j;

/**
 * 
 * <ul>
 * <li>업무 그룹명 : tsop-onm-api</li>
 * <li>서브 업무명 : com.adtcaps.tsop.onm.api.code.controller</li>
 * <li>설  명 : CommonCodeController.java</li>
 * <li>작성일 : 2021. 1. 4.</li>
 * <li>작성자 : jeonyb4</li>
 * </ul>
 */
@Slf4j
@RestController
@RequestMapping("/api/codes")
public class CommonCodeController {
	
	private final String MENU_ID = "ONM0022";
	
	private final String ERR_MSG_NULL_LOGIN_USER_ID = "로그인 사용자ID가 없습니다.";
	private final String ERR_MSG_NULL_MGR_YN = "관리자여부가 없습니다.";
	private final String ERR_MSG_NULL_PAGE_NUMBER = "페이지 번호가 없습니다.";
	private final String ERR_MSG_NULL_COMMON_CD = "공통코드가 없습니다.";
	private final String ERR_MSG_NULL_COMMON_CD_NAME = "공통코드명이 없습니다.";
	
	private final String ERR_MSG_ALREADY_EXIST_COMMAND_CD = "해당 공통코드는 이미 존재하므로 사용할 수 없습니다.";
	
	private final String ERR_MSG_NO_AUTH = "권한이 없는 사용자 입니다.";
	private final String ERR_MSG_NULL_SEARCH_RESULT_LIST = "조회 결과가 없습니다.";
	private final String ERR_MSG_CREATE_FAIL = "등록에 실패하였습니다.";
	private final String ERR_MSG_READ_FAIL = "조회에 실패하였습니다.";
	private final String ERR_MSG_UPDATE_FAIL = "수정에 실패하였습니다.";
	private final String ERR_MSG_DELETE_FAIL = "삭제에 실패하였습니다.";
	
	@Autowired
	private CommonCodeService commonCodeService;
	
	@Autowired
	private UserRoleService userRoleService;
	
	/**
	 * 
	 * listPageCommonCode
	 *
	 * @param commonCodeGridRequestDto
	 * @return ResponseEntity
	 */
	@SuppressWarnings("rawtypes")
    @GetMapping(value="", produces="application/json; charset=UTF-8")
    public ResponseEntity listPageCommonCode(CommonCodeGridRequestDto commonCodeGridRequestDto) throws Exception {
        
    	ResponseEntity<ResultDto> resEntity = null;
		String returnString = "";
    	
		int pageNumber = commonCodeGridRequestDto.getPageNumber();
		if (pageNumber < 1) {
			log.error(">>>>>> pageNumber ERROR:{}", ERR_MSG_NULL_PAGE_NUMBER);
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_PAGE_NUMBER));
			return resEntity;
		}
		// 코드 목록 조회....
		Map<String, Object> commonCodeGridResultDtoListMap = new HashMap<String, Object>();
		List<CommonCodeGridResultDto> commonCodeGridResultDtoList = commonCodeService.listPageCommonCode(commonCodeGridRequestDto);
		if (CollectionUtils.isEmpty(commonCodeGridResultDtoList)) {
			returnString = Const.Common.RESULT_CODE.SUCCESS;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_SEARCH_RESULT_LIST, commonCodeGridResultDtoListMap));
		} else {
			returnString = Const.Common.RESULT_CODE.SUCCESS;
			commonCodeGridResultDtoListMap.put(Const.Definition.PAGE.PAGER, PageUtil.getPageInfo(commonCodeGridResultDtoList));
			commonCodeGridResultDtoListMap.put(Const.Definition.PAGE.LISTS, commonCodeGridResultDtoList);
			resEntity = ResponseEntity.ok(new ResultDto(returnString, "", commonCodeGridResultDtoListMap));
		}
    	
    	return resEntity;
    }
	
	/**
	 * 
	 * listCommonCodeExcel
	 *
	 * @param request
	 * @param response
	 * @param commonCodeGridRequestDto
	 * @return ResponseEntity
	 * @throws Exception 
	 */
	@SuppressWarnings("rawtypes")
    @GetMapping(value="/excels", produces="application/json; charset=UTF-8")
    public ResponseEntity listCommonCodeExcel(HttpServletRequest request, HttpServletResponse response, CommonCodeGridRequestDto commonCodeGridRequestDto) throws Exception {
        
    	ResponseEntity<ResultDto> resEntity = null;
		
		commonCodeGridRequestDto.setExcelYn("Y");
		
		StringBuilder fileNameBuilder = new StringBuilder();
		fileNameBuilder.append("common_code_list");
		fileNameBuilder.append(".");
		fileNameBuilder.append(Const.Definition.FILE_EXTENTION.EXCEL);
		String fileName = fileNameBuilder.toString();
		
		// 엑셀 파일 생성...
		String fileFullPathName = commonCodeService.listCommonCodeExcel(commonCodeGridRequestDto, fileName);
		
		// Excel File Download...
        response.setHeader("Content-Disposition", "attachment;filename=\"" + fileName + "\";");
        response.setContentType("application/octet-stream");
        response.setHeader("Content-transfer-Encoding", "binary");
        response.setHeader("mediaType", "application/vnd.ms-excel");
        OutputStream out = null;
        out = response.getOutputStream();
        FileInputStream fis = new FileInputStream(fileFullPathName);
        FileCopyUtils.copy(fis, out);
     
        out.flush();
		
		// Local Temp Directory 삭제...
        int lastSlashIndexVal = StringUtils.lastIndexOf(fileFullPathName, "/");
		String tempDirPath = StringUtils.substring(fileFullPathName, 0, lastSlashIndexVal);
		File downloadTempDirectory = new File(tempDirPath);
		if (downloadTempDirectory.isDirectory()) {
			FileUtils.deleteDirectory(downloadTempDirectory);
		}
    	
    	return resEntity;
    }
	
	/**
	 * 
	 * readCommonCodeDuplicationCheck
	 *
	 * @param commonCd
	 * @return ResponseEntity
	 */
	@SuppressWarnings("rawtypes")
    @GetMapping(value="/dup-check/{commonCd}", produces="application/json; charset=UTF-8")
    public ResponseEntity readCommonCodeDuplicationCheck(@PathVariable("commonCd") String commonCd) throws Exception {
        
    	ResponseEntity<ResultDto> resEntity = null;
		String returnString = "";
    	
		OomCommonCodeDto reqOomCommonCodeDto = new OomCommonCodeDto();
		reqOomCommonCodeDto.setCommonCd(commonCd);
		
		// 공통코드 중복체크...
		int commonCdCount = CommonObjectUtil.defaultNumber(commonCodeService.readCommonCodeDuplicationCheck(reqOomCommonCodeDto));
		if (commonCdCount > 0) {
			returnString = Const.Common.RESULT_CODE.SUCCESS;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_ALREADY_EXIST_COMMAND_CD, commonCdCount));
		} else {
			returnString = Const.Common.RESULT_CODE.SUCCESS;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, "", commonCdCount));
		}
    	
    	return resEntity;
    }
	
	/**
	 * 
	 * createCommonCode
	 *
	 * @param reqOomCommonCodeDto
	 * @return ResponseEntity
	 */
	@SuppressWarnings("rawtypes")
    @PostMapping(value="", produces="application/json; charset=UTF-8")
    public ResponseEntity createCommonCode(@AuthenticationPrincipal JwtAuthResultDto authResultDto, 
    		@RequestBody OomCommonCodeDto reqOomCommonCodeDto) throws Exception {
        
    	ResponseEntity<ResultDto> resEntity = null;
		String returnString = "";
    	
		String loginUserId = StringUtils.defaultString(authResultDto.getUserId());
		if ("".equals(loginUserId)) {
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_LOGIN_USER_ID));
			return resEntity;
		}
		String mgrYn = StringUtils.defaultString(authResultDto.getMgrYn());
		if ("".equals(mgrYn)) {
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_MGR_YN));
			return resEntity;
		}
		//String loginUserId = "tsop-admin"; // 이후 세션에서 얻어올 값...
		
		if (!"Y".equals(mgrYn)) {
			String authorityTypeCd = "";
			UserRoleMenuAuthorityRequestDto userRoleMenuAuthorityRequestDto = new UserRoleMenuAuthorityRequestDto();
			userRoleMenuAuthorityRequestDto.setUserId(loginUserId);
			userRoleMenuAuthorityRequestDto.setMenuId(MENU_ID);
			OomUserRoleAuthorityDetailDto rsltOomUserRoleAuthorityDetailDto = userRoleService.readMenuAuthority(userRoleMenuAuthorityRequestDto);
			if (rsltOomUserRoleAuthorityDetailDto != null) {
				authorityTypeCd = StringUtils.defaultString(rsltOomUserRoleAuthorityDetailDto.getAuthorityTypeCd());
			}
			if (!"W".equals(authorityTypeCd)) {
				returnString = Const.Common.RESULT_CODE.FAIL;
				resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NO_AUTH));
				return resEntity;
			}
		}
		
		String commonCd = StringUtils.defaultString(reqOomCommonCodeDto.getCommonCd());
		if ("".equals(commonCd)) {
			log.error(">>>>>> commonCd ERROR:{}", ERR_MSG_NULL_COMMON_CD);
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_COMMON_CD));
			return resEntity;
		}
		String commonCdName = StringUtils.defaultString(reqOomCommonCodeDto.getCommonCdName());
		if ("".equals(commonCdName)) {
			log.error(">>>>>> commonCdName ERROR:{}", ERR_MSG_NULL_COMMON_CD_NAME);
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_COMMON_CD_NAME));
			return resEntity;
		}
		
		reqOomCommonCodeDto.setAuditId(loginUserId);
		
		// 공통코드 등록...
		int affectRowCount = commonCodeService.createCommonCode(reqOomCommonCodeDto);
		if (affectRowCount < 1) {
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_CREATE_FAIL, affectRowCount));
		} else {
			returnString = Const.Common.RESULT_CODE.SUCCESS;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, "", affectRowCount));
		}
    	
    	return resEntity;
    }
	
	/**
	 * 
	 * readCommonCode
	 *
	 * @param commonCd
	 * @return ResponseEntity
	 */
	@SuppressWarnings("rawtypes")
    @GetMapping(value="/{commonCd}", produces="application/json; charset=UTF-8")
    public ResponseEntity readCommonCode(@PathVariable("commonCd") String commonCd) throws Exception {
        
    	ResponseEntity<ResultDto> resEntity = null;
		String returnString = "";
    	
		OomCommonCodeDto reqOomCommonCodeDto = new OomCommonCodeDto();
		reqOomCommonCodeDto.setCommonCd(commonCd);
		
		OomCommonCodeDto rsltOomCommonCodeDto = commonCodeService.readCommonCode(reqOomCommonCodeDto);
		if (rsltOomCommonCodeDto == null) {
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_READ_FAIL, rsltOomCommonCodeDto));
		} else {
			returnString = Const.Common.RESULT_CODE.SUCCESS;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, "", rsltOomCommonCodeDto));
		}
    	
    	return resEntity;
    }
	
	/**
	 * 
	 * updateCommonCode
	 *
	 * @param commonCd
	 * @param reqOomCommonCodeDto
	 * @return ResponseEntity
	 */
	@SuppressWarnings("rawtypes")
    @PutMapping(value="/{commonCd}", produces="application/json; charset=UTF-8")
    public ResponseEntity updateCommonCode(@AuthenticationPrincipal JwtAuthResultDto authResultDto, 
    		@PathVariable("commonCd") String commonCd, @RequestBody OomCommonCodeDto reqOomCommonCodeDto) throws Exception {
        
    	ResponseEntity<ResultDto> resEntity = null;
		String returnString = "";
    	
		String loginUserId = StringUtils.defaultString(authResultDto.getUserId());
		if ("".equals(loginUserId)) {
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_LOGIN_USER_ID));
			return resEntity;
		}
		String mgrYn = StringUtils.defaultString(authResultDto.getMgrYn());
		if ("".equals(mgrYn)) {
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_MGR_YN));
			return resEntity;
		}
		//String loginUserId = "tsop-admin"; // 이후 세션에서 얻어올 값...
		
		if (!"Y".equals(mgrYn)) {
			String authorityTypeCd = "";
			UserRoleMenuAuthorityRequestDto userRoleMenuAuthorityRequestDto = new UserRoleMenuAuthorityRequestDto();
			userRoleMenuAuthorityRequestDto.setUserId(loginUserId);
			userRoleMenuAuthorityRequestDto.setMenuId(MENU_ID);
			OomUserRoleAuthorityDetailDto rsltOomUserRoleAuthorityDetailDto = userRoleService.readMenuAuthority(userRoleMenuAuthorityRequestDto);
			if (rsltOomUserRoleAuthorityDetailDto != null) {
				authorityTypeCd = StringUtils.defaultString(rsltOomUserRoleAuthorityDetailDto.getAuthorityTypeCd());
			}
			if (!"W".equals(authorityTypeCd)) {
				returnString = Const.Common.RESULT_CODE.FAIL;
				resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NO_AUTH));
				return resEntity;
			}
		}
		
		String commonCdName = StringUtils.defaultString(reqOomCommonCodeDto.getCommonCdName());
		if ("".equals(commonCdName)) {
			log.error(">>>>>> commonCdName ERROR:{}", ERR_MSG_NULL_COMMON_CD_NAME);
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_COMMON_CD_NAME));
			return resEntity;
		}
		
		reqOomCommonCodeDto.setAuditId(loginUserId);
		reqOomCommonCodeDto.setCommonCd(commonCd);
		
		// 공통코드 수정...
		int affectRowCount = commonCodeService.updateCommonCode(reqOomCommonCodeDto);
		if (affectRowCount < 1) {
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_UPDATE_FAIL, affectRowCount));
		} else {
			returnString = Const.Common.RESULT_CODE.SUCCESS;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, "", affectRowCount));
		}
    	
    	return resEntity;
    }
	
	/**
	 * 
	 * deleteCommonCode
	 *
	 * @param commonCd
	 * @return ResponseEntity
	 */
	@SuppressWarnings("rawtypes")
    @DeleteMapping(value="/{commonCd}", produces="application/json; charset=UTF-8")
    public ResponseEntity deleteCommonCode(@AuthenticationPrincipal JwtAuthResultDto authResultDto, 
    		@PathVariable("commonCd") String commonCd) throws Exception {
        
    	ResponseEntity<ResultDto> resEntity = null;
		String returnString = "";
    	
		String loginUserId = StringUtils.defaultString(authResultDto.getUserId());
		if ("".equals(loginUserId)) {
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_LOGIN_USER_ID));
			return resEntity;
		}
		String mgrYn = StringUtils.defaultString(authResultDto.getMgrYn());
		if ("".equals(mgrYn)) {
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_MGR_YN));
			return resEntity;
		}
		//String loginUserId = "tsop-admin"; // 이후 세션에서 얻어올 값...
		
		if (!"Y".equals(mgrYn)) {
			String authorityTypeCd = "";
			UserRoleMenuAuthorityRequestDto userRoleMenuAuthorityRequestDto = new UserRoleMenuAuthorityRequestDto();
			userRoleMenuAuthorityRequestDto.setUserId(loginUserId);
			userRoleMenuAuthorityRequestDto.setMenuId(MENU_ID);
			OomUserRoleAuthorityDetailDto rsltOomUserRoleAuthorityDetailDto = userRoleService.readMenuAuthority(userRoleMenuAuthorityRequestDto);
			if (rsltOomUserRoleAuthorityDetailDto != null) {
				authorityTypeCd = StringUtils.defaultString(rsltOomUserRoleAuthorityDetailDto.getAuthorityTypeCd());
			}
			if (!"W".equals(authorityTypeCd)) {
				returnString = Const.Common.RESULT_CODE.FAIL;
				resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NO_AUTH));
				return resEntity;
			}
		}
		
		OomCommonCodeDto reqOomCommonCodeDto = new OomCommonCodeDto();
		reqOomCommonCodeDto.setAuditId(loginUserId);
		reqOomCommonCodeDto.setCommonCd(commonCd);
		
		// 공통코드 삭제...
		int affectRowCount = commonCodeService.deleteCommonCode(reqOomCommonCodeDto);
		if (affectRowCount < 1) {
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_DELETE_FAIL, affectRowCount));
		} else {
			returnString = Const.Common.RESULT_CODE.SUCCESS;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, "", affectRowCount));
		}
    	
    	return resEntity;
    }
	
	
	/**
	 * 
	 * listCommonCodeForCombo
	 *
	 * @param commonCodeRequestDto
	 * @return ResponseEntity
	 */
	@SuppressWarnings("rawtypes")
    @GetMapping(value="/combobox", produces="application/json; charset=UTF-8")
    public ResponseEntity listCommonCodeForCombo(CommonCodeRequestDto commonCodeRequestDto) throws Exception {
        
    	ResponseEntity<ResultDto> resEntity = null;
		String returnString = "";
    	
		// 코드 목록 조회....
		List<OomCommonCodeDto> rsltOomCommonCodeDtoList = commonCodeService.listCommonCodeForCombo(commonCodeRequestDto);
		if (CollectionUtils.isEmpty(rsltOomCommonCodeDtoList)) {
			returnString = Const.Common.RESULT_CODE.SUCCESS;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_SEARCH_RESULT_LIST, rsltOomCommonCodeDtoList));
		} else {
			returnString = Const.Common.RESULT_CODE.SUCCESS;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, "", rsltOomCommonCodeDtoList));
		}
    	
    	return resEntity;
    }
	
	/**
	 * 
	 * updateCommonCodeReuse
	 *
	 * @param authResultDto
	 * @param commonCd
	 * @return ResponseEntity
	 * @throws Exception 
	 */
	@SuppressWarnings("rawtypes")
    @PutMapping(value="/{commonCd}/reuse", produces="application/json; charset=UTF-8")
    public ResponseEntity updateCommonCodeReuse(@AuthenticationPrincipal JwtAuthResultDto authResultDto, 
    		@PathVariable("commonCd") String commonCd) throws Exception {
        
    	ResponseEntity<ResultDto> resEntity = null;
		String returnString = "";
    	
		String loginUserId = StringUtils.defaultString(authResultDto.getUserId());
		if ("".equals(loginUserId)) {
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_LOGIN_USER_ID));
			return resEntity;
		}
		String mgrYn = StringUtils.defaultString(authResultDto.getMgrYn());
		if ("".equals(mgrYn)) {
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_MGR_YN));
			return resEntity;
		}
		//String loginUserId = "tsop-admin"; // 이후 세션에서 얻어올 값...
		
		if (!"Y".equals(mgrYn)) {
			String authorityTypeCd = "";
			UserRoleMenuAuthorityRequestDto userRoleMenuAuthorityRequestDto = new UserRoleMenuAuthorityRequestDto();
			userRoleMenuAuthorityRequestDto.setUserId(loginUserId);
			userRoleMenuAuthorityRequestDto.setMenuId(MENU_ID);
			OomUserRoleAuthorityDetailDto rsltOomUserRoleAuthorityDetailDto = userRoleService.readMenuAuthority(userRoleMenuAuthorityRequestDto);
			if (rsltOomUserRoleAuthorityDetailDto != null) {
				authorityTypeCd = StringUtils.defaultString(rsltOomUserRoleAuthorityDetailDto.getAuthorityTypeCd());
			}
			if (!"W".equals(authorityTypeCd)) {
				returnString = Const.Common.RESULT_CODE.FAIL;
				resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NO_AUTH));
				return resEntity;
			}
		}
		
		OomCommonCodeDto reqOomCommonCodeDto = new OomCommonCodeDto();
		reqOomCommonCodeDto.setAuditId(loginUserId);
		reqOomCommonCodeDto.setCommonCd(commonCd);
		
		int affectRowCount = commonCodeService.updateCommonCodeReuse(reqOomCommonCodeDto);
		if (affectRowCount < 1) {
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_UPDATE_FAIL, affectRowCount));
		} else {
			returnString = Const.Common.RESULT_CODE.SUCCESS;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, "", affectRowCount));
		}
    	
    	return resEntity;
    }

}
