package com.adtcaps.tsop.onm.api.sms.service;

import com.adtcaps.tsop.onm.api.sms.domain.SmsAccessInformation;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;

/**
 * SmsAccessInformationServiceImpl.
 *
 * @author sjlee@sk.com
 */
@Service
public class SmsAccessInformationServiceImpl implements SmsAccessInformationService {
    /**
     * Logger.
     */
    private static final Logger LOGGER = LoggerFactory.getLogger(SmsAccessInformationServiceImpl.class);
    /**
     * AuthenticationService.
     */
    @Autowired
    SmsAuthenticationService smsAuthenticationService;
    /**
     * 갱신접속정보.
     */
    SmsAccessInformation smsAccessInfo;
    /**
     * SMS URL.
     */
    @Value("${sms.url}")
    private String url;
     /**
     * USER ID.
     */
    @Value("${sms.user_id}")
    private String id;
    /**
     * 접속 비밀번호.
     */
    @Value("${sms.password}")
    private String pw;
    /**
     * callback번호.
     */
    @Value("${sms.send_no}")
    private String sendNo;
    
    @Override
    //@Scheduled(cron = "${sms.scheduler.cron}")
    public SmsAccessInformation initAccessInformation() {
        LOGGER.debug("INIT_ACCESS_INFORMATION_STARTED");
        SmsAccessInformation smsAccessInformation = new SmsAccessInformation();
        smsAccessInformation.setUrl(url);
        smsAccessInformation.setUserId(id);
        smsAccessInformation.setPw(pw);
        smsAccessInformation.setSendNo(sendNo);

        LOGGER.debug("SKB_SMS_CONFIG : url={}", smsAccessInformation.toString());
        
        smsAccessInfo = smsAuthenticationService.getAuth(smsAccessInformation);
       
        return smsAccessInfo;
    }

    //접속 정보 업데이트 후, 새로 발급된 토큰 Keep-Alive
    @Scheduled(fixedDelay = 60000 * 2)
    public void getKeepAlive() {
        smsAuthenticationService.getKeepAlive(smsAccessInfo);
    }

    @Override
    public SmsAccessInformation getAccessInfo() {

        if( smsAccessInfo != null ) {
            return smsAccessInfo ;
        }
        
        return new SmsAccessInformation();
    }

    @Override
    public void updateAccessInfo(SmsAccessInformation smsAccessInformation) {
        LOGGER.debug("REQUEST_UPDATE_ACCESS_INFO : " + smsAccessInformation);
        smsAccessInfo = smsAuthenticationService.getAuth(smsAccessInformation);
        LOGGER.debug("FINISH_UPDATE_ACCESS_INFO : " + smsAccessInfo);
    }
    
}
