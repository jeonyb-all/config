package com.adtcaps.tsop.onm.api.callee.domain;

import com.adtcaps.tsop.onm.api.domain.OomTechSupportRequestBuildingDto;
import com.adtcaps.tsop.onm.api.domain.OomTechSupportRequestBuildingServiceDto;
import com.adtcaps.tsop.onm.api.domain.OomTechSupportRequestDto;
import com.adtcaps.tsop.onm.api.file.domain.BlobRequestDto;

import lombok.Getter;
import lombok.Setter;

/**
 * 
 * <ul>
 * <li>업무 그룹명 : tsop-onm-api</li>
 * <li>서브 업무명 : com.adtcaps.tsop.onm.api.callee.domain</li>
 * <li>설  명 : TechSupportRequestProcessingDto.java</li>
 * <li>작성일 : 2021. 1. 2.</li>
 * <li>작성자 : jeonyb4</li>
 * </ul>
 */
@Getter
@Setter
public class TechSupportRequestProcessingDto {
	private String tenantId;
	private OomTechSupportRequestDto techSupportRequestInfo;
	private BlobRequestDto attachFile;
	private OomTechSupportRequestBuildingDto buildingInfo;
	private OomTechSupportRequestBuildingServiceDto serviceInfo;

}
