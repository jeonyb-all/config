package com.adtcaps.tsop.onm.api.user.service;

import java.util.List;

import com.adtcaps.tsop.onm.api.domain.OomUserRoleAuthorityDetailDto;
import com.adtcaps.tsop.onm.api.domain.OomUserRoleDetailDto;
import com.adtcaps.tsop.onm.api.domain.OomUserRoleDto;
import com.adtcaps.tsop.onm.api.helper.domain.BasePageDto;
import com.adtcaps.tsop.onm.api.user.domain.UserRoleDetailResultDto;
import com.adtcaps.tsop.onm.api.user.domain.UserRoleForComboResultDto;
import com.adtcaps.tsop.onm.api.user.domain.UserRoleGridResultDto;
import com.adtcaps.tsop.onm.api.user.domain.UserRoleMenuAuthorityRequestDto;
import com.adtcaps.tsop.onm.api.user.domain.UserRoleProcessingDto;

/**
 * 
 * <ul>
 * <li>업무 그룹명 : tsop-onm-api</li>
 * <li>서브 업무명 : com.adtcaps.tsop.onm.api.user.service</li>
 * <li>설  명 : UserRoleService.java</li>
 * <li>작성일 : 2021. 1. 4.</li>
 * <li>작성자 : jeonyb4</li>
 * </ul>
 */
public interface UserRoleService {
	/**
	 * 
	 * listUserRoleForCombo
	 *
	 * @return List<UserRoleForComboResultDto>
	 * @throws Exception 
	 */
	public List<UserRoleForComboResultDto> listUserRoleForCombo() throws Exception;
	
	/**
	 * 
	 * listPageUserRole
	 *
	 * @param reqBasePageDto
	 * @return List<UserRoleGridResultDto>
	 * @throws Exception 
	 */
	public List<UserRoleGridResultDto> listPageUserRole(BasePageDto reqBasePageDto) throws Exception;
	
	/**
	 * 
	 * readUserRoleDuplicationByName
	 *
	 * @param reqOomUserRoleDto
	 * @return int
	 * @throws Exception 
	 */
	public int readUserRoleDuplicationByName(OomUserRoleDto reqOomUserRoleDto) throws Exception;
	
	/**
	 * 
	 * createUserRole
	 *
	 * @param reqUserRoleProcessingDto
	 * @return int
	 * @throws Exception 
	 */
	public int createUserRole(UserRoleProcessingDto reqUserRoleProcessingDto) throws Exception;
	
	/**
	 * 
	 * readUserRole
	 *
	 * @param reqOomUserRoleDto
	 * @return UserRoleDetailResultDto
	 * @throws Exception 
	 */
	public UserRoleDetailResultDto readUserRole(OomUserRoleDto reqOomUserRoleDto) throws Exception;
	
	/**
	 * 
	 * updateUserRole
	 *
	 * @param reUserRoleProcessingDto
	 * @return int
	 * @throws Exception 
	 */
	public int updateUserRole(UserRoleProcessingDto reUserRoleProcessingDto) throws Exception;
	
	/**
	 * 
	 * readUserRoleDetailCount
	 *
	 * @param reqOomUserRoleDetailDto
	 * @return int
	 * @throws Exception 
	 */
	public int readUserRoleDetailCount(OomUserRoleDetailDto reqOomUserRoleDetailDto) throws Exception;
	
	/**
	 * 
	 * deleteUserRole
	 *
	 * @param reqOomUserRoleDto
	 * @return int
	 * @throws Exception 
	 */
	public int deleteUserRole(OomUserRoleDto reqOomUserRoleDto) throws Exception;
	
	/**
	 * 
	 * readMenuAuthority
	 * 
	 * @param userRoleMenuAuthorityRequestDto
	 * @return OomUserRoleAuthorityDetailDto
	 * @throws Exception 
	 */
	public OomUserRoleAuthorityDetailDto readMenuAuthority(UserRoleMenuAuthorityRequestDto userRoleMenuAuthorityRequestDto) throws Exception;
	
	
	/***************************************************************************************/
	
//	/**
//	 * 
//	 * listUserRoleBuilding
//	 *
//	 * @param reqOomUserRoleDetailDetailDto
//	 * @return List<BuildingForComboResultDto>
//	 * @throws Exception 
//	 */
//	public List<BuildingForComboResultDto> listUserRoleBuilding(OomUserRoleDetailDetailDto reqOomUserRoleDetailDetailDto) throws Exception;
//	
//	/**
//	 * 
//	 * listPageUserRoleDetailDetail
//	 *
//	 * @param reqBasePageDto
//	 * @return List<UserRoleDetailDetailGridResultDto>
//	 * @throws Exception 
//	 */
////	public List<UserRoleDetailDetailGridResultDto> listPageUserRoleDetailDetail(BasePageDto reqBasePageDto) throws Exception;
	
	/**
	 * 
	 * createUserRoleDetail
	 *
	 * @param reqOomUserRoleDetailDto
	 * @return int
	 * @throws Exception 
	 */
	public int createUserRoleDetail(OomUserRoleDetailDto reqOomUserRoleDetailDto) throws Exception;
	
	/**
	 * 
	 * updateUserRoleDetail
	 *
	 * @param reqOomUserRoleDetailDto
	 * @return int
	 * @throws Exception 
	 */
	public int updateUserRoleDetail(OomUserRoleDetailDto reqOomUserRoleDetailDto) throws Exception;
	
//	/**
//	 * 
//	 * createUserRoleDetailDetail
//	 *
//	 * @param reqOomUserRoleDetailDetailDto
//	 * @return int
//	 * @throws Exception 
//	 */
//	public int createUserRoleDetailDetail(OomUserRoleDetailDetailDto reqOomUserRoleDetailDetailDto) throws Exception;
//	
//	/**
//	 * 
//	 * deleteUserRoleDetailDetail
//	 *
//	 * @param reqOomUserRoleDetailDetailDto
//	 * @return int
//	 * @throws Exception 
//	 */
//	public int deleteUserRoleDetailDetail(OomUserRoleDetailDetailDto reqOomUserRoleDetailDetailDto) throws Exception;

}
