package com.adtcaps.tsop.onm.api.tenant.domain;

import com.adtcaps.tsop.onm.api.helper.domain.BasePageDto;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

import lombok.Getter;
import lombok.Setter;

/**
 * 
 * <ul>
 * <li>업무 그룹명 : tsop-onm-api</li>
 * <li>서브 업무명 : com.adtcaps.tsop.onm.api.tenant.domain</li>
 * <li>설  명 : TenantGridResultDto.java</li>
 * <li>작성일 : 2021. 1. 5.</li>
 * <li>작성자 : jeonyb4</li>
 * </ul>
 */
@Getter
@Setter
@JsonInclude(Include.NON_EMPTY)
public class TenantGridResultDto extends BasePageDto {
	private Integer rowNum;
	private String tenantId;
	private String tenantName;
	private String userId;
	private String userName;
	private String emailAddr;
	private Integer bldCount;
	private Integer resourceCount;
	private String deleteYn;
	private String registDate;

}
