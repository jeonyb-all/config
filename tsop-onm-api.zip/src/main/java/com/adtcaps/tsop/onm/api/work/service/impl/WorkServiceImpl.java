package com.adtcaps.tsop.onm.api.work.service.impl;

import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.CollectionUtils;

import com.adtcaps.tsop.onm.api.building.domain.TenantBuildingGridResultDto;
import com.adtcaps.tsop.onm.api.building.service.BuildingService;
import com.adtcaps.tsop.onm.api.building.service.BuildingServiceService;
import com.adtcaps.tsop.onm.api.deploy.service.PackageDeployJobService;
import com.adtcaps.tsop.onm.api.domain.OomBuildingDto;
import com.adtcaps.tsop.onm.api.domain.OomBuildingServiceConnectionDto;
import com.adtcaps.tsop.onm.api.domain.OomBuildingServiceConnectionIpDto;
import com.adtcaps.tsop.onm.api.domain.OomPackageDeployJobDto;
import com.adtcaps.tsop.onm.api.domain.OomTechSupportRequestDto;
import com.adtcaps.tsop.onm.api.domain.OomTenantDto;
import com.adtcaps.tsop.onm.api.domain.OomTenantResourceDetailDto;
import com.adtcaps.tsop.onm.api.domain.OomTenantResourceDto;
import com.adtcaps.tsop.onm.api.domain.OomWorkBuildingDto;
import com.adtcaps.tsop.onm.api.domain.OomWorkBuildingServiceConenctionDto;
import com.adtcaps.tsop.onm.api.domain.OomWorkBuildingServiceConnectionIpDto;
import com.adtcaps.tsop.onm.api.domain.OomWorkDto;
import com.adtcaps.tsop.onm.api.domain.OomWorkStatusCodeDto;
import com.adtcaps.tsop.onm.api.domain.OomWorkStatusDto;
import com.adtcaps.tsop.onm.api.domain.OomWorkTenantDto;
import com.adtcaps.tsop.onm.api.domain.OomWorkTenantResourceDetailDto;
import com.adtcaps.tsop.onm.api.domain.OomWorkTenantResourceDto;
import com.adtcaps.tsop.onm.api.helper.constant.Const;
import com.adtcaps.tsop.onm.api.helper.util.CommonDateUtil;
import com.adtcaps.tsop.onm.api.helper.util.CommonObjectUtil;
import com.adtcaps.tsop.onm.api.support.service.SupportService;
import com.adtcaps.tsop.onm.api.tenant.service.TenantResourceService;
import com.adtcaps.tsop.onm.api.tenant.service.TenantService;
import com.adtcaps.tsop.onm.api.work.domain.WorkGridRequestDto;
import com.adtcaps.tsop.onm.api.work.domain.WorkGridResultDto;
import com.adtcaps.tsop.onm.api.work.domain.WorkProcessingResultDto;
import com.adtcaps.tsop.onm.api.work.domain.WorkRegisterDto;
import com.adtcaps.tsop.onm.api.work.domain.WorkStatusCodeForComboResultDto;
import com.adtcaps.tsop.onm.api.work.domain.WorkStatusMenuResultDto;
import com.adtcaps.tsop.onm.api.work.mapper.OomWorkBuildingMapper;
import com.adtcaps.tsop.onm.api.work.mapper.OomWorkBuildingServiceConenctionMapper;
import com.adtcaps.tsop.onm.api.work.mapper.OomWorkBuildingServiceConnectionIpMapper;
import com.adtcaps.tsop.onm.api.work.mapper.OomWorkMapper;
import com.adtcaps.tsop.onm.api.work.mapper.OomWorkStatusCodeMapper;
import com.adtcaps.tsop.onm.api.work.mapper.OomWorkStatusMapper;
import com.adtcaps.tsop.onm.api.work.mapper.OomWorkTenantMapper;
import com.adtcaps.tsop.onm.api.work.mapper.OomWorkTenantResourceDetailMapper;
import com.adtcaps.tsop.onm.api.work.mapper.OomWorkTenantResourceMapper;
import com.adtcaps.tsop.onm.api.work.service.WorkService;

/**
 * 
 * <ul>
 * <li>업무 그룹명 : tsop-onm-api</li>
 * <li>서브 업무명 : com.adtcaps.tsop.onm.api.work.service.impl</li>
 * <li>설  명 : WorkServiceImpl.java</li>
 * <li>작성일 : 2021. 1. 27.</li>
 * <li>작성자 : jeonyb4</li>
 * </ul>
 */
@Transactional
@Service
public class WorkServiceImpl implements WorkService {
	
	@Autowired
	private OomWorkMapper oomWorkMapper;
	
	@Autowired
	private OomWorkStatusCodeMapper oomWorkStatusCodeMapper;
	
	@Autowired
	private OomWorkStatusMapper oomWorkStatusMapper;
	
	@Autowired
	private OomWorkTenantMapper oomWorkTenantMapper;
	
	@Autowired
	private OomWorkTenantResourceDetailMapper oomWorkTenantResourceDetailMapper;
	
	@Autowired
	private OomWorkTenantResourceMapper oomWorkTenantResourceMapper;
	
	@Autowired
	private OomWorkBuildingMapper oomWorkBuildingMapper;
	
	@Autowired
	private OomWorkBuildingServiceConenctionMapper oomWorkBuildingServiceConenctionMapper;
	
	@Autowired
	private OomWorkBuildingServiceConnectionIpMapper oomWorkBuildingServiceConnectionIpMapper;
	
	@Autowired
	private TenantService tenantService;
	
	@Autowired
	private TenantResourceService tenantResourceService;
	
	@Autowired
	private BuildingService buildingService;
	
	@Autowired
	private BuildingServiceService buildingServiceService;
	
	@Autowired
	private PackageDeployJobService packageDeployJobService;
	
	@Autowired
	private SupportService supportService;
	
	/**
	 * 
	 * listWorkStatusCodeForCombo
	 *
	 * @param reqOomWorkStatusCodeDto
	 * @return List<WorkStatusCodeForComboResultDto>
	 * @throws Exception 
	 */
	@Override
	public List<WorkStatusCodeForComboResultDto> listWorkStatusCodeForCombo(OomWorkStatusCodeDto reqOomWorkStatusCodeDto) throws Exception {
		
		List<WorkStatusCodeForComboResultDto> workStatusCodeForComboResultDtoList = null;
		try {
			workStatusCodeForComboResultDtoList = oomWorkStatusCodeMapper.listWorkStatusCodeForCombo(reqOomWorkStatusCodeDto);
    		
		} catch (Exception e) {
			throw e;
		}
		return workStatusCodeForComboResultDtoList;
	}
	
	/**
	 * 
	 * listPageWork
	 *
	 * @param workGridRequestDto
	 * @return List<WorkGridResultDto>
	 * @throws Exception 
	 */
	@Override
	public List<WorkGridResultDto> listPageWork(WorkGridRequestDto workGridRequestDto) throws Exception {
		
		List<WorkGridResultDto> workGridResultDtoList = null;
		try {
			String fromDate = StringUtils.defaultString(workGridRequestDto.getFromDate());
    		String toDate = StringUtils.defaultString(workGridRequestDto.getToDate());
    		
    		fromDate = CommonDateUtil.makeFromDatetime(fromDate);
    		toDate = CommonDateUtil.makeToDatetime(toDate);
    		
    		workGridRequestDto.setFromDate(fromDate);
    		workGridRequestDto.setToDate(toDate);
    		
    		workGridResultDtoList = oomWorkMapper.listPageWork(workGridRequestDto);
    		if (!CollectionUtils.isEmpty(workGridResultDtoList)) {
    			for (int idx = 0; idx < workGridResultDtoList.size(); idx++) {
    				
    				WorkGridResultDto workGridResultDto = workGridResultDtoList.get(idx);
    				
    				String registDatetime = StringUtils.defaultString(workGridResultDto.getRegistDatetime());
    				registDatetime = CommonDateUtil.makeDatetimeFormat(registDatetime);
    				workGridResultDto.setRegistDatetime(registDatetime);
    				
    				String workEndDatetime = StringUtils.defaultString(workGridResultDto.getWorkEndDatetime());
    				workEndDatetime = CommonDateUtil.makeDatetimeFormat(workEndDatetime);
    				workGridResultDto.setWorkEndDatetime(workEndDatetime);
    				
    				String registerName = StringUtils.defaultString(workGridResultDto.getRegisterName());
    				if ("".equals(registerName)) {
    					workGridResultDto.setRegisterName(workGridResultDto.getRegisterId());
    				}
    				
    				workGridResultDtoList.set(idx, workGridResultDto);
    			}
    		}
    		
		} catch (Exception e) {
			throw e;
		}
		return workGridResultDtoList;
	}
	
	/**
	 * 
	 * readWork
	 *
	 * @param reqOomWorkDto
	 * @return OomWorkDto
	 * @throws Exception 
	 */
	@Override
	public OomWorkDto readWork(OomWorkDto reqOomWorkDto) throws Exception {
		
		OomWorkDto rsltOomWorkDto = null;
		try {
			rsltOomWorkDto = oomWorkMapper.readOomWork(reqOomWorkDto);
    		
		} catch (Exception e) {
			throw e;
		}
		return rsltOomWorkDto;
	}
	
	/**
	 * 
	 * createWork
	 *
	 * @param reqWorkRegisterDto
	 * @return WorkProcessingResultDto
	 * @throws Exception 
	 */
	@Transactional(rollbackFor={Exception.class, DataIntegrityViolationException.class})
	@Override
	public WorkProcessingResultDto createWork(WorkRegisterDto reqWorkRegisterDto) throws Exception {
		
		WorkProcessingResultDto workProcessingResultDto = null;
		
		try {
			String onmWorkTypeCd = StringUtils.defaultString(reqWorkRegisterDto.getOnmWorkTypeCd());
			String auditId = StringUtils.defaultString(reqWorkRegisterDto.getAuditId());
			int techSupportReqId = CommonObjectUtil.defaultNumber(reqWorkRegisterDto.getTechSupportReqId());
			
			// 등록 시 최초 작업상태코드 / 작업상태상세코드 setting...
			String onmWorkStatusCd = "";
			String onmWorkStatusDetailCd = "";
			if (Const.Code.WORK_TYPE_CD.RT.equals(onmWorkTypeCd)) {
				onmWorkStatusCd = Const.Code.WORK_STATUS_CD.RTTN;
				onmWorkStatusDetailCd = Const.Code.WORK_STATUS_DETAIL_CD.TN01;
    		} else if (Const.Code.WORK_TYPE_CD.RB.equals(onmWorkTypeCd)) {
    			onmWorkStatusCd = Const.Code.WORK_STATUS_CD.RBBD;
    			onmWorkStatusDetailCd = Const.Code.WORK_STATUS_DETAIL_CD.BD01;
    		} else if (Const.Code.WORK_TYPE_CD.RS.equals(onmWorkTypeCd)) {
    			onmWorkStatusCd = Const.Code.WORK_STATUS_CD.RSSV;
    			onmWorkStatusDetailCd = Const.Code.WORK_STATUS_DETAIL_CD.SV01;
    		} else if (Const.Code.WORK_TYPE_CD.CB.equals(onmWorkTypeCd)) {
    			onmWorkStatusCd = Const.Code.WORK_STATUS_CD.CBBD;
    			onmWorkStatusDetailCd = Const.Code.WORK_STATUS_DETAIL_CD.BD01;
    		} else if (Const.Code.WORK_TYPE_CD.CI.equals(onmWorkTypeCd)) {
    			onmWorkStatusCd = Const.Code.WORK_STATUS_CD.CISI;
    			onmWorkStatusDetailCd = Const.Code.WORK_STATUS_DETAIL_CD.SI01;
    		} else if (Const.Code.WORK_TYPE_CD.DP.equals(onmWorkTypeCd)) {
    			onmWorkStatusCd = Const.Code.WORK_STATUS_CD.DPVF;
    		} else if (Const.Code.WORK_TYPE_CD.DS.equals(onmWorkTypeCd)) {
    			onmWorkStatusCd = Const.Code.WORK_STATUS_CD.DSSI;
    			onmWorkStatusDetailCd = Const.Code.WORK_STATUS_DETAIL_CD.SI01;
			} else if (Const.Code.WORK_TYPE_CD.DB.equals(onmWorkTypeCd)) {
				onmWorkStatusCd = Const.Code.WORK_STATUS_CD.DBSI;
				onmWorkStatusDetailCd = Const.Code.WORK_STATUS_DETAIL_CD.SI01;
			} else if (Const.Code.WORK_TYPE_CD.DT.equals(onmWorkTypeCd)) {
				onmWorkStatusCd = Const.Code.WORK_STATUS_CD.DTSI;
				onmWorkStatusDetailCd = Const.Code.WORK_STATUS_DETAIL_CD.SI01;
			}
			
			reqWorkRegisterDto.setOnmWorkStatusCd(onmWorkStatusCd);
			
			// 작업 등록...
			oomWorkMapper.createOomWork(reqWorkRegisterDto);
			
			// 전체 작업메뉴 일괄 등록...
			int onmWorkId = reqWorkRegisterDto.getOnmWorkId();
			OomWorkStatusDto reqOomWorkStatusDto = new OomWorkStatusDto();
			reqOomWorkStatusDto.setOnmWorkId(onmWorkId);
			reqOomWorkStatusDto.setOnmWorkTypeCd(onmWorkTypeCd);
			reqOomWorkStatusDto.setAuditId(auditId);
			oomWorkStatusMapper.createOomWorkStatus(reqOomWorkStatusDto);
			
			if (techSupportReqId > 0) {
				// 기술지원요청에 의한 작업등록이면...
				if (Const.Code.WORK_TYPE_CD.RS.equals(onmWorkTypeCd)) {
					// 서비스 추가 작업이면... 현재메뉴(RSSV) 상태는 강제 완료 시키고.. 
					reqOomWorkStatusDto.setOnmWorkStatusCd(onmWorkStatusCd);
					reqOomWorkStatusDto.setOnmWorkStatusDetailCd(onmWorkStatusDetailCd);
					reqOomWorkStatusDto.setOnmWorkStatusFinishCd(Const.Code.WORK_STATUS_FINISH_CD.FINISH);
					oomWorkStatusMapper.updateOomWorkStatusFinishCode(reqOomWorkStatusDto);
					
					// 현재메뉴 RSSI를 진행 상태로 만든다..
					onmWorkStatusCd = Const.Code.WORK_STATUS_CD.RSSI;
					onmWorkStatusDetailCd = Const.Code.WORK_STATUS_DETAIL_CD.SI01;
				}
			} else {
				// 사전정보 생성이 필요한 작업들...
				if (Const.Code.WORK_TYPE_CD.DT.equals(onmWorkTypeCd)) {
					createWorkTenant(reqWorkRegisterDto);
					createWorkTenantResource(reqWorkRegisterDto);
					
					String tenantId = reqWorkRegisterDto.getTenantId();
					OomBuildingDto reqOomBuildingDto = new OomBuildingDto();
					reqOomBuildingDto.setTenantId(tenantId);
					List<TenantBuildingGridResultDto> tenantBuildingGridResultDtoList = buildingService.listTenantBuildingForWork(reqOomBuildingDto);
					if (!CollectionUtils.isEmpty(tenantBuildingGridResultDtoList)) {
						int hitBuildingCount = 0;
						int hitServiceCount = 0;
						for (TenantBuildingGridResultDto tenantBuildingGridResultDto : tenantBuildingGridResultDtoList) {
							String bldId = StringUtils.defaultString(tenantBuildingGridResultDto.getBldId());
							reqWorkRegisterDto.setBldId(bldId);
							int hitCount = createWorkBuilding(reqWorkRegisterDto);
							hitBuildingCount = hitBuildingCount + hitCount;
							hitCount = createWorkBuildingServiceConnection(reqWorkRegisterDto);
							hitServiceCount = hitServiceCount + hitCount;
						}
						if (hitBuildingCount < 1) {
							throw new Exception("[작업오류] : 테넌트별 빌딩 정보가 없으므로 작업을 더이상 진행할 수 없습니다.");
						}
						if (hitServiceCount < 1) {
							throw new Exception("[작업오류] : 테넌트별 서비스 연동정보가 없으므로 작업을 더이상 진행할 수 없습니다.");
						}
					}
				} else if (Const.Code.WORK_TYPE_CD.DB.equals(onmWorkTypeCd)) {
					int hitBuildingCount = createWorkBuilding(reqWorkRegisterDto);
					if (hitBuildingCount < 1) {
						throw new Exception("[작업오류] : 테넌트별 빌딩 정보가 없으므로 작업을 더이상 진행할 수 없습니다.");
					}
					int hitServiceCount = createWorkBuildingServiceConnection(reqWorkRegisterDto);
					if (hitServiceCount < 1) {
						throw new Exception("[작업오류] : 테넌트별 서비스 연동정보가 없으므로 작업을 더이상 진행할 수 없습니다.");
					}
				} else if (Const.Code.WORK_TYPE_CD.DS.equals(onmWorkTypeCd)) {
					int hitServiceCount = createWorkBuildingServiceConnection(reqWorkRegisterDto);
					if (hitServiceCount < 1) {
						throw new Exception("[작업오류] : 테넌트별 서비스 연동정보가 없으므로 작업을 더이상 진행할 수 없습니다.");
					}
				} else if (Const.Code.WORK_TYPE_CD.CB.equals(onmWorkTypeCd)) {
					int hitBuildingCount = createWorkBuilding(reqWorkRegisterDto);
					if (hitBuildingCount < 1) {
						throw new Exception("[작업오류] : 테넌트별 빌딩 정보가 없으므로 작업을 더이상 진행할 수 없습니다.");
					}
				} else if (Const.Code.WORK_TYPE_CD.CI.equals(onmWorkTypeCd)) {
					int hitServiceCount = createWorkBuildingServiceConnection(reqWorkRegisterDto);
					if (hitServiceCount < 1) {
						throw new Exception("[작업오류] : 테넌트별 서비스 연동정보가 없으므로 작업을 더이상 진행할 수 없습니다.");
					}
				}
			}
			
			// 현재메뉴를 진행 상태로 만든다..
			reqOomWorkStatusDto.setOnmWorkStatusCd(onmWorkStatusCd);
			reqOomWorkStatusDto.setOnmWorkStatusDetailCd(onmWorkStatusDetailCd);
			reqOomWorkStatusDto.setOnmWorkStatusFinishCd(Const.Code.WORK_STATUS_FINISH_CD.PROCESSING);
			oomWorkStatusMapper.updateOomWorkStatusFinishCode(reqOomWorkStatusDto);
			
			// 작업의 최종상태 수정..
			OomWorkDto reqOomWorkDto = new OomWorkDto();
			BeanUtils.copyProperties(reqWorkRegisterDto, reqOomWorkDto);
			reqOomWorkDto.setOnmWorkStatusCd(onmWorkStatusCd);
			updateWorkCurrentStatus(reqOomWorkDto);
			
			workProcessingResultDto = new WorkProcessingResultDto();
			workProcessingResultDto.setOnmWorkId(onmWorkId);
			workProcessingResultDto.setOnmWorkTypeCd(onmWorkTypeCd);
			workProcessingResultDto.setCurrentWorkStatusCd(onmWorkStatusCd);
			
		} catch (Exception e) {
			throw e;
		}
		
		return workProcessingResultDto;
	}
	
	/**
	 * 
	 * createWorkTenant
	 *
	 * @param reqWorkRegisterDto
	 * @throws Exception void
	 */
	private void createWorkTenant(WorkRegisterDto reqWorkRegisterDto) throws Exception {
		try {
			// 테넌트 등록 처리...
			int onmWorkId = reqWorkRegisterDto.getOnmWorkId();
			String onmWorkTypeCd = StringUtils.defaultString(reqWorkRegisterDto.getOnmWorkTypeCd());
			String auditId = StringUtils.defaultString(reqWorkRegisterDto.getAuditId());
			String tenantId = StringUtils.defaultString(reqWorkRegisterDto.getTenantId());
			OomTenantDto reqOomTenantDto = new OomTenantDto();
			reqOomTenantDto.setTenantId(tenantId);
			OomTenantDto rsltOomTenantDto = tenantService.readTenantForWork(reqOomTenantDto);
			if (rsltOomTenantDto == null) {
				throw new Exception("[작업오류] : 테넌트 정보가 없으므로 작업을 더이상 진행할 수 없습니다.");
			}
			OomWorkTenantDto reqOomWorkTenantDto = new OomWorkTenantDto();
			BeanUtils.copyProperties(rsltOomTenantDto, reqOomWorkTenantDto);
			reqOomWorkTenantDto.setOnmWorkId(onmWorkId);
			reqOomWorkTenantDto.setAuditId(auditId);
			
			String prefixOneWorkTypeCd = StringUtils.substring(onmWorkTypeCd, 0, 1);
			if ("D".equals(prefixOneWorkTypeCd)) {
				// 삭제작업의 경우...
				reqOomWorkTenantDto.setUseYn("N");
			} else {
				reqOomWorkTenantDto.setUseYn("Y");
			}
			
			oomWorkTenantMapper.mergeOomWorkTenant(reqOomWorkTenantDto);
			
		} catch (Exception e) {
			throw e;
		}
	}
	
	/**
	 * 
	 * createWorkTenantResource
	 *
	 * @param reqWorkRegisterDto
	 * @throws Exception void
	 */
	private void createWorkTenantResource(WorkRegisterDto reqWorkRegisterDto) throws Exception {
		try {
			// 테넌트 자원 등록 처리...
			int onmWorkId = reqWorkRegisterDto.getOnmWorkId();
			String onmWorkTypeCd = StringUtils.defaultString(reqWorkRegisterDto.getOnmWorkTypeCd());
			String auditId = StringUtils.defaultString(reqWorkRegisterDto.getAuditId());
			String tenantId = StringUtils.defaultString(reqWorkRegisterDto.getTenantId());
			OomTenantResourceDto reqOomTenantResourceDto = new OomTenantResourceDto();
			reqOomTenantResourceDto.setTenantId(tenantId);
			OomTenantResourceDto rsltOomTenantResourceDto = tenantResourceService.readTenantResourceForWork(reqOomTenantResourceDto);
			if (rsltOomTenantResourceDto == null) {
				throw new Exception("[작업오류] : 테넌트별 리소스 정보가 없으므로 작업을 더이상 진행할 수 없습니다.");
			}
			OomWorkTenantResourceDto reqOomWorkTenantResourceDto = new OomWorkTenantResourceDto();
			BeanUtils.copyProperties(rsltOomTenantResourceDto, reqOomWorkTenantResourceDto);
			reqOomWorkTenantResourceDto.setOnmWorkId(onmWorkId);
			reqOomWorkTenantResourceDto.setAuditId(auditId);
			
			String prefixOneWorkTypeCd = StringUtils.substring(onmWorkTypeCd, 0, 1);
			if ("D".equals(prefixOneWorkTypeCd)) {
				// 삭제작업의 경우...
				reqOomWorkTenantResourceDto.setUseYn("N");
			} else {
				reqOomWorkTenantResourceDto.setUseYn("Y");
			}
			
			oomWorkTenantResourceMapper.mergeOomWorkTenantResource(reqOomWorkTenantResourceDto);
			
			// 테넌트 자원상세 등록 처리...
			OomTenantResourceDetailDto reqOomTenantResourceDetailDto = new OomTenantResourceDetailDto();
			reqOomTenantResourceDetailDto.setTenantId(tenantId);
			List<OomTenantResourceDetailDto> rsltOomTenantResourceDetailDtoList = tenantResourceService.listTenantResourceDetailForWork(reqOomTenantResourceDetailDto);
			if (!CollectionUtils.isEmpty(rsltOomTenantResourceDetailDtoList)) {
				
				for (OomTenantResourceDetailDto rsltOomTenantResourceDetailDto : rsltOomTenantResourceDetailDtoList) {
					OomWorkTenantResourceDetailDto reqOomWorkTenantResourceDetailDto = new OomWorkTenantResourceDetailDto();
					BeanUtils.copyProperties(rsltOomTenantResourceDetailDto, reqOomWorkTenantResourceDetailDto);
					reqOomWorkTenantResourceDetailDto.setOnmWorkId(onmWorkId);
					reqOomWorkTenantResourceDetailDto.setAuditId(auditId);
					reqOomWorkTenantResourceDetailDto.setRegisterId(auditId);
					oomWorkTenantResourceDetailMapper.createOomWorkTenantResourceDetail(reqOomWorkTenantResourceDetailDto);
				}
			}
			
		} catch (Exception e) {
			throw e;
		}
	}
	
	/**
	 * 
	 * createWorkBuilding
	 *
	 * @param reqWorkRegisterDto
	 * @throws Exception void
	 */
	@Override
	public int createWorkBuilding(WorkRegisterDto reqWorkRegisterDto) throws Exception {
		
		int hitCount = 0;
		
		try {
			// 빌딩 등록 처리...
			int onmWorkId = reqWorkRegisterDto.getOnmWorkId();
			String onmWorkTypeCd = StringUtils.defaultString(reqWorkRegisterDto.getOnmWorkTypeCd());
			String auditId = StringUtils.defaultString(reqWorkRegisterDto.getAuditId());
			String tenantId = StringUtils.defaultString(reqWorkRegisterDto.getTenantId());
			String bldId = StringUtils.defaultString(reqWorkRegisterDto.getBldId());
			OomBuildingDto reqOomBuildingDto = new OomBuildingDto();
			reqOomBuildingDto.setTenantId(tenantId);
			reqOomBuildingDto.setBldId(bldId);
			OomBuildingDto rsltOomBuildingDto = buildingService.readBuilding(reqOomBuildingDto);
			if (rsltOomBuildingDto == null) {
				return 0;
			} else {
				hitCount = 1;
			}
			OomWorkBuildingDto reqOomWorkBuildingDto = new OomWorkBuildingDto();
			BeanUtils.copyProperties(rsltOomBuildingDto, reqOomWorkBuildingDto);
			reqOomWorkBuildingDto.setOnmWorkId(onmWorkId);
			reqOomWorkBuildingDto.setAuditId(auditId);
			
			String prefixOneWorkTypeCd = StringUtils.substring(onmWorkTypeCd, 0, 1);
			if ("D".equals(prefixOneWorkTypeCd)) {
				// 삭제작업의 경우...
				reqOomWorkBuildingDto.setUseYn("N");
			} else {
				reqOomWorkBuildingDto.setUseYn("Y");
			}
			
			mergeWorkBuilding(reqOomWorkBuildingDto);
			
		} catch (Exception e) {
			throw e;
		}
		
		return hitCount;
	}
	
	/**
	 * 
	 * updateWorkCurrentStatus
	 *
	 * @param reqOomWorkDto
	 * @return int
	 * @throws Exception 
	 */
	@Override
	public int updateWorkCurrentStatus(OomWorkDto reqOomWorkDto) throws Exception {
		
		int affectRowCount = 0;
		
		try {
			// 작업의 현재상태 수정...
			int updateRow = oomWorkMapper.updateOomWorkCurrentStatus(reqOomWorkDto);
			affectRowCount = affectRowCount + updateRow;
			
		} catch (Exception e) {
			throw e;
		}
		
		return affectRowCount;
	}
	
	/**
	 * 
	 * updateWorkEndDate
	 *
	 * @param reqOomWorkBuildingDto
	 * @return int
	 * @throws Exception 
	 */
	@Override
	public int updateWorkEndDate(OomWorkDto reqOomWorkDto) throws Exception {
		
		int affectRowCount = 0;
		
		try {
			// 작업 종료일자 수정...
			int updateRow = oomWorkMapper.updateOomWorkEndDate(reqOomWorkDto);
			affectRowCount = affectRowCount + updateRow;
			
		} catch (Exception e) {
			throw e;
		}
		
		return affectRowCount;
	}
	
	/****************************** 기술지원요청을 위한 내용 ************************************/
	
	/**
	 * 
	 * mergeWorkBuilding
	 *
	 * @param reqOomWorkBuildingDto
	 * @return int
	 * @throws Exception 
	 */
	@Override
	public int mergeWorkBuilding(OomWorkBuildingDto reqOomWorkBuildingDto) throws Exception {
		
		int affectRowCount = 0;
		
		try {
			// 작업별 건물내역 등록...
			int mergeRow = oomWorkBuildingMapper.mergeOomWorkBuilding(reqOomWorkBuildingDto);
			affectRowCount = affectRowCount + mergeRow;
			
		} catch (Exception e) {
			throw e;
		}
		
		return affectRowCount;
	}
	
	/**
	 * 
	 * mergeWorkBuildingServiceConenction
	 *
	 * @param reqOomWorkBuildingServiceConenctionDto
	 * @return int
	 * @throws Exception 
	 */
	@Override
	public int mergeWorkBuildingServiceConenction(OomWorkBuildingServiceConenctionDto reqOomWorkBuildingServiceConenctionDto) throws Exception {
		
		int affectRowCount = 0;
		
		try {
			// 작업별 서비스 Connection 등록...
			int mergeRow = oomWorkBuildingServiceConenctionMapper.mergeOomWorkBuildingServiceConenction(reqOomWorkBuildingServiceConenctionDto);
			affectRowCount = affectRowCount + mergeRow;
			
		} catch (Exception e) {
			throw e;
		}
		
		return affectRowCount;
	}
	
	/**
	 * 
	 * createWorkBuildingServiceConnection
	 *
	 * @param reqWorkRegisterDto
	 * @throws Exception void
	 */
	@Override
	public int createWorkBuildingServiceConnection(WorkRegisterDto reqWorkRegisterDto) throws Exception {
		
		int hitCount = 0;
		
		try {
			// 서비스 Connection 등록 처리...
			int onmWorkId = reqWorkRegisterDto.getOnmWorkId();
			String onmWorkTypeCd = StringUtils.defaultString(reqWorkRegisterDto.getOnmWorkTypeCd());
			String auditId = StringUtils.defaultString(reqWorkRegisterDto.getAuditId());
			String bldId = StringUtils.defaultString(reqWorkRegisterDto.getBldId());
			OomBuildingServiceConnectionDto reqOomBuildingServiceConnectionDto = new OomBuildingServiceConnectionDto();
			reqOomBuildingServiceConnectionDto.setBldId(bldId);
			
			String prefixOneWorkTypeCd = StringUtils.substring(onmWorkTypeCd, 0, 1);
			if (Const.Code.WORK_TYPE_CD.CI.equals(onmWorkTypeCd) || Const.Code.WORK_TYPE_CD.DS.equals(onmWorkTypeCd)) {
				String serviceClCd = StringUtils.defaultString(reqWorkRegisterDto.getServiceClCd());
				reqOomBuildingServiceConnectionDto.setServiceClCd(serviceClCd);
			}
			List<OomBuildingServiceConnectionDto> rsltOomBuildingServiceConnectionDtoList = buildingServiceService.listBuildingServiceConnection(reqOomBuildingServiceConnectionDto);
			if (CollectionUtils.isEmpty(rsltOomBuildingServiceConnectionDtoList)) {
				return 0;
			} else {
				for (OomBuildingServiceConnectionDto rsltOomBuildingServiceConnectionDto : rsltOomBuildingServiceConnectionDtoList) {
					OomWorkBuildingServiceConenctionDto reqOomWorkBuildingServiceConenctionDto = new OomWorkBuildingServiceConenctionDto();
					BeanUtils.copyProperties(rsltOomBuildingServiceConnectionDto, reqOomWorkBuildingServiceConenctionDto);
					reqOomWorkBuildingServiceConenctionDto.setOnmWorkId(onmWorkId);
					reqOomWorkBuildingServiceConenctionDto.setAuditId(auditId);
					reqOomWorkBuildingServiceConenctionDto.setWebAppUseYn("Y");
					reqOomWorkBuildingServiceConenctionDto.setServiceSysLinkageMethodCd(reqOomWorkBuildingServiceConenctionDto.getProtocolTypeCd());
					if ("D".equals(prefixOneWorkTypeCd)) {
						// 삭제작업의 경우...
						reqOomWorkBuildingServiceConenctionDto.setUseYn("N");
					} else {
						reqOomWorkBuildingServiceConenctionDto.setUseYn("Y");
					}
					// Connection 정보 등록...
					mergeWorkBuildingServiceConenction(reqOomWorkBuildingServiceConenctionDto);
					
					String serviceClCd = StringUtils.defaultString(rsltOomBuildingServiceConnectionDto.getServiceClCd());
					OomBuildingServiceConnectionIpDto reqOomBuildingServiceConnectionIpDto = new OomBuildingServiceConnectionIpDto();
					reqOomBuildingServiceConnectionIpDto.setBldId(bldId);
					reqOomBuildingServiceConnectionIpDto.setServiceClCd(serviceClCd);
					List<OomBuildingServiceConnectionIpDto> rsltOomBuildingServiceConnectionIpDtoList = buildingServiceService.listBuildingServiceConnectionIp(reqOomBuildingServiceConnectionIpDto);
					if (!CollectionUtils.isEmpty(rsltOomBuildingServiceConnectionIpDtoList)) {
						for (OomBuildingServiceConnectionIpDto rsltOomBuildingServiceConnectionIpDto : rsltOomBuildingServiceConnectionIpDtoList) {
							OomWorkBuildingServiceConnectionIpDto reqOomWorkBuildingServiceConnectionIpDto = new OomWorkBuildingServiceConnectionIpDto();
							BeanUtils.copyProperties(rsltOomBuildingServiceConnectionIpDto, reqOomWorkBuildingServiceConnectionIpDto);
							reqOomWorkBuildingServiceConnectionIpDto.setOnmWorkId(onmWorkId);
							reqOomWorkBuildingServiceConnectionIpDto.setAuditId(auditId);
							// Connection IP 정보 등록...
							oomWorkBuildingServiceConnectionIpMapper.mergeOomWorkBuildingServiceConnectionIp(reqOomWorkBuildingServiceConnectionIpDto);
						}
					}
				}
				hitCount = 1;
			}
		} catch (Exception e) {
			throw e;
		}
		
		return hitCount;
	}
	
	/**
	 * 
	 * deleteWork
	 *
	 * @param reqOomWorkDto
	 * @return int
	 * @throws Exception 
	 */
	@Transactional(rollbackFor={Exception.class, DataIntegrityViolationException.class})
	@Override
	public int deleteWork(OomWorkDto reqOomWorkDto) throws Exception {
		
		int affectRowCount = 0;
		
		try {
			int onmWorkId = reqOomWorkDto.getOnmWorkId();
			String auditId = StringUtils.defaultString(reqOomWorkDto.getAuditId());
			String tenantId = StringUtils.defaultString(reqOomWorkDto.getTenantId());
			
			// 기술지원요청 상태 신청 처리...
			int techSupportReqId = CommonObjectUtil.defaultNumber(reqOomWorkDto.getTechSupportReqId());
			if (techSupportReqId > 0) {
				OomTechSupportRequestDto reqOomTechSupportRequestDto = new OomTechSupportRequestDto();
				reqOomTechSupportRequestDto.setTenantId(tenantId);
				reqOomTechSupportRequestDto.setTechSupportReqId(techSupportReqId);
				reqOomTechSupportRequestDto.setTechSupportStatusCd(Const.Code.TECH_SUPPORT_STATUS_CD.REQUEST);
				reqOomTechSupportRequestDto.setAuditId(auditId);
				supportService.updateTechSupportStatus(reqOomTechSupportRequestDto);
			}
			
			// 해당 작업 ALL 삭제...
			OomPackageDeployJobDto reqOomPackageDeployJobDto = new OomPackageDeployJobDto();
			reqOomPackageDeployJobDto.setOnmWorkId(onmWorkId);
			int deleteRow = packageDeployJobService.deleteOomPackageDeployJob(reqOomPackageDeployJobDto);
			affectRowCount = affectRowCount + deleteRow;
			
			OomWorkTenantResourceDetailDto reqOomWorkTenantResourceDetailDto = new OomWorkTenantResourceDetailDto();
			reqOomWorkTenantResourceDetailDto.setOnmWorkId(onmWorkId);
			deleteRow = oomWorkTenantResourceDetailMapper.deleteOomWorkTenantResourceDetail(reqOomWorkTenantResourceDetailDto);
			affectRowCount = affectRowCount + deleteRow;
			
			OomWorkTenantResourceDto reqOomWorkTenantResourceDto = new OomWorkTenantResourceDto();
			reqOomWorkTenantResourceDto.setOnmWorkId(onmWorkId);
			deleteRow = oomWorkTenantResourceMapper.deleteOomWorkTenantResource(reqOomWorkTenantResourceDto);
			affectRowCount = affectRowCount + deleteRow;
			
			OomWorkBuildingServiceConnectionIpDto reqOomWorkBuildingServiceConnectionIpDto = new OomWorkBuildingServiceConnectionIpDto();
			reqOomWorkBuildingServiceConnectionIpDto.setOnmWorkId(onmWorkId);
			deleteRow = oomWorkBuildingServiceConnectionIpMapper.deleteOomWorkBuildingServiceConnectionIp(reqOomWorkBuildingServiceConnectionIpDto);
			affectRowCount = affectRowCount + deleteRow;
			
			OomWorkBuildingServiceConenctionDto reqOomWorkBuildingServiceConenctionDto = new OomWorkBuildingServiceConenctionDto();
			reqOomWorkBuildingServiceConenctionDto.setOnmWorkId(onmWorkId);
			deleteRow = oomWorkBuildingServiceConenctionMapper.deleteOomWorkBuildingServiceConenction(reqOomWorkBuildingServiceConenctionDto);
			affectRowCount = affectRowCount + deleteRow;
			
			OomWorkBuildingDto reqOomWorkBuildingDto = new OomWorkBuildingDto();
			reqOomWorkBuildingDto.setOnmWorkId(onmWorkId);
			deleteRow = oomWorkBuildingMapper.deleteOomWorkBuilding(reqOomWorkBuildingDto);
			affectRowCount = affectRowCount + deleteRow;
			
			OomWorkTenantDto reqOomWorkTenantDto = new OomWorkTenantDto();
			reqOomWorkTenantDto.setOnmWorkId(onmWorkId);
			deleteRow = oomWorkTenantMapper.deleteOomWorkTenant(reqOomWorkTenantDto);
			affectRowCount = affectRowCount + deleteRow;
			
			OomWorkStatusDto reqOomWorkStatusDto = new OomWorkStatusDto();
			reqOomWorkStatusDto.setOnmWorkId(onmWorkId);
			deleteRow = oomWorkStatusMapper.deleteOomWorkStatus(reqOomWorkStatusDto);
			affectRowCount = affectRowCount + deleteRow;
			
			deleteRow = oomWorkMapper.deleteOomWork(reqOomWorkDto);
			affectRowCount = affectRowCount + deleteRow;
			
		} catch (Exception e) {
			throw e;
		}
		
		return affectRowCount;
	}
	
	
	/****************************** 조회를 위한 내용 ************************************/
	
	/**
	 * 
	 * listWorkStatusMenu
	 *
	 * @param reqOomWorkStatusDto
	 * @return List<WorkStatusMenuResultDto>
	 * @throws Exception 
	 */
	@Override
	public List<WorkStatusMenuResultDto> listWorkStatusMenu(OomWorkStatusDto reqOomWorkStatusDto) throws Exception {
		
		List<WorkStatusMenuResultDto> workStatusMenuResultDtoList = null;
		
		try {
			// 해당 작업별 작업상태 메뉴 목록조회...
			workStatusMenuResultDtoList = oomWorkStatusMapper.listWorkStatusMenu(reqOomWorkStatusDto);
			
		} catch (Exception e) {
			throw e;
		}
		
		return workStatusMenuResultDtoList;
	}

}
