package com.adtcaps.tsop.onm.api.alimTalk.batch;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import com.adtcaps.tsop.onm.api.alimTalk.service.AlimTalkService;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Component
public class AlimTalkResultBatch {
	@Autowired
	private AlimTalkService alimTalkService;

	private static String OS = System.getProperty("os.name").toLowerCase();

	@Scheduled(fixedDelay=10000)
	public void alimTalkResultBatch() {
		try {
			if (OS.indexOf("win") < 0) {
				log.debug("##### AlimTalkResultBatch");
				alimTalkService.getAlimTalkResult();
			}
		} catch (Exception e) {
			log.error("##### AlimTalkResultBatch Error {}", e);
		}
	}
}
