package com.adtcaps.tsop.onm.api.deploy.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;

import com.adtcaps.tsop.onm.api.deploy.domain.PackageDeployJobDetailResultDto;
import com.adtcaps.tsop.onm.api.deploy.domain.PackageDeployJobGridRequestDto;
import com.adtcaps.tsop.onm.api.deploy.domain.PackageDeployJobGridResultDto;
import com.adtcaps.tsop.onm.api.domain.OomPackageDeployJobDto;

/**
 * 
 * <ul>
 * <li>업무 그룹명 : tsop-onm-api</li>
 * <li>서브 업무명 : com.adtcaps.tsop.onm.api.deploy.mapper</li>
 * <li>설  명 : OomPackageDeployJobMapper.java</li>
 * <li>작성일 : 2021. 1. 31.</li>
 * <li>작성자 : jeonyb4</li>
 * </ul>
 */
@Mapper
public interface OomPackageDeployJobMapper {
	/**
	 * 
	 * mergeOomPackageDeployJob
	 *
	 * @param reqOomPackageDeployJobDto
	 * @return int
	 */
	public int mergeOomPackageDeployJob(OomPackageDeployJobDto reqOomPackageDeployJobDto);
	
	/**
	 * 
	 * readOomPackageDeployJob
	 *
	 * @param reqOomPackageDeployJobDto
	 * @return PackageDeployJobDetailResultDto
	 */
	public PackageDeployJobDetailResultDto readOomPackageDeployJob(OomPackageDeployJobDto reqOomPackageDeployJobDto);
	
	/**
	 * 
	 * readVerifyProcedureAttachFile
	 *
	 * @param reqOomPackageDeployJobDto
	 * @return PackageDeployJobDetailResultDto
	 */
	public PackageDeployJobDetailResultDto readVerifyProcedureAttachFile(OomPackageDeployJobDto reqOomPackageDeployJobDto);
	
	/**
	 * 
	 * readWorkProcedureAttachFile
	 *
	 * @param reqOomPackageDeployJobDto
	 * @return PackageDeployJobDetailResultDto
	 */
	public PackageDeployJobDetailResultDto readWorkProcedureAttachFile(OomPackageDeployJobDto reqOomPackageDeployJobDto);
	
	/**
	 * 
	 * readInspectionProcedureAttachFile
	 *
	 * @param reqOomPackageDeployJobDto
	 * @return PackageDeployJobDetailResultDto
	 */
	public PackageDeployJobDetailResultDto readInspectionProcedureAttachFile(OomPackageDeployJobDto reqOomPackageDeployJobDto);
	
	/**
	 * 
	 * readDbScriptAttachFile
	 *
	 * @param reqOomPackageDeployJobDto
	 * @return PackageDeployJobDetailResultDto
	 */
	public PackageDeployJobDetailResultDto readDbScriptAttachFile(OomPackageDeployJobDto reqOomPackageDeployJobDto);
	
	/**
	 * 
	 * readInspectionResultAttachFile
	 *
	 * @param reqOomPackageDeployJobDto
	 * @return PackageDeployJobDetailResultDto
	 */
	public PackageDeployJobDetailResultDto readInspectionResultAttachFile(OomPackageDeployJobDto reqOomPackageDeployJobDto);
	
	/**
	 * 
	 * updateDeployWorkEndDatetime
	 *
	 * @param reqOomPackageDeployJobDto
	 * @return int
	 */
	public int updateDeployWorkEndDatetime(OomPackageDeployJobDto reqOomPackageDeployJobDto);
	
	/**
	 * 
	 * updateDeployVerifyProcedureAttachFileNum
	 *
	 * @param reqOomPackageDeployJobDto
	 * @return int
	 */
	public int updateDeployVerifyProcedureAttachFileNum(OomPackageDeployJobDto reqOomPackageDeployJobDto);
	
	/**
	 * 
	 * updateDeployWorkProcedureAttachFileNum
	 *
	 * @param reqOomPackageDeployJobDto
	 * @return int
	 */
	public int updateDeployWorkProcedureAttachFileNum(OomPackageDeployJobDto reqOomPackageDeployJobDto);
	
	/**
	 * 
	 * updateDeployInspectionProcedureAttachFileNum
	 *
	 * @param reqOomPackageDeployJobDto
	 * @return int
	 */
	public int updateDeployInspectionProcedureAttachFileNum(OomPackageDeployJobDto reqOomPackageDeployJobDto);
	
	/**
	 * 
	 * updateDeployDbScriptAttachFileNum
	 *
	 * @param reqOomPackageDeployJobDto
	 * @return int
	 */
	public int updateDeployDbScriptAttachFileNum(OomPackageDeployJobDto reqOomPackageDeployJobDto);
	
	/**
	 * 
	 * updateDeployInspectionResultAttachFileNum
	 *
	 * @param reqOomPackageDeployJobDto
	 * @return int
	 */
	public int updateDeployInspectionResultAttachFileNum(OomPackageDeployJobDto reqOomPackageDeployJobDto);
	
	/**
	 * 
	 * deleteOomPackageDeployJob
	 *
	 * @param reqOomPackageDeployJobDto
	 * @return int
	 */
	public int deleteOomPackageDeployJob(OomPackageDeployJobDto reqOomPackageDeployJobDto);
	
	/**
	 * 
	 * listPagePackageDeployJob
	 *
	 * @param packageDeployJobGridRequestDto
	 * @return List<PackageDeployJobGridResultDto>
	 */
	public List<PackageDeployJobGridResultDto> listPagePackageDeployJob(PackageDeployJobGridRequestDto packageDeployJobGridRequestDto);
	
}
