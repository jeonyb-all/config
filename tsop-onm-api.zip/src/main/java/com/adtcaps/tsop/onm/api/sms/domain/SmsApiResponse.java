package com.adtcaps.tsop.onm.api.sms.domain;

import com.fasterxml.jackson.annotation.JsonInclude;

/**
 * @author zeal77@sk.com
 * SMS 발송 응답 데이터 규격
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
public class SmsApiResponse {
    /**
     * 결과 코드
     */
    private String returnCode;

    /**
     * 결과 메시지
     */
    private String returnMsg;

    /**
     * 에러 코드
     */
    private String errorCode;

    /**
     * 에러 메시지
     */
    private String errorMsg;


    public String getReturnCode() {
        return returnCode;
    }

    public void setReturnCode(String returnCode) {
        this.returnCode = returnCode;
    }

    public String getReturnMsg() {
        return returnMsg;
    }

    public void setReturnMsg(String returnMsg) {
        this.returnMsg = returnMsg;
    }

    public String getErrorCode() {
        return errorCode;
    }

    public void setErrorCode(String errorCode) {
        this.errorCode = errorCode;
    }

    public String getErrorMsg() {
        return errorMsg;
    }

    public void setErrorMsg(String errorMsg) {
        this.errorMsg = errorMsg;
    }

    @Override
    public String toString() {
        return "SmsApiResponse{" +
                "return_code='" + returnCode + '\'' +
                ", return_msg='" + returnMsg + '\'' +
                "error_code='" + returnCode + '\'' +
                ", error_msg='" + returnMsg +
                '}';
    }
}
