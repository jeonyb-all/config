package com.adtcaps.tsop.onm.api.work.controller;

import java.io.File;
import java.io.FileInputStream;
import java.io.OutputStream;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.io.FileUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.util.CollectionUtils;
import org.springframework.util.FileCopyUtils;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.adtcaps.tsop.onm.api.authentication.domain.JwtAuthResultDto;
import com.adtcaps.tsop.onm.api.building.domain.BuildingServiceForComboResultDto;
import com.adtcaps.tsop.onm.api.building.domain.TenantBuildingGridResultDto;
import com.adtcaps.tsop.onm.api.building.service.BuildingService;
import com.adtcaps.tsop.onm.api.building.service.BuildingServiceService;
import com.adtcaps.tsop.onm.api.domain.OomBuildingDto;
import com.adtcaps.tsop.onm.api.domain.OomBuildingServiceDto;
import com.adtcaps.tsop.onm.api.domain.OomUserRoleAuthorityDetailDto;
import com.adtcaps.tsop.onm.api.domain.OomWorkBuildingServiceConenctionDto;
import com.adtcaps.tsop.onm.api.domain.OomWorkDto;
import com.adtcaps.tsop.onm.api.domain.OomWorkStatusCodeDto;
import com.adtcaps.tsop.onm.api.domain.OomWorkStatusDto;
import com.adtcaps.tsop.onm.api.domain.OomWorkTenantResourceDetailDto;
import com.adtcaps.tsop.onm.api.helper.constant.Const;
import com.adtcaps.tsop.onm.api.helper.domain.ResultDto;
import com.adtcaps.tsop.onm.api.helper.util.PageUtil;
import com.adtcaps.tsop.onm.api.user.domain.UserRoleMenuAuthorityRequestDto;
import com.adtcaps.tsop.onm.api.user.service.UserRoleService;
import com.adtcaps.tsop.onm.api.work.domain.CurrentWorkDetailResultDto;
import com.adtcaps.tsop.onm.api.work.domain.WorkGridRequestDto;
import com.adtcaps.tsop.onm.api.work.domain.WorkGridResultDto;
import com.adtcaps.tsop.onm.api.work.domain.WorkProcessingRequestDto;
import com.adtcaps.tsop.onm.api.work.domain.WorkProcessingResultDto;
import com.adtcaps.tsop.onm.api.work.domain.WorkRegisterDto;
import com.adtcaps.tsop.onm.api.work.domain.WorkStatusCodeForComboResultDto;
import com.adtcaps.tsop.onm.api.work.domain.WorkStatusMenuResultDto;
import com.adtcaps.tsop.onm.api.work.service.WorkProcessService;
import com.adtcaps.tsop.onm.api.work.service.WorkService;

import lombok.extern.slf4j.Slf4j;

/**
 * 
 * <ul>
 * <li>업무 그룹명 : tsop-onm-api</li>
 * <li>서브 업무명 : com.adtcaps.tsop.onm.api.work.controller</li>
 * <li>설  명 : WorkController.java</li>
 * <li>작성일 : 2021. 1. 29.</li>
 * <li>작성자 : jeonyb4</li>
 * </ul>
 */
@Slf4j
@RestController
@RequestMapping("/api/works")
public class WorkController {
	
	private final String MENU_ID = "ONM0018";
	
	private final String ERR_MSG_NULL_LOGIN_USER_ID = "로그인 사용자ID가 없습니다.";
	private final String ERR_MSG_NULL_MGR_YN = "관리자여부가 없습니다.";
	private final String ERR_MSG_NULL_PAGE_NUMBER = "페이지 번호가 없습니다.";
	private final String ERR_MSG_NULL_SERACH_DATE = "조회기간(From or To)이 없습니다.";
	private final String ERR_MSG_NULL_WORK_TYPE_CD = "작업유형코드가 없습니다.";
	private final String ERR_MSG_NULL_WORK_STATUS_CD = "작업상태코드가 없습니다.";
	private final String ERR_MSG_NULL_WORK_STATUS_FINISH_CD = "작업상태완료코드가 없습니다.";
	private final String ERR_MSG_NULL_TENANT_ID = "테넌트ID가 없습니다.";
	private final String ERR_MSG_NULL_BLD_ID = "빌딩ID가 없습니다.";
	private final String ERR_MSG_NULL_SERVICE_CL_CD = "서비스구분코드가 없습니다.";
	
	private final String ERR_MSG_NOT_FOUND_WORK = "현재 작업을 찾을 수 없습니다.";
	private final String ERR_MSG_ALREADY_CHANGE_WORK_FINISH_STATUS = "해당 작업에 대한 상태가 이미 완료되어 저장할 수 없습니다.";
	private final String ERR_MSG_NOT_FOUND_BUILDING = "작업을 진행할 빌딩이 없습니다.";
	private final String ERR_MSG_CANNOT_DELETE_ONLY_ONE_BUILDING = "해당 빌딩은 해당 테넌트의 마지막 빌딩입니다. 테넌트 삭제 작업을 진행해 주세요.";
	private final String ERR_MSG_NOT_FOUND_SERVICE = "작업을 진행할 서비스가 없습니다.";
	private final String ERR_MSG_CANNOT_DELETE_ONLY_ONE_SERVICE = "해당 서비스는 해당 빌딩의 마지막 서비스입니다. 빌딩 삭제 작업을 진행해 주세요.";
	private final String ERR_MSG_CANNOT_DELETE_FINISH_WORK = "이미 완료된 작업은 삭제할 수 없습니다.";
	
	private final String ERR_MSG_NO_AUTH = "권한이 없는 사용자 입니다.";
	private final String ERR_MSG_NULL_SEARCH_RESULT_LIST = "조회 결과가 없습니다.";
	private final String ERR_MSG_ATTACH_FILE_DELETE_FAIL = "첨부파일 삭제에 실패하였습니다.";
	private final String ERR_MSG_SEARCH_FAIL = "조회에 실패하였습니다.";
	private final String ERR_MSG_CREATE_FAIL = "등록에 실패하였습니다.";
	private final String ERR_MSG_SAVE_FAIL = "저장에 실패하였습니다.";
	private final String ERR_MSG_DELETE_FAIL = "삭제에 실패하였습니다.";
	
	
	@Autowired
	private WorkService workService;
	
	@Autowired
	private WorkProcessService workProcessService;
	
	@Autowired
	private BuildingService buildingService;
	
	@Autowired
	private BuildingServiceService buildingServiceService;
	
	@Autowired
	private UserRoleService userRoleService;
	
	/**
	 * 
	 * listWorkStatusCodeForCombo
	 *
	 * @param reqOomWorkStatusCodeDto
	 * @return ResponseEntity
	 */
	@SuppressWarnings("rawtypes")
    @GetMapping(value="/status-codes/combobox", produces="application/json; charset=UTF-8")
    public ResponseEntity listWorkStatusCodeForCombo(OomWorkStatusCodeDto reqOomWorkStatusCodeDto) throws Exception {
        
    	ResponseEntity<ResultDto> resEntity = null;
		String returnString = "";
    	
		String onmWorkTypeCd = StringUtils.defaultString(reqOomWorkStatusCodeDto.getOnmWorkTypeCd());
		if ("".equals(onmWorkTypeCd)) {
			log.error(">>>>>> onmWorkTypeCd ERROR:{}", ERR_MSG_NULL_WORK_TYPE_CD);
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_WORK_TYPE_CD));
			return resEntity;
		}
		// 콤보박스 제공용 작업상태코드 목록조회....
		List<WorkStatusCodeForComboResultDto> workStatusCodeForComboResultDtoList = workService.listWorkStatusCodeForCombo(reqOomWorkStatusCodeDto);
		if (CollectionUtils.isEmpty(workStatusCodeForComboResultDtoList)) {
			returnString = Const.Common.RESULT_CODE.SUCCESS;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_SEARCH_RESULT_LIST, workStatusCodeForComboResultDtoList));
		} else {
			returnString = Const.Common.RESULT_CODE.SUCCESS;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, "", workStatusCodeForComboResultDtoList));
		}
    	
    	return resEntity;
    }
	
	/**
	 * 
	 * listPageWork
	 *
	 * @param workGridRequestDto
	 * @return ResponseEntity
	 */
	@SuppressWarnings("rawtypes")
    @GetMapping(value="", produces="application/json; charset=UTF-8")
    public ResponseEntity listPageWork(WorkGridRequestDto workGridRequestDto) throws Exception {
        
    	ResponseEntity<ResultDto> resEntity = null;
		String returnString = "";
    	
		int pageNumber = workGridRequestDto.getPageNumber();
		if (pageNumber < 1) {
			log.error(">>>>>> pageNumber ERROR:{}", ERR_MSG_NULL_PAGE_NUMBER);
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_PAGE_NUMBER));
			return resEntity;
		}
		String fromDate = workGridRequestDto.getFromDate();
		String toDate = workGridRequestDto.getToDate();
		if ("".equals(fromDate) || "".equals(toDate)) {
			log.error(">>>>>> fromDate or toDate ERROR:{}", ERR_MSG_NULL_SERACH_DATE);
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_SERACH_DATE));
			return resEntity;
		}
		// 작업 목록조회....
		Map<String, Object> workGridResultDtoListMap = new HashMap<String, Object>();
		List<WorkGridResultDto> workGridResultDtoList = workService.listPageWork(workGridRequestDto);
		if (CollectionUtils.isEmpty(workGridResultDtoList)) {
			returnString = Const.Common.RESULT_CODE.SUCCESS;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_SEARCH_RESULT_LIST, workGridResultDtoListMap));
		} else {
			returnString = Const.Common.RESULT_CODE.SUCCESS;
			workGridResultDtoListMap.put(Const.Definition.PAGE.PAGER, PageUtil.getPageInfo(workGridResultDtoList));
			workGridResultDtoListMap.put(Const.Definition.PAGE.LISTS, workGridResultDtoList);
			resEntity = ResponseEntity.ok(new ResultDto(returnString, "", workGridResultDtoListMap));
		}
    	
    	return resEntity;
    }
	
	/**
	 * 
	 * createWork
	 *
	 * @param authResultDto
	 * @param reqWorkRegisterDto
	 * @return ResponseEntity
	 */
	@SuppressWarnings("rawtypes")
    @PostMapping(value="", produces="application/json; charset=UTF-8")
    public ResponseEntity createWork(@AuthenticationPrincipal JwtAuthResultDto authResultDto, 
    		@RequestBody WorkRegisterDto reqWorkRegisterDto) throws Exception {
        
    	ResponseEntity<ResultDto> resEntity = null;
		String returnString = "";
    	
		String loginUserId = StringUtils.defaultString(authResultDto.getUserId());
		if ("".equals(loginUserId)) {
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_LOGIN_USER_ID));
			return resEntity;
		}
		String mgrYn = StringUtils.defaultString(authResultDto.getMgrYn());
		if ("".equals(mgrYn)) {
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_MGR_YN));
			return resEntity;
		}
		//String loginUserId = "tsop-admin"; // 이후 세션에서 얻어올 값...
		
		if (!"Y".equals(mgrYn)) {
			String authorityTypeCd = "";
			UserRoleMenuAuthorityRequestDto userRoleMenuAuthorityRequestDto = new UserRoleMenuAuthorityRequestDto();
			userRoleMenuAuthorityRequestDto.setUserId(loginUserId);
			userRoleMenuAuthorityRequestDto.setMenuId(MENU_ID);
			OomUserRoleAuthorityDetailDto rsltOomUserRoleAuthorityDetailDto = userRoleService.readMenuAuthority(userRoleMenuAuthorityRequestDto);
			if (rsltOomUserRoleAuthorityDetailDto != null) {
				authorityTypeCd = StringUtils.defaultString(rsltOomUserRoleAuthorityDetailDto.getAuthorityTypeCd());
			}
			if (!"W".equals(authorityTypeCd)) {
				returnString = Const.Common.RESULT_CODE.FAIL;
				resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NO_AUTH));
				return resEntity;
			}
		}
		
		String onmWorkTypeCd = StringUtils.defaultString(reqWorkRegisterDto.getOnmWorkTypeCd());
		if ("".equals(onmWorkTypeCd)) {
			log.error(">>>>>> onmWorkTypeCd ERROR:{}", ERR_MSG_NULL_WORK_TYPE_CD);
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_WORK_TYPE_CD));
			return resEntity;
		}
		if (!Const.Code.WORK_TYPE_CD.RT.equals(onmWorkTypeCd)) {
			String tenantId = StringUtils.defaultString(reqWorkRegisterDto.getTenantId());
    		if ("".equals(tenantId)) {
    			log.error(">>>>>> tenantId ERROR:{}", ERR_MSG_NULL_TENANT_ID);
				returnString = Const.Common.RESULT_CODE.FAIL;
    			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_TENANT_ID));
    			return resEntity;
    		}
		}
		if (Const.Code.WORK_TYPE_CD.RS.equals(onmWorkTypeCd) || Const.Code.WORK_TYPE_CD.CB.equals(onmWorkTypeCd) || 
				Const.Code.WORK_TYPE_CD.DS.equals(onmWorkTypeCd) || Const.Code.WORK_TYPE_CD.DB.equals(onmWorkTypeCd) || 
				Const.Code.WORK_TYPE_CD.CI.equals(onmWorkTypeCd)) {
			String bldId = StringUtils.defaultString(reqWorkRegisterDto.getBldId());
    		if ("".equals(bldId)) {
    			log.error(">>>>>> bldId ERROR:{}", ERR_MSG_NULL_BLD_ID);
				returnString = Const.Common.RESULT_CODE.FAIL;
    			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_BLD_ID));
    			return resEntity;
    		}
		}
		if (Const.Code.WORK_TYPE_CD.CI.equals(onmWorkTypeCd) || Const.Code.WORK_TYPE_CD.DS.equals(onmWorkTypeCd)) {
			String serviceClCd = StringUtils.defaultString(reqWorkRegisterDto.getServiceClCd());
    		if ("".equals(serviceClCd)) {
    			log.error(">>>>>> serviceClCd ERROR:{}", ERR_MSG_NULL_SERVICE_CL_CD);
				returnString = Const.Common.RESULT_CODE.FAIL;
    			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_SERVICE_CL_CD));
    			return resEntity;
    		}
		}
		
		// 마지막 1개 남은 빌딩 혹은 서비스인지 체크...
		if (Const.Code.WORK_TYPE_CD.DB.equals(onmWorkTypeCd)) {
			String tenantId = StringUtils.defaultString(reqWorkRegisterDto.getTenantId());
			OomBuildingDto reqOomBuildingDto = new OomBuildingDto();
			reqOomBuildingDto.setTenantId(tenantId);
			List<TenantBuildingGridResultDto> tenantBuildingGridResultDtoList = buildingService.listTenantBuildingForWork(reqOomBuildingDto);
			if (CollectionUtils.isEmpty(tenantBuildingGridResultDtoList)) {
				returnString = Const.Common.RESULT_CODE.FAIL;
    			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NOT_FOUND_BUILDING));
    			return resEntity;
			} else {
				if (tenantBuildingGridResultDtoList.size() == 1) {
					returnString = Const.Common.RESULT_CODE.FAIL;
	    			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_CANNOT_DELETE_ONLY_ONE_BUILDING));
	    			return resEntity;
				}
			}
		}
		if (Const.Code.WORK_TYPE_CD.DS.equals(onmWorkTypeCd)) {
			String bldId = StringUtils.defaultString(reqWorkRegisterDto.getBldId());
			OomBuildingServiceDto reqOomBuildingServiceDto = new OomBuildingServiceDto();
			reqOomBuildingServiceDto.setBldId(bldId);
			
			List<BuildingServiceForComboResultDto> buildingServiceForComboResultDtoList = buildingServiceService.listBuildingServiceForCombo(reqOomBuildingServiceDto);
			if (CollectionUtils.isEmpty(buildingServiceForComboResultDtoList)) {
				returnString = Const.Common.RESULT_CODE.FAIL;
    			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NOT_FOUND_SERVICE));
    			return resEntity;
			} else {
				if (buildingServiceForComboResultDtoList.size() == 1) {
					returnString = Const.Common.RESULT_CODE.FAIL;
	    			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_CANNOT_DELETE_ONLY_ONE_SERVICE));
	    			return resEntity;
				}
			}
		}
		
		reqWorkRegisterDto.setRegisterId(loginUserId);
		reqWorkRegisterDto.setAuditId(loginUserId);
		
		// 작업 등록...
		WorkProcessingResultDto workProcessingResultDto = workService.createWork(reqWorkRegisterDto);
		if (workProcessingResultDto == null) {
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_CREATE_FAIL, workProcessingResultDto));
		} else {
			String errorMessage = StringUtils.defaultString(workProcessingResultDto.getErrorMessage());
			if ("".equals(errorMessage)) {
				returnString = Const.Common.RESULT_CODE.SUCCESS;
    			resEntity = ResponseEntity.ok(new ResultDto(returnString, "", workProcessingResultDto));
			} else {
				returnString = Const.Common.RESULT_CODE.FAIL;
    			resEntity = ResponseEntity.ok(new ResultDto(returnString, errorMessage, ""));
			}
		}
    	
    	return resEntity;
    }
	
	/**
	 * 
	 * deleteWork
	 *
	 * @param onmWorkId
	 * @return ResponseEntity
	 */
	@SuppressWarnings("rawtypes")
    @DeleteMapping(value="/{onmWorkId}", produces="application/json; charset=UTF-8")
    public ResponseEntity deleteWork(@AuthenticationPrincipal JwtAuthResultDto authResultDto, 
    		@PathVariable("onmWorkId") int onmWorkId) throws Exception {
        
    	ResponseEntity<ResultDto> resEntity = null;
		String returnString = "";
		
		String loginUserId = StringUtils.defaultString(authResultDto.getUserId());
		if ("".equals(loginUserId)) {
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_LOGIN_USER_ID));
			return resEntity;
		}
		String mgrYn = StringUtils.defaultString(authResultDto.getMgrYn());
		if ("".equals(mgrYn)) {
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_MGR_YN));
			return resEntity;
		}
		//String loginUserId = "tsop-admin"; // 이후 세션에서 얻어올 값...
    	
		if (!"Y".equals(mgrYn)) {
			String authorityTypeCd = "";
			UserRoleMenuAuthorityRequestDto userRoleMenuAuthorityRequestDto = new UserRoleMenuAuthorityRequestDto();
			userRoleMenuAuthorityRequestDto.setUserId(loginUserId);
			userRoleMenuAuthorityRequestDto.setMenuId(MENU_ID);
			OomUserRoleAuthorityDetailDto rsltOomUserRoleAuthorityDetailDto = userRoleService.readMenuAuthority(userRoleMenuAuthorityRequestDto);
			if (rsltOomUserRoleAuthorityDetailDto != null) {
				authorityTypeCd = StringUtils.defaultString(rsltOomUserRoleAuthorityDetailDto.getAuthorityTypeCd());
			}
			if (!"W".equals(authorityTypeCd)) {
				returnString = Const.Common.RESULT_CODE.FAIL;
				resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NO_AUTH));
				return resEntity;
			}
		}
		
		OomWorkDto reqOomWorkDto = new OomWorkDto();
		reqOomWorkDto.setOnmWorkId(onmWorkId);
		
		// 해당 작업 등록정보 조회...
		OomWorkDto rsltOomWorkDto = workService.readWork(reqOomWorkDto);
		if (rsltOomWorkDto == null) {
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_SEARCH_FAIL, rsltOomWorkDto));
			return resEntity;
		}
		// 완료작업여부 체크...
		String workEndDatetime = StringUtils.defaultString(rsltOomWorkDto.getWorkEndDatetime());
		if (!"".equals(workEndDatetime)) {
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_CANNOT_DELETE_FINISH_WORK, null));
			return resEntity;
		}
		
		rsltOomWorkDto.setAuditId(loginUserId);
		
		// 작업 ALL 삭제...
		int affectRowCount = workService.deleteWork(rsltOomWorkDto);
		if (affectRowCount < 1) {
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_DELETE_FAIL, affectRowCount));
		} else {
			returnString = Const.Common.RESULT_CODE.SUCCESS;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, "", affectRowCount));
		}
    	
    	return resEntity;
    }
	
	/**
	 * 
	 * listWorkStatusMenu
	 *
	 * 작업 네비게이션 메뉴 목록조회
	 * @param onmWorkId
	 * @return ResponseEntity
	 */
	@SuppressWarnings("rawtypes")
    @GetMapping(value="/navi-menus/{onmWorkId}", produces="application/json; charset=UTF-8")
    public ResponseEntity listWorkStatusMenu(@PathVariable("onmWorkId") int onmWorkId) throws Exception {
        
    	ResponseEntity<ResultDto> resEntity = null;
		String returnString = "";
    	
		OomWorkStatusDto reqOomWorkStatusDto = new OomWorkStatusDto();
		reqOomWorkStatusDto.setOnmWorkId(onmWorkId);
		
		// 작업별 네비게이션 메뉴 목록조회....
		List<WorkStatusMenuResultDto> workStatusMenuResultDtoList = workService.listWorkStatusMenu(reqOomWorkStatusDto);
		if (CollectionUtils.isEmpty(workStatusMenuResultDtoList)) {
			returnString = Const.Common.RESULT_CODE.SUCCESS;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_SEARCH_RESULT_LIST, workStatusMenuResultDtoList));
		} else {
			returnString = Const.Common.RESULT_CODE.SUCCESS;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, "", workStatusMenuResultDtoList));
		}
    	
    	return resEntity;
    }
	
	/**
	 * 
	 * readCurrentWorkStatus
	 *
	 * @param onmWorkId
	 * @param reqOomWorkStatusDto
	 * @return ResponseEntity
	 */
	@SuppressWarnings("rawtypes")
    @GetMapping(value="/current-status/{onmWorkId}", produces="application/json; charset=UTF-8")
    public ResponseEntity readCurrentWorkStatus(@PathVariable("onmWorkId") int onmWorkId, OomWorkStatusDto reqOomWorkStatusDto) throws Exception {
        
    	ResponseEntity<ResultDto> resEntity = null;
		String returnString = "";
    	
		String onmWorkTypeCd = StringUtils.defaultString(reqOomWorkStatusDto.getOnmWorkTypeCd());
		if ("".equals(onmWorkTypeCd)) {
			log.error(">>>>>> onmWorkTypeCd or toDate ERROR:{}", ERR_MSG_NULL_WORK_TYPE_CD);
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_WORK_TYPE_CD));
			return resEntity;
		}
		String onmWorkStatusCd = StringUtils.defaultString(reqOomWorkStatusDto.getOnmWorkStatusCd());
		if ("".equals(onmWorkStatusCd)) {
			log.error(">>>>>> onmWorkStatusCd or toDate ERROR:{}", ERR_MSG_NULL_WORK_STATUS_CD);
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_WORK_STATUS_CD));
			return resEntity;
		}
		
		reqOomWorkStatusDto.setOnmWorkId(onmWorkId);
		
		// 해당 작업메뉴의 작업상태 및 해당 정보 조회....
		CurrentWorkDetailResultDto currentWorkDetailResultDto = workProcessService.readCurrentWorkStatus(reqOomWorkStatusDto);
		if (currentWorkDetailResultDto == null) {
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_SEARCH_FAIL, currentWorkDetailResultDto));
		} else {
			returnString = Const.Common.RESULT_CODE.SUCCESS;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, "", currentWorkDetailResultDto));
		}
    	
    	return resEntity;
    }
	
	/**
	 * 
	 * processWork
	 *
	 * @param authResultDto
	 * @param reqWorkProcessingRequestDto
	 * @return ResponseEntity
	 */
	@SuppressWarnings("rawtypes")
    @PostMapping(value="/{onmWorkId}", produces="application/json; charset=UTF-8")
    public ResponseEntity processWork(@AuthenticationPrincipal JwtAuthResultDto authResultDto, 
    		@PathVariable("onmWorkId") int onmWorkId, @RequestBody WorkProcessingRequestDto reqWorkProcessingRequestDto) throws Exception {
        
    	ResponseEntity<ResultDto> resEntity = null;
		String returnString = "";
    	
		String loginUserId = StringUtils.defaultString(authResultDto.getUserId());
		if ("".equals(loginUserId)) {
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_LOGIN_USER_ID));
			return resEntity;
		}
		String mgrYn = StringUtils.defaultString(authResultDto.getMgrYn());
		if ("".equals(mgrYn)) {
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_MGR_YN));
			return resEntity;
		}
		//String loginUserId = "tsop-admin"; // 이후 세션에서 얻어올 값...
		
		if (!"Y".equals(mgrYn)) {
			String authorityTypeCd = "";
			UserRoleMenuAuthorityRequestDto userRoleMenuAuthorityRequestDto = new UserRoleMenuAuthorityRequestDto();
			userRoleMenuAuthorityRequestDto.setUserId(loginUserId);
			userRoleMenuAuthorityRequestDto.setMenuId(MENU_ID);
			OomUserRoleAuthorityDetailDto rsltOomUserRoleAuthorityDetailDto = userRoleService.readMenuAuthority(userRoleMenuAuthorityRequestDto);
			if (rsltOomUserRoleAuthorityDetailDto != null) {
				authorityTypeCd = StringUtils.defaultString(rsltOomUserRoleAuthorityDetailDto.getAuthorityTypeCd());
			}
			if (!"W".equals(authorityTypeCd)) {
				returnString = Const.Common.RESULT_CODE.FAIL;
				resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NO_AUTH));
				return resEntity;
			}
		}
		
		String onmWorkTypeCd = StringUtils.defaultString(reqWorkProcessingRequestDto.getOnmWorkTypeCd());
		if ("".equals(onmWorkTypeCd)) {
			log.error(">>>>>> onmWorkTypeCd ERROR:{}", ERR_MSG_NULL_WORK_TYPE_CD);
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_WORK_TYPE_CD));
			return resEntity;
		}
		String currentWorkStatusCd = StringUtils.defaultString(reqWorkProcessingRequestDto.getCurrentWorkStatusCd());
		if ("".equals(currentWorkStatusCd)) {
			log.error(">>>>>> currentWorkStatusCd ERROR:{}", ERR_MSG_NULL_WORK_STATUS_CD);
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_WORK_STATUS_CD));
			return resEntity;
		}
		String currentWorkStatusFinishCd = StringUtils.defaultString(reqWorkProcessingRequestDto.getCurrentWorkStatusFinishCd());
		if ("".equals(currentWorkStatusFinishCd)) {
			log.error(">>>>>> currentWorkStatusFinishCd ERROR:{}", ERR_MSG_NULL_WORK_STATUS_FINISH_CD);
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_WORK_STATUS_FINISH_CD));
			return resEntity;
		}
		if (!Const.Code.WORK_TYPE_CD.RT.equals(onmWorkTypeCd)) {
			String currentTenantId = StringUtils.defaultString(reqWorkProcessingRequestDto.getCurrentTenantId());
    		if ("".equals(currentTenantId)) {
    			log.error(">>>>>> tenantId ERROR:{}", ERR_MSG_NULL_TENANT_ID);
				returnString = Const.Common.RESULT_CODE.FAIL;
    			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_TENANT_ID));
    			return resEntity;
    		}
		}
		
		reqWorkProcessingRequestDto.setOnmWorkId(onmWorkId);
		reqWorkProcessingRequestDto.setAuditId(loginUserId);
		
		// 현재 작업의 진행상태가 이미 완료되었는지 체크...
		OomWorkStatusDto reqOomWorkStatusDto = new OomWorkStatusDto();
		reqOomWorkStatusDto.setOnmWorkId(onmWorkId);
		reqOomWorkStatusDto.setOnmWorkTypeCd(onmWorkTypeCd);
		reqOomWorkStatusDto.setOnmWorkStatusCd(currentWorkStatusCd);
		CurrentWorkDetailResultDto currentWorkDetailResultDto = workProcessService.readCurrentWorkStatus(reqOomWorkStatusDto);
		if (currentWorkDetailResultDto == null) {
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NOT_FOUND_WORK));
			return resEntity;
		} else {
			String getWorkStatusFinishCd = StringUtils.defaultString(currentWorkDetailResultDto.getCurrentWorkStatusFinishCd());
			if (Const.Code.WORK_STATUS_FINISH_CD.FINISH.equals(getWorkStatusFinishCd) || Const.Code.WORK_STATUS_FINISH_CD.BYPASS.equals(getWorkStatusFinishCd)) {
				returnString = Const.Common.RESULT_CODE.FAIL;
				resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_ALREADY_CHANGE_WORK_FINISH_STATUS));
				return resEntity;
			}
		}
		
		// 마지막 1개 남은 빌딩 혹은 서비스인지 체크...
		if (Const.Code.WORK_STATUS_FINISH_CD.FINISH.equals(currentWorkStatusFinishCd)) {
			// next 진행코드가 없으면.. 작업 전체 종료로 간주...
			String nextWorkStatusCd = StringUtils.defaultString(reqWorkProcessingRequestDto.getNextWorkStatusCd());
			if ("".equals(nextWorkStatusCd)) {
				if (Const.Code.WORK_TYPE_CD.DB.equals(onmWorkTypeCd)) {
					String currentTenantId = StringUtils.defaultString(reqWorkProcessingRequestDto.getCurrentTenantId());
					OomBuildingDto reqOomBuildingDto = new OomBuildingDto();
					reqOomBuildingDto.setTenantId(currentTenantId);
					List<TenantBuildingGridResultDto> tenantBuildingGridResultDtoList = buildingService.listTenantBuildingForWork(reqOomBuildingDto);
					if (CollectionUtils.isEmpty(tenantBuildingGridResultDtoList)) {
						returnString = Const.Common.RESULT_CODE.FAIL;
		    			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NOT_FOUND_BUILDING));
		    			return resEntity;
					} else {
						if (tenantBuildingGridResultDtoList.size() == 1) {
							returnString = Const.Common.RESULT_CODE.FAIL;
			    			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_CANNOT_DELETE_ONLY_ONE_BUILDING));
			    			return resEntity;
						}
					}
				}
				if (Const.Code.WORK_TYPE_CD.DS.equals(onmWorkTypeCd)) {
					String currentBldId = StringUtils.defaultString(reqWorkProcessingRequestDto.getCurrentBldId());
					OomBuildingServiceDto reqOomBuildingServiceDto = new OomBuildingServiceDto();
					reqOomBuildingServiceDto.setBldId(currentBldId);
					
					List<BuildingServiceForComboResultDto> buildingServiceForComboResultDtoList = buildingServiceService.listBuildingServiceForCombo(reqOomBuildingServiceDto);
					if (CollectionUtils.isEmpty(buildingServiceForComboResultDtoList)) {
						returnString = Const.Common.RESULT_CODE.FAIL;
		    			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NOT_FOUND_SERVICE));
		    			return resEntity;
					} else {
						if (buildingServiceForComboResultDtoList.size() == 1) {
							returnString = Const.Common.RESULT_CODE.FAIL;
			    			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_CANNOT_DELETE_ONLY_ONE_SERVICE));
			    			return resEntity;
						}
					}
				}
			}
		}
		
		// 작업 저장(중간저장 or 완료)...
		WorkProcessingResultDto workProcessingResultDto = workProcessService.processWork(reqWorkProcessingRequestDto);
		if (workProcessingResultDto == null) {
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_SAVE_FAIL, workProcessingResultDto));
		} else {
			String errorMessage = StringUtils.defaultString(workProcessingResultDto.getErrorMessage());
			if ("".equals(errorMessage)) {
				returnString = Const.Common.RESULT_CODE.SUCCESS;
    			resEntity = ResponseEntity.ok(new ResultDto(returnString, "", workProcessingResultDto));
			} else {
				returnString = Const.Common.RESULT_CODE.FAIL;
    			resEntity = ResponseEntity.ok(new ResultDto(returnString, errorMessage, ""));
			}
		}
    	
    	return resEntity;
    }
	
	/**
	 * 
	 * deleteWorkStatusAttachFile
	 *
	 * @param onmWorkId
	 * @param onmWorkStatusDetailCd
	 * @param attachFileNum
	 * @param reqOomWorkStatusDto
	 * @return ResponseEntity
	 */
	@SuppressWarnings("rawtypes")
    @DeleteMapping(value="/{onmWorkId}/work-status/details/{onmWorkStatusDetailCd}/attach-files/{attachFileNum}", produces="application/json; charset=UTF-8")
    public ResponseEntity deleteWorkStatusAttachFile(@AuthenticationPrincipal JwtAuthResultDto authResultDto, 
    		@PathVariable("onmWorkId") int onmWorkId, @PathVariable("onmWorkStatusDetailCd") String onmWorkStatusDetailCd, 
    		@PathVariable("attachFileNum") int attachFileNum, @RequestBody OomWorkStatusDto reqOomWorkStatusDto) throws Exception {
        
    	ResponseEntity<ResultDto> resEntity = null;
		String returnString = "";
    	
		String loginUserId = StringUtils.defaultString(authResultDto.getUserId());
		if ("".equals(loginUserId)) {
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_LOGIN_USER_ID));
			return resEntity;
		}
		String mgrYn = StringUtils.defaultString(authResultDto.getMgrYn());
		if ("".equals(mgrYn)) {
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_MGR_YN));
			return resEntity;
		}
		//String loginUserId = "tsop-admin"; // 이후 세션에서 얻어올 값...
		
		if (!"Y".equals(mgrYn)) {
			String authorityTypeCd = "";
			UserRoleMenuAuthorityRequestDto userRoleMenuAuthorityRequestDto = new UserRoleMenuAuthorityRequestDto();
			userRoleMenuAuthorityRequestDto.setUserId(loginUserId);
			userRoleMenuAuthorityRequestDto.setMenuId(MENU_ID);
			OomUserRoleAuthorityDetailDto rsltOomUserRoleAuthorityDetailDto = userRoleService.readMenuAuthority(userRoleMenuAuthorityRequestDto);
			if (rsltOomUserRoleAuthorityDetailDto != null) {
				authorityTypeCd = StringUtils.defaultString(rsltOomUserRoleAuthorityDetailDto.getAuthorityTypeCd());
			}
			if (!"W".equals(authorityTypeCd)) {
				returnString = Const.Common.RESULT_CODE.FAIL;
				resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NO_AUTH));
				return resEntity;
			}
		}
		
		String onmWorkTypeCd = StringUtils.defaultString(reqOomWorkStatusDto.getOnmWorkTypeCd());
		if ("".equals(onmWorkTypeCd)) {
			log.error(">>>>>> onmWorkTypeCd ERROR:{}", ERR_MSG_NULL_WORK_TYPE_CD);
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_WORK_TYPE_CD));
			return resEntity;
		}
		String onmWorkStatusCd = StringUtils.defaultString(reqOomWorkStatusDto.getOnmWorkStatusCd());
		if ("".equals(onmWorkStatusCd)) {
			log.error(">>>>>> onmWorkStatusCd ERROR:{}", ERR_MSG_NULL_WORK_STATUS_CD);
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_WORK_STATUS_CD));
			return resEntity;
		}
		
		reqOomWorkStatusDto.setOnmWorkId(onmWorkId);
		reqOomWorkStatusDto.setOnmWorkStatusDetailCd(onmWorkStatusDetailCd);
		reqOomWorkStatusDto.setAttachFileNum(attachFileNum);
		int affectRowCount = workProcessService.deleteWorkStatusAttachFile(reqOomWorkStatusDto);
		if (affectRowCount < 1) {
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_ATTACH_FILE_DELETE_FAIL, affectRowCount));
		} else {
			returnString = Const.Common.RESULT_CODE.SUCCESS;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, "", affectRowCount));
		}
    	
    	return resEntity;
    }
	
	/**
	 * 
	 * deleteWorkInterfaceAttachFile
	 *
	 * @param onmWorkId
	 * @param serviceClCd
	 * @param attachFileNum
	 * @param reqOomWorkBuildingServiceConenctionDto
	 * @return ResponseEntity
	 */
	@SuppressWarnings("rawtypes")
    @DeleteMapping(value="/{onmWorkId}/work-interfaces/{serviceClCd}/attach-files/{attachFileNum}", produces="application/json; charset=UTF-8")
    public ResponseEntity deleteWorkInterfaceAttachFile(@AuthenticationPrincipal JwtAuthResultDto authResultDto, 
    		@PathVariable("onmWorkId") int onmWorkId, @PathVariable("serviceClCd") String serviceClCd, 
    		@PathVariable("attachFileNum") int attachFileNum, @RequestBody OomWorkBuildingServiceConenctionDto reqOomWorkBuildingServiceConenctionDto) throws Exception {
        
    	ResponseEntity<ResultDto> resEntity = null;
		String returnString = "";
    	
		String loginUserId = StringUtils.defaultString(authResultDto.getUserId());
		if ("".equals(loginUserId)) {
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_LOGIN_USER_ID));
			return resEntity;
		}
		String mgrYn = StringUtils.defaultString(authResultDto.getMgrYn());
		if ("".equals(mgrYn)) {
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_MGR_YN));
			return resEntity;
		}
		//String loginUserId = "tsop-admin"; // 이후 세션에서 얻어올 값...
		
		if (!"Y".equals(mgrYn)) {
			String authorityTypeCd = "";
			UserRoleMenuAuthorityRequestDto userRoleMenuAuthorityRequestDto = new UserRoleMenuAuthorityRequestDto();
			userRoleMenuAuthorityRequestDto.setUserId(loginUserId);
			userRoleMenuAuthorityRequestDto.setMenuId(MENU_ID);
			OomUserRoleAuthorityDetailDto rsltOomUserRoleAuthorityDetailDto = userRoleService.readMenuAuthority(userRoleMenuAuthorityRequestDto);
			if (rsltOomUserRoleAuthorityDetailDto != null) {
				authorityTypeCd = StringUtils.defaultString(rsltOomUserRoleAuthorityDetailDto.getAuthorityTypeCd());
			}
			if (!"W".equals(authorityTypeCd)) {
				returnString = Const.Common.RESULT_CODE.FAIL;
				resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NO_AUTH));
				return resEntity;
			}
		}
		
		String bldId = StringUtils.defaultString(reqOomWorkBuildingServiceConenctionDto.getBldId());
		if ("".equals(bldId)) {
			log.error(">>>>>> bldId ERROR:{}", ERR_MSG_NULL_BLD_ID);
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_BLD_ID));
			return resEntity;
		}
		
		reqOomWorkBuildingServiceConenctionDto.setOnmWorkId(onmWorkId);
		reqOomWorkBuildingServiceConenctionDto.setServiceClCd(serviceClCd);
		reqOomWorkBuildingServiceConenctionDto.setAttachFileNum(attachFileNum);
		int affectRowCount = workProcessService.deleteWorkInterfaceAttachFile(reqOomWorkBuildingServiceConenctionDto);
		if (affectRowCount < 1) {
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_ATTACH_FILE_DELETE_FAIL, affectRowCount));
		} else {
			returnString = Const.Common.RESULT_CODE.SUCCESS;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, "", affectRowCount));
		}
    	
    	return resEntity;
    }
	
	/**
	 * 
	 * listConnectionApiListExcel
	 *
	 * @param request
	 * @param response
	 * @param onmWorkId
	 * @return ResponseEntity
	 */
	@SuppressWarnings("rawtypes")
    @GetMapping(value="/{onmWorkId}/tenant-resource-details/excels", produces="application/json; charset=UTF-8")
    public ResponseEntity listConnectionApiListExcel(HttpServletRequest request, HttpServletResponse response, @PathVariable("onmWorkId") int onmWorkId) throws Exception {
        
    	ResponseEntity<ResultDto> resEntity = null;
		
		OomWorkTenantResourceDetailDto reqOomWorkTenantResourceDetailDto = new OomWorkTenantResourceDetailDto();
		reqOomWorkTenantResourceDetailDto.setOnmWorkId(onmWorkId);
		
		StringBuilder fileNameBuilder = new StringBuilder();
		fileNameBuilder.append(String.valueOf(onmWorkId));
		fileNameBuilder.append("-tenant-resource-detail-list");
		fileNameBuilder.append(".");
		fileNameBuilder.append(Const.Definition.FILE_EXTENTION.EXCEL);
		String fileName = fileNameBuilder.toString();
		
		// 엑셀 파일 생성...
		String fileFullPathName = workProcessService.listWorkTenantResourceDetailExcel(reqOomWorkTenantResourceDetailDto, fileName);
		
		// Excel File Download...
        response.setHeader("Content-Disposition", "attachment;filename=\"" + fileName + "\";");
        response.setContentType("application/octet-stream");
        response.setHeader("Content-transfer-Encoding", "binary");
        response.setHeader("mediaType", "application/vnd.ms-excel");
        OutputStream out = null;
        out = response.getOutputStream();
        FileInputStream fis = new FileInputStream(fileFullPathName);
        FileCopyUtils.copy(fis, out);
     
        out.flush();
		
		// Local Temp Directory 삭제...
        int lastSlashIndexVal = StringUtils.lastIndexOf(fileFullPathName, "/");
		String tempDirPath = StringUtils.substring(fileFullPathName, 0, lastSlashIndexVal);
		File downloadTempDirectory = new File(tempDirPath);
		if (downloadTempDirectory.isDirectory()) {
			FileUtils.deleteDirectory(downloadTempDirectory);
		}
    	
    	return resEntity;
    }

}
