package com.adtcaps.tsop.onm.api.alimTalk.domain;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class AlimTalkDetailDto {
	private String msgIdx;
	private String rcverId;
	private String rcverName;
	private String rcvPhoneNum;
	private String empId;
}
