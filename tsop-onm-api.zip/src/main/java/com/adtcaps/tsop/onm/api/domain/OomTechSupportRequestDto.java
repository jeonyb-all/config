package com.adtcaps.tsop.onm.api.domain;

import lombok.Getter;
import lombok.Setter;

/**
 * 
 * <ul>
 * <li>업무 그룹명 : tsop-onm-api</li>
 * <li>서브 업무명 : com.adtcaps.tsop.onm.api.domain</li>
 * <li>설  명 : OomTechSupportRequestDto.java</li>
 * <li>작성일 : 2021. 1. 13.</li>
 * <li>작성자 : jeonyb4</li>
 * </ul>
 */
@Getter
@Setter
public class OomTechSupportRequestDto {
	private String tenantId;
	private Integer techSupportReqId;
	private String auditDatetime;
	private String auditId;
	private String bldId;
	private String reqerName;
	private String techSupportReqTypeCd;
	private String registDatetime;
	private String reqTitleName;
	private String reqContent;
	private String techSupportStatusCd;
	private String workMgmtApplyYn;
	private String changeApprovalYn;
	private String changeApprovalDatetime;
	private String changeApplyDatetime;
	private Integer attachFileNum;
	private Integer serviceTechSupportReqId;

}
