package com.adtcaps.tsop.onm.api.scheduler;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import com.adtcaps.tsop.onm.api.user.mapper.OomUserMapper;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Component
public class CronScheduler {
	
	@Autowired
	OomUserMapper oomUserMapper;
	
	@Autowired
	private Environment env;
	
	
	
	@Scheduled(cron = "* 0 2 * * *")
	public void updateUserLockYn() {
		
		if (isLocalProfile()) {
			return;
		}
		
		int result = 0;
		
		try {
			result = oomUserMapper.updateOomUserLockYn();
		} catch (Exception e) {
			log.error("## update failed [OOM_USER.lock_yn]");
		} finally {
			log.info("## [OOM_USER.lock_yn] update count : " + result);
		}
		
	}
	
	
	private boolean isLocalProfile() {
		
		boolean ret = false;
		String[] profiles = env.getActiveProfiles();
		
		if (profiles.length == 0) {
			return ret;
		}
		
		if ("local".equals(profiles[0])) {
			ret = true;
		}
		
		return ret;
	}
	
}
