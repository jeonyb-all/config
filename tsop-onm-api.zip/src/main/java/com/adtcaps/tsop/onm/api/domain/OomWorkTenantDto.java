package com.adtcaps.tsop.onm.api.domain;

import lombok.Getter;
import lombok.Setter;

/**
 * 
 * <ul>
 * <li>업무 그룹명 : tsop-onm-api</li>
 * <li>서브 업무명 : com.adtcaps.tsop.onm.api.domain</li>
 * <li>설  명 : OomWorkTenantDto.java</li>
 * <li>작성일 : 2021. 1. 30.</li>
 * <li>작성자 : jeonyb4</li>
 * </ul>
 */
@Getter
@Setter
public class OomWorkTenantDto {
	private Integer onmWorkId;
	private String auditDatetime;
	private String auditId;
	private String onmWorkStatusFinishCd;
	private String tenantId;
	private String tenantName;
	private String tenantTypeCd;
	private String registDate;
	private String registerId;
	private String serviceStartDate;
	private String serviceEndDate;
	private String useYn;
	private String lotnumAddr;
	private String streetnameAddr;
	private String representName;

}
