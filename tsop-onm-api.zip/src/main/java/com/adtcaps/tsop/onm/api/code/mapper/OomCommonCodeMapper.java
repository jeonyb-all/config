package com.adtcaps.tsop.onm.api.code.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;

import com.adtcaps.tsop.onm.api.code.domain.CommonCodeGridRequestDto;
import com.adtcaps.tsop.onm.api.code.domain.CommonCodeGridResultDto;
import com.adtcaps.tsop.onm.api.code.domain.CommonCodeRequestDto;
import com.adtcaps.tsop.onm.api.domain.OomCommonCodeDto;


/**
 * 
 * <ul>
 * <li>업무 그룹명 : tsop-onm-api</li>
 * <li>서브 업무명 : com.adtcaps.tsop.onm.api.code.mapper</li>
 * <li>설  명 : OomCommonCodeMapper.java</li>
 * <li>작성일 : 2021. 1. 4.</li>
 * <li>작성자 : jeonyb4</li>
 * </ul>
 */
@Mapper
public interface OomCommonCodeMapper {
	/**
	 * 
	 * listPageCommonCode
	 *
	 * @param commonCodeGridRequestDto
	 * @return List<CommonCodeGridResultDto>
	 */
	public List<CommonCodeGridResultDto> listPageCommonCode(CommonCodeGridRequestDto commonCodeGridRequestDto);
	
	/**
	 * 
	 * readCommonCodeDuplicationCheck
	 *
	 * @param reqOomCommonCodeDto
	 * @return int
	 */
	public int readCommonCodeDuplicationCheck(OomCommonCodeDto reqOomCommonCodeDto);
	
	/**
	 * 
	 * createOomCommonCode
	 *
	 * @param reqOomCommonCodeDto
	 * @return int
	 */
	public int createOomCommonCode(OomCommonCodeDto reqOomCommonCodeDto);
	
	/**
	 * 
	 * readOomCommonCode
	 *
	 * @param reqOomCommonCodeDto
	 * @return OomCommonCodeDto
	 */
	public OomCommonCodeDto readOomCommonCode(OomCommonCodeDto reqOomCommonCodeDto);
	
	/**
	 * 
	 * updateOomCommonCode
	 *
	 * @param reqOomCommonCodeDto
	 * @return int
	 */
	public int updateOomCommonCode(OomCommonCodeDto reqOomCommonCodeDto);
	
	/**
	 * 
	 * deleteOomCommonCode
	 *
	 * @param reqOomCommonCodeDto
	 * @return int
	 */
	public int deleteOomCommonCode(OomCommonCodeDto reqOomCommonCodeDto);
	
	
	/**
	 * 
	 * listCommonCodeForCombo
	 *
	 * @param commonCodeRequestDto
	 * @return List<OomCommonCodeDto>
	 */
	public List<OomCommonCodeDto> listCommonCodeForCombo(CommonCodeRequestDto commonCodeRequestDto);
	
	/**
	 * 
	 * updateCommonCodeReuse
	 *
	 * @param reqOomCommonCodeDto
	 * @return int
	 */
	public int updateCommonCodeReuse(OomCommonCodeDto reqOomCommonCodeDto);

}
