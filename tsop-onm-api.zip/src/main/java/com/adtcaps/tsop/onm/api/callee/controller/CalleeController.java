package com.adtcaps.tsop.onm.api.callee.controller;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.adtcaps.tsop.onm.api.callee.domain.TechSupportRequestProcessingDto;
import com.adtcaps.tsop.onm.api.callee.service.CalleeService;
import com.adtcaps.tsop.onm.api.config.TenantConfig;
import com.adtcaps.tsop.onm.api.domain.OomTechSupportRequestBuildingDto;
import com.adtcaps.tsop.onm.api.domain.OomTechSupportRequestBuildingServiceDto;
import com.adtcaps.tsop.onm.api.domain.OomTechSupportRequestDto;
import com.adtcaps.tsop.onm.api.file.domain.BlobRequestDto;
import com.adtcaps.tsop.onm.api.helper.constant.Const;
import com.adtcaps.tsop.onm.api.helper.domain.ResultDto;

import lombok.extern.slf4j.Slf4j;

/**
 * 
 * <ul>
 * <li>업무 그룹명 : tsop-onm-api</li>
 * <li>서브 업무명 : com.adtcaps.tsop.onm.api.callee.controller</li>
 * <li>설  명 : CalleeController.java</li>
 * <li>작성일 : 2021. 1. 3.</li>
 * <li>작성자 : jeonyb4</li>
 * </ul>
 */
@Slf4j
@RestController
@RequestMapping("/api/callees")
public class CalleeController {
	
	private final String ERR_MSG_NULL_KEY = "Key값이 없습니다.";
	private final String ERR_MSG_NULL_TECH_SUPPORT_INFO = "기술지원요청 등록정보가 없습니다.";
	private final String ERR_MSG_NULL_BUILDING_REQUEST_INFO = "빌딩변경요청 등록정보가 없습니다.";
	private final String ERR_MSG_NULL_SERVICE_REQUEST_INFO = "서비스변경요청 등록정보가 없습니다.";
	private final String ERR_MSG_NULL_REMOTE_FILE_URL = "원격파일 URL이 없습니다.";
	private final String ERR_MSG_NULL_REMOTE_FILE_NAME = "원격파일명이 없습니다.";
	
	private final String ERR_MSG_KEY_AUTH_FAIL = "Key 인증에 실패하였습니다.";
	private final String ERR_MSG_REMOTE_CREATE_FAIL = "원격 등록에 실패하였습니다.";
	
	@Autowired
	private CalleeService calleeService;
	
	@Autowired
	private TenantConfig tenantConfig;
	
	/**
	 * 
	 * createRemoteTechSupportRequest
	 *
	 * @param techSupportRequestProcessingDto
	 * @return ResponseEntity
	 */
	@SuppressWarnings("rawtypes")
    @PostMapping(value="/create-supports", produces="application/json; charset=UTF-8")
    public ResponseEntity createRemoteTechSupportRequest(HttpServletRequest request, @RequestBody TechSupportRequestProcessingDto techSupportRequestProcessingDto) throws Exception {
        
    	ResponseEntity<ResultDto> resEntity = null;
		String returnString = "";
    	
		String callKey = StringUtils.defaultString(request.getHeader("Call-Key"));
		String key = StringUtils.defaultString(tenantConfig.getMyServerInfo().getKey());
		if ("".equals(callKey) || "".equals(key)) {
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_KEY));
			return resEntity;
		}
		if (!callKey.equals(key)) {
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_KEY_AUTH_FAIL));
			return resEntity;
		}
		
		OomTechSupportRequestDto oomTechSupportRequestDto = techSupportRequestProcessingDto.getTechSupportRequestInfo();
		if (oomTechSupportRequestDto == null) {
			log.error(">>>>>> oomTechSupportRequestDto ERROR:{}", ERR_MSG_NULL_TECH_SUPPORT_INFO);
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_TECH_SUPPORT_INFO));
			return resEntity;
		}
		String techSupportReqTypeCd = StringUtils.defaultString(oomTechSupportRequestDto.getTechSupportReqTypeCd());
		if (Const.Code.TECH_SUPPORT_REQ_TYPE_CD.BLD_ADD.equals(techSupportReqTypeCd) || Const.Code.TECH_SUPPORT_REQ_TYPE_CD.BLD_MOD.equals(techSupportReqTypeCd) || 
				Const.Code.TECH_SUPPORT_REQ_TYPE_CD.BLD_DEL.equals(techSupportReqTypeCd)) {
			OomTechSupportRequestBuildingDto oomTechSupportRequestBuildingDto = techSupportRequestProcessingDto.getBuildingInfo();
			if (oomTechSupportRequestBuildingDto == null) {
    			log.error(">>>>>> oomTechSupportRequestBuildingDto ERROR:{}", ERR_MSG_NULL_BUILDING_REQUEST_INFO);
				returnString = Const.Common.RESULT_CODE.FAIL;
    			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_BUILDING_REQUEST_INFO));
    			return resEntity;
    		}
		}
		if (Const.Code.TECH_SUPPORT_REQ_TYPE_CD.SVC_ADD.equals(techSupportReqTypeCd) || Const.Code.TECH_SUPPORT_REQ_TYPE_CD.SVC_DEL.equals(techSupportReqTypeCd)) {
			OomTechSupportRequestBuildingServiceDto oomTechSupportRequestBuildingServiceDto = techSupportRequestProcessingDto.getServiceInfo();
			if (oomTechSupportRequestBuildingServiceDto == null) {
    			log.error(">>>>>> oomTechSupportRequestBuildingServiceDto ERROR:{}", ERR_MSG_NULL_SERVICE_REQUEST_INFO);
				returnString = Const.Common.RESULT_CODE.FAIL;
    			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_SERVICE_REQUEST_INFO));
    			return resEntity;
    		}
		}
		
		BlobRequestDto blobRequestDto = techSupportRequestProcessingDto.getAttachFile();
		if (blobRequestDto != null) {
			String remoteFileUrl = StringUtils.defaultString(blobRequestDto.getRemoteFileUrl());
			if ("".equals(remoteFileUrl)) {
    			log.error(">>>>>> remoteFileUrl ERROR:{}", remoteFileUrl);
				returnString = Const.Common.RESULT_CODE.FAIL;
    			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_REMOTE_FILE_URL));
    			return resEntity;
    		}
			String remoteFileName = StringUtils.defaultString(blobRequestDto.getRemoteFileName());
			if ("".equals(remoteFileName)) {
    			log.error(">>>>>> remoteFileName ERROR:{}", remoteFileName);
				returnString = Const.Common.RESULT_CODE.FAIL;
    			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_REMOTE_FILE_NAME));
    			return resEntity;
    		}
		}
		
		// 원격 기술지원요청 등록...
		int affectRowCount = calleeService.createRemoteTechSupportRequest(techSupportRequestProcessingDto);
		if (affectRowCount < 1) {
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_REMOTE_CREATE_FAIL, affectRowCount));
		} else {
			returnString = Const.Common.RESULT_CODE.SUCCESS;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, "", affectRowCount));
		}
    	
    	return resEntity;
    }

}
