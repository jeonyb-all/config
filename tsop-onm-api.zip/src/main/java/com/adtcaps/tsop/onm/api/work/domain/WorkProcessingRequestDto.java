package com.adtcaps.tsop.onm.api.work.domain;

import java.util.List;

import com.adtcaps.tsop.onm.api.domain.OomWorkBuildingDto;
import com.adtcaps.tsop.onm.api.domain.OomWorkBuildingServiceConenctionDto;
import com.adtcaps.tsop.onm.api.domain.OomWorkTenantDto;

import lombok.Getter;
import lombok.Setter;

/**
 * 
 * <ul>
 * <li>업무 그룹명 : tsop-onm-api</li>
 * <li>서브 업무명 : com.adtcaps.tsop.onm.api.work.domain</li>
 * <li>설  명 : WorkProcessingRequestDto.java</li>
 * <li>작성일 : 2021. 1. 30.</li>
 * <li>작성자 : jeonyb4</li>
 * </ul>
 */
@Getter
@Setter
public class WorkProcessingRequestDto {
	private Integer onmWorkId;
	private String onmWorkTypeCd;
	private String currentWorkStatusCd;
	private String currentWorkStatusDetailCd;
	private String currentWorkStatusFinishCd;
	private String nextWorkStatusCd;
	private String currentTenantId;
	private String currentBldId;
	private String currentServiceClCd;
	private Integer techSupportReqId;
	private String auditId;
	
	private OomWorkTenantDto tenantInfo;
	private List<OomWorkBuildingDto> buildingList;
	private List<OomWorkBuildingServiceConenctionDto> serviceList;
	private List<WorkBuildingServiceConnectionIpDto> serviceConnectionIpList;
	private List<VerifyWorkProcessDto> verifyWorkList;
	private List<InterfaceWorkProcessDto> interfaceList;
	private WorkTenantResourceDto tenantResourceInfo;
	private WorkPackageDeployJobDto packageDeployInfo;
}
