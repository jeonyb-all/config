package com.adtcaps.tsop.onm.api.domain;

import lombok.Getter;
import lombok.Setter;

/**
 * 
 * <ul>
 * <li>업무 그룹명 : tsop-onm-api</li>
 * <li>서브 업무명 : com.adtcaps.tsop.onm.api.domain</li>
 * <li>설  명 : OomTechSupportRequestBuildingDto.java</li>
 * <li>작성일 : 2021. 1. 13.</li>
 * <li>작성자 : jeonyb4</li>
 * </ul>
 */
@Getter
@Setter
public class OomTechSupportRequestBuildingDto {
	private String tenantId;
	private Integer techSupportReqId;
	private String auditDatetime;
	private String auditId;
	private String bldId;
	private String bldName;
	private String lotnumAddr;
	private String streetnameAddr;
	private String ldongCd;
	private Double latitudeVal;
	private Double longitudeVal;
	private Double bldTotalfloorareaSize;
	private Double condAreaSize;
	private Double prksiteAreaSize;
	private Integer groundFloor;
	private Integer undergroundFloor;
	private String completDate;
	private Double weatherForecastXCodnVal;
	private Double weatherForecastYCodnVal;
	private String bldTypeCd;
	private String bldTypeCdName;
	private String useYn;

}
