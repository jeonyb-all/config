package com.adtcaps.tsop.onm.api.user.service;

import java.util.List;

import com.adtcaps.tsop.onm.api.domain.OomUserDto;
import com.adtcaps.tsop.onm.api.user.domain.UserProcessingDto;
import com.adtcaps.tsop.onm.api.user.domain.UserDetailResultDto;
import com.adtcaps.tsop.onm.api.user.domain.UserForShortGridRequestDto;
import com.adtcaps.tsop.onm.api.user.domain.UserForShortGridResultDto;
import com.adtcaps.tsop.onm.api.user.domain.UserGridRequestDto;
import com.adtcaps.tsop.onm.api.user.domain.UserGridResultDto;

/**
 * 
 * <ul>
 * <li>업무 그룹명 : tsop-onm-api</li>
 * <li>서브 업무명 : com.adtcaps.tsop.onm.api.user.service</li>
 * <li>설  명 : UserService.java</li>
 * <li>작성일 : 2021. 1. 4.</li>
 * <li>작성자 : jeonyb4</li>
 * </ul>
 */
public interface UserService {
	/**
	 * 
	 * readUserPasswordEqualCheck
	 *
	 * @param reqOomUserDto
	 * @return int
	 * @throws Exception 
	 */
	public int readUserPasswordEqualCheck(OomUserDto reqOomUserDto) throws Exception;
	
	/**
	 * 
	 * updateMyInfo
	 *
	 * @param reqOomUserDto
	 * @return int
	 * @throws Exception 
	 */
	public int updateMyInfo(OomUserDto reqOomUserDto) throws Exception;
	
	/**
	 * 
	 * updateUserPassword
	 *
	 * @param reqOomUserDto
	 * @return int
	 * @throws Exception 
	 */
	public int updateUserPassword(OomUserDto reqOomUserDto) throws Exception;
	
	/**
	 * 
	 * listUserForShortGrid
	 *
	 * @param userForShortGridRequestDto
	 * @return List<UserForShortGridResultDto>
	 * @throws Exception 
	 */
	public List<UserForShortGridResultDto> listUserForShortGrid(UserForShortGridRequestDto userForShortGridRequestDto) throws Exception;
	
	/**
	 * 
	 * listPageUser
	 *
	 * @param userGridRequestDto
	 * @return List<UserGridResultDto>
	 * @throws Exception 
	 */
	public List<UserGridResultDto> listPageUser(UserGridRequestDto userGridRequestDto) throws Exception;
	
	/**
	 * 
	 * updateUserInitialPassword
	 *
	 * @param reqOomUserDto
	 * @return int
	 * @throws Exception 
	 */
	public int updateUserInitialPassword(OomUserDto reqOomUserDto) throws Exception;
	
	/**
	 * 
	 * readUserDuplicationCheck
	 *
	 * @param reqOomUserDto
	 * @return int
	 * @throws Exception 
	 */
	public int readUserDuplicationCheck(OomUserDto reqOomUserDto) throws Exception;
	
	/**
	 * 
	 * readUserDuplicationServiceOper
	 *
	 * @param reqOomUserDto
	 * @return int
	 * @throws Exception 
	 */
	public int readUserDuplicationServiceOper(OomUserDto reqOomUserDto) throws Exception;
	
	/**
	 * 
	 * createUser
	 *
	 * @param reqUserProcessingDto
	 * @return int
	 * @throws Exception 
	 */
	public int createUser(UserProcessingDto reqUserProcessingDto) throws Exception;
	
	/**
	 * 
	 * readUser
	 *
	 * @param reqOomUserDto
	 * @return UserDetailResultDto
	 * @throws Exception 
	 */
	public UserDetailResultDto readUser(OomUserDto reqOomUserDto) throws Exception;
	
	/**
	 * 
	 * updateUser
	 *
	 * @param reqUserProcessingDto
	 * @return int
	 * @throws Exception 
	 */
	public int updateUser(UserProcessingDto reqUserProcessingDto) throws Exception;
	
	/**
	 * 
	 * deleteUser
	 *
	 * @param reqOomUserDto
	 * @return int
	 * @throws Exception 
	 */
	public int deleteUser(OomUserDto reqOomUserDto) throws Exception;
	
	/**
	 * 
	 * readServiceOperUserInfoForTenantId
	 *
	 * @param reqOomUserDto
	 * @return OomUserDto
	 * @throws Exception 
	 */
	public OomUserDto readServiceOperUserInfoForTenantId(OomUserDto reqOomUserDto) throws Exception;

}
