package com.adtcaps.tsop.onm.api.send.service;

import java.util.List;

import com.adtcaps.tsop.onm.api.domain.OomSmsHistDto;
import com.adtcaps.tsop.onm.api.send.domain.SmsHistDetailResultDto;
import com.adtcaps.tsop.onm.api.send.domain.SmsHistGridRequestDto;
import com.adtcaps.tsop.onm.api.send.domain.SmsHistGridResultDto;

/**
 * 
 * <ul>
 * <li>업무 그룹명 : tsop-onm-api</li>
 * <li>서브 업무명 : com.adtcaps.tsop.onm.api.send.service</li>
 * <li>설  명 : SendService.java</li>
 * <li>작성일 : 2021. 1. 30.</li>
 * <li>작성자 : jeonyb4</li>
 * </ul>
 */
public interface SendService {
	/**
	 * 
	 * listPageSmsHist
	 *
	 * @param reqSmsHistGridRequestDto
	 * @return List<SmsHistGridResultDto>
	 * @throws Exception 
	 */
	public List<SmsHistGridResultDto> listPageSmsHist(SmsHistGridRequestDto reqSmsHistGridRequestDto) throws Exception;
	
	/**
	 * 
	 * readSmsHist
	 *
	 * @param reqOomSmsHistDto
	 * @return SmsHistDetailResultDto
	 * @throws Exception 
	 */
	public SmsHistDetailResultDto readSmsHist(OomSmsHistDto reqOomSmsHistDto) throws Exception;
	
	/**
	 * 
	 * resendSmsHistDto
	 *
	 * @param paramOomSmsHistDto
	 * @return String
	 * @throws Exception 
	 */
	public String resendSmsHistDto(OomSmsHistDto paramOomSmsHistDto) throws Exception;

}
