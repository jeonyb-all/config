package com.adtcaps.tsop.onm.api.support.mapper;

import org.apache.ibatis.annotations.Mapper;

import com.adtcaps.tsop.onm.api.domain.OomTechSupportRequestBuildingServiceDto;

/**
 * 
 * <ul>
 * <li>업무 그룹명 : tsop-onm-api</li>
 * <li>서브 업무명 : com.adtcaps.tsop.onm.api.support.mapper</li>
 * <li>설  명 : OomTechSupportRequestBuildingServiceMapper.java</li>
 * <li>작성일 : 2021. 1. 2.</li>
 * <li>작성자 : jeonyb4</li>
 * </ul>
 */
@Mapper
public interface OomTechSupportRequestBuildingServiceMapper {
	/**
	 * 
	 * createOomTechSupportRequestBuildingService
	 *
	 * @param reqOomTechSupportRequestBuildingServiceDto
	 * @return int
	 */
	public int createOomTechSupportRequestBuildingService(OomTechSupportRequestBuildingServiceDto reqOomTechSupportRequestBuildingServiceDto);
	
	/**
	 * 
	 * readOomTechSupportRequestBuildingService
	 *
	 * @param reqOomTechSupportRequestBuildingServiceDto
	 * @return OomTechSupportRequestBuildingServiceDto
	 */
	public OomTechSupportRequestBuildingServiceDto readOomTechSupportRequestBuildingService(OomTechSupportRequestBuildingServiceDto reqOomTechSupportRequestBuildingServiceDto);
	
}
