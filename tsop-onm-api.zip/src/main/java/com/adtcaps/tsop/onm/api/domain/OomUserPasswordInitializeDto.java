package com.adtcaps.tsop.onm.api.domain;

import lombok.Getter;
import lombok.Setter;

/**
 * 
 * <ul>
 * <li>업무 그룹명 : tsop-onm-api</li>
 * <li>서브 업무명 : com.adtcaps.tsop.onm.api.domain</li>
 * <li>설  명 : OomUserPasswordInitializeDto.java</li>
 * <li>작성일 : 2021. 1. 4.</li>
 * <li>작성자 : jeonyb4</li>
 * </ul>
 */
@Getter
@Setter
public class OomUserPasswordInitializeDto {
	private String userId;
	private String initiallizeDatetime;
	private String auditDatetime;
	private String auditId;

}
