package com.adtcaps.tsop.onm.api.building.service.impl;

import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.adtcaps.tsop.onm.api.building.domain.BuildingServiceConnectionDetailResultDto;
import com.adtcaps.tsop.onm.api.building.domain.BuildingServiceConnectionGridRequestDto;
import com.adtcaps.tsop.onm.api.building.domain.BuildingServiceConnectionGridResultDto;
import com.adtcaps.tsop.onm.api.building.domain.BuildingServiceConnectionIpDetailDto;
import com.adtcaps.tsop.onm.api.building.domain.BuildingServiceForComboResultDto;
import com.adtcaps.tsop.onm.api.building.domain.BuildingServiceUseYnResultDto;
import com.adtcaps.tsop.onm.api.building.mapper.OomBuildingServiceConnectionIpMapper;
import com.adtcaps.tsop.onm.api.building.mapper.OomBuildingServiceConnectionMapper;
import com.adtcaps.tsop.onm.api.building.mapper.OomBuildingServiceMapper;
import com.adtcaps.tsop.onm.api.building.service.BuildingServiceService;
import com.adtcaps.tsop.onm.api.domain.OomBuildingServiceConnectionDto;
import com.adtcaps.tsop.onm.api.domain.OomBuildingServiceConnectionIpDto;
import com.adtcaps.tsop.onm.api.domain.OomBuildingServiceDto;

/**
 * 
 * <ul>
 * <li>업무 그룹명 : tsop-onm-api</li>
 * <li>서브 업무명 : com.adtcaps.tsop.onm.api.building.service.impl</li>
 * <li>설  명 : BuildingServiceServiceImpl.java</li>
 * <li>작성일 : 2021. 1. 6.</li>
 * <li>작성자 : jeonyb4</li>
 * </ul>
 */
@Service
public class BuildingServiceServiceImpl implements BuildingServiceService {
	
	@Autowired
	private OomBuildingServiceMapper oomBuildingServiceMapper;
	
	@Autowired
	private OomBuildingServiceConnectionMapper oomBuildingServiceConnectionMapper;
	
	@Autowired
	private OomBuildingServiceConnectionIpMapper oomBuildingServiceConnectionIpMapper;
	
	/**
	 * 
	 * listBuildingServiceForCombo
	 *
	 * @param reqOomBuildingServiceDto
	 * @return List<BuildingServiceForComboResultDto>
	 * @throws Exception 
	 */
	@Override
	public List<BuildingServiceForComboResultDto> listBuildingServiceForCombo(OomBuildingServiceDto reqOomBuildingServiceDto) throws Exception {
		
		List<BuildingServiceForComboResultDto> buildingServiceForComboResultDtoList = null;
		try {
			buildingServiceForComboResultDtoList = oomBuildingServiceMapper.listBuildingServiceForCombo(reqOomBuildingServiceDto);
			
		} catch (Exception e) {
			throw e;
		}
		return buildingServiceForComboResultDtoList;
	}
	
	/**
	 * 
	 * listBuildingServiceUseYn
	 *
	 * @param reqOomBuildingServiceDto
	 * @return List<BuildingServiceUseYnResultDto>
	 * @throws Exception 
	 */
	@Override
	public List<BuildingServiceUseYnResultDto> listBuildingServiceUseYn(OomBuildingServiceDto reqOomBuildingServiceDto) throws Exception {
		
		List<BuildingServiceUseYnResultDto> buildingServiceUseYnResultDtoList = null;
		try {
			buildingServiceUseYnResultDtoList = oomBuildingServiceMapper.listBuildingServiceUseYn(reqOomBuildingServiceDto);
			
		} catch (Exception e) {
			throw e;
		}
		return buildingServiceUseYnResultDtoList;
	}
	
	/**
	 * 
	 * readBuildingServiceConnection
	 *
	 * @param reqOomBuildingServiceConnectionDto
	 * @return OomBuildingServiceConnectionDto
	 * @throws Exception 
	 */
	@Override
	public OomBuildingServiceConnectionDto readBuildingServiceConnection(OomBuildingServiceConnectionDto reqOomBuildingServiceConnectionDto) throws Exception {
		
		OomBuildingServiceConnectionDto rsltOomBuildingServiceConnectionDto = null;
		try {
			rsltOomBuildingServiceConnectionDto = oomBuildingServiceConnectionMapper.readBuildingServiceConnection(reqOomBuildingServiceConnectionDto);
			
		} catch (Exception e) {
			throw e;
		}
		return rsltOomBuildingServiceConnectionDto;
	}
	
	/**
	 * 
	 * readBuildingServiceConnectionCount
	 *
	 * @param reqOomBuildingServiceConnectionDto
	 * @return int
	 * @throws Exception 
	 */
	@Override
	public int readBuildingServiceConnectionCount(OomBuildingServiceConnectionDto reqOomBuildingServiceConnectionDto) throws Exception {
		
		int connectionCount = 0;
		try {
			connectionCount = oomBuildingServiceConnectionMapper.readBuildingServiceConnectionCount(reqOomBuildingServiceConnectionDto);
			
		} catch (Exception e) {
			throw e;
		}
		return connectionCount;
	}
	
	/**
	 * 
	 * listBuildingServiceConnection
	 *
	 * @param reqOomBuildingServiceConnectionDto
	 * @return List<OomBuildingServiceConnectionDto>
	 * @throws Exception 
	 */
	@Override
	public List<OomBuildingServiceConnectionDto> listBuildingServiceConnection(OomBuildingServiceConnectionDto reqOomBuildingServiceConnectionDto) throws Exception {
		
		List<OomBuildingServiceConnectionDto> rsltOomBuildingServiceConnectionDtoList = null;
		try {
			rsltOomBuildingServiceConnectionDtoList = oomBuildingServiceConnectionMapper.listBuildingServiceConnection(reqOomBuildingServiceConnectionDto);
			
		} catch (Exception e) {
			throw e;
		}
		return rsltOomBuildingServiceConnectionDtoList;
	}
	
	/**
	 * 
	 * listBuildingServiceConnectionIp
	 *
	 * @param reqOomBuildingServiceConnectionIpDto
	 * @return List<OomBuildingServiceConnectionIpDto>
	 * @throws Exception 
	 */
	@Override
	public List<OomBuildingServiceConnectionIpDto> listBuildingServiceConnectionIp(OomBuildingServiceConnectionIpDto reqOomBuildingServiceConnectionIpDto) throws Exception {
		
		List<OomBuildingServiceConnectionIpDto> rsltOomBuildingServiceConnectionIpDtoList = null;
		try {
			rsltOomBuildingServiceConnectionIpDtoList = oomBuildingServiceConnectionIpMapper.listBuildingServiceConnectionIp(reqOomBuildingServiceConnectionIpDto);
			
		} catch (Exception e) {
			throw e;
		}
		return rsltOomBuildingServiceConnectionIpDtoList;
	}
	
	/**
	 * 
	 * listPageBuildingServiceConnection
	 *
	 * @param buildingServiceConnectionGridRequestDto
	 * @return List<BuildingServiceConnectionGridResultDto>
	 * @throws Exception 
	 */
	@Override
	public List<BuildingServiceConnectionGridResultDto> listPageBuildingServiceConnection(BuildingServiceConnectionGridRequestDto buildingServiceConnectionGridRequestDto) throws Exception {
		
		List<BuildingServiceConnectionGridResultDto> buildingServiceConnectionGridResultDtoList = null;
		try {
			buildingServiceConnectionGridResultDtoList = oomBuildingServiceConnectionMapper.listPageBuildingServiceConnection(buildingServiceConnectionGridRequestDto);
    		
		} catch (Exception e) {
			throw e;
		}
		return buildingServiceConnectionGridResultDtoList;
	}
	
	/**
	 * 
	 * readBuildingServiceConnectionInfo
	 *
	 * @param reqOomBuildingServiceConnectionDto
	 * @return BuildingServiceConnectionDetailResultDto
	 * @throws Exception 
	 */
	@Override
	public BuildingServiceConnectionDetailResultDto readBuildingServiceConnectionInfo(OomBuildingServiceConnectionDto reqOomBuildingServiceConnectionDto) throws Exception {
		
		BuildingServiceConnectionDetailResultDto buildingServiceConnectionDetailResultDto = null;
		try {
			buildingServiceConnectionDetailResultDto = oomBuildingServiceConnectionMapper.readOomBuildingServiceConnectionInfo(reqOomBuildingServiceConnectionDto);
			if (buildingServiceConnectionDetailResultDto != null) {
				String bldId = StringUtils.defaultString(buildingServiceConnectionDetailResultDto.getBldId());
				String serviceClCd = StringUtils.defaultString(buildingServiceConnectionDetailResultDto.getServiceClCd());
				String serviceSysName = StringUtils.defaultString(buildingServiceConnectionDetailResultDto.getServiceSysName());
				String linkageStandardVersionVal = StringUtils.defaultString(buildingServiceConnectionDetailResultDto.getLinkageStandardVersionVal());
				OomBuildingServiceConnectionIpDto reqOomBuildingServiceConnectionIpDto = new OomBuildingServiceConnectionIpDto();
				reqOomBuildingServiceConnectionIpDto.setBldId(bldId);
				reqOomBuildingServiceConnectionIpDto.setServiceClCd(serviceClCd);
				reqOomBuildingServiceConnectionIpDto.setServiceSysName(serviceSysName);
				reqOomBuildingServiceConnectionIpDto.setLinkageStandardVersionVal(linkageStandardVersionVal);
				List<BuildingServiceConnectionIpDetailDto> buildingServiceConnectionIpDetailDtoList = oomBuildingServiceConnectionIpMapper.listBuildingServiceConnectionIpDetail(reqOomBuildingServiceConnectionIpDto);
				buildingServiceConnectionDetailResultDto.setConnectionIpList(buildingServiceConnectionIpDetailDtoList);
			}
			
		} catch (Exception e) {
			throw e;
		}
		return buildingServiceConnectionDetailResultDto;
	}

}
