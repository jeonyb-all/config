package com.adtcaps.tsop.onm.api.threshold.service.impl;

import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.CollectionUtils;

import com.adtcaps.tsop.onm.api.domain.OomTenantResourceMonitoringThresholdDto;
import com.adtcaps.tsop.onm.api.helper.util.CommonDateUtil;
import com.adtcaps.tsop.onm.api.threshold.domain.ThresholdDetailResultDto;
import com.adtcaps.tsop.onm.api.threshold.domain.ThresholdGridRequestDto;
import com.adtcaps.tsop.onm.api.threshold.domain.ThresholdGridResultDto;
import com.adtcaps.tsop.onm.api.threshold.mapper.OomTenantResourceMonitoringThresholdMapper;
import com.adtcaps.tsop.onm.api.threshold.service.ThresholdService;

/**
 * 
 * <ul>
 * <li>업무 그룹명 : tsop-onm-api</li>
 * <li>서브 업무명 : com.adtcaps.tsop.onm.api.threshold.service.impl</li>
 * <li>설  명 : ThresholdServiceImpl.java</li>
 * <li>작성일 : 2021. 1. 17.</li>
 * <li>작성자 : jeonyb4</li>
 * </ul>
 */
@Transactional
@Service
public class ThresholdServiceImpl implements ThresholdService {
	
	@Autowired
	private OomTenantResourceMonitoringThresholdMapper oomTenantResourceMonitoringThresholdMapper;
	
	/**
	 * 
	 * listPageThreshold
	 *
	 * @param thresholdGridRequestDto
	 * @return List<ThresholdGridResultDto>
	 * @throws Exception 
	 */
	@Override
	public List<ThresholdGridResultDto> listPageThreshold(ThresholdGridRequestDto thresholdGridRequestDto) throws Exception {
		
		List<ThresholdGridResultDto> thresholdGridResultDtoList = null;
		try {
			// 임계치 목록조회
    		thresholdGridResultDtoList = oomTenantResourceMonitoringThresholdMapper.listPageTenantResourceMonitoringThreshold(thresholdGridRequestDto);
    		if (!CollectionUtils.isEmpty(thresholdGridResultDtoList)) {
    			for (int idx = 0; idx < thresholdGridResultDtoList.size(); idx++) {
    				
    				ThresholdGridResultDto thresholdGridResultDto = thresholdGridResultDtoList.get(idx);
    				
    				String registDatetime = StringUtils.defaultString(thresholdGridResultDto.getRegistDatetime());
    				registDatetime = CommonDateUtil.makeDatetimeFormat(registDatetime);
    				thresholdGridResultDto.setRegistDatetime(registDatetime);
    				
    				thresholdGridResultDtoList.set(idx, thresholdGridResultDto);
    			}
    		}
    		
		} catch (Exception e) {
			throw e;
		}
		return thresholdGridResultDtoList;
	}
	
	/**
	 * 
	 * createThreshold
	 *
	 * @param reqOomTenantResourceMonitoringThresholdDto
	 * @return int
	 * @throws Exception 
	 */
	@Override
	public int createThreshold(OomTenantResourceMonitoringThresholdDto reqOomTenantResourceMonitoringThresholdDto) throws Exception {
		
		int affectRowCount = 0;
		
		try {
			// 임계치 등록...
			int insertRow = oomTenantResourceMonitoringThresholdMapper.createOomTenantResourceMonitoringThreshold(reqOomTenantResourceMonitoringThresholdDto);
			affectRowCount = affectRowCount + insertRow;
			
		} catch (Exception e) {
			throw e;
		}
		
		return affectRowCount;
	}
	
	/**
	 * 
	 * readThreshold
	 *
	 * @param reqOomTenantResourceMonitoringThresholdDto
	 * @return ThresholdDetailResultDto
	 * @throws Exception 
	 */
	@Override
	public ThresholdDetailResultDto readThreshold(OomTenantResourceMonitoringThresholdDto reqOomTenantResourceMonitoringThresholdDto) throws Exception {
		
		ThresholdDetailResultDto thresholdDetailResultDto = null;
		try {
			thresholdDetailResultDto = oomTenantResourceMonitoringThresholdMapper.readOomTenantResourceMonitoringThreshold(reqOomTenantResourceMonitoringThresholdDto);
			if (thresholdDetailResultDto != null) {
				String registDatetime = StringUtils.defaultString(thresholdDetailResultDto.getRegistDatetime());
				registDatetime = CommonDateUtil.makeDatetimeFormat(registDatetime);
				thresholdDetailResultDto.setRegistDatetime(registDatetime);
			}
		} catch (Exception e) {
			throw e;
		}
		return thresholdDetailResultDto;
	}
	
	/**
	 * 
	 * updateThreshold
	 *
	 * @param reqOomTenantResourceMonitoringThresholdDto
	 * @return int
	 * @throws Exception 
	 */
	@Override
	public int updateThreshold(OomTenantResourceMonitoringThresholdDto reqOomTenantResourceMonitoringThresholdDto) throws Exception {
		
		int affectRowCount = 0;
		
		try {
			// 임계치 수정...
			int updateRow = oomTenantResourceMonitoringThresholdMapper.updateOomTenantResourceMonitoringThreshold(reqOomTenantResourceMonitoringThresholdDto);
			affectRowCount = affectRowCount + updateRow;
			
		} catch (Exception e) {
			throw e;
		}
		
		return affectRowCount;
	}
	
	/**
	 * 
	 * deleteThreshold
	 *
	 * @param reqOomTenantResourceMonitoringThresholdDto
	 * @return int
	 * @throws Exception 
	 */
	@Override
	public int deleteThreshold(OomTenantResourceMonitoringThresholdDto reqOomTenantResourceMonitoringThresholdDto) throws Exception {
		
		int affectRowCount = 0;
		
		try {
			// 임계치 삭제...
			int deleteRow = oomTenantResourceMonitoringThresholdMapper.deleteOomTenantResourceMonitoringThreshold(reqOomTenantResourceMonitoringThresholdDto);
			affectRowCount = affectRowCount + deleteRow;
			
		} catch (Exception e) {
			throw e;
		}
		
		return affectRowCount;
	}

}
