package com.adtcaps.tsop.onm.api.alarm.service.impl;

import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.CollectionUtils;

import com.adtcaps.tsop.onm.api.alarm.domain.AlarmNoticeConditionDetailResultDto;
import com.adtcaps.tsop.onm.api.alarm.domain.AlarmNoticeConditionGridRequestDto;
import com.adtcaps.tsop.onm.api.alarm.domain.AlarmNoticeConditionGridResultDto;
import com.adtcaps.tsop.onm.api.alarm.mapper.OomAlarmNoticeConditionMapper;
import com.adtcaps.tsop.onm.api.alarm.service.AlarmNoticeService;
import com.adtcaps.tsop.onm.api.domain.OomAlarmNoticeConditionDto;
import com.adtcaps.tsop.onm.api.helper.constant.Const;
import com.adtcaps.tsop.onm.api.helper.util.CommonDateUtil;

/**
 * 
 * <ul>
 * <li>업무 그룹명 : tsop-onm-api</li>
 * <li>서브 업무명 : com.adtcaps.tsop.onm.api.alarm.service.impl</li>
 * <li>설  명 : AlarmNoticeServiceImpl.java</li>
 * <li>작성일 : 2021. 1. 17.</li>
 * <li>작성자 : jeonyb4</li>
 * </ul>
 */
@Transactional
@Service
public class AlarmNoticeServiceImpl implements AlarmNoticeService {
	
	@Autowired
	private OomAlarmNoticeConditionMapper oomAlarmNoticeConditionMapper;
	
	/**
	 * 
	 * listPageAlarmNoticeCondition
	 *
	 * @param alarmNoticeConditionGridRequestDto
	 * @return List<AlarmNoticeConditionGridResultDto>
	 * @throws Exception 
	 */
	@Override
	public List<AlarmNoticeConditionGridResultDto> listPageAlarmNoticeCondition(AlarmNoticeConditionGridRequestDto alarmNoticeConditionGridRequestDto) throws Exception {
		
		List<AlarmNoticeConditionGridResultDto> alarmNoticeConditionGridResultDtoList = null;
		try {
			alarmNoticeConditionGridResultDtoList = oomAlarmNoticeConditionMapper.listPageAlarmNoticeCondition(alarmNoticeConditionGridRequestDto);
			if (!CollectionUtils.isEmpty(alarmNoticeConditionGridResultDtoList)) {
    			for (int idx = 0; idx < alarmNoticeConditionGridResultDtoList.size(); idx++) {
    				
    				AlarmNoticeConditionGridResultDto alarmNoticeConditionGridResultDto = alarmNoticeConditionGridResultDtoList.get(idx);
    				
    				String registDatetime = StringUtils.defaultString(alarmNoticeConditionGridResultDto.getRegistDatetime());
    				registDatetime = CommonDateUtil.makeDatetimeFormat(registDatetime);
    				alarmNoticeConditionGridResultDto.setRegistDatetime(registDatetime);
    				
    				String useYn = StringUtils.defaultString(alarmNoticeConditionGridResultDto.getUseYn());
    				if ("Y".equals(useYn)) {
    					alarmNoticeConditionGridResultDto.setUseYn(Const.Definition.USE_YN.USE);
    				} else {
    					alarmNoticeConditionGridResultDto.setUseYn(Const.Definition.USE_YN.NO_USE);
    				}
    				
    				alarmNoticeConditionGridResultDtoList.set(idx, alarmNoticeConditionGridResultDto);
    			}
    		}
    		
		} catch (Exception e) {
			throw e;
		}
		return alarmNoticeConditionGridResultDtoList;
	}
	
	/**
	 * 
	 * readAlarmNoticeDuplicationCheck
	 *
	 * @param reqOomAlarmNoticeConditionDto
	 * @return OomAlarmNoticeConditionDto
	 * @throws Exception 
	 */
	@Override
	public OomAlarmNoticeConditionDto readAlarmNoticeDuplicationCheck(OomAlarmNoticeConditionDto reqOomAlarmNoticeConditionDto) throws Exception {
		
		OomAlarmNoticeConditionDto rsltOomAlarmNoticeConditionDto = null;
		try {
			rsltOomAlarmNoticeConditionDto = oomAlarmNoticeConditionMapper.readAlarmNoticeDuplicationCheck(reqOomAlarmNoticeConditionDto);
		} catch (Exception e) {
			throw e;
		}
		return rsltOomAlarmNoticeConditionDto;
	}
	
	/**
	 * 
	 * createAlarmNoticeCondition
	 *
	 * @param reqOomAlarmNoticeConditionDto
	 * @return int
	 * @throws Exception 
	 */
	@Override
	public int createAlarmNoticeCondition(OomAlarmNoticeConditionDto reqOomAlarmNoticeConditionDto) throws Exception {
		
		int affectRowCount = 0;
		
		try {
			int insertRow = oomAlarmNoticeConditionMapper.createOomAlarmNoticeCondition(reqOomAlarmNoticeConditionDto);
			affectRowCount = affectRowCount + insertRow;
			
		} catch (Exception e) {
			throw e;
		}
		
		return affectRowCount;
	}
	
	/**
	 * 
	 * readAlarmNoticeCondition
	 *
	 * @param reqOomAlarmNoticeConditionDto
	 * @return AlarmNoticeConditionDetailResultDto
	 * @throws Exception 
	 */
	@Override
	public AlarmNoticeConditionDetailResultDto readAlarmNoticeCondition(OomAlarmNoticeConditionDto reqOomAlarmNoticeConditionDto) throws Exception {
		
		AlarmNoticeConditionDetailResultDto alarmNoticeConditionDetailResultDto = null;
		try {
			alarmNoticeConditionDetailResultDto = oomAlarmNoticeConditionMapper.readAlarmNoticeCondition(reqOomAlarmNoticeConditionDto);
		} catch (Exception e) {
			throw e;
		}
		return alarmNoticeConditionDetailResultDto;
	}
	
	/**
	 * 
	 * updateAlarmNoticeCondition
	 *
	 * @param reqOomAlarmNoticeConditionDto
	 * @return int
	 * @throws Exception 
	 */
	@Override
	public int updateAlarmNoticeCondition(OomAlarmNoticeConditionDto reqOomAlarmNoticeConditionDto) throws Exception {
		
		int affectRowCount = 0;
		
		try {
			int updateRow = oomAlarmNoticeConditionMapper.updateOomAlarmNoticeCondition(reqOomAlarmNoticeConditionDto);
			affectRowCount = affectRowCount + updateRow;
			
		} catch (Exception e) {
			throw e;
		}
		
		return affectRowCount;
	}
	
	/**
	 * 
	 * deleteAlarmNoticeCondition
	 *
	 * @param reqOomAlarmNoticeConditionDto
	 * @return int
	 * @throws Exception 
	 */
	@Override
	public int deleteAlarmNoticeCondition(OomAlarmNoticeConditionDto reqOomAlarmNoticeConditionDto) throws Exception {
		
		int affectRowCount = 0;
		
		try {
			int deleteRow = oomAlarmNoticeConditionMapper.deleteOomAlarmNoticeCondition(reqOomAlarmNoticeConditionDto);
			affectRowCount = affectRowCount + deleteRow;
			
		} catch (Exception e) {
			throw e;
		}
		
		return affectRowCount;
	}
	
	/**
	 * 
	 * readAlarmNoticeCountForReceiveGroup
	 *
	 * @param reqOomAlarmNoticeConditionDto
	 * @return int
	 * @throws Exception 
	 */
	@Override
	public int readAlarmNoticeCountForReceiveGroup(OomAlarmNoticeConditionDto reqOomAlarmNoticeConditionDto) throws Exception {
		
		int conditionCount = 0;
		
		try {
			conditionCount = oomAlarmNoticeConditionMapper.readAlarmNoticeCountForReceiveGroup(reqOomAlarmNoticeConditionDto);
			
		} catch (Exception e) {
			throw e;
		}
		
		return conditionCount;
	}
	
	/**
	 * 
	 * updateAlarmNoticeConditionReuse
	 *
	 * @param reqOomAlarmNoticeConditionDto
	 * @return int
	 * @throws Exception 
	 */
	@Override
	public int updateAlarmNoticeConditionReuse(OomAlarmNoticeConditionDto reqOomAlarmNoticeConditionDto) throws Exception {
		
		int affectRowCount = 0;
		
		try {
			int updateRow = oomAlarmNoticeConditionMapper.updateAlarmNoticeConditionReuse(reqOomAlarmNoticeConditionDto);
			affectRowCount = affectRowCount + updateRow;
			
		} catch (Exception e) {
			throw e;
		}
		
		return affectRowCount;
	}

}
