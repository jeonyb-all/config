package com.adtcaps.tsop.onm.api.alimTalk.controller;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.adtcaps.tsop.onm.api.alimTalk.domain.AlimTalkBatchResultDto;
import com.adtcaps.tsop.onm.api.alimTalk.domain.AlimTalkRequestDto;
import com.adtcaps.tsop.onm.api.alimTalk.service.AlimTalkService;
import com.adtcaps.tsop.onm.api.config.TenantConfig;
import com.adtcaps.tsop.onm.api.helper.constant.Const;
import com.adtcaps.tsop.onm.api.helper.domain.ResultDto;

@RestController
@RequestMapping("/api/server/alim-talk")
public class AlimTalkController {
	private final String ERR_MSG_NULL_TMPLT_CODE = "템플릿 코드가 없습니다.";
	private final String ERR_MSG_NULL_RECIPIENT = "수신자 번호가 없습니다.";
	private final String ERR_MSG_NULL_MESSAGE = "발신 메시지가 없습니다.";
	private final String ERR_MSG_ALIM_TALK_SEND_FAIL = "알림톡 발송에 실패하였습니다. 잠시 후 다시 시도해주세요";
	private final String ERR_MSG_SMS_SEND_FAIL = "SMS 발송에 실패하였습니다. 잠시 후 다시 시도해주세요";
	private final String ERR_MSG_NULL_KEY = "Key값이 없습니다.";
	private final String ERR_MSG_KEY_AUTH_FAIL = "Key 인증에 실패하였습니다.";

	private static final Logger LOGGER = LoggerFactory.getLogger(AlimTalkController.class);

	@Autowired
	AlimTalkService alimTalkService;

	@Autowired
	private TenantConfig tenantConfig;

	/**
	 * sendAlimTalk
	 * @param alimTalkRequestDto
	 * @param request
	 * @return ResponseEntity
	 * @throws Exception
	 */
	@SuppressWarnings("rawtypes")
	@PostMapping(value = "" , produces="application/json; charset=UTF-8")
	public ResponseEntity sendAlimTalk(
			@RequestBody AlimTalkRequestDto alimTalkRequestDto,
			HttpServletRequest request) throws Exception {
		LOGGER.debug("### /api/server/alim-talk/");
		ResponseEntity<ResultDto> resEntity = null;
		String returnString = "";

		String callKey = StringUtils.defaultString(request.getHeader("Call-Key"));
		String key = StringUtils.defaultString(tenantConfig.getMyServerInfo().getKey());
		if ("".equals(callKey) || "".equals(key)) {
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_KEY));
			return resEntity;
		}
		if (!callKey.equals(key)) {
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_KEY_AUTH_FAIL));
			return resEntity;
		}

		if ("".equals(alimTalkRequestDto.getTmpltCode()) || "".equals(alimTalkRequestDto.getTmpltCode())) {
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_TMPLT_CODE));
			return resEntity;
		}
		if ("".equals(alimTalkRequestDto.getRecipient()) || "".equals(alimTalkRequestDto.getRecipient())) {
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_RECIPIENT));
			return resEntity;
		}
		if ("".equals(alimTalkRequestDto.getMessage()) || "".equals(alimTalkRequestDto.getMessage())) {
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_MESSAGE));
			return resEntity;
		}

		AlimTalkBatchResultDto alimTalkBatchResultDto = alimTalkService.sendAlimTalk(alimTalkRequestDto);

		if (alimTalkBatchResultDto == null) {
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_ALIM_TALK_SEND_FAIL, alimTalkBatchResultDto));
		} else {
			String responseCode = alimTalkBatchResultDto.getResponseCode();

			if ("alimtalk".equals(alimTalkBatchResultDto.getSender())) {
				if ("1000".equals(responseCode)) {
					returnString = Const.Common.RESULT_CODE.SUCCESS;
	    			resEntity = ResponseEntity.ok(new ResultDto(returnString, "", alimTalkBatchResultDto));
				} else {
					returnString = Const.Common.RESULT_CODE.FAIL;
					resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_ALIM_TALK_SEND_FAIL, alimTalkBatchResultDto));
				}
			} else if ("sms".equals(alimTalkBatchResultDto.getSender())) {
				if ("01".equals(responseCode) || "1000".equals(responseCode)) {
					returnString = Const.Common.RESULT_CODE.SUCCESS;
	    			resEntity = ResponseEntity.ok(new ResultDto(returnString, "", alimTalkBatchResultDto));
				} else {
					returnString = Const.Common.RESULT_CODE.FAIL;
					resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_SMS_SEND_FAIL, alimTalkBatchResultDto));
				}
			}
		}

		return resEntity;
	}
}
