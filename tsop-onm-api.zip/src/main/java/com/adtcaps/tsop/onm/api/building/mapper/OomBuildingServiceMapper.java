package com.adtcaps.tsop.onm.api.building.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;

import com.adtcaps.tsop.onm.api.building.domain.BuildingServiceForComboResultDto;
import com.adtcaps.tsop.onm.api.building.domain.BuildingServiceUseYnResultDto;
import com.adtcaps.tsop.onm.api.domain.OomBuildingServiceDto;

/**
 * 
 * <ul>
 * <li>업무 그룹명 : tsop-onm-api</li>
 * <li>서브 업무명 : com.adtcaps.tsop.onm.api.building.mapper</li>
 * <li>설  명 : OomBuildingServiceMapper.java</li>
 * <li>작성일 : 2021. 1. 6.</li>
 * <li>작성자 : jeonyb4</li>
 * </ul>
 */
@Mapper
public interface OomBuildingServiceMapper {
	/**
	 * 
	 * listBuildingServiceForCombo
	 *
	 * @param reqOomBuildingServiceDto
	 * @return List<BuildingServiceForComboResultDto>
	 */
	public List<BuildingServiceForComboResultDto> listBuildingServiceForCombo(OomBuildingServiceDto reqOomBuildingServiceDto);
	
	/**
	 * 
	 * listBuildingServiceUseYn
	 *
	 * @param reqOomBuildingServiceDto
	 * @return List<BuildingServiceUseYnResultDto>
	 */
	public List<BuildingServiceUseYnResultDto> listBuildingServiceUseYn(OomBuildingServiceDto reqOomBuildingServiceDto);
	

}
