package com.adtcaps.tsop.onm.api.service.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;

import com.adtcaps.tsop.onm.api.domain.OomServiceConnectionApiListDto;
import com.adtcaps.tsop.onm.api.service.domain.ServiceConnectionApiExcelDto;

/**
 * 
 * <ul>
 * <li>업무 그룹명 : tsop-onm-api</li>
 * <li>서브 업무명 : com.adtcaps.tsop.onm.api.service.mapper</li>
 * <li>설  명 : OomServiceConnectionApiListMapper.java</li>
 * <li>작성일 : 2021. 1. 26.</li>
 * <li>작성자 : jeonyb4</li>
 * </ul>
 */
@Mapper
public interface OomServiceConnectionApiListMapper {
	/**
	 * 
	 * createOomServiceConnectionApiList
	 *
	 * @param reqOomServiceConnectionApiListDto
	 * @return int
	 */
	public int createOomServiceConnectionApiList(OomServiceConnectionApiListDto reqOomServiceConnectionApiListDto);
	
	/**
	 * 
	 * deleteOomServiceConnectionApiList
	 *
	 * @param reqOomServiceConnectionApiListDto
	 * @return int
	 */
	public int deleteOomServiceConnectionApiList(OomServiceConnectionApiListDto reqOomServiceConnectionApiListDto);
	
	/**
	 * 
	 * listServiceConnectionApiList
	 *
	 * @param reqOomServiceConnectionApiListDto
	 * @return List<ServiceConnectionApiExcelDto>
	 */
	public List<ServiceConnectionApiExcelDto> listServiceConnectionApiList(OomServiceConnectionApiListDto reqOomServiceConnectionApiListDto);

}
