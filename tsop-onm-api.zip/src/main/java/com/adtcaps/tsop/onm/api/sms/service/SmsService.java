package com.adtcaps.tsop.onm.api.sms.service;

import com.adtcaps.tsop.onm.api.sms.domain.SmsApiResponse;
import java.util.Map;

/**
 * SmsService.
 * @author zeal77@sk.com
 */
public interface SmsService {
    /**
     * SMS 전송
     *
     * @param request 요청 들어온 HttpServletRequest 객체
     * @param smsContent 요청 들어온 Parameter
     * @return TsoEventResponse
     */
    public SmsApiResponse sendSms(Map<String, Object> smsContent) throws Exception;
}
