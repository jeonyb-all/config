package com.adtcaps.tsop.onm.api.work.domain;

import java.util.List;

import com.adtcaps.tsop.onm.api.deploy.domain.PackageDeployJobDetailResultDto;
import com.adtcaps.tsop.onm.api.domain.OomWorkBuildingDto;
import com.adtcaps.tsop.onm.api.domain.OomWorkTenantDto;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

import lombok.Getter;
import lombok.Setter;

/**
 * 
 * <ul>
 * <li>업무 그룹명 : tsop-onm-api</li>
 * <li>서브 업무명 : com.adtcaps.tsop.onm.api.work.domain</li>
 * <li>설  명 : CurrentWorkDetailResultDto.java</li>
 * <li>작성일 : 2021. 2. 1.</li>
 * <li>작성자 : jeonyb4</li>
 * </ul>
 */
@Getter
@Setter
@JsonInclude(Include.NON_EMPTY)
public class CurrentWorkDetailResultDto {
	private Integer onmWorkId;
	private String onmWorkTypeCd;
	private String currentWorkStatusCd;
	private String currentWorkStatusDetailCd;
	private String currentWorkStatusFinishCd;
	private String nextWorkStatusCd;
	private String currentTenantId;
	private String currentTenantName;
	private String currentBldId;
	private String currentBldName;
	private String currentServiceClCd;
	private Integer techSupportReqId;
	private String auditId;
	
	private OomWorkTenantDto tenantInfo;
	private List<OomWorkBuildingDto> buildingList;
	private List<WorkBuildingServiceUseYnDto> serviceList;
	private List<SearchWorkConnectionIpDto> serviceConnectionIpList;
	private List<WorkStatusDetailResultDto> verifyWorkList;
	private List<InterfaceWorkDetailResultDto> interfaceList;
	private WorkTenantResourceDto tenantResourceInfo;
	private PackageDeployJobDetailResultDto packageDeployInfo;

}
