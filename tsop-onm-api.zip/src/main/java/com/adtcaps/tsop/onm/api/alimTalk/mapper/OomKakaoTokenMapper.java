package com.adtcaps.tsop.onm.api.alimTalk.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;

import com.adtcaps.tsop.onm.api.domain.OomKakaoTokenDto;

/**
 * <ul>
 * <li>업무 그룹명 : tsop-backend-api</li>
 * <li>서브 업무명 : com.adtcaps.tsop.onm.api.alimTalk.mapper</li>
 * <li>설  명 : OomKakaoTokenMapper.java</li>
 * <li>작성일 : 2021. 12. 24.</li>
 * <li>작성자 : vader</li>
 * </ul>
 */
@Mapper
public interface OomKakaoTokenMapper {
	/**
	 * createOomKakaoToken
	 * @param oomKakaoTokenDto
	 * @return int
	 */
	public int createOomKakaoToken(OomKakaoTokenDto oomKakaoTokenDto);

	/**
	 * updateOomKakaoToken
	 * @param oomKakaoTokenDto
	 * @return int
	 */
	public int updateOomKakaoToken(OomKakaoTokenDto oomKakaoTokenDto);

	/**
	 * listOomKakaoToken
	 * @param oomKakaoTokenDto
	 * @return List<OomKakaoTokenDto>
	 */
	public List<OomKakaoTokenDto> listOomKakaoToken();
}
