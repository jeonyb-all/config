package com.adtcaps.tsop.onm.api.domain;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

import lombok.Getter;
import lombok.Setter;

/**
 * 
 * <ul>
 * <li>업무 그룹명 : tsop-onm-api</li>
 * <li>서브 업무명 : com.adtcaps.tsop.onm.api.domain</li>
 * <li>설  명 : OomCommonCodeDetailDto.java</li>
 * <li>작성일 : 2021. 1. 4.</li>
 * <li>작성자 : jeonyb4</li>
 * </ul>
 */
@Getter
@Setter
@JsonInclude(Include.NON_EMPTY)
public class OomCommonCodeDetailDto {
	private String commonCd;
	private String commonCdVal;
	private String auditDatetime;
	private String auditId;
	private String commonCdValName;
	private String commonCdValDesc;
	private String effectStartDatetime;
	private String effectEndDatetime;
	private Integer sortSeq;
	private String superCommonCd;
	private String superCommonCdVal;

}
