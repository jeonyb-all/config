package com.adtcaps.tsop.onm.api.config;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.adtcaps.tsop.onm.api.config.domain.TenantDto;

/**
 * 
 * <ul>
 * <li>업무 그룹명 : tsop-onm-api</li>
 * <li>서브 업무명 : com.adtcaps.tsop.onm.api.config</li>
 * <li>설  명 : TenantConfig.java</li>
 * <li>작성일 : 2021. 1. 9.</li>
 * <li>작성자 : jeonyb4</li>
 * </ul>
 */
@Configuration
public class TenantConfig {
	
	private static String OS = System.getProperty("os.name").toLowerCase();
	
	/**
	 * 
	 * getMyConfig
	 *
	 * @return TenantDto
	 */
	@Bean
    @ConfigurationProperties("tenant.my")
    public TenantDto getMyConfig() {
		return new TenantDto();
    }
	
	@Bean
	public TenantDto getMyServerInfo() {
		
		TenantDto tenantDto = getMyConfig();
		return tenantDto;
	}
	
	/**
	 * 
	 * getTenantSktConfig
	 *
	 * @return TenantDto
	 */
	@Bean
    @ConfigurationProperties("tenant.skt")
    public TenantDto getTenantSktConfig() {
		return new TenantDto();
    }
	
	@Bean
	public TenantDto getTenantSktServerInfo() {
		
		TenantDto tenantDto = getTenantSktConfig();
		if (OS.indexOf("win") >= 0) {
			tenantDto.setUrl(tenantDto.getTestUrl());
		}
		
		return tenantDto;
	}

}
