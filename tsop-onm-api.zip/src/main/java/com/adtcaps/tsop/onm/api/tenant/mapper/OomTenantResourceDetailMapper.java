package com.adtcaps.tsop.onm.api.tenant.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;

import com.adtcaps.tsop.onm.api.dashboard.domain.DashboardRequestDto;
import com.adtcaps.tsop.onm.api.domain.OomTenantResourceDetailDto;
import com.adtcaps.tsop.onm.api.tenant.domain.TenantResourceDetailGridResultDto;
import com.adtcaps.tsop.onm.api.tenant.domain.TenantResourceForComboResultDto;

/**
 * 
 * <ul>
 * <li>업무 그룹명 : tsop-onm-api</li>
 * <li>서브 업무명 : com.adtcaps.tsop.onm.api.tenant.mapper</li>
 * <li>설  명 : OomTenantResourceDetailMapper.java</li>
 * <li>작성일 : 2021. 1. 6.</li>
 * <li>작성자 : jeonyb4</li>
 * </ul>
 */
@Mapper
public interface OomTenantResourceDetailMapper {
	/**
	 * 
	 * listTenantResourceForThresholdCombo
	 *
	 * @param reqOomTenantResourceDetailDto
	 * @return List<TenantResourceForComboResultDto>
	 */
	public List<TenantResourceForComboResultDto> listTenantResourceForThresholdCombo(OomTenantResourceDetailDto reqOomTenantResourceDetailDto);
	
	/**
	 * 
	 * listTenantResourceDetail
	 *
	 * @param reqOomTenantResourceDetailDto
	 * @return List<TenantResourceDetailGridResultDto>
	 */
	public List<TenantResourceDetailGridResultDto> listTenantResourceDetail(OomTenantResourceDetailDto reqOomTenantResourceDetailDto);
	
	/**
	 * 
	 * listTenantResourceDetailForWork
	 *
	 * @param reqOomTenantResourceDetailDto
	 * @return List<OomTenantResourceDetailDto>
	 */
	public List<OomTenantResourceDetailDto> listTenantResourceDetailForWork(OomTenantResourceDetailDto reqOomTenantResourceDetailDto);
	
	
	
	
	
	/**
	 * 
	 * getCountTenantResourceDetail - dashboard
	 * 
	 * @param tenantId
	 * @return integer
	 */
	public int getCountTenantResourceDetail(DashboardRequestDto reqDashboardDto);
	
}
