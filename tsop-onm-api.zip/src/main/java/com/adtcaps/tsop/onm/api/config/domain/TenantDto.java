package com.adtcaps.tsop.onm.api.config.domain;

import lombok.Getter;
import lombok.Setter;

/**
 * 
 * <ul>
 * <li>업무 그룹명 : tsop-onm-api</li>
 * <li>서브 업무명 : com.adtcaps.tsop.onm.api.config.domain</li>
 * <li>설  명 : TenantDto.java</li>
 * <li>작성일 : 2021. 1. 9.</li>
 * <li>작성자 : jeonyb4</li>
 * </ul>
 */
@Getter
@Setter
public class TenantDto {
	private String key;
	private String url;
	private String testUrl;
	private String actionYn;

}
