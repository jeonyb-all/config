package com.adtcaps.tsop.onm.api.domain;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class OomKakaoSendHistDto {
	private String msgIdx;
	private String transDatetime;
	private String rcvPhoneNum;
	private String msgContent;
	private String requestAt;
	private String receivedAt;
	private String resultCode;
	private String tenantName;
	private String resultSendYn;
	private String fromDate;
	private String toDate;
	private String sender;
}
