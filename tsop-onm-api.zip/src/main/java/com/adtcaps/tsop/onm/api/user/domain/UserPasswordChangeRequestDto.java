package com.adtcaps.tsop.onm.api.user.domain;

import lombok.Getter;
import lombok.Setter;

/**
 * 
 * <ul>
 * <li>업무 그룹명 : tsop-onm-api</li>
 * <li>서브 업무명 : com.adtcaps.tsop.onm.api.user.domain</li>
 * <li>설  명 : UserPasswordChangeRequestDto.java</li>
 * <li>작성일 : 2021. 2. 6.</li>
 * <li>작성자 : jeonyb4</li>
 * </ul>
 */
@Getter
@Setter
public class UserPasswordChangeRequestDto {
	private String userId;
	private String auditId;
	private String loginPassword;
	private String beforePassword;

}
