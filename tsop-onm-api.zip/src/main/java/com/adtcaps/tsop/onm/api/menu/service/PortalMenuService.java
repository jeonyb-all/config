package com.adtcaps.tsop.onm.api.menu.service;

import java.util.List;

import com.adtcaps.tsop.onm.api.domain.OomTenantServicePortalMenuDto;
import com.adtcaps.tsop.onm.api.helper.domain.BasePageDto;
import com.adtcaps.tsop.onm.api.menu.domain.TenantServicePortalMenuDetailResultDto;
import com.adtcaps.tsop.onm.api.menu.domain.TenantServicePortalMenuForComboResultDto;
import com.adtcaps.tsop.onm.api.menu.domain.TenantServicePortalMenuForShortGridResultDto;
import com.adtcaps.tsop.onm.api.menu.domain.TenantServicePortalMenuGridRequestDto;
import com.adtcaps.tsop.onm.api.menu.domain.TenantServicePortalMenuGridResultDto;

/**
 * 
 * <ul>
 * <li>업무 그룹명 : tsop-onm-api</li>
 * <li>서브 업무명 : com.adtcaps.tsop.onm.api.menu.service</li>
 * <li>설  명 : PortalMenuService.java</li>
 * <li>작성일 : 2021. 1. 11.</li>
 * <li>작성자 : jeonyb4</li>
 * </ul>
 */
public interface PortalMenuService {
	/**
	 * 
	 * listTenantServicePortalMenuForCombo
	 *
	 * @param reqOomTenantServicePortalMenuDto
	 * @return List<TenantServicePortalMenuForComboResultDto>
	 * @throws Exception 
	 */
	public List<TenantServicePortalMenuForComboResultDto> listTenantServicePortalMenuForCombo(OomTenantServicePortalMenuDto reqOomTenantServicePortalMenuDto) throws Exception;
	
	/**
	 * 
	 * listTenantServicePortalMenuForShortGrid
	 *
	 * @param reqBasePageDto
	 * @return List<TenantServicePortalMenuForShortGridResultDto>
	 * @throws Exception 
	 */
	public List<TenantServicePortalMenuForShortGridResultDto> listTenantServicePortalMenuForShortGrid(BasePageDto reqBasePageDto) throws Exception;
	
	/**
	 * 
	 * listPageTenantServicePortalMenu
	 *
	 * @param tenantServicePortalMenuGridRequestDto
	 * @return List<TenantServicePortalMenuGridResultDto>
	 * @throws Exception 
	 */
	public List<TenantServicePortalMenuGridResultDto> listPageTenantServicePortalMenu(TenantServicePortalMenuGridRequestDto tenantServicePortalMenuGridRequestDto) throws Exception;
	
	/**
	 * 
	 * createTenantServicePortalMenu
	 *
	 * @param reqOomTenantServicePortalMenuDto
	 * @return int
	 * @throws Exception 
	 */
	public int createTenantServicePortalMenu(OomTenantServicePortalMenuDto reqOomTenantServicePortalMenuDto) throws Exception;
	
	/**
	 * 
	 * readTenantServicePortalMenu
	 *
	 * @param reqOomTenantServicePortalMenuDto
	 * @return TenantServicePortalMenuDetailResultDto
	 * @throws Exception 
	 */
	public TenantServicePortalMenuDetailResultDto readTenantServicePortalMenu(OomTenantServicePortalMenuDto reqOomTenantServicePortalMenuDto) throws Exception;
	
	/**
	 * 
	 * updateTenantServicePortalMenu
	 *
	 * @param reqOomTenantServicePortalMenuDto
	 * @return int
	 * @throws Exception 
	 */
	public int updateTenantServicePortalMenu(OomTenantServicePortalMenuDto reqOomTenantServicePortalMenuDto) throws Exception;
	
	/**
	 * 
	 * deleteTenantServicePortalMenu
	 *
	 * @param reqOomTenantServicePortalMenuDto
	 * @return int
	 * @throws Exception 
	 */
	public int deleteTenantServicePortalMenu(OomTenantServicePortalMenuDto reqOomTenantServicePortalMenuDto) throws Exception;
	
	/**
	 * 
	 * readTenantServicePortalChildMenuCount
	 *
	 * @param reqOomTenantServicePortalMenuDto
	 * @return int
	 * @throws Exception 
	 */
	public int readTenantServicePortalChildMenuCount(OomTenantServicePortalMenuDto reqOomTenantServicePortalMenuDto) throws Exception;
	
	/**
	 * 
	 * readTenantServicePortalMenuSameMenuNameCount
	 *
	 * @param reqOomTenantServicePortalMenuDto
	 * @return int
	 * @throws Exception 
	 */
	public int readTenantServicePortalMenuSameMenuNameCount(OomTenantServicePortalMenuDto reqOomTenantServicePortalMenuDto) throws Exception;

}
