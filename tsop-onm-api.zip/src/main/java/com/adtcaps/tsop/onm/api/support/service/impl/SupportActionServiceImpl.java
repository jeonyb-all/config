package com.adtcaps.tsop.onm.api.support.service.impl;

import java.net.ConnectException;
import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.apache.http.conn.ConnectTimeoutException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.CollectionUtils;

import com.adtcaps.tsop.onm.api.config.TenantConfig;
import com.adtcaps.tsop.onm.api.domain.OomTechSupportActionDto;
import com.adtcaps.tsop.onm.api.domain.OomTechSupportRequestDto;
import com.adtcaps.tsop.onm.api.file.domain.BlobRequestDto;
import com.adtcaps.tsop.onm.api.file.service.FileService;
import com.adtcaps.tsop.onm.api.helper.constant.Const;
import com.adtcaps.tsop.onm.api.helper.domain.ResultDto;
import com.adtcaps.tsop.onm.api.helper.util.CommonDateUtil;
import com.adtcaps.tsop.onm.api.helper.util.CommonObjectUtil;
import com.adtcaps.tsop.onm.api.support.domain.TechSupportActionGridResultDto;
import com.adtcaps.tsop.onm.api.support.domain.TechSupportActionProcessingDto;
import com.adtcaps.tsop.onm.api.support.mapper.OomTechSupportActionMapper;
import com.adtcaps.tsop.onm.api.support.service.SupportActionService;
import com.adtcaps.tsop.onm.api.support.service.SupportService;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.gson.Gson;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.squareup.okhttp.MediaType;
import com.squareup.okhttp.OkHttpClient;
import com.squareup.okhttp.Request;
import com.squareup.okhttp.RequestBody;
import com.squareup.okhttp.Response;

/**
 * 
 * <ul>
 * <li>업무 그룹명 : tsop-onm-api</li>
 * <li>서브 업무명 : com.adtcaps.tsop.onm.api.support.service.impl</li>
 * <li>설  명 : TechSupportActionServiceImpl.java</li>
 * <li>작성일 : 2021. 1. 3.</li>
 * <li>작성자 : jeonyb4</li>
 * </ul>
 */
@Transactional
@Service
public class SupportActionServiceImpl implements SupportActionService {
	
	private final String ERR_MSG_REMOTE_EXECUTION_FAIL = "원격 실행에 실패하였습니다.";
	private final String ERR_MSG_REMOTE_CALL_CONNECTION_FAIL = "원격 접속이 실패하였습니다.";
	private final String ERR_MSG_REMOTE_CALL_TIMEOUT = "원격 실행 시 Timeout이 발생하였습니다.";
	
	@Autowired
	private OomTechSupportActionMapper oomTechSupportActionMapper;
	
	@Autowired
	private SupportService supportService;
	
	@Autowired
	private FileService fileService;
	
	@Autowired
	private TenantConfig tenantConfig;
	
	/**
	 * 
	 * listTechSupportAction
	 *
	 * @param reqOomTechSupportActionDto
	 * @return List<TechSupportActionGridResultDto>
	 * @throws Exception 
	 */
	@Override
	public List<TechSupportActionGridResultDto> listTechSupportAction(OomTechSupportActionDto reqOomTechSupportActionDto) throws Exception {
		
		List<TechSupportActionGridResultDto> techSupportActionGridResultDtoList = null;
		try {
			techSupportActionGridResultDtoList = oomTechSupportActionMapper.listTechSupportAction(reqOomTechSupportActionDto);
    		if (!CollectionUtils.isEmpty(techSupportActionGridResultDtoList)) {
    			for (int idx = 0; idx < techSupportActionGridResultDtoList.size(); idx++) {
    				
    				TechSupportActionGridResultDto techSupportActionGridResultDto = techSupportActionGridResultDtoList.get(idx);
    				
    				String techSupportActionDatetime = StringUtils.defaultString(techSupportActionGridResultDto.getTechSupportActionDatetime());
    				techSupportActionDatetime = CommonDateUtil.makeDatetimeFormat(techSupportActionDatetime);
    				techSupportActionGridResultDto.setTechSupportActionDatetime(techSupportActionDatetime);
    				
    				techSupportActionGridResultDtoList.set(idx, techSupportActionGridResultDto);
    			}
    		}
    		
		} catch (Exception e) {
			throw e;
		}
		return techSupportActionGridResultDtoList;
	}
	
	/**
	 * 
	 * createTechSupportAction
	 *
	 * @param reqTechSupportActionProcessingDto
	 * @return ResultDto
	 * @throws Exception 
	 */
	@Override
	public ResultDto createTechSupportAction(TechSupportActionProcessingDto reqTechSupportActionProcessingDto) throws Exception {
		
		ResultDto resultDto = null;
		
		try {
			OomTechSupportActionDto reqOomTechSupportActionDto = reqTechSupportActionProcessingDto.getTechSupportActionInfo();
			BlobRequestDto blobRequestDto = reqTechSupportActionProcessingDto.getAttachFile();
			if (blobRequestDto != null) {
				blobRequestDto.setContainerName(Const.Definition.BLOB_CONTAINER.FILE);
				blobRequestDto.setBlobBaseDir(Const.Definition.BLOB_BASEDIR.SUPPORT);
				int attachFileNum = fileService.createAttachFile(blobRequestDto);
				if (attachFileNum > 0) {
					reqOomTechSupportActionDto.setAttachFileNum(attachFileNum);
				}
			}
			
			// 기술지원요청 조치내역 등록...
			oomTechSupportActionMapper.createOomTechSupportAction(reqOomTechSupportActionDto);
			
			// 기술지원요청 상태값 수정...
			String techSupportStatusCd = StringUtils.defaultString(reqTechSupportActionProcessingDto.getTechSupportStatusCd());
			if (Const.Code.TECH_SUPPORT_STATUS_CD.APPROVAL.equals(techSupportStatusCd)) {
				reqTechSupportActionProcessingDto.setTechSupportStatusCd(Const.Code.TECH_SUPPORT_STATUS_CD.PROCESSING);
			}
			OomTechSupportRequestDto reqOomTechSupportRequestDto = new OomTechSupportRequestDto();
			reqOomTechSupportRequestDto.setTenantId(reqOomTechSupportActionDto.getTenantId());
			reqOomTechSupportRequestDto.setTechSupportReqId(reqOomTechSupportActionDto.getTechSupportReqId());
			reqOomTechSupportRequestDto.setTechSupportStatusCd(reqTechSupportActionProcessingDto.getTechSupportStatusCd());
			reqOomTechSupportRequestDto.setAuditId(reqOomTechSupportActionDto.getAuditId());
			supportService.updateTechSupportStatus(reqOomTechSupportRequestDto);
			
			// Remote Call 처리...
			String actionYn = StringUtils.defaultString(tenantConfig.getTenantSktServerInfo().getActionYn());
			if ("Y".equals(actionYn)) {
				String key = tenantConfig.getTenantSktServerInfo().getKey();
				String portalWasUrl = tenantConfig.getTenantSktServerInfo().getUrl();
				
				StringBuilder urlBuilder = new StringBuilder();
				urlBuilder.append(portalWasUrl);
				urlBuilder.append("/api/portal/callees/create-support-action");
				
				Gson gson = new Gson();
	    	    String requestJsonString = gson.toJson(reqTechSupportActionProcessingDto);
				
				OkHttpClient client = new OkHttpClient();
				Request request = new Request.Builder()
						.addHeader("Call-Key", key)
						.url(urlBuilder.toString())
	    	            .post(RequestBody.create(MediaType.parse(org.springframework.http.MediaType.APPLICATION_JSON.toString()), requestJsonString))
	    	            .build();
	    	    
	    	    Response response = null;
				try {
	    	    	response = client.newCall(request).execute();
	    	    } catch (ConnectException e) {
	    	    	resultDto = new ResultDto(Const.Common.RESULT_CODE.FAIL, ERR_MSG_REMOTE_CALL_CONNECTION_FAIL);
	    	    	return resultDto;
	    	    } catch (ConnectTimeoutException e) {
	    	    	resultDto = new ResultDto(Const.Common.RESULT_CODE.FAIL, ERR_MSG_REMOTE_CALL_TIMEOUT);
	    	    	return resultDto;
	    	    }
	    	    
	    	    String responseJsonString = StringUtils.defaultString(response.body().string());
				if ("".equals(responseJsonString)) {
					resultDto = new ResultDto(Const.Common.RESULT_CODE.FAIL, ERR_MSG_REMOTE_EXECUTION_FAIL);
				} else {
					JsonObject responseJsonObject = JsonParser.parseString(responseJsonString).getAsJsonObject();
					
					ObjectMapper objectMapper = new ObjectMapper();
					resultDto = objectMapper.readValue(responseJsonObject.toString(), ResultDto.class);
				}
			}
			
		} catch (Exception e) {
			throw e;
		}
		
		return resultDto;
	}
	
	/**
	 * 
	 * deleteTechSupportActionAttachFile
	 *
	 * @param reqOomTechSupportActionDto
	 * @return int
	 * @throws Exception 
	 */
	@Override
	public int deleteTechSupportActionAttachFile(OomTechSupportActionDto reqOomTechSupportActionDto) throws Exception {
		
		int affectRowCount = 0;
		
		try {
			int attachFileNum = reqOomTechSupportActionDto.getAttachFileNum();
			// 첨부파일 삭제
			int deleteRow = fileService.deleteAttachFile(Const.Definition.BLOB_CONTAINER.FILE, attachFileNum);
			affectRowCount = affectRowCount + deleteRow;
			// 기술지원요청 조치내역의 첨부파일번호 Null update
			reqOomTechSupportActionDto.setAttachFileNum(null);
			int updateRow = oomTechSupportActionMapper.updateTechSupportActionAttachFileNum(reqOomTechSupportActionDto);
			affectRowCount = affectRowCount + updateRow;
			
		} catch (Exception e) {
			throw e;
		}
		return affectRowCount;
	}
	
	/**
	 * 
	 * deleteTechSupportAction
	 *
	 * @param reqOomTechSupportActionDto
	 * @return int
	 * @throws Exception 
	 */
	@Override
	public int deleteTechSupportAction(OomTechSupportActionDto reqOomTechSupportActionDto) throws Exception {
		
		int affectRowCount = 0;
		
		try {
			int attachFileNum = CommonObjectUtil.defaultNumber(reqOomTechSupportActionDto.getAttachFileNum());
			if (attachFileNum > 0) {
				// 첨부파일 삭제
				int deleteRow = fileService.deleteAttachFile(Const.Definition.BLOB_CONTAINER.FILE, attachFileNum);
				affectRowCount = affectRowCount + deleteRow;
			}
			// 기술지원요청 조치내역 삭제...
			int deleteRow = oomTechSupportActionMapper.deleteOomTechSupportAction(reqOomTechSupportActionDto);
			affectRowCount = affectRowCount + deleteRow;
			
		} catch (Exception e) {
			throw e;
		}
		
		return affectRowCount;
	}

}
