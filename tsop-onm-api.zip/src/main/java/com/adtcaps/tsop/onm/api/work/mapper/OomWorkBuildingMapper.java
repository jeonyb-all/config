package com.adtcaps.tsop.onm.api.work.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;

import com.adtcaps.tsop.onm.api.domain.OomWorkBuildingDto;
import com.adtcaps.tsop.onm.api.work.domain.TenantWorkBuildingRequestDto;

/**
 * 
 * <ul>
 * <li>업무 그룹명 : tsop-onm-api</li>
 * <li>서브 업무명 : com.adtcaps.tsop.onm.api.work.mapper</li>
 * <li>설  명 : OomWorkBuildingMapper.java</li>
 * <li>작성일 : 2021. 1. 27.</li>
 * <li>작성자 : jeonyb4</li>
 * </ul>
 */
@Mapper
public interface OomWorkBuildingMapper {
	/**
	 * 
	 * insertOomWorkBuilding
	 *
	 * @param reqOomWorkBuildingDto
	 * @return int
	 */
	public int insertOomWorkBuilding(OomWorkBuildingDto reqOomWorkBuildingDto);
	
	/**
	 * 
	 * deleteOomWorkBuilding
	 *
	 * @param reqOomWorkBuildingDto
	 * @return int
	 */
	public int deleteOomWorkBuilding(OomWorkBuildingDto reqOomWorkBuildingDto);
	
	/**
	 * 
	 * mergeOomWorkBuilding
	 *
	 * @param reqOomWorkBuildingDto
	 * @return int
	 */
	public int mergeOomWorkBuilding(OomWorkBuildingDto reqOomWorkBuildingDto);
	
	/**
	 * 
	 * updateOomWorkBuildingUseYn
	 *
	 * @param reqOomWorkBuildingDto
	 * @return int
	 */
	public int updateOomWorkBuildingUseYn(OomWorkBuildingDto reqOomWorkBuildingDto);
	
	/**
	 * 
	 * listOomWorkBuilding
	 *
	 * @param reqOomWorkBuildingDto
	 * @return List<OomWorkBuildingDto>
	 */
	public List<OomWorkBuildingDto> listOomWorkBuilding(OomWorkBuildingDto reqOomWorkBuildingDto);
	
	/**
	 * 
	 * createBuildingFromWork
	 *
	 * @param tenantWorkBuildingRequestDto
	 * @return int
	 */
	public int createBuildingFromWork(TenantWorkBuildingRequestDto tenantWorkBuildingRequestDto);
	
	/**
	 * 
	 * updateBuildingFromWork
	 *
	 * @param tenantWorkBuildingRequestDto
	 * @return int
	 */
	public int updateBuildingFromWork(TenantWorkBuildingRequestDto tenantWorkBuildingRequestDto);
	
	/**
	 * 
	 * updateBuildingUseYnFromWork
	 *
	 * @param tenantWorkBuildingRequestDto
	 * @return int
	 */
	public int updateBuildingUseYnFromWork(TenantWorkBuildingRequestDto tenantWorkBuildingRequestDto);
	

}
