package com.adtcaps.tsop.onm.api.authentication.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.naming.LimitExceededException;

import com.adtcaps.tsop.onm.api.alimTalk.domain.AlimTalkDetailDto;
import com.adtcaps.tsop.onm.api.alimTalk.domain.AlimTalkRequestDto;
import com.adtcaps.tsop.onm.api.alimTalk.mapper.OomKakaoAlimTalkMapper;
import com.adtcaps.tsop.onm.api.alimTalk.service.AlimTalkService;
import com.adtcaps.tsop.onm.api.authentication.domain.JwtAuthSmsDto;
import com.adtcaps.tsop.onm.api.authentication.mapper.JwtAuthenticationMapper;
import com.adtcaps.tsop.onm.api.domain.OomKakaoAlimTalkDto;
import com.adtcaps.tsop.onm.api.helper.constant.Const;

import org.apache.commons.lang3.StringUtils;
import org.apache.poi.poifs.crypt.dsig.ExpiredCertificateSecurityException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.stereotype.Service;

@Service
public class JwtAuthenticatioSmsServiceImpl implements JwtAuthenticatioSmsService{
    @Value("${jwt.sms.limituserid}")
    private Integer limitUserId;

    @Value("${jwt.sms.limitip}")
    private Integer limitIp;
    
    @Autowired
    private JwtAuthenticationMapper jwtAuthenticationMapper;
    
    @Autowired
    private OomKakaoAlimTalkMapper oomKakaoAlimTalkMapper;
    
    @Autowired
    private AlimTalkService alimTalkService;
    
    @Override
    public void sendAuthenticationSms(JwtAuthSmsDto request, boolean sendFlag) throws Exception {
         
        //인증번호 요청 시도 수 제한 체크
        checkAuthSendHist(request);
        //인증 번호 임시 저장
        jwtAuthenticationMapper.createAuthSms(request);   
           
   
        Map<String, Object> smsRequest = new HashMap<String, Object>(); 
        smsRequest.put("recv_no",request.getPhoneNm() );
        smsRequest.put("msg","TSO 인증 번호 : " + request.getAuthSms());
        
        //인증 번호 발송
        if(sendFlag) {
        	// 알림톡 발송 처리...
     		String contactPhoneNum = StringUtils.defaultString(request.getPhoneNm());
     		OomKakaoAlimTalkDto reqOomKakaoAlimTalkDto = new OomKakaoAlimTalkDto();
     		reqOomKakaoAlimTalkDto.setTmpltCode(Const.Definition.MSG_TEMPLATE_CODE.TSOP_003);
     		reqOomKakaoAlimTalkDto.setSmsCreateCd(Const.Code.SMS_CREATE_CD.AUTH);
     		OomKakaoAlimTalkDto oomKakaoAlimTalkDto = oomKakaoAlimTalkMapper.readKakaoAlimTalk(reqOomKakaoAlimTalkDto);
     		if (oomKakaoAlimTalkDto != null) {
     			List<AlimTalkDetailDto> alimTalkDetailDtoList = new ArrayList<AlimTalkDetailDto>();
     			String rcverId = request.getUserId();
     			String rcvPhoneNum = contactPhoneNum;
     			AlimTalkDetailDto alimTalkDetailDto = new AlimTalkDetailDto();
     			alimTalkDetailDto.setRcverId(rcverId);
     			alimTalkDetailDto.setRcvPhoneNum(rcvPhoneNum);
     			alimTalkDetailDtoList.add(alimTalkDetailDto);
     			
     			String message = oomKakaoAlimTalkDto.getMessage();
     			message = message.replaceAll("#\\{\"123456\"\\}", request.getAuthSms());
     			
     			// 카카오 알림톡 발송 처리..
     			AlimTalkRequestDto alimTalkRequestDto = new AlimTalkRequestDto();
     			alimTalkRequestDto.setTmpltCode(Const.Definition.MSG_TEMPLATE_CODE.TSOP_003);
     			alimTalkRequestDto.setRecipient(contactPhoneNum);
     			alimTalkRequestDto.setMessage(message);
     			alimTalkRequestDto.setSmsCreateCd(Const.Code.SMS_CREATE_CD.AUTH);
     			alimTalkRequestDto.setAuditId(request.getUserId());
     			alimTalkRequestDto.setDetailList(alimTalkDetailDtoList);
     			String alarmNoticeResultCd = alimTalkService.sendOnmAlimTalk(alimTalkRequestDto);
     			if (!"1".equals(alarmNoticeResultCd)) {
      				throw new Exception("운용자에게 문의해 주세요.");
      			}
     		}
        }     
    }


    @Override
    public String readAuthenticationSmsToken(JwtAuthSmsDto request) throws Exception {
        JwtAuthSmsDto result = jwtAuthenticationMapper.readAuthSmsToken(request);
        if(result == null) throw new BadCredentialsException("인증번호를 다시 요청 해 주세요.");
        if(result.getPasswordYn().equalsIgnoreCase("0")) throw new BadCredentialsException("로그인 정보를 확인 바랍니다.");
        if(!result.getAuthSms().equalsIgnoreCase(request.getAuthSms()))throw new BadCredentialsException("인증번호를 확인 바랍니다.");
        if(result.getExpirYn().equalsIgnoreCase("N")) throw new ExpiredCertificateSecurityException();

        String token = result.getToken();
        
        jwtAuthenticationMapper.createAuthHist(result);
        jwtAuthenticationMapper.updateAuthHist(result);
        jwtAuthenticationMapper.updateAuthUseYn(result);
        return token;
    }

    public void checkAuthSendHist(JwtAuthSmsDto request) throws Exception{
        int checkUserid = jwtAuthenticationMapper.checkAuthSmsCntByUserid(request);
        int checkIp = jwtAuthenticationMapper.checkAuthSmsCntByIp(request);

        if(checkUserid > limitUserId || checkIp > limitIp) throw new LimitExceededException("잠시 후 다시 인증 요청하세요.");

    }

    @Override
    public void sendInitSms(JwtAuthSmsDto request, boolean sendFlag) throws Exception {
    	//인증번호 요청 시도 수 제한 체크
        checkAuthSendHist(request);
        //인증 번호 임시 저장
        jwtAuthenticationMapper.createInitSms(request);
        
        // 알림톡 발송 처리...
  		String contactPhoneNum = StringUtils.defaultString(request.getPhoneNm());
  		OomKakaoAlimTalkDto reqOomKakaoAlimTalkDto = new OomKakaoAlimTalkDto();
  		reqOomKakaoAlimTalkDto.setTmpltCode(Const.Definition.MSG_TEMPLATE_CODE.TSOP_003);
  		reqOomKakaoAlimTalkDto.setSmsCreateCd(Const.Code.SMS_CREATE_CD.AUTH);
  		OomKakaoAlimTalkDto oomKakaoAlimTalkDto = oomKakaoAlimTalkMapper.readKakaoAlimTalk(reqOomKakaoAlimTalkDto);
  		if (oomKakaoAlimTalkDto != null) {
  			List<AlimTalkDetailDto> alimTalkDetailDtoList = new ArrayList<AlimTalkDetailDto>();
  			String rcverId = request.getUserId();
  			String rcvPhoneNum = contactPhoneNum;
  			AlimTalkDetailDto alimTalkDetailDto = new AlimTalkDetailDto();
  			alimTalkDetailDto.setRcverId(rcverId);
  			alimTalkDetailDto.setRcvPhoneNum(rcvPhoneNum);
  			alimTalkDetailDtoList.add(alimTalkDetailDto);
  			
  			String message = oomKakaoAlimTalkDto.getMessage();
  			message = message.replaceAll("#\\{\"123456\"\\}", request.getAuthSms());
  			
  			// 카카오 알림톡 발송 처리..
  			AlimTalkRequestDto alimTalkRequestDto = new AlimTalkRequestDto();
  			alimTalkRequestDto.setTmpltCode(Const.Definition.MSG_TEMPLATE_CODE.TSOP_003);
  			alimTalkRequestDto.setRecipient(contactPhoneNum);
  			alimTalkRequestDto.setMessage(message);
  			alimTalkRequestDto.setSmsCreateCd(Const.Code.SMS_CREATE_CD.AUTH);
  			alimTalkRequestDto.setAuditId(request.getUserId());
  			alimTalkRequestDto.setDetailList(alimTalkDetailDtoList);
  			String alarmNoticeResultCd = alimTalkService.sendOnmAlimTalk(alimTalkRequestDto);
  			if (!"1".equals(alarmNoticeResultCd)) {
  				throw new Exception("운용자에게 문의해 주세요.");
  			}
  		}
    }


    @Override
    public String readInitSmsToken(JwtAuthSmsDto request) throws Exception {
        JwtAuthSmsDto result = jwtAuthenticationMapper.readInitSmsToken(request);
        if(result == null) throw new BadCredentialsException("인증번호를 다시 요청 해 주세요.");
        if(!result.getAuthSms().equalsIgnoreCase(request.getAuthSms()))throw new BadCredentialsException("인증번호를 확인 바랍니다.");
        if(result.getExpirYn().equalsIgnoreCase("N")) throw new ExpiredCertificateSecurityException();

        String token = result.getToken();
                
        jwtAuthenticationMapper.updateAuthUseYn(result);
        return token;
    }

  
    
}
