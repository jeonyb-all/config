package com.adtcaps.tsop.onm.api.domain;

import lombok.Getter;
import lombok.Setter;

/**
 * 
 * <ul>
 * <li>업무 그룹명 : tsop-onm-api</li>
 * <li>서브 업무명 : com.adtcaps.tsop.onm.api.domain</li>
 * <li>설  명 : OomDbTableColumnDto.java</li>
 * <li>작성일 : 2021. 1. 7.</li>
 * <li>작성자 : jeonyb4</li>
 * </ul>
 */
@Getter
@Setter
public class OomDbTableColumnDto {
	private String tableId;
	private String columnId;
	private String auditDatetime;
	private String auditId;
	private Integer columnSeq;
	private String columnName;
	private String dataTypeName;
	private Double dataLength;
	private String mandatoryYn;
	private String defaultVal;
	private String pkYn;

}
