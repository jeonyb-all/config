package com.adtcaps.tsop.onm.api.fault.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;

import com.adtcaps.tsop.onm.api.domain.OomFaultDto;
import com.adtcaps.tsop.onm.api.fault.domain.FaultDetailResultDto;
import com.adtcaps.tsop.onm.api.fault.domain.FaultGridRequestDto;
import com.adtcaps.tsop.onm.api.fault.domain.FaultGridResultDto;

/**
 * 
 * <ul>
 * <li>업무 그룹명 : tsop-onm-api</li>
 * <li>서브 업무명 : com.adtcaps.tsop.onm.api.fault.mapper</li>
 * <li>설  명 : OomFaultMapper.java</li>
 * <li>작성일 : 2021. 1. 17.</li>
 * <li>작성자 : jeonyb4</li>
 * </ul>
 */
@Mapper
public interface OomFaultMapper {
	/**
	 * 
	 * listPageFault
	 *
	 * @param faultGridRequestDto
	 * @return List<FaultGridResultDto>
	 */
	public List<FaultGridResultDto> listPageFault(FaultGridRequestDto faultGridRequestDto);
	
	/**
	 * 
	 * createOomFault
	 *
	 * @param reqOomFaultDto
	 * @return int
	 */
	public int createOomFault(OomFaultDto reqOomFaultDto);
	
	/**
	 * 
	 * readOomFault
	 *
	 * @param reqOomFaultDto
	 * @return FaultDetailResultDto
	 */
	public FaultDetailResultDto readOomFault(OomFaultDto reqOomFaultDto);
	
	/**
	 * 
	 * readOomFaultAttachFile
	 *
	 * @param reqOomFaultDto
	 * @return FaultDetailResultDto
	 */
	public FaultDetailResultDto readOomFaultAttachFile(OomFaultDto reqOomFaultDto);
	
	/**
	 * 
	 * updateFaultAttachFileNum
	 *
	 * @param reqOomFaultDto
	 * @return int
	 */
	public int updateFaultAttachFileNum(OomFaultDto reqOomFaultDto);
	
	/**
	 * 
	 * updateOomFault
	 *
	 * @param reqOomFaultDto
	 * @return int
	 */
	public int updateOomFault(OomFaultDto reqOomFaultDto);
	
	/**
	 * 
	 * readOomFaultDuplicationCheck
	 *
	 * @param reqOomFaultDto
	 * @return FaultDetailResultDto
	 */
	public FaultDetailResultDto readOomFaultDuplicationCheck(OomFaultDto reqOomFaultDto);
	
	/**
	 * 
	 * readFalutCountForAlarm
	 *
	 * @param reqOomFaultDto
	 * @return int
	 */
	public int readFalutCountForAlarm(OomFaultDto reqOomFaultDto);
	
}
