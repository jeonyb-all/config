package com.adtcaps.tsop.onm.api.work.service.impl;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.adtcaps.tsop.onm.api.building.mapper.OomBuildingServiceConnectionIpMapper;
import com.adtcaps.tsop.onm.api.domain.OomBuildingServiceConnectionIpDto;
import com.adtcaps.tsop.onm.api.domain.OomWorkBuildingServiceConenctionDto;
import com.adtcaps.tsop.onm.api.domain.OomWorkBuildingServiceConnectionIpDto;
import com.adtcaps.tsop.onm.api.domain.OomWorkDto;
import com.adtcaps.tsop.onm.api.domain.OomWorkTenantDto;
import com.adtcaps.tsop.onm.api.domain.OomWorkTenantResourceDetailDto;
import com.adtcaps.tsop.onm.api.domain.OomWorkTenantResourceDto;
import com.adtcaps.tsop.onm.api.helper.constant.Const;
import com.adtcaps.tsop.onm.api.work.domain.TenantWorkBuildingRequestDto;
import com.adtcaps.tsop.onm.api.work.mapper.OomWorkBuildingMapper;
import com.adtcaps.tsop.onm.api.work.mapper.OomWorkBuildingServiceConenctionMapper;
import com.adtcaps.tsop.onm.api.work.mapper.OomWorkBuildingServiceConnectionIpMapper;
import com.adtcaps.tsop.onm.api.work.mapper.OomWorkMapper;
import com.adtcaps.tsop.onm.api.work.mapper.OomWorkTenantMapper;
import com.adtcaps.tsop.onm.api.work.mapper.OomWorkTenantResourceDetailMapper;
import com.adtcaps.tsop.onm.api.work.mapper.OomWorkTenantResourceMapper;
import com.adtcaps.tsop.onm.api.work.service.WorkFinishService;

/**
 * 
 * <ul>
 * <li>업무 그룹명 : tsop-onm-api</li>
 * <li>서브 업무명 : com.adtcaps.tsop.onm.api.work.service.impl</li>
 * <li>설  명 : WorkFinishServiceImpl.java</li>
 * <li>작성일 : 2021. 2. 18.</li>
 * <li>작성자 : jeonyb4</li>
 * </ul>
 */
@Service
public class WorkFinishServiceImpl implements WorkFinishService {
	
	@Autowired
	private OomWorkMapper oomWorkMapper;
	
	@Autowired
	private OomWorkTenantMapper oomWorkTenantMapper;
	
	@Autowired
	private OomWorkBuildingMapper oomWorkBuildingMapper;
	
	@Autowired
	private OomWorkBuildingServiceConenctionMapper oomWorkBuildingServiceConenctionMapper;
	
	@Autowired
	private OomWorkBuildingServiceConnectionIpMapper oomWorkBuildingServiceConnectionIpMapper;
	
	@Autowired
	private OomWorkTenantResourceMapper oomWorkTenantResourceMapper;
	
	@Autowired
	private OomWorkTenantResourceDetailMapper oomWorkTenantResourceDetailMapper;
	
	@Autowired
	private OomBuildingServiceConnectionIpMapper oomBuildingServiceConnectionIpMapper;
	
	/**
	 * 
	 * copyWork
	 *
	 * @param reqOomWorkDto
	 * @return int
	 * @throws Exception 
	 */
	@Override
	public int copyWork(OomWorkDto reqOomWorkDto) throws Exception {
		
		int affectRowCount = 0;
		
		try {
			OomWorkDto rsltOomWorkDto = oomWorkMapper.readOomWork(reqOomWorkDto);
			if (rsltOomWorkDto != null) {
				int onmWorkId = rsltOomWorkDto.getOnmWorkId();
				String tenantId = StringUtils.defaultString(rsltOomWorkDto.getTenantId());
				String bldId = StringUtils.defaultString(rsltOomWorkDto.getBldId());
				String serviceClCd = StringUtils.defaultString(rsltOomWorkDto.getServiceClCd());
				String onmWorkTypeCd = StringUtils.defaultString(rsltOomWorkDto.getOnmWorkTypeCd());
				
				if (Const.Code.WORK_TYPE_CD.RT.equals(onmWorkTypeCd)) {
					// OOM_TENANT insert
					OomWorkTenantDto reqOomWorkTenantDto = new OomWorkTenantDto();
					reqOomWorkTenantDto.setOnmWorkId(onmWorkId);
					int insertRow = oomWorkTenantMapper.createTenantFromWork(reqOomWorkTenantDto);
					affectRowCount = affectRowCount + insertRow;
					
					// OOM_TENANT_RESOURCE insert
					OomWorkTenantResourceDto reqOomWorkTenantResourceDto = new OomWorkTenantResourceDto();
					reqOomWorkTenantResourceDto.setOnmWorkId(onmWorkId);
					insertRow = oomWorkTenantResourceMapper.createTenantResourceFromWork(reqOomWorkTenantResourceDto);
					affectRowCount = affectRowCount + insertRow;
					
					// OOM_TENANT_RESOURCE_DETAIL insert
					OomWorkTenantResourceDetailDto reqOomWorkTenantResourceDetailDto = new OomWorkTenantResourceDetailDto();
					reqOomWorkTenantResourceDetailDto.setOnmWorkId(onmWorkId);
					insertRow = oomWorkTenantResourceDetailMapper.createTenantResourceDetailFromWork(reqOomWorkTenantResourceDetailDto);
					affectRowCount = affectRowCount + insertRow;
					
					// OOM_BUILDING insert
					TenantWorkBuildingRequestDto tenantWorkBuildingRequestDto = new TenantWorkBuildingRequestDto();
	    			tenantWorkBuildingRequestDto.setOnmWorkId(onmWorkId);
	    			tenantWorkBuildingRequestDto.setTenantId(tenantId);
	    			insertRow = oomWorkBuildingMapper.createBuildingFromWork(tenantWorkBuildingRequestDto);
	    			affectRowCount = affectRowCount + insertRow;
					
					// OOM_BUILDING_SERVICE insert
	    			OomWorkBuildingServiceConenctionDto reqOomWorkBuildingServiceConenctionDto = new OomWorkBuildingServiceConenctionDto();
	    			reqOomWorkBuildingServiceConenctionDto.setOnmWorkId(onmWorkId);
	    			insertRow = oomWorkBuildingServiceConenctionMapper.createServiceFromWork(reqOomWorkBuildingServiceConenctionDto);
	    			affectRowCount = affectRowCount + insertRow;
					
					// OOM_BUILDING_SERVICE_CONNECTION insert
	    			insertRow = oomWorkBuildingServiceConenctionMapper.createServiceConnectionFromWork(reqOomWorkBuildingServiceConenctionDto);
	    			affectRowCount = affectRowCount + insertRow;
					
					// OOM_BUILDING_SERVICE_CONNECTION_IP insert
	    			OomWorkBuildingServiceConnectionIpDto reqOomWorkBuildingServiceConnectionIpDto = new OomWorkBuildingServiceConnectionIpDto();
	    			reqOomWorkBuildingServiceConnectionIpDto.setOnmWorkId(onmWorkId);
	    			insertRow = oomWorkBuildingServiceConnectionIpMapper.createServiceConnectionIpFromWork(reqOomWorkBuildingServiceConnectionIpDto);
	    			affectRowCount = affectRowCount + insertRow;
					
	    		} else if (Const.Code.WORK_TYPE_CD.RB.equals(onmWorkTypeCd)) {
	    			// OOM_BUILDING insert
	    			TenantWorkBuildingRequestDto tenantWorkBuildingRequestDto = new TenantWorkBuildingRequestDto();
	    			tenantWorkBuildingRequestDto.setOnmWorkId(onmWorkId);
	    			tenantWorkBuildingRequestDto.setTenantId(tenantId);
	    			int insertRow = oomWorkBuildingMapper.createBuildingFromWork(tenantWorkBuildingRequestDto);
	    			affectRowCount = affectRowCount + insertRow;
	    			
					// OOM_BUILDING_SERVICE insert
	    			OomWorkBuildingServiceConenctionDto reqOomWorkBuildingServiceConenctionDto = new OomWorkBuildingServiceConenctionDto();
	    			reqOomWorkBuildingServiceConenctionDto.setOnmWorkId(onmWorkId);
	    			insertRow = oomWorkBuildingServiceConenctionMapper.createServiceFromWork(reqOomWorkBuildingServiceConenctionDto);
	    			affectRowCount = affectRowCount + insertRow;
					
					// OOM_BUILDING_SERVICE_CONNECTION insert
	    			insertRow = oomWorkBuildingServiceConenctionMapper.createServiceConnectionFromWork(reqOomWorkBuildingServiceConenctionDto);
	    			affectRowCount = affectRowCount + insertRow;
					
					// OOM_BUILDING_SERVICE_CONNECTION_IP insert
	    			OomWorkBuildingServiceConnectionIpDto reqOomWorkBuildingServiceConnectionIpDto = new OomWorkBuildingServiceConnectionIpDto();
	    			reqOomWorkBuildingServiceConnectionIpDto.setOnmWorkId(onmWorkId);
	    			insertRow = oomWorkBuildingServiceConnectionIpMapper.createServiceConnectionIpFromWork(reqOomWorkBuildingServiceConnectionIpDto);
	    			affectRowCount = affectRowCount + insertRow;
	    			
	    		} else if (Const.Code.WORK_TYPE_CD.RS.equals(onmWorkTypeCd)) {
	    			// OOM_BUILDING_SERVICE insert
	    			OomWorkBuildingServiceConenctionDto reqOomWorkBuildingServiceConenctionDto = new OomWorkBuildingServiceConenctionDto();
	    			reqOomWorkBuildingServiceConenctionDto.setOnmWorkId(onmWorkId);
	    			int insertRow = oomWorkBuildingServiceConenctionMapper.createServiceFromWork(reqOomWorkBuildingServiceConenctionDto);
	    			affectRowCount = affectRowCount + insertRow;
					
					// OOM_BUILDING_SERVICE_CONNECTION insert
	    			insertRow = oomWorkBuildingServiceConenctionMapper.createServiceConnectionFromWork(reqOomWorkBuildingServiceConenctionDto);
	    			affectRowCount = affectRowCount + insertRow;
					
					// OOM_BUILDING_SERVICE_CONNECTION_IP insert
	    			OomWorkBuildingServiceConnectionIpDto reqOomWorkBuildingServiceConnectionIpDto = new OomWorkBuildingServiceConnectionIpDto();
	    			reqOomWorkBuildingServiceConnectionIpDto.setOnmWorkId(onmWorkId);
	    			insertRow = oomWorkBuildingServiceConnectionIpMapper.createServiceConnectionIpFromWork(reqOomWorkBuildingServiceConnectionIpDto);
	    			affectRowCount = affectRowCount + insertRow;
	    			
	    		} else if (Const.Code.WORK_TYPE_CD.CB.equals(onmWorkTypeCd)) {
	    			// OOM_BUILDING update
	    			TenantWorkBuildingRequestDto tenantWorkBuildingRequestDto = new TenantWorkBuildingRequestDto();
	    			tenantWorkBuildingRequestDto.setOnmWorkId(onmWorkId);
	    			tenantWorkBuildingRequestDto.setTenantId(tenantId);
	    			int updateRow = oomWorkBuildingMapper.updateBuildingFromWork(tenantWorkBuildingRequestDto);
	    			affectRowCount = affectRowCount + updateRow;
	    			
	    		} else if (Const.Code.WORK_TYPE_CD.CI.equals(onmWorkTypeCd)) {
	    			// OOM_BUILDING_SERVICE_CONNECTION update
	    			OomWorkBuildingServiceConenctionDto reqOomWorkBuildingServiceConenctionDto = new OomWorkBuildingServiceConenctionDto();
	    			reqOomWorkBuildingServiceConenctionDto.setOnmWorkId(onmWorkId);
	    			int updateRow = oomWorkBuildingServiceConenctionMapper.updateServiceConnectionFromWork(reqOomWorkBuildingServiceConenctionDto);
	    			affectRowCount = affectRowCount + updateRow;
					
					// OOM_BUILDING_SERVICE_CONNECTION_IP delete
	    			OomBuildingServiceConnectionIpDto reqOomBuildingServiceConnectionIpDto = new OomBuildingServiceConnectionIpDto();
	    			reqOomBuildingServiceConnectionIpDto.setBldId(bldId);
	    			reqOomBuildingServiceConnectionIpDto.setServiceClCd(serviceClCd);
	    			oomBuildingServiceConnectionIpMapper.deleteOomBuildingServiceConnectionIp(reqOomBuildingServiceConnectionIpDto);
	    			// insert
	    			OomWorkBuildingServiceConnectionIpDto reqOomWorkBuildingServiceConnectionIpDto = new OomWorkBuildingServiceConnectionIpDto();
	    			reqOomWorkBuildingServiceConnectionIpDto.setOnmWorkId(onmWorkId);
	    			int insertRow = oomWorkBuildingServiceConnectionIpMapper.createServiceConnectionIpFromWork(reqOomWorkBuildingServiceConnectionIpDto);
	    			affectRowCount = affectRowCount + insertRow;
	    			
	    		} else if (Const.Code.WORK_TYPE_CD.DS.equals(onmWorkTypeCd)) {
	    			// OOM_BUILDING_SERVICE use_yn update
	    			OomWorkBuildingServiceConenctionDto reqOomWorkBuildingServiceConenctionDto = new OomWorkBuildingServiceConenctionDto();
	    			reqOomWorkBuildingServiceConenctionDto.setOnmWorkId(onmWorkId);
	    			int updateRow = oomWorkBuildingServiceConenctionMapper.updateServiceUseYnFromWork(reqOomWorkBuildingServiceConenctionDto);
	    			affectRowCount = affectRowCount + updateRow;
	    			
				} else if (Const.Code.WORK_TYPE_CD.DB.equals(onmWorkTypeCd)) {
					// OOM_BUILDING use_yn update
					TenantWorkBuildingRequestDto tenantWorkBuildingRequestDto = new TenantWorkBuildingRequestDto();
	    			tenantWorkBuildingRequestDto.setOnmWorkId(onmWorkId);
	    			int updateRow = oomWorkBuildingMapper.updateBuildingUseYnFromWork(tenantWorkBuildingRequestDto);
	    			affectRowCount = affectRowCount + updateRow;
					
					// OOM_BUILDING_SERVICE use_yn update
	    			OomWorkBuildingServiceConenctionDto reqOomWorkBuildingServiceConenctionDto = new OomWorkBuildingServiceConenctionDto();
	    			reqOomWorkBuildingServiceConenctionDto.setOnmWorkId(onmWorkId);
	    			updateRow = oomWorkBuildingServiceConenctionMapper.updateServiceUseYnFromWork(reqOomWorkBuildingServiceConenctionDto);
	    			affectRowCount = affectRowCount + updateRow;
					
				} else if (Const.Code.WORK_TYPE_CD.DT.equals(onmWorkTypeCd)) {
					// OOM_TENANT use_yn update
					OomWorkTenantDto reqOomWorkTenantDto = new OomWorkTenantDto();
					reqOomWorkTenantDto.setOnmWorkId(onmWorkId);
					int updateRow = oomWorkTenantMapper.updateTenantUseYnFromWork(reqOomWorkTenantDto);
					affectRowCount = affectRowCount + updateRow;
					
					// OOM_USER 해당 테넌트 소속 사용자 use_yn update
					updateRow = oomWorkTenantMapper.updateTenantUserUseYnFromWork(reqOomWorkTenantDto);
					affectRowCount = affectRowCount + updateRow;
					
					// OOM_TENANT_RESOURCE use_yn update
					OomWorkTenantResourceDto reqOomWorkTenantResourceDto = new OomWorkTenantResourceDto();
					reqOomWorkTenantResourceDto.setOnmWorkId(onmWorkId);
					updateRow = oomWorkTenantResourceMapper.updateTenantResourceFromWork(reqOomWorkTenantResourceDto);
					affectRowCount = affectRowCount + updateRow;
					
					// OOM_BUILDING use_yn update
					TenantWorkBuildingRequestDto tenantWorkBuildingRequestDto = new TenantWorkBuildingRequestDto();
	    			tenantWorkBuildingRequestDto.setOnmWorkId(onmWorkId);
	    			updateRow = oomWorkBuildingMapper.updateBuildingUseYnFromWork(tenantWorkBuildingRequestDto);
	    			affectRowCount = affectRowCount + updateRow;
					
					// OOM_BUILDING_SERVICE use_yn update
	    			OomWorkBuildingServiceConenctionDto reqOomWorkBuildingServiceConenctionDto = new OomWorkBuildingServiceConenctionDto();
	    			reqOomWorkBuildingServiceConenctionDto.setOnmWorkId(onmWorkId);
	    			updateRow = oomWorkBuildingServiceConenctionMapper.updateServiceUseYnFromWork(reqOomWorkBuildingServiceConenctionDto);
	    			affectRowCount = affectRowCount + updateRow;
				}
			}
			
		} catch (Exception e) {
			throw e;
		}
		
		return affectRowCount;
		
	}

}
