package com.adtcaps.tsop.onm.api.address.domain;

import com.adtcaps.tsop.onm.api.helper.domain.BasePageDto;

import lombok.Getter;
import lombok.Setter;

/**
 * 
 * <ul>
 * <li>업무 그룹명 : tsop-onm-api</li>
 * <li>서브 업무명 : com.adtcaps.tsop.onm.api.address.domain</li>
 * <li>설  명 : StreetnameAddressGridResultDto.java</li>
 * <li>작성일 : 2021. 2. 2.</li>
 * <li>작성자 : jeonyb4</li>
 * </ul>
 */
@Getter
@Setter
public class StreetnameAddressGridResultDto extends BasePageDto {
	private String streetCtPvcName;
	private String streetCtGunGuName;
	private String streetUpmyundongName;
	private String streetnameAddr;
	private Integer bldMlotnum;
	private String bldName;
	private String zipcode;
	private String ldongCd;
	private Double xCodnVal;
	private Double yCodnVal;
	private Double weatherForecastXCodnVal;
	private Double weatherForecastYCodnVal;
	private Double latitudeVal;
	private Double longitudeVal;
	private String lotCtPvcName;
	private String lotCtGunGuName;
	private String lotUpmyundongName;
	private String riName;

}
