package com.adtcaps.tsop.onm.api.work.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;

import com.adtcaps.tsop.onm.api.domain.OomWorkStatusDto;
import com.adtcaps.tsop.onm.api.work.domain.CurrentWorkDetailResultDto;
import com.adtcaps.tsop.onm.api.work.domain.WorkStatusDetailResultDto;
import com.adtcaps.tsop.onm.api.work.domain.WorkStatusMenuResultDto;

/**
 * 
 * <ul>
 * <li>업무 그룹명 : tsop-onm-api</li>
 * <li>서브 업무명 : com.adtcaps.tsop.onm.api.work.mapper</li>
 * <li>설  명 : OomWorkStatusMapper.java</li>
 * <li>작성일 : 2021. 1. 29.</li>
 * <li>작성자 : jeonyb4</li>
 * </ul>
 */
@Mapper
public interface OomWorkStatusMapper {
	/**
	 * 
	 * mergeOomWorkStatus
	 *
	 * @param reqOomWorkStatusDto
	 * @return int
	 */
	public int mergeOomWorkStatus(OomWorkStatusDto reqOomWorkStatusDto);
	
	/**
	 * 
	 * createOomWorkStatus
	 *
	 * @param reqOomWorkStatusDto
	 * @return int
	 */
	public int createOomWorkStatus(OomWorkStatusDto reqOomWorkStatusDto);
	
	/**
	 * 
	 * updateOomWorkStatusFinishCode
	 *
	 * @param reqOomWorkStatusDto
	 * @return int
	 */
	public int updateOomWorkStatusFinishCode(OomWorkStatusDto reqOomWorkStatusDto);
	
	/**
	 * 
	 * listWorkStatusMenu
	 *
	 * @param reqOomWorkStatusDto
	 * @return List<WorkStatusMenuResultDto>
	 */
	public List<WorkStatusMenuResultDto> listWorkStatusMenu(OomWorkStatusDto reqOomWorkStatusDto);
	
	/**
	 * 
	 * readCurrentWorkStatus
	 *
	 * @param reqOomWorkStatusDto
	 * @return CurrentWorkDetailResultDto
	 */
	public CurrentWorkDetailResultDto readCurrentWorkStatus(OomWorkStatusDto reqOomWorkStatusDto);
	
	/**
	 * 
	 * listOomWorkStatus
	 *
	 * @param reqOomWorkStatusDto
	 * @return List<WorkStatusDetailResultDto>
	 */
	public List<WorkStatusDetailResultDto> listOomWorkStatus(OomWorkStatusDto reqOomWorkStatusDto);
	
	/**
	 * 
	 * readOomWorkStatusAttachFile
	 *
	 * @param reqOomWorkStatusDto
	 * @return WorkStatusDetailResultDto
	 */
	public WorkStatusDetailResultDto readOomWorkStatusAttachFile(OomWorkStatusDto reqOomWorkStatusDto);
	
	/**
	 * 
	 * updateWorkStatusAttachFileNum
	 *
	 * @param reqOomWorkStatusDto
	 * @return int
	 */
	public int updateWorkStatusAttachFileNum(OomWorkStatusDto reqOomWorkStatusDto);
	
	/**
	 * 
	 * deleteOomWorkStatus
	 *
	 * @param reqOomWorkStatusDto
	 * @return int
	 */
	public int deleteOomWorkStatus(OomWorkStatusDto reqOomWorkStatusDto);
	
	
}
