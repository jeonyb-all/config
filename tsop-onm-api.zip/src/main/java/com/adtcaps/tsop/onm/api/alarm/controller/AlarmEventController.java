package com.adtcaps.tsop.onm.api.alarm.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.util.CollectionUtils;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.adtcaps.tsop.onm.api.alarm.domain.AlarmEventGridRequestDto;
import com.adtcaps.tsop.onm.api.alarm.domain.AlarmEventGridResultDto;
import com.adtcaps.tsop.onm.api.alarm.domain.SendAlarmRequestDto;
import com.adtcaps.tsop.onm.api.alarm.service.AlarmEventService;
import com.adtcaps.tsop.onm.api.config.TenantConfig;
import com.adtcaps.tsop.onm.api.helper.constant.Const;
import com.adtcaps.tsop.onm.api.helper.domain.ResultDto;
import com.adtcaps.tsop.onm.api.helper.util.PageUtil;

import lombok.extern.slf4j.Slf4j;

/**
 * 
 * <ul>
 * <li>업무 그룹명 : tsop-onm-api</li>
 * <li>서브 업무명 : com.adtcaps.tsop.onm.api.alarm.controller</li>
 * <li>설  명 : AlarmEventController.java</li>
 * <li>작성일 : 2021. 1. 8.</li>
 * <li>작성자 : jeonyb4</li>
 * </ul>
 */
@Slf4j
@RestController
@RequestMapping("/api/alarms")
public class AlarmEventController {
	
	private final String ERR_MSG_NULL_KEY = "Key값이 없습니다.";
	private final String ERR_MSG_NULL_PAGE_NUMBER = "페이지 번호가 없습니다.";
	private final String ERR_MSG_NULL_SERACH_DATE = "조회기간(From or To)이 없습니다.";

	private final String ERR_MSG_NULL_TENANT_ID = "테넌트ID가 없습니다.";
	private final String ERR_MSG_NULL_ALARM_EVENT_ID = "알람이벤트ID가 없습니다.";
	private final String ERR_MSG_NULL_EVENT_DATETIME = "이벤트일시가 없습니다.";
	private final String ERR_MSG_NULL_ALARM_CODE = "알람코드가 없습니다.";
	private final String ERR_MSG_NULL_ALARM_GRADE_CODE = "알람등급코드가 없습니다.";
	
	private final String ERR_MSG_NULL_SEARCH_RESULT_LIST = "조회 결과가 없습니다.";
	private final String ERR_MSG_KEY_AUTH_FAIL = "Key 인증에 실패하였습니다.";
	private final String ERR_MSG_SMS_SEND_FAIL = "알림톡 발송에 실패하였습니다.";
	
	@Autowired
	private TenantConfig tenantConfig;
	
	@Autowired
	private AlarmEventService alarmEventService;
	
	/**
	 * 
	 * listPageAlarmEvent
	 *
	 * @param alarmEventGridRequestDto
	 * @return ResponseEntity
	 */
	@SuppressWarnings("rawtypes")
	@GetMapping(value="", produces="application/json; charset=UTF-8")
	public ResponseEntity listPageAlarmEvent(AlarmEventGridRequestDto alarmEventGridRequestDto) throws Exception {
		
		ResponseEntity<ResultDto> resEntity = null;
		String returnString = "";
		
		int pageNumber = alarmEventGridRequestDto.getPageNumber();
		if (pageNumber < 1) {
			log.error(">>>>>> pageNumber ERROR:{}", ERR_MSG_NULL_PAGE_NUMBER);
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_PAGE_NUMBER));
			return resEntity;
		}
		String fromDate = alarmEventGridRequestDto.getFromDate();
		String toDate = alarmEventGridRequestDto.getToDate();
		if ("".equals(fromDate) || "".equals(toDate)) {
			log.error(">>>>>> fromDate or toDate ERROR:{}", ERR_MSG_NULL_SERACH_DATE);
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_SERACH_DATE));
			return resEntity;
		}
		
		// 알람이벤트 목록조회
		Map<String, Object> alarmEventGridResultDtoListMap = new HashMap<String, Object>();
		List<AlarmEventGridResultDto> alarmEventGridResultDtoList = alarmEventService.listPageAlarmEvent(alarmEventGridRequestDto);
		if (CollectionUtils.isEmpty(alarmEventGridResultDtoList)) {
			returnString = Const.Common.RESULT_CODE.SUCCESS;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_SEARCH_RESULT_LIST, alarmEventGridResultDtoListMap));
        } else {
        	returnString = Const.Common.RESULT_CODE.SUCCESS;
        	alarmEventGridResultDtoListMap.put(Const.Definition.PAGE.PAGER, PageUtil.getPageInfo(alarmEventGridResultDtoList));
        	alarmEventGridResultDtoListMap.put(Const.Definition.PAGE.LISTS, alarmEventGridResultDtoList);
			resEntity = ResponseEntity.ok(new ResultDto(returnString, "", alarmEventGridResultDtoListMap));
		}
		
		return resEntity;
	}
	
	/**
	 * 
	 * sendSmsAlarm
	 *
	 * @param request
	 * @param sendAlarmRequestDto
	 * @return ResponseEntity
	 */
	@SuppressWarnings("rawtypes")
    @PostMapping(value="/sms-sends", produces="application/json; charset=UTF-8")
    public ResponseEntity sendSmsAlarm(HttpServletRequest request, @RequestBody SendAlarmRequestDto sendAlarmRequestDto) throws Exception {
        
    	ResponseEntity<ResultDto> resEntity = null;
		String returnString = "";
    	
		String callKey = StringUtils.defaultString(request.getHeader("Call-Key"));
		String key = StringUtils.defaultString(tenantConfig.getMyServerInfo().getKey());
		if ("".equals(callKey) || "".equals(key)) {
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_KEY));
			return resEntity;
		}
		if (!callKey.equals(key)) {
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_KEY_AUTH_FAIL));
			return resEntity;
		}
		
		String tenantId = sendAlarmRequestDto.getTenantId();
		if ("".equals(tenantId)) {
			log.error(">>>>>> tenantId ERROR:{}", ERR_MSG_NULL_TENANT_ID);
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_TENANT_ID));
			return resEntity;
		}
		String onmAlarmCd = sendAlarmRequestDto.getOnmAlarmCd();
		if ("".equals(onmAlarmCd)) {
			log.error(">>>>>> onmAlarmCd ERROR:{}", ERR_MSG_NULL_ALARM_CODE);
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_ALARM_CODE));
			return resEntity;
		}
		String onmAlarmGradeCd = sendAlarmRequestDto.getOnmAlarmGradeCd();
		if ("".equals(onmAlarmGradeCd)) {
			log.error(">>>>>> onmAlarmGradeCd ERROR:{}", ERR_MSG_NULL_ALARM_GRADE_CODE);
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_ALARM_GRADE_CODE));
			return resEntity;
		}
		int onmAlarmEventId = sendAlarmRequestDto.getOnmAlarmEventId();
		if (onmAlarmEventId < 1) {
			log.error(">>>>>> onmAlarmEventId ERROR:{}", ERR_MSG_NULL_ALARM_EVENT_ID);
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_ALARM_EVENT_ID));
			return resEntity;
		}
		String eventDatetime = sendAlarmRequestDto.getEventDatetime();
		if ("".equals(eventDatetime)) {
			log.error(">>>>>> eventDatetime ERROR:{}", ERR_MSG_NULL_EVENT_DATETIME);
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_EVENT_DATETIME));
			return resEntity;
		}
		
		// 알림톡 발송처리....
		int affectRowCount = alarmEventService.sendSmsAlarm(sendAlarmRequestDto);
		if (affectRowCount < 0) {
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_SMS_SEND_FAIL, affectRowCount));
		} else {
			returnString = Const.Common.RESULT_CODE.SUCCESS;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, "", affectRowCount));
		}
    	
    	return resEntity;
    }

}
