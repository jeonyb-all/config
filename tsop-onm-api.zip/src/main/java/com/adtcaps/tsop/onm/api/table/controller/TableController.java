package com.adtcaps.tsop.onm.api.table.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.util.CollectionUtils;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.adtcaps.tsop.onm.api.helper.constant.Const;
import com.adtcaps.tsop.onm.api.helper.domain.ResultDto;
import com.adtcaps.tsop.onm.api.helper.util.PageUtil;
import com.adtcaps.tsop.onm.api.table.domain.DbTableColumnGridRequestDto;
import com.adtcaps.tsop.onm.api.table.domain.DbTableColumnGridResultDto;
import com.adtcaps.tsop.onm.api.table.domain.DbTableGridRequestDto;
import com.adtcaps.tsop.onm.api.table.domain.DbTableGridResultDto;
import com.adtcaps.tsop.onm.api.table.service.TableService;

import lombok.extern.slf4j.Slf4j;

/**
 * 
 * <ul>
 * <li>업무 그룹명 : tsop-onm-api</li>
 * <li>서브 업무명 : com.adtcaps.tsop.onm.api.table.controller</li>
 * <li>설  명 : TableController.java</li>
 * <li>작성일 : 2021. 1. 7.</li>
 * <li>작성자 : jeonyb4</li>
 * </ul>
 */
@Slf4j
@RestController
@RequestMapping("/api/tables")
public class TableController {
	
	private final String ERR_MSG_NULL_PAGE_NUMBER = "페이지 번호가 없습니다.";
	
	private final String ERR_MSG_NULL_SEARCH_RESULT_LIST = "조회 결과가 없습니다.";
	
	@Autowired
	private TableService tableService;
	
	/**
	 * 
	 * listPageDbTable
	 *
	 * @param dbTableGridRequestDto
	 * @return ResponseEntity
	 */
	@SuppressWarnings("rawtypes")
	@GetMapping(value="", produces="application/json; charset=UTF-8")
	public ResponseEntity listPageDbTable(DbTableGridRequestDto dbTableGridRequestDto) throws Exception {
		
		ResponseEntity<ResultDto> resEntity = null;
		String returnString = "";
		
		int pageNumber = dbTableGridRequestDto.getPageNumber();
		if (pageNumber < 1) {
			log.error(">>>>>> pageNumber ERROR:{}", ERR_MSG_NULL_PAGE_NUMBER);
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_PAGE_NUMBER));
			return resEntity;
		}
		
		// 테이블 목록조회
		Map<String, Object> dbTableGridResultDtoMap = new HashMap<String, Object>();
		List<DbTableGridResultDto> dbTableGridResultDtoList = tableService.listPageDbTable(dbTableGridRequestDto);
		if (CollectionUtils.isEmpty(dbTableGridResultDtoList)) {
			returnString = Const.Common.RESULT_CODE.SUCCESS;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_SEARCH_RESULT_LIST, dbTableGridResultDtoMap));
        } else {
        	returnString = Const.Common.RESULT_CODE.SUCCESS;
        	dbTableGridResultDtoMap.put(Const.Definition.PAGE.PAGER, PageUtil.getPageInfo(dbTableGridResultDtoList));
        	dbTableGridResultDtoMap.put(Const.Definition.PAGE.LISTS, dbTableGridResultDtoList);
			resEntity = ResponseEntity.ok(new ResultDto(returnString, "", dbTableGridResultDtoMap));
		}

		return resEntity;
	}
	
	/**
	 * 
	 * listPageDbTableColumn
	 *
	 * @param dbTableColumnGridRequestDto
	 * @return ResponseEntity
	 */
	@SuppressWarnings("rawtypes")
	@GetMapping(value="/columns", produces="application/json; charset=UTF-8")
	public ResponseEntity listPageDbTableColumn(DbTableColumnGridRequestDto dbTableColumnGridRequestDto) throws Exception {
		
		ResponseEntity<ResultDto> resEntity = null;
		String returnString = "";
		
		int pageNumber = dbTableColumnGridRequestDto.getPageNumber();
		if (pageNumber < 1) {
			log.error(">>>>>> pageNumber ERROR:{}", ERR_MSG_NULL_PAGE_NUMBER);
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_PAGE_NUMBER));
			return resEntity;
		}
		
		// 테이블 컬럼 목록조회
		Map<String, Object> dbTableColumnGridResultDtoListMap = new HashMap<String, Object>();
		List<DbTableColumnGridResultDto> dbTableColumnGridResultDtoList = tableService.listPageDbTableColumn(dbTableColumnGridRequestDto);
		if (CollectionUtils.isEmpty(dbTableColumnGridResultDtoList)) {
			returnString = Const.Common.RESULT_CODE.SUCCESS;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_SEARCH_RESULT_LIST, dbTableColumnGridResultDtoListMap));
        } else {
        	returnString = Const.Common.RESULT_CODE.SUCCESS;
        	dbTableColumnGridResultDtoListMap.put(Const.Definition.PAGE.PAGER, PageUtil.getPageInfo(dbTableColumnGridResultDtoList));
        	dbTableColumnGridResultDtoListMap.put(Const.Definition.PAGE.LISTS, dbTableColumnGridResultDtoList);
			resEntity = ResponseEntity.ok(new ResultDto(returnString, "", dbTableColumnGridResultDtoListMap));
		}

		return resEntity;
	}

}
