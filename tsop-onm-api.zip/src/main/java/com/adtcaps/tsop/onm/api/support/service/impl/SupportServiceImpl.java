package com.adtcaps.tsop.onm.api.support.service.impl;

import java.net.ConnectException;
import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.apache.http.conn.ConnectTimeoutException;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.CollectionUtils;

import com.adtcaps.tsop.onm.api.config.TenantConfig;
import com.adtcaps.tsop.onm.api.domain.OomTechSupportRequestBuildingDto;
import com.adtcaps.tsop.onm.api.domain.OomTechSupportRequestBuildingServiceDto;
import com.adtcaps.tsop.onm.api.domain.OomTechSupportRequestDto;
import com.adtcaps.tsop.onm.api.domain.OomWorkBuildingDto;
import com.adtcaps.tsop.onm.api.domain.OomWorkBuildingServiceConenctionDto;
import com.adtcaps.tsop.onm.api.helper.constant.Const;
import com.adtcaps.tsop.onm.api.helper.domain.ResultDto;
import com.adtcaps.tsop.onm.api.helper.util.CommonDateUtil;
import com.adtcaps.tsop.onm.api.helper.util.CommonObjectUtil;
import com.adtcaps.tsop.onm.api.support.domain.TechSupportRequestGridRequestDto;
import com.adtcaps.tsop.onm.api.support.domain.TechSupportRequestGridResultDto;
import com.adtcaps.tsop.onm.api.support.domain.TechSupportResultDetailResultDto;
import com.adtcaps.tsop.onm.api.support.mapper.OomTechSupportRequestBuildingMapper;
import com.adtcaps.tsop.onm.api.support.mapper.OomTechSupportRequestBuildingServiceMapper;
import com.adtcaps.tsop.onm.api.support.mapper.OomTechSupportRequestMapper;
import com.adtcaps.tsop.onm.api.support.service.SupportService;
import com.adtcaps.tsop.onm.api.work.domain.WorkRegisterDto;
import com.adtcaps.tsop.onm.api.work.service.WorkService;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.gson.Gson;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.squareup.okhttp.MediaType;
import com.squareup.okhttp.OkHttpClient;
import com.squareup.okhttp.Request;
import com.squareup.okhttp.RequestBody;
import com.squareup.okhttp.Response;

/**
 * 
 * <ul>
 * <li>업무 그룹명 : tsop-onm-api</li>
 * <li>서브 업무명 : com.adtcaps.tsop.onm.api.support.service.impl</li>
 * <li>설  명 : SupportServiceImpl.java</li>
 * <li>작성일 : 2021. 1. 3.</li>
 * <li>작성자 : jeonyb4</li>
 * </ul>
 */
@Transactional
@Service
public class SupportServiceImpl implements SupportService {
	
	private final String ERR_MSG_REMOTE_EXECUTION_FAIL = "원격 실행에 실패하였습니다.";
	private final String ERR_MSG_REMOTE_CALL_CONNECTION_FAIL = "원격 접속이 실패하였습니다.";
	private final String ERR_MSG_REMOTE_CALL_TIMEOUT = "원격 실행 시 Timeout이 발생하였습니다.";
	
	private final String ERR_MSG_NULL_TECH_SUPPORT_REQUEST_BUILDING = "건물변경요청내역 등록정보가 없습니다.";
	private final String ERR_MSG_NULL_TECH_SUPPORT_REQUEST_SERVICE = "서비스변경요청내역 등록정보가 없습니다.";
	
	@Autowired
	private OomTechSupportRequestMapper oomTechSupportRequestMapper;
	
	@Autowired
	private OomTechSupportRequestBuildingMapper oomTechSupportRequestBuildingMapper;
	
	@Autowired
	private OomTechSupportRequestBuildingServiceMapper oomTechSupportRequestBuildingServiceMapper;
	
	@Autowired
	private WorkService workService;
	
	@Autowired
	private TenantConfig tenantConfig;
	
	/**
	 * 
	 * listPageTechSupportRequest
	 *
	 * @param techSupportRequestGridRequestDto
	 * @return List<TechSupportRequestGridResultDto>
	 * @throws Exception 
	 */
	@Override
	public List<TechSupportRequestGridResultDto> listPageTechSupportRequest(TechSupportRequestGridRequestDto techSupportRequestGridRequestDto) throws Exception {
		
		List<TechSupportRequestGridResultDto> techSupportRequestGridResultDtoList = null;
		try {
			String fromDate = techSupportRequestGridRequestDto.getFromDate();
    		String toDate = techSupportRequestGridRequestDto.getToDate();
    		
    		fromDate = CommonDateUtil.makeFromDatetime(fromDate);
    		toDate = CommonDateUtil.makeToDatetime(toDate);
    		
    		techSupportRequestGridRequestDto.setFromDate(fromDate);
    		techSupportRequestGridRequestDto.setToDate(toDate);
    		
    		techSupportRequestGridResultDtoList = oomTechSupportRequestMapper.listPageTechSupportRequest(techSupportRequestGridRequestDto);
    		if (!CollectionUtils.isEmpty(techSupportRequestGridResultDtoList)) {
    			for (int idx = 0; idx < techSupportRequestGridResultDtoList.size(); idx++) {
    				
    				TechSupportRequestGridResultDto techSupportRequestGridResultDto = techSupportRequestGridResultDtoList.get(idx);
    				
    				int attachFileNum = CommonObjectUtil.defaultNumber(techSupportRequestGridResultDto.getAttachFileNum());
    				if (attachFileNum > 0) {
    					techSupportRequestGridResultDto.setAttachFileYn("Y");
    				} else {
    					techSupportRequestGridResultDto.setAttachFileYn("N");
    				}
    				
    				String registDatetime = StringUtils.defaultString(techSupportRequestGridResultDto.getRegistDatetime());
    				registDatetime = CommonDateUtil.makeDatetimeFormat(registDatetime);
    				techSupportRequestGridResultDto.setRegistDatetime(registDatetime);
    				
    				techSupportRequestGridResultDtoList.set(idx, techSupportRequestGridResultDto);
    			}
    		}
    		
		} catch (Exception e) {
			throw e;
		}
		return techSupportRequestGridResultDtoList;
	}
	
	/**
	 * 
	 * readTechSupportRequest
	 *
	 * @param reqOomTechSupportRequestDto
	 * @return TechSupportResultDetailResultDto
	 * @throws Exception 
	 */
	@Override
	public TechSupportResultDetailResultDto readTechSupportRequest(OomTechSupportRequestDto reqOomTechSupportRequestDto) throws Exception {
		
		TechSupportResultDetailResultDto techSupportResultDetailResultDto = null;
		try {
			// 기술지원요청 정보 조회 (기타포함)
			techSupportResultDetailResultDto = oomTechSupportRequestMapper.readOomTechSupportRequest(reqOomTechSupportRequestDto);
			if (techSupportResultDetailResultDto != null) {
				String tenantId = techSupportResultDetailResultDto.getTenantId();
				int techSupportReqId = techSupportResultDetailResultDto.getTechSupportReqId();
				String techSupportReqTypeCd = StringUtils.defaultString(techSupportResultDetailResultDto.getTechSupportReqTypeCd());
				if (Const.Code.TECH_SUPPORT_REQ_TYPE_CD.BLD_ADD.equals(techSupportReqTypeCd) || Const.Code.TECH_SUPPORT_REQ_TYPE_CD.BLD_MOD.equals(techSupportReqTypeCd) || 
						Const.Code.TECH_SUPPORT_REQ_TYPE_CD.BLD_DEL.equals(techSupportReqTypeCd)) {
					OomTechSupportRequestBuildingDto reqOomTechSupportRequestBuildingDto = new OomTechSupportRequestBuildingDto();
					reqOomTechSupportRequestBuildingDto.setTenantId(tenantId);
					reqOomTechSupportRequestBuildingDto.setTechSupportReqId(techSupportReqId);
					OomTechSupportRequestBuildingDto rsltOomTechSupportRequestBuildingDto = oomTechSupportRequestBuildingMapper.readOomTechSupportRequestBuilding(reqOomTechSupportRequestBuildingDto);
					techSupportResultDetailResultDto.setBuildingInfo(rsltOomTechSupportRequestBuildingDto);
				} else if (Const.Code.TECH_SUPPORT_REQ_TYPE_CD.SVC_ADD.equals(techSupportReqTypeCd) || Const.Code.TECH_SUPPORT_REQ_TYPE_CD.SVC_DEL.equals(techSupportReqTypeCd)) {
					OomTechSupportRequestBuildingServiceDto reqOomTechSupportRequestBuildingServiceDto = new OomTechSupportRequestBuildingServiceDto();
					reqOomTechSupportRequestBuildingServiceDto.setTenantId(tenantId);
					reqOomTechSupportRequestBuildingServiceDto.setTechSupportReqId(techSupportReqId);
					OomTechSupportRequestBuildingServiceDto rsltOomTechSupportRequestBuildingServiceDto = oomTechSupportRequestBuildingServiceMapper.readOomTechSupportRequestBuildingService(reqOomTechSupportRequestBuildingServiceDto);
					techSupportResultDetailResultDto.setServiceInfo(rsltOomTechSupportRequestBuildingServiceDto);
				}
			}
		} catch (Exception e) {
			throw e;
		}
		return techSupportResultDetailResultDto;
	}
	
	/**
	 * 
	 * updateTechSupportStatus
	 *
	 * @param reqOomTechSupportRequestDto
	 * @return ResultDto
	 * @throws Exception 
	 */
	@Transactional(rollbackFor={Exception.class, DataIntegrityViolationException.class})
	@Override
	public ResultDto updateTechSupportStatus(OomTechSupportRequestDto reqOomTechSupportRequestDto) throws Exception {
		
		ResultDto resultDto = null;
		
		try {
			// 기술지원요청 상태값 수정...
			oomTechSupportRequestMapper.updateTechSupportStatus(reqOomTechSupportRequestDto);
			
			String tenantId = StringUtils.defaultString(reqOomTechSupportRequestDto.getTenantId());
			int techSupportReqId = reqOomTechSupportRequestDto.getTechSupportReqId();
			String techSupportStatusCd = StringUtils.defaultString(reqOomTechSupportRequestDto.getTechSupportStatusCd());
			String techSupportReqTypeCd = StringUtils.defaultString(reqOomTechSupportRequestDto.getTechSupportReqTypeCd());
			// 기술지원요청유형이 기타가 아니고.. 승인 상태면.. 작업 등록...
			if (Const.Code.TECH_SUPPORT_STATUS_CD.APPROVAL.equals(techSupportStatusCd) && !Const.Code.TECH_SUPPORT_REQ_TYPE_CD.ETC.equals(techSupportReqTypeCd)) {
				// 작업등록 처리...
				String auditId = StringUtils.defaultString(reqOomTechSupportRequestDto.getAuditId());
				String onmWorkTypeCd = "";
				String bldId = "";
				String serviceClCd = "";
				OomTechSupportRequestBuildingDto rsltOomTechSupportRequestBuildingDto = null;
				OomTechSupportRequestBuildingServiceDto rsltOomTechSupportRequestBuildingServiceDto = null;
				if (Const.Code.TECH_SUPPORT_REQ_TYPE_CD.BLD_ADD.equals(techSupportReqTypeCd)) {
					onmWorkTypeCd = Const.Code.WORK_TYPE_CD.RB;
					OomTechSupportRequestBuildingDto reqOomTechSupportRequestBuildingDto = new OomTechSupportRequestBuildingDto();
					reqOomTechSupportRequestBuildingDto.setTenantId(tenantId);
					reqOomTechSupportRequestBuildingDto.setTechSupportReqId(techSupportReqId);
					rsltOomTechSupportRequestBuildingDto = oomTechSupportRequestBuildingMapper.readOomTechSupportRequestBuilding(reqOomTechSupportRequestBuildingDto);
					if (rsltOomTechSupportRequestBuildingDto == null) {
						resultDto = new ResultDto(Const.Common.RESULT_CODE.FAIL, ERR_MSG_NULL_TECH_SUPPORT_REQUEST_BUILDING);
		    	    	return resultDto;
					}
				} else if (Const.Code.TECH_SUPPORT_REQ_TYPE_CD.BLD_MOD.equals(techSupportReqTypeCd)) {
					onmWorkTypeCd = Const.Code.WORK_TYPE_CD.CB;
					OomTechSupportRequestBuildingDto reqOomTechSupportRequestBuildingDto = new OomTechSupportRequestBuildingDto();
					reqOomTechSupportRequestBuildingDto.setTenantId(tenantId);
					reqOomTechSupportRequestBuildingDto.setTechSupportReqId(techSupportReqId);
					rsltOomTechSupportRequestBuildingDto = oomTechSupportRequestBuildingMapper.readOomTechSupportRequestBuilding(reqOomTechSupportRequestBuildingDto);
					if (rsltOomTechSupportRequestBuildingDto == null) {
						resultDto = new ResultDto(Const.Common.RESULT_CODE.FAIL, ERR_MSG_NULL_TECH_SUPPORT_REQUEST_BUILDING);
		    	    	return resultDto;
					}
					bldId = rsltOomTechSupportRequestBuildingDto.getBldId();
				} else if (Const.Code.TECH_SUPPORT_REQ_TYPE_CD.BLD_DEL.equals(techSupportReqTypeCd)) {
					onmWorkTypeCd = Const.Code.WORK_TYPE_CD.DB;
					OomTechSupportRequestBuildingDto reqOomTechSupportRequestBuildingDto = new OomTechSupportRequestBuildingDto();
					reqOomTechSupportRequestBuildingDto.setTenantId(tenantId);
					reqOomTechSupportRequestBuildingDto.setTechSupportReqId(techSupportReqId);
					rsltOomTechSupportRequestBuildingDto = oomTechSupportRequestBuildingMapper.readOomTechSupportRequestBuilding(reqOomTechSupportRequestBuildingDto);
					if (rsltOomTechSupportRequestBuildingDto == null) {
						resultDto = new ResultDto(Const.Common.RESULT_CODE.FAIL, ERR_MSG_NULL_TECH_SUPPORT_REQUEST_BUILDING);
		    	    	return resultDto;
					}
					bldId = rsltOomTechSupportRequestBuildingDto.getBldId();
				} else if (Const.Code.TECH_SUPPORT_REQ_TYPE_CD.SVC_ADD.equals(techSupportReqTypeCd)) {
					onmWorkTypeCd = Const.Code.WORK_TYPE_CD.RS;
					OomTechSupportRequestBuildingServiceDto reqOomTechSupportRequestBuildingServiceDto = new OomTechSupportRequestBuildingServiceDto();
					reqOomTechSupportRequestBuildingServiceDto.setTenantId(tenantId);
					reqOomTechSupportRequestBuildingServiceDto.setTechSupportReqId(techSupportReqId);
					rsltOomTechSupportRequestBuildingServiceDto = oomTechSupportRequestBuildingServiceMapper.readOomTechSupportRequestBuildingService(reqOomTechSupportRequestBuildingServiceDto);
					if (rsltOomTechSupportRequestBuildingServiceDto == null) {
						resultDto = new ResultDto(Const.Common.RESULT_CODE.FAIL, ERR_MSG_NULL_TECH_SUPPORT_REQUEST_SERVICE);
		    	    	return resultDto;
					}
					bldId = rsltOomTechSupportRequestBuildingServiceDto.getBldId();
				} else if (Const.Code.TECH_SUPPORT_REQ_TYPE_CD.SVC_DEL.equals(techSupportReqTypeCd)) {
					onmWorkTypeCd = Const.Code.WORK_TYPE_CD.DS;
					OomTechSupportRequestBuildingServiceDto reqOomTechSupportRequestBuildingServiceDto = new OomTechSupportRequestBuildingServiceDto();
					reqOomTechSupportRequestBuildingServiceDto.setTenantId(tenantId);
					reqOomTechSupportRequestBuildingServiceDto.setTechSupportReqId(techSupportReqId);
					rsltOomTechSupportRequestBuildingServiceDto = oomTechSupportRequestBuildingServiceMapper.readOomTechSupportRequestBuildingService(reqOomTechSupportRequestBuildingServiceDto);
					if (rsltOomTechSupportRequestBuildingServiceDto == null) {
						resultDto = new ResultDto(Const.Common.RESULT_CODE.FAIL, ERR_MSG_NULL_TECH_SUPPORT_REQUEST_SERVICE);
		    	    	return resultDto;
					}
					bldId = rsltOomTechSupportRequestBuildingServiceDto.getBldId();
					serviceClCd = rsltOomTechSupportRequestBuildingServiceDto.getServiceClCd();
				}
				
				// 작업 등록...
				WorkRegisterDto reqWorkRegisterDto = new WorkRegisterDto();
				reqWorkRegisterDto.setTenantId(tenantId);
				reqWorkRegisterDto.setAuditId(auditId);
				reqWorkRegisterDto.setTechSupportReqId(techSupportReqId);
				reqWorkRegisterDto.setOnmWorkTypeCd(onmWorkTypeCd);
				reqWorkRegisterDto.setBldId(bldId);
				reqWorkRegisterDto.setServiceClCd(serviceClCd);
				workService.createWork(reqWorkRegisterDto);
				
				int onmWorkId = reqWorkRegisterDto.getOnmWorkId();
				
				// 빌딩 및 서비스작업관련 정보 추가...
				if (Const.Code.TECH_SUPPORT_REQ_TYPE_CD.BLD_ADD.equals(techSupportReqTypeCd) || Const.Code.TECH_SUPPORT_REQ_TYPE_CD.BLD_MOD.equals(techSupportReqTypeCd)) {
					// 빌딩작업 추가..
					OomWorkBuildingDto reqOomWorkBuildingDto = new OomWorkBuildingDto();
					BeanUtils.copyProperties(rsltOomTechSupportRequestBuildingDto, reqOomWorkBuildingDto);
					reqOomWorkBuildingDto.setOnmWorkId(onmWorkId);
					reqOomWorkBuildingDto.setAuditId(auditId);
					workService.mergeWorkBuilding(reqOomWorkBuildingDto);
					
				} else if (Const.Code.TECH_SUPPORT_REQ_TYPE_CD.BLD_DEL.equals(techSupportReqTypeCd)) {
					workService.createWorkBuilding(reqWorkRegisterDto);
					workService.createWorkBuildingServiceConnection(reqWorkRegisterDto);
				
				} else if (Const.Code.TECH_SUPPORT_REQ_TYPE_CD.SVC_ADD.equals(techSupportReqTypeCd)) {
					// 서비스작업 추가..
					OomWorkBuildingServiceConenctionDto reqOomWorkBuildingServiceConenctionDto = new OomWorkBuildingServiceConenctionDto();
					BeanUtils.copyProperties(rsltOomTechSupportRequestBuildingServiceDto, reqOomWorkBuildingServiceConenctionDto);
					reqOomWorkBuildingServiceConenctionDto.setOnmWorkId(onmWorkId);
					reqOomWorkBuildingServiceConenctionDto.setWebAppUseYn("Y");
					reqOomWorkBuildingServiceConenctionDto.setAuditId(auditId);
					workService.mergeWorkBuildingServiceConenction(reqOomWorkBuildingServiceConenctionDto);
				} else if (Const.Code.TECH_SUPPORT_REQ_TYPE_CD.SVC_DEL.equals(techSupportReqTypeCd)) {
					workService.createWorkBuildingServiceConnection(reqWorkRegisterDto);
				}
			}
			
			// Remote Call 처리...
			String actionYn = StringUtils.defaultString(tenantConfig.getTenantSktServerInfo().getActionYn());
			if ("Y".equals(actionYn)) {
				String key = tenantConfig.getTenantSktServerInfo().getKey();
				String portalWasUrl = tenantConfig.getTenantSktServerInfo().getUrl();
				
				StringBuilder urlBuilder = new StringBuilder();
				urlBuilder.append(portalWasUrl);
				urlBuilder.append("/api/portal/callees/update-support-status");
				
				Gson gson = new Gson();
	    	    String requestJsonString = gson.toJson(reqOomTechSupportRequestDto);
				
				OkHttpClient client = new OkHttpClient();
				Request request = new Request.Builder()
						.addHeader("Call-Key", key)
						.url(urlBuilder.toString())
	    	            .post(RequestBody.create(MediaType.parse(org.springframework.http.MediaType.APPLICATION_JSON.toString()), requestJsonString))
	    	            .build();
	    	    
	    	    Response response = null;
				try {
	    	    	response = client.newCall(request).execute();
	    	    } catch (ConnectException e) {
	    	    	resultDto = new ResultDto(Const.Common.RESULT_CODE.FAIL, ERR_MSG_REMOTE_CALL_CONNECTION_FAIL);
	    	    	return resultDto;
	    	    } catch (ConnectTimeoutException e) {
	    	    	resultDto = new ResultDto(Const.Common.RESULT_CODE.FAIL, ERR_MSG_REMOTE_CALL_TIMEOUT);
	    	    	return resultDto;
	    	    }
	    	    
	    	    String responseJsonString = StringUtils.defaultString(response.body().string());
				if ("".equals(responseJsonString)) {
					resultDto = new ResultDto(Const.Common.RESULT_CODE.FAIL, ERR_MSG_REMOTE_EXECUTION_FAIL);
				} else {
					JsonObject responseJsonObject = JsonParser.parseString(responseJsonString).getAsJsonObject();
					
					ObjectMapper objectMapper = new ObjectMapper();
					resultDto = objectMapper.readValue(responseJsonObject.toString(), ResultDto.class);
				}
			}
			
		} catch (Exception e) {
			throw e;
		}
		
		return resultDto;
	}
	
}
