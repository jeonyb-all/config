package com.adtcaps.tsop.onm.api.send.domain;

import com.adtcaps.tsop.onm.api.helper.domain.BasePageDto;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

import lombok.Getter;
import lombok.Setter;

/**
 * 
 * <ul>
 * <li>업무 그룹명 : tsop-onm-api</li>
 * <li>서브 업무명 : com.adtcaps.tsop.onm.api.send.domain</li>
 * <li>설  명 : AlarmNoticeSendGridResultDto.java</li>
 * <li>작성일 : 2021. 1. 30.</li>
 * <li>작성자 : jeonyb4</li>
 * </ul>
 */
@Getter
@Setter
@JsonInclude(Include.NON_EMPTY)
public class AlarmNoticeSendGridResultDto extends BasePageDto {
	private Integer rowNum;
	private String notiTypeVal;
	private String bulletinTypeCd;
	private Integer bulletinNum;
	private Integer transSeq;
	private String tenantId;
	private Integer alarmNoticeGroupId;
	private Integer alarmNoticeTransSeq;
	private String transDatetime;
	private String msgContent;
	private String alarmNoticeMethodClCd;
	private String alarmNoticeMethodClName;
	private String alarmNoticeResultCd;
	private String alarmNoticeResultName;
	private String transDatetimeFormat;

}
