package com.adtcaps.tsop.onm.api.dashboard.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;

import com.adtcaps.tsop.onm.api.dashboard.domain.DashboardRequestDto;
import com.adtcaps.tsop.onm.api.dashboard.domain.DashboardTopoResourceResultDto;

/**
 * 
 * <ul>
 * <li>업무 그룹명 : tsop-onm-api</li>
 * <li>서브 업무명 : com.adtcaps.tsop.onm.api.dashboard.mapper</li>
 * <li>설  명 : OomTenantTopologyResourceMapper.java</li>
 * <li>작성일 : 2021. 2. 1.</li>
 * <li>작성자 : song</li>
 * </ul>
 */
@Mapper
public interface OomTenantTopologyResourceMapper {
	
	public List<DashboardTopoResourceResultDto> listDashboardTopoResource(DashboardRequestDto reqDashboardDto);
	
}
