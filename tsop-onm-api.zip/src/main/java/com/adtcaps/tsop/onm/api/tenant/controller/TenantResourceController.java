package com.adtcaps.tsop.onm.api.tenant.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.util.CollectionUtils;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.adtcaps.tsop.onm.api.domain.OomTenantResourceDetailDto;
import com.adtcaps.tsop.onm.api.domain.OomTenantResourceDto;
import com.adtcaps.tsop.onm.api.helper.constant.Const;
import com.adtcaps.tsop.onm.api.helper.domain.ResultDto;
import com.adtcaps.tsop.onm.api.tenant.domain.TenantResourceDetailGridResultDto;
import com.adtcaps.tsop.onm.api.tenant.domain.TenantResourceForComboResultDto;
import com.adtcaps.tsop.onm.api.tenant.service.TenantResourceService;

import lombok.extern.slf4j.Slf4j;

/**
 * 
 * <ul>
 * <li>업무 그룹명 : tsop-onm-api</li>
 * <li>서브 업무명 : com.adtcaps.tsop.onm.api.tenant.controller</li>
 * <li>설  명 : TenantResourceController.java</li>
 * <li>작성일 : 2021. 1. 6.</li>
 * <li>작성자 : jeonyb4</li>
 * </ul>
 */
@Slf4j
@RestController
@RequestMapping("/api/tenant-resources")
public class TenantResourceController {
	
	private final String ERR_MSG_NULL_TENANT_ID = "테넌트ID가 없습니다.";
	private final String ERR_MSG_NULL_RESOURCE_CATEGORY_CD = "자원분류코드가 없습니다.";
	
	private final String ERR_MSG_NULL_SEARCH_RESULT_LIST = "조회 결과가 없습니다.";
	private final String ERR_MSG_READ_FAIL = "조회에 실패하였습니다.";
	
	@Autowired
	private TenantResourceService tenantResourceService;
	
	/**
	 * 
	 * listTenantResourceForThresholdCombo
	 *
	 * @param tenantId
	 * @return ResponseEntity
	 */
	@SuppressWarnings("rawtypes")
	@GetMapping(value="/threshold-alarms/combobox", produces="application/json; charset=UTF-8")
	public ResponseEntity listTenantResourceForThresholdCombo(OomTenantResourceDetailDto reqOomTenantResourceDetailDto) throws Exception {
		
		ResponseEntity<ResultDto> resEntity = null;
		String returnString = "";
		
		String tenantId = StringUtils.defaultString(reqOomTenantResourceDetailDto.getTenantId());
		if ("".equals(tenantId)) {
			log.error(">>>>>> tenantId ERROR:{}", ERR_MSG_NULL_TENANT_ID);
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_TENANT_ID));
			return resEntity;
		}
		String onmResourceCategoryCd = StringUtils.defaultString(reqOomTenantResourceDetailDto.getOnmResourceCategoryCd());
		if ("".equals(onmResourceCategoryCd)) {
			log.error(">>>>>> onmResourceCategoryCd ERROR:{}", ERR_MSG_NULL_RESOURCE_CATEGORY_CD);
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_RESOURCE_CATEGORY_CD));
			return resEntity;
		}
		
		// 임계치 제공용 테넌트리소스상세 콤보박스 목록조회
		List<TenantResourceForComboResultDto> tenantResourceForComboResultDtoList = tenantResourceService.listTenantResourceForThresholdCombo(reqOomTenantResourceDetailDto);
		if (CollectionUtils.isEmpty(tenantResourceForComboResultDtoList)) {
			returnString = Const.Common.RESULT_CODE.SUCCESS;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_SEARCH_RESULT_LIST, tenantResourceForComboResultDtoList));
        } else {
        	returnString = Const.Common.RESULT_CODE.SUCCESS;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, "", tenantResourceForComboResultDtoList));
		}

		return resEntity;
	}
	
	/**
	 * 
	 * readTenantResource
	 *
	 * @param tenantId
	 * @return ResponseEntity
	 */
	@SuppressWarnings("rawtypes")
	@GetMapping(value="/tenants/{tenantId}", produces="application/json; charset=UTF-8")
	public ResponseEntity readTenantResource(@PathVariable("tenantId") String tenantId) throws Exception {
		
		ResponseEntity<ResultDto> resEntity = null;
		String returnString = "";
		
		OomTenantResourceDto reqOomTenantResourceDto = new OomTenantResourceDto();
		reqOomTenantResourceDto.setTenantId(tenantId);
		
		// 테넌트별 테넌트리소스 상세조회
		OomTenantResourceDto rsltOomTenantResourceDto = tenantResourceService.readTenantResource(reqOomTenantResourceDto);
		if (rsltOomTenantResourceDto == null) {
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_READ_FAIL, rsltOomTenantResourceDto));
        } else {
        	returnString = Const.Common.RESULT_CODE.SUCCESS;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, "", rsltOomTenantResourceDto));
		}

		return resEntity;
	}
	
	/**
	 * 
	 * listTenantResourceDetail
	 *
	 * @param tenantId
	 * @return ResponseEntity
	 */
	@SuppressWarnings("rawtypes")
	@GetMapping(value="/tenants/{tenantId}/resource-details", produces="application/json; charset=UTF-8")
	public ResponseEntity listTenantResourceDetail(@PathVariable("tenantId") String tenantId) throws Exception {
		
		ResponseEntity<ResultDto> resEntity = null;
		String returnString = "";
		
		OomTenantResourceDetailDto reqOomTenantResourceDetailDto = new OomTenantResourceDetailDto();
		reqOomTenantResourceDetailDto.setTenantId(tenantId);
		
		// 테넌트별 테넌트리소스상세 목록조회
		Map<String, Object> tenantResourceDetailGridResultDtoListMap = new HashMap<String, Object>();
		List<TenantResourceDetailGridResultDto> tenantResourceDetailGridResultDtoList = tenantResourceService.listTenantResourceDetail(reqOomTenantResourceDetailDto);
		if (CollectionUtils.isEmpty(tenantResourceDetailGridResultDtoList)) {
			returnString = Const.Common.RESULT_CODE.SUCCESS;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_SEARCH_RESULT_LIST, tenantResourceDetailGridResultDtoListMap));
        } else {
        	returnString = Const.Common.RESULT_CODE.SUCCESS;
			int totalCount = tenantResourceDetailGridResultDtoList.size();
			Map<String, Object> totalCountMap = new HashMap<String, Object>();
			totalCountMap.put("totalCount", totalCount);
			
        	tenantResourceDetailGridResultDtoListMap.put(Const.Definition.PAGE.PAGER, totalCountMap);
        	tenantResourceDetailGridResultDtoListMap.put(Const.Definition.PAGE.LISTS, tenantResourceDetailGridResultDtoList);
			resEntity = ResponseEntity.ok(new ResultDto(returnString, "", tenantResourceDetailGridResultDtoListMap));
		}

		return resEntity;
	}

}
