package com.adtcaps.tsop.onm.api.tenant.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.adtcaps.tsop.onm.api.domain.OomTenantResourceDetailDto;
import com.adtcaps.tsop.onm.api.domain.OomTenantResourceDto;
import com.adtcaps.tsop.onm.api.tenant.domain.TenantResourceDetailGridResultDto;
import com.adtcaps.tsop.onm.api.tenant.domain.TenantResourceForComboResultDto;
import com.adtcaps.tsop.onm.api.tenant.mapper.OomTenantResourceDetailMapper;
import com.adtcaps.tsop.onm.api.tenant.mapper.OomTenantResourceMapper;
import com.adtcaps.tsop.onm.api.tenant.service.TenantResourceService;

/**
 * 
 * <ul>
 * <li>업무 그룹명 : tsop-onm-api</li>
 * <li>서브 업무명 : com.adtcaps.tsop.onm.api.tenant.service.impl</li>
 * <li>설  명 : TenantResourceServiceImpl.java</li>
 * <li>작성일 : 2021. 1. 6.</li>
 * <li>작성자 : jeonyb4</li>
 * </ul>
 */
@Service
public class TenantResourceServiceImpl implements TenantResourceService {
	
	@Autowired
	private OomTenantResourceMapper oomTenantResourceMapper;
	
	@Autowired
	private OomTenantResourceDetailMapper oomTenantResourceDetailMapper;
	
	/**
	 * 
	 * listTenantResourceForThresholdCombo
	 *
	 * @param reqOomTenantResourceDetailDto
	 * @return List<TenantResourceForComboResultDto>
	 * @throws Exception 
	 */
	@Override
	public List<TenantResourceForComboResultDto> listTenantResourceForThresholdCombo(OomTenantResourceDetailDto reqOomTenantResourceDetailDto) throws Exception {
		
		List<TenantResourceForComboResultDto> tenantResourceForComboResultDtoList = null;
		try {
			tenantResourceForComboResultDtoList = oomTenantResourceDetailMapper.listTenantResourceForThresholdCombo(reqOomTenantResourceDetailDto);
		} catch (Exception e) {
			throw e;
		}
		return tenantResourceForComboResultDtoList;
	}
	
	/**
	 * 
	 * readTenantResource
	 *
	 * @param reqOomTenantResourceDto
	 * @return OomTenantResourceDto
	 * @throws Exception 
	 */
	@Override
	public OomTenantResourceDto readTenantResource(OomTenantResourceDto reqOomTenantResourceDto) throws Exception {
		
		OomTenantResourceDto rsltOomTenantResourceDto = null;
		try {
			rsltOomTenantResourceDto = oomTenantResourceMapper.readTenantResource(reqOomTenantResourceDto);
		} catch (Exception e) {
			throw e;
		}
		return rsltOomTenantResourceDto;
	}
	
	/**
	 * 
	 * listTenantResourceDetail
	 *
	 * @param reqOomTenantResourceDetailDto
	 * @return List<TenantResourceDetailGridResultDto>
	 * @throws Exception 
	 */
	@Override
	public List<TenantResourceDetailGridResultDto> listTenantResourceDetail(OomTenantResourceDetailDto reqOomTenantResourceDetailDto) throws Exception {
		
		List<TenantResourceDetailGridResultDto> tenantResourceDetailGridResultDtoList = null;
		try {
			tenantResourceDetailGridResultDtoList = oomTenantResourceDetailMapper.listTenantResourceDetail(reqOomTenantResourceDetailDto);
		} catch (Exception e) {
			throw e;
		}
		return tenantResourceDetailGridResultDtoList;
	}
	
	/**
	 * 
	 * readTenantResourceForWork
	 *
	 * @param reqOomTenantResourceDto
	 * @return OomTenantResourceDto
	 * @throws Exception
	 */
	@Override
	public OomTenantResourceDto readTenantResourceForWork(OomTenantResourceDto reqOomTenantResourceDto) throws Exception {
		
		OomTenantResourceDto rsltOomTenantResourceDto = null;
		try {
			rsltOomTenantResourceDto = oomTenantResourceMapper.readTenantResourceForWork(reqOomTenantResourceDto);
		} catch (Exception e) {
			throw e;
		}
		return rsltOomTenantResourceDto;
	}
	
	/**
	 * 
	 * listTenantResourceDetailForWork
	 *
	 * @param reqOomTenantResourceDetailDto
	 * @return List<OomTenantResourceDetailDto>
	 * @throws Exception 
	 */
	@Override
	public List<OomTenantResourceDetailDto> listTenantResourceDetailForWork(OomTenantResourceDetailDto reqOomTenantResourceDetailDto) throws Exception {
		
		List<OomTenantResourceDetailDto> rsltOomTenantResourceDetailDtoList = null;
		try {
			rsltOomTenantResourceDetailDtoList = oomTenantResourceDetailMapper.listTenantResourceDetailForWork(reqOomTenantResourceDetailDto);
		} catch (Exception e) {
			throw e;
		}
		return rsltOomTenantResourceDetailDtoList;
	}

}
