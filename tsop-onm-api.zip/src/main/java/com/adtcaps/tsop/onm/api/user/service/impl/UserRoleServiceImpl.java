package com.adtcaps.tsop.onm.api.user.service.impl;

import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import com.adtcaps.tsop.onm.api.domain.OomUserRoleAuthorityDetailDto;
import com.adtcaps.tsop.onm.api.domain.OomUserRoleDetailDto;
import com.adtcaps.tsop.onm.api.domain.OomUserRoleDto;
import com.adtcaps.tsop.onm.api.helper.domain.BasePageDto;
import com.adtcaps.tsop.onm.api.helper.util.CommonObjectUtil;
import com.adtcaps.tsop.onm.api.user.domain.RoleMenuTreeResultDto;
import com.adtcaps.tsop.onm.api.user.domain.UserRoleDetailResultDto;
import com.adtcaps.tsop.onm.api.user.domain.UserRoleForComboResultDto;
import com.adtcaps.tsop.onm.api.user.domain.UserRoleGridResultDto;
import com.adtcaps.tsop.onm.api.user.domain.UserRoleMenuAuthorityRequestDto;
import com.adtcaps.tsop.onm.api.user.domain.UserRoleProcessingDto;
import com.adtcaps.tsop.onm.api.user.mapper.OomUserRoleAuthorityDetailMapper;
import com.adtcaps.tsop.onm.api.user.mapper.OomUserRoleDetailMapper;
import com.adtcaps.tsop.onm.api.user.mapper.OomUserRoleMapper;
import com.adtcaps.tsop.onm.api.user.service.UserRoleService;

/**
 * 
 * <ul>
 * <li>업무 그룹명 : tsop-onm-api</li>
 * <li>서브 업무명 : com.adtcaps.tsop.onm.api.user.service.impl</li>
 * <li>설  명 : UserRoleServiceImpl.java</li>
 * <li>작성일 : 2021. 1. 4.</li>
 * <li>작성자 : jeonyb4</li>
 * </ul>
 */
@Service
public class UserRoleServiceImpl implements UserRoleService {
	
//	@Autowired
//	private OomUserRoleDetailDetailMapper oomUserRoleDetailDetailMapper;
	
	@Autowired
	private OomUserRoleDetailMapper oomUserRoleDetailMapper;
	
	@Autowired
	private OomUserRoleMapper oomUserRoleMapper;
	
	@Autowired
	private OomUserRoleAuthorityDetailMapper oomUserRoleAuthorityDetailMapper;
	
	
	/**
	 * 
	 * listUserRoleForCombo
	 *
	 * @return List<UserRoleForComboResultDto>
	 * @throws Exception 
	 */
	@Override
	public List<UserRoleForComboResultDto> listUserRoleForCombo() throws Exception {
		
		List<UserRoleForComboResultDto> userRoleForComboResultDtoList = null;
		try {
			userRoleForComboResultDtoList = oomUserRoleMapper.listUserRoleForCombo();
    		
		} catch (Exception e) {
			throw e;
		}
		return userRoleForComboResultDtoList;
	}
	
	/**
	 * 
	 * listPageUserRole
	 *
	 * @param reqBasePageDto
	 * @return List<UserRoleGridResultDto>
	 * @throws Exception 
	 */
	@Override
	public List<UserRoleGridResultDto> listPageUserRole(BasePageDto reqBasePageDto) throws Exception {
		
		List<UserRoleGridResultDto> userRoleGridResultDtoList = null;
		try {
			userRoleGridResultDtoList = oomUserRoleMapper.listPageUserRole(reqBasePageDto);
    		
		} catch (Exception e) {
			throw e;
		}
		return userRoleGridResultDtoList;
	}
	
	/**
	 * 
	 * readUserRoleDuplicationByName
	 *
	 * @param reqOomUserRoleDto
	 * @return int
	 * @throws Exception 
	 */
	@Override
	public int readUserRoleDuplicationByName(OomUserRoleDto reqOomUserRoleDto) throws Exception {
		
		int userRoleCount = 0;
		try {
			userRoleCount = oomUserRoleMapper.readUserRoleDuplicationByName(reqOomUserRoleDto);
    		
		} catch (Exception e) {
			throw e;
		}
		return userRoleCount;
	}
	
	/**
	 * 
	 * createUserRole
	 *
	 * @param reqUserRoleProcessingDto
	 * @return int
	 * @throws Exception 
	 */
	@Override
	public int createUserRole(UserRoleProcessingDto reqUserRoleProcessingDto) throws Exception {
		
		int affectRowCount = 0;
		
		try {
			// 메뉴그룹 등록...
			OomUserRoleDto reqOomUserRoleDto = reqUserRoleProcessingDto.getRoleInfo();
			int insertRow = oomUserRoleMapper.createOomUserRole(reqOomUserRoleDto);
			affectRowCount = affectRowCount + insertRow;
			
			// 메뉴그룹별 메뉴 등록...
			List<OomUserRoleAuthorityDetailDto> reqOomUserRoleAuthorityDetailDtoList = reqUserRoleProcessingDto.getMenuAuthList();
			if (!CollectionUtils.isEmpty(reqOomUserRoleAuthorityDetailDtoList)) {
				String roleId = reqOomUserRoleDto.getRoleId();
				String auditId = reqOomUserRoleDto.getAuditId();
				for (OomUserRoleAuthorityDetailDto reqOomUserRoleAuthorityDetailDto : reqOomUserRoleAuthorityDetailDtoList) {
					String authorityTypeCd = StringUtils.defaultString(reqOomUserRoleAuthorityDetailDto.getAuthorityTypeCd());
					if ("".equals(authorityTypeCd)) {
						continue;
					}
					reqOomUserRoleAuthorityDetailDto.setRoleId(roleId);
					reqOomUserRoleAuthorityDetailDto.setAuditId(auditId);
					insertRow = oomUserRoleAuthorityDetailMapper.createOomUserRoleAuthorityDetail(reqOomUserRoleAuthorityDetailDto);
					affectRowCount = affectRowCount + insertRow;
				}
			}
			
		} catch (Exception e) {
			throw e;
		}
		
		return affectRowCount;
	}
	
	/**
	 * 
	 * readUserRole
	 *
	 * @param reqOomUserRoleDto
	 * @return UserRoleDetailResultDto
	 * @throws Exception 
	 */
	@Override
	public UserRoleDetailResultDto readUserRole(OomUserRoleDto reqOomUserRoleDto) throws Exception {
		
		UserRoleDetailResultDto userRoleDetailResultDto = null;
		try {
			OomUserRoleDto rsltOomUserRoleDto = oomUserRoleMapper.readOomUserRole(reqOomUserRoleDto);
			if (rsltOomUserRoleDto != null) {
				userRoleDetailResultDto = new UserRoleDetailResultDto();
				userRoleDetailResultDto.setRoleInfo(rsltOomUserRoleDto);
				
				String roleId = reqOomUserRoleDto.getRoleId();
				OomUserRoleAuthorityDetailDto reqOomUserRoleAuthorityDetailDto = new OomUserRoleAuthorityDetailDto();
				reqOomUserRoleAuthorityDetailDto.setRoleId(roleId);
				List<RoleMenuTreeResultDto> roleMenuTreeResultDtoList = oomUserRoleAuthorityDetailMapper.listRoleMenuTree(reqOomUserRoleAuthorityDetailDto);
				if (!CollectionUtils.isEmpty(roleMenuTreeResultDtoList)) {
					for (int idx = 0; idx < roleMenuTreeResultDtoList.size(); idx++) {
						RoleMenuTreeResultDto roleMenuTreeResultDto = roleMenuTreeResultDtoList.get(idx);
						String fullMenuName = StringUtils.defaultString(roleMenuTreeResultDto.getFullMenuName());
						fullMenuName = CommonObjectUtil.replaceAllCertainSection(fullMenuName, '>', "    ");
						roleMenuTreeResultDto.setFullMenuName(fullMenuName);
						roleMenuTreeResultDtoList.set(idx, roleMenuTreeResultDto);
					}
					userRoleDetailResultDto.setMenuAuthList(roleMenuTreeResultDtoList);
				}
			}
			
		} catch (Exception e) {
			throw e;
		}
		return userRoleDetailResultDto;
	}
	
	/**
	 * 
	 * updateUserRole
	 *
	 * @param reqUserRoleProcessingDto
	 * @return int
	 * @throws Exception 
	 */
	@Override
	public int updateUserRole(UserRoleProcessingDto reqUserRoleProcessingDto) throws Exception {
		
		int affectRowCount = 0;
		
		try {
			OomUserRoleDto reqOomUserRoleDto = reqUserRoleProcessingDto.getRoleInfo();
			String roleId = reqOomUserRoleDto.getRoleId();
			
			// 메뉴그룹별 메뉴 삭제...
			OomUserRoleAuthorityDetailDto delOomUserRoleAuthorityDetailDto = new OomUserRoleAuthorityDetailDto();
			delOomUserRoleAuthorityDetailDto.setRoleId(roleId);
			int deleteRow = oomUserRoleAuthorityDetailMapper.deleteOomUserRoleAuthorityDetail(delOomUserRoleAuthorityDetailDto);
			affectRowCount = affectRowCount + deleteRow;
			
			// 메뉴그룹별 메뉴 등록...
			List<OomUserRoleAuthorityDetailDto> reqOomUserRoleAuthorityDetailDtoList = reqUserRoleProcessingDto.getMenuAuthList();
			if (!CollectionUtils.isEmpty(reqOomUserRoleAuthorityDetailDtoList)) {
				String auditId = reqOomUserRoleDto.getAuditId();
				for (OomUserRoleAuthorityDetailDto reqOomUserRoleAuthorityDetailDto : reqOomUserRoleAuthorityDetailDtoList) {
					String authorityTypeCd = StringUtils.defaultString(reqOomUserRoleAuthorityDetailDto.getAuthorityTypeCd());
					if ("".equals(authorityTypeCd)) {
						continue;
					}
					reqOomUserRoleAuthorityDetailDto.setRoleId(roleId);
					reqOomUserRoleAuthorityDetailDto.setAuditId(auditId);
					int insertRow = oomUserRoleAuthorityDetailMapper.createOomUserRoleAuthorityDetail(reqOomUserRoleAuthorityDetailDto);
					affectRowCount = affectRowCount + insertRow;
				}
			}
			
			// 메뉴그룹 수정...
			int updateRow = oomUserRoleMapper.updateOomUserRole(reqOomUserRoleDto);
			affectRowCount = affectRowCount + updateRow;
			
		} catch (Exception e) {
			throw e;
		}
		
		return affectRowCount;
	}
	
	/**
	 * 
	 * readUserRoleDetailCount
	 *
	 * @param reqOomUserRoleDetailDto
	 * @return int
	 * @throws Exception 
	 */
	@Override
	public int readUserRoleDetailCount(OomUserRoleDetailDto reqOomUserRoleDetailDto) throws Exception {
		
		int userCount = 0;
		
		try {
			userCount = oomUserRoleDetailMapper.readOomUserRoleDetailCount(reqOomUserRoleDetailDto);
		} catch (Exception e) {
			throw e;
		}
		return userCount;
	}
	
	/**
	 * 
	 * deleteUserRole
	 *
	 * @param reqOomUserRoleDto
	 * @return int
	 * @throws Exception 
	 */
	@Override
	public int deleteUserRole(OomUserRoleDto reqOomUserRoleDto) throws Exception {
		
		int affectRowCount = 0;
		
		try {
			String roleId = reqOomUserRoleDto.getRoleId();
			
			// 메뉴그룹별 메뉴 삭제...
			OomUserRoleAuthorityDetailDto delOomUserRoleAuthorityDetailDto = new OomUserRoleAuthorityDetailDto();
			delOomUserRoleAuthorityDetailDto.setRoleId(roleId);
			int deleteRow = oomUserRoleAuthorityDetailMapper.deleteOomUserRoleAuthorityDetail(delOomUserRoleAuthorityDetailDto);
			affectRowCount = affectRowCount + deleteRow;
			
			// 메뉴그룹 삭제...
			deleteRow = oomUserRoleMapper.deleteOomUserRole(reqOomUserRoleDto);
			affectRowCount = affectRowCount + deleteRow;
			
		} catch (Exception e) {
			throw e;
		}
		
		return affectRowCount;
	}
	
	/**
	 * 
	 * readMenuAuthority
	 * 
	 * @param userRoleMenuAuthorityRequestDto
	 * @return OomUserRoleAuthorityDetailDto
	 * @throws Exception 
	 */
	@Override
	public OomUserRoleAuthorityDetailDto readMenuAuthority(UserRoleMenuAuthorityRequestDto userRoleMenuAuthorityRequestDto) throws Exception {
		
		OomUserRoleAuthorityDetailDto rsltOomUserRoleAuthorityDetailDto = null;
		try {
			
			rsltOomUserRoleAuthorityDetailDto = oomUserRoleAuthorityDetailMapper.readRoleMenuAuthority(userRoleMenuAuthorityRequestDto);
    		
		} catch (Exception e) {
			throw e;
		}
		return rsltOomUserRoleAuthorityDetailDto;
	}
	
	
	
	/*******************************************************************************************/
	
	/**
	 * 
	 * listUserRoleBuilding
	 *
	 * @param reqOomUserRoleDetailDetailDto
	 * @return List<BuildingForComboResultDto>
	 * @throws Exception 
	 */
//	@Override
//	public List<BuildingForComboResultDto> listUserRoleBuilding(OomUserRoleDetailDetailDto reqOomUserRoleDetailDetailDto) throws Exception {
//		
//		List<BuildingForComboResultDto> buildingForComboResultDtoList = null;
//		try {
//			buildingForComboResultDtoList = oomUserRoleDetailDetailMapper.listUserRoleBuilding(reqOomUserRoleDetailDetailDto);
//    		
//		} catch (Exception e) {
//			throw e;
//		}
//		return buildingForComboResultDtoList;
//	}
	
	/**
	 * 
	 * listPageUserRoleDetailDetail
	 *
	 * @param reqBasePageDto
	 * @return List<UserRoleDetailDetailGridResultDto>
	 * @throws Exception 
	 */
//	@Override
//	public List<UserRoleDetailDetailGridResultDto> listPageUserRoleDetailDetail(BasePageDto reqBasePageDto) throws Exception {
//		
//		List<UserRoleDetailDetailGridResultDto> userRoleMappingDetailGridResultDtoList = null;
//		try {
//			userRoleMappingDetailGridResultDtoList = oomUserRoleDetailDetailMapper.listPageUserRoleDetailDetail(reqBasePageDto);
//    		
//		} catch (Exception e) {
//			throw e;
//		}
//		return userRoleMappingDetailGridResultDtoList;
//	}
	
	/**
	 * 
	 * createUserRoleDetail
	 *
	 * @param reqOomUserRoleDetailDto
	 * @return int
	 * @throws Exception 
	 */
	@Override
	public int createUserRoleDetail(OomUserRoleDetailDto reqOomUserRoleDetailDto) throws Exception {
		
		int affectRowCount = 0;
		
		try {
			// 사용자별 메뉴그룹 등록...
			int insertRow = oomUserRoleDetailMapper.createOomUserRoleDetail(reqOomUserRoleDetailDto);
			affectRowCount = affectRowCount + insertRow;
			
		} catch (Exception e) {
			throw e;
		}
		
		return affectRowCount;
	}
	
	/**
	 * 
	 * updateUserRoleDetail
	 *
	 * @param reqOomUserRoleDetailDto
	 * @return int
	 * @throws Exception 
	 */
	@Override
	public int updateUserRoleDetail(OomUserRoleDetailDto reqOomUserRoleDetailDto) throws Exception {
		
		int affectRowCount = 0;
		
		try {
			// 사용자별 메뉴그룹 삭제...
			int deleteRow = oomUserRoleDetailMapper.updateOomUserRoleDetail(reqOomUserRoleDetailDto);
			affectRowCount = affectRowCount + deleteRow;
			
		} catch (Exception e) {
			throw e;
		}
		
		return affectRowCount;
	}
	
	/**
	 * 
	 * createUserRoleDetailDetail
	 *
	 * @param reqOomUserRoleDetailDetailDto
	 * @return int
	 * @throws Exception 
	 */
//	@Override
//	public int createUserRoleDetailDetail(OomUserRoleDetailDetailDto reqOomUserRoleDetailDetailDto) throws Exception {
//		
//		int affectRowCount = 0;
//		
//		try {
//			// 사용자별 메뉴그룹별 빌딩 등록...
//			int insertRow = oomUserRoleDetailDetailMapper.createOomUserRoleDetailDetail(reqOomUserRoleDetailDetailDto);
//			affectRowCount = affectRowCount + insertRow;
//			
//		} catch (Exception e) {
//			throw e;
//		}
//		
//		return affectRowCount;
//	}
	
	/**
	 * 
	 * deleteUserRoleDetailDetail
	 *
	 * @param reqOomUserRoleDetailDetailDto
	 * @return int
	 * @throws Exception 
	 */
//	@Override
//	public int deleteUserRoleDetailDetail(OomUserRoleDetailDetailDto reqOomUserRoleDetailDetailDto) throws Exception {
//		
//		int affectRowCount = 0;
//		
//		try {
//			// 사용자별 메뉴그룹 빌딩 삭제...
//			int deleteRow = oomUserRoleDetailDetailMapper.deleteOomUserRoleDetailDetail(reqOomUserRoleDetailDetailDto);
//			affectRowCount = affectRowCount + deleteRow;
//			
//		} catch (Exception e) {
//			throw e;
//		}
//		
//		return affectRowCount;
//	}

}
