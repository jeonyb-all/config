package com.adtcaps.tsop.onm.api.sms.service;

import com.adtcaps.tsop.onm.api.helper.constant.Const;
import com.adtcaps.tsop.onm.api.helper.util.CommonObjectUtil;
import com.adtcaps.tsop.onm.api.sms.domain.SmsAccessInformation;
import com.adtcaps.tsop.onm.api.sms.domain.SmsApiResponse;
import com.adtcaps.tsop.onm.api.sms.util.RestTemplateUtil;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpMethod;
import org.springframework.stereotype.Service;

import java.util.Map;
import java.util.ArrayList;
import java.util.List;

import java.io.UnsupportedEncodingException;
import java.util.concurrent.TimeUnit ;

/**
 * SmsServiceImpl.
 *
 * @author sjlee@sk.com
 */
@Service
public class SmsServiceImpl implements SmsService {

    private final String SMS_RETURN_CD_FAIL = "00";
	private final String SMS_RETURN_MSG_FAIL = "SMS 발송에 실패하였습니다. 잠시 후 다시 시도해주세요";

    private final String SMS_ERROR_CD = "00";
    private final String SMS_ERROR_MSG = "SMS 발송에 실패하였습니다. 잠시 후 다시 시도해주세요";

    /**
     * Logger
     */
    private static final Logger LOGGER = LoggerFactory.getLogger(SmsServiceImpl.class);

    /**
     * RestTemplate Util
     */
    @Autowired
    RestTemplateUtil restTemplateUtil;

    /**
     * AccessService
     */
    @Autowired
    SmsAccessInformationService smsAccessInformationService;

    
    @Override
    public SmsApiResponse sendSms(Map<String, Object> smsContent) throws Exception {
    	
    	String recvNo = StringUtils.defaultString((String)smsContent.get("recv_no"));
    	String msg = StringUtils.defaultString((String)smsContent.get("msg"));
    	// 전화번호 중복체크
        recvNo = CommonObjectUtil.duplicateRecvNoCheck(recvNo);
        
    	// 메시지 길이제한
 //   	msg = CommonObjectUtil.subStringBytes(msg, Integer.parseInt(Const.Definition.COMMON_VAL.SMS_BYTE_LENGTH));
        
        // 메시지 Concatenate
        List< String > targetList = new ArrayList< String >() ;

        try {
                CommonObjectUtil.concat( msg, targetList, Integer.parseInt(Const.Definition.COMMON_VAL.SMS_BYTE_LENGTH)) ;
                SmsAccessInformation smsAccessInformation = smsAccessInformationService.getAccessInfo();
                Map responseMap = null ;
                int concatCount = 0;
	    	    for( String target : targetList ) {
                    if( concatCount > 0 ) {
                        try {
                            TimeUnit.MILLISECONDS.sleep( 100 ) ;
                            LOGGER.debug("CONCATENATE SLEEP");
                        } catch ( InterruptedException e ) {
                            LOGGER.debug("Thread ERROR!!");
                        }
                    }

                    String fullUrl = smsAccessInformation.getUrl() + "/sendSMS";
                    fullUrl += "?" ;
                    fullUrl += "access_token" + "=" + smsAccessInformation.getAccessToken() + "&" ;
                    fullUrl += "large_yn" + "=" + "N" + "&" ;
                    fullUrl += "enc_yn" + "=" + "N" + "&" ;
                    fullUrl += "user_id" + "=" + smsAccessInformation.getUserId() + "&" ;
                    fullUrl += "reserved" + "=" + "N" + "&" ;
                    fullUrl += "send_no" + "=" + smsAccessInformation.getSendNo() + "&" ;
                    fullUrl += "recv_no" + "=" + recvNo + "&" ;
                    fullUrl += "msg" + "=" + target + "&" ;
                    fullUrl += "advertise" + "=" + "N" ;

                    LOGGER.debug("SEND_SMS : url={}", fullUrl);
                    responseMap = restTemplateUtil.restTemplate(fullUrl, HttpMethod.POST, null, null, "SEND_SMS", smsAccessInformation, Map.class);

                    if( responseMap == null ) {
                        LOGGER.debug("SEND_SMS : responsMap is null!");
                        return makeErrSmsApiResponse() ;
                    }
                    else if (!"01".equals((String) responseMap.get("return_code"))) {
                        break ;
                    }

                    concatCount++ ;
                }

                if(  responseMap == null ) {
                    LOGGER.debug("SEND_SMS : responsMap is null!");
                    return makeErrSmsApiResponse() ;
                }
                else {
                    SmsApiResponse smsApiResponse = new SmsApiResponse();
                    smsApiResponse.setReturnCode((String) responseMap.get("return_code"));
                    smsApiResponse.setReturnMsg((String) responseMap.get("return_msg"));

                    smsApiResponse.setErrorCode((String) responseMap.get("error_code"));
                    smsApiResponse.setErrorMsg((String) responseMap.get("error_msg"));
                            
                    return smsApiResponse;
                }
        } catch(UnsupportedEncodingException e) {
            LOGGER.debug("SEND_SMS :UnsupportedEncodingException :  msg={}", e);
            return makeErrSmsApiResponse() ;
        } catch (Exception e) {
            LOGGER.debug("SEND_SMS :Exception :  msg={}", e);
            return makeErrSmsApiResponse() ;
        }
    }

    public SmsApiResponse makeErrSmsApiResponse() {
        SmsApiResponse smsApiResponse = new SmsApiResponse();
        smsApiResponse.setReturnCode(SMS_RETURN_CD_FAIL);
        smsApiResponse.setReturnMsg(SMS_RETURN_MSG_FAIL);

        smsApiResponse.setErrorCode(SMS_ERROR_CD);
        smsApiResponse.setErrorMsg(SMS_ERROR_MSG);
        return smsApiResponse ;
    }
}
