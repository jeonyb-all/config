package com.adtcaps.tsop.onm.api.dashboard.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.adtcaps.tsop.onm.api.alarm.mapper.OomOnmAlarmCurrentStatusMapper;
import com.adtcaps.tsop.onm.api.alarm.mapper.OomOnmAlarmEventMapper;
import com.adtcaps.tsop.onm.api.dashboard.domain.DashboardAlarmCountResultDto;
import com.adtcaps.tsop.onm.api.dashboard.domain.DashboardAlarmGraphResultDto;
import com.adtcaps.tsop.onm.api.dashboard.domain.DashboardAlarmGridResultDto;
import com.adtcaps.tsop.onm.api.dashboard.domain.DashboardHttpErrResultDto;
import com.adtcaps.tsop.onm.api.dashboard.domain.DashboardHttpResponseResultDto;
import com.adtcaps.tsop.onm.api.dashboard.domain.DashboardRequestDto;
import com.adtcaps.tsop.onm.api.dashboard.domain.DashboardTopoResourceResultDto;
import com.adtcaps.tsop.onm.api.dashboard.domain.DashboardTrafficResultDto;
import com.adtcaps.tsop.onm.api.dashboard.mapper.OomEventhubResourceMetricHistMapper;
import com.adtcaps.tsop.onm.api.dashboard.mapper.OomTenantTopologyResourceMapper;
import com.adtcaps.tsop.onm.api.dashboard.mapper.OomWebappResourceMetricHistMapper;
import com.adtcaps.tsop.onm.api.dashboard.service.DashboardService;
import com.adtcaps.tsop.onm.api.tenant.mapper.OomTenantResourceDetailMapper;

/**
 * 
 * <ul>
 * <li>업무 그룹명 : tsop-onm-api</li>
 * <li>서브 업무명 : com.adtcaps.tsop.onm.api.dashboard.service.impl</li>
 * <li>설  명 : DashboardServiceImpl.java</li>
 * <li>작성일 : 2021. 1. 31.</li>
 * <li>작성자 : song</li>
 * </ul>
 */
@Service
public class DashboardServiceImpl implements DashboardService{
	
	@Autowired
	OomTenantTopologyResourceMapper oomTenantTopologyResourceMapper;
	
	@Autowired
	OomOnmAlarmEventMapper oomOnmAlarmEventMapper;
	
	@Autowired
	OomOnmAlarmCurrentStatusMapper oomOnmAlarmCurrentStatusMapper;
	
	@Autowired
	OomEventhubResourceMetricHistMapper oomEventhubResourceMetricHistMapper;

	@Autowired
	OomWebappResourceMetricHistMapper oomWebappResourceMetricHistMapper;
	
	@Autowired
	OomTenantResourceDetailMapper oomTenantResourceDetailMapper;
	
	
	@Override
	public List<DashboardTopoResourceResultDto> listDashboardTopoResource(DashboardRequestDto reqDashboardDto) throws Exception {
		List<DashboardTopoResourceResultDto> dashboardTopoResourceList = null;
		try {
			dashboardTopoResourceList = oomTenantTopologyResourceMapper.listDashboardTopoResource(reqDashboardDto);
		} catch (Exception e) {
			throw e;
		}
		return dashboardTopoResourceList;
	}

	@Override
	public List<DashboardAlarmGraphResultDto> listDashboardAlarmGraph(DashboardRequestDto reqDashboardDto) throws Exception {
		List<DashboardAlarmGraphResultDto> dashboardAlarmGraphResultDto = null;
		try {
			dashboardAlarmGraphResultDto = oomOnmAlarmEventMapper.listDashboardAlarmGraph(reqDashboardDto);
		} catch (Exception e) {
			throw e;
		}
		return dashboardAlarmGraphResultDto;
	}

	@Override
	public List<DashboardAlarmGridResultDto> listDashboardAlarmGrid(DashboardRequestDto reqDashboardDto) throws Exception {
		List<DashboardAlarmGridResultDto> dashboardAlarmListResultDto = null;
		try {
			dashboardAlarmListResultDto = oomOnmAlarmEventMapper.listDashboardAlarmGrid(reqDashboardDto);
		} catch (Exception e) {
			throw e;
		}
		return dashboardAlarmListResultDto;
	}

	@Override
	public List<DashboardAlarmCountResultDto> listDashboardTenantAlarm(DashboardRequestDto reqDashboardDto) throws Exception {
		List<DashboardAlarmCountResultDto> dashboardAlarmCountResultList = null;
		try {
			dashboardAlarmCountResultList = oomOnmAlarmCurrentStatusMapper.listDashboardTenantAlarm(reqDashboardDto);
		} catch (Exception e) {
			throw e;
		}
		return dashboardAlarmCountResultList;
	}

	@Override
	public List<DashboardAlarmCountResultDto> listDashboardResourceAlarm(DashboardRequestDto reqDashboardDto) throws Exception {
		List<DashboardAlarmCountResultDto> dashboardAlarmCountResultList = null;
		try {
			dashboardAlarmCountResultList = oomOnmAlarmCurrentStatusMapper.listDashboardResourceAlarm(reqDashboardDto);
		} catch (Exception e) {
			throw e;
		}
		return dashboardAlarmCountResultList;
	}

	@Override
	public List<DashboardAlarmCountResultDto> listDashboardBuildingAlarm(DashboardRequestDto reqDashboardDto) throws Exception {
		List<DashboardAlarmCountResultDto> dashboardAlarmCountResultList = null;
		try {
			dashboardAlarmCountResultList = oomOnmAlarmCurrentStatusMapper.listDashboardBuildingAlarm(reqDashboardDto);
		} catch (Exception e) {
			throw e;
		}
		return dashboardAlarmCountResultList;
	}

	@Override
	public List<DashboardAlarmCountResultDto> listDashboardServiceAlarm(DashboardRequestDto reqDashboardDto) throws Exception {
		List<DashboardAlarmCountResultDto> dashboardAlarmCountResultList = null;
		try {
			dashboardAlarmCountResultList = oomOnmAlarmCurrentStatusMapper.listDashboardServiceAlarm(reqDashboardDto);
		} catch (Exception e) {
			throw e;
		}
		return dashboardAlarmCountResultList;
	}

	@Override
	public List<DashboardTrafficResultDto> listDashboardTrafficResult(DashboardRequestDto reqDashboardDto)	throws Exception {
		List<DashboardTrafficResultDto> dashboardTrafficResultList = null;
		try {
			dashboardTrafficResultList = oomEventhubResourceMetricHistMapper.listDashboardTrafficResult(reqDashboardDto);
		} catch (Exception e) {
			throw e;
		}
		return dashboardTrafficResultList;
	}

	@Override
	public List<DashboardHttpErrResultDto> listDashboardHttpErrResult(DashboardRequestDto reqDashboardDto)	throws Exception {
		List<DashboardHttpErrResultDto> dashboardHttpErrResultList = null;
		try {
			dashboardHttpErrResultList = oomWebappResourceMetricHistMapper.listDashboardHttpErrResult(reqDashboardDto);
		} catch (Exception e) {
			throw e;
		}
		return dashboardHttpErrResultList;
	}

	@Override
	public List<DashboardHttpResponseResultDto> listDashboardHttpResponseResult(DashboardRequestDto reqDashboardDto) throws Exception {
		List<DashboardHttpResponseResultDto> dashboardHttpResponseResultDto = null;
		try {
			dashboardHttpResponseResultDto = oomWebappResourceMetricHistMapper.listDashboardHttpResponseResult(reqDashboardDto);
		} catch (Exception e) {
			throw e;
		}
		return dashboardHttpResponseResultDto;
	}

	@Override
	public int updateOomAlarmEventAckYn(DashboardRequestDto reqDashboardDto) throws Exception {
		int updateCount = 0;
		try {
			updateCount = oomOnmAlarmEventMapper.updateOomAlarmEventAckYn(reqDashboardDto);
		} catch (Exception e) {
			throw e;
		}
		return updateCount;
	}

	@Override
	public int updateOomAlarmMaskYn(DashboardRequestDto reqDashboardDto) throws Exception {
		int updateCount = 0;
		try {
			updateCount = oomOnmAlarmEventMapper.updateOomAlarmMaskYn(reqDashboardDto);
		} catch (Exception e) {
			throw e;
		}
		return updateCount;
	}

	@Override
	public int getCountTenantResourceDetail(DashboardRequestDto reqDashboardDto) throws Exception {
		int getCount = 0;
		try {
			getCount = oomTenantResourceDetailMapper.getCountTenantResourceDetail(reqDashboardDto);
		} catch (Exception e) {
			throw e;
		}
		return getCount;
	}
	

}
