package com.adtcaps.tsop.onm.api.file.controller;

import java.io.File;
import java.io.FileInputStream;
import java.io.OutputStream;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.io.FileUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.util.CollectionUtils;
import org.springframework.util.FileCopyUtils;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.MultipartHttpServletRequest;

import com.adtcaps.tsop.onm.api.config.AzureBlobConfig;
import com.adtcaps.tsop.onm.api.domain.OomAttachFileDto;
import com.adtcaps.tsop.onm.api.file.domain.BlobRequestDto;
import com.adtcaps.tsop.onm.api.file.domain.BlobResultDto;
import com.adtcaps.tsop.onm.api.file.service.FileService;
import com.adtcaps.tsop.onm.api.helper.constant.Const;
import com.adtcaps.tsop.onm.api.helper.domain.ResultDto;
import com.adtcaps.tsop.onm.api.helper.service.HelperService;
import com.adtcaps.tsop.onm.api.helper.util.CommonObjectUtil;

import lombok.extern.slf4j.Slf4j;

/**
 * 
 * <ul>
 * <li>업무 그룹명 : tsop-portal-api</li>
 * <li>서브 업무명 : com.adtcaps.tsop.portal.api.helper.controller</li>
 * <li>설  명 : FileController.java</li>
 * <li>작성일 : 2020. 11. 19.</li>
 * <li>작성자 : jeonyb4</li>
 * </ul>
 */
@Slf4j
@RestController
@RequestMapping("/api/files")
public class FileController {
	
	private final String ERR_MSG_NULL_UPLOAD_FILES = "등록할 첨부파일이 없습니다.";
	private final String ERR_MSG_NULL_LOCAL_FILE_PATH = "로컬(WAS) 파일경로가 없습니다.";
	private final String ERR_MSG_NULL_ATTACH_FILE_INFO = "첨부파일 정보가 없습니다.";
	
	private final String ERR_MSG_CANNOT_UPLOAD_CONTENT_TYPE = "해당 Content Type은 업로드 할 수 없습니다.";
	
	private final String ERR_MSG_UPLOAD_FAIL = "upload에 실패하였습니다.";
	private final String ERR_MSG_DOWNLOAD_FAIL = "첨부파일 Download에 실패하였습니다.";
	
	@Autowired
	private AzureBlobConfig azureBlobConfig;
	
	@Autowired
	private HelperService helperService;
	
	@Autowired
	private FileService fileService;
	
	
	/**
	 * 
	 * multipartUpload
	 *
	 * @param request
	 * @return ResponseEntity
	 * @throws Exception 
	 */
	@SuppressWarnings("rawtypes")
	@PostMapping(value="/multipart-upload", produces="application/json; charset=UTF-8")
	public ResponseEntity multipartUpload(MultipartHttpServletRequest request) throws Exception {
		
		ResponseEntity<ResultDto> resEntity = null;
		String returnString = "";
    	
		List<MultipartFile> multipartFileList = request.getFiles("file");
		if (CollectionUtils.isEmpty(multipartFileList)) {
			log.error(">>>>>> multipartFileList ERROR:{}", ERR_MSG_NULL_UPLOAD_FILES);
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_UPLOAD_FILES));
			return resEntity;
		}
		
		List<BlobRequestDto> blobRequestDtoList = new ArrayList<BlobRequestDto>();
		
		String uploadTempBasePath = azureBlobConfig.getAzureBlobInfo().getUploadTempBasePath();
		String currentMilliSeconds = helperService.readCurrentMilliSeconds();
		
		for (MultipartFile multipartFile : multipartFileList) {
			String fileName = multipartFile.getOriginalFilename();
			String contentType = StringUtils.defaultString(multipartFile.getContentType());
			log.info(">>>>>> contentType:{}", contentType);
			if (!Const.Definition.ACCEPT_CONTENT_TYPE.GIF.equals(contentType) &&
					!Const.Definition.ACCEPT_CONTENT_TYPE.PNG.equals(contentType) &&
					!Const.Definition.ACCEPT_CONTENT_TYPE.JPG.equals(contentType) &&
					!Const.Definition.ACCEPT_CONTENT_TYPE.PDF.equals(contentType) &&
					!Const.Definition.ACCEPT_CONTENT_TYPE.XLS.equals(contentType) &&
					!Const.Definition.ACCEPT_CONTENT_TYPE.XLS1.equals(contentType) &&
					!Const.Definition.ACCEPT_CONTENT_TYPE.XLS2.equals(contentType) &&
					!Const.Definition.ACCEPT_CONTENT_TYPE.XLS3.equals(contentType) &&
					!Const.Definition.ACCEPT_CONTENT_TYPE.PPT.equals(contentType) &&
					!Const.Definition.ACCEPT_CONTENT_TYPE.DOC.equals(contentType) &&
					!Const.Definition.ACCEPT_CONTENT_TYPE.PPTX.equals(contentType) &&
					!Const.Definition.ACCEPT_CONTENT_TYPE.XLSX.equals(contentType) &&
					!Const.Definition.ACCEPT_CONTENT_TYPE.DOCX.equals(contentType) &&
					!Const.Definition.ACCEPT_CONTENT_TYPE.ZIP1.equals(contentType) &&
					!Const.Definition.ACCEPT_CONTENT_TYPE.ZIP2.equals(contentType) &&
					!Const.Definition.ACCEPT_CONTENT_TYPE.ZIP3.equals(contentType) &&
					!Const.Definition.ACCEPT_CONTENT_TYPE.ZIP4.equals(contentType)) {
				returnString = Const.Common.RESULT_CODE.FAIL;
    			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_CANNOT_UPLOAD_CONTENT_TYPE, blobRequestDtoList));
    			return resEntity;
			}
            long fileSize = CommonObjectUtil.defaultNumber(multipartFile.getSize());
            
            StringBuilder uploadPathBuilder = new StringBuilder();
            uploadPathBuilder.append(uploadTempBasePath);
            uploadPathBuilder.append("/");
            uploadPathBuilder.append(currentMilliSeconds);
            
            File uploadTempDirectory = new File(uploadPathBuilder.toString());
            if (!uploadTempDirectory.isDirectory()) {
            	FileUtils.forceMkdir(uploadTempDirectory);
            }
            
			StringBuilder localFilePathBuilder = new StringBuilder();
            localFilePathBuilder.append(uploadPathBuilder.toString());
            localFilePathBuilder.append("/");
            localFilePathBuilder.append(fileName);
            
            String uploadPath = request.getSession().getServletContext().getRealPath("upload");
            log.info("실제 파일 업로드 경로 : "+uploadPath);
            
            if(fileSize > 0) {            
            	multipartFile.transferTo(new File(localFilePathBuilder.toString()));
            	
            	BlobRequestDto blobRequestDto = new BlobRequestDto();
                blobRequestDto.setLocalFilePath(localFilePathBuilder.toString());
                blobRequestDtoList.add(blobRequestDto);
            }
		}
		
		if (CollectionUtils.isEmpty(blobRequestDtoList)) {
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_UPLOAD_FAIL, blobRequestDtoList));
		} else {
			returnString = Const.Common.RESULT_CODE.SUCCESS;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, "", blobRequestDtoList));
		}
    	
    	return resEntity;
	}
	
	/**
	 * 
	 * tempFileDelete
	 *
	 * @param blobRequestDto
	 * @return ResponseEntity
	 * @throws Exception 
	 */
	@SuppressWarnings("rawtypes")
	@PostMapping(value="/tempfile-delete", produces="application/json; charset=UTF-8")
	public ResponseEntity tempFileDelete(@RequestBody BlobRequestDto blobRequestDto) throws Exception {
		
		ResponseEntity<ResultDto> resEntity = null;
		String returnString = "";
    	
		String localFilePath = StringUtils.defaultString(blobRequestDto.getLocalFilePath());
		if ("".equals(localFilePath)) {
			log.error(">>>>>> localFilePath ERROR:{}", ERR_MSG_NULL_LOCAL_FILE_PATH);
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_LOCAL_FILE_PATH));
			return resEntity;
		}
		
		File deleteLocalFile = new File(localFilePath);
		if (deleteLocalFile.exists()) {
			FileUtils.forceDelete(deleteLocalFile);
		}
		
		int lastSlashIndexVal = StringUtils.lastIndexOf(localFilePath, "/");
		String tempDirPath = StringUtils.substring(localFilePath, 0, lastSlashIndexVal);
		
		File tempDirectory = new File(tempDirPath);
		if (tempDirectory.isDirectory()) {
			File[] tempFileList = tempDirectory.listFiles();
			if (tempFileList.length < 1) {
				// Local Temp Directory 삭제...
				FileUtils.deleteDirectory(tempDirectory);
			}
		}
		
		returnString = Const.Common.RESULT_CODE.SUCCESS;
		resEntity = ResponseEntity.ok(new ResultDto(returnString, "", ""));
    	
    	return resEntity;
	}
	
	/**
	 * 
	 * downloadAttachFile
	 *
	 * @param attachFileNum
	 * @param response
	 * @throws Exception void
	 */
	@GetMapping(value="/downloads/{attachFileNum}")
    public void downloadAttachFile(@PathVariable("attachFileNum") int attachFileNum, HttpServletRequest request, HttpServletResponse response) throws Exception {
		
		OomAttachFileDto reqOomAttachFileDto = new OomAttachFileDto();
		reqOomAttachFileDto.setAttachFileNum(attachFileNum);
		OomAttachFileDto rsltOomAttachFileDto = fileService.readAttachFile(reqOomAttachFileDto);
		if (rsltOomAttachFileDto == null) {
			throw new Exception(ERR_MSG_NULL_ATTACH_FILE_INFO);
		}
		
		String containerName = Const.Definition.BLOB_CONTAINER.FILE;
		String attachFilePathName = rsltOomAttachFileDto.getAttachFilePathName();
		String attachFileId = rsltOomAttachFileDto.getAttachFileId();
		String attachFileName = rsltOomAttachFileDto.getAttachFileName();
		
		String downloadTempBasePath = azureBlobConfig.getAzureBlobInfo().getDownloadTempBasePath();
		String currentMilliSeconds = helperService.readCurrentMilliSeconds();
		
		StringBuilder downloadPathBuilder = new StringBuilder();
		downloadPathBuilder.append(downloadTempBasePath);
		downloadPathBuilder.append("/");
		downloadPathBuilder.append(currentMilliSeconds);
		
		StringBuilder localFilePathBuilder = new StringBuilder();
		localFilePathBuilder.append(downloadPathBuilder.toString());
		localFilePathBuilder.append("/");
		localFilePathBuilder.append(attachFileName);
		
		// Azure Download...
		BlobRequestDto blobRequestDto = new BlobRequestDto();
		blobRequestDto.setContainerName(containerName);
		blobRequestDto.setBlobFilePath(attachFilePathName);
		blobRequestDto.setBlobFileName(attachFileId);
		blobRequestDto.setLocalFilePath(localFilePathBuilder.toString());
		
		BlobResultDto blobResultDto = fileService.downloadFile(blobRequestDto);
		if (blobResultDto == null) {
			throw new Exception(ERR_MSG_DOWNLOAD_FAIL);
		}
		String localFilePath = blobResultDto.getLocalFilePath();
		String contentType = blobResultDto.getContentType();
		
		File file = new File(localFilePath);
		String fileName = null;
		String userAgent = request.getHeader("User-Agent");
        if(userAgent.indexOf("MSIE") > -1 || userAgent.indexOf("Trident") > -1){
            fileName = URLEncoder.encode(file.getName(), "utf-8").replaceAll("\\+", "%20");;
        }else if(userAgent.indexOf("Chrome") > -1) {
        	StringBuffer sb = new StringBuffer();
        	for(int i=0; i<file.getName().length(); i++) {
        		char c = file.getName().charAt(i);
        		if(c > '~') {
        			sb.append(URLEncoder.encode(""+c, "UTF-8"));
        		}else {
        			sb.append(c);
        		}
        	}
        	fileName = sb.toString();
        }else {
        	fileName = new String(file.getName().getBytes("utf-8"));
        }
		
		// WAS File Download...
        response.setHeader("Content-Disposition", "attachment;filename=\"" + fileName + "\";");
        response.setContentType("application/octet-stream");
        response.setHeader("Content-transfer-Encoding", "binary");
        response.setHeader("mediaType", contentType);
        OutputStream out = null;
        out = response.getOutputStream();
        FileInputStream fis = new FileInputStream(file);
        FileCopyUtils.copy(fis, out);
     
        out.flush();
		
		// Local Temp Directory 삭제...
		File uploadTempDirectory = new File(downloadPathBuilder.toString());
		if (uploadTempDirectory.isDirectory()) {
			FileUtils.deleteDirectory(uploadTempDirectory);
		}
    }
	

}
