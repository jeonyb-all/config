package com.adtcaps.tsop.onm.api.threshold.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.util.CollectionUtils;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.adtcaps.tsop.onm.api.authentication.domain.JwtAuthResultDto;
import com.adtcaps.tsop.onm.api.domain.OomTenantResourceMonitoringAlarmConditionDto;
import com.adtcaps.tsop.onm.api.domain.OomTenantResourceMonitoringThresholdDto;
import com.adtcaps.tsop.onm.api.domain.OomUserRoleAuthorityDetailDto;
import com.adtcaps.tsop.onm.api.helper.constant.Const;
import com.adtcaps.tsop.onm.api.helper.domain.ResultDto;
import com.adtcaps.tsop.onm.api.helper.util.CommonObjectUtil;
import com.adtcaps.tsop.onm.api.helper.util.PageUtil;
import com.adtcaps.tsop.onm.api.resource.service.ResourceMonitoringAlarmService;
import com.adtcaps.tsop.onm.api.threshold.domain.ThresholdDetailResultDto;
import com.adtcaps.tsop.onm.api.threshold.domain.ThresholdGridRequestDto;
import com.adtcaps.tsop.onm.api.threshold.domain.ThresholdGridResultDto;
import com.adtcaps.tsop.onm.api.threshold.service.ThresholdService;
import com.adtcaps.tsop.onm.api.user.domain.UserRoleMenuAuthorityRequestDto;
import com.adtcaps.tsop.onm.api.user.service.UserRoleService;

import lombok.extern.slf4j.Slf4j;

/**
 * 
 * <ul>
 * <li>업무 그룹명 : tsop-onm-api</li>
 * <li>서브 업무명 : com.adtcaps.tsop.onm.api.threshold.controller</li>
 * <li>설  명 : ThresholdController.java</li>
 * <li>작성일 : 2021. 1. 17.</li>
 * <li>작성자 : jeonyb4</li>
 * </ul>
 */
@Slf4j
@RestController
@RequestMapping("/api/thresholds")
public class ThresholdController {
	
	private final String MENU_ID = "ONM0013";
	
	private final String ERR_MSG_NULL_LOGIN_USER_ID = "로그인 사용자ID가 없습니다.";
	private final String ERR_MSG_NULL_MGR_YN = "관리자여부가 없습니다.";
	private final String ERR_MSG_NULL_PAGE_NUMBER = "페이지 번호가 없습니다.";
	private final String ERR_MSG_NULL_TENANT_ID = "테넌트ID가 없습니다.";
	private final String ERR_MSG_NULL_RESOURCE_CATEGORY_CD = "자원분류코드가 없습니다.";
	private final String ERR_MSG_NULL_ALARM_CD = "알람코드가 없습니다.";
	private final String ERR_MSG_NULL_RESOURCE_ID = "자원ID가 없습니다.";
	
	private final String ERR_MSG_NULL_STANDARD_VAL = "Critical, Major, Minor 등급기준값이 하나 이상은 있어야 합니다.";
	private final String ERR_MSG_ALREADY_EXIST_THRESHOLD = "해당 임계치 정보는 이미 등록된 정보가 있습니다.";
	private final String ERR_MSG_EXIST_MONITORING_ALARM = "해당 임계치 정보에 대한 감시알람이 등록되어 있으므로 삭제할 수 없습니다.";
	
	private final String ERR_MSG_NO_AUTH = "권한이 없는 사용자 입니다.";
	private final String ERR_MSG_NULL_SEARCH_RESULT_LIST = "조회 결과가 없습니다.";
	private final String ERR_MSG_CREATE_FAIL = "등록에 실패하였습니다.";
	private final String ERR_MSG_READ_FAIL = "조회에 실패하였습니다.";
	private final String ERR_MSG_UPDATE_FAIL = "수정에 실패하였습니다.";
	private final String ERR_MSG_DELETE_FAIL = "삭제에 실패하였습니다.";
	
	@Autowired
	private ThresholdService thresholdService;
	
	@Autowired
	private ResourceMonitoringAlarmService resourceMonitoringAlarmService;
	
	@Autowired
	private UserRoleService userRoleService;
	
	/**
	 * 
	 * listPageThreshold
	 *
	 * @param thresholdGridRequestDto
	 * @return ResponseEntity
	 */
	@SuppressWarnings("rawtypes")
    @GetMapping(value="", produces="application/json; charset=UTF-8")
    public ResponseEntity listPageThreshold(ThresholdGridRequestDto thresholdGridRequestDto) throws Exception {
        
    	ResponseEntity<ResultDto> resEntity = null;
		String returnString = "";
    	
		int pageNumber = thresholdGridRequestDto.getPageNumber();
		if (pageNumber < 1) {
			log.error(">>>>>> pageNumber ERROR:{}", ERR_MSG_NULL_PAGE_NUMBER);
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_PAGE_NUMBER));
			return resEntity;
		}
		// 임계치 목록 조회....
		Map<String, Object> thresholdGridResultDtoListMap = new HashMap<String, Object>();
		List<ThresholdGridResultDto> thresholdGridResultDtoList = thresholdService.listPageThreshold(thresholdGridRequestDto);
		if (CollectionUtils.isEmpty(thresholdGridResultDtoList)) {
			returnString = Const.Common.RESULT_CODE.SUCCESS;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_SEARCH_RESULT_LIST, thresholdGridResultDtoList));
		} else {
			returnString = Const.Common.RESULT_CODE.SUCCESS;
			thresholdGridResultDtoListMap.put(Const.Definition.PAGE.PAGER, PageUtil.getPageInfo(thresholdGridResultDtoList));
			thresholdGridResultDtoListMap.put(Const.Definition.PAGE.LISTS, thresholdGridResultDtoList);
			resEntity = ResponseEntity.ok(new ResultDto(returnString, "", thresholdGridResultDtoListMap));
		}
    	
    	return resEntity;
    }
	
	/**
	 * 
	 * createThreshold
	 *
	 * @param authResultDto
	 * @param reqOomTenantResourceMonitoringThresholdDto
	 * @return ResponseEntity
	 */
	@SuppressWarnings("rawtypes")
    @PostMapping(value="", produces="application/json; charset=UTF-8")
    public ResponseEntity createThreshold(@AuthenticationPrincipal JwtAuthResultDto authResultDto, 
    		@RequestBody OomTenantResourceMonitoringThresholdDto reqOomTenantResourceMonitoringThresholdDto) throws Exception {
        
    	ResponseEntity<ResultDto> resEntity = null;
		String returnString = "";
    	
		String loginUserId = StringUtils.defaultString(authResultDto.getUserId());
		if ("".equals(loginUserId)) {
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_LOGIN_USER_ID));
			return resEntity;
		}
		String mgrYn = StringUtils.defaultString(authResultDto.getMgrYn());
		if ("".equals(mgrYn)) {
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_MGR_YN));
			return resEntity;
		}
		//String loginUserId = "tsop-admin"; // 이후 세션에서 얻어올 값...
		
		if (!"Y".equals(mgrYn)) {
			String authorityTypeCd = "";
			UserRoleMenuAuthorityRequestDto userRoleMenuAuthorityRequestDto = new UserRoleMenuAuthorityRequestDto();
			userRoleMenuAuthorityRequestDto.setUserId(loginUserId);
			userRoleMenuAuthorityRequestDto.setMenuId(MENU_ID);
			OomUserRoleAuthorityDetailDto rsltOomUserRoleAuthorityDetailDto = userRoleService.readMenuAuthority(userRoleMenuAuthorityRequestDto);
			if (rsltOomUserRoleAuthorityDetailDto != null) {
				authorityTypeCd = StringUtils.defaultString(rsltOomUserRoleAuthorityDetailDto.getAuthorityTypeCd());
			}
			if (!"W".equals(authorityTypeCd)) {
				returnString = Const.Common.RESULT_CODE.FAIL;
				resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NO_AUTH));
				return resEntity;
			}
		}
		
		String tenantId = StringUtils.defaultString(reqOomTenantResourceMonitoringThresholdDto.getTenantId());
		if ("".equals(tenantId)) {
			log.error(">>>>>> tenantId ERROR:{}", ERR_MSG_NULL_TENANT_ID);
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_TENANT_ID));
			return resEntity;
		}
		String onmResourceCategoryCd = StringUtils.defaultString(reqOomTenantResourceMonitoringThresholdDto.getOnmResourceCategoryCd());
		if ("".equals(onmResourceCategoryCd)) {
			log.error(">>>>>> onmResourceCategoryCd ERROR:{}", ERR_MSG_NULL_RESOURCE_CATEGORY_CD);
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_RESOURCE_CATEGORY_CD));
			return resEntity;
		}
		String onmAlarmCd = StringUtils.defaultString(reqOomTenantResourceMonitoringThresholdDto.getOnmAlarmCd());
		if ("".equals(onmAlarmCd)) {
			log.error(">>>>>> onmAlarmCd ERROR:{}", ERR_MSG_NULL_ALARM_CD);
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_ALARM_CD));
			return resEntity;
		}
		String onmResourceId = StringUtils.defaultString(reqOomTenantResourceMonitoringThresholdDto.getOnmResourceId());
		if ("".equals(onmResourceId)) {
			log.error(">>>>>> onmResourceId ERROR:{}", ERR_MSG_NULL_RESOURCE_ID);
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_RESOURCE_ID));
			return resEntity;
		}
		int criticalgStandardVal = CommonObjectUtil.defaultNumber(reqOomTenantResourceMonitoringThresholdDto.getCriticalgStandardVal());
		int majorgStandardVal = CommonObjectUtil.defaultNumber(reqOomTenantResourceMonitoringThresholdDto.getMajorgStandardVal());
		int minorgStandardVal = CommonObjectUtil.defaultNumber(reqOomTenantResourceMonitoringThresholdDto.getMinorgStandardVal());
		if (criticalgStandardVal < 1 && majorgStandardVal < 1 && minorgStandardVal < 1) {
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_STANDARD_VAL));
			return resEntity;
		}
		
		reqOomTenantResourceMonitoringThresholdDto.setAuditId(loginUserId);
		reqOomTenantResourceMonitoringThresholdDto.setRegisterId(loginUserId);
		
		// 중복 등록 체크...
		ThresholdDetailResultDto thresholdDetailResultDto = thresholdService.readThreshold(reqOomTenantResourceMonitoringThresholdDto);
		if (thresholdDetailResultDto != null) {
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_ALREADY_EXIST_THRESHOLD, thresholdDetailResultDto));
			return resEntity;
		}
		
		// 임계치 등록...
		int affectRowCount = thresholdService.createThreshold(reqOomTenantResourceMonitoringThresholdDto);
		if (affectRowCount < 1) {
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_CREATE_FAIL, affectRowCount));
		} else {
			returnString = Const.Common.RESULT_CODE.SUCCESS;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, "", affectRowCount));
		}
    	
    	return resEntity;
    }
	
	/**
	 * 
	 * readThreshold
	 *
	 * @param onmAlarmTypeCd
	 * @param reqOomTenantResourceMonitoringThresholdDto
	 * @return ResponseEntity
	 */
	@SuppressWarnings("rawtypes")
    @GetMapping(value="/{onmAlarmCd}", produces="application/json; charset=UTF-8")
    public ResponseEntity readThreshold(@PathVariable("onmAlarmCd") String onmAlarmCd, OomTenantResourceMonitoringThresholdDto reqOomTenantResourceMonitoringThresholdDto) throws Exception {
        
    	ResponseEntity<ResultDto> resEntity = null;
		String returnString = "";
    	
		String tenantId = StringUtils.defaultString(reqOomTenantResourceMonitoringThresholdDto.getTenantId());
		if ("".equals(tenantId)) {
			log.error(">>>>>> tenantId ERROR:{}", ERR_MSG_NULL_TENANT_ID);
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_TENANT_ID));
			return resEntity;
		}
		String onmResourceId = StringUtils.defaultString(reqOomTenantResourceMonitoringThresholdDto.getOnmResourceId());
		if ("".equals(onmResourceId)) {
			log.error(">>>>>> onmResourceId ERROR:{}", ERR_MSG_NULL_RESOURCE_ID);
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_RESOURCE_ID));
			return resEntity;
		}
		
		reqOomTenantResourceMonitoringThresholdDto.setOnmAlarmCd(onmAlarmCd);
		
		ThresholdDetailResultDto thresholdDetailResultDto = thresholdService.readThreshold(reqOomTenantResourceMonitoringThresholdDto);
		if (thresholdDetailResultDto == null) {
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_READ_FAIL, thresholdDetailResultDto));
		} else {
			returnString = Const.Common.RESULT_CODE.SUCCESS;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, "", thresholdDetailResultDto));
		}
    	
    	return resEntity;
    }
	
	/**
	 * 
	 * updateThreshold
	 *
	 * @param authResultDto
	 * @param onmAlarmTypeCd
	 * @param reqOomTenantResourceMonitoringThresholdDto
	 * @return ResponseEntity
	 */
	@SuppressWarnings("rawtypes")
    @PutMapping(value="/{onmAlarmCd}", produces="application/json; charset=UTF-8")
    public ResponseEntity updateThreshold(@AuthenticationPrincipal JwtAuthResultDto authResultDto, 
    		@PathVariable("onmAlarmCd") String onmAlarmCd, @RequestBody OomTenantResourceMonitoringThresholdDto reqOomTenantResourceMonitoringThresholdDto) throws Exception {
        
    	ResponseEntity<ResultDto> resEntity = null;
		String returnString = "";
    	
		String loginUserId = StringUtils.defaultString(authResultDto.getUserId());
		if ("".equals(loginUserId)) {
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_LOGIN_USER_ID));
			return resEntity;
		}
		String mgrYn = StringUtils.defaultString(authResultDto.getMgrYn());
		if ("".equals(mgrYn)) {
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_MGR_YN));
			return resEntity;
		}
		//String loginUserId = "tsop-admin"; // 이후 세션에서 얻어올 값...
		
		if (!"Y".equals(mgrYn)) {
			String authorityTypeCd = "";
			UserRoleMenuAuthorityRequestDto userRoleMenuAuthorityRequestDto = new UserRoleMenuAuthorityRequestDto();
			userRoleMenuAuthorityRequestDto.setUserId(loginUserId);
			userRoleMenuAuthorityRequestDto.setMenuId(MENU_ID);
			OomUserRoleAuthorityDetailDto rsltOomUserRoleAuthorityDetailDto = userRoleService.readMenuAuthority(userRoleMenuAuthorityRequestDto);
			if (rsltOomUserRoleAuthorityDetailDto != null) {
				authorityTypeCd = StringUtils.defaultString(rsltOomUserRoleAuthorityDetailDto.getAuthorityTypeCd());
			}
			if (!"W".equals(authorityTypeCd)) {
				returnString = Const.Common.RESULT_CODE.FAIL;
				resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NO_AUTH));
				return resEntity;
			}
		}
		
		String tenantId = StringUtils.defaultString(reqOomTenantResourceMonitoringThresholdDto.getTenantId());
		if ("".equals(tenantId)) {
			log.error(">>>>>> tenantId ERROR:{}", ERR_MSG_NULL_TENANT_ID);
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_TENANT_ID));
			return resEntity;
		}
		String onmResourceId = StringUtils.defaultString(reqOomTenantResourceMonitoringThresholdDto.getOnmResourceId());
		if ("".equals(onmResourceId)) {
			log.error(">>>>>> onmResourceId ERROR:{}", ERR_MSG_NULL_RESOURCE_ID);
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_RESOURCE_ID));
			return resEntity;
		}
		int criticalgStandardVal = CommonObjectUtil.defaultNumber(reqOomTenantResourceMonitoringThresholdDto.getCriticalgStandardVal());
		int majorgStandardVal = CommonObjectUtil.defaultNumber(reqOomTenantResourceMonitoringThresholdDto.getMajorgStandardVal());
		int minorgStandardVal = CommonObjectUtil.defaultNumber(reqOomTenantResourceMonitoringThresholdDto.getMinorgStandardVal());
		if (criticalgStandardVal < 1 && majorgStandardVal < 1 && minorgStandardVal < 1) {
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_STANDARD_VAL));
			return resEntity;
		}
		
		reqOomTenantResourceMonitoringThresholdDto.setOnmAlarmCd(onmAlarmCd);
		reqOomTenantResourceMonitoringThresholdDto.setAuditId(loginUserId);
		
		// 임계치 수정...
		int affectRowCount = thresholdService.updateThreshold(reqOomTenantResourceMonitoringThresholdDto);
		if (affectRowCount < 1) {
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_UPDATE_FAIL, affectRowCount));
		} else {
			returnString = Const.Common.RESULT_CODE.SUCCESS;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, "", affectRowCount));
		}
    	
    	return resEntity;
    }
	
	/**
	 * 
	 * deleteThreshold
	 *
	 * @param onmAlarmTypeCd
	 * @param reqOomTenantResourceMonitoringThresholdDto
	 * @return ResponseEntity
	 */
	@SuppressWarnings("rawtypes")
    @DeleteMapping(value="/{onmAlarmCd}", produces="application/json; charset=UTF-8")
    public ResponseEntity deleteThreshold(@AuthenticationPrincipal JwtAuthResultDto authResultDto, 
    		@PathVariable("onmAlarmCd") String onmAlarmCd, @RequestBody OomTenantResourceMonitoringThresholdDto reqOomTenantResourceMonitoringThresholdDto) throws Exception {
        
    	ResponseEntity<ResultDto> resEntity = null;
		String returnString = "";
    	
		String loginUserId = StringUtils.defaultString(authResultDto.getUserId());
		if ("".equals(loginUserId)) {
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_LOGIN_USER_ID));
			return resEntity;
		}
		String mgrYn = StringUtils.defaultString(authResultDto.getMgrYn());
		if ("".equals(mgrYn)) {
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_MGR_YN));
			return resEntity;
		}
		//String loginUserId = "tsop-admin"; // 이후 세션에서 얻어올 값...
		
		if (!"Y".equals(mgrYn)) {
			String authorityTypeCd = "";
			UserRoleMenuAuthorityRequestDto userRoleMenuAuthorityRequestDto = new UserRoleMenuAuthorityRequestDto();
			userRoleMenuAuthorityRequestDto.setUserId(loginUserId);
			userRoleMenuAuthorityRequestDto.setMenuId(MENU_ID);
			OomUserRoleAuthorityDetailDto rsltOomUserRoleAuthorityDetailDto = userRoleService.readMenuAuthority(userRoleMenuAuthorityRequestDto);
			if (rsltOomUserRoleAuthorityDetailDto != null) {
				authorityTypeCd = StringUtils.defaultString(rsltOomUserRoleAuthorityDetailDto.getAuthorityTypeCd());
			}
			if (!"W".equals(authorityTypeCd)) {
				returnString = Const.Common.RESULT_CODE.FAIL;
				resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NO_AUTH));
				return resEntity;
			}
		}
		
		String tenantId = StringUtils.defaultString(reqOomTenantResourceMonitoringThresholdDto.getTenantId());
		if ("".equals(tenantId)) {
			log.error(">>>>>> tenantId ERROR:{}", ERR_MSG_NULL_TENANT_ID);
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_TENANT_ID));
			return resEntity;
		}
		String onmResourceId = StringUtils.defaultString(reqOomTenantResourceMonitoringThresholdDto.getOnmResourceId());
		if ("".equals(onmResourceId)) {
			log.error(">>>>>> onmResourceId ERROR:{}", ERR_MSG_NULL_RESOURCE_ID);
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_RESOURCE_ID));
			return resEntity;
		}
		reqOomTenantResourceMonitoringThresholdDto.setOnmAlarmCd(onmAlarmCd);
		
		// 해당 임계치 관련 감시알람이 등록되어 있는 지 확인...
		OomTenantResourceMonitoringAlarmConditionDto reqOomTenantResourceMonitoringAlarmConditionDto = new OomTenantResourceMonitoringAlarmConditionDto();
		reqOomTenantResourceMonitoringAlarmConditionDto.setTenantId(tenantId);
		reqOomTenantResourceMonitoringAlarmConditionDto.setOnmAlarmCd(onmAlarmCd);
		int conditionCount = resourceMonitoringAlarmService.readTenantResourceMonitoringAlarmConditionCount(reqOomTenantResourceMonitoringAlarmConditionDto);
		if (conditionCount > 0) {
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_EXIST_MONITORING_ALARM));
			return resEntity;
		}
		
		// 임계치 삭제...
		int affectRowCount = thresholdService.deleteThreshold(reqOomTenantResourceMonitoringThresholdDto);
		if (affectRowCount < 1) {
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_DELETE_FAIL, affectRowCount));
		} else {
			returnString = Const.Common.RESULT_CODE.SUCCESS;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, "", affectRowCount));
		}
    	
    	return resEntity;
    }

}
