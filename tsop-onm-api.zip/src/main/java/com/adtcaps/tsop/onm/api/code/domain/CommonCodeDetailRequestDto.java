package com.adtcaps.tsop.onm.api.code.domain;

import java.util.List;

import lombok.Getter;
import lombok.Setter;

/**
 * 
 * <ul>
 * <li>업무 그룹명 : tsop-onm-api</li>
 * <li>서브 업무명 : com.adtcaps.tsop.onm.api.code.domain</li>
 * <li>설  명 : CommonCodeDetailRequestDto.java</li>
 * <li>작성일 : 2021. 1. 5.</li>
 * <li>작성자 : jeonyb4</li>
 * </ul>
 */
@Getter
@Setter
public class CommonCodeDetailRequestDto {
	private String commonCd;
	private String commonCdValLike;
	private String commonCdValIn;
	private String commonCdValNotIn;
	private Integer sortSeq;
	private List<String> commonCdValInList;
	private List<String> commonCdValNotInList;
	private String commonCdValName;
	
	public CommonCodeDetailRequestDto() {
		this.commonCd = "";
		this.commonCdValLike = "";
		this.commonCdValIn = "";
		this.commonCdValNotIn = "";
		this.commonCdValName = "";
		this.sortSeq = 0;
	}
}
