package com.adtcaps.tsop.onm.api.code.domain;

import com.adtcaps.tsop.onm.api.helper.domain.BasePageDto;

import lombok.Getter;
import lombok.Setter;

/**
 * 
 * <ul>
 * <li>업무 그룹명 : tsop-onm-api</li>
 * <li>서브 업무명 : com.adtcaps.tsop.onm.api.code.domain</li>
 * <li>설  명 : CommonCodeGridRequestDto.java</li>
 * <li>작성일 : 2021. 1. 4.</li>
 * <li>작성자 : jeonyb4</li>
 * </ul>
 */
@Getter
@Setter
public class CommonCodeGridRequestDto extends BasePageDto {
	private String serviceClCd;
	private String useYn;
	
	public CommonCodeGridRequestDto() {
		this.serviceClCd = "";
		this.useYn = "";
	}

}
