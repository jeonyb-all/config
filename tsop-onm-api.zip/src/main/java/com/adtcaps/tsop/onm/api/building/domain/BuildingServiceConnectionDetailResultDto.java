package com.adtcaps.tsop.onm.api.building.domain;

import java.util.List;

import lombok.Getter;
import lombok.Setter;

/**
 * 
 * <ul>
 * <li>업무 그룹명 : tsop-onm-api</li>
 * <li>서브 업무명 : com.adtcaps.tsop.onm.api.building.domain</li>
 * <li>설  명 : BuildingServiceConnectionDetailResultDto.java</li>
 * <li>작성일 : 2021. 2. 4.</li>
 * <li>작성자 : jeonyb4</li>
 * </ul>
 */
@Getter
@Setter
public class BuildingServiceConnectionDetailResultDto {
	private String tenantName;
	private String bldName;
	private String bldId;
	private String serviceClCd;
	private String serviceSysName;
	private String serviceClName;
	private String linkageStandardVersionVal;
	private String connectionInfo;
	private String connectionPortNum;
	private String developLinkageKeyVal;
	private String commonLinkageKeyVal;
	private List<BuildingServiceConnectionIpDetailDto> connectionIpList;

}
