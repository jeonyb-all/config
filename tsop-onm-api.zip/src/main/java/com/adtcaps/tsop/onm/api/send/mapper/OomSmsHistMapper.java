package com.adtcaps.tsop.onm.api.send.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;

import com.adtcaps.tsop.onm.api.domain.OomSmsHistDto;
import com.adtcaps.tsop.onm.api.send.domain.SmsHistDetailResultDto;
import com.adtcaps.tsop.onm.api.send.domain.SmsHistGridRequestDto;
import com.adtcaps.tsop.onm.api.send.domain.SmsHistGridResultDto;

/**
 * 
 * <ul>
 * <li>업무 그룹명 : tsop-onm-api</li>
 * <li>서브 업무명 : com.adtcaps.tsop.onm.api.send.mapper</li>
 * <li>설  명 : OomSmsHistMapper.java</li>
 * <li>작성일 : 2021. 2. 24.</li>
 * <li>작성자 : jeonyb4</li>
 * </ul>
 */
@Mapper
public interface OomSmsHistMapper {
	/**
	 * 
	 * createOomSmsHist
	 *
	 * @param reqOomSmsHistDto
	 * @return int
	 */
	public int createOomSmsHist(OomSmsHistDto reqOomSmsHistDto);
	
	/**
	 * 
	 * listPageSmsHist
	 *
	 * @param reqSmsHistGridRequestDto
	 * @return List<SmsHistGridResultDto>
	 */
	public List<SmsHistGridResultDto> listPageSmsHist(SmsHistGridRequestDto reqSmsHistGridRequestDto);
	
	/**
	 * 
	 * readOomSmsHist
	 *
	 * @param reqOomSmsHistDto
	 * @return SmsHistDetailResultDto
	 */
	public SmsHistDetailResultDto readOomSmsHist(OomSmsHistDto reqOomSmsHistDto);

}
