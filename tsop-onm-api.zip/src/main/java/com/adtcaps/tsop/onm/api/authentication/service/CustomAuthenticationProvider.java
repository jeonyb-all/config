package com.adtcaps.tsop.onm.api.authentication.service;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.security.authentication.AuthenticationProvider;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.LockedException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.AuthenticationException;
import org.springframework.stereotype.Component;

import java.util.HashMap;
import java.util.Map;

import com.adtcaps.tsop.onm.api.authentication.domain.JwtAuthResultDto;
import com.adtcaps.tsop.onm.api.authentication.domain.JwtRequest;
import com.adtcaps.tsop.onm.api.authentication.mapper.JwtAuthenticationMapper;



@Component
public class CustomAuthenticationProvider implements AuthenticationProvider {
    @Autowired
    JwtAuthenticationServiceImpl jwtAuthenticationServiceImpl;

    @Autowired
    JwtAuthenticationMapper jwtAuthenticationMapper;

    @Value("${jwt.sms.limituserid}")
    private Integer limitUserId;

    @Value("${jwt.sms.limitip}")
    private Integer limitIp;
    
    private  static Map<String, Integer> loginFail = new HashMap<String, Integer>();

    
    public   Map<String, Integer> getLoginFail(){
        return loginFail;
    }

    public int getLoginFailCnt(String key){
        if(!loginFail.containsKey(key)) {
            return 0;
        }else return (int)loginFail.get(key);
    }

    public void setLoginFailCnt(String key){
        if(!loginFail.containsKey(key)) {
            loginFail.put(key, 1);
        }else {
            int cnt = (int)loginFail.get(key) + 1;
            loginFail.replace(key, cnt);
        }
    }

    public void clearLoginFailCnt(String key){
        if(loginFail.containsKey(key)) 	loginFail.remove(key);
    }
    @Override
    public Authentication authenticate(Authentication authentication) throws AuthenticationException {

        String userid = authentication.getName();
        String userpw = (String) authentication.getCredentials();

        JwtRequest request = new JwtRequest(userid, userpw );
        
        JwtAuthResultDto result = jwtAuthenticationServiceImpl.loadUserByUsernamePassword(request);

        if(result == null ){
            throw new BadCredentialsException("로그인 정보를 확인 바랍니다.");
        } else if("Y".equalsIgnoreCase(result.getLockYn())){
            throw new LockedException("계정 활성화를 위해서 운용자에게 문의바랍니다. ");
        } else if( !"1".equalsIgnoreCase(result.getPasswordYn())){
            if(getLoginFailCnt(userid) >=limitUserId){
               jwtAuthenticationMapper.updateLockUser(userid);
            }
            setLoginFailCnt(userid);
            throw new BadCredentialsException("로그인 정보를 확인 바랍니다.");
        }
        clearLoginFailCnt(userid);
        return new UsernamePasswordAuthenticationToken(userid, userpw);
    }

    @Override
    public boolean supports(Class<?> authentication) {
        
        return true;
    }
    
}
