package com.adtcaps.tsop.onm.api.alarm.domain;

import com.adtcaps.tsop.onm.api.helper.domain.BasePageDto;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

import lombok.Getter;
import lombok.Setter;

/**
 * 
 * <ul>
 * <li>업무 그룹명 : tsop-onm-api</li>
 * <li>서브 업무명 : com.adtcaps.tsop.onm.api.alarm.domain</li>
 * <li>설  명 : AlarmNoticeReceiveGroupGridResultDto.java</li>
 * <li>작성일 : 2021. 1. 8.</li>
 * <li>작성자 : jeonyb4</li>
 * </ul>
 */
@Getter
@Setter
@JsonInclude(Include.NON_EMPTY)
public class AlarmNoticeReceiveGroupGridResultDto extends BasePageDto {
	private Integer rowNum;
	private Integer alarmNoticeGroupId;
	private String alarmNoticeGroupName;
	private String alarmNoticeGroupDesc;
	private String useYn;
	private String registerName;
	private String registDatetime;
	private String auditDatetime;
	
}
