package com.adtcaps.tsop.onm.api.work.service;

import com.adtcaps.tsop.onm.api.domain.OomWorkDto;

/**
 * 
 * <ul>
 * <li>업무 그룹명 : tsop-onm-api</li>
 * <li>서브 업무명 : com.adtcaps.tsop.onm.api.work.service</li>
 * <li>설  명 : WorkFinishService.java</li>
 * <li>작성일 : 2021. 2. 18.</li>
 * <li>작성자 : jeonyb4</li>
 * </ul>
 */
public interface WorkFinishService {
	/**
	 * 
	 * copyWork
	 *
	 * @param reqOomWorkDto
	 * @return int
	 * @throws Exception 
	 */
	public int copyWork(OomWorkDto reqOomWorkDto) throws Exception;

}
