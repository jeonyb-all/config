package com.adtcaps.tsop.onm.api.dashboard.domain;

import lombok.Getter;
import lombok.Setter;

/**
 * 
 * <ul>
 * <li>업무 그룹명 : tsop-onm-api</li>
 * <li>서브 업무명 : com.adtcaps.tsop.onm.api.dashboard.domain</li>
 * <li>설  명 : DashboardTrafficResultDto.java</li>
 * <li>작성일 : 2021. 2. 1.</li>
 * <li>작성자 : song</li>
 * </ul>
 */
@Getter
@Setter
public class DashboardTrafficResultDto {
	private String baseDatetime;
	private String inCnt;
	private String outCnt;

}
