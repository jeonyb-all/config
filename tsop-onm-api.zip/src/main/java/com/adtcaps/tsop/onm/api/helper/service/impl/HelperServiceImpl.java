package com.adtcaps.tsop.onm.api.helper.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.adtcaps.tsop.onm.api.helper.domain.DateCalculateRequestDto;
import com.adtcaps.tsop.onm.api.helper.domain.WeekMinMaxDateDto;
import com.adtcaps.tsop.onm.api.helper.mapper.HelperMapper;
import com.adtcaps.tsop.onm.api.helper.service.HelperService;

/**
 * 
 * <ul>
 * <li>업무 그룹명 : tsop-onm-api</li>
 * <li>서브 업무명 : com.adtcaps.tsop.onm.api.helper.service.impl</li>
 * <li>설  명 : HelperServiceImpl.java</li>
 * <li>작성일 : 2021. 1. 2.</li>
 * <li>작성자 : jeonyb4</li>
 * </ul>
 */
@Service
public class HelperServiceImpl implements HelperService {
	
	@Autowired
	private HelperMapper helperMapper;
	
	/**
	 * 
	 * readCurrentDate
	 *
	 * @return String
	 */
	@Override
	public String readCurrentDate() {
		return helperMapper.readCurrentDate();
	}
	
	/**
	 * 
	 * readCurrentTime
	 *
	 * @return String
	 */
	@Override
	public String readCurrentTime() {
		return helperMapper.readCurrentTime();
	}
	
	/**
	 * 
	 * readCalculateSomeDate
	 *
	 * @param dateCalculateRequestDto
	 * @return String
	 */
	@Override
	public String readCalculateSomeDate(DateCalculateRequestDto dateCalculateRequestDto) {
		return helperMapper.readCalculateSomeDate(dateCalculateRequestDto);
	}
	
	/**
	 * 
	 * readCurrentDatetimeRoundupHour
	 *
	 * @return String
	 */
	@Override
	public String readCurrentDatetimeRoundupHour() {
		return helperMapper.readCurrentDatetimeRoundupHour();
	}
	
	/**
	 * 
	 * readBeforeWeekDate
	 *
	 * @return String
	 */
	@Override
	public String readBeforeWeekDate() {
		return helperMapper.readBeforeWeekDate();
	}
	
	/**
	 * 
	 * readBeforeMonthDate
	 *
	 * @return String
	 */
	@Override
	public String readBeforeMonthDate() {
		return helperMapper.readBeforeMonthDate();
	}
	
	/**
	 * 
	 * readBeforeYearDate
	 *
	 * @return String
	 */
	@Override
	public String readBeforeYearDate() {
		return helperMapper.readBeforeYearDate();
	}
	
	/**
	 * 
	 * readCurrentDatetime
	 *
	 * @return String
	 */
	@Override
	public String readCurrentDatetime() {
		return helperMapper.readCurrentDatetime();
	}
	
	/**
	 * 
	 * readCurrentMilliSeconds
	 *
	 * @return String
	 */
	@Override
	public String readCurrentMilliSeconds() {
		return helperMapper.readCurrentMilliSeconds();
	}
	
	/**
	 * 
	 * readCurrentWeek
	 *
	 * @param currentYyyymmdd
	 * @return Integer
	 */
	@Override
	public Integer readCurrentWeek(String currentYyyymmdd) {
		return helperMapper.readCurrentWeek(currentYyyymmdd);
	}
	
	/**
	 * 
	 * readMaxWeek
	 *
	 * @param firstYyyymmdd
	 * @return Integer
	 */
	@Override
	public Integer readMaxWeek(String firstYyyymmdd) {
		return helperMapper.readMaxWeek(firstYyyymmdd);
	}
	
	/**
	 * 
	 * readWeekMinMaxDate
	 *
	 * @param inputYyyyMmWeek
	 * @return WeekMinMaxDateDto
	 */
	@Override
	public WeekMinMaxDateDto readWeekMinMaxDate(String inputYyyyMmWeek) {
		return helperMapper.readWeekMinMaxDate(inputYyyyMmWeek);
	}

}
