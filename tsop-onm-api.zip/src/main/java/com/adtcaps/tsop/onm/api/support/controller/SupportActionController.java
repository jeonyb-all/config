package com.adtcaps.tsop.onm.api.support.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.util.CollectionUtils;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.adtcaps.tsop.onm.api.authentication.domain.JwtAuthResultDto;
import com.adtcaps.tsop.onm.api.domain.OomTechSupportActionDto;
import com.adtcaps.tsop.onm.api.domain.OomTechSupportRequestDto;
import com.adtcaps.tsop.onm.api.domain.OomUserRoleAuthorityDetailDto;
import com.adtcaps.tsop.onm.api.file.domain.BlobRequestDto;
import com.adtcaps.tsop.onm.api.helper.constant.Const;
import com.adtcaps.tsop.onm.api.helper.domain.ResultDto;
import com.adtcaps.tsop.onm.api.helper.util.CommonObjectUtil;
import com.adtcaps.tsop.onm.api.support.domain.TechSupportActionGridResultDto;
import com.adtcaps.tsop.onm.api.support.domain.TechSupportActionProcessingDto;
import com.adtcaps.tsop.onm.api.support.domain.TechSupportResultDetailResultDto;
import com.adtcaps.tsop.onm.api.support.service.SupportActionService;
import com.adtcaps.tsop.onm.api.support.service.SupportService;
import com.adtcaps.tsop.onm.api.user.domain.UserRoleMenuAuthorityRequestDto;
import com.adtcaps.tsop.onm.api.user.service.UserRoleService;

import lombok.extern.slf4j.Slf4j;

/**
 * 
 * <ul>
 * <li>업무 그룹명 : tsop-onm-api</li>
 * <li>서브 업무명 : com.adtcaps.tsop.onm.api.support.controller</li>
 * <li>설  명 : TechSupportActionController.java</li>
 * <li>작성일 : 2021. 1. 3.</li>
 * <li>작성자 : jeonyb4</li>
 * </ul>
 */
@Slf4j
@RestController
@RequestMapping("/api/support-actions")
public class SupportActionController {
	
	private final String MENU_ID = "ONM0017";
	
	private final String ERR_MSG_NULL_LOGIN_USER_ID = "로그인 사용자ID가 없습니다.";
	private final String ERR_MSG_NULL_MGR_YN = "관리자여부가 없습니다.";
	private final String ERR_MSG_NULL_TENANT_ID = "테넌트ID가 없습니다.";
	private final String ERR_MSG_NULL_TECH_SUPPORT_STATUS_CD = "기술지원상태코드가 없습니다.";
	private final String ERR_MSG_NULL_TECH_SUPPORT_ID = "기술지원요청ID가 없습니다.";
	private final String ERR_MSG_NULL_TECH_SUPPORT_ACTION_INFO = "기술지원요청 조치내역 등록정보가 없습니다.";
	private final String ERR_MSG_NULL_LOCAL_FILE_PATH = "로컬파일경로가 없습니다.";
	
	private final String ERR_MSG_NOT_FOUND_TECH_SUPPORT_REQUEST = "해당 기술지원요청을 찾을 수 없습니다.";
	private final String ERR_MSG_ALREADY_CHANGE_SUPPORT_STATUS = "해당 기술지원요청에 대한 상태가 이미 변경되어 저장할 수 없습니다.";
	private final String ERR_MSG_CANNOT_INSERT_TECH_SUPPORT_ACTION = "해당 상태코드는 기술지원 조치내역을 등록할 수 없습니다.";
	
	private final String ERR_MSG_NO_AUTH = "권한이 없는 사용자 입니다.";
	private final String ERR_MSG_NULL_SEARCH_RESULT_LIST = "조회 결과가 없습니다.";
	private final String ERR_MSG_CREATE_FAIL = "등록에 실패하였습니다.";
	
	@Autowired
	private SupportActionService supportActionService;
	
	@Autowired
	private SupportService supportService;
	
	@Autowired
	private UserRoleService userRoleService;
	
	/**
	 * 
	 * listTechSupportAction
	 *
	 * @param reqOomTechSupportActionDto
	 * @return ResponseEntity
	 */
	@SuppressWarnings("rawtypes")
    @GetMapping(value="", produces="application/json; charset=UTF-8")
    public ResponseEntity listTechSupportAction(OomTechSupportActionDto reqOomTechSupportActionDto) throws Exception {
        
    	ResponseEntity<ResultDto> resEntity = null;
		String returnString = "";
    	
		String tenantId = StringUtils.defaultString(reqOomTechSupportActionDto.getTenantId());
		if ("".equals(tenantId)) {
			log.error(">>>>>> tenantId ERROR:{}", ERR_MSG_NULL_TENANT_ID);
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_TENANT_ID));
			return resEntity;
		}
		int techSupportReqId = CommonObjectUtil.defaultNumber(reqOomTechSupportActionDto.getTechSupportReqId());
		if (techSupportReqId < 1) {
			log.error(">>>>>> techSupportReqId ERROR:{}", ERR_MSG_NULL_TECH_SUPPORT_ID);
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_TECH_SUPPORT_ID));
			return resEntity;
		}
		// 기술지원요청 조치내역 목록조회....
		Map<String, Object> techSupportActionGridResultDtoListMap = new HashMap<String, Object>();
		List<TechSupportActionGridResultDto> techSupportActionGridResultDtoList = supportActionService.listTechSupportAction(reqOomTechSupportActionDto);
		if (CollectionUtils.isEmpty(techSupportActionGridResultDtoList)) {
			returnString = Const.Common.RESULT_CODE.SUCCESS;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_SEARCH_RESULT_LIST, techSupportActionGridResultDtoListMap));
		} else {
			returnString = Const.Common.RESULT_CODE.SUCCESS;
			int totalCount = techSupportActionGridResultDtoList.size();
			Map<String, Object> totalCountMap = new HashMap<String, Object>();
			totalCountMap.put("totalCount", totalCount);
			
			techSupportActionGridResultDtoListMap.put(Const.Definition.PAGE.PAGER, totalCountMap);
			techSupportActionGridResultDtoListMap.put(Const.Definition.PAGE.LISTS, techSupportActionGridResultDtoList);
			resEntity = ResponseEntity.ok(new ResultDto(returnString, "", techSupportActionGridResultDtoListMap));
		}
    	
    	return resEntity;
    }
	
	/**
	 * 
	 * createOomTechSupportAction
	 *
	 * @param reqTechSupportActionProcessingDto
	 * @return ResponseEntity
	 */
	@SuppressWarnings("rawtypes")
    @PostMapping(value="", produces="application/json; charset=UTF-8")
    public ResponseEntity createOomTechSupportAction(@AuthenticationPrincipal JwtAuthResultDto authResultDto, 
    		@RequestBody TechSupportActionProcessingDto reqTechSupportActionProcessingDto) throws Exception {
        
    	ResponseEntity<ResultDto> resEntity = null;
		String returnString = "";
    	
		String loginUserId = StringUtils.defaultString(authResultDto.getUserId());
		if ("".equals(loginUserId)) {
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_LOGIN_USER_ID));
			return resEntity;
		}
		String mgrYn = StringUtils.defaultString(authResultDto.getMgrYn());
		if ("".equals(mgrYn)) {
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_MGR_YN));
			return resEntity;
		}
		//String loginUserId = "tsop-admin"; // 이후 세션에서 얻어올 값...
		
		if (!"Y".equals(mgrYn)) {
			String authorityTypeCd = "";
			UserRoleMenuAuthorityRequestDto userRoleMenuAuthorityRequestDto = new UserRoleMenuAuthorityRequestDto();
			userRoleMenuAuthorityRequestDto.setUserId(loginUserId);
			userRoleMenuAuthorityRequestDto.setMenuId(MENU_ID);
			OomUserRoleAuthorityDetailDto rsltOomUserRoleAuthorityDetailDto = userRoleService.readMenuAuthority(userRoleMenuAuthorityRequestDto);
			if (rsltOomUserRoleAuthorityDetailDto != null) {
				authorityTypeCd = StringUtils.defaultString(rsltOomUserRoleAuthorityDetailDto.getAuthorityTypeCd());
			}
			if (!"W".equals(authorityTypeCd)) {
				returnString = Const.Common.RESULT_CODE.FAIL;
				resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NO_AUTH));
				return resEntity;
			}
		}
		
		String techSupportStatusCd = StringUtils.defaultString(reqTechSupportActionProcessingDto.getTechSupportStatusCd());
		if ("".equals(techSupportStatusCd)) {
			log.error(">>>>>> techSupportStatusCd ERROR:{}", ERR_MSG_NULL_TECH_SUPPORT_STATUS_CD);
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_TECH_SUPPORT_STATUS_CD));
			return resEntity;
		}
		if (Const.Code.TECH_SUPPORT_STATUS_CD.REQUEST.equals(techSupportStatusCd)) {
			log.error(">>>>>> techSupportStatusCd ERROR:{}", ERR_MSG_CANNOT_INSERT_TECH_SUPPORT_ACTION);
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_CANNOT_INSERT_TECH_SUPPORT_ACTION));
			return resEntity;
		}
		OomTechSupportActionDto reqOomTechSupportActionDto = reqTechSupportActionProcessingDto.getTechSupportActionInfo();
		if (reqOomTechSupportActionDto == null) {
			log.error(">>>>>> reqOomTechSupportActionDto ERROR:{}", ERR_MSG_NULL_TECH_SUPPORT_ACTION_INFO);
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_TECH_SUPPORT_ACTION_INFO));
			return resEntity;
		}
		String tenantId = StringUtils.defaultString(reqOomTechSupportActionDto.getTenantId());
		if ("".equals(tenantId)) {
			log.error(">>>>>> tenantId ERROR:{}", ERR_MSG_NULL_TENANT_ID);
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_TENANT_ID));
			return resEntity;
		}
		int techSupportReqId = CommonObjectUtil.defaultNumber(reqOomTechSupportActionDto.getTechSupportReqId());
		if (techSupportReqId < 1) {
			log.error(">>>>>> techSupportReqId ERROR:{}", ERR_MSG_NULL_TECH_SUPPORT_ID);
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_TECH_SUPPORT_ID));
			return resEntity;
		}
		
		BlobRequestDto blobRequestDto = reqTechSupportActionProcessingDto.getAttachFile();
		if (blobRequestDto != null) {
			String localFilePath = StringUtils.defaultString(blobRequestDto.getLocalFilePath());
			if ("".equals(localFilePath)) {
    			log.error(">>>>>> localFilePath ERROR:{}", ERR_MSG_NULL_LOCAL_FILE_PATH);
				returnString = Const.Common.RESULT_CODE.FAIL;
    			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_LOCAL_FILE_PATH));
    			return resEntity;
    		}
		}
		
		reqOomTechSupportActionDto.setAuditId(loginUserId);
		reqTechSupportActionProcessingDto.setTechSupportActionInfo(reqOomTechSupportActionDto);
		
		// 상태값이 변경되었는 지 체크...
		OomTechSupportRequestDto reqOomTechSupportRequestDto = new OomTechSupportRequestDto();
		reqOomTechSupportRequestDto.setTenantId(tenantId);
		reqOomTechSupportRequestDto.setTechSupportReqId(techSupportReqId);
		TechSupportResultDetailResultDto techSupportResultDetailResultDto = supportService.readTechSupportRequest(reqOomTechSupportRequestDto);
		if (techSupportResultDetailResultDto == null) {
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NOT_FOUND_TECH_SUPPORT_REQUEST));
			return resEntity;
		} else {
			String getTechSupportStatusCd = techSupportResultDetailResultDto.getTechSupportStatusCd();
			if (Const.Code.TECH_SUPPORT_STATUS_CD.FINISH.equals(getTechSupportStatusCd) || Const.Code.TECH_SUPPORT_STATUS_CD.RETURN.equals(getTechSupportStatusCd)) {
				returnString = Const.Common.RESULT_CODE.FAIL;
				resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_ALREADY_CHANGE_SUPPORT_STATUS));
				return resEntity;
			}
			// 지금 반려를 하고자 할 때...
			if (Const.Code.TECH_SUPPORT_STATUS_CD.RETURN.equals(techSupportStatusCd)) {
				if (!Const.Code.TECH_SUPPORT_STATUS_CD.REQUEST.equals(getTechSupportStatusCd)) {
					returnString = Const.Common.RESULT_CODE.FAIL;
					resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_ALREADY_CHANGE_SUPPORT_STATUS));
					return resEntity;
				}
			}
		}
		
		// 기술지원요청 조치내역 등록...
		ResultDto resultDto = supportActionService.createTechSupportAction(reqTechSupportActionProcessingDto);
		if (resultDto == null) {
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_CREATE_FAIL, resultDto));
		} else {
			resEntity = ResponseEntity.ok(resultDto);
		}
    	
    	return resEntity;
    }
	
	/**
	 * 
	 * deleteTechSupportActionAttachFile
	 *
	 * @param techSupportActionDatetime
	 * @param attachFileNum
	 * @param reqOomTechSupportActionDto
	 * @return ResponseEntity
	 */
//	@SuppressWarnings("rawtypes")
//    @DeleteMapping(value="/{techSupportActionDatetime}/attach-files/{attachFileNum}", produces="application/json; charset=UTF-8")
//    public ResponseEntity deleteTechSupportActionAttachFile(@PathVariable("techSupportActionDatetime") String techSupportActionDatetime, @PathVariable("attachFileNum") int attachFileNum, @RequestBody OomTechSupportActionDto reqOomTechSupportActionDto) {
//        
//    	ResponseEntity<ResultDto> resEntity = null;
//		String returnString = "";
//    	
//    	try {
//    		String tenantId = StringUtils.defaultString(reqOomTechSupportActionDto.getTenantId());
//    		if ("".equals(tenantId)) {
//    			log.error(">>>>>> tenantId ERROR:{}", ERR_MSG_NULL_TENANT_ID);
//				returnString = Const.Common.RESULT_CODE.FAIL;
//    			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_TENANT_ID));
//    			return resEntity;
//    		}
//    		String bldId = StringUtils.defaultString(reqOomTechSupportActionDto.getBldId());
//    		if ("".equals(bldId)) {
//    			log.error(">>>>>> bldId ERROR:{}", ERR_MSG_NULL_BLD_ID);
//				returnString = Const.Common.RESULT_CODE.FAIL;
//    			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_BLD_ID));
//    			return resEntity;
//    		}
//    		int techSupportReqId = CommonObjectUtil.defaultNumber(reqOomTechSupportActionDto.getTechSupportReqId());
//    		if (techSupportReqId < 1) {
//    			log.error(">>>>>> techSupportReqId ERROR:{}", ERR_MSG_NULL_TECH_SUPPORT_ID);
//				returnString = Const.Common.RESULT_CODE.FAIL;
//    			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_TECH_SUPPORT_ID));
//    			return resEntity;
//    		}
//			
//    		reqOomTechSupportActionDto.setTechSupportActionDatetime(techSupportActionDatetime);
//    		reqOomTechSupportActionDto.setAttachFileNum(attachFileNum);
//			int affectRowCount = supportActionService.deleteTechSupportActionAttachFile(reqOomTechSupportActionDto);
//    		if (affectRowCount < 1) {
//    			returnString = Const.Common.RESULT_CODE.FAIL;
//    			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_ATTACH_FILE_DELETE_FAIL, affectRowCount));
//    		} else {
//    			returnString = Const.Common.RESULT_CODE.SUCCESS;
//    			resEntity = ResponseEntity.ok(new ResultDto(returnString, "", affectRowCount));
//    		}
//        	
//        } catch (Exception ex) {
//        	log.error("deleteTechSupportActionAttachFile.Exception: {}", ex);
//    		returnString = Const.Common.RESULT_CODE.FAIL;
//    		resEntity = ResponseEntity.ok(new ResultDto(returnString, ex));
//        }
//    	
//    	return resEntity;
//    }
	
	/**
	 * 
	 * deleteTechSupportAction
	 *
	 * @param techSupportActionDatetime
	 * @param reqOomTechSupportActionDto
	 * @return ResponseEntity
	 */
//	@SuppressWarnings("rawtypes")
//    @DeleteMapping(value="/{techSupportActionDatetime}", produces="application/json; charset=UTF-8")
//    public ResponseEntity deleteTechSupportAction(@AuthenticationPrincipal JwtAuthResultDto authResultDto, 
//    		@PathVariable("techSupportActionDatetime") String techSupportActionDatetime, @RequestBody OomTechSupportActionDto reqOomTechSupportActionDto) {
//        
//    	ResponseEntity<ResultDto> resEntity = null;
//		String returnString = "";
//    	
//    	try {
//    		String loginUserId = StringUtils.defaultString(authResultDto.getUserId());
//			if ("".equals(loginUserId)) {
//    			returnString = Const.Common.RESULT_CODE.FAIL;
//    			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_LOGIN_USER_ID));
//    			return resEntity;
//    		}
//    		//String loginUserId = "tsop-admin"; // 이후 세션에서 얻어올 값...
//    		
//    		String tenantId = StringUtils.defaultString(reqOomTechSupportActionDto.getTenantId());
//    		if ("".equals(tenantId)) {
//    			log.error(">>>>>> tenantId ERROR:{}", ERR_MSG_NULL_TENANT_ID);
//				returnString = Const.Common.RESULT_CODE.FAIL;
//    			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_TENANT_ID));
//    			return resEntity;
//    		}
//    		String bldId = StringUtils.defaultString(reqOomTechSupportActionDto.getBldId());
//    		if ("".equals(bldId)) {
//    			log.error(">>>>>> bldId ERROR:{}", ERR_MSG_NULL_BLD_ID);
//				returnString = Const.Common.RESULT_CODE.FAIL;
//    			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_BLD_ID));
//    			return resEntity;
//    		}
//    		int techSupportReqId = CommonObjectUtil.defaultNumber(reqOomTechSupportActionDto.getTechSupportReqId());
//    		if (techSupportReqId < 1) {
//    			log.error(">>>>>> techSupportReqId ERROR:{}", ERR_MSG_NULL_TECH_SUPPORT_ID);
//				returnString = Const.Common.RESULT_CODE.FAIL;
//    			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_TECH_SUPPORT_ID));
//    			return resEntity;
//    		}
//    		String auditId = StringUtils.defaultString(reqOomTechSupportActionDto.getAuditId());
//    		if ("".equals(auditId)) {
//    			log.error(">>>>>> auditId ERROR:{}", ERR_MSG_NULL_AUDIT_ID);
//				returnString = Const.Common.RESULT_CODE.FAIL;
//    			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_AUDIT_ID));
//    			return resEntity;
//    		}
//    		if (!auditId.equals(loginUserId)) {
//    			log.error(">>>>>> auditId ERROR:{}", ERR_MSG_NULL_CANNOT_DELETE);
//				returnString = Const.Common.RESULT_CODE.FAIL;
//    			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_CANNOT_DELETE));
//    			return resEntity;
//    		}
//    		reqOomTechSupportActionDto.setTechSupportActionDatetime(techSupportActionDatetime);
//    		
//    		// 기술지원요청 조치내역 삭제...
//    		int affectRowCount = supportActionService.deleteTechSupportAction(reqOomTechSupportActionDto);
//    		if (affectRowCount < 1) {
//    			returnString = Const.Common.RESULT_CODE.FAIL;
//    			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_DELETE_FAIL, affectRowCount));
//    		} else {
//    			returnString = Const.Common.RESULT_CODE.SUCCESS;
//    			resEntity = ResponseEntity.ok(new ResultDto(returnString, "", affectRowCount));
//    		}
//        	
//        } catch (Exception ex) {
//        	log.error("deleteTechSupportAction.Exception: {}", ex);
//    		returnString = Const.Common.RESULT_CODE.FAIL;
//    		resEntity = ResponseEntity.ok(new ResultDto(returnString, ex));
//        }
//    	
//    	return resEntity;
//    }

}
