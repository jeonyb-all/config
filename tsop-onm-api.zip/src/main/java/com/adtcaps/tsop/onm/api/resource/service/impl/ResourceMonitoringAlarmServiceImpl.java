package com.adtcaps.tsop.onm.api.resource.service.impl;

import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.CollectionUtils;

import com.adtcaps.tsop.onm.api.domain.OomTenantResourceMonitoringAlarmConditionDto;
import com.adtcaps.tsop.onm.api.helper.util.CommonDateUtil;
import com.adtcaps.tsop.onm.api.resource.domain.ResourceMonitoringAlarmDetailResultDto;
import com.adtcaps.tsop.onm.api.resource.domain.ResourceMonitoringAlarmGridRequestDto;
import com.adtcaps.tsop.onm.api.resource.domain.ResourceMonitoringAlarmGridResultDto;
import com.adtcaps.tsop.onm.api.resource.mapper.OomTenantResourceMonitoringAlarmConditionMapper;
import com.adtcaps.tsop.onm.api.resource.service.ResourceMonitoringAlarmService;

/**
 * 
 * <ul>
 * <li>업무 그룹명 : tsop-onm-api</li>
 * <li>서브 업무명 : com.adtcaps.tsop.onm.api.resource.service.impl</li>
 * <li>설  명 : ResourceMonitoringAlarmServiceImpl.java</li>
 * <li>작성일 : 2021. 1. 21.</li>
 * <li>작성자 : jeonyb4</li>
 * </ul>
 */
@Transactional
@Service
public class ResourceMonitoringAlarmServiceImpl implements ResourceMonitoringAlarmService {
	
	@Autowired
	private OomTenantResourceMonitoringAlarmConditionMapper oomTenantResourceMonitoringAlarmConditionMapper;
	
	/**
	 * 
	 * listPageTenantResourceMonitoringAlarmCondition
	 *
	 * @param resourceMonitoringAlarmGridRequestDto
	 * @return List<ResourceMonitoringAlarmGridResultDto>
	 * @throws Exception 
	 */
	@Override
	public List<ResourceMonitoringAlarmGridResultDto> listPageTenantResourceMonitoringAlarmCondition(ResourceMonitoringAlarmGridRequestDto resourceMonitoringAlarmGridRequestDto) throws Exception {
		
		List<ResourceMonitoringAlarmGridResultDto> resourceMonitoringAlarmGridResultDtoList = null;
		try {
			resourceMonitoringAlarmGridResultDtoList = oomTenantResourceMonitoringAlarmConditionMapper.listPageTenantResourceMonitoringAlarmCondition(resourceMonitoringAlarmGridRequestDto);
			if (!CollectionUtils.isEmpty(resourceMonitoringAlarmGridResultDtoList)) {
    			for (int idx = 0; idx < resourceMonitoringAlarmGridResultDtoList.size(); idx++) {
    				
    				ResourceMonitoringAlarmGridResultDto resourceMonitoringAlarmGridResultDto = resourceMonitoringAlarmGridResultDtoList.get(idx);
    				
    				String registDatetime = StringUtils.defaultString(resourceMonitoringAlarmGridResultDto.getRegistDatetime());
    				registDatetime = CommonDateUtil.makeDatetimeFormat(registDatetime);
    				resourceMonitoringAlarmGridResultDto.setRegistDatetime(registDatetime);
    				
    				resourceMonitoringAlarmGridResultDtoList.set(idx, resourceMonitoringAlarmGridResultDto);
    			}
    		}
    		
		} catch (Exception e) {
			throw e;
		}
		return resourceMonitoringAlarmGridResultDtoList;
	}
	
	/**
	 * 
	 * createTenantResourceMonitoringAlarmCondition
	 *
	 * @param reqOomTenantResourceMonitoringAlarmConditionDto
	 * @return int
	 * @throws Exception 
	 */
	@Override
	public int createTenantResourceMonitoringAlarmCondition(OomTenantResourceMonitoringAlarmConditionDto reqOomTenantResourceMonitoringAlarmConditionDto) throws Exception {
		
		int affectRowCount = 0;
		
		try {
			// 테넌트자원감시알람조건 등록...
			int insertRow = oomTenantResourceMonitoringAlarmConditionMapper.createOomTenantResourceMonitoringAlarmCondition(reqOomTenantResourceMonitoringAlarmConditionDto);
			affectRowCount = affectRowCount + insertRow;
			
		} catch (Exception e) {
			throw e;
		}
		
		return affectRowCount;
	}
	
	/**
	 * 
	 * readTenantResourceMonitoringAlarmCondition
	 *
	 * @param reqOomTenantResourceMonitoringAlarmConditionDto
	 * @return ResourceMonitoringAlarmDetailResultDto
	 * @throws Exception 
	 */
	@Override
	public ResourceMonitoringAlarmDetailResultDto readTenantResourceMonitoringAlarmCondition(OomTenantResourceMonitoringAlarmConditionDto reqOomTenantResourceMonitoringAlarmConditionDto) throws Exception {
		
		ResourceMonitoringAlarmDetailResultDto alarmConditionDetailResultDto = null;
		try {
			alarmConditionDetailResultDto = oomTenantResourceMonitoringAlarmConditionMapper.readOomTenantResourceMonitoringAlarmCondition(reqOomTenantResourceMonitoringAlarmConditionDto);
		} catch (Exception e) {
			throw e;
		}
		return alarmConditionDetailResultDto;
	}
	
	/**
	 * 
	 * updateTenantResourceMonitoringAlarmCondition
	 *
	 * @param reqOomTenantResourceMonitoringAlarmConditionDto
	 * @return int
	 * @throws Exception 
	 */
	@Override
	public int updateTenantResourceMonitoringAlarmCondition(OomTenantResourceMonitoringAlarmConditionDto reqOomTenantResourceMonitoringAlarmConditionDto) throws Exception {
		
		int affectRowCount = 0;
		
		try {
			// 테넌트자원감시알람조건 수정...
			int updateRow = oomTenantResourceMonitoringAlarmConditionMapper.updateOomTenantResourceMonitoringAlarmCondition(reqOomTenantResourceMonitoringAlarmConditionDto);
			affectRowCount = affectRowCount + updateRow;
			
		} catch (Exception e) {
			throw e;
		}
		
		return affectRowCount;
	}
	
	/**
	 * 
	 * deleteTenantResourceMonitoringAlarmCondition
	 *
	 * @param reqOomTenantResourceMonitoringAlarmConditionDto
	 * @return int
	 * @throws Exception 
	 */
	@Override
	public int deleteTenantResourceMonitoringAlarmCondition(OomTenantResourceMonitoringAlarmConditionDto reqOomTenantResourceMonitoringAlarmConditionDto) throws Exception {
		
		int affectRowCount = 0;
		
		try {
			// 테넌트자원감시알람조건 삭제...
			int deleteRow = oomTenantResourceMonitoringAlarmConditionMapper.deleteOomTenantResourceMonitoringAlarmCondition(reqOomTenantResourceMonitoringAlarmConditionDto);
			affectRowCount = affectRowCount + deleteRow;
			
		} catch (Exception e) {
			throw e;
		}
		
		return affectRowCount;
	}
	
	/**
	 * 
	 * readTenantResourceMonitoringAlarmConditionCount
	 *
	 * @param reqOomTenantResourceMonitoringAlarmConditionDto
	 * @return int
	 * @throws Exception 
	 */
	@Override
	public int readTenantResourceMonitoringAlarmConditionCount(OomTenantResourceMonitoringAlarmConditionDto reqOomTenantResourceMonitoringAlarmConditionDto) throws Exception {
		
		int conditionCount = 0;
		
		try {
			conditionCount = oomTenantResourceMonitoringAlarmConditionMapper.readOomTenantResourceMonitoringAlarmConditionCount(reqOomTenantResourceMonitoringAlarmConditionDto);
			
		} catch (Exception e) {
			throw e;
		}
		
		return conditionCount;
	}

}
