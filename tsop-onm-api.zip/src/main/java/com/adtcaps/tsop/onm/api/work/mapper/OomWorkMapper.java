package com.adtcaps.tsop.onm.api.work.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;

import com.adtcaps.tsop.onm.api.domain.OomWorkDto;
import com.adtcaps.tsop.onm.api.work.domain.WorkGridRequestDto;
import com.adtcaps.tsop.onm.api.work.domain.WorkGridResultDto;
import com.adtcaps.tsop.onm.api.work.domain.WorkRegisterDto;

/**
 * 
 * <ul>
 * <li>업무 그룹명 : tsop-onm-api</li>
 * <li>서브 업무명 : com.adtcaps.tsop.onm.api.work.mapper</li>
 * <li>설  명 : OomWorkMapper.java</li>
 * <li>작성일 : 2021. 1. 27.</li>
 * <li>작성자 : jeonyb4</li>
 * </ul>
 */
@Mapper
public interface OomWorkMapper {
	/**
	 * 
	 * listPageWork
	 *
	 * @param workGridRequestDto
	 * @return List<WorkGridResultDto>
	 */
	public List<WorkGridResultDto> listPageWork(WorkGridRequestDto workGridRequestDto);
	
	/**
	 * 
	 * createOomWork
	 *
	 * @param reqWorkRegisterDto
	 * @return int
	 */
	public int createOomWork(WorkRegisterDto reqWorkRegisterDto);
	
	/**
	 * 
	 * readOomWork
	 *
	 * @param reqOomWorkDto
	 * @return OomWorkDto
	 */
	public OomWorkDto readOomWork(OomWorkDto reqOomWorkDto);
	
	/**
	 * 
	 * updateOomWorkTenantId
	 *
	 * @param reqOomWorkDto
	 * @return int
	 */
	public int updateOomWorkTenantId(OomWorkDto reqOomWorkDto);
	
	/**
	 * 
	 * updateOomWorkCurrentStatus
	 *
	 * @param reqOomWorkDto
	 * @return int
	 */
	public int updateOomWorkCurrentStatus(OomWorkDto reqOomWorkDto);
	
	/**
	 * 
	 * updateOomWorkEndDate
	 *
	 * @param reqOomWorkDto
	 * @return int
	 */
	public int updateOomWorkEndDate(OomWorkDto reqOomWorkDto);
	
	/**
	 * 
	 * deleteOomWork
	 *
	 * @param reqOomWorkDto
	 * @return int
	 */
	public int deleteOomWork(OomWorkDto reqOomWorkDto);

}
