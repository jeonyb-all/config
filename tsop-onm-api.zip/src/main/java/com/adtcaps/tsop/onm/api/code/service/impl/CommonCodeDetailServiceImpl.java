package com.adtcaps.tsop.onm.api.code.service.impl;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.CollectionUtils;

import com.adtcaps.tsop.onm.api.code.domain.CommonCodeDetailDetailResultDto;
import com.adtcaps.tsop.onm.api.code.domain.CommonCodeDetailForShortGridResultDto;
import com.adtcaps.tsop.onm.api.code.domain.CommonCodeDetailGridResultDto;
import com.adtcaps.tsop.onm.api.code.domain.CommonCodeDetailRequestDto;
import com.adtcaps.tsop.onm.api.code.mapper.OomCommonCodeDetailMapper;
import com.adtcaps.tsop.onm.api.code.service.CommonCodeDetailService;
import com.adtcaps.tsop.onm.api.domain.OomCommonCodeDetailDto;
import com.adtcaps.tsop.onm.api.helper.domain.BasePageDto;
import com.adtcaps.tsop.onm.api.helper.util.CommonDateUtil;

/**
 * 
 * <ul>
 * <li>업무 그룹명 : tsop-onm-api</li>
 * <li>서브 업무명 : com.adtcaps.tsop.onm.api.code.service.impl</li>
 * <li>설  명 : CommonCodeDetailDetailServiceImpl.java</li>
 * <li>작성일 : 2021. 1. 5.</li>
 * <li>작성자 : jeonyb4</li>
 * </ul>
 */
@Transactional
@Service
public class CommonCodeDetailServiceImpl implements CommonCodeDetailService {
	
	@Autowired
	private OomCommonCodeDetailMapper oomCommonCodeDetailMapper;
	
	/**
	 * 
	 * listCommonCodeDetail
	 *
	 * @param reqOomCommonCodeDetailDto
	 * @return List<CommonCodeDetailGridResultDto>
	 * @throws Exception 
	 */
	@Override
	public List<CommonCodeDetailGridResultDto> listCommonCodeDetail(OomCommonCodeDetailDto reqOomCommonCodeDetailDto) throws Exception {
		
		List<CommonCodeDetailGridResultDto> commonCodeDetailGridResultDtoList = null;
		try {
			commonCodeDetailGridResultDtoList = oomCommonCodeDetailMapper.listCommonCodeDetail(reqOomCommonCodeDetailDto);
			if (CollectionUtils.isEmpty(commonCodeDetailGridResultDtoList)) {
				for (int idx=0; idx < commonCodeDetailGridResultDtoList.size(); idx ++) {
					CommonCodeDetailGridResultDto commonCodeGridResultDto = commonCodeDetailGridResultDtoList.get(idx);
					String effectStartDatetime = StringUtils.defaultString(commonCodeGridResultDto.getEffectStartDatetime());
					String effectEndDatetime = StringUtils.defaultString(commonCodeGridResultDto.getEffectEndDatetime());
					effectStartDatetime = CommonDateUtil.makeDatetimeToDateFormat(effectStartDatetime);
					effectEndDatetime = CommonDateUtil.makeDatetimeToDateFormat(effectEndDatetime);
					commonCodeGridResultDto.setEffectStartDatetime(effectStartDatetime);
					commonCodeGridResultDto.setEffectEndDatetime(effectEndDatetime);
					commonCodeDetailGridResultDtoList.set(idx, commonCodeGridResultDto);
				}
			}
    		
		} catch (Exception e) {
			throw e;
		}
		return commonCodeDetailGridResultDtoList;
	}
	
	/**
	 * 
	 * readCommonCodeDetailDuplicationCheck
	 *
	 * @param reqOomCommonCodeDetailDto
	 * @return int
	 * @throws Exception 
	 */
	@Override
	public int readCommonCodeDetailDuplicationCheck(OomCommonCodeDetailDto reqOomCommonCodeDetailDto) throws Exception {
		
		int commonCdCount = 1;
		try {
			commonCdCount = oomCommonCodeDetailMapper.readCommonCodeDetailDuplicationCheck(reqOomCommonCodeDetailDto);
		} catch (Exception e) {
			throw e;
		}
		return commonCdCount;
	}
	
	/**
	 * 
	 * createCommonCodeDetail
	 *
	 * @param reqOomCommonCodeDetailDto
	 * @return int
	 * @throws Exception 
	 */
	@Override
	public int createCommonCodeDetail(OomCommonCodeDetailDto reqOomCommonCodeDetailDto) throws Exception {
		
		int affectRowCount = 0;
		
		try {
			String effectStartDatetime = StringUtils.defaultString(reqOomCommonCodeDetailDto.getEffectStartDatetime());
    		String effectEndDatetime = StringUtils.defaultString(reqOomCommonCodeDetailDto.getEffectEndDatetime());
    		effectStartDatetime = CommonDateUtil.makeFromDatetime(effectStartDatetime);
    		effectEndDatetime = CommonDateUtil.makeToDatetime(effectEndDatetime);
    		reqOomCommonCodeDetailDto.setEffectStartDatetime(effectStartDatetime);
    		reqOomCommonCodeDetailDto.setEffectEndDatetime(effectEndDatetime);
    		
			int insertRow = oomCommonCodeDetailMapper.createOomCommonCodeDetail(reqOomCommonCodeDetailDto);
			affectRowCount = affectRowCount + insertRow;
			
		} catch (Exception e) {
			throw e;
		}
		
		return affectRowCount;
	}
	
	/**
	 * 
	 * readCommonCodeDetail
	 *
	 * @param reqOomCommonCodeDetailDto
	 * @return OomCommonCodeDetailDto
	 * @throws Exception 
	 */
	@Override
	public CommonCodeDetailDetailResultDto readCommonCodeDetail(OomCommonCodeDetailDto reqOomCommonCodeDetailDto) throws Exception {
		
		CommonCodeDetailDetailResultDto commonCodeDetailDetailResultDto = null;
		try {
			commonCodeDetailDetailResultDto = oomCommonCodeDetailMapper.readOomCommonCodeDetail(reqOomCommonCodeDetailDto);
			if (commonCodeDetailDetailResultDto != null) {
				String effectStartDatetime = StringUtils.defaultString(commonCodeDetailDetailResultDto.getEffectStartDatetime());
				String effectEndDatetime = StringUtils.defaultString(commonCodeDetailDetailResultDto.getEffectEndDatetime());
				effectStartDatetime = CommonDateUtil.makeDatetimeToDateFormat(effectStartDatetime);
				effectEndDatetime = CommonDateUtil.makeDatetimeToDateFormat(effectEndDatetime);
				commonCodeDetailDetailResultDto.setEffectStartDatetime(effectStartDatetime);
				commonCodeDetailDetailResultDto.setEffectEndDatetime(effectEndDatetime);
			}
		} catch (Exception e) {
			throw e;
		}
		return commonCodeDetailDetailResultDto;
	}
	
	/**
	 * 
	 * updateCommonCodeDetail
	 *
	 * @param reqOomCommonCodeDetailDto
	 * @return int
	 * @throws Exception 
	 */
	@Override
	public int updateCommonCodeDetail(OomCommonCodeDetailDto reqOomCommonCodeDetailDto) throws Exception {
		
		int affectRowCount = 0;
		
		try {
			String effectStartDatetime = StringUtils.defaultString(reqOomCommonCodeDetailDto.getEffectStartDatetime());
    		String effectEndDatetime = StringUtils.defaultString(reqOomCommonCodeDetailDto.getEffectEndDatetime());
    		effectStartDatetime = CommonDateUtil.makeFromDatetime(effectStartDatetime);
    		effectEndDatetime = CommonDateUtil.makeToDatetime(effectEndDatetime);
    		reqOomCommonCodeDetailDto.setEffectStartDatetime(effectStartDatetime);
    		reqOomCommonCodeDetailDto.setEffectEndDatetime(effectEndDatetime);
			
			int updateRow = oomCommonCodeDetailMapper.updateOomCommonCodeDetail(reqOomCommonCodeDetailDto);
			affectRowCount = affectRowCount + updateRow;
			
		} catch (Exception e) {
			throw e;
		}
		
		return affectRowCount;
	}
	
	/**
	 * 
	 * deleteCommonCodeDetail
	 *
	 * @param reqOomCommonCodeDetailDto
	 * @return int
	 * @throws Exception 
	 */
	@Override
	public int deleteCommonCodeDetail(OomCommonCodeDetailDto reqOomCommonCodeDetailDto) throws Exception {
		
		int affectRowCount = 0;
		
		try {
			int deleteRow = oomCommonCodeDetailMapper.deleteOomCommonCodeDetail(reqOomCommonCodeDetailDto);
			affectRowCount = affectRowCount + deleteRow;
			
		} catch (Exception e) {
			throw e;
		}
		
		return affectRowCount;
	}
	
	
	/**
	 * 
	 * listCommonCodeDetailForCombo
	 *
	 * @param commonCodeDetailRequestDto
	 * @return List<OomCommonCodeDetailDto>
	 * @throws Exception 
	 */
	@Override
	public List<OomCommonCodeDetailDto> listCommonCodeDetailForCombo(CommonCodeDetailRequestDto commonCodeDetailRequestDto) throws Exception {
		
		List<OomCommonCodeDetailDto> rsltOomCommonCodeDetailDtoList = null;
		try {
			String commonCdValIn = StringUtils.defaultString(commonCodeDetailRequestDto.getCommonCdValIn());
			String commonCdValNotIn = StringUtils.defaultString(commonCodeDetailRequestDto.getCommonCdValNotIn());
			if (!"".equals(commonCdValIn)) {
				List<String> commonCdValInList = new ArrayList<String>();
				String[] commonCdValInArr = StringUtils.split(commonCdValIn, ",");
				for (int idx=0; idx < commonCdValInArr.length; idx++) {
					commonCdValInList.add(commonCdValInArr[idx]);
				}
				commonCodeDetailRequestDto.setCommonCdValInList(commonCdValInList);
			}
			if (!"".equals(commonCdValNotIn)) {
				List<String> commonCdValNotInList = new ArrayList<String>();
				String[] commonCdValNotInArr = StringUtils.split(commonCdValNotIn, ",");
				for (int idx=0; idx < commonCdValNotInArr.length; idx++) {
					commonCdValNotInList.add(commonCdValNotInArr[idx]);
				}
				commonCodeDetailRequestDto.setCommonCdValNotInList(commonCdValNotInList);
			}
			rsltOomCommonCodeDetailDtoList = oomCommonCodeDetailMapper.listCommonCodeDetailForCombo(commonCodeDetailRequestDto);
			
		} catch (Exception e) {
			throw e;
		}
		return rsltOomCommonCodeDetailDtoList;
	}
	
	/**
	 * 
	 * listCommonCodeDetailForShortGrid
	 *
	 * @param reqBasePageDto
	 * @return List<CommonCodeDetailForShortGridResultDto>
	 * @throws Exception 
	 */
	@Override
	public List<CommonCodeDetailForShortGridResultDto> listCommonCodeDetailForShortGrid(BasePageDto reqBasePageDto) throws Exception {
		
		List<CommonCodeDetailForShortGridResultDto> commonCodeDetailForShortGridResultDtoList = null;
		try {
			commonCodeDetailForShortGridResultDtoList = oomCommonCodeDetailMapper.listCommonCodeDetailForShortGrid(reqBasePageDto);
			
		} catch (Exception e) {
			throw e;
		}
		return commonCodeDetailForShortGridResultDtoList;
	}
	
	/**
	 * 
	 * readCommonCodeDetailByName
	 *
	 * @param commonCodeDetailRequestDto
	 * @return OomCommonCodeDetailDto
	 * @throws Exception 
	 */
	@Override
	public OomCommonCodeDetailDto readCommonCodeDetailByName(CommonCodeDetailRequestDto commonCodeDetailRequestDto) throws Exception {
		
		OomCommonCodeDetailDto rsltOomCommonCodeDetailDto = null;
		try {
			rsltOomCommonCodeDetailDto = oomCommonCodeDetailMapper.readCommonCodeDetailByName(commonCodeDetailRequestDto);
			
		} catch (Exception e) {
			throw e;
		}
		return rsltOomCommonCodeDetailDto;
	}

}
