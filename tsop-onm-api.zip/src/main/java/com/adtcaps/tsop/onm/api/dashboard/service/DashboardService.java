package com.adtcaps.tsop.onm.api.dashboard.service;

import java.util.List;

import com.adtcaps.tsop.onm.api.dashboard.domain.DashboardAlarmCountResultDto;
import com.adtcaps.tsop.onm.api.dashboard.domain.DashboardAlarmGraphResultDto;
import com.adtcaps.tsop.onm.api.dashboard.domain.DashboardAlarmGridResultDto;
import com.adtcaps.tsop.onm.api.dashboard.domain.DashboardHttpErrResultDto;
import com.adtcaps.tsop.onm.api.dashboard.domain.DashboardHttpResponseResultDto;
import com.adtcaps.tsop.onm.api.dashboard.domain.DashboardRequestDto;
import com.adtcaps.tsop.onm.api.dashboard.domain.DashboardTopoResourceResultDto;
import com.adtcaps.tsop.onm.api.dashboard.domain.DashboardTrafficResultDto;

/**
 * 
 * <ul>
 * <li>업무 그룹명 : tsop-onm-api</li>
 * <li>서브 업무명 : com.adtcaps.tsop.onm.api.dashboard.service</li>
 * <li>설  명 : DashboardService.java</li>
 * <li>작성일 : 2021. 1. 31.</li>
 * <li>작성자 : song</li>
 * </ul>
 */
public interface DashboardService {

	public List<DashboardTopoResourceResultDto> listDashboardTopoResource(DashboardRequestDto reqDashboardDto) throws Exception;
	public List<DashboardAlarmGraphResultDto> listDashboardAlarmGraph(DashboardRequestDto reqDashboardDto) throws Exception;
	public List<DashboardAlarmGridResultDto> listDashboardAlarmGrid(DashboardRequestDto reqDashboardDto) throws Exception;
	
	public List<DashboardAlarmCountResultDto> listDashboardTenantAlarm(DashboardRequestDto reqDashboardDto) throws Exception;
	public List<DashboardAlarmCountResultDto> listDashboardResourceAlarm(DashboardRequestDto reqDashboardDto) throws Exception;
	public List<DashboardAlarmCountResultDto> listDashboardBuildingAlarm(DashboardRequestDto reqDashboardDto) throws Exception;
	public List<DashboardAlarmCountResultDto> listDashboardServiceAlarm(DashboardRequestDto reqDashboardDto) throws Exception;
	
	public List<DashboardTrafficResultDto> listDashboardTrafficResult(DashboardRequestDto reqDashboardDto) throws Exception;
	public List<DashboardHttpErrResultDto> listDashboardHttpErrResult(DashboardRequestDto reqDashboardDto) throws Exception;
	
	public List<DashboardHttpResponseResultDto> listDashboardHttpResponseResult(DashboardRequestDto reqDashboardDto) throws Exception;
	
	public int updateOomAlarmEventAckYn(DashboardRequestDto reqDashboardDto) throws Exception;
	public int updateOomAlarmMaskYn(DashboardRequestDto reqDashboardDto) throws Exception;

	public int getCountTenantResourceDetail(DashboardRequestDto reqDashboardDto) throws Exception;
}
