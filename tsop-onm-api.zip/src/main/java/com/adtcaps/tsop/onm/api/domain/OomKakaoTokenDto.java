package com.adtcaps.tsop.onm.api.domain;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class OomKakaoTokenDto {
	private String token;
	private String bgmsResponseCode;
	private String bgmsResponseMsg;
	private String auditDatetime;
	private String tokenExpire;
}
