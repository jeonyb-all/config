package com.adtcaps.tsop.onm.api.service.service.impl;

import java.io.File;
import java.io.FileOutputStream;
import java.util.List;

import org.apache.commons.io.FileUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.poi.hssf.util.HSSFColor.HSSFColorPredefined;
import org.apache.poi.ss.usermodel.BorderStyle;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.FillPatternType;
import org.apache.poi.ss.usermodel.HorizontalAlignment;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.VerticalAlignment;
import org.apache.poi.ss.util.CellRangeAddress;
import org.apache.poi.xssf.streaming.SXSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.CollectionUtils;

import com.adtcaps.tsop.onm.api.code.domain.CommonCodeDetailRequestDto;
import com.adtcaps.tsop.onm.api.code.service.CommonCodeDetailService;
import com.adtcaps.tsop.onm.api.config.AzureBlobConfig;
import com.adtcaps.tsop.onm.api.domain.OomCommonCodeDetailDto;
import com.adtcaps.tsop.onm.api.domain.OomServiceConnectionApiListDto;
import com.adtcaps.tsop.onm.api.domain.OomServiceConnectionDto;
import com.adtcaps.tsop.onm.api.file.domain.BlobRequestDto;
import com.adtcaps.tsop.onm.api.file.service.FileService;
import com.adtcaps.tsop.onm.api.helper.constant.Const;
import com.adtcaps.tsop.onm.api.helper.service.HelperService;
import com.adtcaps.tsop.onm.api.helper.util.CommonDateUtil;
import com.adtcaps.tsop.onm.api.helper.util.CommonObjectUtil;
import com.adtcaps.tsop.onm.api.service.domain.LinkageStandardVersionForComboResultDto;
import com.adtcaps.tsop.onm.api.service.domain.ServiceConnectionApiExcelDto;
import com.adtcaps.tsop.onm.api.service.domain.ServiceConnectionDetailResultDto;
import com.adtcaps.tsop.onm.api.service.domain.ServiceConnectionGridRequestDto;
import com.adtcaps.tsop.onm.api.service.domain.ServiceConnectionGridResultDto;
import com.adtcaps.tsop.onm.api.service.domain.ServiceConnectionProcessingDto;
import com.adtcaps.tsop.onm.api.service.domain.ServiceSysLinkageMethodForComboResultDto;
import com.adtcaps.tsop.onm.api.service.domain.ServiceSysNameForComboResultDto;
import com.adtcaps.tsop.onm.api.service.mapper.OomServiceConnectionApiListMapper;
import com.adtcaps.tsop.onm.api.service.mapper.OomServiceConnectionMapper;
import com.adtcaps.tsop.onm.api.service.service.ServiceConnectionService;

/**
 * 
 * <ul>
 * <li>업무 그룹명 : tsop-onm-api</li>
 * <li>서브 업무명 : com.adtcaps.tsop.onm.api.service.service.impl</li>
 * <li>설  명 : ServiceConnectionServiceImpl.java</li>
 * <li>작성일 : 2021. 1. 24.</li>
 * <li>작성자 : jeonyb4</li>
 * </ul>
 */
@Transactional
@Service
public class ServiceConnectionServiceImpl implements ServiceConnectionService {
	
	private final String SUCCESS_MSG_CREATE_CONNECTION = "연동정보가 등록되었습니다.";
	private final String SUCCESS_MSG_UPDATE_CONNECTION = "연동정보가 수정되었습니다.";
	private final String SUCCESS_MSG_CREATE_API_LIST = "연동API목록 등록정보";
	
	@Autowired
	private AzureBlobConfig azureBlobConfig;
	
	@Autowired
	private OomServiceConnectionMapper oomServiceConnectionMapper;
	
	@Autowired
	private OomServiceConnectionApiListMapper oomServiceConnectionApiListMapper;
	
	@Autowired
	private CommonCodeDetailService commonCodeDetailService;
	
	@Autowired
	private FileService fileService;
	
	@Autowired
	private HelperService helperService;
	
	/**
	 * 
	 * listServiceSysLinkageMethodForCombo
	 *
	 * @param reqOomServiceConnectionDto
	 * @return List<ServiceSysLinkageMethodForComboResultDto>
	 * @throws Exception 
	 */
	@Override
	public List<ServiceSysLinkageMethodForComboResultDto> listServiceSysLinkageMethodForCombo(OomServiceConnectionDto reqOomServiceConnectionDto) throws Exception {
		
		List<ServiceSysLinkageMethodForComboResultDto> serviceSysLinkageMethodForComboResultDtoList = null;
		try {
			serviceSysLinkageMethodForComboResultDtoList = oomServiceConnectionMapper.listServiceSysLinkageMethodForCombo(reqOomServiceConnectionDto);
			
		} catch (Exception e) {
			throw e;
		}
		return serviceSysLinkageMethodForComboResultDtoList;
	}
	
	/**
	 * 
	 * listServiceSysNameForCombo
	 *
	 * @param reqOomServiceConnectionDto
	 * @return List<ServiceSysNameForComboResultDto>
	 * @throws Exception 
	 */
	@Override
	public List<ServiceSysNameForComboResultDto> listServiceSysNameForCombo(OomServiceConnectionDto reqOomServiceConnectionDto) throws Exception {
		
		List<ServiceSysNameForComboResultDto> serviceSysNameForComboResultDtoList = null;
		try {
			serviceSysNameForComboResultDtoList = oomServiceConnectionMapper.listServiceSysNameForCombo(reqOomServiceConnectionDto);
			
		} catch (Exception e) {
			throw e;
		}
		return serviceSysNameForComboResultDtoList;
	}
	
	/**
	 * 
	 * listLinkageStandardVersionForCombo
	 *
	 * @param reqOomServiceConnectionDto
	 * @return List<LinkageStandardVersionForComboResultDto>
	 * @throws Exception 
	 */
	@Override
	public List<LinkageStandardVersionForComboResultDto> listLinkageStandardVersionForCombo(OomServiceConnectionDto reqOomServiceConnectionDto) throws Exception {
		
		List<LinkageStandardVersionForComboResultDto> linkageStandardVersionForComboResultDtoList = null;
		try {
			linkageStandardVersionForComboResultDtoList = oomServiceConnectionMapper.listLinkageStandardVersionForCombo(reqOomServiceConnectionDto);
			
		} catch (Exception e) {
			throw e;
		}
		return linkageStandardVersionForComboResultDtoList;
	}
	
	/**
	 * 
	 * listPageServiceConnection
	 *
	 * @param serviceConnectionGridRequestDto
	 * @return List<ServiceConnectionGridResultDto>
	 * @throws Exception 
	 */
	@Override
	public List<ServiceConnectionGridResultDto> listPageServiceConnection(ServiceConnectionGridRequestDto serviceConnectionGridRequestDto) throws Exception {
		
		List<ServiceConnectionGridResultDto> resourceMonitoringAlarmGridResultDtoList = null;
		try {
			resourceMonitoringAlarmGridResultDtoList = oomServiceConnectionMapper.listPageServiceConnection(serviceConnectionGridRequestDto);
			if (!CollectionUtils.isEmpty(resourceMonitoringAlarmGridResultDtoList)) {
    			for (int idx = 0; idx < resourceMonitoringAlarmGridResultDtoList.size(); idx++) {
    				
    				ServiceConnectionGridResultDto resourceMonitoringAlarmGridResultDto = resourceMonitoringAlarmGridResultDtoList.get(idx);
    				
    				String registDatetime = StringUtils.defaultString(resourceMonitoringAlarmGridResultDto.getRegistDatetime());
    				registDatetime = CommonDateUtil.makeDatetimeFormat(registDatetime);
    				resourceMonitoringAlarmGridResultDto.setRegistDatetime(registDatetime);
    				
    				resourceMonitoringAlarmGridResultDtoList.set(idx, resourceMonitoringAlarmGridResultDto);
    			}
    		}
    		
		} catch (Exception e) {
			throw e;
		}
		return resourceMonitoringAlarmGridResultDtoList;
	}
	
	/**
	 * 
	 * listConnectionApiListExcel
	 *
	 * @param reqOomServiceConnectionApiListDto
	 * @param fileName
	 * @return String
	 * @throws Exception 
	 */
	@Override
	public String listConnectionApiListExcel(OomServiceConnectionApiListDto reqOomServiceConnectionApiListDto, String fileName) throws Exception {
		
		SXSSFWorkbook wb = null;
		FileOutputStream fileOut = null;
		String fileFullPathName = "";
		
		try {
			
			String downloadTempBasePath = azureBlobConfig.getAzureBlobInfo().getDownloadTempBasePath();
    		String currentMilliSeconds = helperService.readCurrentMilliSeconds();
			
    		// 디렉토리 생성
    		StringBuilder downloadPathBuilder = new StringBuilder();
    		downloadPathBuilder.append(downloadTempBasePath);
    		downloadPathBuilder.append("/");
    		downloadPathBuilder.append(currentMilliSeconds);
            
            File downloadTempDirectory = new File(downloadPathBuilder.toString());
            if (!downloadTempDirectory.isDirectory()) {
            	FileUtils.forceMkdir(downloadTempDirectory);
            }
            
            StringBuilder fileFullPathNameBuilder = new StringBuilder();
            fileFullPathNameBuilder.append(downloadPathBuilder.toString());
            fileFullPathNameBuilder.append("/");
            fileFullPathNameBuilder.append(fileName);
            
            // 파일명 (FullPath)
            fileFullPathName = fileFullPathNameBuilder.toString();
            
            // 워크북 생성
            wb = new SXSSFWorkbook();
            
            // 타이틀용 경계 스타일 테두리만 지정
            CellStyle titleStyle = wb.createCellStyle();
            titleStyle.setBorderTop(BorderStyle.THIN);
            titleStyle.setBorderBottom(BorderStyle.THIN);
            titleStyle.setBorderLeft(BorderStyle.THIN);
            titleStyle.setBorderRight(BorderStyle.THIN);
            titleStyle.setVerticalAlignment(VerticalAlignment.CENTER);
            titleStyle.setWrapText(true);
            
            // 테이블 헤더용 스타일
            CellStyle headStyle = wb.createCellStyle();
            // 가는 경계선을 가집니다.
            headStyle.setBorderTop(BorderStyle.THIN);
            headStyle.setBorderBottom(BorderStyle.THIN);
            headStyle.setBorderLeft(BorderStyle.THIN);
            headStyle.setBorderRight(BorderStyle.THIN);
            // 배경색은 노란색입니다.
            headStyle.setFillForegroundColor(HSSFColorPredefined.YELLOW.getIndex());
            headStyle.setFillPattern(FillPatternType.SOLID_FOREGROUND);
            headStyle.setAlignment(HorizontalAlignment.CENTER);
            
            // 데이터용 경계 스타일 테두리만 지정
            CellStyle bodyStyle = wb.createCellStyle();
            bodyStyle.setBorderTop(BorderStyle.THIN);
            bodyStyle.setBorderBottom(BorderStyle.THIN);
            bodyStyle.setBorderLeft(BorderStyle.THIN);
            bodyStyle.setBorderRight(BorderStyle.THIN);
            
            Sheet sheet = wb.createSheet("API List");
			
			Row row = null;
	        Cell cell = null;
	        int rowNo = 0;
	        
	        // Title 생성
	        StringBuilder titleBuilder = new StringBuilder();
	        titleBuilder.append("※ 엑셀 업로드 시 반드시 이 양식을 사용하시기 바랍니다.\n");
	        titleBuilder.append("※ 임의로 컬럼을 추가 및 삭제하면 데이터가 잘못 등록될 수 있으므로 주의하시기 바랍니다.\n");
	        titleBuilder.append("※ Cell에 : 과 | 특수문자는 사용할 수 없습니다. \n");
	        titleBuilder.append("※ 행 별로 [구분] 컬럼에는 [이벤트 / 제어 / 조회] 중 1개만 사용할 수 있으며, 필수입력 입니다.\n");
	        titleBuilder.append("※ 행 별로 API명은 필수입력 입니다.\n");
	        titleBuilder.append("※ 행 별로 [연동방식] 컬럼에는 [POST / GET] 중 1개만 사용할 수 있으며, 필수입력은 아닙니다.");
	        
	        row = sheet.createRow(rowNo++);
	        row.setHeight((short)2000);
	        for(int i=0; i < 5; i++) {
	        	cell = row.createCell(i);
	            cell.setCellStyle(titleStyle);
	            if (i == 0) {
	        		cell.setCellValue(titleBuilder.toString());
	        	}
	        }
	        sheet.addMergedRegion(new CellRangeAddress(0, 0, 0, 4));	// 행시작, 행끝, 열시작, 열끝
	        
			// 헤더 생성
            row = sheet.createRow(rowNo++);
            
            sheet.setColumnWidth(0, 3500);
            cell = row.createCell(0);
            cell.setCellStyle(headStyle);
            cell.setCellValue("구분");
            
            sheet.setColumnWidth(1, 7500);
            cell = row.createCell(1);
            cell.setCellStyle(headStyle);
            cell.setCellValue("API명");
            
            sheet.setColumnWidth(2, 3500);
            cell = row.createCell(2);
            cell.setCellStyle(headStyle);
            cell.setCellValue("연동방식");
            
            sheet.setColumnWidth(3, 6500);
            cell = row.createCell(3);
            cell.setCellStyle(headStyle);
            cell.setCellValue("URL");
            
            sheet.setColumnWidth(4, 8500);
            cell = row.createCell(4);
            cell.setCellStyle(headStyle);
            cell.setCellValue("설명");
            
			List<ServiceConnectionApiExcelDto> rsltServiceConnectionApiExcelDtoList = oomServiceConnectionApiListMapper.listServiceConnectionApiList(reqOomServiceConnectionApiListDto);
    		if (!CollectionUtils.isEmpty(rsltServiceConnectionApiExcelDtoList)) {
				for (ServiceConnectionApiExcelDto serviceConnectionApiExcelDto : rsltServiceConnectionApiExcelDtoList) {
					String apiTypeClName = StringUtils.defaultString(serviceConnectionApiExcelDto.getApiTypeClName());
					String apiName = StringUtils.defaultString(serviceConnectionApiExcelDto.getApiName());
					String apiMethodClName = StringUtils.defaultString(serviceConnectionApiExcelDto.getApiMethodClName());
					String apiUrlAddr = StringUtils.defaultString(serviceConnectionApiExcelDto.getApiUrlAddr());
					String apiDesc = StringUtils.defaultString(serviceConnectionApiExcelDto.getApiDesc());
					
					row = sheet.createRow(rowNo++);
					cell = row.createCell(0);
	                cell.setCellStyle(bodyStyle);
	                cell.setCellValue(apiTypeClName);
	                cell = row.createCell(1);
	                cell.setCellStyle(bodyStyle);
	                cell.setCellValue(apiName);
	                cell = row.createCell(2);
	                cell.setCellStyle(bodyStyle);
	                cell.setCellValue(apiMethodClName);
	                cell = row.createCell(3);
	                cell.setCellStyle(bodyStyle);
	                cell.setCellValue(apiUrlAddr);
	                cell = row.createCell(4);
	                cell.setCellStyle(bodyStyle);
	                cell.setCellValue(apiDesc);
				}
			}
			
			fileOut = new FileOutputStream(fileFullPathName);
			wb.write(fileOut);
    		
		} catch (Exception e) {
			throw e;
		} finally {
			if (wb != null) {
				wb.close();
			}
			if (fileOut != null) {
				fileOut.close();
			}
		}
		
		return fileFullPathName;
	}
	
	/**
	 * 
	 * createServiceConnection
	 *
	 * @param reqServiceConnectionProcessingDto
	 * @return String
	 * @throws Exception 
	 */
	@Override
	public String createServiceConnection(ServiceConnectionProcessingDto reqServiceConnectionProcessingDto) throws Exception {
		
		String resultMessage = "";
		
		try {
			StringBuilder resultMessageBuilder = new StringBuilder();
			
			OomServiceConnectionDto reqOomServiceConnectionDto = reqServiceConnectionProcessingDto.getConnectionInfo();
			BlobRequestDto blobRequestDto = reqServiceConnectionProcessingDto.getAttachFile();
			if (blobRequestDto != null) {
				blobRequestDto.setContainerName(Const.Definition.BLOB_CONTAINER.FILE);
				blobRequestDto.setBlobBaseDir(Const.Definition.BLOB_BASEDIR.CONNECT);
				int attachFileNum = fileService.createAttachFile(blobRequestDto);
				if (attachFileNum > 0) {
					reqOomServiceConnectionDto.setAttachFileNum(attachFileNum);
				}
			}
			
			// 서비스연동 등록...
			oomServiceConnectionMapper.createOomServiceConnection(reqOomServiceConnectionDto);
			resultMessageBuilder.append(SUCCESS_MSG_CREATE_CONNECTION);
			
			// API 목록 등록...
			List<ServiceConnectionApiExcelDto> reqServiceConnectionApiExcelDtoList = reqServiceConnectionProcessingDto.getApiExcelList();
    		if (!CollectionUtils.isEmpty(reqServiceConnectionApiExcelDtoList)) {
    			int successCount = 0;
    			int failCount = 0;
    			
    			String serviceClCd = StringUtils.defaultString(reqOomServiceConnectionDto.getServiceClCd());
    			String serviceSysName = StringUtils.defaultString(reqOomServiceConnectionDto.getServiceSysName());
    			String linkageStandardVersionVal = StringUtils.defaultString(reqOomServiceConnectionDto.getLinkageStandardVersionVal());
    			String auditId = StringUtils.defaultString(reqOomServiceConnectionDto.getAuditId());
    			
    			for (ServiceConnectionApiExcelDto reqServiceConnectionApiExcelDto : reqServiceConnectionApiExcelDtoList) {
    				String apiTypeClName = StringUtils.defaultString(reqServiceConnectionApiExcelDto.getApiTypeClName());
    				CommonCodeDetailRequestDto commonCodeDetailRequestDto = new CommonCodeDetailRequestDto();
    				commonCodeDetailRequestDto.setCommonCd(Const.Code.COMMON_CD.API_TYPE_CL_CD);
    				commonCodeDetailRequestDto.setCommonCdValName(apiTypeClName);
    				OomCommonCodeDetailDto typeOomCommonCodeDetailDto = commonCodeDetailService.readCommonCodeDetailByName(commonCodeDetailRequestDto);
    				if (typeOomCommonCodeDetailDto == null) {
    					failCount = failCount + 1;
    					continue;
    				}
    				String apiTypeClCd = typeOomCommonCodeDetailDto.getCommonCdVal();	// 필수...
    				
    				String apiName = StringUtils.defaultString(reqServiceConnectionApiExcelDto.getApiName());
    				if ("".equals(apiName)) {
    					failCount = failCount + 1;
    					continue;
    				}
    				
    				String apiMethodClCd = "";
    				String apiMethodClName = StringUtils.defaultString(reqServiceConnectionApiExcelDto.getApiMethodClName());
    				CommonCodeDetailRequestDto reqCommonCodeDetailRequestDto = new CommonCodeDetailRequestDto();
    				reqCommonCodeDetailRequestDto.setCommonCd(Const.Code.COMMON_CD.API_METHOD_CL_CD);
    				reqCommonCodeDetailRequestDto.setCommonCdValName(apiMethodClName);
    				OomCommonCodeDetailDto methodOomCommonCodeDetailDto = commonCodeDetailService.readCommonCodeDetailByName(reqCommonCodeDetailRequestDto);
    				if (methodOomCommonCodeDetailDto != null) {
    					apiMethodClCd = methodOomCommonCodeDetailDto.getCommonCdVal();
    				}
    				
    				String apiUrlAddr = StringUtils.defaultString(reqServiceConnectionApiExcelDto.getApiUrlAddr());
    				String apiDesc = StringUtils.defaultString(reqServiceConnectionApiExcelDto.getApiDesc());
    				
    				OomServiceConnectionApiListDto reqOomServiceConnectionApiListDto = new OomServiceConnectionApiListDto();
    				reqOomServiceConnectionApiListDto.setServiceClCd(serviceClCd);
    				reqOomServiceConnectionApiListDto.setServiceSysName(serviceSysName);
    				reqOomServiceConnectionApiListDto.setLinkageStandardVersionVal(linkageStandardVersionVal);
    				reqOomServiceConnectionApiListDto.setAuditId(auditId);
    				reqOomServiceConnectionApiListDto.setApiTypeClCd(apiTypeClCd);
    				reqOomServiceConnectionApiListDto.setApiName(apiName);
    				reqOomServiceConnectionApiListDto.setApiDesc(apiDesc);
    				reqOomServiceConnectionApiListDto.setApiMethodClCd(apiMethodClCd);
    				reqOomServiceConnectionApiListDto.setApiUrlAddr(apiUrlAddr);
    				reqOomServiceConnectionApiListDto.setUseYn("Y");
    				reqOomServiceConnectionApiListDto.setRegisterId(auditId);
    				
    				oomServiceConnectionApiListMapper.createOomServiceConnectionApiList(reqOomServiceConnectionApiListDto);
    				successCount = successCount + 1;
    			}
    			resultMessageBuilder.append("\n");
    			resultMessageBuilder.append(SUCCESS_MSG_CREATE_API_LIST);
    			resultMessageBuilder.append("\n");
    			resultMessageBuilder.append("성공건수 : ");
    			resultMessageBuilder.append(String.valueOf(successCount));
    			resultMessageBuilder.append(", 실패건수 : ");
    			resultMessageBuilder.append(String.valueOf(failCount));
    		}
    		
    		resultMessage = resultMessageBuilder.toString();
			
		} catch (Exception e) {
			throw e;
		}
		
		return resultMessage;
	}
	
	/**
	 * 
	 * readServiceConnection
	 *
	 * @param reqOomServiceConnectionDto
	 * @return ServiceConnectionDetailResultDto
	 * @throws Exception 
	 */
	@Override
	public ServiceConnectionDetailResultDto readServiceConnection(OomServiceConnectionDto reqOomServiceConnectionDto) throws Exception {
		
		ServiceConnectionDetailResultDto serviceConnectionDetailResultDto = null;
		try {
			// 서비스연동 조회..
			serviceConnectionDetailResultDto = oomServiceConnectionMapper.readOomServiceConnection(reqOomServiceConnectionDto);
			if (serviceConnectionDetailResultDto != null) {
				String serviceClCd = StringUtils.defaultString(serviceConnectionDetailResultDto.getServiceClCd());
				String serviceSysName = StringUtils.defaultString(serviceConnectionDetailResultDto.getServiceSysName());
				String linkageStandardVersionVal = StringUtils.defaultString(serviceConnectionDetailResultDto.getLinkageStandardVersionVal());
				
				// API 목록조회
				OomServiceConnectionApiListDto reqOomServiceConnectionApiListDto = new OomServiceConnectionApiListDto();
				reqOomServiceConnectionApiListDto.setServiceClCd(serviceClCd);
				reqOomServiceConnectionApiListDto.setServiceSysName(serviceSysName);
				reqOomServiceConnectionApiListDto.setLinkageStandardVersionVal(linkageStandardVersionVal);
				List<ServiceConnectionApiExcelDto> rsltServiceConnectionApiExcelDtoList = oomServiceConnectionApiListMapper.listServiceConnectionApiList(reqOomServiceConnectionApiListDto);
				
				serviceConnectionDetailResultDto.setApiExcelList(rsltServiceConnectionApiExcelDtoList);
			}
			
		} catch (Exception e) {
			throw e;
		}
		return serviceConnectionDetailResultDto;
	}
	
	/**
	 * 
	 * deleteServiceConnectionAttachFile
	 *
	 * @param reqOomServiceConnectionDto
	 * @return int
	 * @throws Exception 
	 */
	@Override
	public int deleteServiceConnectionAttachFile(OomServiceConnectionDto reqOomServiceConnectionDto) throws Exception {
		
		int affectRowCount = 0;
		
		try {
			int attachFileNum = reqOomServiceConnectionDto.getAttachFileNum();
			// 첨부파일 삭제
			int deleteRow = fileService.deleteAttachFile(Const.Definition.BLOB_CONTAINER.FILE, attachFileNum);
			affectRowCount = affectRowCount + deleteRow;
			// 서비스연동의 첨부파일번호 Null update
			reqOomServiceConnectionDto.setAttachFileNum(null);
			int updateRow = oomServiceConnectionMapper.updateServiceConnectionAttachFileNum(reqOomServiceConnectionDto);
			affectRowCount = affectRowCount + updateRow;
			
		} catch (Exception e) {
			throw e;
		}
		return affectRowCount;
	}
	
	/**
	 * 
	 * updateServiceConnection
	 *
	 * @param reqServiceConnectionProcessingDto
	 * @return String
	 * @throws Exception 
	 */
	@Override
	public String updateServiceConnection(ServiceConnectionProcessingDto reqServiceConnectionProcessingDto) throws Exception {
		
		String resultMessage = "";
		
		try {
			StringBuilder resultMessageBuilder = new StringBuilder();
			
			OomServiceConnectionDto reqOomServiceConnectionDto = reqServiceConnectionProcessingDto.getConnectionInfo();
			BlobRequestDto blobRequestDto = reqServiceConnectionProcessingDto.getAttachFile();
			if (blobRequestDto != null) {
				// 기존 첨부파일이 존재하는 지 확인...
				ServiceConnectionDetailResultDto serviceConnectionDetailResultDto = oomServiceConnectionMapper.readOomServiceConnectionAttachFile(reqOomServiceConnectionDto);
				if (serviceConnectionDetailResultDto != null) {
					int oldAttachFileNum = CommonObjectUtil.defaultNumber(serviceConnectionDetailResultDto.getAttachFileNum());
					if (oldAttachFileNum > 0) {
						// 기존 첨부파일 삭제
						fileService.deleteAttachFile(Const.Definition.BLOB_CONTAINER.FILE, oldAttachFileNum);
					}
				}
				// 신규 첨부파일 등록..
				blobRequestDto.setContainerName(Const.Definition.BLOB_CONTAINER.FILE);
				blobRequestDto.setBlobBaseDir(Const.Definition.BLOB_BASEDIR.CONNECT);
				int attachFileNum = fileService.createAttachFile(blobRequestDto);
				if (attachFileNum > 0) {
					reqOomServiceConnectionDto.setAttachFileNum(attachFileNum);
				}
			}
			
			// 서비스연동 수정...
			oomServiceConnectionMapper.updateOomServiceConnection(reqOomServiceConnectionDto);
			resultMessageBuilder.append(SUCCESS_MSG_UPDATE_CONNECTION);
			
			// API 목록 처리...
			List<ServiceConnectionApiExcelDto> reqServiceConnectionApiExcelDtoList = reqServiceConnectionProcessingDto.getApiExcelList();
    		if (!CollectionUtils.isEmpty(reqServiceConnectionApiExcelDtoList)) {
    			int successCount = 0;
    			int failCount = 0;
    			
    			String serviceClCd = StringUtils.defaultString(reqOomServiceConnectionDto.getServiceClCd());
    			String serviceSysName = StringUtils.defaultString(reqOomServiceConnectionDto.getServiceSysName());
    			String linkageStandardVersionVal = StringUtils.defaultString(reqOomServiceConnectionDto.getLinkageStandardVersionVal());
    			String auditId = StringUtils.defaultString(reqOomServiceConnectionDto.getAuditId());
    			
    			// 기존 API 목록 삭제...
    			OomServiceConnectionApiListDto delOomServiceConnectionApiListDto = new OomServiceConnectionApiListDto();
    			delOomServiceConnectionApiListDto.setServiceClCd(serviceClCd);
    			delOomServiceConnectionApiListDto.setServiceSysName(serviceSysName);
    			delOomServiceConnectionApiListDto.setLinkageStandardVersionVal(linkageStandardVersionVal);
    			oomServiceConnectionApiListMapper.deleteOomServiceConnectionApiList(delOomServiceConnectionApiListDto);
    			
    			// API 목록 등록...
    			for (ServiceConnectionApiExcelDto reqServiceConnectionApiExcelDto : reqServiceConnectionApiExcelDtoList) {
    				String apiTypeClName = StringUtils.defaultString(reqServiceConnectionApiExcelDto.getApiTypeClName());
    				CommonCodeDetailRequestDto commonCodeDetailRequestDto = new CommonCodeDetailRequestDto();
    				commonCodeDetailRequestDto.setCommonCd(Const.Code.COMMON_CD.API_TYPE_CL_CD);
    				commonCodeDetailRequestDto.setCommonCdValName(apiTypeClName);
    				OomCommonCodeDetailDto typeOomCommonCodeDetailDto = commonCodeDetailService.readCommonCodeDetailByName(commonCodeDetailRequestDto);
    				if (typeOomCommonCodeDetailDto == null) {
    					failCount = failCount + 1;
    					continue;
    				}
    				String apiTypeClCd = typeOomCommonCodeDetailDto.getCommonCdVal();	// 필수...
    				
    				String apiName = StringUtils.defaultString(reqServiceConnectionApiExcelDto.getApiName());
    				if ("".equals(apiName)) {
    					failCount = failCount + 1;
    					continue;
    				}
    				
    				String apiMethodClCd = "";
    				String apiMethodClName = StringUtils.defaultString(reqServiceConnectionApiExcelDto.getApiMethodClName());
    				CommonCodeDetailRequestDto reqCommonCodeDetailRequestDto = new CommonCodeDetailRequestDto();
    				reqCommonCodeDetailRequestDto.setCommonCd(Const.Code.COMMON_CD.API_METHOD_CL_CD);
    				reqCommonCodeDetailRequestDto.setCommonCdValName(apiMethodClName);
    				OomCommonCodeDetailDto methodOomCommonCodeDetailDto = commonCodeDetailService.readCommonCodeDetailByName(reqCommonCodeDetailRequestDto);
    				if (methodOomCommonCodeDetailDto != null) {
    					apiMethodClCd = methodOomCommonCodeDetailDto.getCommonCdVal();
    				}
    				
    				String apiUrlAddr = StringUtils.defaultString(reqServiceConnectionApiExcelDto.getApiUrlAddr());
    				String apiDesc = StringUtils.defaultString(reqServiceConnectionApiExcelDto.getApiDesc());
    				
    				OomServiceConnectionApiListDto reqOomServiceConnectionApiListDto = new OomServiceConnectionApiListDto();
    				reqOomServiceConnectionApiListDto.setServiceClCd(serviceClCd);
    				reqOomServiceConnectionApiListDto.setServiceSysName(serviceSysName);
    				reqOomServiceConnectionApiListDto.setLinkageStandardVersionVal(linkageStandardVersionVal);
    				reqOomServiceConnectionApiListDto.setAuditId(auditId);
    				reqOomServiceConnectionApiListDto.setApiTypeClCd(apiTypeClCd);
    				reqOomServiceConnectionApiListDto.setApiName(apiName);
    				reqOomServiceConnectionApiListDto.setApiDesc(apiDesc);
    				reqOomServiceConnectionApiListDto.setApiMethodClCd(apiMethodClCd);
    				reqOomServiceConnectionApiListDto.setApiUrlAddr(apiUrlAddr);
    				reqOomServiceConnectionApiListDto.setUseYn("Y");
    				reqOomServiceConnectionApiListDto.setRegisterId(auditId);
    				
    				oomServiceConnectionApiListMapper.createOomServiceConnectionApiList(reqOomServiceConnectionApiListDto);
    				successCount = successCount + 1;
    			}
    			resultMessageBuilder.append("\n");
    			resultMessageBuilder.append(SUCCESS_MSG_CREATE_API_LIST);
    			resultMessageBuilder.append("\n");
    			resultMessageBuilder.append("성공건수 : ");
    			resultMessageBuilder.append(String.valueOf(successCount));
    			resultMessageBuilder.append(", 실패건수 : ");
    			resultMessageBuilder.append(String.valueOf(failCount));
    		}
    		
    		resultMessage = resultMessageBuilder.toString();
			
		} catch (Exception e) {
			throw e;
		}
		
		return resultMessage;
	}
	
	/**
	 * 
	 * deleteServiceConnection
	 *
	 * @param reqOomServiceConnectionDto
	 * @return int
	 * @throws Exception 
	 */
	@Override
	public int deleteServiceConnection(OomServiceConnectionDto reqOomServiceConnectionDto) throws Exception {
		
		int affectRowCount = 0;
		
		try {
			String serviceClCd = StringUtils.defaultString(reqOomServiceConnectionDto.getServiceClCd());
			String serviceSysName = StringUtils.defaultString(reqOomServiceConnectionDto.getServiceSysName());
			String linkageStandardVersionVal = StringUtils.defaultString(reqOomServiceConnectionDto.getLinkageStandardVersionVal());
			
			// API 목록 삭제...
			OomServiceConnectionApiListDto delOomServiceConnectionApiListDto = new OomServiceConnectionApiListDto();
			delOomServiceConnectionApiListDto.setServiceClCd(serviceClCd);
			delOomServiceConnectionApiListDto.setServiceSysName(serviceSysName);
			delOomServiceConnectionApiListDto.setLinkageStandardVersionVal(linkageStandardVersionVal);
			int deleteRow = oomServiceConnectionApiListMapper.deleteOomServiceConnectionApiList(delOomServiceConnectionApiListDto);
			affectRowCount = affectRowCount + deleteRow;
			
			// 서비스연동 첨부파일 삭제...
			ServiceConnectionDetailResultDto serviceConnectionDetailResultDto = oomServiceConnectionMapper.readOomServiceConnection(reqOomServiceConnectionDto);
			int attachFileNum = CommonObjectUtil.defaultNumber(serviceConnectionDetailResultDto.getAttachFileNum());
			if (attachFileNum > 0) {
				fileService.deleteAttachFile(Const.Definition.BLOB_CONTAINER.FILE, attachFileNum);
			}
			
			// 서비스연동 삭제...
			deleteRow = oomServiceConnectionMapper.deleteOomServiceConnection(reqOomServiceConnectionDto);
			affectRowCount = affectRowCount + deleteRow;
			
		} catch (Exception e) {
			throw e;
		}
		
		return affectRowCount;
	}

}
