package com.adtcaps.tsop.onm.api.menu.controller;

import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.util.CollectionUtils;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.adtcaps.tsop.onm.api.authentication.domain.JwtAuthResultDto;
import com.adtcaps.tsop.onm.api.helper.constant.Const;
import com.adtcaps.tsop.onm.api.helper.domain.ResultDto;
import com.adtcaps.tsop.onm.api.menu.domain.MenuRequestDto;
import com.adtcaps.tsop.onm.api.menu.domain.MenuResultDto;
import com.adtcaps.tsop.onm.api.menu.domain.MenuTreeResultDto;
import com.adtcaps.tsop.onm.api.menu.service.MenuService;

/**
 * 
 * <ul>
 * <li>업무 그룹명 : tsop-backend-api</li>
 * <li>서브 업무명 : com.adtcaps.tsop.portal.api.menu.controller</li>
 * <li>설  명 : MenuController.java</li>
 * <li>작성일 : 2020. 12. 22.</li>
 * <li>작성자 : jeonyb4</li>
 * </ul>
 */
@RestController
@RequestMapping("/api/menus")
public class MenuController {
	
	private final String ERR_MSG_NULL_LOGIN_USER_ID = "로그인 사용자ID가 없습니다.";
	private final String ERR_MSG_NULL_MGR_YN = "관리자여부가 없습니다.";
	
	private final String ERR_MSG_NULL_SEARCH_RESULT_LIST = "조회 결과가 없습니다.";
	
	@Autowired
	private MenuService menuService;
	
	/**
	 * 
	 * listMenu
	 *
	 * @param menuRequestDto
	 * @return ResponseEntity
	 */
	@SuppressWarnings("rawtypes")
    @GetMapping(value="", produces="application/json; charset=UTF-8")
    public ResponseEntity listMenu(@AuthenticationPrincipal JwtAuthResultDto authResultDto, 
    		MenuRequestDto menuRequestDto) throws Exception {
        
    	ResponseEntity<ResultDto> resEntity = null;
		String returnString = "";
    	
		String loginUserId = StringUtils.defaultString(authResultDto.getUserId());
		if ("".equals(loginUserId)) {
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_LOGIN_USER_ID));
			return resEntity;
		}
		String mgrYn = StringUtils.defaultString(authResultDto.getMgrYn());
		if ("".equals(mgrYn)) {
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_MGR_YN));
			return resEntity;
		}
		//String loginUserId = "admin"; // 이후 세션에서 얻어올 값...
		
		menuRequestDto.setUserId(loginUserId);
		if (!"Y".equals(mgrYn)) {
			menuRequestDto.setAdminMenuId(Const.Definition.ADMIN_MENU_ID.USER_MGMT);
		}
		
		// 메뉴 목록 조회....
		List<MenuResultDto> menuResultDtoList = menuService.listMenu(menuRequestDto);
		if (CollectionUtils.isEmpty(menuResultDtoList)) {
			returnString = Const.Common.RESULT_CODE.SUCCESS;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_SEARCH_RESULT_LIST, menuResultDtoList));
		} else {
			returnString = Const.Common.RESULT_CODE.SUCCESS;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, "", menuResultDtoList));
		}
    	
    	return resEntity;
    }
	
	/**
	 * 
	 * listHiddenMenu
	 *
	 * @param authResultDto
	 * @param menuRequestDto
	 * @return ResponseEntity
	 */
	@SuppressWarnings("rawtypes")
    @GetMapping(value="/hiddens", produces="application/json; charset=UTF-8")
    public ResponseEntity listHiddenMenu(@AuthenticationPrincipal JwtAuthResultDto authResultDto, 
    		MenuRequestDto menuRequestDto) throws Exception {
        
    	ResponseEntity<ResultDto> resEntity = null;
		String returnString = "";
    	
		String loginUserId = StringUtils.defaultString(authResultDto.getUserId());
		if ("".equals(loginUserId)) {
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_LOGIN_USER_ID));
			return resEntity;
		}
		//String loginUserId = "admin"; // 이후 세션에서 얻어올 값...
		
		menuRequestDto.setUserId(loginUserId);
		menuRequestDto.setSuperMenuId(Const.Definition.HIDDEN_SUPER_MENU_ID.SERVICE_NOTI);
		
		// 서비스Noti 아래 노출이 안되는 Hidden된 메뉴 목록 조회....
		List<MenuResultDto> menuResultDtoList = menuService.listHiddenMenu(menuRequestDto);
		if (CollectionUtils.isEmpty(menuResultDtoList)) {
			returnString = Const.Common.RESULT_CODE.SUCCESS;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_SEARCH_RESULT_LIST, menuResultDtoList));
		} else {
			returnString = Const.Common.RESULT_CODE.SUCCESS;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, "", menuResultDtoList));
		}
    	
    	return resEntity;
    }
	
	/**
	 * 
	 * listMenuTree
	 *
	 * @return ResponseEntity
	 */
	@SuppressWarnings("rawtypes")
    @GetMapping(value="/tree", produces="application/json; charset=UTF-8")
    public ResponseEntity listMenuTree() throws Exception {
        
    	ResponseEntity<ResultDto> resEntity = null;
		String returnString = "";
    	
		// 메뉴 트리 조회....
		List<MenuTreeResultDto> menuTreeResultDtoList = menuService.listMenuTree();
		if (CollectionUtils.isEmpty(menuTreeResultDtoList)) {
			returnString = Const.Common.RESULT_CODE.SUCCESS;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_SEARCH_RESULT_LIST, menuTreeResultDtoList));
		} else {
			returnString = Const.Common.RESULT_CODE.SUCCESS;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, "", menuTreeResultDtoList));
		}
    	
    	return resEntity;
    }

}
