package com.adtcaps.tsop.onm.api.alarm.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;

import com.adtcaps.tsop.onm.api.alarm.domain.AlarmEventGridRequestDto;
import com.adtcaps.tsop.onm.api.alarm.domain.AlarmEventGridResultDto;
import com.adtcaps.tsop.onm.api.dashboard.domain.DashboardAlarmGraphResultDto;
import com.adtcaps.tsop.onm.api.dashboard.domain.DashboardAlarmGridResultDto;
import com.adtcaps.tsop.onm.api.dashboard.domain.DashboardRequestDto;
import com.adtcaps.tsop.onm.api.domain.OomFaultDto;
import com.adtcaps.tsop.onm.api.fault.domain.FaultDetailResultDto;

/**
 * 
 * <ul>
 * <li>업무 그룹명 : tsop-onm-api</li>
 * <li>서브 업무명 : com.adtcaps.tsop.onm.api.alarm.mapper</li>
 * <li>설  명 : OomOnmAlarmEventMapper.java</li>
 * <li>작성일 : 2021. 1. 8.</li>
 * <li>작성자 : jeonyb4</li>
 * </ul>
 */
@Mapper
public interface OomOnmAlarmEventMapper {
	/**
	 * 
	 * listPageAlarmEvent
	 *
	 * @param alarmEventGridRequestDto
	 * @return List<AlarmEventGridResultDto>
	 */
	public List<AlarmEventGridResultDto> listPageAlarmEvent(AlarmEventGridRequestDto alarmEventGridRequestDto);
	
	/**
	 * 
	 * readAlarmForFault
	 *
	 * @param reqOomFaultDto
	 * @return FaultDetailResultDto
	 */
	public FaultDetailResultDto readAlarmForFault(OomFaultDto reqOomFaultDto);
	
	/**
	 * 
	 * readAlarmForFaultSmsMessage
	 *
	 * @param reqOomFaultDto
	 * @return FaultDetailResultDto
	 */
	public FaultDetailResultDto readAlarmForFaultSmsMessage(OomFaultDto reqOomFaultDto);
	
	
	
	/* DashBoard AlarmGrid & AlarmGraph */ 
	public List<DashboardAlarmGraphResultDto> listDashboardAlarmGraph(DashboardRequestDto reqDashboardDto);
	public List<DashboardAlarmGridResultDto> listDashboardAlarmGrid(DashboardRequestDto reqDashboardDto);
	public int updateOomAlarmEventAckYn(DashboardRequestDto reqDashboardDto);
	public int updateOomAlarmMaskYn(DashboardRequestDto reqDashboardDto);
	
}
