package com.adtcaps.tsop.onm.api.alarm.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.util.CollectionUtils;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.adtcaps.tsop.onm.api.alarm.domain.AlarmCodeForComboResultDto;
import com.adtcaps.tsop.onm.api.alarm.domain.AlarmCodeForShortGridResultDto;
import com.adtcaps.tsop.onm.api.alarm.service.AlarmCodeService;
import com.adtcaps.tsop.onm.api.domain.OomOnmAlarmCodeDto;
import com.adtcaps.tsop.onm.api.helper.constant.Const;
import com.adtcaps.tsop.onm.api.helper.domain.BasePageDto;
import com.adtcaps.tsop.onm.api.helper.domain.ResultDto;

/**
 * 
 * <ul>
 * <li>업무 그룹명 : tsop-onm-api</li>
 * <li>서브 업무명 : com.adtcaps.tsop.onm.api.alarm.controller</li>
 * <li>설  명 : AlarmCodeController.java</li>
 * <li>작성일 : 2021. 1. 21.</li>
 * <li>작성자 : jeonyb4</li>
 * </ul>
 */
@RestController
@RequestMapping("/api/alarm-codes")
public class AlarmCodeController {
	
	private final String ERR_MSG_NULL_SEARCH_RESULT_LIST = "조회 결과가 없습니다.";
	
	@Autowired
	private AlarmCodeService alarmCodeService;
	
	/**
	 * 
	 * listAlarmCodeForCombo
	 *
	 * @param reqOomOnmAlarmCodeDto
	 * @return ResponseEntity
	 */
	@SuppressWarnings("rawtypes")
	@GetMapping(value="/combobox", produces="application/json; charset=UTF-8")
	public ResponseEntity listAlarmCodeForCombo(OomOnmAlarmCodeDto reqOomOnmAlarmCodeDto) throws Exception {
		
		ResponseEntity<ResultDto> resEntity = null;
		String returnString = "";
		
		// 콤보박스용 알람코드 목록조회
		List<AlarmCodeForComboResultDto> alarmCodeForComboResultDtoList = alarmCodeService.listAlarmCodeForCombo(reqOomOnmAlarmCodeDto);
		if (CollectionUtils.isEmpty(alarmCodeForComboResultDtoList)) {
			returnString = Const.Common.RESULT_CODE.SUCCESS;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_SEARCH_RESULT_LIST, alarmCodeForComboResultDtoList));
        } else {
        	returnString = Const.Common.RESULT_CODE.SUCCESS;
        	resEntity = ResponseEntity.ok(new ResultDto(returnString, "", alarmCodeForComboResultDtoList));
		}
		
		return resEntity;
	}
	
	/**
	 * 
	 * listAlarmCodeForThresholdCombo
	 *
	 * @param reqOomOnmAlarmCodeDto
	 * @return ResponseEntity
	 */
	@SuppressWarnings("rawtypes")
	@GetMapping(value="/threshold-alarms/combobox", produces="application/json; charset=UTF-8")
	public ResponseEntity listAlarmCodeForThresholdCombo(OomOnmAlarmCodeDto reqOomOnmAlarmCodeDto) throws Exception {
		
		ResponseEntity<ResultDto> resEntity = null;
		String returnString = "";
		
		// 콤보박스용 임계치용 알람코드 목록조회
		List<AlarmCodeForComboResultDto> alarmCodeForComboResultDtoList = alarmCodeService.listAlarmCodeForThresholdCombo(reqOomOnmAlarmCodeDto);
		if (CollectionUtils.isEmpty(alarmCodeForComboResultDtoList)) {
			returnString = Const.Common.RESULT_CODE.SUCCESS;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_SEARCH_RESULT_LIST, alarmCodeForComboResultDtoList));
        } else {
        	returnString = Const.Common.RESULT_CODE.SUCCESS;
        	resEntity = ResponseEntity.ok(new ResultDto(returnString, "", alarmCodeForComboResultDtoList));
		}
		
		return resEntity;
	}
	
	/**
	 * 
	 * listAlarmCodeForShortGrid
	 *
	 * @param reqBasePageDto
	 * @return ResponseEntity
	 */
	@SuppressWarnings("rawtypes")
	@GetMapping(value="/short-grid", produces="application/json; charset=UTF-8")
	public ResponseEntity listAlarmCodeForShortGrid(BasePageDto reqBasePageDto) throws Exception {
		
		ResponseEntity<ResultDto> resEntity = null;
		String returnString = "";
		
		// 팝업제공용 알람코드 목록조회
		Map<String, Object> alarmCodeForShortGridResultDtoListMap = new HashMap<String, Object>();
		List<AlarmCodeForShortGridResultDto> alarmCodeForShortGridResultDtoList = alarmCodeService.listAlarmCodeForShortGrid(reqBasePageDto);
		if (CollectionUtils.isEmpty(alarmCodeForShortGridResultDtoList)) {
			returnString = Const.Common.RESULT_CODE.SUCCESS;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_SEARCH_RESULT_LIST, alarmCodeForShortGridResultDtoListMap));
        } else {
        	returnString = Const.Common.RESULT_CODE.SUCCESS;
        	int totalCount = alarmCodeForShortGridResultDtoList.size();
			Map<String, Object> totalCountMap = new HashMap<String, Object>();
			totalCountMap.put("totalCount", totalCount);
			
			alarmCodeForShortGridResultDtoListMap.put(Const.Definition.PAGE.PAGER, totalCountMap);
			alarmCodeForShortGridResultDtoListMap.put(Const.Definition.PAGE.LISTS, alarmCodeForShortGridResultDtoList);
			resEntity = ResponseEntity.ok(new ResultDto(returnString, "", alarmCodeForShortGridResultDtoListMap));
		}

		return resEntity;
	}
	
	/**
	 * 
	 * listAlarmCodeForThresholdShortGrid
	 *
	 * @param reqBasePageDto
	 * @return ResponseEntity
	 */
	@SuppressWarnings("rawtypes")
	@GetMapping(value="/threshold-alarms/short-grid", produces="application/json; charset=UTF-8")
	public ResponseEntity listAlarmCodeForThresholdShortGrid(BasePageDto reqBasePageDto) throws Exception {
		
		ResponseEntity<ResultDto> resEntity = null;
		String returnString = "";
		
		// 임계치 팝업제공용 알람코드 목록조회
		Map<String, Object> alarmCodeForShortGridResultDtoListMap = new HashMap<String, Object>();
		List<AlarmCodeForShortGridResultDto> alarmCodeForShortGridResultDtoList = alarmCodeService.listAlarmCodeForThresholdShortGrid(reqBasePageDto);
		if (CollectionUtils.isEmpty(alarmCodeForShortGridResultDtoList)) {
			returnString = Const.Common.RESULT_CODE.SUCCESS;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_SEARCH_RESULT_LIST, alarmCodeForShortGridResultDtoListMap));
        } else {
        	returnString = Const.Common.RESULT_CODE.SUCCESS;
        	int totalCount = alarmCodeForShortGridResultDtoList.size();
			Map<String, Object> totalCountMap = new HashMap<String, Object>();
			totalCountMap.put("totalCount", totalCount);
			
			alarmCodeForShortGridResultDtoListMap.put(Const.Definition.PAGE.PAGER, totalCountMap);
			alarmCodeForShortGridResultDtoListMap.put(Const.Definition.PAGE.LISTS, alarmCodeForShortGridResultDtoList);
			resEntity = ResponseEntity.ok(new ResultDto(returnString, "", alarmCodeForShortGridResultDtoListMap));
		}

		return resEntity;
	}

}
