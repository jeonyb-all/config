package com.adtcaps.tsop.onm.api.building.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.adtcaps.tsop.onm.api.building.domain.BuildingForComboResultDto;
import com.adtcaps.tsop.onm.api.building.domain.BuildingGridDto;
import com.adtcaps.tsop.onm.api.building.domain.TenantBuildingGridResultDto;
import com.adtcaps.tsop.onm.api.building.mapper.OomBuildingMapper;
import com.adtcaps.tsop.onm.api.building.service.BuildingService;
import com.adtcaps.tsop.onm.api.domain.OomBuildingDto;

/**
 * 
 * <ul>
 * <li>업무 그룹명 : tsop-onm-api</li>
 * <li>서브 업무명 : com.adtcaps.tsop.onm.api.building.service.impl</li>
 * <li>설  명 : BuildingServiceImpl.java</li>
 * <li>작성일 : 2021. 1. 5.</li>
 * <li>작성자 : jeonyb4</li>
 * </ul>
 */
@Service
public class BuildingServiceImpl implements BuildingService {
	
	@Autowired
	private OomBuildingMapper oomBuildingMapper;
	
	/**
	 * 
	 * listBuildingForCombo
	 *
	 * @param reqOomBuildingDto
	 * @return List<BuildingForComboResultDto>
	 * @throws Exception 
	 */
	@Override
	public List<BuildingForComboResultDto> listBuildingForCombo(OomBuildingDto reqOomBuildingDto) throws Exception {
		
		List<BuildingForComboResultDto> buildingForComboResultDtoList = null;
		try {
			buildingForComboResultDtoList = oomBuildingMapper.listBuildingForCombo(reqOomBuildingDto);
			
		} catch (Exception e) {
			throw e;
		}
		return buildingForComboResultDtoList;
	}
	
	/**
	 * 
	 * listTenantBuilding
	 *
	 * @param reqOomBuildingDto
	 * @return List<TenantBuildingGridResultDto>
	 * @throws Exception 
	 */
	@Override
	public List<TenantBuildingGridResultDto> listTenantBuilding(OomBuildingDto reqOomBuildingDto) throws Exception {
		
		List<TenantBuildingGridResultDto> tenantBuildingGridResultDtoList = null;
		try {
			tenantBuildingGridResultDtoList = oomBuildingMapper.listTenantBuilding(reqOomBuildingDto);
		} catch (Exception e) {
			throw e;
		}
		return tenantBuildingGridResultDtoList;
	}
	
	/**
	 * 
	 * listTenantBuildingForWork
	 *
	 * @param reqOomBuildingDto
	 * @return List<TenantBuildingGridResultDto>
	 * @throws Exception 
	 */
	@Override
	public List<TenantBuildingGridResultDto> listTenantBuildingForWork(OomBuildingDto reqOomBuildingDto) throws Exception {
		
		List<TenantBuildingGridResultDto> tenantBuildingGridResultDtoList = null;
		try {
			tenantBuildingGridResultDtoList = oomBuildingMapper.listTenantBuildingForWork(reqOomBuildingDto);
		} catch (Exception e) {
			throw e;
		}
		return tenantBuildingGridResultDtoList;
	}
	
	/**
	 * 
	 * readBuilding
	 *
	 * @param reqOomBuildingDto
	 * @return OomBuildingDto
	 * @throws Exception 
	 */
	@Override
	public OomBuildingDto readBuilding(OomBuildingDto reqOomBuildingDto) throws Exception {
		
		OomBuildingDto rsltOomBuildingDto = null;
		try {
			rsltOomBuildingDto = oomBuildingMapper.readOomBuilding(reqOomBuildingDto);
		} catch (Exception e) {
			throw e;
		}
		return rsltOomBuildingDto;
	}
	
	
	
	
	
	/**
	 * 
	 * listPageBuilding
	 *
	 * @param reqBuildingGridDto
	 * @return List<BuildingGridDto>
	 * @throws Exception 
	 */
	@Override
	public List<BuildingGridDto> listPageBuilding(BuildingGridDto reqBuildingGridDto) throws Exception {
		
		List<BuildingGridDto> rsltBuildingGridDtoList = null;
		try {
			rsltBuildingGridDtoList = oomBuildingMapper.listPageOomBuilding(reqBuildingGridDto);
		} catch (Exception e) {
			throw e;
		}
		return rsltBuildingGridDtoList;
	}

}
