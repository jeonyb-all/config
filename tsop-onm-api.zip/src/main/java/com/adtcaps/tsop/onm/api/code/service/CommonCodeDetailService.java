package com.adtcaps.tsop.onm.api.code.service;

import java.util.List;

import com.adtcaps.tsop.onm.api.code.domain.CommonCodeDetailDetailResultDto;
import com.adtcaps.tsop.onm.api.code.domain.CommonCodeDetailForShortGridResultDto;
import com.adtcaps.tsop.onm.api.code.domain.CommonCodeDetailGridResultDto;
import com.adtcaps.tsop.onm.api.code.domain.CommonCodeDetailRequestDto;
import com.adtcaps.tsop.onm.api.domain.OomCommonCodeDetailDto;
import com.adtcaps.tsop.onm.api.helper.domain.BasePageDto;

/**
 * 
 * <ul>
 * <li>업무 그룹명 : tsop-onm-api</li>
 * <li>서브 업무명 : com.adtcaps.tsop.onm.api.code.service</li>
 * <li>설  명 : CommonCodeDetailService.java</li>
 * <li>작성일 : 2021. 1. 5.</li>
 * <li>작성자 : jeonyb4</li>
 * </ul>
 */
public interface CommonCodeDetailService {
	/**
	 * 
	 * listCommonCodeDetail
	 *
	 * @param reqOomCommonCodeDetailDto
	 * @return List<CommonCodeDetailGridResultDto>
	 * @throws Exception 
	 */
	public List<CommonCodeDetailGridResultDto> listCommonCodeDetail(OomCommonCodeDetailDto reqOomCommonCodeDetailDto) throws Exception;
	
	/**
	 * 
	 * readCommonCodeDetailDuplicationCheck
	 *
	 * @param reqOomCommonCodeDetailDto
	 * @return int
	 * @throws Exception 
	 */
	public int readCommonCodeDetailDuplicationCheck(OomCommonCodeDetailDto reqOomCommonCodeDetailDto) throws Exception;
	
	/**
	 * 
	 * createCommonCodeDetail
	 *
	 * @param reqOomCommonCodeDetailDto
	 * @return int
	 * @throws Exception 
	 */
	public int createCommonCodeDetail(OomCommonCodeDetailDto reqOomCommonCodeDetailDto) throws Exception;
	
	/**
	 * 
	 * readCommonCodeDetail
	 *
	 * @param reqOomCommonCodeDetailDto
	 * @return CommonCodeDetailDetailResultDto
	 * @throws Exception 
	 */
	public CommonCodeDetailDetailResultDto readCommonCodeDetail(OomCommonCodeDetailDto reqOomCommonCodeDetailDto) throws Exception;
	
	/**
	 * 
	 * updateCommonCodeDetail
	 *
	 * @param reqOomCommonCodeDetailDto
	 * @return int
	 * @throws Exception 
	 */
	public int updateCommonCodeDetail(OomCommonCodeDetailDto reqOomCommonCodeDetailDto) throws Exception;
	
	/**
	 * 
	 * deleteCommonCodeDetail
	 *
	 * @param reqOomCommonCodeDetailDto
	 * @return int
	 * @throws Exception 
	 */
	public int deleteCommonCodeDetail(OomCommonCodeDetailDto reqOomCommonCodeDetailDto) throws Exception;
	
	
	/**
	 * 
	 * listCommonCodeDetailForCombo
	 *
	 * @param commonCodeDetailRequestDto
	 * @return List<OomCommonCodeDetailDto>
	 * @throws Exception 
	 */
	public List<OomCommonCodeDetailDto> listCommonCodeDetailForCombo(CommonCodeDetailRequestDto commonCodeDetailRequestDto) throws Exception;
	
	/**
	 * 
	 * listCommonCodeDetailForShortGrid
	 *
	 * @param reqBasePageDto
	 * @return List<CommonCodeDetailForShortGridResultDto>
	 * @throws Exception 
	 */
	public List<CommonCodeDetailForShortGridResultDto> listCommonCodeDetailForShortGrid(BasePageDto reqBasePageDto) throws Exception;
	
	/**
	 * 
	 * readCommonCodeDetailByName
	 *
	 * @param commonCodeDetailRequestDto
	 * @return OomCommonCodeDetailDto
	 * @throws Exception 
	 */
	public OomCommonCodeDetailDto readCommonCodeDetailByName(CommonCodeDetailRequestDto commonCodeDetailRequestDto) throws Exception;

}
