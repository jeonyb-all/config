package com.adtcaps.tsop.onm.api.sms.util;

import com.google.gson.Gson;
import com.google.gson.JsonSyntaxException;
import com.adtcaps.tsop.onm.api.sms.exception.ExternalApiException;
import com.adtcaps.tsop.onm.api.sms.domain.SmsAccessInformation;
import com.adtcaps.tsop.onm.api.sms.service.SmsAccessInformationService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.client.HttpStatusCodeException;
import org.springframework.web.client.RestTemplate;

import java.util.Map;

/**
 * RestTemplateMapUtil.
 *
 * @author zeal77@sk.com
 */
@Component
public class RestTemplateUtil {
    /**
     * Logger.
     */
    private static final Logger LOGGER = LoggerFactory.getLogger(RestTemplateUtil.class);
    /**
     * RestTemplate.
     */
    @Autowired
    RestTemplate restTemplate;
    /**
     * AccessInformationService.
     */
    @Autowired
    SmsAccessInformationService smsAccessInformationService;

    public <T> T restTemplate(String url, HttpMethod httpMethod, HttpHeaders headers, Object body, String eventName,
                              SmsAccessInformation smsAccessInformation, Class<T> responseType) {
        long trId = System.currentTimeMillis();
        HttpEntity<Object> entity = new HttpEntity<>(body, headers);
        Gson gson = new Gson();
        String jsonBody = gson.toJson(body);
        LOGGER.debug("###[REST_REQUEST_INFO] >> " + eventName + " : trId={}, url={}, method={}, header={}, body={}", trId, url, httpMethod, headers, jsonBody);

        try {
            ResponseEntity<T> responseEntity = restTemplate.exchange(url, httpMethod, entity, responseType);
            LOGGER.debug("###[REST_RESPONSE_INFO] >> " + eventName + " : trId={}, statusCode={}, body={}", trId, responseEntity.getStatusCode(), responseEntity.getBody());
            Map<String, Object> responsMap = (Map)responseEntity.getBody() ;
            if( "Authentication failed".equals((String)responsMap.get("error_code")) || "99".equals((String)responsMap.get("error_code"))){
                smsAccessInformationService.updateAccessInfo(smsAccessInformation);
            }
            
            return responseEntity.getBody();
        } catch (HttpStatusCodeException e) {
            LOGGER.debug("###[REST_RESPONSE_ERROR_INFO] >> " + eventName + " : trId={}, statusCode={}, body={}", trId, e.getStatusCode(), String.valueOf(e));

            if( e.getStatusCode().value() == 403 ) {
                try {
                    Gson gson1 = new Gson();
                    Map<String, Object> map = gson1.fromJson(e.getResponseBodyAsString(), Map.class);
                    if( "Authentication failed".equals(map.get("error_msg")) || "99".equals(map.get("error_code"))) {
                        LOGGER.debug("###[AUTHORIZATION_TOKEN_EXPIRED] >> " + eventName + " : code={}, error_message={}, error_code={}", e.getStatusCode().value(), map.get("error_msg"), map.get("error_code"));
                        smsAccessInformationService.updateAccessInfo(smsAccessInformation);
                        // throw new ExternalApiException("TOKEN_EXPIRED > 다시 시도해주세요.");
                    }
                    else {
                        // throw new ExternalApiException(e.getResponseBodyAsString());
                    }
                } catch (JsonSyntaxException err) {
                    LOGGER.debug("###[REST_EXCEPTION] >> Invalid Json Format!! : trId={}, err={}", trId, err.getMessage());
                }
            }
            return null ;
        } catch (Exception e) {
            LOGGER.debug("###[REST_EXCEPTION] >> " + eventName + " : trId={}, body={}", trId, e.getMessage());
            return null ;
        }
    }
}