package com.adtcaps.tsop.onm.api.fault.domain;

import lombok.Getter;
import lombok.Setter;

/**
 * 
 * <ul>
 * <li>업무 그룹명 : tsop-onm-api</li>
 * <li>서브 업무명 : com.adtcaps.tsop.onm.api.fault.domain</li>
 * <li>설  명 : FaultDetailResultDto.java</li>
 * <li>작성일 : 2021. 1. 17.</li>
 * <li>작성자 : jeonyb4</li>
 * </ul>
 */
@Getter
@Setter
public class FaultDetailResultDto {
	private Integer onmFaultId;
	private String tenantId;
	private String tenantName;
	private String onmResourceCategoryCd;
	private String onmResourceCategoryCdName;
	private String onmResourceName;
	private Integer onmAlarmEventId;
	private String eventDatetime;
	private String eventDatetimeFormat;
	private String onmAlarmTypeCd;
	private String onmAlarmTypeName;
	private String onmAlarmCd;
	private String onmAlarmCdName;
	private String faultContent;
	private String onmAlarmGradeCd;
	private String onmAlarmGradeName;
	private String faultActionStatusCd;
	private String faultActionStatusName;
	private String faultReleaseDatetime;
	private String registerId;
	private String registerName;
	private String faultOccrDatetime;
	private Integer alarmNoticeGroupId;
	private String alarmNoticeGroupName;
	private Integer attachFileNum;
	private String attachFileName;
	
}
