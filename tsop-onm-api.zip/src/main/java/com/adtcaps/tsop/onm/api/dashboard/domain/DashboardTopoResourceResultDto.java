package com.adtcaps.tsop.onm.api.dashboard.domain;

import lombok.Getter;
import lombok.Setter;

/**
 * 
 * <ul>
 * <li>업무 그룹명 : tsop-onm-api</li>
 * <li>서브 업무명 : com.adtcaps.tsop.onm.api.dashboard.domain</li>
 * <li>설  명 : DashboardTopoResourceResultDto.java</li>
 * <li>작성일 : 2021. 2. 1.</li>
 * <li>작성자 : song</li>
 * </ul>
 */
@Getter
@Setter
public class DashboardTopoResourceResultDto {
	private String tenantId;
	private String topologyResourceCategoryCd;
	private String superTopologyResourceName;
	private String topologyResourceAbbrName;
	private String topologyResourceId;
	private String onmResourceId;
	private String onmResourceName;
	private String onmResourceAbbrName;
	private String onmResourceCategoryCd;
	private String superOnmResourceId;
	private String superOnmResourceName;
	private String azureResourceId;
	private String onmAlarmYn;
	private String onmAlarmGradeCd;
	private String onmAlarmCdName;
}
