package com.adtcaps.tsop.onm.api.table.service.impl;

import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import com.adtcaps.tsop.onm.api.helper.util.CommonDateUtil;
import com.adtcaps.tsop.onm.api.table.domain.DbTableColumnGridRequestDto;
import com.adtcaps.tsop.onm.api.table.domain.DbTableColumnGridResultDto;
import com.adtcaps.tsop.onm.api.table.domain.DbTableGridRequestDto;
import com.adtcaps.tsop.onm.api.table.domain.DbTableGridResultDto;
import com.adtcaps.tsop.onm.api.table.mapper.OomDbTableColumnMapper;
import com.adtcaps.tsop.onm.api.table.mapper.OomDbTableMapper;
import com.adtcaps.tsop.onm.api.table.service.TableService;

/**
 * 
 * <ul>
 * <li>업무 그룹명 : tsop-onm-api</li>
 * <li>서브 업무명 : com.adtcaps.tsop.onm.api.table.service.impl</li>
 * <li>설  명 : DbServiceImpl.java</li>
 * <li>작성일 : 2021. 1. 7.</li>
 * <li>작성자 : jeonyb4</li>
 * </ul>
 */
@Service
public class TableServiceImpl implements TableService {
	
	@Autowired
	private OomDbTableMapper oomDbTableMapper;
	
	@Autowired
	private OomDbTableColumnMapper oomDbTableColumnMapper;
	
	/**
	 * 
	 * listPageDbTable
	 *
	 * @param dbTableGridRequestDto
	 * @return List<DbTableGridResultDto>
	 * @throws Exception 
	 */
	@Override
	public List<DbTableGridResultDto> listPageDbTable(DbTableGridRequestDto dbTableGridRequestDto) throws Exception {
		
		List<DbTableGridResultDto> dbTableGridResultDtoList = null;
		try {
			dbTableGridResultDtoList = oomDbTableMapper.listPageDbTable(dbTableGridRequestDto);
			if (!CollectionUtils.isEmpty(dbTableGridResultDtoList)) {
    			for (int idx = 0; idx < dbTableGridResultDtoList.size(); idx++) {
    				DbTableGridResultDto dbTableGridResultDto = dbTableGridResultDtoList.get(idx);
    				
    				String registDate = StringUtils.defaultString(dbTableGridResultDto.getRegistDate());
    				registDate = CommonDateUtil.makeDateToDateFormat(registDate);
    				dbTableGridResultDto.setRegistDate(registDate);
    				
    				dbTableGridResultDtoList.set(idx, dbTableGridResultDto);
    			}
    			
			}
		} catch (Exception e) {
			throw e;
		}
		return dbTableGridResultDtoList;
	}
	
	/**
	 * 
	 * listPageDbTableColumn
	 *
	 * @param dbTableColumnGridRequestDto
	 * @return List<DbTableColumnGridResultDto>
	 * @throws Exception 
	 */
	@Override
	public List<DbTableColumnGridResultDto> listPageDbTableColumn(DbTableColumnGridRequestDto dbTableColumnGridRequestDto) throws Exception {
		
		List<DbTableColumnGridResultDto> dbTableColumnGridResultDtoList = null;
		try {
			dbTableColumnGridResultDtoList = oomDbTableColumnMapper.listPageDbTableColumn(dbTableColumnGridRequestDto);
		} catch (Exception e) {
			throw e;
		}
		return dbTableColumnGridResultDtoList;
	}

}
