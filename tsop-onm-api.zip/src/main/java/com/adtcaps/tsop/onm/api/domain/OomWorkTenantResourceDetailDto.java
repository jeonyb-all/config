package com.adtcaps.tsop.onm.api.domain;

import lombok.Getter;
import lombok.Setter;

/**
 * 
 * <ul>
 * <li>업무 그룹명 : tsop-onm-api</li>
 * <li>서브 업무명 : com.adtcaps.tsop.onm.api.domain</li>
 * <li>설  명 : OomWorkTenantResourceDetailDto.java</li>
 * <li>작성일 : 2021. 1. 30.</li>
 * <li>작성자 : jeonyb4</li>
 * </ul>
 */
@Getter
@Setter
public class OomWorkTenantResourceDetailDto {
	private String onmResourceId;
	private Integer onmWorkId;
	private String auditDatetime;
	private String auditId;
	private String tenantId;
	private String onmResourceName;
	private String onmResourceAliasName;
	private String onmResourceAbbrName;
	private String onmResourceRegionName;
	private String onmResourceCategoryCd;
	private String superOnmResourceId;
	private String superOnmResourceName;
	private String azureResourceId;
	private String topologyCategoryCd;
	private String registDatetime;
	private String registerId;

}
