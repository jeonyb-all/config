package com.adtcaps.tsop.onm.api.board.mapper;

import org.apache.ibatis.annotations.Mapper;

import com.adtcaps.tsop.onm.api.domain.OomBulletinboardAlarmNoticeDto;
import com.adtcaps.tsop.onm.api.domain.OomBulletinboardDto;
import com.adtcaps.tsop.onm.api.send.domain.AlarmNoticeSendDetailResultDto;

/**
 * 
 * <ul>
 * <li>업무 그룹명 : tsop-onm-api</li>
 * <li>서브 업무명 : com.adtcaps.tsop.onm.api.board.mapper</li>
 * <li>설  명 : OomBulletinboardAlarmNoticeMapper.java</li>
 * <li>작성일 : 2021. 1. 8.</li>
 * <li>작성자 : jeonyb4</li>
 * </ul>
 */
@Mapper
public interface OomBulletinboardAlarmNoticeMapper {
	/**
	 * 
	 * createOomBulletinboardAlarmNotice
	 *
	 * @param reqOomBulletinboardAlarmNoticeDto
	 * @return int
	 */
	public int createOomBulletinboardAlarmNotice(OomBulletinboardAlarmNoticeDto reqOomBulletinboardAlarmNoticeDto);
	
	/**
	 * 
	 * deleteOomBulletinboardAlarmNotice
	 *
	 * @param reqOomBulletinboardDto
	 * @return int
	 */
	public int deleteOomBulletinboardAlarmNotice(OomBulletinboardDto reqOomBulletinboardDto);
	
	/**
	 * 
	 * readBulletinboardAlarmNotice
	 *
	 * @param reqOomBulletinboardAlarmNoticeDto
	 * @return AlarmNoticeSendDetailResultDto
	 */
	public AlarmNoticeSendDetailResultDto readBulletinboardAlarmNotice(OomBulletinboardAlarmNoticeDto reqOomBulletinboardAlarmNoticeDto);

}
