package com.adtcaps.tsop.onm.api.address.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.util.CollectionUtils;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.adtcaps.tsop.onm.api.address.domain.CtPvcNameForComboResultDto;
import com.adtcaps.tsop.onm.api.address.domain.StreetnameAddressGridRequestDto;
import com.adtcaps.tsop.onm.api.address.domain.StreetnameAddressGridResultDto;
import com.adtcaps.tsop.onm.api.address.service.AddressService;
import com.adtcaps.tsop.onm.api.helper.constant.Const;
import com.adtcaps.tsop.onm.api.helper.domain.ResultDto;
import com.adtcaps.tsop.onm.api.helper.util.PageUtil;

import lombok.extern.slf4j.Slf4j;

/**
 * 
 * <ul>
 * <li>업무 그룹명 : tsop-onm-api</li>
 * <li>서브 업무명 : com.adtcaps.tsop.onm.api.address.controller</li>
 * <li>설  명 : AddressController.java</li>
 * <li>작성일 : 2021. 2. 2.</li>
 * <li>작성자 : jeonyb4</li>
 * </ul>
 */
@Slf4j
@RestController
@RequestMapping("/api/address")
public class AddressController {
	
	private final String ERR_MSG_NULL_PAGE_NUMBER = "페이지 번호가 없습니다.";
	private final String ERR_MSG_NULL_SIDO = "시도가 없습니다.";
	private final String ERR_MSG_NULL_SEARCH_KEYWORD = "검색어가 없습니다.";
	
	private final String ERR_MSG_NULL_SEARCH_RESULT_LIST = "조회 결과가 없습니다.";
	
	@Autowired
	private AddressService addressService;
	
	/**
	 * 
	 * listCtPvcNameForCombo
	 *
	 * @return
	 * @throws Exception ResponseEntity
	 */
	@SuppressWarnings("rawtypes")
	@GetMapping(value="/sido/combobox", produces="application/json; charset=UTF-8")
	public ResponseEntity listCtPvcNameForCombo() throws Exception {
		
		ResponseEntity<ResultDto> resEntity = null;
		String returnString = "";
		
		// 콤보박스용 시도 목록조회
		List<CtPvcNameForComboResultDto> ctPvcNameForComboResultDtoList = addressService.listCtPvcNameForCombo();
		if (CollectionUtils.isEmpty(ctPvcNameForComboResultDtoList)) {
			returnString = Const.Common.RESULT_CODE.SUCCESS;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_SEARCH_RESULT_LIST, ctPvcNameForComboResultDtoList));
        } else {
        	returnString = Const.Common.RESULT_CODE.SUCCESS;
        	resEntity = ResponseEntity.ok(new ResultDto(returnString, "", ctPvcNameForComboResultDtoList));
		}
		
		return resEntity;
	}
	
	/**
	 * 
	 * listCtPvcNameForCombo
	 *
	 * @param ctPvcNameForComboResultDto
	 * @return ResponseEntity
	 * @throws Exception 
	 */
	@SuppressWarnings("rawtypes")
	@GetMapping(value="/sigungu/combobox", produces="application/json; charset=UTF-8")
	public ResponseEntity listCtPvcNameForCombo(CtPvcNameForComboResultDto ctPvcNameForComboResultDto) throws Exception {
		
		ResponseEntity<ResultDto> resEntity = null;
		String returnString = "";
		
		String ctPvcName = StringUtils.defaultString(ctPvcNameForComboResultDto.getCtPvcName());
		if ("".equals(ctPvcName)) {
			log.error(">>>>>> ctPvcName ERROR:{}", ERR_MSG_NULL_SIDO);
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_SIDO));
			return resEntity;
		}
		
		// 콤보박스용 시군구 목록조회
		List<CtPvcNameForComboResultDto> ctPvcNameForComboResultDtoList = addressService.listCtGunGuNameForCombo(ctPvcNameForComboResultDto);
		if (CollectionUtils.isEmpty(ctPvcNameForComboResultDtoList)) {
			returnString = Const.Common.RESULT_CODE.SUCCESS;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_SEARCH_RESULT_LIST, ctPvcNameForComboResultDtoList));
        } else {
        	returnString = Const.Common.RESULT_CODE.SUCCESS;
        	resEntity = ResponseEntity.ok(new ResultDto(returnString, "", ctPvcNameForComboResultDtoList));
		}
		
		return resEntity;
	}
	
	/**
	 * 
	 * listPageStreetnameAddress
	 *
	 * @param reqBasePageDto
	 * @return ResponseEntity
	 */
	@SuppressWarnings("rawtypes")
    @GetMapping(value="/street-names", produces="application/json; charset=UTF-8")
    public ResponseEntity listPageStreetnameAddress(StreetnameAddressGridRequestDto streetnameAddressGridRequestDto) throws Exception {
        
    	ResponseEntity<ResultDto> resEntity = null;
		String returnString = "";
    	
		int pageNumber = streetnameAddressGridRequestDto.getPageNumber();
		if (pageNumber < 1) {
			log.error(">>>>>> pageNumber ERROR:{}", ERR_MSG_NULL_PAGE_NUMBER);
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_PAGE_NUMBER));
			return resEntity;
		}
		String ctPvcName = StringUtils.defaultString(streetnameAddressGridRequestDto.getCtPvcName());
		if ("".equals(ctPvcName)) {
			log.error(">>>>>> ctPvcName ERROR:{}", ERR_MSG_NULL_SIDO);
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_SIDO));
			return resEntity;
		}
		String searchKeyword = StringUtils.defaultString(streetnameAddressGridRequestDto.getSearchKeyword());
		if ("".equals(searchKeyword)) {
			log.error(">>>>>> searchKeyword ERROR:{}", ERR_MSG_NULL_SEARCH_KEYWORD);
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_SEARCH_KEYWORD));
			return resEntity;
		}
		
		// 도로명 주소 목록 조회....
		Map<String, Object> streetnameAddressGridResultDtoListMap = new HashMap<String, Object>();
		List<StreetnameAddressGridResultDto> streetnameAddressGridResultDtoList = addressService.listPageStreetnameAddress(streetnameAddressGridRequestDto);
		if (CollectionUtils.isEmpty(streetnameAddressGridResultDtoList)) {
			returnString = Const.Common.RESULT_CODE.SUCCESS;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_SEARCH_RESULT_LIST, streetnameAddressGridResultDtoListMap));
		} else {
			returnString = Const.Common.RESULT_CODE.SUCCESS;
			streetnameAddressGridResultDtoListMap.put(Const.Definition.PAGE.PAGER, PageUtil.getPageInfo(streetnameAddressGridResultDtoList));
			streetnameAddressGridResultDtoListMap.put(Const.Definition.PAGE.LISTS, streetnameAddressGridResultDtoList);
			resEntity = ResponseEntity.ok(new ResultDto(returnString, "", streetnameAddressGridResultDtoListMap));
		}
    	
    	return resEntity;
    }

}
