package com.adtcaps.tsop.onm.api.threshold.domain;

import com.adtcaps.tsop.onm.api.helper.domain.BasePageDto;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

import lombok.Getter;
import lombok.Setter;

/**
 * 
 * <ul>
 * <li>업무 그룹명 : tsop-onm-api</li>
 * <li>서브 업무명 : com.adtcaps.tsop.onm.api.threshold.domain</li>
 * <li>설  명 : ThresholdGridResultDto.java</li>
 * <li>작성일 : 2021. 1. 17.</li>
 * <li>작성자 : jeonyb4</li>
 * </ul>
 */
@Getter
@Setter
@JsonInclude(Include.NON_EMPTY)
public class ThresholdGridResultDto extends BasePageDto {
	private Integer rowNum;
	private String onmAlarmCd;
	private String onmResourceId;
	private String tenantName;
	private String onmResourceCategoryCd;
	private String onmResourceCategoryCdName;
	private String onmResourceName;
	private String onmAlarmCdName;
	private Integer criticalgStandardVal;
	private Integer majorgStandardVal;
	private Integer minorgStandardVal;
	private String registerId;
	private String registerName;
	private String registDatetime;
	private String auditDatetime;
	
}
