package com.adtcaps.tsop.onm.api.address.service.impl;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.adtcaps.tsop.onm.api.address.domain.CtPvcNameForComboResultDto;
import com.adtcaps.tsop.onm.api.address.domain.StreetnameAddressGridRequestDto;
import com.adtcaps.tsop.onm.api.address.domain.StreetnameAddressGridResultDto;
import com.adtcaps.tsop.onm.api.address.mapper.OomStreetnameAddressMapper;
import com.adtcaps.tsop.onm.api.address.service.AddressService;

/**
 * 
 * <ul>
 * <li>업무 그룹명 : tsop-onm-api</li>
 * <li>서브 업무명 : com.adtcaps.tsop.onm.api.address.service.impl</li>
 * <li>설  명 : AddressServiceImpl.java</li>
 * <li>작성일 : 2021. 2. 2.</li>
 * <li>작성자 : jeonyb4</li>
 * </ul>
 */
@Service
public class AddressServiceImpl implements AddressService {
	
	@Autowired
	private OomStreetnameAddressMapper oomStreetnameAddressMapper;
	
	/**
	 * 
	 * listCtPvcNameForCombo
	 *
	 * @return List<CtPvcNameForComboResultDto>
	 * @throws Exception 
	 */
	@Override
	public List<CtPvcNameForComboResultDto> listCtPvcNameForCombo() throws Exception {
		
		List<CtPvcNameForComboResultDto> ctPvcNameForComboResultDtoList = null;
		try {
			ctPvcNameForComboResultDtoList = oomStreetnameAddressMapper.listCtPvcNameForCombo();
    		
		} catch (Exception e) {
			throw e;
		}
		return ctPvcNameForComboResultDtoList;
	}
	
	/**
	 * 
	 * listCtGunGuNameForCombo
	 *
	 * @param ctPvcNameForComboResultDto
	 * @return List<CtPvcNameForComboResultDto>
	 * @throws Exception 
	 */
	@Override
	public List<CtPvcNameForComboResultDto> listCtGunGuNameForCombo(CtPvcNameForComboResultDto ctPvcNameForComboResultDto) throws Exception {
		
		List<CtPvcNameForComboResultDto> ctPvcNameForComboResultDtoList = null;
		try {
			ctPvcNameForComboResultDtoList = oomStreetnameAddressMapper.listCtGunGuNameForCombo(ctPvcNameForComboResultDto);
    		
		} catch (Exception e) {
			throw e;
		}
		return ctPvcNameForComboResultDtoList;
	}
	
	/**
	 * 
	 * listPageStreetnameAddress
	 *
	 * @param streetnameAddressGridRequestDto
	 * @return List<StreetnameAddressGridResultDto>
	 * @throws Exception 
	 */
	@Override
	public List<StreetnameAddressGridResultDto> listPageStreetnameAddress(StreetnameAddressGridRequestDto streetnameAddressGridRequestDto) throws Exception {
		
		List<StreetnameAddressGridResultDto> streetnameAddressGridResultDtoList = null;
		try {
			String searchKeyword = StringUtils.defaultString(streetnameAddressGridRequestDto.getSearchKeyword());
			String[] searchKeywordArr = StringUtils.split(searchKeyword, " ");
			
			List<String> searchKeywordList = new ArrayList<String>();
			for (int idx=0; idx < searchKeywordArr.length; idx++) {
				searchKeywordList.add(searchKeywordArr[idx]);
			}
			streetnameAddressGridRequestDto.setSearchKeywordList(searchKeywordList);
			
			streetnameAddressGridResultDtoList = oomStreetnameAddressMapper.listPageStreetnameAddress(streetnameAddressGridRequestDto);
    		
		} catch (Exception e) {
			throw e;
		}
		return streetnameAddressGridResultDtoList;
	}

}
