package com.adtcaps.tsop.onm.api.alarm.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;

import com.adtcaps.tsop.onm.api.alarm.domain.AlarmNoticeReceiveGroupDetailResultDto;
import com.adtcaps.tsop.onm.api.alarm.domain.AlarmNoticeReceiveGroupForComboResultDto;
import com.adtcaps.tsop.onm.api.alarm.domain.AlarmNoticeReceiveGroupGridRequestDto;
import com.adtcaps.tsop.onm.api.alarm.domain.AlarmNoticeReceiveGroupGridResultDto;
import com.adtcaps.tsop.onm.api.domain.OomAlarmNoticeReceiveGroupDto;


/**
 * 
 * <ul>
 * <li>업무 그룹명 : tsop-onm-api</li>
 * <li>서브 업무명 : com.adtcaps.tsop.onm.api.alarm.mapper</li>
 * <li>설  명 : OomAlarmNoticeReceiveGroupMapper.java</li>
 * <li>작성일 : 2021. 1. 8.</li>
 * <li>작성자 : jeonyb4</li>
 * </ul>
 */
@Mapper
public interface OomAlarmNoticeReceiveGroupMapper {
	/**
	 * 
	 * listBuildingAlarmNoticeReceiveGroupForCombo
	 *
	 * @return List<AlarmNoticeReceiveGroupForComboResultDto>
	 */
	public List<AlarmNoticeReceiveGroupForComboResultDto> listAlarmNoticeReceiveGroupForCombo();
	
	/**
	 * 
	 * listPageAlarmNoticeReceiveGroup
	 *
	 * @param alarmNoticeConditionGridRequestDto
	 * @return List<AlarmNoticeReceiveGroupGridResultDto>
	 */
	public List<AlarmNoticeReceiveGroupGridResultDto> listPageAlarmNoticeReceiveGroup(AlarmNoticeReceiveGroupGridRequestDto alarmNoticeConditionGridRequestDto);
	
	/**
	 * 
	 * createOomAlarmNoticeReceiveGroup
	 *
	 * @param reqOomAlarmNoticeReceiveGroupDto
	 * @return int
	 */
	public int createOomAlarmNoticeReceiveGroup(OomAlarmNoticeReceiveGroupDto reqOomAlarmNoticeReceiveGroupDto);
	
	/**
	 * 
	 * readAlarmNoticeReceiveGroup
	 *
	 * @param reqOomAlarmNoticeReceiveGroupDto
	 * @return AlarmNoticeReceiveGroupDetailResultDto
	 */
	public AlarmNoticeReceiveGroupDetailResultDto readAlarmNoticeReceiveGroup(OomAlarmNoticeReceiveGroupDto reqOomAlarmNoticeReceiveGroupDto);
	
	/**
	 * 
	 * updateOomAlarmNoticeReceiveGroup
	 *
	 * @param reqOomAlarmNoticeReceiveGroupDto
	 * @return int
	 */
	public int updateOomAlarmNoticeReceiveGroup(OomAlarmNoticeReceiveGroupDto reqOomAlarmNoticeReceiveGroupDto);
	
	/**
	 * 
	 * deleteOomAlarmNoticeReceiveGroup
	 *
	 * @param reqOomAlarmNoticeReceiveGroupDto
	 * @return int
	 */
	public int deleteOomAlarmNoticeReceiveGroup(OomAlarmNoticeReceiveGroupDto reqOomAlarmNoticeReceiveGroupDto);
	
	/**
	 * 
	 * updateAlarmReceiveGroupReuse
	 *
	 * @param reqOomAlarmNoticeReceiveGroupDto
	 * @return int
	 */
	public int updateAlarmReceiveGroupReuse(OomAlarmNoticeReceiveGroupDto reqOomAlarmNoticeReceiveGroupDto);
	
	/**
	 * 
	 * getAlarmReceiveGroupCount
	 *
	 * @param reqOomAlarmNoticeReceiveGroupDto
	 * @return int
	 */
	public int getAlarmReceiveGroupCount(OomAlarmNoticeReceiveGroupDto reqOomAlarmNoticeReceiveGroupDto);
	
}
