package com.adtcaps.tsop.onm.api.work.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;

import com.adtcaps.tsop.onm.api.domain.OomWorkTenantResourceDetailDto;
import com.adtcaps.tsop.onm.api.work.domain.WorkTenantResourceDetailDto;

/**
 * 
 * <ul>
 * <li>업무 그룹명 : tsop-onm-api</li>
 * <li>서브 업무명 : com.adtcaps.tsop.onm.api.work.mapper</li>
 * <li>설  명 : OomWorkTenantResourceDetailMapper.java</li>
 * <li>작성일 : 2021. 1. 30.</li>
 * <li>작성자 : jeonyb4</li>
 * </ul>
 */
@Mapper
public interface OomWorkTenantResourceDetailMapper {
	/**
	 * 
	 * createOomWorkTenantResourceDetail
	 *
	 * @param reqOomWorkTenantResourceDetailDto
	 * @return int
	 */
	public int createOomWorkTenantResourceDetail(OomWorkTenantResourceDetailDto reqOomWorkTenantResourceDetailDto);
	
	/**
	 * 
	 * deleteOomWorkTenantResourceDetail
	 *
	 * @param reqOomWorkTenantResourceDetailDto
	 * @return int
	 */
	public int deleteOomWorkTenantResourceDetail(OomWorkTenantResourceDetailDto reqOomWorkTenantResourceDetailDto);
	
	/**
	 * 
	 * listOomWorkTenantResourceDetail
	 *
	 * @param reqOomWorkTenantResourceDetailDto
	 * @return List<OomWorkTenantResourceDetailDto>
	 */
	public List<OomWorkTenantResourceDetailDto> listOomWorkTenantResourceDetail(OomWorkTenantResourceDetailDto reqOomWorkTenantResourceDetailDto);
	
	/**
	 * 
	 * updateWorkTenantResourceDetailSuperResourceIdByName
	 *
	 * @param reqOomWorkTenantResourceDetailDto
	 * @return int
	 */
	public int updateWorkTenantResourceDetailSuperResourceIdByName(OomWorkTenantResourceDetailDto reqOomWorkTenantResourceDetailDto);
	
	/**
	 * 
	 * listWorkTenantResourceDetailExcel
	 *
	 * @param reqOomWorkTenantResourceDetailDto
	 * @return List<WorkTenantResourceDetailDto>
	 */
	public List<WorkTenantResourceDetailDto> listWorkTenantResourceDetailExcel(OomWorkTenantResourceDetailDto reqOomWorkTenantResourceDetailDto);
	
	/**
	 * 
	 * createTenantResourceDetailFromWork
	 *
	 * @param reqOomWorkTenantResourceDetailDto
	 * @return int
	 */
	public int createTenantResourceDetailFromWork(OomWorkTenantResourceDetailDto reqOomWorkTenantResourceDetailDto);

}
