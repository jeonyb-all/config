package com.adtcaps.tsop.onm.api.user.service.impl;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.CollectionUtils;

import com.adtcaps.tsop.onm.api.alimTalk.domain.AlimTalkDetailDto;
import com.adtcaps.tsop.onm.api.alimTalk.domain.AlimTalkRequestDto;
import com.adtcaps.tsop.onm.api.alimTalk.mapper.OomKakaoAlimTalkMapper;
import com.adtcaps.tsop.onm.api.alimTalk.service.AlimTalkService;
import com.adtcaps.tsop.onm.api.domain.OomKakaoAlimTalkDto;
import com.adtcaps.tsop.onm.api.domain.OomUserDto;
import com.adtcaps.tsop.onm.api.domain.OomUserPasswordInitializeDto;
import com.adtcaps.tsop.onm.api.domain.OomUserRoleDetailDto;
import com.adtcaps.tsop.onm.api.helper.constant.Const;
import com.adtcaps.tsop.onm.api.helper.util.CommonDateUtil;
import com.adtcaps.tsop.onm.api.helper.util.CommonObjectUtil;
import com.adtcaps.tsop.onm.api.user.domain.UserProcessingDto;
import com.adtcaps.tsop.onm.api.user.domain.UserDetailResultDto;
import com.adtcaps.tsop.onm.api.user.domain.UserForShortGridRequestDto;
import com.adtcaps.tsop.onm.api.user.domain.UserForShortGridResultDto;
import com.adtcaps.tsop.onm.api.user.domain.UserGridRequestDto;
import com.adtcaps.tsop.onm.api.user.domain.UserGridResultDto;
import com.adtcaps.tsop.onm.api.user.mapper.OomUserMapper;
import com.adtcaps.tsop.onm.api.user.mapper.OomUserPasswordInitializeMapper;
import com.adtcaps.tsop.onm.api.user.service.UserRoleService;
import com.adtcaps.tsop.onm.api.user.service.UserService;

/**
 * 
 * <ul>
 * <li>업무 그룹명 : tsop-onm-api</li>
 * <li>서브 업무명 : com.adtcaps.tsop.onm.api.user.service.impl</li>
 * <li>설  명 : UserServiceImpl.java</li>
 * <li>작성일 : 2021. 1. 4.</li>
 * <li>작성자 : jeonyb4</li>
 * </ul>
 */
@Transactional
@Service
public class UserServiceImpl implements UserService {
	
	@Autowired
	private OomUserMapper oomUserMapper;
	
	@Autowired
	private OomUserPasswordInitializeMapper oomUserPasswordInitializeMapper;
	
	@Autowired
	private UserRoleService userRoleService;
	
	@Autowired
	private OomKakaoAlimTalkMapper oomKakaoAlimTalkMapper;
	
	@Autowired
	private AlimTalkService alimTalkService;
	
	/**
	 * 
	 * readUserPasswordEqualCheck
	 *
	 * @param reqOomUserDto
	 * @return int
	 * @throws Exception 
	 */
	@Override
	public int readUserPasswordEqualCheck(OomUserDto reqOomUserDto) throws Exception {
		
		int compareResult = 0;
		try {
			compareResult = oomUserMapper.readUserPasswordEqualCheck(reqOomUserDto);
		} catch (Exception e) {
			throw e;
		}
		return compareResult;
	}
	
	/**
	 * 
	 * updateMyInfo
	 *
	 * @param reqOomUserDto
	 * @return int
	 * @throws Exception 
	 */
	@Override
	public int updateMyInfo(OomUserDto reqOomUserDto) throws Exception {
		
		int affectRowCount = 0;
		
		try {
			// 내정보 수정...
			int updateRow = oomUserMapper.updateMyProfile(reqOomUserDto);
			affectRowCount = affectRowCount + updateRow;
			
		} catch (Exception e) {
			throw e;
		}
		
		return affectRowCount;
	}
	
	/**
	 * 
	 * updateUserPassword
	 *
	 * @param reqOomUserDto
	 * @return int
	 * @throws Exception 
	 */
	@Override
	public int updateUserPassword(OomUserDto reqOomUserDto) throws Exception {
		
		int affectRowCount = 0;
		
		try {
			String userId = reqOomUserDto.getUserId();
			String auditId = reqOomUserDto.getAuditId();
			// 사용자 패스워드 업데이트...
			int updateRow = oomUserMapper.updateUserPassword(reqOomUserDto);
			affectRowCount = affectRowCount + updateRow;
			// 사용자비밀번호초기화내역 등록...
			OomUserPasswordInitializeDto reqOomUserPasswordInitializeDto = new OomUserPasswordInitializeDto();
			reqOomUserPasswordInitializeDto.setUserId(userId);
			reqOomUserPasswordInitializeDto.setAuditId(auditId);
			int insertRow = oomUserPasswordInitializeMapper.createOomUserPasswordInitialize(reqOomUserPasswordInitializeDto);
			affectRowCount = affectRowCount + insertRow;
			
		} catch (Exception e) {
			throw e;
		}
		
		return affectRowCount;
	}
	
	/**
	 * 
	 * listUserForShortGrid
	 *
	 * @param userForShortGridRequestDto
	 * @return List<UserForShortGridResultDto>
	 * @throws Exception 
	 */
	@Override
	public List<UserForShortGridResultDto> listUserForShortGrid(UserForShortGridRequestDto userForShortGridRequestDto) throws Exception {
		
		List<UserForShortGridResultDto> userForShortGridResultDtoList = null;
		try {
			userForShortGridResultDtoList = oomUserMapper.listUserForShortGrid(userForShortGridRequestDto);
    		
		} catch (Exception e) {
			throw e;
		}
		return userForShortGridResultDtoList;
	}
	
	/**
	 * 
	 * listPageUser
	 *
	 * @param userGridRequestDto
	 * @return List<UserGridResultDto>
	 * @throws Exception 
	 */
	@Override
	public List<UserGridResultDto> listPageUser(UserGridRequestDto userGridRequestDto) throws Exception {
		
		List<UserGridResultDto> userGridResultDtoList = null;
		try {
			String fromDate = userGridRequestDto.getFromDate();
    		String toDate = userGridRequestDto.getToDate();
    		
    		fromDate = CommonDateUtil.makeFromDatetimeForCompareDatetime(fromDate);
    		toDate = CommonDateUtil.makeToDatetimeForCompareDatetime(toDate);
    		
    		userGridRequestDto.setFromDate(fromDate);
    		userGridRequestDto.setToDate(toDate);
    		
    		userGridResultDtoList = oomUserMapper.listPageUser(userGridRequestDto);
    		if (!CollectionUtils.isEmpty(userGridResultDtoList)) {
    			for (int idx=0; idx < userGridResultDtoList.size(); idx++) {
    				UserGridResultDto userGridResultDto = userGridResultDtoList.get(idx);
    				
    				String useYn = StringUtils.defaultString(userGridResultDto.getUseYn());
    				if ("Y".equals(useYn)) {
    					userGridResultDto.setUseYn(Const.Definition.USE_YN.USE);
    				} else {
    					userGridResultDto.setUseYn(Const.Definition.USE_YN.NO_USE);
    				}
    				
    				userGridResultDtoList.set(idx, userGridResultDto);
    			}
    		}
    		
		} catch (Exception e) {
			throw e;
		}
		return userGridResultDtoList;
	}
	
	/**
	 * 
	 * updateUserInitialPassword
	 *
	 * @param reqOomUserDto
	 * @return int
	 * @throws Exception 
	 */
	@Override
	public int updateUserInitialPassword(OomUserDto reqOomUserDto) throws Exception {
		
		int affectRowCount = 0;
		
		try {
			String userId = reqOomUserDto.getUserId();
			String auditId = reqOomUserDto.getAuditId();
			String userName = "";
			UserDetailResultDto userDetailResultDto = oomUserMapper.readOomUser(reqOomUserDto);
			if (userDetailResultDto != null) {
				userName = StringUtils.defaultString(userDetailResultDto.getUserName());
			}
			
			// 패스워드 생성...
			String randomPassword = CommonObjectUtil.makeRandomPassword();
			// 사용자 패스워드 초기화 업데이트...
			reqOomUserDto.setLoginPassword(randomPassword);
			int updateRow = oomUserMapper.updateUserPassword(reqOomUserDto);
			affectRowCount = affectRowCount + updateRow;
			// 사용자비밀번호초기화내역 등록...
			OomUserPasswordInitializeDto reqOomUserPasswordInitializeDto = new OomUserPasswordInitializeDto();
			reqOomUserPasswordInitializeDto.setUserId(userId);
			reqOomUserPasswordInitializeDto.setAuditId(auditId);
			int insertRow = oomUserPasswordInitializeMapper.createOomUserPasswordInitialize(reqOomUserPasswordInitializeDto);
			affectRowCount = affectRowCount + insertRow;
			
			// 알림톡 발송 처리...
			String contactPhoneNum = StringUtils.defaultString(reqOomUserDto.getContactPhoneNum());
			OomKakaoAlimTalkDto reqOomKakaoAlimTalkDto = new OomKakaoAlimTalkDto();
			reqOomKakaoAlimTalkDto.setTmpltCode(Const.Definition.MSG_TEMPLATE_CODE.TSOP_004);
			reqOomKakaoAlimTalkDto.setSmsCreateCd(Const.Code.SMS_CREATE_CD.PASSWORD);
			OomKakaoAlimTalkDto oomKakaoAlimTalkDto = oomKakaoAlimTalkMapper.readKakaoAlimTalk(reqOomKakaoAlimTalkDto);
			if (oomKakaoAlimTalkDto != null) {
				List<AlimTalkDetailDto> alimTalkDetailDtoList = new ArrayList<AlimTalkDetailDto>();
				String rcverId = userId;
				String rcverName = userName;
				String rcvPhoneNum = contactPhoneNum;
				AlimTalkDetailDto alimTalkDetailDto = new AlimTalkDetailDto();
				alimTalkDetailDto.setRcverId(rcverId);
				alimTalkDetailDto.setRcverName(rcverName);
				alimTalkDetailDto.setRcvPhoneNum(rcvPhoneNum);
				alimTalkDetailDtoList.add(alimTalkDetailDto);
				
				String message = oomKakaoAlimTalkDto.getMessage();
				message = message.replaceAll("#\\{\"초기화\"\\}", "초기화");
				message = message.replaceAll("#\\{\"abcd1234\"\\}", randomPassword);
				
				// 카카오 알림톡 발송 처리..
				AlimTalkRequestDto alimTalkRequestDto = new AlimTalkRequestDto();
				alimTalkRequestDto.setTmpltCode(Const.Definition.MSG_TEMPLATE_CODE.TSOP_004);
				alimTalkRequestDto.setRecipient(contactPhoneNum);
				alimTalkRequestDto.setMessage(message);
				alimTalkRequestDto.setSmsCreateCd(Const.Code.SMS_CREATE_CD.PASSWORD);
				alimTalkRequestDto.setAuditId(auditId);
				alimTalkRequestDto.setDetailList(alimTalkDetailDtoList);
				String alarmNoticeResultCd = alimTalkService.sendOnmAlimTalk(alimTalkRequestDto);
				if (!"1".equals(alarmNoticeResultCd)) {
					// 성공이 아니면.. 모두 실패 처리...
					affectRowCount = -9999;
				}
			}
			
		} catch (Exception e) {
			throw e;
		}
		
		return affectRowCount;
	}
	
	/**
	 * 
	 * readUserDuplicationCheck
	 *
	 * @param reqOomUserDto
	 * @return int
	 * @throws Exception 
	 */
	@Override
	public int readUserDuplicationCheck(OomUserDto reqOomUserDto) throws Exception {
		
		int userCount = 1;
		try {
			userCount = oomUserMapper.readUserDuplicationCheck(reqOomUserDto);
		} catch (Exception e) {
			throw e;
		}
		return userCount;
	}
	
	/**
	 * 
	 * readUserDuplicationServiceOper
	 *
	 * @param reqOomUserDto
	 * @return int
	 * @throws Exception 
	 */
	@Override
	public int readUserDuplicationServiceOper(OomUserDto reqOomUserDto) throws Exception {
		
		int userCount = 1;
		try {
			userCount = oomUserMapper.readUserDuplicationServiceOper(reqOomUserDto);
		} catch (Exception e) {
			throw e;
		}
		return userCount;
	}
	
	/**
	 * 
	 * createUser
	 *
	 * @param reqUserProcessingDto
	 * @return int
	 * @throws Exception 
	 */
	@Override
	public int createUser(UserProcessingDto reqUserProcessingDto) throws Exception {
		
		int affectRowCount = 0;
		
		try {
			// 패스워드 생성...
			String randomPassword = CommonObjectUtil.makeRandomPassword();
			// 사용자 등록...
			OomUserDto reqOomUserDto = new OomUserDto();
			BeanUtils.copyProperties(reqUserProcessingDto, reqOomUserDto);
			reqOomUserDto.setLoginPassword(randomPassword);
			int insertRow = oomUserMapper.createOomUser(reqOomUserDto);
			affectRowCount = affectRowCount + insertRow;
			
			// 사용자별 메뉴그룹 등록...
			String userId = reqUserProcessingDto.getUserId();
			String roleId = reqUserProcessingDto.getRoleId();
			String auditId = reqUserProcessingDto.getAuditId();
			OomUserRoleDetailDto reqOomUserRoleDetailDto = new OomUserRoleDetailDto();
			reqOomUserRoleDetailDto.setUserId(userId);
			reqOomUserRoleDetailDto.setRoleId(roleId);
			reqOomUserRoleDetailDto.setAuditId(auditId);
			insertRow = userRoleService.createUserRoleDetail(reqOomUserRoleDetailDto);
			affectRowCount = affectRowCount + insertRow;
			
			// SMS 발송 처리...
			String userName = StringUtils.defaultString(reqOomUserDto.getUserName());
			String contactPhoneNum = StringUtils.defaultString(reqOomUserDto.getContactPhoneNum());
			OomKakaoAlimTalkDto reqOomKakaoAlimTalkDto = new OomKakaoAlimTalkDto();
			reqOomKakaoAlimTalkDto.setTmpltCode(Const.Definition.MSG_TEMPLATE_CODE.TSOP_004);
			reqOomKakaoAlimTalkDto.setSmsCreateCd(Const.Code.SMS_CREATE_CD.PASSWORD);
			OomKakaoAlimTalkDto oomKakaoAlimTalkDto = oomKakaoAlimTalkMapper.readKakaoAlimTalk(reqOomKakaoAlimTalkDto);
			if (oomKakaoAlimTalkDto != null) {
				List<AlimTalkDetailDto> alimTalkDetailDtoList = new ArrayList<AlimTalkDetailDto>();
				String rcverId = userId;
				String rcverName = userName;
				String rcvPhoneNum = contactPhoneNum;
				AlimTalkDetailDto alimTalkDetailDto = new AlimTalkDetailDto();
				alimTalkDetailDto.setRcverId(rcverId);
				alimTalkDetailDto.setRcverName(rcverName);
				alimTalkDetailDto.setRcvPhoneNum(rcvPhoneNum);
				alimTalkDetailDtoList.add(alimTalkDetailDto);
				
				String message = oomKakaoAlimTalkDto.getMessage();
				message = message.replaceAll("#\\{\"초기화\"\\}", "등록");
				message = message.replaceAll("#\\{\"abcd1234\"\\}", randomPassword);
				
				// 카카오 알림톡 발송 처리..
				AlimTalkRequestDto alimTalkRequestDto = new AlimTalkRequestDto();
				alimTalkRequestDto.setTmpltCode(Const.Definition.MSG_TEMPLATE_CODE.TSOP_004);
				alimTalkRequestDto.setRecipient(contactPhoneNum);
				alimTalkRequestDto.setMessage(message);
				alimTalkRequestDto.setSmsCreateCd(Const.Code.SMS_CREATE_CD.PASSWORD);
				alimTalkRequestDto.setAuditId(auditId);
				alimTalkRequestDto.setDetailList(alimTalkDetailDtoList);
				String alarmNoticeResultCd = alimTalkService.sendOnmAlimTalk(alimTalkRequestDto);
				if (!"1".equals(alarmNoticeResultCd)) {
					// 성공이 아니면.. 모두 실패 처리...
					affectRowCount = -9999;
				}
			}
		} catch (Exception e) {
			throw e;
		}
		
		return affectRowCount;
	}
	
	/**
	 * 
	 * readUser
	 *
	 * @param reqOomUserDto
	 * @return UserDetailResultDto
	 * @throws Exception 
	 */
	@Override
	public UserDetailResultDto readUser(OomUserDto reqOomUserDto) throws Exception {
		
		UserDetailResultDto userDetailResultDto = null;
		try {
			userDetailResultDto = oomUserMapper.readOomUser(reqOomUserDto);
		} catch (Exception e) {
			throw e;
		}
		return userDetailResultDto;
	}
	
	/**
	 * 
	 * updateUser
	 *
	 * @param reqUserProcessingDto
	 * @return int
	 * @throws Exception 
	 */
	@Override
	public int updateUser(UserProcessingDto reqUserProcessingDto) throws Exception {
		
		int affectRowCount = 0;
		
		try {
			String userId = reqUserProcessingDto.getUserId();
			String roleId = reqUserProcessingDto.getRoleId();
			String auditId = reqUserProcessingDto.getAuditId();
			
			// 사용자별 메뉴그룹 수정...
			OomUserRoleDetailDto reqOomUserRoleDetailDto = new OomUserRoleDetailDto();
			reqOomUserRoleDetailDto.setUserId(userId);
			reqOomUserRoleDetailDto.setRoleId(roleId);
			reqOomUserRoleDetailDto.setAuditId(auditId);
			int udpateRow = userRoleService.updateUserRoleDetail(reqOomUserRoleDetailDto);
			affectRowCount = affectRowCount + udpateRow;
			
			// 사용자 수정...
			OomUserDto reqOomUserDto = new OomUserDto();
			BeanUtils.copyProperties(reqUserProcessingDto, reqOomUserDto);
			int updateRow = oomUserMapper.updateOomUser(reqOomUserDto);
			affectRowCount = affectRowCount + updateRow;
			
		} catch (Exception e) {
			throw e;
		}
		
		return affectRowCount;
	}
	
	/**
	 * 
	 * deleteUser
	 *
	 * @param reqOomUserDto
	 * @return int
	 * @throws Exception 
	 */
	@Override
	public int deleteUser(OomUserDto reqOomUserDto) throws Exception {
		
		int affectRowCount = 0;
		
		try {
			// 사용자 삭제...
			int deleteRow = oomUserMapper.deleteOomUser(reqOomUserDto);
			affectRowCount = affectRowCount + deleteRow;
			
		} catch (Exception e) {
			throw e;
		}
		
		return affectRowCount;
	}
	
	/**
	 * 
	 * readServiceOperUserInfoForTenantId
	 *
	 * @param reqOomUserDto
	 * @return OomUserDto
	 * @throws Exception 
	 */
	@Override
	public OomUserDto readServiceOperUserInfoForTenantId(OomUserDto reqOomUserDto) throws Exception {
		
		OomUserDto rsltOomUserDto = null;
		try {
			rsltOomUserDto = oomUserMapper.readServiceOperUserInfoForTenantId(reqOomUserDto);
		} catch (Exception e) {
			throw e;
		}
		return rsltOomUserDto;
	}

}
