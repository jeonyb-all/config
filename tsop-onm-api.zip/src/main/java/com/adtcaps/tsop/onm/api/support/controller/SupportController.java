package com.adtcaps.tsop.onm.api.support.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.util.CollectionUtils;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.adtcaps.tsop.onm.api.authentication.domain.JwtAuthResultDto;
import com.adtcaps.tsop.onm.api.domain.OomTechSupportRequestDto;
import com.adtcaps.tsop.onm.api.domain.OomUserRoleAuthorityDetailDto;
import com.adtcaps.tsop.onm.api.helper.constant.Const;
import com.adtcaps.tsop.onm.api.helper.domain.ResultDto;
import com.adtcaps.tsop.onm.api.helper.util.PageUtil;
import com.adtcaps.tsop.onm.api.support.domain.TechSupportRequestGridRequestDto;
import com.adtcaps.tsop.onm.api.support.domain.TechSupportRequestGridResultDto;
import com.adtcaps.tsop.onm.api.support.domain.TechSupportResultDetailResultDto;
import com.adtcaps.tsop.onm.api.support.service.SupportService;
import com.adtcaps.tsop.onm.api.user.domain.UserRoleMenuAuthorityRequestDto;
import com.adtcaps.tsop.onm.api.user.service.UserRoleService;

import lombok.extern.slf4j.Slf4j;

/**
 * 
 * <ul>
 * <li>업무 그룹명 : tsop-onm-api</li>
 * <li>서브 업무명 : com.adtcaps.tsop.onm.api.support.controller</li>
 * <li>설  명 : SupportController.java</li>
 * <li>작성일 : 2021. 1. 3.</li>
 * <li>작성자 : jeonyb4</li>
 * </ul>
 */
@Slf4j
@RestController
@RequestMapping("/api/supports")
public class SupportController {
	
	private final String MENU_ID = "ONM0017";
	
	private final String ERR_MSG_NULL_LOGIN_USER_ID = "로그인 사용자ID가 없습니다.";
	private final String ERR_MSG_NULL_MGR_YN = "관리자여부가 없습니다.";
	private final String ERR_MSG_NULL_PAGE_NUMBER = "페이지 번호가 없습니다.";
	private final String ERR_MSG_NULL_SERACH_DATE = "조회기간(From or To)이 없습니다.";
	private final String ERR_MSG_NULL_TENANT_ID = "테넌트ID가 없습니다.";
	private final String ERR_MSG_NULL_TECH_SUPPORT_TYPE_CD = "기술지원유형코드가 없습니다.";
	private final String ERR_MSG_NULL_TECH_SUPPORT_STATUS_CD = "기술지원상태코드가 없습니다.";
	
	private final String ERR_MSG_NOT_FOUND_TECH_SUPPORT_REQUEST = "해당 기술지원요청을 찾을 수 없습니다.";
	private final String ERR_MSG_ALREADY_CHANGE_SUPPORT_STATUS = "해당 기술지원요청에 대한 상태가 이미 변경되어 저장할 수 없습니다.";
	
	private final String ERR_MSG_NO_AUTH = "권한이 없는 사용자 입니다.";
	private final String ERR_MSG_NULL_SEARCH_RESULT_LIST = "조회 결과가 없습니다.";
	private final String ERR_MSG_READ_FAIL = "조회에 실패하였습니다.";
	private final String ERR_MSG_UPDATE_FAIL = "수정에 실패하였습니다.";
	
	@Autowired
	private SupportService supportService;
	
	@Autowired
	private UserRoleService userRoleService;
	
	/**
	 * 
	 * listPageTechSupportRequest
	 *
	 * @param techSupportRequestGridRequestDto
	 * @return ResponseEntity
	 */
	@SuppressWarnings("rawtypes")
    @GetMapping(value="", produces="application/json; charset=UTF-8")
    public ResponseEntity listPageTechSupportRequest(TechSupportRequestGridRequestDto techSupportRequestGridRequestDto) throws Exception {
        
    	ResponseEntity<ResultDto> resEntity = null;
		String returnString = "";
    	
		int pageNumber = techSupportRequestGridRequestDto.getPageNumber();
		if (pageNumber < 1) {
			log.error(">>>>>> pageNumber ERROR:{}", ERR_MSG_NULL_PAGE_NUMBER);
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_PAGE_NUMBER));
			return resEntity;
		}
		String fromDate = techSupportRequestGridRequestDto.getFromDate();
		String toDate = techSupportRequestGridRequestDto.getToDate();
		if ("".equals(fromDate) || "".equals(toDate)) {
			log.error(">>>>>> fromDate or toDate ERROR:{}", ERR_MSG_NULL_SERACH_DATE);
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_SERACH_DATE));
			return resEntity;
		}
		// 기술지원요청 목록 조회....
		Map<String, Object> techSupportRequestGridResultDtoListMap = new HashMap<String, Object>();
		List<TechSupportRequestGridResultDto> techSupportRequestGridResultDtoList = supportService.listPageTechSupportRequest(techSupportRequestGridRequestDto);
		if (CollectionUtils.isEmpty(techSupportRequestGridResultDtoList)) {
			returnString = Const.Common.RESULT_CODE.SUCCESS;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_SEARCH_RESULT_LIST, techSupportRequestGridResultDtoListMap));
		} else {
			returnString = Const.Common.RESULT_CODE.SUCCESS;
			techSupportRequestGridResultDtoListMap.put(Const.Definition.PAGE.PAGER, PageUtil.getPageInfo(techSupportRequestGridResultDtoList));
			techSupportRequestGridResultDtoListMap.put(Const.Definition.PAGE.LISTS, techSupportRequestGridResultDtoList);
			resEntity = ResponseEntity.ok(new ResultDto(returnString, "", techSupportRequestGridResultDtoListMap));
		}
    	
    	return resEntity;
    }
	
	/**
	 * 
	 * readTechSupportRequest
	 *
	 * @param techSupportReqId
	 * @param reqOomTechSupportRequestDto
	 * @return ResponseEntity
	 */
	@SuppressWarnings("rawtypes")
    @GetMapping(value="/{techSupportReqId}", produces="application/json; charset=UTF-8")
    public ResponseEntity readTechSupportRequest(@PathVariable("techSupportReqId") int techSupportReqId, OomTechSupportRequestDto reqOomTechSupportRequestDto) throws Exception {
        
    	ResponseEntity<ResultDto> resEntity = null;
		String returnString = "";
    	
		String tenantId = StringUtils.defaultString(reqOomTechSupportRequestDto.getTenantId());
		if ("".equals(tenantId)) {
			log.error(">>>>>> tenantId ERROR:{}", ERR_MSG_NULL_TENANT_ID);
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_TENANT_ID));
			return resEntity;
		}
		
		reqOomTechSupportRequestDto.setTechSupportReqId(techSupportReqId);
		
		TechSupportResultDetailResultDto techSupportResultDetailResultDto = supportService.readTechSupportRequest(reqOomTechSupportRequestDto);
		if (techSupportResultDetailResultDto == null) {
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_READ_FAIL, techSupportResultDetailResultDto));
		} else {
			returnString = Const.Common.RESULT_CODE.SUCCESS;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, "", techSupportResultDetailResultDto));
		}
    	
    	return resEntity;
    }
	
	/**
	 * 
	 * updateTechSupportStatus
	 *
	 * @param authResultDto
	 * @param techSupportReqId
	 * @param reqOomTechSupportRequestDto
	 * @return ResponseEntity
	 */
	@SuppressWarnings("rawtypes")
    @PutMapping(value="/{techSupportReqId}", produces="application/json; charset=UTF-8")
	public ResponseEntity updateTechSupportStatus(@AuthenticationPrincipal JwtAuthResultDto authResultDto, 
			@PathVariable("techSupportReqId") int techSupportReqId, @RequestBody OomTechSupportRequestDto reqOomTechSupportRequestDto) throws Exception {
        
    	ResponseEntity<ResultDto> resEntity = null;
		String returnString = "";
    	
		String loginUserId = StringUtils.defaultString(authResultDto.getUserId());
		if ("".equals(loginUserId)) {
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_LOGIN_USER_ID));
			return resEntity;
		}
		String mgrYn = StringUtils.defaultString(authResultDto.getMgrYn());
		if ("".equals(mgrYn)) {
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_MGR_YN));
			return resEntity;
		}
		//String loginUserId = "tsop-admin"; // 이후 세션에서 얻어올 값...
		
		if (!"Y".equals(mgrYn)) {
			String authorityTypeCd = "";
			UserRoleMenuAuthorityRequestDto userRoleMenuAuthorityRequestDto = new UserRoleMenuAuthorityRequestDto();
			userRoleMenuAuthorityRequestDto.setUserId(loginUserId);
			userRoleMenuAuthorityRequestDto.setMenuId(MENU_ID);
			OomUserRoleAuthorityDetailDto rsltOomUserRoleAuthorityDetailDto = userRoleService.readMenuAuthority(userRoleMenuAuthorityRequestDto);
			if (rsltOomUserRoleAuthorityDetailDto != null) {
				authorityTypeCd = StringUtils.defaultString(rsltOomUserRoleAuthorityDetailDto.getAuthorityTypeCd());
			}
			if (!"W".equals(authorityTypeCd)) {
				returnString = Const.Common.RESULT_CODE.FAIL;
				resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NO_AUTH));
				return resEntity;
			}
		}
		
		String tenantId = StringUtils.defaultString(reqOomTechSupportRequestDto.getTenantId());
		if ("".equals(tenantId)) {
			log.error(">>>>>> tenantId ERROR:{}", ERR_MSG_NULL_TENANT_ID);
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_TENANT_ID));
			return resEntity;
		}
		String techSupportReqTypeCd = StringUtils.defaultString(reqOomTechSupportRequestDto.getTechSupportReqTypeCd());
		if ("".equals(techSupportReqTypeCd)) {
			log.error(">>>>>> techSupportReqTypeCd ERROR:{}", ERR_MSG_NULL_TECH_SUPPORT_TYPE_CD);
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_TECH_SUPPORT_TYPE_CD));
			return resEntity;
		}
		String techSupportStatusCd = StringUtils.defaultString(reqOomTechSupportRequestDto.getTechSupportStatusCd());
		if ("".equals(techSupportStatusCd)) {
			log.error(">>>>>> techSupportStatusCd ERROR:{}", ERR_MSG_NULL_TECH_SUPPORT_STATUS_CD);
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_TECH_SUPPORT_STATUS_CD));
			return resEntity;
		}
		
		reqOomTechSupportRequestDto.setTechSupportReqId(techSupportReqId);
		reqOomTechSupportRequestDto.setAuditId(loginUserId);
		
		// 상태값이 변경되었는 지 체크...
		TechSupportResultDetailResultDto techSupportResultDetailResultDto = supportService.readTechSupportRequest(reqOomTechSupportRequestDto);
		if (techSupportResultDetailResultDto == null) {
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NOT_FOUND_TECH_SUPPORT_REQUEST));
			return resEntity;
		} else {
			String getTechSupportStatusCd = techSupportResultDetailResultDto.getTechSupportStatusCd();
			if (!Const.Code.TECH_SUPPORT_STATUS_CD.REQUEST.equals(getTechSupportStatusCd)) {
				returnString = Const.Common.RESULT_CODE.FAIL;
				resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_ALREADY_CHANGE_SUPPORT_STATUS));
				return resEntity;
			}
		}
		
		// 기술지원요청 상태값 수정...
		ResultDto resultDto = supportService.updateTechSupportStatus(reqOomTechSupportRequestDto);
		if (resultDto == null) {
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_UPDATE_FAIL, resultDto));
		} else {
			resEntity = ResponseEntity.ok(resultDto);
		}
    	
    	return resEntity;
    }

}
