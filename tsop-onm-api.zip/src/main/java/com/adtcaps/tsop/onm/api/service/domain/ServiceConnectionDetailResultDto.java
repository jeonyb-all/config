package com.adtcaps.tsop.onm.api.service.domain;

import java.util.List;

import lombok.Getter;
import lombok.Setter;

/**
 * 
 * <ul>
 * <li>업무 그룹명 : tsop-onm-api</li>
 * <li>서브 업무명 : com.adtcaps.tsop.onm.api.service.domain</li>
 * <li>설  명 : ServiceConnectionDetailResultDto.java</li>
 * <li>작성일 : 2021. 1. 23.</li>
 * <li>작성자 : jeonyb4</li>
 * </ul>
 */
@Getter
@Setter
public class ServiceConnectionDetailResultDto {
	private String serviceClCd;
	private String serviceSysName;
	private String linkageStandardVersionVal;
	private String serviceClName;
	private String serviceSysLinkageMethodCd;
	private String serviceSysRcvFormCd;
	private String registDatetime;
	private Integer attachFileNum;
	private String attachFileName;
	private List<ServiceConnectionApiExcelDto> apiExcelList;

}
