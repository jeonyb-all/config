package com.adtcaps.tsop.onm.api.deploy.service;

import java.util.List;

import com.adtcaps.tsop.onm.api.deploy.domain.PackageDeployJobDetailResultDto;
import com.adtcaps.tsop.onm.api.deploy.domain.PackageDeployJobGridRequestDto;
import com.adtcaps.tsop.onm.api.deploy.domain.PackageDeployJobGridResultDto;
import com.adtcaps.tsop.onm.api.domain.OomPackageDeployJobDto;

/**
 * 
 * <ul>
 * <li>업무 그룹명 : tsop-onm-api</li>
 * <li>서브 업무명 : com.adtcaps.tsop.onm.api.deploy.service</li>
 * <li>설  명 : PackageDeployJobService.java</li>
 * <li>작성일 : 2021. 1. 31.</li>
 * <li>작성자 : jeonyb4</li>
 * </ul>
 */
public interface PackageDeployJobService {
	/**
	 * 
	 * mergePackageDeployJob
	 *
	 * @param reqOomPackageDeployJobDto
	 * @return int
	 * @throws Exception 
	 */
	public int mergePackageDeployJob(OomPackageDeployJobDto reqOomPackageDeployJobDto) throws Exception;
	
	/**
	 * 
	 * readPackageDeployJob
	 *
	 * @param reqOomPackageDeployJobDto
	 * @return PackageDeployJobDetailResultDto
	 * @throws Exception 
	 */
	public PackageDeployJobDetailResultDto readPackageDeployJob(OomPackageDeployJobDto reqOomPackageDeployJobDto) throws Exception;
	
	/**
	 * 
	 * readVerifyProcedureAttachFile
	 *
	 * @param reqOomPackageDeployJobDto
	 * @return PackageDeployJobDetailResultDto
	 * @throws Exception 
	 */
	public PackageDeployJobDetailResultDto readVerifyProcedureAttachFile(OomPackageDeployJobDto reqOomPackageDeployJobDto) throws Exception;
	
	/**
	 * 
	 * readWorkProcedureAttachFile
	 *
	 * @param reqOomPackageDeployJobDto
	 * @return PackageDeployJobDetailResultDto
	 * @throws Exception 
	 */
	public PackageDeployJobDetailResultDto readWorkProcedureAttachFile(OomPackageDeployJobDto reqOomPackageDeployJobDto) throws Exception;
	
	/**
	 * 
	 * readInspectionProcedureAttachFile
	 *
	 * @param reqOomPackageDeployJobDto
	 * @return PackageDeployJobDetailResultDto
	 * @throws Exception 
	 */
	public PackageDeployJobDetailResultDto readInspectionProcedureAttachFile(OomPackageDeployJobDto reqOomPackageDeployJobDto) throws Exception;
	
	/**
	 * 
	 * readDbScriptAttachFile
	 *
	 * @param reqOomPackageDeployJobDto
	 * @return PackageDeployJobDetailResultDto
	 * @throws Exception 
	 */
	public PackageDeployJobDetailResultDto readDbScriptAttachFile(OomPackageDeployJobDto reqOomPackageDeployJobDto) throws Exception;
	
	/**
	 * 
	 * readInspectionResultAttachFile
	 *
	 * @param reqOomPackageDeployJobDto
	 * @return PackageDeployJobDetailResultDto
	 * @throws Exception 
	 */
	public PackageDeployJobDetailResultDto readInspectionResultAttachFile(OomPackageDeployJobDto reqOomPackageDeployJobDto) throws Exception;
	
	/**
	 * 
	 * updateDeployWorkEndDatetime
	 *
	 * @param reqOomPackageDeployJobDto
	 * @return int
	 * @throws Exception 
	 */
	public int updateDeployWorkEndDatetime(OomPackageDeployJobDto reqOomPackageDeployJobDto) throws Exception;
	
	/**
	 * 
	 * deleteDeployVerifyProcedureAttachFile
	 *
	 * @param reqOomPackageDeployJobDto
	 * @return int
	 * @throws Exception 
	 */
	public int deleteDeployVerifyProcedureAttachFile(OomPackageDeployJobDto reqOomPackageDeployJobDto) throws Exception;
	
	/**
	 * 
	 * deleteDeployWorkProcedureAttachFile
	 *
	 * @param reqOomPackageDeployJobDto
	 * @return int
	 * @throws Exception 
	 */
	public int deleteDeployWorkProcedureAttachFile(OomPackageDeployJobDto reqOomPackageDeployJobDto) throws Exception;
	
	/**
	 * 
	 * deleteDeployInspectionProcedureAttachFile
	 *
	 * @param reqOomPackageDeployJobDto
	 * @return int
	 * @throws Exception 
	 */
	public int deleteDeployInspectionProcedureAttachFile(OomPackageDeployJobDto reqOomPackageDeployJobDto) throws Exception;
	
	/**
	 * 
	 * deleteDeployDbScriptAttachFile
	 *
	 * @param reqOomPackageDeployJobDto
	 * @return int
	 * @throws Exception 
	 */
	public int deleteDeployDbScriptAttachFile(OomPackageDeployJobDto reqOomPackageDeployJobDto) throws Exception;
	
	/**
	 * 
	 * deleteDeployInspectionResultAttachFile
	 *
	 * @param reqOomPackageDeployJobDto
	 * @return int
	 * @throws Exception 
	 */
	public int deleteDeployInspectionResultAttachFile(OomPackageDeployJobDto reqOomPackageDeployJobDto) throws Exception;
	
	/**
	 * 
	 * deleteOomPackageDeployJob
	 *
	 * @param reqOomPackageDeployJobDto
	 * @return int
	 * @throws Exception 
	 */
	public int deleteOomPackageDeployJob(OomPackageDeployJobDto reqOomPackageDeployJobDto) throws Exception;
	
	/**
	 * 
	 * listPagePackageDeployJob
	 *
	 * @param packageDeployJobGridRequestDto
	 * @return List<PackageDeployJobGridResultDto>
	 * @throws Exception 
	 */
	public List<PackageDeployJobGridResultDto> listPagePackageDeployJob(PackageDeployJobGridRequestDto packageDeployJobGridRequestDto) throws Exception;

}
