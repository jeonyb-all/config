package com.adtcaps.tsop.onm.api.alarm.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.util.CollectionUtils;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.adtcaps.tsop.onm.api.alarm.domain.AlarmCurrentStatusDetailResultDto;
import com.adtcaps.tsop.onm.api.alarm.domain.AlarmCurrentStatusGridRequestDto;
import com.adtcaps.tsop.onm.api.alarm.domain.AlarmCurrentStatusGridResultDto;
import com.adtcaps.tsop.onm.api.alarm.service.AlarmCurrentStatusService;
import com.adtcaps.tsop.onm.api.authentication.domain.JwtAuthResultDto;
import com.adtcaps.tsop.onm.api.domain.OomOnmAlarmCurrentStatusDto;
import com.adtcaps.tsop.onm.api.domain.OomUserRoleAuthorityDetailDto;
import com.adtcaps.tsop.onm.api.helper.constant.Const;
import com.adtcaps.tsop.onm.api.helper.domain.ResultDto;
import com.adtcaps.tsop.onm.api.helper.util.PageUtil;
import com.adtcaps.tsop.onm.api.user.domain.UserRoleMenuAuthorityRequestDto;
import com.adtcaps.tsop.onm.api.user.service.UserRoleService;

import lombok.extern.slf4j.Slf4j;

/**
 * 
 * <ul>
 * <li>업무 그룹명 : tsop-onm-api</li>
 * <li>서브 업무명 : com.adtcaps.tsop.onm.api.alarm.controller</li>
 * <li>설  명 : AlarmCurrentStatusController.java</li>
 * <li>작성일 : 2021. 2. 6.</li>
 * <li>작성자 : jeonyb4</li>
 * </ul>
 */
@Slf4j
@RestController
@RequestMapping("/api/alarm-status")
public class AlarmCurrentStatusController {
	
	private final String MENU_ID = "ONM0029";
	
	private final String ERR_MSG_NULL_LOGIN_USER_ID = "로그인 사용자ID가 없습니다.";
	private final String ERR_MSG_NULL_MGR_YN = "관리자여부가 없습니다.";
	private final String ERR_MSG_NULL_PAGE_NUMBER = "페이지 번호가 없습니다.";
	private final String ERR_MSG_NULL_TENANT_ID = "테넌트ID가 없습니다.";
	private final String ERR_MSG_NULL_RESOURCE_ID = "자원ID가 없습니다.";
	private final String ERR_MSG_NULL_ALARM_MASK_YN = "알람마스킹여부가 없습니다.";
	
	private final String ERR_MSG_NO_AUTH = "권한이 없는 사용자 입니다.";
	private final String ERR_MSG_NULL_SEARCH_RESULT_LIST = "조회 결과가 없습니다.";
	private final String ERR_MSG_READ_FAIL = "조회에 실패하였습니다.";
	private final String ERR_MSG_UPDATE_FAIL = "수정에 실패하였습니다.";
	
	@Autowired
	private AlarmCurrentStatusService alarmCurrentStatusService;
	
	@Autowired
	private UserRoleService userRoleService;
	
	/**
	 * 
	 * listPageAlarmCurrentStatus
	 *
	 * @param alarmCurrentStatusGridRequestDto
	 * @return ResponseEntity
	 */
	@SuppressWarnings("rawtypes")
    @GetMapping(value="", produces="application/json; charset=UTF-8")
    public ResponseEntity listPageAlarmCurrentStatus(@AuthenticationPrincipal JwtAuthResultDto authResultDto, 
    		AlarmCurrentStatusGridRequestDto alarmCurrentStatusGridRequestDto) throws Exception {
        
    	ResponseEntity<ResultDto> resEntity = null;
		String returnString = "";
		
		String loginUserId = StringUtils.defaultString(authResultDto.getUserId());
		if ("".equals(loginUserId)) {
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_LOGIN_USER_ID));
			return resEntity;
		}
		String mgrYn = StringUtils.defaultString(authResultDto.getMgrYn());
		if ("".equals(mgrYn)) {
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_MGR_YN));
			return resEntity;
		}
    	
		if (!"Y".equals(mgrYn)) {
			String authorityTypeCd = "";
			UserRoleMenuAuthorityRequestDto userRoleMenuAuthorityRequestDto = new UserRoleMenuAuthorityRequestDto();
			userRoleMenuAuthorityRequestDto.setUserId(loginUserId);
			userRoleMenuAuthorityRequestDto.setMenuId(MENU_ID);
			OomUserRoleAuthorityDetailDto rsltOomUserRoleAuthorityDetailDto = userRoleService.readMenuAuthority(userRoleMenuAuthorityRequestDto);
			if (rsltOomUserRoleAuthorityDetailDto != null) {
				authorityTypeCd = StringUtils.defaultString(rsltOomUserRoleAuthorityDetailDto.getAuthorityTypeCd());
			}
			if (!"R".equals(authorityTypeCd) && !"W".equals(authorityTypeCd)) {
				returnString = Const.Common.RESULT_CODE.FAIL;
				resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NO_AUTH));
				return resEntity;
			}
		}
		
		int pageNumber = alarmCurrentStatusGridRequestDto.getPageNumber();
		if (pageNumber < 1) {
			log.error(">>>>>> pageNumber ERROR:{}", ERR_MSG_NULL_PAGE_NUMBER);
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_PAGE_NUMBER));
			return resEntity;
		}
		// 알람현재상태 목록 조회....
		Map<String, Object> alarmCurrentStatusGridResultDtoListMap = new HashMap<String, Object>();
		List<AlarmCurrentStatusGridResultDto> alarmCurrentStatusGridResultDtoList = alarmCurrentStatusService.listPageAlarmCurrentStatus(alarmCurrentStatusGridRequestDto);
		if (CollectionUtils.isEmpty(alarmCurrentStatusGridResultDtoList)) {
			returnString = Const.Common.RESULT_CODE.SUCCESS;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_SEARCH_RESULT_LIST, alarmCurrentStatusGridResultDtoListMap));
		} else {
			returnString = Const.Common.RESULT_CODE.SUCCESS;
			alarmCurrentStatusGridResultDtoListMap.put(Const.Definition.PAGE.PAGER, PageUtil.getPageInfo(alarmCurrentStatusGridResultDtoList));
			alarmCurrentStatusGridResultDtoListMap.put(Const.Definition.PAGE.LISTS, alarmCurrentStatusGridResultDtoList);
			resEntity = ResponseEntity.ok(new ResultDto(returnString, "", alarmCurrentStatusGridResultDtoListMap));
		}
    	
    	return resEntity;
    }
	
	/**
	 * 
	 * readAlarmCurrentStatus
	 *
	 * @param onmAlarmCd
	 * @param reqOomOnmAlarmCurrentStatusDto
	 * @return ResponseEntity
	 */
	@SuppressWarnings("rawtypes")
    @GetMapping(value="/{onmAlarmCd}", produces="application/json; charset=UTF-8")
    public ResponseEntity readAlarmCurrentStatus(@PathVariable("onmAlarmCd") String onmAlarmCd, OomOnmAlarmCurrentStatusDto reqOomOnmAlarmCurrentStatusDto) throws Exception {
        
    	ResponseEntity<ResultDto> resEntity = null;
		String returnString = "";
    	
		String tenantId = StringUtils.defaultString(reqOomOnmAlarmCurrentStatusDto.getTenantId());
		if ("".equals(tenantId)) {
			log.error(">>>>>> tenantId ERROR:{}", ERR_MSG_NULL_TENANT_ID);
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_TENANT_ID));
			return resEntity;
		}
		String onmResourceId = StringUtils.defaultString(reqOomOnmAlarmCurrentStatusDto.getOnmResourceId());
		if ("".equals(onmResourceId)) {
			log.error(">>>>>> onmResourceId ERROR:{}", ERR_MSG_NULL_RESOURCE_ID);
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_RESOURCE_ID));
			return resEntity;
		}
		
		reqOomOnmAlarmCurrentStatusDto.setOnmAlarmCd(onmAlarmCd);
		
		AlarmCurrentStatusDetailResultDto alarmCurrentStatusDetailResultDto = alarmCurrentStatusService.readAlarmCurrentStatus(reqOomOnmAlarmCurrentStatusDto);
		if (alarmCurrentStatusDetailResultDto == null) {
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_READ_FAIL, alarmCurrentStatusDetailResultDto));
		} else {
			returnString = Const.Common.RESULT_CODE.SUCCESS;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, "", alarmCurrentStatusDetailResultDto));
		}
    	
    	return resEntity;
    }
	
	/**
	 * 
	 * updateAlarmCurrentStatus
	 *
	 * @param authResultDto
	 * @param onmAlarmCd
	 * @param reqOomOnmAlarmCurrentStatusDto
	 * @return ResponseEntity
	 */
	@SuppressWarnings("rawtypes")
    @PutMapping(value="/{onmAlarmCd}", produces="application/json; charset=UTF-8")
    public ResponseEntity updateAlarmCurrentStatus(@AuthenticationPrincipal JwtAuthResultDto authResultDto, 
    		@PathVariable("onmAlarmCd") String onmAlarmCd, @RequestBody OomOnmAlarmCurrentStatusDto reqOomOnmAlarmCurrentStatusDto) throws Exception {
        
    	ResponseEntity<ResultDto> resEntity = null;
		String returnString = "";
    	
		String loginUserId = StringUtils.defaultString(authResultDto.getUserId());
		if ("".equals(loginUserId)) {
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_LOGIN_USER_ID));
			return resEntity;
		}
		String mgrYn = StringUtils.defaultString(authResultDto.getMgrYn());
		if ("".equals(mgrYn)) {
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_MGR_YN));
			return resEntity;
		}
		//String loginUserId = "tsop-admin"; // 이후 세션에서 얻어올 값...
		
		if (!"Y".equals(mgrYn)) {
			String authorityTypeCd = "";
			UserRoleMenuAuthorityRequestDto userRoleMenuAuthorityRequestDto = new UserRoleMenuAuthorityRequestDto();
			userRoleMenuAuthorityRequestDto.setUserId(loginUserId);
			userRoleMenuAuthorityRequestDto.setMenuId(MENU_ID);
			OomUserRoleAuthorityDetailDto rsltOomUserRoleAuthorityDetailDto = userRoleService.readMenuAuthority(userRoleMenuAuthorityRequestDto);
			if (rsltOomUserRoleAuthorityDetailDto != null) {
				authorityTypeCd = StringUtils.defaultString(rsltOomUserRoleAuthorityDetailDto.getAuthorityTypeCd());
			}
			if (!"W".equals(authorityTypeCd)) {
				returnString = Const.Common.RESULT_CODE.FAIL;
				resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NO_AUTH));
				return resEntity;
			}
		}
		
		String tenantId = StringUtils.defaultString(reqOomOnmAlarmCurrentStatusDto.getTenantId());
		if ("".equals(tenantId)) {
			log.error(">>>>>> tenantId ERROR:{}", ERR_MSG_NULL_TENANT_ID);
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_TENANT_ID));
			return resEntity;
		}
		String onmResourceId = StringUtils.defaultString(reqOomOnmAlarmCurrentStatusDto.getOnmResourceId());
		if ("".equals(onmResourceId)) {
			log.error(">>>>>> onmResourceId ERROR:{}", ERR_MSG_NULL_RESOURCE_ID);
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_RESOURCE_ID));
			return resEntity;
		}
		String onmAlarmMaskYn = StringUtils.defaultString(reqOomOnmAlarmCurrentStatusDto.getOnmAlarmMaskYn());
		if ("".equals(onmAlarmMaskYn)) {
			log.error(">>>>>> onmAlarmMaskYn ERROR:{}", ERR_MSG_NULL_ALARM_MASK_YN);
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_ALARM_MASK_YN));
			return resEntity;
		}
		
		reqOomOnmAlarmCurrentStatusDto.setOnmAlarmCd(onmAlarmCd);
		reqOomOnmAlarmCurrentStatusDto.setAuditId(loginUserId);
		
		// 알람현재상태목록 수정...
		int affectRowCount = alarmCurrentStatusService.updateAlarmCurrentStatus(reqOomOnmAlarmCurrentStatusDto);
		if (affectRowCount < 1) {
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_UPDATE_FAIL, affectRowCount));
		} else {
			returnString = Const.Common.RESULT_CODE.SUCCESS;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, "", affectRowCount));
		}
    	
    	return resEntity;
    }

}
