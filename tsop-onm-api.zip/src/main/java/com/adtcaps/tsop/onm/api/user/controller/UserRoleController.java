package com.adtcaps.tsop.onm.api.user.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.util.CollectionUtils;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.adtcaps.tsop.onm.api.authentication.domain.JwtAuthResultDto;
import com.adtcaps.tsop.onm.api.domain.OomUserRoleDetailDto;
import com.adtcaps.tsop.onm.api.domain.OomUserRoleDto;
import com.adtcaps.tsop.onm.api.helper.constant.Const;
import com.adtcaps.tsop.onm.api.helper.domain.BasePageDto;
import com.adtcaps.tsop.onm.api.helper.domain.ResultDto;
import com.adtcaps.tsop.onm.api.helper.util.PageUtil;
import com.adtcaps.tsop.onm.api.user.domain.UserRoleDetailResultDto;
import com.adtcaps.tsop.onm.api.user.domain.UserRoleForComboResultDto;
import com.adtcaps.tsop.onm.api.user.domain.UserRoleGridResultDto;
import com.adtcaps.tsop.onm.api.user.domain.UserRoleProcessingDto;
import com.adtcaps.tsop.onm.api.user.service.UserRoleService;

import lombok.extern.slf4j.Slf4j;

/**
 * 
 * <ul>
 * <li>업무 그룹명 : tsop-onm-api</li>
 * <li>서브 업무명 : com.adtcaps.tsop.onm.api.user.controller</li>
 * <li>설  명 : UserRoleController.java</li>
 * <li>작성일 : 2021. 1. 4.</li>
 * <li>작성자 : jeonyb4</li>
 * </ul>
 */
@Slf4j
@RestController
@RequestMapping("/api/roles")
public class UserRoleController {
	
	private final String ERR_MSG_NULL_LOGIN_USER_ID = "로그인 사용자ID가 없습니다.";
	private final String ERR_MSG_NULL_MGR_YN = "관리자여부가 없습니다.";
	private final String ERR_MSG_NULL_PAGE_NUMBER = "페이지 번호가 없습니다.";
	private final String ERR_MSG_NULL_ROLE_INFO = "메뉴그룹 정보가 없습니다.";
	private final String ERR_MSG_NULL_ROLE_NAME = "메뉴그룹명이 없습니다.";
	
	private final String ERR_MSG_EXIST_ROLE_MAPPING_USER = "메뉴그룹에 매핑된 운영자가 있으므로 삭제할 수 없습니다.";
	private final String ERR_MSG_ALREADY_EXIST_ROLE_NAME = "해당 메뉴그룹명은 이미 존재하므로 사용할 수 없습니다.";
	
	private final String ERR_MSG_ABNORMAL_AUTH = "현재 사용자는 권한이 없습니다.";
	
	private final String ERR_MSG_NULL_SEARCH_RESULT_LIST = "조회 결과가 없습니다.";
	private final String ERR_MSG_CREATE_FAIL = "등록에 실패하였습니다.";
	private final String ERR_MSG_READ_FAIL = "조회에 실패하였습니다.";
	private final String ERR_MSG_UPDATE_FAIL = "수정에 실패하였습니다.";
	private final String ERR_MSG_DELETE_FAIL = "삭제에 실패하였습니다.";
	
	@Autowired
	private UserRoleService userRoleService;
	
	/**
	 * 
	 * listUserRoleForCombo
	 *
	 * @return ResponseEntity
	 */
	@SuppressWarnings("rawtypes")
    @GetMapping(value="/combobox", produces="application/json; charset=UTF-8")
    public ResponseEntity listUserRoleForCombo() throws Exception {
        
    	ResponseEntity<ResultDto> resEntity = null;
		String returnString = "";
    	
		// 사용자역할(메뉴그룹) 콤보박스용 목록 조회....
		Map<String, Object> userRoleForComboResultDtoListMap = new HashMap<String, Object>();
		List<UserRoleForComboResultDto> userRoleForComboResultDtoList = userRoleService.listUserRoleForCombo();
		if (CollectionUtils.isEmpty(userRoleForComboResultDtoList)) {
			returnString = Const.Common.RESULT_CODE.SUCCESS;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_SEARCH_RESULT_LIST, userRoleForComboResultDtoListMap));
		} else {
			returnString = Const.Common.RESULT_CODE.SUCCESS;
			userRoleForComboResultDtoListMap.put(Const.Definition.PAGE.PAGER, PageUtil.getPageInfo(userRoleForComboResultDtoList));
			userRoleForComboResultDtoListMap.put(Const.Definition.PAGE.LISTS, userRoleForComboResultDtoList);
			resEntity = ResponseEntity.ok(new ResultDto(returnString, "", userRoleForComboResultDtoListMap));
		}
    	
    	return resEntity;
    }
	
	/**
	 * 
	 * listPageUserRole
	 *
	 * @param reqBasePageDto
	 * @return ResponseEntity
	 */
	@SuppressWarnings("rawtypes")
    @GetMapping(value="", produces="application/json; charset=UTF-8")
    public ResponseEntity listPageUserRole(BasePageDto reqBasePageDto) throws Exception {
        
    	ResponseEntity<ResultDto> resEntity = null;
		String returnString = "";
    	
		int pageNumber = reqBasePageDto.getPageNumber();
		if (pageNumber < 1) {
			log.error(">>>>>> pageNumber ERROR:{}", ERR_MSG_NULL_PAGE_NUMBER);
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_PAGE_NUMBER));
			return resEntity;
		}
		
		// 사용자역할(메뉴그룹) 목록 조회....
		Map<String, Object> userRoleGridResultDtoListMap = new HashMap<String, Object>();
		List<UserRoleGridResultDto> userRoleGridResultDtoList = userRoleService.listPageUserRole(reqBasePageDto);
		if (CollectionUtils.isEmpty(userRoleGridResultDtoList)) {
			returnString = Const.Common.RESULT_CODE.SUCCESS;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_SEARCH_RESULT_LIST, userRoleGridResultDtoListMap));
		} else {
			returnString = Const.Common.RESULT_CODE.SUCCESS;
			userRoleGridResultDtoListMap.put(Const.Definition.PAGE.PAGER, PageUtil.getPageInfo(userRoleGridResultDtoList));
			userRoleGridResultDtoListMap.put(Const.Definition.PAGE.LISTS, userRoleGridResultDtoList);
			resEntity = ResponseEntity.ok(new ResultDto(returnString, "", userRoleGridResultDtoListMap));
		}
    	
    	return resEntity;
    }
	
	/**
	 * 
	 * createUserRole
	 *
	 * @param reqUserRoleProcessingDto
	 * @return ResponseEntity
	 */
	@SuppressWarnings("rawtypes")
    @PostMapping(value="", produces="application/json; charset=UTF-8")
    public ResponseEntity createUserRole(@AuthenticationPrincipal JwtAuthResultDto authResultDto, 
    		@RequestBody UserRoleProcessingDto reqUserRoleProcessingDto) throws Exception {
        
    	ResponseEntity<ResultDto> resEntity = null;
		String returnString = "";
    	
		String loginUserId = StringUtils.defaultString(authResultDto.getUserId());
		if ("".equals(loginUserId)) {
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_LOGIN_USER_ID));
			return resEntity;
		}
		String mgrYn = StringUtils.defaultString(authResultDto.getMgrYn());
		if ("".equals(mgrYn)) {
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_MGR_YN));
			return resEntity;
		}
		//String loginUserId = "tsop-admin"; // 이후 세션에서 얻어올 값...
		
		if (!"Y".equals(mgrYn)) {
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_ABNORMAL_AUTH));
			return resEntity;
		}
		
		OomUserRoleDto reqOomUserRoleDto = reqUserRoleProcessingDto.getRoleInfo();
		if (reqOomUserRoleDto == null) {
			log.error(">>>>>> reqOomUserRoleDto ERROR:{}", ERR_MSG_NULL_ROLE_INFO);
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_ROLE_INFO));
			return resEntity;
		}
		String roleName = StringUtils.defaultString(reqOomUserRoleDto.getRoleName());
		if ("".equals(roleName)) {
			log.error(">>>>>> roleName ERROR:{}", ERR_MSG_NULL_ROLE_NAME);
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_ROLE_NAME));
			return resEntity;
		}
		
		reqOomUserRoleDto.setAuditId(loginUserId);
		reqUserRoleProcessingDto.setRoleInfo(reqOomUserRoleDto);
		
		// 이름으로 중복체크..
		int userRoleCount = userRoleService.readUserRoleDuplicationByName(reqOomUserRoleDto);
		if (userRoleCount > 0) {
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_ALREADY_EXIST_ROLE_NAME));
			return resEntity;
		}
		
		// 메뉴그룹 등록...
		int affectRowCount = userRoleService.createUserRole(reqUserRoleProcessingDto);
		if (affectRowCount < 1) {
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_CREATE_FAIL, affectRowCount));
		} else {
			returnString = Const.Common.RESULT_CODE.SUCCESS;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, "", affectRowCount));
		}
    	
    	return resEntity;
    }
	
	/**
	 * 
	 * readUserRole
	 *
	 * @param roleId
	 * @return ResponseEntity
	 */
	@SuppressWarnings("rawtypes")
    @GetMapping(value="/{roleId}", produces="application/json; charset=UTF-8")
    public ResponseEntity readUserRole(@PathVariable("roleId") String roleId) throws Exception {
        
    	ResponseEntity<ResultDto> resEntity = null;
		String returnString = "";
    	
		OomUserRoleDto reqOomUserRoleDto = new OomUserRoleDto();
		reqOomUserRoleDto.setRoleId(roleId);
		
		UserRoleDetailResultDto userRoleDetailResultDto = userRoleService.readUserRole(reqOomUserRoleDto);
		if (userRoleDetailResultDto == null) {
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_READ_FAIL, userRoleDetailResultDto));
		} else {
			returnString = Const.Common.RESULT_CODE.SUCCESS;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, "", userRoleDetailResultDto));
		}
    	
    	return resEntity;
    }
	
	/**
	 * 
	 * updateUserRole
	 *
	 * @param roleId
	 * @param reqUserRoleProcessingDto
	 * @return ResponseEntity
	 */
	@SuppressWarnings("rawtypes")
    @PutMapping(value="/{roleId}", produces="application/json; charset=UTF-8")
    public ResponseEntity updateUserRole(@AuthenticationPrincipal JwtAuthResultDto authResultDto, 
    		@PathVariable("roleId") String roleId, @RequestBody UserRoleProcessingDto reqUserRoleProcessingDto) throws Exception {
        
    	ResponseEntity<ResultDto> resEntity = null;
		String returnString = "";
    	
		String loginUserId = StringUtils.defaultString(authResultDto.getUserId());
		if ("".equals(loginUserId)) {
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_LOGIN_USER_ID));
			return resEntity;
		}
		String mgrYn = StringUtils.defaultString(authResultDto.getMgrYn());
		if ("".equals(mgrYn)) {
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_MGR_YN));
			return resEntity;
		}
		//String loginUserId = "tsop-admin"; // 이후 세션에서 얻어올 값...
		
		if (!"Y".equals(mgrYn)) {
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_ABNORMAL_AUTH));
			return resEntity;
		}
		
		OomUserRoleDto reqOomUserRoleDto = reqUserRoleProcessingDto.getRoleInfo();
		if (reqOomUserRoleDto == null) {
			log.error(">>>>>> reqOomUserRoleDto ERROR:{}", ERR_MSG_NULL_ROLE_INFO);
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_ROLE_INFO));
			return resEntity;
		}
		String roleName = StringUtils.defaultString(reqOomUserRoleDto.getRoleName());
		if ("".equals(roleName)) {
			log.error(">>>>>> roleName ERROR:{}", ERR_MSG_NULL_ROLE_NAME);
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_ROLE_NAME));
			return resEntity;
		}
		
		reqOomUserRoleDto.setRoleId(roleId);
		reqOomUserRoleDto.setAuditId(loginUserId);
		reqUserRoleProcessingDto.setRoleInfo(reqOomUserRoleDto);
		
		// 이름으로 중복체크..
		int userRoleCount = userRoleService.readUserRoleDuplicationByName(reqOomUserRoleDto);
		if (userRoleCount > 0) {
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_ALREADY_EXIST_ROLE_NAME));
			return resEntity;
		}
		
		// 메뉴그룹 수정...
		int affectRowCount = userRoleService.updateUserRole(reqUserRoleProcessingDto);
		if (affectRowCount < 1) {
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_UPDATE_FAIL, affectRowCount));
		} else {
			returnString = Const.Common.RESULT_CODE.SUCCESS;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, "", affectRowCount));
		}
    	
    	return resEntity;
    }
	
	/**
	 * 
	 * deleteUserRole
	 *
	 * @param roleId
	 * @return ResponseEntity
	 */
	@SuppressWarnings("rawtypes")
    @DeleteMapping(value="/{roleId}", produces="application/json; charset=UTF-8")
    public ResponseEntity deleteUserRole(@AuthenticationPrincipal JwtAuthResultDto authResultDto, 
    		@PathVariable("roleId") String roleId) throws Exception {
        
    	ResponseEntity<ResultDto> resEntity = null;
		String returnString = "";
    	
		String loginUserId = StringUtils.defaultString(authResultDto.getUserId());
		if ("".equals(loginUserId)) {
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_LOGIN_USER_ID));
			return resEntity;
		}
		String mgrYn = StringUtils.defaultString(authResultDto.getMgrYn());
		if ("".equals(mgrYn)) {
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_MGR_YN));
			return resEntity;
		}
		//String loginUserId = "tsop-admin"; // 이후 세션에서 얻어올 값...
		
		if (!"Y".equals(mgrYn)) {
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_ABNORMAL_AUTH));
			return resEntity;
		}
		
		OomUserRoleDto reqOomUserRoleDto = new OomUserRoleDto();
		reqOomUserRoleDto.setRoleId(roleId);
		
		// 메뉴그룹에 매핑된 사용자가 있는지 확인
		OomUserRoleDetailDto reqOomUserRoleDetailDto = new OomUserRoleDetailDto();
		reqOomUserRoleDetailDto.setRoleId(roleId);
		int userCount = userRoleService.readUserRoleDetailCount(reqOomUserRoleDetailDto);
		if (userCount > 0) {
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_EXIST_ROLE_MAPPING_USER, userCount));
			return resEntity;
		}
		
		// 메뉴그룹 삭제...
		int affectRowCount = userRoleService.deleteUserRole(reqOomUserRoleDto);
		if (affectRowCount < 1) {
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_DELETE_FAIL, affectRowCount));
		} else {
			returnString = Const.Common.RESULT_CODE.SUCCESS;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, "", affectRowCount));
		}
    	
    	return resEntity;
    }
	
	
	/***************************************************************************************/
	
	/**
	 * 
	 * listPageUserRoleMappingDetail
	 *
	 * @param reqBasePageDto
	 * @return ResponseEntity
	 */
//	@SuppressWarnings("rawtypes")
//    @GetMapping(value="/user-role-mapping-details", produces="application/json; charset=UTF-8")
//    public ResponseEntity listPageUserRoleMappingDetail(BasePageDto reqBasePageDto) {
//        
//    	ResponseEntity<ResultDto> resEntity = null;
//		String returnString = "";
//    	
//    	try {
//    		int pageNumber = reqBasePageDto.getPageNumber();
//    		if (pageNumber < 1) {
//    			log.error(">>>>>> pageNumber ERROR:{}", ERR_MSG_NULL_PAGE_NUMBER);
//				returnString = Const.Common.RESULT_CODE.FAIL;
//    			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_PAGE_NUMBER));
//    			return resEntity;
//    		}
//    		// 사용자역할내역상세 목록 조회....
//    		Map<String, Object> userRoleMappingDetailGridResultDtoListMap = new HashMap<String, Object>();
//    		List<UserRoleMappingDetailGridResultDto> userRoleMappingDetailGridResultDtoList = userRoleService.listPageUserRoleMappingDetail(reqBasePageDto);
//    		if (CollectionUtils.isEmpty(userRoleMappingDetailGridResultDtoList)) {
//    			returnString = Const.Common.RESULT_CODE.SUCCESS;
//    			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_SEARCH_RESULT_LIST, userRoleMappingDetailGridResultDtoListMap));
//    		} else {
//    			returnString = Const.Common.RESULT_CODE.SUCCESS;
//    			userRoleMappingDetailGridResultDtoListMap.put(Const.Definition.PAGE.PAGER, PageUtil.getPageInfo(userRoleMappingDetailGridResultDtoList));
//    			userRoleMappingDetailGridResultDtoListMap.put(Const.Definition.PAGE.LISTS, userRoleMappingDetailGridResultDtoList);
//    			resEntity = ResponseEntity.ok(new ResultDto(returnString, "", userRoleMappingDetailGridResultDtoListMap));
//    		}
//    		
//    	} catch (Exception ex) {
//        	log.error("listPageUserRoleMappingDetail.Exception: {}", ex);
//    		returnString = Const.Common.RESULT_CODE.FAIL;
//    		resEntity = ResponseEntity.ok(new ResultDto(returnString, ex));
//        }
//    	
//    	return resEntity;
//    }

}
