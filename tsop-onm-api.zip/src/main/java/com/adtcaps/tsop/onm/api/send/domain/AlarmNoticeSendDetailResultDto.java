package com.adtcaps.tsop.onm.api.send.domain;

import java.util.List;

import lombok.Getter;
import lombok.Setter;

/**
 * 
 * <ul>
 * <li>업무 그룹명 : tsop-onm-api</li>
 * <li>서브 업무명 : com.adtcaps.tsop.onm.api.send.domain</li>
 * <li>설  명 : AlarmNoticeSendDetailResultDto.java</li>
 * <li>작성일 : 2021. 1. 30.</li>
 * <li>작성자 : jeonyb4</li>
 * </ul>
 */
@Getter
@Setter
public class AlarmNoticeSendDetailResultDto {
	private String tenantId;
	private Integer alarmNoticeTransSeq;
	private Integer alarmNoticeGroupId;
	private String bulletinTypeCd;
	private Integer bulletinNum;
	private Integer transSeq;
	private String transDatetime;
	private String msgContent;
	private String alarmNoticeResultCd;
	private String alarmNoticeResultName;
	private String alarmNoticeMethodClCd;
	private List<NoticeSendReceiverDto> recevierList;

}
