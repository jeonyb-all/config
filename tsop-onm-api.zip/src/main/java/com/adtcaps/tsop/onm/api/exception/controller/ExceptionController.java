package com.adtcaps.tsop.onm.api.exception.controller;

import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestControllerAdvice;

import com.adtcaps.tsop.onm.api.helper.constant.Const;
import com.adtcaps.tsop.onm.api.helper.domain.ResultDto;

import lombok.extern.slf4j.Slf4j;

/**
 * 
 * <ul>
 * <li>업무 그룹명 : tsop-onm-api</li>
 * <li>서브 업무명 : com.adtcaps.tsop.onm.api.exception.controller</li>
 * <li>설  명 : ExceptionController.java</li>
 * <li>작성일 : 2021. 2. 8.</li>
 * <li>작성자 : jeonyb4</li>
 * </ul>
 */
@Slf4j
@RestControllerAdvice
public class ExceptionController {

	@ExceptionHandler
    public @ResponseBody ResultDto handleAll(final Exception ex) {
        
		log.error(ex.getMessage(), ex);
		ResultDto resultDto = null;
		
		if (ex.getMessage().indexOf("[작업오류]") > -1) {
    		resultDto = new ResultDto(Const.Common.RESULT_CODE.FAIL, ex.getMessage());
    	} else {
    		resultDto = new ResultDto(Const.Common.RESULT_CODE.FAIL, "서버 오류가 발생하였습니다. 관리자에게 문의해 주세요.");
    	}
		
        return resultDto;
    }
	
}
