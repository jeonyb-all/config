package com.adtcaps.tsop.onm.api.deploy.domain;

import lombok.Getter;
import lombok.Setter;

/**
 * 
 * <ul>
 * <li>업무 그룹명 : tsop-onm-api</li>
 * <li>서브 업무명 : com.adtcaps.tsop.onm.api.deploy.domain</li>
 * <li>설  명 : PackageDeployJobDetailResultDto.java</li>
 * <li>작성일 : 2021. 1. 31.</li>
 * <li>작성자 : jeonyb4</li>
 * </ul>
 */
@Getter
@Setter
public class PackageDeployJobDetailResultDto {
	private String tenantId;
	private String pkgWorkId;
	private String auditDatetime;
	private String auditId;
	private String pkgTypeCd;
	private String pkgName;
	private String pkgVersionVal;
	private String pkgDesc;
	private String pkgReleaseTypeCd;
	private String pkgReleaseTypeName;
	private String workStartDatetime;
	private String workEndDatetime;
	private Integer verifyProcedureAttachFileNum;
	private String verifyProcedureAttachFileName;
	private Integer workProcedureAttachFileNum;
	private String workProcedureAttachFileName;
	private Integer inspectionProcedureAttachFileNum;
	private String inspectionProcedureAttachFileName;
	private String workScheduleDatetime;
	private String dbWorkYn;
	private Integer dbScriptAttachFileNum;
	private String dbScriptAttachFileName;
	private String ddlExecYn;
	private String bprintPoiReleaseYn;
	private String workExecResultCd;
	private String workExecResultName;
	private Integer inspectionResultAttachFileNum;
	private String inspectionResultAttachFileName;
	private String reexecDatetime;
	private Integer onmWorkId;
	private String commonDataReleaseResultVal;

}
