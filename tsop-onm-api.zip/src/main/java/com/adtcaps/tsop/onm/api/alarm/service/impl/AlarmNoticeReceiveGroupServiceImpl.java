package com.adtcaps.tsop.onm.api.alarm.service.impl;

import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.CollectionUtils;

import com.adtcaps.tsop.onm.api.alarm.domain.AlarmNoticeReceiveGroupDetailDetailResultDto;
import com.adtcaps.tsop.onm.api.alarm.domain.AlarmNoticeReceiveGroupDetailResultDto;
import com.adtcaps.tsop.onm.api.alarm.domain.AlarmNoticeReceiveGroupForComboResultDto;
import com.adtcaps.tsop.onm.api.alarm.domain.AlarmNoticeReceiveGroupGridRequestDto;
import com.adtcaps.tsop.onm.api.alarm.domain.AlarmNoticeReceiveGroupGridResultDto;
import com.adtcaps.tsop.onm.api.alarm.domain.AlarmNoticeReceiveGroupProcessingDto;
import com.adtcaps.tsop.onm.api.alarm.mapper.OomAlarmNoticeReceiveGroupDetailMapper;
import com.adtcaps.tsop.onm.api.alarm.mapper.OomAlarmNoticeReceiveGroupMapper;
import com.adtcaps.tsop.onm.api.alarm.service.AlarmNoticeReceiveGroupService;
import com.adtcaps.tsop.onm.api.domain.OomAlarmNoticeReceiveGroupDetailDto;
import com.adtcaps.tsop.onm.api.domain.OomAlarmNoticeReceiveGroupDto;
import com.adtcaps.tsop.onm.api.helper.constant.Const;
import com.adtcaps.tsop.onm.api.helper.util.CommonDateUtil;

/**
 * 
 * <ul>
 * <li>업무 그룹명 : tsop-onm-api</li>
 * <li>서브 업무명 : com.adtcaps.tsop.onm.api.alarm.service.impl</li>
 * <li>설  명 : AlarmNoticeReceiveGroupServiceImpl.java</li>
 * <li>작성일 : 2021. 1. 8.</li>
 * <li>작성자 : jeonyb4</li>
 * </ul>
 */
@Transactional
@Service
public class AlarmNoticeReceiveGroupServiceImpl implements AlarmNoticeReceiveGroupService {
	
	@Autowired
	private OomAlarmNoticeReceiveGroupMapper oomAlarmNoticeReceiveGroupMapper;
	
	@Autowired
	private OomAlarmNoticeReceiveGroupDetailMapper oomAlarmNoticeReceiveGroupDetailMapper;
	
	
	/**
	 * 
	 * listBuildingAlarmNoticeReceiveGroupForCombo
	 *
	 * @return List<AlarmNoticeReceiveGroupForComboResultDto>
	 * @throws Exception 
	 */
	@Override
	public List<AlarmNoticeReceiveGroupForComboResultDto> listAlarmNoticeReceiveGroupForCombo() throws Exception {
		
		List<AlarmNoticeReceiveGroupForComboResultDto> buildingAlarmNoticeReceiveGroupForComboResultDtoList = null;
		try {
			buildingAlarmNoticeReceiveGroupForComboResultDtoList = oomAlarmNoticeReceiveGroupMapper.listAlarmNoticeReceiveGroupForCombo();
			
		} catch (Exception e) {
			throw e;
		}
		return buildingAlarmNoticeReceiveGroupForComboResultDtoList;
	}
	
	/**
	 * 
	 * listPageAlarmNoticeReceiveGroup
	 *
	 * @param alarmReceiveGroupGridRequestDto
	 * @return List<AlarmNoticeReceiveGroupGridResultDto>
	 * @throws Exception 
	 */
	@Override
	public List<AlarmNoticeReceiveGroupGridResultDto> listPageAlarmNoticeReceiveGroup(AlarmNoticeReceiveGroupGridRequestDto alarmReceiveGroupGridRequestDto) throws Exception {
		
		List<AlarmNoticeReceiveGroupGridResultDto> alarmReceiveGroupGridResultDtoList = null;
		try {
			alarmReceiveGroupGridResultDtoList = oomAlarmNoticeReceiveGroupMapper.listPageAlarmNoticeReceiveGroup(alarmReceiveGroupGridRequestDto);
    		if (!CollectionUtils.isEmpty(alarmReceiveGroupGridResultDtoList)) {
    			for (int idx = 0; idx < alarmReceiveGroupGridResultDtoList.size(); idx++) {
    				
    				AlarmNoticeReceiveGroupGridResultDto alarmReceiveGroupGridResultDto = alarmReceiveGroupGridResultDtoList.get(idx);
    				
    				String registDatetime = StringUtils.defaultString(alarmReceiveGroupGridResultDto.getRegistDatetime());
    				registDatetime = CommonDateUtil.makeDatetimeFormat(registDatetime);
    				alarmReceiveGroupGridResultDto.setRegistDatetime(registDatetime);
    				
    				String useYn = StringUtils.defaultString(alarmReceiveGroupGridResultDto.getUseYn());
    				if ("Y".equals(useYn)) {
    					alarmReceiveGroupGridResultDto.setUseYn(Const.Definition.USE_YN.USE);
    				} else {
    					alarmReceiveGroupGridResultDto.setUseYn(Const.Definition.USE_YN.NO_USE);
    				}
    				
    				alarmReceiveGroupGridResultDtoList.set(idx, alarmReceiveGroupGridResultDto);
    			}
    		}
    		
		} catch (Exception e) {
			throw e;
		}
		return alarmReceiveGroupGridResultDtoList;
	}
	
	/**
	 * 
	 * createAlarmNoticeReceiveGroup
	 *
	 * @param reqAlarmNoticeReceiveGroupProcessingDto
	 * @return int
	 * @throws Exception 
	 */
	@Override
	public int createAlarmNoticeReceiveGroup(AlarmNoticeReceiveGroupProcessingDto reqAlarmNoticeReceiveGroupProcessingDto) throws Exception {
		
		int affectRowCount = 0;
		
		try {
			OomAlarmNoticeReceiveGroupDto reqOomAlarmNoticeReceiveGroupDto = reqAlarmNoticeReceiveGroupProcessingDto.getReceiveGroupInfo();
			int insertRow = oomAlarmNoticeReceiveGroupMapper.createOomAlarmNoticeReceiveGroup(reqOomAlarmNoticeReceiveGroupDto);
			affectRowCount = affectRowCount + insertRow;
			
			if (insertRow > 0) {
				String registerId = reqOomAlarmNoticeReceiveGroupDto.getRegisterId();
				int alarmNoticeGroupId = reqOomAlarmNoticeReceiveGroupDto.getAlarmNoticeGroupId();
				List<OomAlarmNoticeReceiveGroupDetailDto> reqOomAlarmNoticeReceiveGroupDetailDtoList = reqAlarmNoticeReceiveGroupProcessingDto.getReceiveGroupDetailList();
				for (OomAlarmNoticeReceiveGroupDetailDto reqOomAlarmNoticeReceiveGroupDetailDto : reqOomAlarmNoticeReceiveGroupDetailDtoList) {
					reqOomAlarmNoticeReceiveGroupDetailDto.setAlarmNoticeGroupId(alarmNoticeGroupId);
					reqOomAlarmNoticeReceiveGroupDetailDto.setRegisterId(registerId);
					insertRow = oomAlarmNoticeReceiveGroupDetailMapper.createOomAlarmNoticeReceiveGroupDetail(reqOomAlarmNoticeReceiveGroupDetailDto);
					affectRowCount = affectRowCount + insertRow;
				}
			}
			
		} catch (Exception e) {
			throw e;
		}
		
		return affectRowCount;
	}
	
	/**
	 * 
	 * readAlarmNoticeReceiveGroup
	 *
	 * @param reqOomAlarmNoticeReceiveGroupDto
	 * @return AlarmNoticeReceiveGroupDetailResultDto
	 * @throws Exception 
	 */
	@Override
	public AlarmNoticeReceiveGroupDetailResultDto readAlarmNoticeReceiveGroup(OomAlarmNoticeReceiveGroupDto reqOomAlarmNoticeReceiveGroupDto) throws Exception {
		
		AlarmNoticeReceiveGroupDetailResultDto alarmReceiveGroupDetailResultDto = null;
		try {
			alarmReceiveGroupDetailResultDto = oomAlarmNoticeReceiveGroupMapper.readAlarmNoticeReceiveGroup(reqOomAlarmNoticeReceiveGroupDto);
			if (alarmReceiveGroupDetailResultDto != null) {
				int alarmNoticeGroupId = reqOomAlarmNoticeReceiveGroupDto.getAlarmNoticeGroupId();
				OomAlarmNoticeReceiveGroupDetailDto reqOomAlarmNoticeReceiveGroupDetailDto = new OomAlarmNoticeReceiveGroupDetailDto();
				reqOomAlarmNoticeReceiveGroupDetailDto.setAlarmNoticeGroupId(alarmNoticeGroupId);
				List<AlarmNoticeReceiveGroupDetailDetailResultDto> alarmReceiveGroupDetailDetailResultDtoList = oomAlarmNoticeReceiveGroupDetailMapper.listAlarmNoticeReceiveGroupDetail(reqOomAlarmNoticeReceiveGroupDetailDto);
				alarmReceiveGroupDetailResultDto.setReceiveGroupDetailList(alarmReceiveGroupDetailDetailResultDtoList);
			}
		} catch (Exception e) {
			throw e;
		}
		return alarmReceiveGroupDetailResultDto;
	}
	
	/**
	 * 
	 * updateAlarmNoticeReceiveGroup
	 *
	 * @param reqOomAlarmNoticeReceiveGroupDto
	 * @return int
	 * @throws Exception 
	 */
	@Override
	public int updateAlarmNoticeReceiveGroup(AlarmNoticeReceiveGroupProcessingDto reqAlarmNoticeReceiveGroupProcessingDto) throws Exception {
		
		int affectRowCount = 0;
		
		try {
			// 수신그룹 수정...
			OomAlarmNoticeReceiveGroupDto reqOomAlarmNoticeReceiveGroupDto = reqAlarmNoticeReceiveGroupProcessingDto.getReceiveGroupInfo();
			int updateRow = oomAlarmNoticeReceiveGroupMapper.updateOomAlarmNoticeReceiveGroup(reqOomAlarmNoticeReceiveGroupDto);
			affectRowCount = affectRowCount + updateRow;
			
			if (updateRow > 0) {
				// 수신그룹상세 삭제...
				int alarmNoticeGroupId = reqOomAlarmNoticeReceiveGroupDto.getAlarmNoticeGroupId();
				OomAlarmNoticeReceiveGroupDetailDto delReqOomAlarmNoticeReceiveGroupDetailDto = new OomAlarmNoticeReceiveGroupDetailDto();
				delReqOomAlarmNoticeReceiveGroupDetailDto.setAlarmNoticeGroupId(alarmNoticeGroupId);
				oomAlarmNoticeReceiveGroupDetailMapper.deleteOomAlarmNoticeReceiveGroupDetail(delReqOomAlarmNoticeReceiveGroupDetailDto);
				// 수신그룹상세 등록...
				String auditId = reqOomAlarmNoticeReceiveGroupDto.getAuditId();
				List<OomAlarmNoticeReceiveGroupDetailDto> reqOomAlarmNoticeReceiveGroupDetailDtoList = reqAlarmNoticeReceiveGroupProcessingDto.getReceiveGroupDetailList();
				for (OomAlarmNoticeReceiveGroupDetailDto reqOomAlarmNoticeReceiveGroupDetailDto : reqOomAlarmNoticeReceiveGroupDetailDtoList) {
					reqOomAlarmNoticeReceiveGroupDetailDto.setAlarmNoticeGroupId(alarmNoticeGroupId);
					reqOomAlarmNoticeReceiveGroupDetailDto.setRegisterId(auditId);
					int insertRow = oomAlarmNoticeReceiveGroupDetailMapper.createOomAlarmNoticeReceiveGroupDetail(reqOomAlarmNoticeReceiveGroupDetailDto);
					affectRowCount = affectRowCount + insertRow;
				}
			}
			
		} catch (Exception e) {
			throw e;
		}
		
		return affectRowCount;
	}
	
	/**
	 * 
	 * deleteAlarmNoticeReceiveGroup
	 *
	 * @param reqOomAlarmNoticeReceiveGroupDto
	 * @return int
	 * @throws Exception 
	 */
	@Override
	public int deleteAlarmNoticeReceiveGroup(OomAlarmNoticeReceiveGroupDto reqOomAlarmNoticeReceiveGroupDto) throws Exception {
		
		int affectRowCount = 0;
		
		try {
			int deleteRow = oomAlarmNoticeReceiveGroupMapper.deleteOomAlarmNoticeReceiveGroup(reqOomAlarmNoticeReceiveGroupDto);
			affectRowCount = affectRowCount + deleteRow;
			
		} catch (Exception e) {
			throw e;
		}
		
		return affectRowCount;
	}
	
	/**
	 * 
	 * updateAlarmReceiveGroupReuse
	 *
	 * @param reqOomAlarmNoticeReceiveGroupDto
	 * @return int
	 * @throws Exception 
	 */
	@Override
	public int updateAlarmReceiveGroupReuse(OomAlarmNoticeReceiveGroupDto reqOomAlarmNoticeReceiveGroupDto) throws Exception {
		
		int affectRowCount = 0;
		
		try {
			int updateRow = oomAlarmNoticeReceiveGroupMapper.updateAlarmReceiveGroupReuse(reqOomAlarmNoticeReceiveGroupDto);
			affectRowCount = affectRowCount + updateRow;
			
		} catch (Exception e) {
			throw e;
		}
		
		return affectRowCount;
	}
	
	/**
	 * 
	 * getAlarmReceiveGroupCount
	 *
	 * @param reqOomAlarmNoticeReceiveGroupDto
	 * @return int
	 * @throws Exception 
	 */
	@Override
	public int getAlarmReceiveGroupCount(OomAlarmNoticeReceiveGroupDto reqOomAlarmNoticeReceiveGroupDto) throws Exception {
		int getCount = 0;
		
		try {
			getCount = oomAlarmNoticeReceiveGroupMapper.getAlarmReceiveGroupCount(reqOomAlarmNoticeReceiveGroupDto);
		} catch (Exception e) {
			throw e;
		}
		
		return getCount;
	}
	

}
