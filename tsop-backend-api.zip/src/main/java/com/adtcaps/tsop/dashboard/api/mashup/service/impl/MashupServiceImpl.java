package com.adtcaps.tsop.dashboard.api.mashup.service.impl;

import java.net.ConnectException;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.apache.commons.lang3.StringUtils;
import org.apache.http.conn.ConnectTimeoutException;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.CollectionUtils;

import com.adtcaps.tsop.config.InterfaceConfig;
import com.adtcaps.tsop.dashboard.api.mashup.domain.AlarmCurrentStateDto;
import com.adtcaps.tsop.dashboard.api.mashup.domain.AlarmGradeAlarmCountDto;
import com.adtcaps.tsop.dashboard.api.mashup.domain.AlarmGradeAlarmNoCheckResultDto;
import com.adtcaps.tsop.dashboard.api.mashup.domain.AlarmGradeAlarmTotalResultDto;
import com.adtcaps.tsop.dashboard.api.mashup.domain.AlarmGradeServiceClassCountDto;
import com.adtcaps.tsop.dashboard.api.mashup.domain.AlarmGradeServiceClassCountQueryResultDto;
import com.adtcaps.tsop.dashboard.api.mashup.domain.ServiceClassAlarmCountDto;
import com.adtcaps.tsop.dashboard.api.mashup.service.MashupService;
import com.adtcaps.tsop.helper.domain.PushResultDto;
import com.adtcaps.tsop.mapper.mashup.OmuAlarmMapper;
import com.adtcaps.tsop.portal.api.alarm.domain.AlarmPushRequestDto;
import com.adtcaps.tsop.portal.api.alarm.domain.AlarmPushRequestDto.Content;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.gson.Gson;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.squareup.okhttp.MediaType;
import com.squareup.okhttp.OkHttpClient;
import com.squareup.okhttp.Request;
import com.squareup.okhttp.RequestBody;
import com.squareup.okhttp.Response;

import io.netty.handler.timeout.ReadTimeoutException;

/**
 * 
 * <ul>
 * <li>업무 그룹명 : tsop-backend-api</li>
 * <li>서브 업무명 : com.adtcaps.tsop.dashboard.api.mashup.service.impl</li>
 * <li>설  명 : MashupServiceImpl.java</li>
 * <li>작성일 : 2020. 12. 4.</li>
 * <li>작성자 : jeonyb4</li>
 * </ul>
 */
@Transactional
@Service
public class MashupServiceImpl implements MashupService {
	
	@Autowired
	private OmuAlarmMapper omuAlarmMapper;
	
	@Autowired
	private InterfaceConfig interfaceConfig;
	
	
	/**
	 * 
	 * listAlarmGradeAlarmTotalCount
	 *
	 * @param reqAlarmCurrentStateDto
	 * @return AlarmGradeAlarmTotalResultDto
	 * @throws Exception
	 */
	@Override
	public AlarmGradeAlarmTotalResultDto listAlarmGradeAlarmTotalCount(AlarmCurrentStateDto reqAlarmCurrentStateDto) throws Exception {
		
		AlarmGradeAlarmTotalResultDto alarmGradeAlarmTotalResultDto = null;
		try {
			// 알람등급별 전체 알람 건수 조회...
			List<AlarmGradeAlarmCountDto> alarmGradeAlarmCountDtoList = omuAlarmMapper.listAlarmGradeAlarmCount(reqAlarmCurrentStateDto);
			
			alarmGradeAlarmTotalResultDto = new AlarmGradeAlarmTotalResultDto();
			alarmGradeAlarmTotalResultDto.setAlarmTotalCountList(alarmGradeAlarmCountDtoList);
			
			// 알람등급별 서비스별 전체 알람 건수 조회...
			List<AlarmGradeServiceClassCountQueryResultDto> alarmGradeServiceClassCountQueryResultDtoList = omuAlarmMapper.listAlarmGradeServiceClassAlarmCount(reqAlarmCurrentStateDto);
			
			List<AlarmGradeServiceClassCountDto> alarmGradeServiceClassCountDtoList = null;
			if (!CollectionUtils.isEmpty(alarmGradeServiceClassCountQueryResultDtoList)) {
				String bfAlarmGradeCd = "";
				// 알람등급별 서비스별 전체 알람 건수
				alarmGradeServiceClassCountDtoList = new ArrayList<AlarmGradeServiceClassCountDto>();
				// 서비스별 전체 알람 건수
				List<ServiceClassAlarmCountDto> serviceClassAlarmCountDtoList = new ArrayList<ServiceClassAlarmCountDto>();
				AlarmGradeServiceClassCountDto alarmGradeServiceClassCountDto = new AlarmGradeServiceClassCountDto();
				int idx = 0;
				for (AlarmGradeServiceClassCountQueryResultDto alarmGradeServiceClassCountQueryResultDto : alarmGradeServiceClassCountQueryResultDtoList) {
					String alarmGradeCd = StringUtils.defaultString(alarmGradeServiceClassCountQueryResultDto.getAlarmGradeCd());
					idx = idx + 1;
					if (bfAlarmGradeCd.equals(alarmGradeCd)) {
						ServiceClassAlarmCountDto serviceClassAlarmCountDto = new ServiceClassAlarmCountDto();
						BeanUtils.copyProperties(alarmGradeServiceClassCountQueryResultDto, serviceClassAlarmCountDto);
						serviceClassAlarmCountDtoList.add(serviceClassAlarmCountDto);
					
					} else {
						
						if (!"".equals(bfAlarmGradeCd)) {
							// 이전 데이터가 있으면.. 이전데이터 add 하고 new...
							alarmGradeServiceClassCountDto.setServiceAlarmCountList(serviceClassAlarmCountDtoList);
							alarmGradeServiceClassCountDtoList.add(alarmGradeServiceClassCountDto);
							
							alarmGradeServiceClassCountDto = new AlarmGradeServiceClassCountDto();
							serviceClassAlarmCountDtoList = new ArrayList<ServiceClassAlarmCountDto>();
						}
						
						alarmGradeServiceClassCountDto.setAlarmGradeCd(alarmGradeCd);
						
						ServiceClassAlarmCountDto serviceClassAlarmCountDto = new ServiceClassAlarmCountDto();
						BeanUtils.copyProperties(alarmGradeServiceClassCountQueryResultDto, serviceClassAlarmCountDto);
						serviceClassAlarmCountDtoList.add(serviceClassAlarmCountDto);
						
						bfAlarmGradeCd = alarmGradeCd;
					}
					// 마지막 데이터 이면...
					if (alarmGradeServiceClassCountQueryResultDtoList.size() == idx) {
						alarmGradeServiceClassCountDto.setServiceAlarmCountList(serviceClassAlarmCountDtoList);
						alarmGradeServiceClassCountDtoList.add(alarmGradeServiceClassCountDto);
						break;
					}
				}
			}
			
			alarmGradeAlarmTotalResultDto.setAlarmServiceTotalCountList(alarmGradeServiceClassCountDtoList);
			
		} catch (Exception e) {
			throw e;
		}
		return alarmGradeAlarmTotalResultDto;
	}
	
	/**
	 * 
	 * listAlarmGradeAlarmNoCheck
	 *
	 * @param reqAlarmCurrentStateDto
	 * @return AlarmGradeAlarmNoCheckResultDto
	 * @throws Exception 
	 */
	@Override
	public AlarmGradeAlarmNoCheckResultDto listAlarmGradeAlarmNoCheck(AlarmCurrentStateDto reqAlarmCurrentStateDto) throws Exception {
		
		AlarmGradeAlarmNoCheckResultDto alarmGradeAlarmNoCheckResultDto = null;
		try {
			// 알람등급별 미확인 알람 건수 조회...
			List<AlarmGradeAlarmCountDto> alarmGradeAlarmCountDtoList = omuAlarmMapper.listAlarmGradeAlarmCount(reqAlarmCurrentStateDto);
			// 미확인 알람 목록 조회...
			List<AlarmCurrentStateDto> alarmCurrentStateDtoList = omuAlarmMapper.listAlarmCurrentSate(reqAlarmCurrentStateDto);
			
			alarmGradeAlarmNoCheckResultDto = new AlarmGradeAlarmNoCheckResultDto();
			alarmGradeAlarmNoCheckResultDto.setAlarmNonCheckCountList(alarmGradeAlarmCountDtoList);
			alarmGradeAlarmNoCheckResultDto.setAlarmList(alarmCurrentStateDtoList);
			
		} catch (Exception e) {
			throw e;
		}
		return alarmGradeAlarmNoCheckResultDto;
	}
	
	/**
	 * 
	 * listAlarmGradeCurrentState
	 *
	 * @param reqAlarmCurrentStateDto
	 * @return List<AlarmCurrentStateDto>
	 * @throws Exception 
	 */
	@Override
	public List<AlarmCurrentStateDto> listAlarmGradeCurrentState(AlarmCurrentStateDto reqAlarmCurrentStateDto) throws Exception {
		
		List<AlarmCurrentStateDto> alarmCurrentStateDtoList = null;
		try {
			// 알람등급별 전체 알람 목록 조회...
			alarmCurrentStateDtoList = omuAlarmMapper.listAlarmCurrentSate(reqAlarmCurrentStateDto);
			
		} catch (Exception e) {
			throw e;
		}
		return alarmCurrentStateDtoList;
	}
	
	/**
	 * 
	 * updateNoCheckAlarmToCheck
	 *
	 * @param reqAlarmCurrentStateDto
	 * @return int
	 * @throws Exception 
	 */
	@Override
	public int updateNoCheckAlarmToCheck(AlarmCurrentStateDto reqAlarmCurrentStateDto) throws Exception {
		
		int affectRowCount = 0;
		try {
			// update...
			affectRowCount = omuAlarmMapper.updateNoCheckAlarmToCheck(reqAlarmCurrentStateDto);
			
			// Push 처리...
			PushResultDto pushResultDto = pushAlarmOccur(reqAlarmCurrentStateDto);
			if (pushResultDto == null) {
				affectRowCount = 9999;
			} else {
				String resultCode = StringUtils.defaultString(pushResultDto.getResult());
				if (!"1".equals(resultCode)) {
					affectRowCount = 9999;
				}
			}
			
		} catch (Exception e) {
			throw e;
		}
		return affectRowCount;
	}
	
	
	private PushResultDto pushAlarmOccur(AlarmCurrentStateDto reqAlarmCurrentStateDto) throws Exception {
		
		PushResultDto pushResultDto = null;
		
		try {
			Response response = null;
			String pushResultCd = "";
			
			int eventSeq = reqAlarmCurrentStateDto.getEventSeq();
			String bldId = StringUtils.defaultString(reqAlarmCurrentStateDto.getBldId());
			String checkYn = StringUtils.defaultString(reqAlarmCurrentStateDto.getCheckYn());
			String alarmGradeCd = StringUtils.defaultString(reqAlarmCurrentStateDto.getAlarmGradeCd());
			
			AlarmPushRequestDto alarmPushRequestDto = new AlarmPushRequestDto();
			Content content = new Content();
			content.setBldId(bldId);
			content.setEventSeq(eventSeq);
			content.setCheckYn(checkYn);
			content.setAlarmGradeCd(alarmGradeCd);
			alarmPushRequestDto.setAlarmStatus("Update");
			alarmPushRequestDto.setContent(content);
			
			Gson gson = new Gson();
    	    String requestJsonString = gson.toJson(alarmPushRequestDto);
    	    
    	    String pushUrl = interfaceConfig.getPushServerInfo().getUrl();
    	    
    	    StringBuilder urlBuilder = new StringBuilder();
			urlBuilder.append(pushUrl);
			urlBuilder.append("/api/server/push/alarms/update");
			
			OkHttpClient client = new OkHttpClient();
			client.setConnectTimeout(30, TimeUnit.SECONDS);
			Request request = new Request.Builder()
					.url(urlBuilder.toString())
    	            .post(RequestBody.create(MediaType.parse(org.springframework.http.MediaType.APPLICATION_JSON.toString()), requestJsonString))
    	            .build();
			
			try {
    	    	response = client.newCall(request).execute();
			} catch (ConnectException e) {
				pushResultCd = "3";
    	    } catch (ConnectTimeoutException e) {
    	    	pushResultCd = "4";
    	    } catch (ReadTimeoutException e) {
    	    	pushResultCd = "5";
    	    }
			
			String responseJsonString = StringUtils.defaultString(response.body().string());
			if ("".equals(responseJsonString)) {
				pushResultCd = "2";
			} else {
				
				JsonObject responseJsonObject;
				try {
					responseJsonObject = JsonParser.parseString(responseJsonString).getAsJsonObject();
					
					ObjectMapper objectMapper = new ObjectMapper();
					pushResultDto = objectMapper.readValue(responseJsonObject.toString(), PushResultDto.class);
					String resultCode = StringUtils.defaultString(pushResultDto.getResult());
					if ("success".equals(resultCode)) {
						pushResultCd = "1";
					} else {
						pushResultCd = "2";
					}
					
				} catch (Exception e) {
					pushResultCd = "6";
				}
			}
			
			pushResultDto.setResult(pushResultCd);
			
		} catch (Exception e) {
			throw e;
		}
		
		return pushResultDto;
	}

}
