package com.adtcaps.tsop.dashboard.api.energy.domain;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class WeekendPowerStatVO {

	private String bldId;
	private int dayOfWeek;
	private String dayOfWeekName;
	private Float powerVal;
}
