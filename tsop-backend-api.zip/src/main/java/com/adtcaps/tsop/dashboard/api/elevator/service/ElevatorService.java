package com.adtcaps.tsop.dashboard.api.elevator.service;

import com.adtcaps.tsop.dashboard.api.elevator.domain.ElevatorEventChartResultDto;
import com.adtcaps.tsop.domain.elevator.OfmElevatorEventDto;

/**
 * 
 * <ul>
 * <li>업무 그룹명 : tsop-backend-api</li>
 * <li>서브 업무명 : com.adtcaps.tsop.dashboard.api.elevator.service</li>
 * <li>설  명 : ElevatorService.java</li>
 * <li>작성일 : 2020. 12. 4.</li>
 * <li>작성자 : jeonyb4</li>
 * </ul>
 */
public interface ElevatorService {
	/**
	 * 
	 * listElevatorEventChart
	 *
	 * @param reqOfmElevatorEventDto
	 * @return ElevatorEventChartResultDto
	 * @throws Exception 
	 */
	public ElevatorEventChartResultDto listElevatorEventChart(OfmElevatorEventDto reqOfmElevatorEventDto) throws Exception;

}
