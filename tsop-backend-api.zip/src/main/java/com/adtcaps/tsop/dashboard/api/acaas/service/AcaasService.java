package com.adtcaps.tsop.dashboard.api.acaas.service;

import com.adtcaps.tsop.dashboard.api.acaas.domain.EnterEventCurrentStatePieChartResultDto;
import com.adtcaps.tsop.domain.acaas.OacEnterEventDayStatDto;
import com.adtcaps.tsop.domain.acaas.OacEnterEventDto;
import com.adtcaps.tsop.helper.domain.LineChartResultDto;

/**
 * 
 * <ul>
 * <li>업무 그룹명 : tsop-backend-api</li>
 * <li>서브 업무명 : com.adtcaps.tsop.dashboard.api.acaas.service</li>
 * <li>설  명 : AcaasService.java</li>
 * <li>작성일 : 2020. 12. 4.</li>
 * <li>작성자 : jeonyb4</li>
 * </ul>
 */
public interface AcaasService {
	/**
	 * 
	 * readEnterEventCurrentStatePieChart
	 *
	 * @param reqOacEnterEventDto
	 * @return EnterEventCurrentStatePieChartResultDto
	 * @throws Exception 
	 */
	public EnterEventCurrentStatePieChartResultDto readEnterEventCurrentStatePieChart(OacEnterEventDto reqOacEnterEventDto) throws Exception;
	
	/**
	 * 
	 * listEnterEventAlarmCurrentStateChart
	 *
	 * @param reqOacEnterEventDayStatDto
	 * @return LineChartResultDto
	 * @throws Exception 
	 */
	public LineChartResultDto listEnterEventAlarmCurrentStateChart(OacEnterEventDayStatDto reqOacEnterEventDayStatDto) throws Exception;

}
