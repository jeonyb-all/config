package com.adtcaps.tsop.dashboard.api.fm.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.adtcaps.tsop.dashboard.api.fm.domain.BuildingHeatVO;
import com.adtcaps.tsop.dashboard.api.fm.domain.BuildingSummaryVO;
import com.adtcaps.tsop.dashboard.api.fm.domain.BuildingVO;
import com.adtcaps.tsop.dashboard.api.fm.domain.EquipObjVO;
import com.adtcaps.tsop.dashboard.api.fm.domain.EquipVO;
import com.adtcaps.tsop.dashboard.api.fm.domain.FloorAmbientAirVO;
import com.adtcaps.tsop.dashboard.api.fm.domain.FmTrendVO;
import com.adtcaps.tsop.dashboard.api.fm.domain.FmVO;
import com.adtcaps.tsop.dashboard.api.fm.domain.PowerUnitViewVO;
import com.adtcaps.tsop.dashboard.api.fm.domain.RoomCondition;
import com.adtcaps.tsop.dashboard.api.fm.service.FmService;
import com.adtcaps.tsop.helper.constant.Const.Common.RESULT_CODE;
import com.adtcaps.tsop.helper.domain.ResultDto;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@RestController
@RequestMapping(value = "/api/dashboard/fm")
public class FmController {

	@Autowired
	private FmService fmService;

	//설비운전 현황 장비 목록
	@GetMapping(value="fmEquipment", produces="application/json; charset=UTF-8")
	public @ResponseBody List<FmVO> fmEquipment() {
		List<FmVO> fmEquipmentList = fmService.getFmEquipment();
		return fmEquipmentList;
	}

	@GetMapping(value="powerUnit", produces="application/json; charset=UTF-8")
	public @ResponseBody List<PowerUnitViewVO> powerUnit(Model model) {
		List<PowerUnitViewVO> powerUnitList = fmService.getPowerUnit();
		return powerUnitList;
	}

	//실내온습도
	// RTM: 온도, HMD: 습도
	@GetMapping(value="roomEnvironmentNew", produces="application/json; charset=UTF-8")
	@ResponseBody
	public List<RoomCondition> roomEnvironmentNew(String equipmentCd) {
		List<RoomCondition> powerUnitList = fmService.roomEnvironmentNew(equipmentCd);
		return powerUnitList;
	}

	//실내온습도
	// RTM: 온도, HMD: 습도
	@GetMapping(value="buildingSummary", produces="application/json; charset=UTF-8")
	@ResponseBody
	public ResultDto getWorkingTimeNUsedPower(@RequestParam(required= false, name="bldId") String bldId) {
		List<BuildingSummaryVO> builingSummaryList = fmService.getWorkingTimeNUsedPower(bldId);
		return new ResultDto(RESULT_CODE.SUCCESS, "", builingSummaryList);
	}
	
	//설비운전 현황(평균)
	@GetMapping(value="fmBuildingPointStatAvg", produces="application/json; charset=UTF-8")
	public @ResponseBody List<FmTrendVO> fmBuildingPointStatAvg(@RequestParam(required= false, name="bldId") String bldId) {
		List<FmTrendVO> fmOperationList = fmService.fmBuildingPointStatAvg(bldId);
		return fmOperationList;
	}

	/**
	 * 
	 * <pre>
	 *  메소드명 : fmBuildingEquipHour
	 *  설    명 : 빌딩 최근 24시간 온습도 조회
	 *  작 성 일 : 2020. 12. 21.
	 *  작 성 자 : Jeong.HyunMin
	 * </pre>
	 * @param bldId
	 * @param equipment
	 * @return
	 */
	@GetMapping(value="/building/{bldId}/equipment/{equipment}/24hr", produces="application/json; charset=UTF-8")
	public @ResponseBody BuildingVO fmBuildingEquipHour(@PathVariable("bldId") String bldId, @PathVariable("equipment") String equipment) {
	    return fmService.fmBuildingEquipHour(bldId, equipment);
	}
	
	/**
	 * 
	 * <pre>
	 *  메소드명 : fmBuildingEquipPointHour
	 *  설    명 : 빌딩 포인트별 24시간 온습도 조회 
	 *  작 성 일 : 2020. 12. 21.
	 *  작 성 자 : Jeong.HyunMin
	 * </pre>
	 * @param bldId
	 * @param equipment
	 * @return
	 */
	@GetMapping(value="/building/{bldId}/equipment/{equipment}/24hr/point", produces="application/json; charset=UTF-8")
    public @ResponseBody BuildingVO fmBuildingEquipPointHour(@PathVariable("bldId") String bldId, @PathVariable("equipment") String equipment) {   
        return fmService.fmBuildingEquipPointHour(bldId, equipment);
    }
	
	/**
	 * 
	 * <pre>
	 *  메소드명 : fmBuildingEquipDayWeek
	 *  설    명 : 빌딩 별 최근 7일간 온습도 조회 
	 *  작 성 일 : 2020. 12. 21.
	 *  작 성 자 : Jeong.HyunMin
	 * </pre>
	 * @param equipment
	 * @return
	 */
	@GetMapping(value="/building/equipment/{equipment}/dayweek", produces="application/json; charset=UTF-8")
    public @ResponseBody List<BuildingVO> fmBuildingEquipDayWeek(@PathVariable("equipment") String equipment) {
        return fmService.fmBuildingEquipDayWeek(equipment);
    }
	
	/**
	 * 
	 * <pre>
	 *  메소드명 : getBuildingWorkingTimeNUsedPower
	 *  설    명 : 빌딩군관리자 빌딩별 전력사용 및 사용시간 조회
	 *  작 성 일 : 2020. 12. 23.
	 *  작 성 자 : Jeong.HyunMin
	 * </pre>
	 * @return
	 */
	@GetMapping(value="/building/summary", produces="application/json; charset=UTF-8")    
    public @ResponseBody ResultDto getBuildingWorkingTimeNUsedPower() {
        return new ResultDto(RESULT_CODE.SUCCESS, "", fmService.getBuildingWorkingTimeNUsedPower());
    }
	
	/**
	 * 
	 * <pre>
	 *  메소드명 : getBuildingWorkingTimeNUsedPower
	 *  설    명 : 빌딩 전력사용 및 사용시간 조회
	 *  작 성 일 : 2020. 12. 23.
	 *  작 성 자 : Jeong.HyunMin
	 * </pre>
	 * @param bldId
	 * @return
	 */
	@GetMapping(value="/building/{bldId}/summary", produces="application/json; charset=UTF-8")    
	public @ResponseBody ResultDto getBuildingWorkingTimeNUsedPower(@PathVariable("bldId") String bldId) {
	    return new ResultDto(RESULT_CODE.SUCCESS, "", fmService.getBuildingWorkingTimeNUsedPower(bldId));
	}
	
	/**
	 * 
	 * <pre>
	 *  메소드명 : fmBuildingEquipRefrigerationStatus
	 *  설    명 : 빌딩별 냉방시스템 현황
	 *  작 성 일 : 2020. 12. 29.
	 *  작 성 자 : Jeong.HyunMin
	 * </pre>
	 * @param bldId
	 * @return
	 */
	@GetMapping(value="/building/{bldId}/equipment/refrigeration/status", produces="application/json; charset=UTF-8")
	public @ResponseBody BuildingVO fmBuildingEquipRefrigerationStatus(@PathVariable("bldId") String bldId) {
	    return fmService.fmBuildingEquipRefrigerationStatus(bldId);
	}
	
	/**
     * 
     * <pre>
     *  메소드명 : fmBuildingEquipAirhandlingStatus
     *  설    명 : 빌딩별 공조기 현황
     *  작 성 일 : 2020. 12. 31.
     *  작 성 자 : Jeong.HyunMin
     * </pre>
     * @param bldId
     * @return
     */
    @GetMapping(value="/building/{bldId}/equipment/airhandling/status", produces="application/json; charset=UTF-8")
    public @ResponseBody BuildingVO fmBuildingEquipAirhandlingStatus(@PathVariable("bldId") String bldId) {
        return fmService.fmBuildingEquipAirhandlingStatus(bldId);
    }
	
	/**
	 * 
	 * <pre>
	 *  메소드명 : fmBuildingEquipOperateTime
	 *  설    명 : 냉방시스템별 운전 현황
	 *  작 성 일 : 2020. 12. 29.
	 *  작 성 자 : Jeong.HyunMin
	 * </pre>
	 * @param bldId
	 * @param equipment
	 * @return
	 */
	@GetMapping(value="/building/{bldId}/equipment/{equipment}/operatetime", produces="application/json; charset=UTF-8")
    public @ResponseBody BuildingVO fmBuildingEquipOperateTime(@PathVariable("bldId") String bldId, @PathVariable("equipment") String equipment) {
        return fmService.fmBuildingEquipOperateTime(bldId, equipment);
    }
	
	/**
	 * 
	 * <pre>
	 *  메소드명 : fmBldTypeEquipStatus
	 *  설    명 : 설비별 빌딩군 현황
	 *  작 성 일 : 2020. 12. 30.
	 *  작 성 자 : Jeong.HyunMin
	 * </pre>
	 * @return
	 */
	@GetMapping(value="/equipment/bldType/status", produces="application/json; charset=UTF-8")
	public @ResponseBody List<EquipVO> fmBldTypeEquipStatus() {
        return fmService.fmBldTypeEquipStatus();
    }
	
	/**
	 * 
	 * <pre>
	 *  메소드명 : fmBuildingEquipStatus
	 *  설    명 : 설비별 빌딩 현황
	 *  작 성 일 : 2020. 12. 30.
	 *  작 성 자 : Jeong.HyunMin
	 * </pre>
	 * @return
	 */
	@GetMapping(value="/equipment/building/status", produces="application/json; charset=UTF-8")
    public @ResponseBody List<EquipVO> fmBuildingEquipStatus() {
        return fmService.fmBuildingEquipStatus();
    }
	
	/**
     * 
     * <pre>
     *  메소드명 : fmBuildingEquipStatus
     *  설    명 : 설비별 빌딩 현황
     *  작 성 일 : 2020. 12. 30.
     *  작 성 자 : Jeong.HyunMin
     * </pre>
     * @return
     */
    @GetMapping(value="/equipment/building/{bldId}/status", produces="application/json; charset=UTF-8")
    public @ResponseBody List<EquipVO> fmBuildingEquipStatus(@PathVariable("bldId") String bldId) {
        return fmService.fmBuildingEquipStatus(bldId);
    }
	
	/**
	 * 
	 * <pre>
	 *  메소드명 : fmBuildingAirhandlingSummary
	 *  설    명 : 빌딩 공조기 현황
	 *  작 성 일 : 2021. 1. 4.
	 *  작 성 자 : Jeong.HyunMin
	 * </pre>
	 * @param bldId
	 * @return
	 */
	@GetMapping(value="/building/{bldId}/equipment/airhandling/summary", produces="application/json; charset=UTF-8")
    public @ResponseBody BuildingVO fmBuildingAirhandlingSummary(@PathVariable("bldId") String bldId) {
        return fmService.fmBuildingAirhandlingSummary(bldId);
    }
	
	/**
	 * 
	 * <pre>
	 *  메소드명 : fmBuildingFloor
	 *  설    명 : 빌딩 층 목록 조회 
	 *  작 성 일 : 2021. 1. 4.
	 *  작 성 자 : Jeong.HyunMin
	 * </pre>
	 * @param bldId
	 * @return
	 */
	@GetMapping(value="/building/{bldId}/floor", produces="application/json; charset=UTF-8")
    public @ResponseBody BuildingVO fmBuildingFloor(@PathVariable("bldId") String bldId) {
        return fmService.fmBuildingFloor(bldId);
    }
	
	/**
	 * 
	 * <pre>
	 *  메소드명 : fmBuildingEquipHeatingStatus
	 *  설    명 : 빌딩 난방 시스템 현황
	 *  작 성 일 : 2021. 1. 5.
	 *  작 성 자 : Jeong.HyunMin
	 * </pre>
	 * @param bldId
	 * @return
	 */
	@GetMapping(value="/building/{bldId}/equipment/heating/status", produces="application/json; charset=UTF-8")
    public @ResponseBody BuildingVO fmBuildingEquipHeatingStatus(@PathVariable("bldId") String bldId) {
        return fmService.fmBuildingEquipHeatingStatus(bldId);
    }
	
	/**
	 * 
	 * <pre>
	 *  메소드명 : fmBuildingEquipHeatingDetail
	 *  설    명 : 빌딩 난방 시스템 현황 상세
	 *  작 성 일 : 2021. 1. 5.
	 *  작 성 자 : Jeong.HyunMin
	 * </pre>
	 * @param bldId
	 * @return
	 */
	@GetMapping(value="/building/{bldId}/equipment/heating/detail", produces="application/json; charset=UTF-8")
    public @ResponseBody BuildingHeatVO fmBuildingEquipHeatingDetail(@PathVariable("bldId") String bldId) {
        return fmService.fmBuildingEquipHeatingDetail(bldId);
    }
	
	/**
	 * 
	 * <pre>
	 *  메소드명 : fmBuildingEquipRefrigerationWeek
	 *  설    명 : 빌딩 냉동기별 Week Trend 조회 
	 *  작 성 일 : 2021. 1. 5.
	 *  작 성 자 : Jeong.HyunMin
	 * </pre>
	 * @param bldId
	 * @return
	 */
	@GetMapping(value="/building/{bldId}/equipment/refrigeration/week", produces="application/json; charset=UTF-8")
    public @ResponseBody List<EquipObjVO> fmBuildingEquipRefrigerationWeek(@PathVariable("bldId") String bldId) {
        return fmService.fmBuildingEquipRefrigerationWeek(bldId);
    }
	
	/**
	 * 
	 * <pre>
	 *  메소드명 : fmBuildingEquipAmbientAirFloorState
	 *  설    명 : 빌딩 외기 냉방 운영 현황 조회 
	 *  작 성 일 : 2021. 1. 6.
	 *  작 성 자 : Jeong.HyunMin
	 * </pre>
	 * @param bldId
	 * @param floor
	 * @return
	 */
	@GetMapping(value="/building/{bldId}/equipment/ambientAir/floor/{floor}/hourState", produces="application/json; charset=UTF-8")
	public @ResponseBody List<FloorAmbientAirVO> fmBuildingEquipAmbientAirFloorState(@PathVariable("bldId") String bldId, @PathVariable("floor") String floor) {
        return fmService.fmBuildingEquipAmbientAirFloorState(bldId, floor);
    }
	
	/**
	 * 
	 * <pre>
	 *  메소드명 : fmBldTypeRefrigerationWeek
	 *  설    명 : 사옥별  냉동기 Cop, 냉수 입출구, 냉각수 입출구 조회
	 *  작 성 일 : 2021. 1. 11.
	 *  작 성 자 : Jeong.HyunMin
	 * </pre>
	 * @return
	 */
	@GetMapping(value="/equipment/refrigeration/bldType/week", produces="application/json; charset=UTF-8")
    public @ResponseBody List<BuildingVO> fmBldTypeRefrigerationWeek() {
        return fmService.fmBldTypeRefrigerationWeek();
    }
}
