package com.adtcaps.tsop.dashboard.api.elevator.service.impl;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.CollectionUtils;

import com.adtcaps.tsop.dashboard.api.elevator.domain.ElevatorDailyReportResultDto;
import com.adtcaps.tsop.dashboard.api.elevator.domain.ElevatorEventChartResultDto;
import com.adtcaps.tsop.dashboard.api.elevator.domain.ElevatorEventResultDto;
import com.adtcaps.tsop.dashboard.api.elevator.domain.EscalatorEventDataResultDto;
import com.adtcaps.tsop.dashboard.api.elevator.domain.EscalatorEventResultDto;
import com.adtcaps.tsop.dashboard.api.elevator.service.ElevatorService;
import com.adtcaps.tsop.domain.elevator.OfmElevatorEventDto;
import com.adtcaps.tsop.helper.util.CommonObjectUtil;
import com.adtcaps.tsop.mapper.elevator.OfmElevatorEventMapper;

/**
 * 
 * <ul>
 * <li>업무 그룹명 : tsop-backend-api</li>
 * <li>서브 업무명 : com.adtcaps.tsop.dashboard.api.elevator.service.impl</li>
 * <li>설  명 : ElevatorServiceImpl.java</li>
 * <li>작성일 : 2020. 12. 4.</li>
 * <li>작성자 : jeonyb4</li>
 * </ul>
 */
@Transactional
@Service
public class ElevatorServiceImpl implements ElevatorService {
	
	@Autowired
	private OfmElevatorEventMapper ofmElevatorEventMapper;
	
	/**
	 * 
	 * listElevatorEventChart
	 *
	 * @param reqOfmElevatorEventDto
	 * @return ElevatorEventChartResultDto
	 * @throws Exception 
	 */
	@Override
	public ElevatorEventChartResultDto listElevatorEventChart(OfmElevatorEventDto reqOfmElevatorEventDto) throws Exception {
		
		ElevatorEventChartResultDto elevatorEventChartResultDto = null;
		
		try {
			// 빌딩별 엘리베이터 현황 조회...
			List<ElevatorEventResultDto> elevatorEventResultDtoList = ofmElevatorEventMapper.listElevatorEventChart(reqOfmElevatorEventDto);
			
			// 빌딩별 에스컬레이터 현황 조회...
			List<EscalatorEventDataResultDto> escalatorEventDataResultDtoList = ofmElevatorEventMapper.listEscalatorEventChart(reqOfmElevatorEventDto);
			
			if (!CollectionUtils.isEmpty(elevatorEventResultDtoList) || !CollectionUtils.isEmpty(escalatorEventDataResultDtoList)) {
				elevatorEventChartResultDto = new ElevatorEventChartResultDto();
				if (!CollectionUtils.isEmpty(elevatorEventResultDtoList)) {
					elevatorEventChartResultDto.setElevatorList(elevatorEventResultDtoList);
				}
				if (!CollectionUtils.isEmpty(escalatorEventDataResultDtoList)) {
					List<EscalatorEventResultDto> escalatorEventResultDtoList = new ArrayList<EscalatorEventResultDto>(); // 최종 넣을 곳...
					List<EscalatorEventDataResultDto> newEscalatorEventDataResultDtoList = new ArrayList<EscalatorEventDataResultDto>();
					EscalatorEventResultDto escalatorEventResultDto = new EscalatorEventResultDto();
					String bfEscalatorName = "";
					int idx = 0;
					for (EscalatorEventDataResultDto escalatorEventDataResultDto : escalatorEventDataResultDtoList) {
						String escalatorName = StringUtils.defaultString(escalatorEventDataResultDto.getEscalatorName());
						idx = idx + 1;
						if (bfEscalatorName.equals(escalatorName)) {
							newEscalatorEventDataResultDtoList.add(escalatorEventDataResultDto);
						} else {
							if (!"".equals(bfEscalatorName)) {
								// 이전 데이터가 있으면.. 이전데이터 add 하고 new...
								escalatorEventResultDto.setDatas(newEscalatorEventDataResultDtoList);
								escalatorEventResultDtoList.add(escalatorEventResultDto);
								
								escalatorEventResultDto = new EscalatorEventResultDto();
								newEscalatorEventDataResultDtoList = new ArrayList<EscalatorEventDataResultDto>();
							}
							escalatorEventResultDto.setEscalatorName(escalatorName);
							newEscalatorEventDataResultDtoList.add(escalatorEventDataResultDto);
							
							bfEscalatorName = escalatorName;
						}
						// 마지막 데이터 이면...
						if (escalatorEventDataResultDtoList.size() == idx) {
							escalatorEventResultDto.setDatas(newEscalatorEventDataResultDtoList);
							escalatorEventResultDtoList.add(escalatorEventResultDto);
							break;
						}
					}
					elevatorEventChartResultDto.setEscalatorList(escalatorEventResultDtoList);
				}
				// 빌딩별 일일 리포트 조회...
				ElevatorDailyReportResultDto elevatorDailyReportResultDto = ofmElevatorEventMapper.readElevatorDailyReport(reqOfmElevatorEventDto);
				if (elevatorDailyReportResultDto != null) {
					int elevatorRunMunitTm = CommonObjectUtil.defaultNumber(elevatorDailyReportResultDto.getElevatorRunMunitTm());
					if (elevatorRunMunitTm == 0) {
						elevatorDailyReportResultDto.setElevatorRunHour(0);
						elevatorDailyReportResultDto.setElevatorRunMinute(0);
					} else {
						int elevatorRunHour = elevatorRunMunitTm / 60;
						int elevatorRunMinute = elevatorRunMunitTm % 60;
						elevatorDailyReportResultDto.setElevatorRunHour(elevatorRunHour);
						elevatorDailyReportResultDto.setElevatorRunMinute(elevatorRunMinute);
					}
				}
				elevatorEventChartResultDto.setDailyReportInfo(elevatorDailyReportResultDto);
			}
			
			
		} catch (Exception e) {
			throw e;
		}
		return elevatorEventChartResultDto;
	}

}
