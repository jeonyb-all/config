package com.adtcaps.tsop.dashboard.api.parking.domain;

import lombok.Getter;
import lombok.Setter;

/**
 * 
 * <ul>
 * <li>업무 그룹명 : tsop-backend-api</li>
 * <li>서브 업무명 : com.adtcaps.tsop.dashboard.api.parking.domain</li>
 * <li>설  명 : ParkingReportResultDto.java</li>
 * <li>작성일 : 2021. 1. 7.</li>
 * <li>작성자 : jeonyb4</li>
 * </ul>
 */
@Getter
@Setter
public class ParkingReportResultDto {
	private String bldId;
	private String bldName;
	private Integer todayUvInoutvehicleCount;
	private Integer weekAvgPrkMinuteUnitTm;
	private Integer weekAvgPrkHour;
	private Integer weekAvgPrkMinute;
	private Integer totAvailPrkslotcnt;
	private Integer totPrkslotcnt;
	private String prksiteCongestionVal;
	
}
