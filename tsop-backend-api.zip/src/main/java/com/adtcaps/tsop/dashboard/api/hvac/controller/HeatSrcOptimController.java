package com.adtcaps.tsop.dashboard.api.hvac.controller;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.util.CollectionUtils;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.adtcaps.tsop.authentication.domain.JwtAuthResultDto;
import com.adtcaps.tsop.dashboard.api.hvac.domain.AirEnvirResultVO;
import com.adtcaps.tsop.dashboard.api.hvac.domain.HeatSourceOptiResultVO;
import com.adtcaps.tsop.dashboard.api.hvac.service.HeatSrcOptimService;
import com.adtcaps.tsop.domain.inventory.OivBuildingDto;
import com.adtcaps.tsop.helper.constant.Const;
import com.adtcaps.tsop.helper.domain.ResultDto;
import com.adtcaps.tsop.portal.api.building.domain.BuildingDetailResultDto;
import com.adtcaps.tsop.portal.api.building.service.BuildingService;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.extern.slf4j.Slf4j;


@Api(value = "대시보드업무 HVAC 열원최적화운전 API", tags = {"대시보드업무 HVAC 열원최적화운영 서비스카드 API"})
@Tag(name = "대시보드업무 HVAC 열원최적화운영 서비스카드 API", description = ""
		+ "``` \n"
		+ "(1)실시간 통합대기환경  분석  조회 요구사항\n"
		+ "  1) dbo.oot_air_quality 의 공기질 관련 항목 표출(PM10,PM2.5) \n"
		+ "  2) 관측소 정보 표시(ex.종로구)  \n"
		+ "  3)  수치값에 따라 말풍선 이동(좌,우) \n"
		+ "  4) 수치값에 따른 상태메시지 표출(단계별) -대기질(PM10,PM2.5)만 표시   \n"
		+ "  5)외부엔탈피,PM10,PM2.5 각각 범위값은 경보지표관리에서 관리한다.  \n"
		+ "  6)범위 색상 : 좋음 (파란색), 보통( 초록색), 나쁨 ( 주황), 매우나쁨( 빨강)  \n"
		+ "  7)PM10,PM2.5 기준값이 저장된게 없을경우 환경부 기준값으로 화면에 보내준다.  \n"
		+ "    PM10 (㎍/㎥) :  0~30 :좋음,  31~80:보통, 81~150:나쁨,  151이상 : 매우나쁨  \n"
		+ "    PM2.5(㎍/㎥) : 0~15 : 좋음 , 16~35 :보통, 36~75: 나쁨  , 76 이상 : 매우나쁨  \n" 
		+ "  8)15분마다 갱신이지만 공공API에서 제공하는  데이터는 1시간별 데이터이다 \n"
		+ "   배치주기 15분    \n"

		
		+ "(2)열원조합 최적화 운영 가이드  조회 요구사항\n"
		+ "  1) 권장열원 표시 (Azuer PaaS분석계에서 제공)- 시간단위 실행 \n"
		+ "  2) 권장운영값 ON 이면  GREEN ,OFF이면 GRAY \n"  
		+ "  3) 데이터주기 1시간주기 갱신,화면갱신 1시간주기 \n" 
		+ "``` \n")
@Slf4j
@RestController
@RequestMapping(value = "/api/dashboard/hvac/heatSrc")
public class HeatSrcOptimController {
	private final String ERR_MSG_NULL_LOGIN_USER_ID = "로그인 사용자ID가 없습니다.";
	private final String ERR_MSG_NULL_BLD_ID = "빌딩ID가 없습니다."; 

	private final String ERR_MSG_NULL_SEARCH_RESULT_LIST = "조회 결과가 없습니다.";
	private final String ERR_MSG_READ_FAIL = "조회에 실패하였습니다.";
	private final String ERR_MSG_UPDATE_FAIL = "저장에 실패하였습니다.";
	private final String ERR_MSG_DELETE_FAIL = "삭제에 실패하였습니다.";
	

    @Autowired
    private BuildingService buildingService;
    
	@Autowired
	private HeatSrcOptimService heatSrcOptimService;

	@ApiOperation(nickname = "실시간 통합대기환경  분석  조회", value = "실시간 통합대기환경  분석  조회"
			, notes = "``` \n"
				+"건물 외기의 엔탈피, 관측소에서 제공한 대기질(PM10,PM2.5) 수치를 조회한다. \n"
				+"``` \n" 

		        +"```"
		        + "sequence\n"
		        + "User -> 열원최적화Controller: GET /api/dashboard/hvac/heatSrc/building/{bldId}/integrated/air \n"
		        + "열원최적화Controller -> 열원최적화Controller : 입력값 유효성체크\n"
		        + "열원최적화Controller -> 열원최적화Service: 조회요청\n"
				+ "열원최적화Service    -> 열원최적화Mapper: 조회요청\n"
				+ "열원최적화Mapper     -> Database: 조회요청\n"
				+ "Note right of Database :  구성_관리기준값상세(경보지표관리)-대기질기준\\n설비_외부환경15분집계\n" 
				+ "Database              --> 열원최적화Mapper: return 조회결과 \n" 
				+ "열원최적화Mapper     --> 열원최적화Service: 조회결과List \n"
				+ "열원최적화Service    --> 열원최적화Controller: 조회결과List\n"
				+ "열원최적화Controller --> User : 실시간 통합대기환경  조회 결과 JSON Object\\n-건물ID,층(OUT),실시간 온도,습도,엔탈피,PM10농도,PM2.5농도,관측소명\\n-대기질기준 : 대기질구분(엔탈피,PM2.5,Pm10),대기질상태명,From값,to값  \n"
				+ "```\n"						
				+ "")
	//@ResponseBody AirEnvirResultVO
	@GetMapping(value="building/{bldId}/integrated/air", produces="application/json; charset=UTF-8")
	public ResponseEntity findRealTimeIntegratedAir(
			@AuthenticationPrincipal JwtAuthResultDto authResultDto, 
			@ApiParam(value = "건물ID", required = true, example = "0000") 
			@PathVariable(required = true) String bldId
			) {

    	ResponseEntity<ResultDto> resEntity = null;
		String returnString = "";
		//로그인체크
		String loginUserId = StringUtils.defaultString(authResultDto.getUserId());
		if ("".equals(loginUserId)) {
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_LOGIN_USER_ID));
			return resEntity;
		}

		//빌딩체크 
		if (bldId==null || "".equals(bldId)) {
			log.error(">>>>>> bldId ERROR:{}", ERR_MSG_NULL_BLD_ID);
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_BLD_ID));
			return resEntity;
		}
		AirEnvirResultVO airEnvirResultVO = heatSrcOptimService.findRealTimeIntegratedAir(bldId);
		
		
		if (airEnvirResultVO == null || CollectionUtils.isEmpty(airEnvirResultVO.getAirQualityList())) {
			//오류가 아닌 데이터가 없을때 C0000
            String returnMesg = "";
		    if(CollectionUtils.isEmpty(airEnvirResultVO.getAirQualityList())){
                returnString = Const.Common.RESULT_CODE.SUCCESS;
                returnMesg = ERR_MSG_NULL_SEARCH_RESULT_LIST;
             }else { 
                returnString = Const.Common.RESULT_CODE.FAIL;
                returnMesg = ERR_MSG_READ_FAIL;
             } 
			if(airEnvirResultVO == null )  airEnvirResultVO = new AirEnvirResultVO();
            
			resEntity = ResponseEntity.ok(new ResultDto(returnString, returnMesg, airEnvirResultVO ));
		} else {
			returnString = Const.Common.RESULT_CODE.SUCCESS; 
			resEntity = ResponseEntity.ok(new ResultDto(returnString, "", airEnvirResultVO));
		}
    	
    	return resEntity;
	}
 
	

	@ApiOperation(nickname = "열원조합 최적화 운영 가이드  조회", value = "열원조합 최적화 운영 가이드  조회"
			, notes = "``` \n"
				+"건물의 각각 냉방설비에 대해 권장열원(냉수펌프,냉각수펌프), 사용열원(냉수펌프,냉각수펌프)을 조회하여 화면에 보여준다. \n"
				+"``` \n"

		        +"```"
		        + "sequence\n"
		        + "User -> 열원최적화Controller: GET /api/dashboard/hvac/heatSrc/building/{bldId}/heatSource/optimize \n"
		        + "열원최적화Controller -> 열원최적화Controller : 입력값 유효성체크\n"
		        + "열원최적화Controller -> 열원최적화Service: 조회요청\n"
				+ "열원최적화Service    -> 열원최적화Mapper: 조회요청\n"
				+ "열원최적화Mapper     -> Database: 조회요청\n"
				+ "Note right of Database :  [PASS-연동]설비_열원일자시기준내역  \n" 
				+ "Database              --> 열원최적화Mapper: return 조회결과 \n" 
				+ "열원최적화Mapper     --> 열원최적화Service: 조회결과List \n"
				+ "열원최적화Service    --> 열원최적화Controller: 조회결과List\n"
				+ "열원최적화Controller --> User : 열원조합 최적화 운영  조회 결과 JSON Object\\n-권장열원:건물ID,측정일자시분,열원오브젝트ID,열원명\\n-,권장열원상태(ON/OFF),냉수펌프권장열원비율,냉각수펌프권장열원비율 \n"
				+ "```\n"
					)
	//@ResponseBody HeatSourceOptiResultVO
	@GetMapping(value="building/{bldId}/heatSource/optimize", produces="application/json; charset=UTF-8")
	public @ResponseBody ResponseEntity findHeatSourceOptimize(
			@AuthenticationPrincipal JwtAuthResultDto authResultDto, 
			@ApiParam(value = "건물ID", required = true, example = "0000") 
			@PathVariable(required = true) String bldId
			) {

    	ResponseEntity<ResultDto> resEntity = null;
		String returnString = "";
		//로그인체크
		String loginUserId = StringUtils.defaultString(authResultDto.getUserId());
		if ("".equals(loginUserId)) {
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_LOGIN_USER_ID));
			return resEntity;
		}

		//빌딩체크 
		if (bldId==null || "".equals(bldId)) {
			log.error(">>>>>> bldId ERROR:{}", ERR_MSG_NULL_BLD_ID);
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_BLD_ID));
			return resEntity;
		}
        // 빌딩정보..
        String bldName = "";
        try {
            OivBuildingDto reqOivBuildingDto = new OivBuildingDto();
            reqOivBuildingDto.setBldId(bldId);
            
            BuildingDetailResultDto buildingDetailResultDto = buildingService.readBuilding(reqOivBuildingDto);
            if (buildingDetailResultDto != null) {
                bldName = StringUtils.defaultString(buildingDetailResultDto.getBldAbbrName());
            } 
        }catch(Exception e) {
            log.debug("findHeatSourceOptimize buildingService.readBuilding exception:{}",e.getMessage());
        }
		HeatSourceOptiResultVO heatSourceOptiResultVO =  heatSrcOptimService.findHeatSourceOptimize(bldId,bldName);
		
		

		//if (heatSourceOptiResultVO == null || CollectionUtils.isEmpty(heatSourceOptiResultVO.getHeatSourceList()) ) {
		//데이터가 없을때  기준시간은 출력되고  데이터가 없습니다.로 하기 위해 
		if (heatSourceOptiResultVO == null ) {
			returnString = Const.Common.RESULT_CODE.FAIL;
			if(heatSourceOptiResultVO == null )  heatSourceOptiResultVO = new HeatSourceOptiResultVO();
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_SEARCH_RESULT_LIST,   heatSourceOptiResultVO) );
		} else {
			returnString = Const.Common.RESULT_CODE.SUCCESS; 
			resEntity = ResponseEntity.ok(new ResultDto(returnString, "", heatSourceOptiResultVO));
		}
    	
    	return resEntity;
	}


	

}
