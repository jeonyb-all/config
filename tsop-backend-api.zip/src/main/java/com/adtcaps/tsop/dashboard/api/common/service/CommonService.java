package com.adtcaps.tsop.dashboard.api.common.service;

import java.util.List;

import com.adtcaps.tsop.dashboard.api.common.domain.DashboardCardRequestDto;
import com.adtcaps.tsop.dashboard.api.common.domain.DashboardCardTabResultDto;
import com.adtcaps.tsop.dashboard.api.common.domain.GuideScheduleRequestDto;
import com.adtcaps.tsop.dashboard.api.common.domain.GuideScheduleResultDto;
import com.adtcaps.tsop.domain.common.OcoGuideScheduleDto;
import com.adtcaps.tsop.domain.common.OcoUserDashboardCardDto;
import com.adtcaps.tsop.portal.api.board.domain.BulletinboardGridRequestDto;
import com.adtcaps.tsop.portal.api.board.domain.BulletinboardGridResultDto;

/**
 * 
 * <ul>
 * <li>업무 그룹명 : tsop-backend-api</li>
 * <li>서브 업무명 : com.adtcaps.tsop.dashboard.api.common.service</li>
 * <li>설  명 : CommonService.java</li>
 * <li>작성일 : 2020. 12. 4.</li>
 * <li>작성자 : jeonyb4</li>
 * </ul>
 */
public interface CommonService {
	/**
	 * 
	 * listDashboardCard
	 *
	 * @param dashboardCardRequestDto
	 * @return List<DashboardCardTabResultDto>
	 * @throws Exception 
	 */
	public List<DashboardCardTabResultDto> listDashboardCard(DashboardCardRequestDto dashboardCardRequestDto) throws Exception;
	
	
	/**
	 * 
	 * updateGuideScheduleCheckYn
	 *
	 * @param reqOcoGuideScheduleDto
	 * @return int
	 * @throws Exception 
	 */
	public int updateGuideScheduleCheckYn(OcoGuideScheduleDto reqOcoGuideScheduleDto) throws Exception;
	
	/**
	 * 
	 * listDashboardNoticeBulletinboard
	 *
	 * @param bulletinboardGridRequestDto
	 * @return List<BulletinboardGridResultDto>
	 * @throws Exception 
	 */
	public List<BulletinboardGridResultDto> listDashboardNoticeBulletinboard(BulletinboardGridRequestDto bulletinboardGridRequestDto) throws Exception;
	
	/**
	 * 
	 * listUserDashboardCard
	 * 
	 * @param dashboardCardRequestDto
	 * @param dashboardCardTabResultDtoList
	 * @return List<OcoUserDashboardCardDto>
	 * @throws Exception 
	 */
	public List<OcoUserDashboardCardDto> listUserDashboardCard(DashboardCardRequestDto dashboardCardRequestDto, List<DashboardCardTabResultDto> dashboardCardTabResultDtoList) throws Exception;
	/**
	 * 
	 * mergeOcoUserDashboardCard
	 *
	 * @param reqOcoUserDashboardCardDto
	 * @return int
	 * @throws Exception 
	 */
	public int mergeOcoUserDashboardCard(OcoUserDashboardCardDto reqOcoUserDashboardCardDto) throws Exception;
	
	/**
	 * 
	 * deleteUserDashboardCardElecTabHvacTab
	 *
	 * @param reqOcoUserDashboardCardDto
	 * @return int
	 * @throws Exception 
	 */
	public int deleteUserDashboardCardElecTabHvacTab(OcoUserDashboardCardDto reqOcoUserDashboardCardDto) throws Exception;
	
	
	/******************************* Old Version ***********************************************/
	
	/**
	 * 
	 * listCalendarYyyymm
	 *
	 * @param guideScheduleRequestDto
	 * @return List<String>
	 * @throws Exception 
	 */
	public List<String> listCalendarYyyymm(GuideScheduleRequestDto guideScheduleRequestDto) throws Exception;
	
	/**
	 * 
	 * listCurrentGuideSchedule
	 *
	 * @param guideScheduleRequestDto
	 * @return GuideScheduleResultDto
	 * @throws Exception 
	 */
	public GuideScheduleResultDto listCurrentGuideSchedule(GuideScheduleRequestDto guideScheduleRequestDto) throws Exception;
	
	/**
	 * 
	 * listGuideSchedule
	 *
	 * @param guideScheduleRequestDto
	 * @return
	 * @throws Exception GuideScheduleResultDto
	 */
	public GuideScheduleResultDto listGuideSchedule(GuideScheduleRequestDto guideScheduleRequestDto) throws Exception;
	
}
