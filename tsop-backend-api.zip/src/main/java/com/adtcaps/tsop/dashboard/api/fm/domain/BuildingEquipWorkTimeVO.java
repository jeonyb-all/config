package com.adtcaps.tsop.dashboard.api.fm.domain;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class BuildingEquipWorkTimeVO {
    
	private String bldId;                      //건물Id
	private String bldName;			           //건물명
	private String equipmentCd;                //설비코드
	private String equipmentName;              //설비명
	private Integer sortSeq;                   //순서
	private Float equipDeviation;	           //가동시간 편차
	private Float equipUpTime;		           //가동시간

}
