package com.adtcaps.tsop.dashboard.api.fm.domain;

import java.util.ArrayList;
import java.util.List;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class BuildingVO {
	private String bldId;
	private String bldName;			                         //건물명
	private String bldTypeCd;
    private Float bldTotalfloorareaSize;
    private String auditDatetime;
	private List<Float> periodHour;
    private List<Float> currentVal;
    private Double mgmtBaseTempr;							// jeonyb 추가
    private Integer overTemprCellCount;						// jeonyb 추가
	private List<BuildingPointVO> objectList = new ArrayList<BuildingPointVO>();                       //빌딩 포인트 정보
	private List<BuildingFloorVO> floorList = new ArrayList<BuildingFloorVO>();                        //빌딩 층목록 정보
	private List<BuildingEquipDayWeekVO> weekDayList = new ArrayList<BuildingEquipDayWeekVO>();        //최근 7일
	private List<DayWeekVO> ChrDayWeekList = new ArrayList<DayWeekVO>();           //냉동기
	private List<DayWeekVO> CltDayWeekList = new ArrayList<DayWeekVO>();           //냉각탑	
	private List<DayWeekVO> AhuDayWeekList = new ArrayList<DayWeekVO>();           //공조기
	private List<DayWeekVO> BlrDayWeekList = new ArrayList<DayWeekVO>();           //보일러
	private List<DayWeekVO> HexDayWeekList = new ArrayList<DayWeekVO>();           //열교환기
	private List<ObjectOprTmVO> oprTmList  = new ArrayList<ObjectOprTmVO>();        //
	private List<ObjStatusVO> statusList = new ArrayList<ObjStatusVO>();           //
}
