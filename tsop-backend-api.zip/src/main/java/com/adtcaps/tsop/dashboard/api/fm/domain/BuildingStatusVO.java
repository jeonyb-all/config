package com.adtcaps.tsop.dashboard.api.fm.domain;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class BuildingStatusVO {
    private String bldTypeCd;                               //빌딩구분 코드
    private String bldTypeCdName;                           //빌딩구분 코드 명
    private String facilityMcategoryCd;                     //카테고리 중분류 코드
    private String facilityMcategoryCdName;                 //카테고리 중분류 코드 명
    private Integer bldCnt;                                 //빌딩건수
    private String bldId;                                   //빌딩Id
    private String bldName;                                 //빌딩명
    private Integer facilityOperateCnt;                     //설비가동개수
    private String facilityOperateStartHourminute;          //설비가동시작시분
    private String facilityOperateSuspendHourminute;        //설비가동정지시분
    private Integer facilityOperateTm;                      //설비가동시간
    private Float chilledwaterSupplyTemprVal;               //냉수공급온도값
    private Float chilledwaterReturnTemprVal;               //냉수반환온도값
    private Float cowSupplyTemprVal;                        //냉각수공급온도값
    private Float cowReturnTemprVal;                        //냉각수반환온도값
    private Float chrFlowrateVal;                           //냉동기유량값
    private Float chrCopVal;                                //냉동기CoP값
    private Float ahuSupplyTemprVal;                        //공조기공급온도값
    private Float ahuReturnTemprVal;                        //공조기반환온도값
    private Float ahuReturnSetupTemprVal;                   //공조기반환설정온도값
    private Float ahuReturnHumidityVal;                     //공조기반환습도값
    private Float ahuDamperOpeningRate;                     //공조기댐퍼개도율
    private String locFloor;                                //위치층수
    private Float blrSupplyTemprVal;                        //보일러공급온도값
    private Float blrReturnTemprVal;                        //보일러반환온도값
    private Float hexSupplyTemprVal;                        //열교환기공급온도값
    private Float hexReturnTemprVal;                        //열교환기반환온도값
}
