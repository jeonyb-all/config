package com.adtcaps.tsop.dashboard.api.hvac.domain;

import javax.validation.constraints.Size;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@ApiModel(value = "DB 전력소비량 목록정보", description = "전력소비량 정보을 보여준다.")
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class PowerMinuteConsumptionAllVO { 
 
	@ApiModelProperty(position = 1 , required = false, value="건물ID", example = "0000")
	@Size(min = 1, max = 4, message="건물ID는 4자리입니다")
    private String bldId;//건물ID
 
	@ApiModelProperty(position = 3 , required = false, value="시분", example = "1300")
	private String hourminute;//시분 4자리

	@ApiModelProperty(position = 5 , required = false, value="시분Str", example = "13:00")
	private String hourminuteStr;//시분 4자리
	
	private String collectDateHourminute;// yyyyMMddHHmm
	    
	@ApiModelProperty(position = 7 , required = false, value="peak기준전력", example = "28.34")
	private Float peakStndPowerVal;//peak기준전력
	
	@ApiModelProperty(position = 9 , required = false, value="전력소비량", example = "25.35")
	private Float powerUseVal;//전력소비량

    @ApiModelProperty(position = 9 , required = false, value="전력소비량(W)", example = "25.35")
    private Float powerUseWattVal;//전력소비량(W)

	public PowerMinuteConsumptionVO toPowerMinuteConsumptionVO() {
		PowerMinuteConsumptionVO powerMinuteConsumptionVO = new PowerMinuteConsumptionVO();
		
		powerMinuteConsumptionVO.setHourminute(this.hourminute);
		powerMinuteConsumptionVO.setHourminuteStr(this.hourminuteStr); 
        powerMinuteConsumptionVO.setCollectDateHourminute(this.collectDateHourminute); 
		powerMinuteConsumptionVO.setPeakStndPowerVal(this.peakStndPowerVal); 
		powerMinuteConsumptionVO.setPowerUseVal(this.powerUseVal);  
        powerMinuteConsumptionVO.setPowerUseWattVal(this.powerUseWattVal);  
		return powerMinuteConsumptionVO;
	}
	
}
