package com.adtcaps.tsop.dashboard.api.hvac.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;

import com.adtcaps.tsop.dashboard.api.hvac.domain.AirQualityCO2InfoVO;
import com.adtcaps.tsop.dashboard.api.hvac.domain.FloorOccupantInfoVO;
import com.adtcaps.tsop.dashboard.api.hvac.domain.FloorPreHourAirQualityCO2AllVO;
import com.adtcaps.tsop.dashboard.api.hvac.domain.FloorPreHourOccupantAllVO;
import com.adtcaps.tsop.dashboard.api.hvac.domain.FloorRecmdVentiRateVO;

@Mapper
public interface VentiCtrlMapper {
	/**
	 * 층별 재실자 현황 조회
	 * @param bldId
	 * @return
	 */ 
	public List<FloorOccupantInfoVO> getFloorOccupantInfoList(String bldId);
	/**
	 * 층별 재실자 현황 상세조회
	 * @param bldId
	 * @return
	 */ 
	public List<FloorPreHourOccupantAllVO> getFloorPreHourOccupantList(String bldId);
	
 
  /**
   * 층별 공기질(CO2) 현황 상세조회
   * @param bldId
   * @return
   */ 
    public List<FloorPreHourAirQualityCO2AllVO> getFloorPreHourAirQualityCO2List(String bldId);
      
  /**
   * 층별 공기질(CO2) 목록조회:층별 재실자 현황에서 사용
   * @param bldId
   * @return
   */ 
    public List<AirQualityCO2InfoVO> getFloorAirQualityCO2AllListForOccupant(String bldId);
    
    /**
     * 층별 공기질(CO2) 목록조회:실시간 상세조회에서 사용
     * @param bldId
     * @return
     */ 
      public List<AirQualityCO2InfoVO> getFloorAirQualityCO2AllListForDetail(String bldId);
     
	/**
	 * 층별 권장환기량
	 * @param bldId
	 * @return
	 */
	List<FloorRecmdVentiRateVO> getRecmdVentirateList(String bldId);

}
