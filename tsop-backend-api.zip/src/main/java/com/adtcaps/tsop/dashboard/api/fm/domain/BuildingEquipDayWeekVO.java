package com.adtcaps.tsop.dashboard.api.fm.domain;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class BuildingEquipDayWeekVO {
    private String bldId;
    private String bldName;             //건물명
    private String queryDate;           //날짜
    private String dateFormat;          //데이트포맷
    private String dayWeek;             //요일 코드
    private String dayWeekName;         //요일
    private Integer seq;                //순번
    private Float curVal;               //현재통계값
    private Float chilledwaterSupplyTemprVal;               //냉수공급온도값
    private Float chilledwaterReturnTemprVal;               //냉수반환온도값
    private Float chilledwaterGapTemprVal;                  //냉수온도차
    private Float cowSupplyTemprVal;                        //냉각수공급온도값
    private Float cowReturnTemprVal;                        //냉각수반환온도값
    private Float cowGapTemprVal;                           //냉각수온도차
    private Float chrFlowrateVal;                           //냉동기유량값
    private Float chrCopVal;                                //냉동기CoP값
}
