package com.adtcaps.tsop.dashboard.api.fm.domain;

import java.util.List;

import lombok.Getter;
import lombok.Setter;

/**
 * 
 * <ul>
 * <li>업무 그룹명 : tsop-backend-api</li>
 * <li>서브 업무명 : com.adtcaps.tsop.dashboard.api.fm.domain</li>
 * <li>설  명 : BuildingInTemprCellResultDto.java</li>
 * <li>작성일 : 2021. 10. 29.</li>
 * <li>작성자 : jeonyb4</li>
 * </ul>
 */
@Getter
@Setter
public class BuildingInTemprCellResultDto {
	private String bldId;
	private String bldName;
	private Double mgmtBaseTempr;
	private String excessReferenceVal;
	private List<InTemprFloorCellResultDto> locFloorObjectList;
	
}
