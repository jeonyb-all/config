package com.adtcaps.tsop.dashboard.api.hvac.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;

import com.adtcaps.tsop.dashboard.api.hvac.domain.FloorAmbientAirAnalysisVO;
import com.adtcaps.tsop.dashboard.api.hvac.domain.InEnthalpyStandardVO;
import com.adtcaps.tsop.dashboard.api.hvac.domain.OutAirCoolFloorAmbientAirVO;
import com.adtcaps.tsop.dashboard.api.hvac.domain.OutEnthalpyInfoVO;

@Mapper
public interface OutAirCoolMapper {
	  
	
	/**
	 * 외기 냉방 운영 현황조회
	 * @param bldId
	 * @param floor
	 * @return
	 */
	//실내엔탈피 기준
	public InEnthalpyStandardVO getInEnthalpyStandardInfo(String bldId,String floor);
	
	//외기 냉방 층별현황 목록
	public List<OutAirCoolFloorAmbientAirVO> getBuildingOutAirCoolFloorAmbientAir(String bldId,String floor);
  
	
	/**
	 * 외기 냉방 운영 현황 분석 조회
	 * @param bldId
	 * @return
	 */
	//실외엔탈피
	public OutEnthalpyInfoVO getOutEnthalpyInfo(String bldId );
	
	
	//외기 냉방 층별현황 분석목록
	public List<FloorAmbientAirAnalysisVO> getFloorAmientAirAnalysisList(String bldId);
  
	 
	//실내엔탈피 값
	public InEnthalpyStandardVO getInEnthalpyInfo(String bldId,String floor);
	
}
