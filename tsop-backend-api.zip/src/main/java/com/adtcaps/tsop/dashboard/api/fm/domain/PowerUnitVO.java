package com.adtcaps.tsop.dashboard.api.fm.domain;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@NoArgsConstructor
@Getter
@Setter
@ToString
public class PowerUnitVO {
	private String maxBld;
	private String maxBldName;
	private String maxBldAbbrName;
	private float maxVal;
	private String minBld;
	private String minBldName;
	private String minBldAbbrName;
	private float minVal;
	private float avgVal;
	private String bldTypeCd;
	private String bldTypeCdName;
	
	
	
}
