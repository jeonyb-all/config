package com.adtcaps.tsop.dashboard.api.fm.domain;

import java.util.ArrayList;
import java.util.List;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class BuildingSummaryVO {
	private String bldId;
	private String name;			//건물명
	private Float equipDeviation;	//가동시간 편차
	private Float equipUpTime;		//가동시간
	private Float energyDeviation;	//에너지사용량 편차
	private Float electricalEnergy;	//전력량

	private List<BuildingEquipWorkTimeVO> equipment = new ArrayList<BuildingEquipWorkTimeVO>();             //빌딩 설비별 사용시간 목록 
}
