package com.adtcaps.tsop.dashboard.api.esop.service.impl;

import java.net.ConnectException;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.apache.commons.lang3.StringUtils;
import org.apache.http.conn.ConnectTimeoutException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.adtcaps.tsop.config.InterfaceConfig;
import com.adtcaps.tsop.dashboard.api.esop.domain.EsopAlarmContentDto;
import com.adtcaps.tsop.dashboard.api.esop.domain.EsopAlarmDto;
import com.adtcaps.tsop.dashboard.api.esop.domain.EsopContactNetworkMemberDto;
import com.adtcaps.tsop.dashboard.api.esop.domain.EsopProcessResultDto;
import com.adtcaps.tsop.dashboard.api.esop.service.FireEsopService;
import com.adtcaps.tsop.domain.common.OcoKakaoAlimTalkDto;
import com.adtcaps.tsop.domain.esop.EsopMemoDto;
import com.adtcaps.tsop.domain.esop.EsopProcessDto;
import com.adtcaps.tsop.domain.esop.EsopScenarioDto;
import com.adtcaps.tsop.domain.esop.FireProcessResultDto;
import com.adtcaps.tsop.domain.esop.ProcessResultDetailDto;
import com.adtcaps.tsop.domain.esop.ProcessResultDto;
import com.adtcaps.tsop.domain.esop.ResponseTeamDto;
import com.adtcaps.tsop.domain.esop.WeakAreaDto;
import com.adtcaps.tsop.domain.inventory.OivBuildingDto;
import com.adtcaps.tsop.mapper.common.OcoKakaoAlimTalkMapper;
import com.adtcaps.tsop.mapper.esop.FireEsopMapper;
import com.adtcaps.tsop.mapper.esop.ResponseTeamMapper;
import com.adtcaps.tsop.mapper.esop.ScenarioMapper;
import com.adtcaps.tsop.mapper.inventory.OivBuildingMapper;
import com.adtcaps.tsop.portal.api.building.domain.BuildingDetailResultDto;
import com.google.gson.Gson;
import com.squareup.okhttp.MediaType;
import com.squareup.okhttp.OkHttpClient;
import com.squareup.okhttp.Request;
import com.squareup.okhttp.RequestBody;

import io.netty.handler.timeout.ReadTimeoutException;

@Transactional
@Service
public class FireEsopServiceImpl implements FireEsopService {
	@Autowired FireEsopMapper fireEsopMapper;
	@Autowired ScenarioMapper scenarioMapper;
	@Autowired OcoKakaoAlimTalkMapper ocoKakaoAlimTalkMapper;
	@Autowired OivBuildingMapper oivBuildingMapper;
	@Autowired ResponseTeamMapper responseTeamMapper;
	@Autowired private InterfaceConfig interfaceConfig;

	@Override
	public List<FireProcessResultDto> listOpenEsopResult(String bldId) throws Exception {
		return fireEsopMapper.listOpenEsopResult(bldId);
	}

	@Override
	public List<EsopScenarioDto> listEsopScenarioStep(String bldId) throws Exception {
		return fireEsopMapper.listEsopScenarioStep(bldId);
	}

	@Override
	public List<EsopProcessResultDto> listEsopProcess(String bldId) throws Exception {
		return fireEsopMapper.listEsopProcessStep(bldId);
	}

	@Override
	public List<EsopMemoDto> listEsopMemo(String bldId) throws Exception {
		return fireEsopMapper.listEsopMemo(bldId);
	}

	@Override
	public List<WeakAreaDto> listWeakArea(WeakAreaDto weakAreaDto) throws Exception {
		return fireEsopMapper.listWeakArea(weakAreaDto);
	}

	@Override
	public List<WeakAreaDto> listWeakAreaAll(WeakAreaDto weakAreaDto) throws Exception {
		return fireEsopMapper.listWeakAreaAll(weakAreaDto);
	}

	@Override
	public int createEsopProcessResult(ProcessResultDto processResultDto) throws Exception {
		int insertRow = 0;
		try {
			insertRow = fireEsopMapper.createEsopProcessResult(processResultDto);
		} catch (Exception e) {
			throw e;
		}
		return insertRow;
	}

	@Override
	public int createEsopProcessResultDetail(ProcessResultDetailDto processResultDetailDto) throws Exception {
		int insertRow = 0;
		try {
			ProcessResultDto reqProcessResultDto = new ProcessResultDto();
			reqProcessResultDto.setBldId(processResultDetailDto.getBldId());
			reqProcessResultDto.setFireResultId(processResultDetailDto.getFireResultId());
			reqProcessResultDto.setAuditId(processResultDetailDto.getAuditId());
			reqProcessResultDto.setAuditName(processResultDetailDto.getAuditName());
			ProcessResultDto resProcessResultDto = fireEsopMapper.readEsopProcessResult(reqProcessResultDto);
			if (resProcessResultDto == null) {
				return 0;
			} else {
				if (resProcessResultDto.getProcessEndDate() != null) {
					return 0;
				} else {
					if (!StringUtils.defaultString(resProcessResultDto.getFireGradeCd()).equals(StringUtils.defaultString(processResultDetailDto.getFireGradeCd()))) {
						reqProcessResultDto.setFireGradeCd(processResultDetailDto.getFireGradeCd());
						//fireEsopMapper.updateEsopProcessResult(reqProcessResultDto);
					}

					insertRow = fireEsopMapper.createEsopProcessResultDetail(processResultDetailDto);

					if ("end".equals(StringUtils.defaultString(processResultDetailDto.getProcessEndDate()))) {
						reqProcessResultDto.setProcessEndDate(processResultDetailDto.getProcessEndDate());
						//fireEsopMapper.updateEsopProcessResult(reqProcessResultDto);
					}

					fireEsopMapper.updateEsopProcessResult(reqProcessResultDto);
				}
			}
		} catch (Exception e) {
			throw e;
		}
		return insertRow;
	}

	@Override
	public List<ProcessResultDetailDto> listEsopProcessResultDetail(ProcessResultDetailDto processResultDetailDto) throws Exception {
		return fireEsopMapper.listEsopProcessResultDetail(processResultDetailDto);
	}

	@Override
	public int updateEsopProcessResult(ProcessResultDto processResultDto) throws Exception {
		int updateRow = 0;
		try {
			updateRow = fireEsopMapper.updateEsopProcessResult(processResultDto);
		} catch (Exception e) {
			throw e;
		}
		return updateRow;
	}

	@Override
	public List<EsopContactNetworkMemberDto> listContactNetworkMember(EsopContactNetworkMemberDto esopContactNetworkMemberDto) throws Exception {
		return fireEsopMapper.listContactNetworkMember(esopContactNetworkMemberDto);
	}

	@Override
	public OcoKakaoAlimTalkDto readTraningEsopAlimTalkMessage(String processId, String bldId, OcoKakaoAlimTalkDto reqOcoKakaoAlimTalkDto) throws Exception {
		OcoKakaoAlimTalkDto ocoKakaoAlimTalkDto = ocoKakaoAlimTalkMapper.readKakaoAlimTalk(reqOcoKakaoAlimTalkDto);

		OivBuildingDto oivBuildingDto = new OivBuildingDto();
		oivBuildingDto.setBldId(bldId);
		BuildingDetailResultDto buildingDetailResultDto = oivBuildingMapper.readOivBuilding(oivBuildingDto);

		EsopProcessResultDto esopProcessResultDto = new EsopProcessResultDto();
		esopProcessResultDto.setBldId(bldId);
		esopProcessResultDto.setProcessId(processId);
		EsopScenarioDto esopScenarioDto = fireEsopMapper.readProcessScenario(esopProcessResultDto);

		String esopMessage = ocoKakaoAlimTalkDto.getMessage();
		esopMessage = esopMessage.replaceAll("#\\{\"T타워\"\\}", buildingDetailResultDto.getBldName());

		LocalDate nowDay = LocalDate.now();
		int month = nowDay.getMonthValue();
		int dayOfMonth = nowDay.getDayOfMonth();

		LocalTime now = LocalTime.now();
		int nowHour = now.getHour();
		int nowMinute = now.getMinute();

		String processStartDate = Integer.toString(month) + "월 " + Integer.toString(dayOfMonth) + "일 " + Integer.toString(nowHour) + ":" + Integer.toString(nowMinute);
		//esopMessage = esopMessage.replaceAll("#\\{\"발생\"\\}", "발생");
		//esopMessage = esopMessage.replaceAll("#\\{\"발생\"\\}", "<span id=\"spStatus\"></span>");
		esopMessage = esopMessage.replaceAll("#\\{\"발생1\"\\}", "#\\\\{\\\"발생1\\\"\\\\}");
		esopMessage = esopMessage.replaceAll("#\\{\"발생2\"\\}", "#\\\\{\\\"발생2\\\"\\\\}");
		esopMessage = esopMessage.replaceAll("#\\{\"11월 1일 13:18\"\\}", processStartDate);
		//esopMessage = esopMessage.replaceAll("#\\{\"\\(B등급\\)\"\\}", "<span id=\\\"spFireGrade\\\"></span>");
		esopMessage = esopMessage.replaceAll("#\\{\"\\(B등급\\)\"\\}", "#\\\\{\\\"fireGrade\\\"\\\\}");
		esopMessage = esopMessage.replaceAll("#\\{\"1단계\"\\}", esopScenarioDto.getStepName());

		/*if (reqOcoKakaoAlimTalkDto.getContactNetworkName() != null) {
			esopMessage = esopMessage.replaceAll("#\\{\"화재반 상황실 소집\"\\}", reqOcoKakaoAlimTalkDto.getContactNetworkName() + " 상황실 소집");
		} else {
			esopMessage = esopMessage.replaceAll("#\\{\"화재반 상황실 소집\"\\}", "상황실 소집");
		}*/
		//esopMessage = esopMessage.replaceAll("#\\{\"화재반 상황실 소집\"\\}", "<span id=\"spEtc\"></span>");
		esopMessage = esopMessage.replaceAll("#\\{\"화재반 상황실 소집\"\\}", "#\\\\{\\\"etc\\\"\\\\}");

		esopMessage = esopMessage.replaceAll("#\\{\"16층\"\\}", "#\\\\{\\\"화재위치\\\"\\\\}");
		ocoKakaoAlimTalkDto.setMessage(esopMessage);

		return ocoKakaoAlimTalkDto;
	}

	@Override
	public OcoKakaoAlimTalkDto readEsopAlimTalkMessage(String fireResultId, String bldId, OcoKakaoAlimTalkDto reqOcoKakaoAlimTalkDto) throws Exception {
		ProcessResultDto reqProcessResultDto = new ProcessResultDto();
		reqProcessResultDto.setBldId(bldId);
		reqProcessResultDto.setFireResultId(fireResultId);
		ProcessResultDto processResultDto = fireEsopMapper.readEsopProcessResult(reqProcessResultDto);

		OcoKakaoAlimTalkDto ocoKakaoAlimTalkDto = ocoKakaoAlimTalkMapper.readKakaoAlimTalk(reqOcoKakaoAlimTalkDto);

		OivBuildingDto oivBuildingDto = new OivBuildingDto();
		oivBuildingDto.setBldId(bldId);
		BuildingDetailResultDto buildingDetailResultDto = oivBuildingMapper.readOivBuilding(oivBuildingDto);

		EsopScenarioDto reqEsopScenarioDto = new EsopScenarioDto();
		reqEsopScenarioDto.setBldId(bldId);
		reqEsopScenarioDto.setFireResultId(fireResultId);
		EsopScenarioDto resEsopScenarioDto = fireEsopMapper.readEsopScenario(reqEsopScenarioDto);

		String esopMessage = ocoKakaoAlimTalkDto.getMessage();
		esopMessage = esopMessage.replaceAll("#\\{\"T타워\"\\}", buildingDetailResultDto.getBldName());

		esopMessage = esopMessage.replaceAll("#\\{\"발생1\"\\}", "#\\\\{\\\"발생1\\\"\\\\}");
		esopMessage = esopMessage.replaceAll("#\\{\"발생2\"\\}", "#\\\\{\\\"발생2\\\"\\\\}");
		if (processResultDto.getProcessEndDate() == null) {
			//esopMessage = esopMessage.replaceAll("#\\{\"발생\"\\}", "발생");
			//esopMessage = esopMessage.replaceAll("#\\{\"발생\"\\}", "#\\\\{\\\"발생\\\"\\\\}");
			esopMessage = esopMessage.replaceAll("#\\{\"11월 1일 13:18\"\\}", processResultDto.getHProcessStartDate());
		} else {
			//esopMessage = esopMessage.replaceAll("#\\{\"발생\"\\}", "종료");
			//esopMessage = esopMessage.replaceAll("#\\{\"발생\"\\}", "#\\\\{\\\"발생\\\"\\\\}");
			esopMessage = esopMessage.replaceAll("#\\{\"11월 1일 13:18\"\\}", processResultDto.getHProcessEndDate());
		}

		/*if (processResultDto.getFireGradeCd() == null) {
			esopMessage = esopMessage.replaceAll("#\\{\"\\(B등급\\)\"\\}", "");
		} else {
			esopMessage = esopMessage.replaceAll("#\\{\"\\(B등급\\)\"\\}", processResultDto.getFireGradeCd()+"등급");
		}*/
		esopMessage = esopMessage.replaceAll("#\\{\"\\(B등급\\)\"\\}", "#\\\\{\\\"fireGrade\\\"\\\\}");

		esopMessage = esopMessage.replaceAll("#\\{\"1단계\"\\}", resEsopScenarioDto.getStepName());

		/*if (reqOcoKakaoAlimTalkDto.getContactNetworkName() != null) {
			esopMessage = esopMessage.replaceAll("#\\{\"화재반 상황실 소집\"\\}", reqOcoKakaoAlimTalkDto.getContactNetworkName() + " 상황실 소집");
		} else {
			esopMessage = esopMessage.replaceAll("#\\{\"화재반 상황실 소집\"\\}", "상황실 소집");
		}*/
		esopMessage = esopMessage.replaceAll("#\\{\"화재반 상황실 소집\"\\}", "#\\\\{\\\"etc\\\"\\\\}");

		esopMessage = esopMessage.replaceAll("#\\{\"16층\"\\}", "#\\\\{\\\"화재위치\\\"\\\\}");
		ocoKakaoAlimTalkDto.setMessage(esopMessage);

		return ocoKakaoAlimTalkDto;
	}

	@Override
	public int setFireAlarmManual(ProcessResultDto processResultDto) throws Exception {
		int insertRow = 0;
		try {
			List<FireProcessResultDto> fireProcessResultDtoList = fireEsopMapper.listOpenEsopResult(processResultDto.getBldId());
			if (fireProcessResultDtoList.size() > 0) {
				insertRow = 999;
			} else {
				insertRow = fireEsopMapper.createEsopProcessResult(processResultDto);
				EsopProcessDto reqEsopProcessDto = new EsopProcessDto();
				reqEsopProcessDto.setProcessId("1001");
				reqEsopProcessDto.setBldId(processResultDto.getBldId());
				reqEsopProcessDto.setStepId("S001");
				EsopProcessDto esopProcessDto = scenarioMapper.readProcessStep(reqEsopProcessDto);
				ProcessResultDetailDto processResultDetailDto = new ProcessResultDetailDto();
				processResultDetailDto.setBldId(processResultDto.getBldId());
				processResultDetailDto.setFireResultId(processResultDto.getFireResultId());
				processResultDetailDto.setProcessId(esopProcessDto.getProcessId());
				processResultDetailDto.setStepId(esopProcessDto.getStepId());
				processResultDetailDto.setFireGradeCd(processResultDto.getFireGradeCd());
				processResultDetailDto.setAuditId(processResultDto.getAuditId());
				processResultDetailDto.setAuditName(processResultDto.getAuditName());
				fireEsopMapper.createEsopProcessResultDetail(processResultDetailDto);

				EsopAlarmDto esopAlarmDto = new EsopAlarmDto();
				EsopAlarmContentDto contentDto = new EsopAlarmContentDto();
				contentDto.setBldId(processResultDto.getBldId());
				contentDto.setEsoYn("Y");
				contentDto.setFireResultId(processResultDto.getFireResultId());
				esopAlarmDto.setAlarmStatus("esop");
				esopAlarmDto.setContent(contentDto);
				Gson gson = new Gson();
				String requestJsonString = gson.toJson(esopAlarmDto);
				String pushUrl = interfaceConfig.getPushServerInfo().getUrl();
				StringBuilder urlBuilder = new StringBuilder();
				urlBuilder.append(pushUrl);
				urlBuilder.append("/api/server/push/alarms/esop");

				OkHttpClient client = new OkHttpClient();
				client.setConnectTimeout(30, TimeUnit.SECONDS);
				Request request = new Request.Builder()
						.url(urlBuilder.toString())
	    	            .post(RequestBody.create(MediaType.parse(org.springframework.http.MediaType.APPLICATION_JSON.toString()), requestJsonString))
	    	            .build();

				try {
	    	    	client.newCall(request).execute();
				} catch (ConnectException e) {
					throw e;
	    	    } catch (ConnectTimeoutException e) {
	    	    	throw e;
	    	    } catch (ReadTimeoutException e) {
	    	    	throw e;
	    	    }
			}
		} catch (Exception e) {
			throw e;
		}
		return insertRow;
	}

	@Override
	public int setFireAlarmAuto(String processId, ProcessResultDto processResultDto) throws Exception {
		int insertRow = 0;
		try {
			List<FireProcessResultDto> fireProcessResultDtoList = fireEsopMapper.listOpenEsopResult(processResultDto.getBldId());
			if (fireProcessResultDtoList.size() > 0) {
				insertRow = 999;
			} else {
				insertRow = fireEsopMapper.createEsopProcessResult(processResultDto);
				EsopProcessDto reqEsopProcessDto = new EsopProcessDto();
				reqEsopProcessDto.setProcessId("1001");
				reqEsopProcessDto.setBldId(processResultDto.getBldId());
				reqEsopProcessDto.setStepId("S001");
				EsopProcessDto esopProcessDto = scenarioMapper.readProcessStep(reqEsopProcessDto);
				ProcessResultDetailDto processResultDetailDto = new ProcessResultDetailDto();
				processResultDetailDto.setBldId(processResultDto.getBldId());
				processResultDetailDto.setFireResultId(processResultDto.getFireResultId());
				processResultDetailDto.setProcessId(esopProcessDto.getProcessId());
				processResultDetailDto.setStepId(esopProcessDto.getStepId());
				processResultDetailDto.setFireGradeCd(processResultDto.getFireGradeCd());
				processResultDetailDto.setAuditId(processResultDto.getAuditId());
				processResultDetailDto.setAuditName(processResultDetailDto.getAuditName());
				fireEsopMapper.createEsopProcessResultDetail(processResultDetailDto);

				processId = StringUtils.defaultString(processId);
				if (!"".equals(processId)) {
					processResultDetailDto = new ProcessResultDetailDto();
					processResultDetailDto.setBldId(processResultDto.getBldId());
					processResultDetailDto.setFireResultId(processResultDto.getFireResultId());
					processResultDetailDto.setProcessId(processId);
					processResultDetailDto.setStepId(esopProcessDto.getStepId());
					processResultDetailDto.setFireGradeCd(processResultDto.getFireGradeCd());
					fireEsopMapper.createEsopProcessResultDetail(processResultDetailDto);
				}
			}
		} catch (Exception e) {
			throw e;
		}
		return insertRow;
	}

	@Override
	public List<ProcessResultDetailDto> listProcessResultDetail(ProcessResultDetailDto processResultDetailDto) throws Exception {
		return fireEsopMapper.listProcessResultDetail(processResultDetailDto);
	}

	@Override
	public ProcessResultDto readEsopProcessResult(ProcessResultDto processResultDto) throws Exception {
		return fireEsopMapper.readEsopProcessResult(processResultDto);
	}

	@Override
	public EsopScenarioDto readEsopScenario(EsopScenarioDto esopScenarioDto) throws Exception {
		EsopScenarioDto resEsopScenarioDto = fireEsopMapper.readEsopScenario(esopScenarioDto);
		if (resEsopScenarioDto == null) {
			esopScenarioDto.setStepId("S001");
			resEsopScenarioDto = scenarioMapper.readEsopScenario(esopScenarioDto);
		}
		return resEsopScenarioDto;
	}

	@Override
	public List<ResponseTeamDto> listResponseTeamAll(String bldId) throws Exception {
		return responseTeamMapper.listResponseTeamAll(bldId);
	}
}
