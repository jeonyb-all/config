package com.adtcaps.tsop.dashboard.api.hvac.domain;

import java.util.List;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@ApiModel(value = "층별권장환기량 조회 Controller 에서의 결과값", description = "층별권장환기량 수치를 조회한다.")

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class RecmdVentiResultVO {
    @ApiModelProperty(position = 2 ,required = false, value="층별권장환기량 기본정보", example = " ")
    private RecmdVentiBaseInfoVO recmdVentiBaseInfo;     //층별권장환기량 기본정보

	@ApiModelProperty(position = 1 ,required = false, value="층별권장환기량 목록", example = " ")
    private List<FloorRecmdVentiRateVO> floorRecmdVentiRateList;     //층별권장환기량 목록

	
 	
	
 
}
