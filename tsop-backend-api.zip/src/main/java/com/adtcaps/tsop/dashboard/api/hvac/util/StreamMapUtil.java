package com.adtcaps.tsop.dashboard.api.hvac.util;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.function.Function;
import java.util.function.Predicate;
import java.util.stream.Collectors;

import com.adtcaps.tsop.portal.api.hvac.domain.EnergyDateInfoVO;
 

public final class StreamMapUtil {
    private StreamMapUtil() {}
/*
    public static Float parseFloat(String v) {
        try {
            return Float.parseFloat(v);
        }
        catch (NumberFormatException ex) {
            return null;
        }
    }
*/
    public static <T> Predicate<T> distinctByKey(Function<? super T, ?> keyExtractor) {
        Set<Object> seen = ConcurrentHashMap.newKeySet();
        return t -> seen.add(keyExtractor.apply(t));
    }
    
    public static <T> Predicate<T> distinctByKeys(Function<? super T, ?>... keyExtractors) 
    {
      final Map<List<?>, Boolean> seen = new ConcurrentHashMap<>();
       
      return t -> 
      {
        final List<?> keys = Arrays.stream(keyExtractors)
                    .map(ke -> ke.apply(t))
                    .collect(Collectors.toList());
         
        return seen.putIfAbsent(keys, Boolean.TRUE) == null;
      };
    }
    /**
     * 조건에 시작일자,종료일자 없을경우 채우기
     * 시작일자,종료일자 없으면 현재일자-30~현재일자  ,시작일자 없으면 종료일자보다 -30,  종료일자없으면 시작일자+30
     * @param energyDateInfoVO
     * @return
     */
    public static EnergyDateInfoVO getDefaultSearchDate(EnergyDateInfoVO energyDateInfoVO) {
    	SimpleDateFormat sdTermFormat = new SimpleDateFormat("yyyyMMdd");
     	
		String startDate = energyDateInfoVO.getStartDate();
		String endDate = energyDateInfoVO.getEndDate();
		startDate  = startDate==null||startDate.length()!=8 ?null:startDate;
		endDate  = endDate==null||endDate.length()!=8 ?null:endDate;
		if(startDate ==null &&  endDate == null) {
		    Calendar calTemp = Calendar.getInstance();
		    calTemp.setTime(new Date());
		    //현재일
		    endDate = sdTermFormat.format(calTemp.getTime());
		    
		    calTemp.add(Calendar.DATE, -30);//30일 전
		    startDate = sdTermFormat.format(calTemp.getTime());
		}else if(startDate==null) {
			Date toDt = null;
			try {
	     	    toDt = sdTermFormat.parse(endDate);
			}catch(ParseException e) {
				toDt = new Date();
			}
	        Calendar calTemp = Calendar.getInstance();
			calTemp.setTime(toDt);
		    calTemp.add(Calendar.DATE, -30);//30일 전
		    startDate = sdTermFormat.format(calTemp.getTime());
			    
		}else if(endDate==null) {
			Date fromDt = null;
			try {
				fromDt = sdTermFormat.parse(startDate);
			}catch(ParseException e) {
				fromDt = new Date();
			}
	        Calendar calTemp = Calendar.getInstance();
			calTemp.setTime(fromDt);
		    calTemp.add(Calendar.DATE, 30);//30일 후
		    endDate = sdTermFormat.format(calTemp.getTime());
		}
		energyDateInfoVO.setStartDate(startDate);
		energyDateInfoVO.setEndDate(endDate);
    	return energyDateInfoVO;
    }
}
