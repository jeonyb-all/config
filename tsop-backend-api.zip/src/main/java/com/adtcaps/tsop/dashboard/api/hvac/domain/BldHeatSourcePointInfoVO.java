package com.adtcaps.tsop.dashboard.api.hvac.domain;

import java.util.List;

import javax.validation.constraints.Size;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@ApiModel(value = "열원 상세정보정보", description = "건물의 각각 냉방설비에 대해 권장열원(냉수펌프,냉각수펌프), 사용열원(냉수펌프,냉각수펌프)을 조회하여 화면에 보여준다.")
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class BldHeatSourcePointInfoVO { 

	@ApiModelProperty(position = 1 , required = false, value="건물ID", example = "0000")
	@Size(min = 1, max = 4, message="건물ID는 4자리입니다")
    private String bldId               ;//건물ID

	@ApiModelProperty(position = 3 , required = false, value="포인트코드", example = "2100")
    private String pointCd;     //포인트코드

	@ApiModelProperty(position = 5 , required = false, value="포인트코드", example = "냉수펌프")
    private String pointName;     //포인트명 ex)	권장열원, 냉수펌프  , 냉각수펌프 
 
	
	@ApiModelProperty(position = 6 , required = false, value="포인트소트", example = "3")
    private Integer pointSortSeq   ;//포인트소트
	

	@ApiModelProperty(position = 9 ,required = false, value="포인트 기준의 열", example = "")
    private List<BldHeatSourceInfoVO> heatSourceObjectList;//포인트 기준의 열
	 
}
