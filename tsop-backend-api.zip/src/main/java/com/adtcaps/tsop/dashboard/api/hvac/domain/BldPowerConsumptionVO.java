package com.adtcaps.tsop.dashboard.api.hvac.domain;

import java.util.List;

import javax.validation.constraints.Size;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@ApiModel(value = "빌딩별 전력소비량 정보", description = "빌딩별 전력소비량 정보을 보여준다.")
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class BldPowerConsumptionVO { 
	 
	@ApiModelProperty(position = 1 , required = false, value="건물ID", example = "0000")
	@Size(min = 1, max = 4, message="건물ID는 4자리입니다")
    private String bldId;//건물ID

	 

	@ApiModelProperty(position = 3 , required = false, value="빌딩명", example = "T타워")
	private String bldName;//빌딩명

	@ApiModelProperty(position = 3 , required = false, value="빌딩약어명", example = "T타워")
	private String bldAbbrName;//빌딩약어명

    private String collectDateHourminute;//수집일자시분
    private String maxCollectDateHourminute;//수집일자시분

    private Float pwrAmount;//분당전력소비량
    private Float peakStndPowerVal;//peak 기준값
    
	@ApiModelProperty(position = 5 , required = false, value="전력부하율", example = "89")
	private Float powerLoadRate;//전력부하율
	 
	    
	@ApiModelProperty(position = 5 , required = false, value="기준부하율 90%이상여부", example = "Y")
	private String stndLoadRateOverYn;//기준부하율 90%이상여부
	
  
	@ApiModelProperty(position = 9 , required = false, value="전력소비량", example = "")
	private List<PowerMinuteConsumptionVO>  powerMinuteConsumptionList;//	전력소비량

	
}
