package com.adtcaps.tsop.dashboard.api.robot.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.CollectionUtils;

import com.adtcaps.tsop.dashboard.api.robot.domain.RobotBatteryEventChartResultDto;
import com.adtcaps.tsop.dashboard.api.robot.domain.RobotBatteryEventQueryResultDto;
import com.adtcaps.tsop.dashboard.api.robot.service.RobotService;
import com.adtcaps.tsop.mapper.robot.OrbRobotBatteryEventMapper;

/**
 * 
 * <ul>
 * <li>업무 그룹명 : tsop-backend-api</li>
 * <li>서브 업무명 : com.adtcaps.tsop.dashboard.api.robot.service.impl</li>
 * <li>설  명 : RobotServiceImpl.java</li>
 * <li>작성일 : 2020. 12. 4.</li>
 * <li>작성자 : jeonyb4</li>
 * </ul>
 */
@Transactional
@Service
public class RobotServiceImpl implements RobotService {
	
	@Autowired
	private OrbRobotBatteryEventMapper orbRobotBatteryEventMapper;
	
	/**
	 * 
	 * listRobotBatteryEventChart
	 *
	 * @return RobotBatteryEventChartResultDto
	 * @throws Exception 
	 */
	@Override
	public RobotBatteryEventChartResultDto listRobotBatteryEventChart() throws Exception {
		
		RobotBatteryEventChartResultDto robotBatteryEventChartResultDto = null;
		try {
			// 모든 로봇 건수 조회...
			int robotCount = orbRobotBatteryEventMapper.readCountRobot();
			
			robotBatteryEventChartResultDto = new RobotBatteryEventChartResultDto();
			robotBatteryEventChartResultDto.setRobotCount(robotCount);
			
			// 모든 로봇별 배터리 현황 조회...
			List<RobotBatteryEventQueryResultDto> robotBatteryEventQueryResultDtoList = orbRobotBatteryEventMapper.listRobotBatteryEventChart();
			if (!CollectionUtils.isEmpty(robotBatteryEventQueryResultDtoList)) {
				robotBatteryEventChartResultDto.setRobotBatteryList(robotBatteryEventQueryResultDtoList);
			}
			
		} catch (Exception e) {
			throw e;
		}
		return robotBatteryEventChartResultDto;
	}

}
