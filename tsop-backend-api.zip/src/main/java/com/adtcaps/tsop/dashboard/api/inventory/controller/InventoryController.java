package com.adtcaps.tsop.dashboard.api.inventory.controller;

import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.util.CollectionUtils;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.adtcaps.tsop.authentication.domain.JwtAuthResultDto;
import com.adtcaps.tsop.dashboard.api.inventory.domain.DashboardLocationResultDto;
import com.adtcaps.tsop.dashboard.api.inventory.service.InventoryService;
import com.adtcaps.tsop.domain.inventory.OivBuildingDto;
import com.adtcaps.tsop.helper.constant.Const;
import com.adtcaps.tsop.helper.domain.BasePageDto;
import com.adtcaps.tsop.helper.domain.ResultDto;
import com.adtcaps.tsop.portal.api.building.domain.BuildingGridRequestDto;

/**
 * 
 * <ul>
 * <li>업무 그룹명 : tsop-backend-api</li>
 * <li>서브 업무명 : com.adtcaps.tsop.dashboard.api.inventory.controller</li>
 * <li>설  명 : InventoryController.java</li>
 * <li>작성일 : 2020. 12. 4.</li>
 * <li>작성자 : jeonyb4</li>
 * </ul>
 */
@RestController
@RequestMapping("/api/dashboard/inventories")
public class InventoryController {
	
	private final String ERR_MSG_NULL_BLD_ID = "빌딩ID가 없습니다.";
	
	private final String ERR_MSG_NULL_READ_RESULT = "조회 결과가 없습니다.";
	
	@Autowired
	private InventoryService inventoryService;
	
	/**
	 * 
	 * listBuilding
	 *
	 * @return ResponseEntity
	 */
	@SuppressWarnings("rawtypes")
	@GetMapping(value="/buildings", produces="application/json; charset=UTF-8")
	public ResponseEntity listBuilding(@AuthenticationPrincipal JwtAuthResultDto authResultDto) throws Exception {
		
		ResponseEntity<ResultDto> resEntity = null;
		String returnString = "";
		
		List<String> bldIdList = authResultDto.getBldIdList();
		
		BuildingGridRequestDto reqBuildingGridRequestDto = new BuildingGridRequestDto();
		reqBuildingGridRequestDto.setBldIdList(bldIdList);
		
		// 빌딩 목록 조회...
		List<OivBuildingDto> rsltOivBuildingDtoList = inventoryService.listBuilding(reqBuildingGridRequestDto);
		if (CollectionUtils.isEmpty(rsltOivBuildingDtoList)) {
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_READ_RESULT, rsltOivBuildingDtoList));
        } else {
        	returnString = Const.Common.RESULT_CODE.SUCCESS;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, "", rsltOivBuildingDtoList));
		}
		
		return resEntity;
	}
	
	/**
	 * 
	 * listDashboardLocation
	 * 
	 * @param reqBasePageDto
	 * @return ResponseEntity
	 * @throws Exception 
	 */
	@SuppressWarnings("rawtypes")
	@GetMapping(value="/locations", produces="application/json; charset=UTF-8")
	public ResponseEntity listDashboardLocation(BasePageDto reqBasePageDto) throws Exception {
		
		ResponseEntity<ResultDto> resEntity = null;
		String returnString = "";
		
		String bldId = StringUtils.defaultString(reqBasePageDto.getBldId());
		if ("".equals(bldId)) {
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_BLD_ID));
			return resEntity;
		}
		
		// 콤보박스 제공용 빌딩별 층목록 조회...
		List<DashboardLocationResultDto> dashboardLocationResultDtoList = inventoryService.listDashboardLocation(reqBasePageDto);
		if (CollectionUtils.isEmpty(dashboardLocationResultDtoList)) {
			returnString = Const.Common.RESULT_CODE.SUCCESS;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_READ_RESULT, dashboardLocationResultDtoList));
		} else {
			returnString = Const.Common.RESULT_CODE.SUCCESS;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, "", dashboardLocationResultDtoList));
		}
    	
		return resEntity;
	}

}
