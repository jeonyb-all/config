package com.adtcaps.tsop.dashboard.api.hvac.domain;

import javax.validation.constraints.Size;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@ApiModel(value = "DB에서 가져오는 빌딩 층의 이전 시간에대한 재실자수 ", description = "DB에서 가져오는빌딩/층의 이전 시간에대한 재실자수")
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class FloorPreHourOccupantAllVO { 
	 
	@ApiModelProperty(position = 1 , required = false, value="건물ID", example = "0000")
	@Size(min = 1, max = 4, message="건물ID는 4자리입니다")
    private String bldId;//건물ID

	@ApiModelProperty(position = 3 , required = false, value="층ID", example = "3")
	private Integer locId;//층정보
	@ApiModelProperty(position = 3 , required = false, value="층정보", example = "3F")
	private String locFloor;//	층정보
	
	@ApiModelProperty(position = 5 , required = false, value="통계시간", example = "13")
    private String sumDateHourminute;//  통계시간    현재시간-24~현재시간

	@ApiModelProperty(position = 5 , required = false, value="통계시간", example = "13")
	private String hourTime;//	통계시간	현재시간-24~현재시간

	@ApiModelProperty(position = 7 , required = false, value="재실자수", example = "26")
	private String occupantCnt;// 	현재통계값(재실자수)  통계낸경우는 숫자,0이지만  통계를 안낸경우 -를 줄경우로 대비<- int로 안함

	
	

	public FloorPreHourOccupantVO toFloorPreHourOccupantVO() {
		FloorPreHourOccupantVO floorPreHourOccupantVO = new FloorPreHourOccupantVO();
		
		floorPreHourOccupantVO.setHourTime(this.hourTime);
		floorPreHourOccupantVO.setOccupantCnt(this.occupantCnt); 
		return floorPreHourOccupantVO;
	}

    
}
