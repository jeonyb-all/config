package com.adtcaps.tsop.dashboard.api.mashup.service;

import java.util.List;

import com.adtcaps.tsop.dashboard.api.mashup.domain.AlarmCurrentStateDto;
import com.adtcaps.tsop.dashboard.api.mashup.domain.AlarmGradeAlarmNoCheckResultDto;
import com.adtcaps.tsop.dashboard.api.mashup.domain.AlarmGradeAlarmTotalResultDto;

/**
 * 
 * <ul>
 * <li>업무 그룹명 : tsop-backend-api</li>
 * <li>서브 업무명 : com.adtcaps.tsop.dashboard.api.mashup.service</li>
 * <li>설  명 : MashupService.java</li>
 * <li>작성일 : 2020. 12. 4.</li>
 * <li>작성자 : jeonyb4</li>
 * </ul>
 */
public interface MashupService {
	/**
	 * 
	 * listAlarmGradeAlarmTotalCount
	 *
	 * @param reqAlarmCurrentStateDto
	 * @return AlarmGradeAlarmTotalResultDto
	 * @throws Exception
	 */
	public AlarmGradeAlarmTotalResultDto listAlarmGradeAlarmTotalCount(AlarmCurrentStateDto reqAlarmCurrentStateDto) throws Exception;
	
	/**
	 * 
	 * listAlarmGradeAlarmNoCheck
	 *
	 * @param reqAlarmCurrentStateDto
	 * @return AlarmGradeAlarmNoCheckResultDto
	 * @throws Exception 
	 */
	public AlarmGradeAlarmNoCheckResultDto listAlarmGradeAlarmNoCheck(AlarmCurrentStateDto reqAlarmCurrentStateDto) throws Exception;
	
	/**
	 * 
	 * listAlarmGradeCurrentState
	 *
	 * @param reqAlarmCurrentStateDto
	 * @return List<AlarmCurrentStateDto>
	 * @throws Exception 
	 */
	public List<AlarmCurrentStateDto> listAlarmGradeCurrentState(AlarmCurrentStateDto reqAlarmCurrentStateDto) throws Exception;
	
	/**
	 * 
	 * updateNoCheckAlarmToCheck
	 *
	 * @param reqAlarmCurrentStateDto
	 * @return int
	 * @throws Exception 
	 */
	public int updateNoCheckAlarmToCheck(AlarmCurrentStateDto reqAlarmCurrentStateDto) throws Exception;
	
}
