package com.adtcaps.tsop.dashboard.api.energy.domain;

import java.util.ArrayList;
import java.util.List;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class BuildingPowerVO {
	
	private String bldId;                                                                      //빌딩 아이디                      
	private String bldName;                                                                    //빌딩 명
	private String bldTypeCd;                                                                  //빌딩 타입 코드
	private String bldTypeCdName;                                                              //빌딩 타입 명
	private Integer baseFee;                                                                   //기본요금
	private Integer elecenergyFee;                                                             //전력량요금
	private Integer dcFee;                                                                     //할인요금
	private Integer electricityFee;                                                            //전기요금
	private Integer invoiceFee;                                                                //청구요금
	private Integer wunitElecenergy;                                                           //원단위전력량
	private Integer contractElecenergyVal;                                                     //계약전력량값
	private List<CustomerVO> customerList = new ArrayList<CustomerVO>();                       //고객 정보
	private List<BuildingPowerTrendVO> trendList = new ArrayList<BuildingPowerTrendVO>();      //dayweek트랜드
	
}
