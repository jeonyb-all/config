package com.adtcaps.tsop.dashboard.api.esop.domain;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class EsopAlarmDto {
	private String alarmStatus;
	private EsopAlarmContentDto content;
}
