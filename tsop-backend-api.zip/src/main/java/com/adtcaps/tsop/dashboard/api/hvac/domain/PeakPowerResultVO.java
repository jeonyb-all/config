package com.adtcaps.tsop.dashboard.api.hvac.domain;

import java.util.List;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@ApiModel(value = "사옥별 전력사용 기본정보", description = "사옥별 전력사용 기본정보")

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class PeakPowerResultVO {
    @ApiModelProperty(position = 2 ,required = false, value="사옥별 전력사용 기본값", example = " ")
    private BldPowerBaseInfoVO bldPowerBaseInfo;     //사옥별 전력사용 기본값
    
	@ApiModelProperty(position = 1 ,required = false, value="사옥별 전력사용현황", example = " ")
    private List<BldPowerConsumptionVO> bldPowerConsumptionDataList;     //사옥별 전력사용현황

	
 	
	
 
}
