package com.adtcaps.tsop.dashboard.api.hvac.domain;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@ApiModel(value = "열원 상세정보정보", description = "건물의 각각 냉방설비에 대해 권장열원(냉수펌프,냉각수펌프), 사용열원(냉수펌프,냉각수펌프)을 조회하여 화면에 보여준다.")
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class BldHeatSourceInfoVO { 
 	
	
	@ApiModelProperty(position = 5 , required = false, value="냉동기구분", example = "FM0000005638") 
    private String objectId        ;//오브젝트ID(냉동기구분)
	
	@ApiModelProperty(position = 7 , required = false, value="냉동기명", example = "고층용냉동기2") 
    private String facilityName    ;//장비명(냉동기명)	ex)냉동기1,냉동기2…

	@ApiModelProperty(position = 9 , required = false, value="현재값", example = "ON,OFF,90%,85%") 
	private String currVal        ;//현재값	ex) ON,OFF,90%,85%;//
    private String currStat        ;//현재값    ex) ON,OFF
	    
	
  
}
