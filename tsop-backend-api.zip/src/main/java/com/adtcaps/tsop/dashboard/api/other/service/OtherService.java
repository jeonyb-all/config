package com.adtcaps.tsop.dashboard.api.other.service;

import com.adtcaps.tsop.dashboard.api.other.domain.WeatherForcastResultDto;
import com.adtcaps.tsop.domain.other.OotWeatherForecastExtraShortDto;

/**
 * 
 * <ul>
 * <li>업무 그룹명 : tsop-backend-api</li>
 * <li>서브 업무명 : com.adtcaps.tsop.dashboard.api.other.service</li>
 * <li>설  명 : OtherService.java</li>
 * <li>작성일 : 2020. 12. 4.</li>
 * <li>작성자 : jeonyb4</li>
 * </ul>
 */
public interface OtherService {
	/**
	 * 
	 * readBuildingWeatherForcast
	 *
	 * @param reqOotWeatherForecastExtraShortDto
	 * @return WeatherForcastResultDto
	 * @throws Exception 
	 */
	public WeatherForcastResultDto readBuildingWeatherForcast(OotWeatherForecastExtraShortDto reqOotWeatherForecastExtraShortDto) throws Exception;

}
