package com.adtcaps.tsop.dashboard.api.fm.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import com.adtcaps.tsop.dashboard.api.fm.domain.BuildingEquipDayWeekVO;
import com.adtcaps.tsop.dashboard.api.fm.domain.BuildingEquipHourVO;
import com.adtcaps.tsop.dashboard.api.fm.domain.BuildingEquipWorkTimeVO;
import com.adtcaps.tsop.dashboard.api.fm.domain.BuildingFloorVO;
import com.adtcaps.tsop.dashboard.api.fm.domain.BuildingPointVO;
import com.adtcaps.tsop.dashboard.api.fm.domain.BuildingStatusVO;
import com.adtcaps.tsop.dashboard.api.fm.domain.BuildingSummaryVO;
import com.adtcaps.tsop.dashboard.api.fm.domain.BuildingVO;
import com.adtcaps.tsop.dashboard.api.fm.domain.DayWeekVO;
import com.adtcaps.tsop.dashboard.api.fm.domain.EquipObjVO;
import com.adtcaps.tsop.dashboard.api.fm.domain.EquipObjWeekVO;
import com.adtcaps.tsop.dashboard.api.fm.domain.EquipVO;
import com.adtcaps.tsop.dashboard.api.fm.domain.FloorAmbientAirVO;
import com.adtcaps.tsop.dashboard.api.fm.domain.FmTrendVO;
import com.adtcaps.tsop.dashboard.api.fm.domain.FmVO;
import com.adtcaps.tsop.dashboard.api.fm.domain.ObjStatusVO;
import com.adtcaps.tsop.dashboard.api.fm.domain.ObjectOprTmVO;
import com.adtcaps.tsop.dashboard.api.fm.domain.PowerUnitVO;

@Mapper
public interface FmMapper {

	public List<FmVO> getFmEquipment();

	public List<PowerUnitVO> getPowerUnit();

	public List<FmVO> getRoomEnvironmentBldList(String equipmentCd);

	public List<FmVO> roomEnvironment( @Param("bldId") String bldId,  @Param("bldName") String bldName,  @Param("equipmentCd") String equipmentCd);

	public List<BuildingSummaryVO> getBuildingSummary();
	
	String getLastUpdateTime(String equiptmentCd);

	public List<FmTrendVO> fmBuildingPointStatAvg(@Param("bldId") String bldId);
	
	public List<BuildingFloorVO> getBuildingFoorList(@Param("bldId") String bldId);
	
	public List<BuildingVO> getBuildingInfo();

	public BuildingVO getBuildingInfo(@Param("bldId") String bldId);
	
	public List<BuildingEquipHourVO> getBuildingEquipHour(@Param("bldId") String bldId, @Param("equipment") String equipment);
	
	public List<BuildingPointVO> getBuildingEquipPoint(@Param("bldId") String bldId, @Param("equipment") String equipment);
	
	public List<BuildingEquipHourVO> getBuildingEquipPointHour(@Param("bldId") String bldId, @Param("equipment") String equipment);
	
	public List<BuildingEquipDayWeekVO> getBuildingEquipDayWeek(@Param("bldId") String bldId, @Param("equipment") String equipment);
	
	public List<BuildingSummaryVO> getBuildingWorkingTimeNUsedPower();
	
	public BuildingSummaryVO getBuildingWorkingTimeNUsedPower(@Param("bldId") String bldId);
	
	public List<BuildingEquipWorkTimeVO> getBuildingEquipWorkTime(@Param("bldId") String bldId);
	
	public List<DayWeekVO> getBuildingCHRDayWeek(@Param("bldId") String bldId);
	
	public List<DayWeekVO> getBuildingCLTDayWeek(@Param("bldId") String bldId);
	
	public List<DayWeekVO> getBuildingAHUDayWeek(@Param("bldId") String bldId);
	
	public List<DayWeekVO> getBuildingBLRDayWeek(@Param("bldId") String bldId);
	
	public List<DayWeekVO> getBuildingHEXDayWeek(@Param("bldId") String bldId);	
	
	public List<ObjectOprTmVO> getEquipOperateTm(@Param("bldId") String bldId, @Param("equipment") String equipment);

	public List<EquipVO> getEquipList();
	
	public List<EquipVO> getBldEquipList(@Param("bldId") String bldId);
	
	public List<BuildingStatusVO> getBldTypeEquipStatus();
	
	public List<BuildingStatusVO> getBuildingEquipStatus();
	
	public List<ObjStatusVO> getBuildingAirhandlingSummary(@Param("bldId") String bldId);
	
	public List<BuildingFloorVO> getBuildingFloorEnv(@Param("bldId") String bldId);
	
	public List<EquipObjVO> getBuildingEquipObjList(@Param("bldId") String bldId, @Param("equipment") String equipment);
	
	public List<EquipObjWeekVO> getBuildingEquipObjWeekList(@Param("bldId") String bldId, @Param("equipment") String equipment);
	
	public List<FloorAmbientAirVO> getBuildingEquipAmbientAirFloor(@Param("bldId") String bldId, @Param("floor") String floor);
	
	public List<BuildingEquipDayWeekVO> getBuildingEquipDayWeekStatus();
}
