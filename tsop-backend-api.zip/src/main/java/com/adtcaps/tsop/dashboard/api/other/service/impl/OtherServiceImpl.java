package com.adtcaps.tsop.dashboard.api.other.service.impl;

import java.util.List;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.adtcaps.tsop.dashboard.api.other.domain.AirQualityResultDto;
import com.adtcaps.tsop.dashboard.api.other.domain.EarthquakeNoticeResultDto;
import com.adtcaps.tsop.dashboard.api.other.domain.WeatherForcastResultDto;
import com.adtcaps.tsop.dashboard.api.other.domain.WeatherForecastExtraShortResultDto;
import com.adtcaps.tsop.dashboard.api.other.domain.WeatherForecastVillageResultDto;
import com.adtcaps.tsop.dashboard.api.other.domain.WeatherMinMaxTemprResultDto;
import com.adtcaps.tsop.dashboard.api.other.service.OtherService;
import com.adtcaps.tsop.domain.inventory.OivManagementReferenceBaseDto;
import com.adtcaps.tsop.domain.inventory.OivManagementReferenceDetailDto;
import com.adtcaps.tsop.domain.other.OotAirQualityDto;
import com.adtcaps.tsop.domain.other.OotWeatherForecastExtraShortDto;
import com.adtcaps.tsop.domain.other.OotWeatherForecastVillageDto;
import com.adtcaps.tsop.helper.constant.Const;
import com.adtcaps.tsop.helper.service.HelperService;
import com.adtcaps.tsop.helper.util.CommonObjectUtil;
import com.adtcaps.tsop.mapper.inventory.OivManagementReferenceBaseMapper;
import com.adtcaps.tsop.mapper.inventory.OivManagementReferenceDetailMapper;
import com.adtcaps.tsop.mapper.other.OotAirQualityMapper;
import com.adtcaps.tsop.mapper.other.OotEarthquakeNoticeMapper;
import com.adtcaps.tsop.mapper.other.OotWeatherForecastExtraShortMapper;
import com.adtcaps.tsop.mapper.other.OotWeatherForecastVillageMapper;
import com.adtcaps.tsop.portal.api.alert.domain.AlertIndicatorDetailDto;

/**
 * 
 * <ul>
 * <li>업무 그룹명 : tsop-backend-api</li>
 * <li>서브 업무명 : com.adtcaps.tsop.dashboard.api.other.service.impl</li>
 * <li>설  명 : OtherServiceImpl.java</li>
 * <li>작성일 : 2020. 12. 4.</li>
 * <li>작성자 : jeonyb4</li>
 * </ul>
 */
@Service
public class OtherServiceImpl implements OtherService {
	
	@Autowired
	private OotWeatherForecastExtraShortMapper ootWeatherForecastExtraShortMapper;
	
	@Autowired
	private OotEarthquakeNoticeMapper ootEarthquakeNoticeMapper;
	
	@Autowired
	private OotAirQualityMapper ootAirQualityMapper;
	
	@Autowired
	private OotWeatherForecastVillageMapper ootWeatherForecastVillageMapper;
	
	@Autowired
	private OivManagementReferenceBaseMapper oivManagementReferenceBaseMapper;
	
	@Autowired
	private OivManagementReferenceDetailMapper oivManagementReferenceDetailMapper;
	
	@Autowired
	private HelperService helperService;
	
	/**
	 * 
	 * readBuildingWeatherForcast
	 *
	 * @param reqOotWeatherForecastExtraShortDto
	 * @return WeatherForcastResultDto
	 * @throws Exception 
	 */
	@Override
	public WeatherForcastResultDto readBuildingWeatherForcast(OotWeatherForecastExtraShortDto reqOotWeatherForecastExtraShortDto) throws Exception {
		
		WeatherForcastResultDto weatherForcastResultDto = null;
		try {
			// 현재일시의 올림시간 조회...
			String currentDatetimeRoundupHour = helperService.readCurrentDatetimeRoundupHour();
			String roundupHourMinute = StringUtils.substring(currentDatetimeRoundupHour, 0, 12);
			
			String bldId = reqOotWeatherForecastExtraShortDto.getBldId();
			
			// 빌딩별 현재 날씨정보 조회...
			reqOotWeatherForecastExtraShortDto.setPredDateHourminute(roundupHourMinute);
			WeatherForecastExtraShortResultDto weatherForecastExtraShortResultDto = ootWeatherForecastExtraShortMapper.readBuildingWeatherForecastExtraShort(reqOotWeatherForecastExtraShortDto);
			
			// 지진정보 조회...
			EarthquakeNoticeResultDto earthquakeNoticeResultDto = ootEarthquakeNoticeMapper.readEarthquakeNotice();
			
			// 빌딩별 미세먼지정보 조회...
			OotAirQualityDto reqOotAirQualityDto = new OotAirQualityDto();
			reqOotAirQualityDto.setBldId(bldId);
			AirQualityResultDto airQualityResultDto = ootAirQualityMapper.readBuildingAirQuality(reqOotAirQualityDto);
			if (airQualityResultDto != null) {
				double finedustPm10Concent = CommonObjectUtil.defaultNumber(airQualityResultDto.getFinedustPm10Concent());
				if (finedustPm10Concent > 0) {
					// 미세먼지에 대한 최대값 조회..
					OivManagementReferenceBaseDto reqOivManagementReferenceBaseDto = new OivManagementReferenceBaseDto();
					reqOivManagementReferenceBaseDto.setBldId(bldId);
					reqOivManagementReferenceBaseDto.setManagementCategoryCd(Const.Code.MANAGEMENT_CATEGORY_CD.FINE_DUST);
					OivManagementReferenceBaseDto rsltOivManagementReferenceBaseDto = oivManagementReferenceBaseMapper.readManagementReferenceBase(reqOivManagementReferenceBaseDto);
					if (rsltOivManagementReferenceBaseDto == null) {
						String maxReferenceVal = "200";
						airQualityResultDto.setFinedustMaxReferenceVal(maxReferenceVal);
						// 정보표준값으로 세팅...
						if (finedustPm10Concent >= Integer.parseInt(Const.Definition.GOVERNMENT_STANDARD_INDICATOR.FINE_DUST_TOO_BAD_FROM)) {
							airQualityResultDto.setFinedustDetailCd(Const.Code.MANAGEMENT_DETAIL_CD.FINE_DUST_TOO_BAD);
							airQualityResultDto.setFinedustDetailName(Const.Definition.MANAGEMENT_DETAIL_NAME.TOO_BAD);
						} else {
							if (finedustPm10Concent >= Integer.parseInt(Const.Definition.GOVERNMENT_STANDARD_INDICATOR.FINE_DUST_GOOD_FROM) && 
									finedustPm10Concent <= Integer.parseInt(Const.Definition.GOVERNMENT_STANDARD_INDICATOR.FINE_DUST_GOOD_TO)) {
								airQualityResultDto.setFinedustDetailCd(Const.Code.MANAGEMENT_DETAIL_CD.FINE_DUST_GOOD);
								airQualityResultDto.setFinedustDetailName(Const.Definition.MANAGEMENT_DETAIL_NAME.GOOD);
							} else if (finedustPm10Concent >= Integer.parseInt(Const.Definition.GOVERNMENT_STANDARD_INDICATOR.FINE_DUST_GENERAL_FROM) && 
									finedustPm10Concent <= Integer.parseInt(Const.Definition.GOVERNMENT_STANDARD_INDICATOR.FINE_DUST_GENERAL_TO)) {
								airQualityResultDto.setFinedustDetailCd(Const.Code.MANAGEMENT_DETAIL_CD.FINE_DUST_GENERAL);
								airQualityResultDto.setFinedustDetailName(Const.Definition.MANAGEMENT_DETAIL_NAME.GENERAL);
							} else if (finedustPm10Concent >= Integer.parseInt(Const.Definition.GOVERNMENT_STANDARD_INDICATOR.FINE_DUST_BAD_FROM) && 
									finedustPm10Concent <= Integer.parseInt(Const.Definition.GOVERNMENT_STANDARD_INDICATOR.FINE_DUST_BAD_TO)) {
								airQualityResultDto.setFinedustDetailCd(Const.Code.MANAGEMENT_DETAIL_CD.FINE_DUST_BAD);
								airQualityResultDto.setFinedustDetailName(Const.Definition.MANAGEMENT_DETAIL_NAME.BAD);
							}
						}
						
					} else {
						String maxReferenceVal = StringUtils.defaultString(rsltOivManagementReferenceBaseDto.getMaxReferenceVal());
						airQualityResultDto.setFinedustMaxReferenceVal(maxReferenceVal);
						// 미세먼지에 대한 경보지표 상세조회..
						OivManagementReferenceDetailDto reqOivManagementReferenceDetailDto = new OivManagementReferenceDetailDto();
						reqOivManagementReferenceDetailDto.setBldId(bldId);
						reqOivManagementReferenceDetailDto.setManagementCategoryCd(Const.Code.MANAGEMENT_CATEGORY_CD.FINE_DUST);
						List<AlertIndicatorDetailDto> rsltAlertIndicatorDetailDtoList = oivManagementReferenceDetailMapper.listManagementReferenceDetail(reqOivManagementReferenceDetailDto);
						if (!CollectionUtils.isEmpty(rsltAlertIndicatorDetailDtoList)) {
							for (AlertIndicatorDetailDto rsltAlertIndicatorDetailDto : rsltAlertIndicatorDetailDtoList) {
								String managementDetailCd = StringUtils.defaultString(rsltAlertIndicatorDetailDto.getManagementDetailCd());
								String managementDetailName = StringUtils.defaultString(rsltAlertIndicatorDetailDto.getManagementDetailName());
								String referenceValFirst = StringUtils.defaultString(rsltAlertIndicatorDetailDto.getReferenceValFirst(), "0");
								String referenceValSecond = StringUtils.defaultString(rsltAlertIndicatorDetailDto.getReferenceValSecond(), "0");
								int firstValue = Integer.parseInt(referenceValFirst);
								int secondValue = Integer.parseInt(referenceValSecond);
								if (Const.Code.MANAGEMENT_DETAIL_CD.FINE_DUST_TOO_BAD.equals(managementDetailCd)) {
									if (finedustPm10Concent >= firstValue) {
										airQualityResultDto.setFinedustDetailCd(managementDetailCd);
										airQualityResultDto.setFinedustDetailName(managementDetailName);
										break;
									}
								} else {
									if (finedustPm10Concent >= firstValue && finedustPm10Concent <= secondValue) {
										airQualityResultDto.setFinedustDetailCd(managementDetailCd);
										airQualityResultDto.setFinedustDetailName(managementDetailName);
										break;
									}
								}
							}
						}
					}
				}
				
				double finedustPm2p5Concent = CommonObjectUtil.defaultNumber(airQualityResultDto.getFinedustPm2p5Concent());
				if (finedustPm2p5Concent > 0) {
					// 초미세먼지에 대한 최대값 조회..
					OivManagementReferenceBaseDto reqOivManagementReferenceBaseDto = new OivManagementReferenceBaseDto();
					reqOivManagementReferenceBaseDto.setBldId(bldId);
					reqOivManagementReferenceBaseDto.setManagementCategoryCd(Const.Code.MANAGEMENT_CATEGORY_CD.ULTRA_FINE_DUST);
					OivManagementReferenceBaseDto rsltOivManagementReferenceBaseDto = oivManagementReferenceBaseMapper.readManagementReferenceBase(reqOivManagementReferenceBaseDto);
					if (rsltOivManagementReferenceBaseDto == null) {
						String maxReferenceVal = "200";
						airQualityResultDto.setFinedustMaxReferenceVal(maxReferenceVal);
						// 정보표준값으로 세팅...
						if (finedustPm2p5Concent >= Integer.parseInt(Const.Definition.GOVERNMENT_STANDARD_INDICATOR.ULTRA_FINE_DUST_TOO_BAD_FROM)) {
							airQualityResultDto.setUltraFinedustDetailCd(Const.Code.MANAGEMENT_DETAIL_CD.ULTRA_FINE_DUST_TOO_BAD);
							airQualityResultDto.setUltraFinedustDetailName(Const.Definition.MANAGEMENT_DETAIL_NAME.TOO_BAD);
						} else {
							if (finedustPm2p5Concent >= Integer.parseInt(Const.Definition.GOVERNMENT_STANDARD_INDICATOR.ULTRA_FINE_DUST_GOOD_FROM) && 
									finedustPm2p5Concent <= Integer.parseInt(Const.Definition.GOVERNMENT_STANDARD_INDICATOR.ULTRA_FINE_DUST_GOOD_TO)) {
								airQualityResultDto.setUltraFinedustDetailCd(Const.Code.MANAGEMENT_DETAIL_CD.ULTRA_FINE_DUST_GOOD);
								airQualityResultDto.setUltraFinedustDetailName(Const.Definition.MANAGEMENT_DETAIL_NAME.GOOD);
							} else if (finedustPm2p5Concent >= Integer.parseInt(Const.Definition.GOVERNMENT_STANDARD_INDICATOR.ULTRA_FINE_DUST_GENERAL_FROM) && 
									finedustPm2p5Concent <= Integer.parseInt(Const.Definition.GOVERNMENT_STANDARD_INDICATOR.ULTRA_FINE_DUST_GENERAL_TO)) {
								airQualityResultDto.setUltraFinedustDetailCd(Const.Code.MANAGEMENT_DETAIL_CD.ULTRA_FINE_DUST_GENERAL);
								airQualityResultDto.setUltraFinedustDetailName(Const.Definition.MANAGEMENT_DETAIL_NAME.GENERAL);
							} else if (finedustPm2p5Concent >= Integer.parseInt(Const.Definition.GOVERNMENT_STANDARD_INDICATOR.ULTRA_FINE_DUST_BAD_FROM) && 
									finedustPm2p5Concent <= Integer.parseInt(Const.Definition.GOVERNMENT_STANDARD_INDICATOR.ULTRA_FINE_DUST_BAD_TO)) {
								airQualityResultDto.setUltraFinedustDetailCd(Const.Code.MANAGEMENT_DETAIL_CD.ULTRA_FINE_DUST_BAD);
								airQualityResultDto.setUltraFinedustDetailName(Const.Definition.MANAGEMENT_DETAIL_NAME.BAD);
							}
						}
					} else {
						String maxReferenceVal = StringUtils.defaultString(rsltOivManagementReferenceBaseDto.getMaxReferenceVal());
						airQualityResultDto.setUltraFinedustMaxReferenceVal(maxReferenceVal);
						// 초미세먼지에 대한 경보지표 상세조회..
						OivManagementReferenceDetailDto reqOivManagementReferenceDetailDto = new OivManagementReferenceDetailDto();
						reqOivManagementReferenceDetailDto.setBldId(bldId);
						reqOivManagementReferenceDetailDto.setManagementCategoryCd(Const.Code.MANAGEMENT_CATEGORY_CD.ULTRA_FINE_DUST);
						List<AlertIndicatorDetailDto> rsltAlertIndicatorDetailDtoList = oivManagementReferenceDetailMapper.listManagementReferenceDetail(reqOivManagementReferenceDetailDto);
						if (!CollectionUtils.isEmpty(rsltAlertIndicatorDetailDtoList)) {
							for (AlertIndicatorDetailDto rsltAlertIndicatorDetailDto : rsltAlertIndicatorDetailDtoList) {
								String managementDetailCd = StringUtils.defaultString(rsltAlertIndicatorDetailDto.getManagementDetailCd());
								String managementDetailName = StringUtils.defaultString(rsltAlertIndicatorDetailDto.getManagementDetailName());
								String referenceValFirst = StringUtils.defaultString(rsltAlertIndicatorDetailDto.getReferenceValFirst(), "0");
								String referenceValSecond = StringUtils.defaultString(rsltAlertIndicatorDetailDto.getReferenceValSecond(), "0");
								int firstValue = Integer.parseInt(referenceValFirst);
								int secondValue = Integer.parseInt(referenceValSecond);
								if (Const.Code.MANAGEMENT_DETAIL_CD.ULTRA_FINE_DUST_TOO_BAD.equals(managementDetailCd)) {
									if (finedustPm2p5Concent >= firstValue) {
										airQualityResultDto.setUltraFinedustDetailCd(managementDetailCd);
										airQualityResultDto.setUltraFinedustDetailName(managementDetailName);
										break;
									}
								} else {
									if (finedustPm2p5Concent >= firstValue && finedustPm2p5Concent <= secondValue) {
										airQualityResultDto.setUltraFinedustDetailCd(managementDetailCd);
										airQualityResultDto.setUltraFinedustDetailName(managementDetailName);
										break;
									}
								}
							}
						}
					}
				}
			}
			
			// 빌딩별 예측 날씨정보 목록조회...
			OotWeatherForecastVillageDto reqOotWeatherForecastVillageDto = new OotWeatherForecastVillageDto();
			reqOotWeatherForecastVillageDto.setBldId(bldId);
			List<WeatherForecastVillageResultDto> weatherForecastVillageResultDtoList = ootWeatherForecastVillageMapper.listBuildingWeatherForecastVillage(reqOotWeatherForecastVillageDto);
			
			// 빌딩별 최저/최고 기온정보 조회...
			WeatherMinMaxTemprResultDto weatherMinMaxTemprResultDto = ootWeatherForecastVillageMapper.readMinMaxTemprVal(reqOotWeatherForecastVillageDto);
			if (weatherMinMaxTemprResultDto != null) {
				String minTemprVal = StringUtils.defaultString(weatherMinMaxTemprResultDto.getMinTemprVal());
				String maxTemprVal = StringUtils.defaultString(weatherMinMaxTemprResultDto.getMaxTemprVal());
				for (int idx = 0; idx < weatherForecastVillageResultDtoList.size(); idx++) {
					WeatherForecastVillageResultDto weatherForecastVillageResultDto = weatherForecastVillageResultDtoList.get(idx);
					weatherForecastVillageResultDto.setMinTemprVal(minTemprVal);
					weatherForecastVillageResultDto.setMaxTemprVal(maxTemprVal);
					weatherForecastVillageResultDtoList.set(idx, weatherForecastVillageResultDto);
				}
			}
			
			// 결과 Setting...
			weatherForcastResultDto = new WeatherForcastResultDto();
			weatherForcastResultDto.setCurrentWeatherInfo(weatherForecastExtraShortResultDto);
			weatherForcastResultDto.setEarthquakeInfo(earthquakeNoticeResultDto);
			weatherForcastResultDto.setAirQualityInfo(airQualityResultDto);
			weatherForcastResultDto.setFutureWeatherList(weatherForecastVillageResultDtoList);
			
		} catch (Exception e) {
			throw e;
		}
		return weatherForcastResultDto;
	}

}
