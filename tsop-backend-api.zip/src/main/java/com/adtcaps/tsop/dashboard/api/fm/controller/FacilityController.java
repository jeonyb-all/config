package com.adtcaps.tsop.dashboard.api.fm.controller;

import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.util.CollectionUtils;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.adtcaps.tsop.dashboard.api.fm.domain.BuildingInTemprCellRequestDto;
import com.adtcaps.tsop.dashboard.api.fm.domain.BuildingInTemprCellResultDto;
import com.adtcaps.tsop.dashboard.api.fm.domain.BuildingInTemprChartResultDto;
import com.adtcaps.tsop.dashboard.api.fm.domain.ChilledwaterTemprChartRequestDto;
import com.adtcaps.tsop.dashboard.api.fm.domain.ChilledwaterTemprChartResultDto;
import com.adtcaps.tsop.dashboard.api.fm.domain.FreezerSystemDetailResultDto;
import com.adtcaps.tsop.dashboard.api.fm.service.FacilityService;
import com.adtcaps.tsop.domain.fm.OfmFacilityObjectDto;
import com.adtcaps.tsop.helper.constant.Const;
import com.adtcaps.tsop.helper.domain.ResultDto;
import com.adtcaps.tsop.helper.util.CommonObjectUtil;

import lombok.extern.slf4j.Slf4j;

/**
 * 
 * <ul>
 * <li>업무 그룹명 : tsop-backend-api</li>
 * <li>서브 업무명 : com.adtcaps.tsop.dashboard.api.fm.controller</li>
 * <li>설  명 : FacilityController.java</li>
 * <li>작성일 : 2021. 10. 26.</li>
 * <li>작성자 : jeonyb4</li>
 * </ul>
 */
@Slf4j
@RestController
@RequestMapping("/api/dashboard/facility")
public class FacilityController {
	
	private final String ERR_MSG_NULL_BLD_ID = "빌딩ID가 없습니다.";
	private final String ERR_MSG_NULL_PERIOD_TIME = "조회기간주기가 없습니다.";
	
	private final String ERR_MSG_NULL_READ_RESULT = "조회 결과가 없습니다.";
	
	@Autowired
	private FacilityService facilityService;
	
	/**
	 * 
	 * listFreezerSystemOperateTime
	 * 
	 * @param facilityCategoryCd
	 * @param reqOfmFacilityObjectDto
	 * @return ResponseEntity
	 * @throws Exception 
	 */
	@SuppressWarnings("rawtypes")
	@GetMapping(value="/facility-categories/{facilityCategoryCd}/operate-times", produces="application/json; charset=UTF-8")
	public ResponseEntity listFreezerSystemOperateTime(@PathVariable("facilityCategoryCd") String facilityCategoryCd, OfmFacilityObjectDto reqOfmFacilityObjectDto) throws Exception {
		
		ResponseEntity<ResultDto> resEntity = null;
		String returnString = "";
		
		String bldId = StringUtils.defaultString(reqOfmFacilityObjectDto.getBldId());
		if ("".equals(bldId)) {
			log.error(">>>>>> bldId ERROR:{}", ERR_MSG_NULL_BLD_ID);
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_BLD_ID));
			return resEntity;
		}
		
		reqOfmFacilityObjectDto.setFacilityCategoryCd(facilityCategoryCd);
		
		// 냉방시스템현황 상세 목록조회...
		List<FreezerSystemDetailResultDto> freezerSystemDetailResultDtoList = facilityService.listFreezerSystemOperateTime(reqOfmFacilityObjectDto);
		if (CollectionUtils.isEmpty(freezerSystemDetailResultDtoList)) {
			returnString = Const.Common.RESULT_CODE.SUCCESS;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_READ_RESULT, freezerSystemDetailResultDtoList));
        } else {
        	returnString = Const.Common.RESULT_CODE.SUCCESS;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, "", freezerSystemDetailResultDtoList));
		}
    	
		return resEntity;
	}
	
	/**
	 * 
	 * listChilledwaterTemprGapLineChart
	 * 
	 * @param chilledwaterTemprChartRequestDto
	 * @return ResponseEntity
	 * @throws Exception 
	 */
	@SuppressWarnings("rawtypes")
	@GetMapping(value="/chilledwater-differ-temprs/realtime-line-chart", produces="application/json; charset=UTF-8")
	public ResponseEntity listChilledwaterTemprGapLineChart(ChilledwaterTemprChartRequestDto chilledwaterTemprChartRequestDto) throws Exception {
		
		ResponseEntity<ResultDto> resEntity = null;
		String returnString = "";
		
		String bldId = StringUtils.defaultString(chilledwaterTemprChartRequestDto.getBldId());
		if ("".equals(bldId)) {
			log.error(">>>>>> bldId ERROR:{}", ERR_MSG_NULL_BLD_ID);
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_BLD_ID));
			return resEntity;
		}
		int periodTime = CommonObjectUtil.defaultNumber(chilledwaterTemprChartRequestDto.getPeriodTime());
		if (periodTime < 1) {
			log.error(">>>>>> periodTime ERROR:{}", ERR_MSG_NULL_PERIOD_TIME);
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_PERIOD_TIME));
			return resEntity;
		}
		
		// 빌딩별 냉수입출구 온도차 실시간 Line 차트 조회
		ChilledwaterTemprChartResultDto chilledwaterTemprChartResultDto = facilityService.listChilledwaterTemprGapLineChart(chilledwaterTemprChartRequestDto);
		if (chilledwaterTemprChartResultDto == null) {
			returnString = Const.Common.RESULT_CODE.SUCCESS;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_READ_RESULT, chilledwaterTemprChartResultDto));
        } else {
        	returnString = Const.Common.RESULT_CODE.SUCCESS;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, "", chilledwaterTemprChartResultDto));
		}
		
		return resEntity;
	}
	
	/**
	 * 
	 * listBuildingInTemprLineChart
	 * 
	 * @param reqOfmFacilityObjectDto
	 * @return ResponseEntity
	 * @throws Exception 
	 */
	@SuppressWarnings("rawtypes")
	@GetMapping(value="/building-in-temprs/realtime-line-chart", produces="application/json; charset=UTF-8")
	public ResponseEntity listBuildingInTemprLineChart(OfmFacilityObjectDto reqOfmFacilityObjectDto) throws Exception {
		
		ResponseEntity<ResultDto> resEntity = null;
		String returnString = "";
		
		String bldId = StringUtils.defaultString(reqOfmFacilityObjectDto.getBldId());
		if ("".equals(bldId)) {
			log.error(">>>>>> bldId ERROR:{}", ERR_MSG_NULL_BLD_ID);
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_BLD_ID));
			return resEntity;
		}
		
		reqOfmFacilityObjectDto.setFacilityCategoryCd(Const.Code.FACILITY_CATEGORY_CD.IN_TEMPERATURE);
		
		// 빌딩별 실내온도현황 실시간 Line 차트 조회
		BuildingInTemprChartResultDto buildingInTemprChartResultDto = facilityService.listBuildingInTemprLineChart(reqOfmFacilityObjectDto);
		if (buildingInTemprChartResultDto == null) {
			returnString = Const.Common.RESULT_CODE.SUCCESS;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_READ_RESULT, buildingInTemprChartResultDto));
        } else {
        	returnString = Const.Common.RESULT_CODE.SUCCESS;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, "", buildingInTemprChartResultDto));
		}
		
		return resEntity;
	}
	
	/**
	 * 
	 * listBuildingInTemprCellDetail
	 * 
	 * @param buildingInTemprCellRequestDto
	 * @return ResponseEntity
	 * @throws Exception 
	 */
	@SuppressWarnings("rawtypes")
	@GetMapping(value="/building-in-temprs/point-details", produces="application/json; charset=UTF-8")
	public ResponseEntity listBuildingInTemprCellDetail(BuildingInTemprCellRequestDto buildingInTemprCellRequestDto) throws Exception {
		
		ResponseEntity<ResultDto> resEntity = null;
		String returnString = "";
		
		String bldId = StringUtils.defaultString(buildingInTemprCellRequestDto.getBldId());
		if ("".equals(bldId)) {
			log.error(">>>>>> bldId ERROR:{}", ERR_MSG_NULL_BLD_ID);
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_BLD_ID));
			return resEntity;
		}
		
		buildingInTemprCellRequestDto.setFacilityCategoryCd(Const.Code.FACILITY_CATEGORY_CD.IN_TEMPERATURE);
		
		// 빌딩별 층별 셀별 실내온도현황 상세 목록조회
		BuildingInTemprCellResultDto buildingInTemprCellResultDto = facilityService.listBuildingInTemprCellDetail(buildingInTemprCellRequestDto);
		if (buildingInTemprCellResultDto == null) {
			returnString = Const.Common.RESULT_CODE.SUCCESS;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_READ_RESULT, buildingInTemprCellResultDto));
        } else {
        	returnString = Const.Common.RESULT_CODE.SUCCESS;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, "", buildingInTemprCellResultDto));
		}
		
		return resEntity;
	}

}
