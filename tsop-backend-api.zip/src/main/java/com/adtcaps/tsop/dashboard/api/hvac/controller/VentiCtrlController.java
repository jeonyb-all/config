package com.adtcaps.tsop.dashboard.api.hvac.controller;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.util.CollectionUtils;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.adtcaps.tsop.authentication.domain.JwtAuthResultDto;
import com.adtcaps.tsop.dashboard.api.hvac.domain.FloorOccupantResultVO;
import com.adtcaps.tsop.dashboard.api.hvac.domain.FloorRealTimeAirQualityCO2InfoVO;
import com.adtcaps.tsop.dashboard.api.hvac.domain.FloorRealTimeOccupantInfoVO;
import com.adtcaps.tsop.dashboard.api.hvac.domain.RecmdVentiResultVO;
import com.adtcaps.tsop.dashboard.api.hvac.service.VentiCtrlService;
import com.adtcaps.tsop.helper.constant.Const;
import com.adtcaps.tsop.helper.domain.ResultDto;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.extern.slf4j.Slf4j;


@Api(value = "대시보드업무 HVAC 재실밀도기반 환기제어 API", tags = {"대시보드업무 HVAC 재실밀도기반 환기제어 API"})
@Tag(name = "대시보드업무 HVAC 재실밀도기반 환기제어 API", description = ""
		+ "``` \n"
		+ "(1)층별 재실자 현황 조회 요구사항\n" 
		+ "  1)재실자 0명인경우  0명수 배경색을 회색처리\n" 
		+ "  2)가장 많은층의  000명수 1곳에 배경색을 빨강처리\n" 
		+ "  3)그외는 배경색을 파란색 처리 \n" 
		+ "  4)화면상단의   [ ] 클릭시 실시간 재실자 현황을 보여준다.\n"
		+ "  5)재실자수(Azuer PaaS분석계에서 제공) \n"
		+ "  6)화면 갱신주기 15분마다 갱신 \n" 		
		+ "(2)층별권장 환기량(외기댐퍼 개도율) 요구사항\n"  
		+ "  1) 각 층별 숫자 table과  환기량(색상) table 별도로 보여준다.   \n"  
		+ "    - 권장량 > 운영량  : 빨간색 환기량부족  \n"
		+ "    - 권장량< 운영량   : 녹색 절감가능 \n"
		+ "    - 권장량 = 운영량  : 하늘색  쾌적  \n"
		+ "  2)건물 층에 맞게 화면에 표현하면 된다(T 타워는 33층까지만 존재)  \n"
		+ "  3)층을 클릭하면  층의 권장환기량을 풍선도움말로 보여준다.  \n"
		+ "  4)층별 권장환기량 (Azuer PaaS분석계에서 제공) \n"
		+ "  5)화면 갱신주기 15분마다 갱신  \n"

	
		+ "(3)층별 재실자 현황 상세-실시간 재실자 현황  요구사항\n" 
		+ "  1)열은  00~23시 고정이 아니라  현재시간-24시간 부터 현재시간까지 보여준다.\n" 
		+ "    예) 현재시간이 14시면  어제  15시부터 ~현재 14시 까지로 보여준다.\n" 
		+ "  2)재실자수(Azuer PaaS분석계에서 제공) \n"

		+ "``` \n")



@Slf4j
@RestController
@RequestMapping(value = "/api/dashboard/hvac/venti")
public class VentiCtrlController {
	private final String ERR_MSG_NULL_LOGIN_USER_ID = "로그인 사용자ID가 없습니다.";
	private final String ERR_MSG_NULL_BLD_ID = "빌딩ID가 없습니다.";
 

	private final String ERR_MSG_NULL_SEARCH_RESULT_LIST = "조회 결과가 없습니다.";
	private final String ERR_MSG_READ_FAIL = "조회에 실패하였습니다.";
	private final String ERR_MSG_UPDATE_FAIL = "저장에 실패하였습니다.";
	private final String ERR_MSG_DELETE_FAIL = "삭제에 실패하였습니다.";
	
	@Autowired
	private VentiCtrlService ventiCtrlService;

	@ApiOperation(nickname = "층별 재실자 현황 조회", value = "층별 재실자 현황  조회"
			, notes = "``` \n"
					+"건물의 층별 재실자 현황을 조회하여 보여준다 \n"
					+"``` \n"

		        +"```"
		        + "sequence\n"
		        + "User -> 재실밀도기반환기제어Controller: GET /api/dashboard/hvac/venti/building/{bldId}/officePerson \n"
		        + "재실밀도기반환기제어Controller -> 재실밀도기반환기제어Controller : 입력값 유효성체크\n"
		        + "재실밀도기반환기제어Controller -> 재실밀도기반환기제어Service: 조회요청\n"
				+ "재실밀도기반환기제어Service    -> 재실밀도기반환기제어Mapper: 조회요청\n"
				+ "재실밀도기반환기제어Mapper     -> Database: 조회요청\n"
				+ "Note right of Database :  출입_AI재실자수15분집계 \n" 
				+ "Database                 --> 재실밀도기반환기제어Mapper: return 조회결과 \n" 
				+ "재실밀도기반환기제어Mapper     --> 재실밀도기반환기제어Service: 조회결과List \n"
				+ "재실밀도기반환기제어Service    --> 재실밀도기반환기제어Controller: 조회결과List\n"
				+ "재실밀도기반환기제어Controller --> User : 층별 재실자현황  조회 결과 JSON Object\\n건물ID,측정일자시분,층,재실자수 \n"
				+ "```\n"	
				
					+ "")
	//@ResponseBody FloorOccupantResultVO
	@SuppressWarnings("rawtypes")
	@GetMapping(value="building/{bldId}/officePerson", produces="application/json; charset=UTF-8")
	public @ResponseBody ResponseEntity findOfficePerson(
			@AuthenticationPrincipal JwtAuthResultDto authResultDto, 
			@ApiParam(value = "건물ID", required = true, example = "0000") 
			@PathVariable(required = true) String bldId
			 
			) {

    	ResponseEntity<ResultDto> resEntity = null;
		String returnString = "";
		//로그인체크
		String loginUserId = StringUtils.defaultString(authResultDto.getUserId());
		if ("".equals(loginUserId)) {
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_LOGIN_USER_ID));
			return resEntity;
		}

		//빌딩체크 
		if (bldId==null || "".equals(bldId)) {
			log.error(">>>>>> bldId ERROR:{}", ERR_MSG_NULL_BLD_ID);
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_BLD_ID));
			return resEntity;
		}
		FloorOccupantResultVO floorOccupantResultVO = ventiCtrlService.findOfficePerson(bldId);

		if (floorOccupantResultVO == null || CollectionUtils.isEmpty(floorOccupantResultVO.getFloorOccupantInfoList()) ) {
		    if(floorOccupantResultVO == null )  floorOccupantResultVO = new FloorOccupantResultVO();
            //오류가 아닌 데이터가 없을때 C0000
            String returnMesg = "";
            if(CollectionUtils.isEmpty(floorOccupantResultVO.getFloorOccupantInfoList())){
                returnString = Const.Common.RESULT_CODE.SUCCESS;
                returnMesg = ERR_MSG_NULL_SEARCH_RESULT_LIST;
             }else { 
                returnString = Const.Common.RESULT_CODE.FAIL;
                returnMesg = ERR_MSG_READ_FAIL;
             } 
			resEntity = ResponseEntity.ok(new ResultDto(returnString, returnMesg,floorOccupantResultVO ));
		} else {
			returnString = Const.Common.RESULT_CODE.SUCCESS; 
			resEntity = ResponseEntity.ok(new ResultDto(returnString, "", floorOccupantResultVO));
		}
    	
    	return resEntity;
	}

	@ApiOperation(nickname = "층별권장 환기량(외기댐퍼 개도율)", value = "층별권장 환기량(외기댐퍼 개도율)"
			, notes = "``` \n"
					+"건물의 층별 권장 환기량과 운영량(댐퍼개도율)을 비교하여 절감가능,쾌적수준,환기량 부족을 화면에 보여준다.  \n"
					+"``` \n"

		        +"```"
		        + "sequence\n"
		        + "User -> 재실밀도기반환기제어Controller:  GET /api/dashboard/hvac/venti/building/{bldId}/recmd/ventirate \n"
		        + "재실밀도기반환기제어Controller -> 재실밀도기반환기제어Controller : 입력값 유효성체크\n"
		        + "재실밀도기반환기제어Controller -> 재실밀도기반환기제어Service: 조회요청\n"
				+ "재실밀도기반환기제어Service    -> 재실밀도기반환기제어Mapper: 조회요청\n"
				+ "재실밀도기반환기제어Mapper     -> Database: 조회요청\n"
				+ "Note right of Database :  설비_AI댐퍼15분기준목록\\n설비_건물외기냉방집계 \n" 
				+ "Database                 --> 재실밀도기반환기제어Mapper: return 조회결과 \n" 
				+ "재실밀도기반환기제어Mapper     --> 재실밀도기반환기제어Service: 조회결과List \n"
				+ "재실밀도기반환기제어Service    --> 재실밀도기반환기제어Controller: 조회결과List\n"
				+ "재실밀도기반환기제어Controller --> User : 층별 권장 환기량  조회 결과 JSON Object\\n건물ID,측정일자시간,층,재실자수 \n"
				+ "```\n"	
					)
	//@ResponseBody List<FloorRecmdVentiRateVO>
	@SuppressWarnings("rawtypes")
	@GetMapping(value="building/{bldId}/recmd/ventirate", produces="application/json; charset=UTF-8")
	public @ResponseBody ResponseEntity findRecmdVentirate(
			@AuthenticationPrincipal JwtAuthResultDto authResultDto, 
			@ApiParam(value = "건물ID", required = true, example = "0000") 
			@PathVariable(required = true) String bldId
			 
			) {

    	ResponseEntity<ResultDto> resEntity = null;
		String returnString = "";
		//로그인체크
		String loginUserId = StringUtils.defaultString(authResultDto.getUserId());
		if ("".equals(loginUserId)) {
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_LOGIN_USER_ID));
			return resEntity;
		}

		//빌딩체크 
		if (bldId==null || "".equals(bldId)) {
			log.error(">>>>>> bldId ERROR:{}", ERR_MSG_NULL_BLD_ID);
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_BLD_ID));
			return resEntity;
		}
		/*
		List<FloorRecmdVentiRateVO> floorRecmdVentiRateList =  ventiCtrlService.findRecmdVentirate(bldId);

		if (floorRecmdVentiRateList == null || CollectionUtils.isEmpty(floorRecmdVentiRateList ) ) {
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_SEARCH_RESULT_LIST, new ArrayList<FloorRecmdVentiRateVO>() ));
		} else {
			returnString = Const.Common.RESULT_CODE.SUCCESS; 
			resEntity = ResponseEntity.ok(new ResultDto(returnString, "", floorRecmdVentiRateList));
		}
    	*/
		//List<FloorRecmdVentiRateVO> floorRecmdVentiRateList =  ventiCtrlService.findRecmdVentirate(bldId);
	    RecmdVentiResultVO recmdVentiResultVO = ventiCtrlService.findRecmdVentirate(bldId);

        if (recmdVentiResultVO == null || CollectionUtils.isEmpty(recmdVentiResultVO.getFloorRecmdVentiRateList() ) ) {
            if(recmdVentiResultVO == null )  recmdVentiResultVO = new RecmdVentiResultVO();
            
            //오류가 아닌 데이터가 없을때 C0000
            String returnMesg = "";
            if(CollectionUtils.isEmpty(recmdVentiResultVO.getFloorRecmdVentiRateList())){
                returnString = Const.Common.RESULT_CODE.SUCCESS;
                returnMesg = ERR_MSG_NULL_SEARCH_RESULT_LIST;
             }else { 
                returnString = Const.Common.RESULT_CODE.FAIL;
                returnMesg = ERR_MSG_READ_FAIL;
             } 
            resEntity = ResponseEntity.ok(new ResultDto(returnString, returnMesg, recmdVentiResultVO   ));
        } else {
            returnString = Const.Common.RESULT_CODE.SUCCESS; 
            resEntity = ResponseEntity.ok(new ResultDto(returnString, "", recmdVentiResultVO));
        }

        
		return resEntity;
	}
	
	@ApiOperation(nickname = "층별 재실자 현황 상세-실시간 재실자 현황", value = "층별 재실자 현황 상세-실시간 재실자 현황"
			, notes = "``` \n"
					+"건물의 층별 최근 시간부터 24시간 전까지의 재실자현황을 보여준다.  \n"
					+"``` \n"

		        +"```"
		        + "sequence\n"
		        + "User -> 재실밀도기반환기제어Controller: GET /api/dashboard/hvac/venti/building/{bldId}/officePerson/detail \n"
		        + "재실밀도기반환기제어Controller -> 재실밀도기반환기제어Controller : 입력값 유효성체크\n"
		        + "재실밀도기반환기제어Controller -> 재실밀도기반환기제어Service: 조회요청\n"
				+ "재실밀도기반환기제어Service    -> 재실밀도기반환기제어Mapper: 조회요청\n"
				+ "재실밀도기반환기제어Mapper     -> Database: 조회요청\n"
				+ "Note right of Database :  출입_AI재실자수15분집계 \n" 
				+ "Database                 --> 재실밀도기반환기제어Mapper: return 조회결과 \n" 
				+ "재실밀도기반환기제어Mapper     --> 재실밀도기반환기제어Service: 조회결과List \n"
				+ "재실밀도기반환기제어Service    --> 재실밀도기반환기제어Controller: 조회결과List\n"
				+ "재실밀도기반환기제어Controller --> User : 실시간 재실자 현황  조회 결과 JSON Object\\n-건물ID,시간별,층,재실자수 \n"
				+ "```\n"	
									
					)
	//@ResponseBody List<FloorRealTimeOccupantInfoVO> 
	@SuppressWarnings("rawtypes")
	@GetMapping(value="building/{bldId}/officePerson/detail", produces="application/json; charset=UTF-8")
	public @ResponseBody ResponseEntity findRealTimeOfficePerson(
			@AuthenticationPrincipal JwtAuthResultDto authResultDto, 
			@ApiParam(value = "건물ID", required = true, example = "0000") 
			@PathVariable(required = true) String bldId
			 
			) {
		 	

    	ResponseEntity<ResultDto> resEntity = null;
		String returnString = "";
		//로그인체크
		String loginUserId = StringUtils.defaultString(authResultDto.getUserId());
		if ("".equals(loginUserId)) {
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_LOGIN_USER_ID));
			return resEntity;
		}
		//빌딩체크 
		if (bldId==null || "".equals(bldId)) {
			log.error(">>>>>> bldId ERROR:{}", ERR_MSG_NULL_BLD_ID);
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_BLD_ID));
			return resEntity;
		}
		
		List<FloorRealTimeOccupantInfoVO> floorRealTimeOccupantList =  ventiCtrlService.findRealTimeOfficePerson(bldId);
		

		if (floorRealTimeOccupantList == null || CollectionUtils.isEmpty(floorRealTimeOccupantList ) ) {
		 
            //오류가 아닌 데이터가 없을때 C0000
            String returnMesg = "";
            if(CollectionUtils.isEmpty(floorRealTimeOccupantList)){
                returnString = Const.Common.RESULT_CODE.SUCCESS;
                returnMesg = ERR_MSG_NULL_SEARCH_RESULT_LIST;
             }else { 
                returnString = Const.Common.RESULT_CODE.FAIL;
                returnMesg = ERR_MSG_READ_FAIL;
             } 
            
			resEntity = ResponseEntity.ok(new ResultDto(returnString, returnMesg, new ArrayList<FloorRealTimeOccupantInfoVO>() ));
		} else {
			returnString = Const.Common.RESULT_CODE.SUCCESS; 
			resEntity = ResponseEntity.ok(new ResultDto(returnString, "", floorRealTimeOccupantList));
		}
    	
    	return resEntity;
	}
	
	//층별 재실자 현황 상세-공기질(CO2) 현황	
    @SuppressWarnings("rawtypes")
    @GetMapping(value="building/{bldId}/airQualityCO2/detail", produces="application/json; charset=UTF-8")
    public @ResponseBody ResponseEntity findRealTimeAirQualityCO2(
            @AuthenticationPrincipal JwtAuthResultDto authResultDto, 
            @ApiParam(value = "건물ID", required = true, example = "0000") 
            @PathVariable(required = true) String bldId
             
            ) {
            

        ResponseEntity<ResultDto> resEntity = null;
        String returnString = "";
        //로그인체크
        String loginUserId = StringUtils.defaultString(authResultDto.getUserId());
        if ("".equals(loginUserId)) {
            returnString = Const.Common.RESULT_CODE.FAIL;
            resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_LOGIN_USER_ID));
            return resEntity;
        }
        //빌딩체크 
        if (bldId==null || "".equals(bldId)) {
            log.error(">>>>>> bldId ERROR:{}", ERR_MSG_NULL_BLD_ID);
            returnString = Const.Common.RESULT_CODE.FAIL;
            resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_BLD_ID));
            return resEntity;
        }
        
        List<FloorRealTimeAirQualityCO2InfoVO> floorRealTimeAirQualityCO2List =  ventiCtrlService.findRealTimeAirQualityCO2(bldId);
        

        if (floorRealTimeAirQualityCO2List == null || CollectionUtils.isEmpty(floorRealTimeAirQualityCO2List ) ) {
         
            //오류가 아닌 데이터가 없을때 C0000
            String returnMesg = "";
            if(CollectionUtils.isEmpty(floorRealTimeAirQualityCO2List)){
                returnString = Const.Common.RESULT_CODE.SUCCESS;
                returnMesg = ERR_MSG_NULL_SEARCH_RESULT_LIST;
             }else { 
                returnString = Const.Common.RESULT_CODE.FAIL;
                returnMesg = ERR_MSG_READ_FAIL;
             } 
            
            resEntity = ResponseEntity.ok(new ResultDto(returnString, returnMesg, new ArrayList<FloorRealTimeOccupantInfoVO>() ));
        } else {
            returnString = Const.Common.RESULT_CODE.SUCCESS; 
            resEntity = ResponseEntity.ok(new ResultDto(returnString, "", floorRealTimeAirQualityCO2List));
        }
        
        return resEntity;
    }
	

}
