package com.adtcaps.tsop.dashboard.api.acaas.controller;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.adtcaps.tsop.dashboard.api.acaas.domain.EnterEventCurrentStatePieChartResultDto;
import com.adtcaps.tsop.dashboard.api.acaas.service.AcaasService;
import com.adtcaps.tsop.domain.acaas.OacEnterEventDayStatDto;
import com.adtcaps.tsop.domain.acaas.OacEnterEventDto;
import com.adtcaps.tsop.helper.constant.Const;
import com.adtcaps.tsop.helper.domain.LineChartResultDto;
import com.adtcaps.tsop.helper.domain.ResultDto;

import lombok.extern.slf4j.Slf4j;

/**
 * 
 * <ul>
 * <li>업무 그룹명 : tsop-backend-api</li>
 * <li>서브 업무명 : com.adtcaps.tsop.dashboard.api.acaas.controller</li>
 * <li>설  명 : AcaasController.java</li>
 * <li>작성일 : 2020. 12. 4.</li>
 * <li>작성자 : jeonyb4</li>
 * </ul>
 */
@Slf4j
@RestController
@RequestMapping("/api/dashboard/acaas")
public class AcaasController {
	
	private final String ERR_MSG_NULL_BLD_ID = "bldId가 없습니다.";
	
	private final String ERR_MSG_NULL_SEARCH_RESULT_LIST = "조회 결과가 없습니다.";
	
	@Autowired
	private AcaasService acaasService;
	
	/**
	 * 
	 * readEnterEventCurrentStatePieChart
	 *
	 * @param reqOacEnterEventDto
	 * @return ResponseEntity
	 */
	@SuppressWarnings("rawtypes")
	@GetMapping(value="/enter-events/pi-chart", produces="application/json; charset=UTF-8")
	public ResponseEntity readEnterEventCurrentStatePieChart(OacEnterEventDto reqOacEnterEventDto) throws Exception {
		
		ResponseEntity<ResultDto> resEntity = null;
		String returnString = "";
			
//		Gson gson = new Gson();
//		String jsonStr = gson.toJsonTree(chartRequestDto).toString();
//		jsonStr = CommonJsonUtil.getPretty(jsonStr);
//		log.debug(">>>>>> Input jsonStr:{}", jsonStr);
		
		// 필수값 체크...
		String bldId = StringUtils.defaultString(reqOacEnterEventDto.getBldId());
		if ("".equals(bldId)) {
			log.error(">>>>>> bldId ERROR:{}", ERR_MSG_NULL_BLD_ID);
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_BLD_ID));
			return resEntity;
		}
		// 입출입 현황 Pi Chart 조회
		EnterEventCurrentStatePieChartResultDto enterEventCurrentStatePieChartResultDto = acaasService.readEnterEventCurrentStatePieChart(reqOacEnterEventDto);
		if (enterEventCurrentStatePieChartResultDto == null) {
			returnString = Const.Common.RESULT_CODE.SUCCESS;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_SEARCH_RESULT_LIST, enterEventCurrentStatePieChartResultDto));
        } else {
        	returnString = Const.Common.RESULT_CODE.SUCCESS;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, "", enterEventCurrentStatePieChartResultDto));
		}
		
		return resEntity;
	}
	
	/**
	 * 
	 * listEnterEventAlarmCurrentStateChart
	 *
	 * @param reqOacEnterEventDayStatDto
	 * @return ResponseEntity
	 */
	@SuppressWarnings("rawtypes")
	@GetMapping(value="/enter-events/line-chart/{searchUnit}", produces="application/json; charset=UTF-8")
	public ResponseEntity listEnterEventAlarmCurrentStateChart(@PathVariable("searchUnit") String searchUnit, OacEnterEventDayStatDto reqOacEnterEventDayStatDto) throws Exception {
		
		ResponseEntity<ResultDto> resEntity = null;
		String returnString = "";
		
		String bldId = StringUtils.defaultString(reqOacEnterEventDayStatDto.getBldId());
		if ("".equals(bldId)) {
			log.error(">>>>>> bldId ERROR:{}", ERR_MSG_NULL_BLD_ID);
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_BLD_ID));
			return resEntity;
		}
		
		// 빌딩별 입출입/알람현황 Line 차트 조회
		LineChartResultDto lineChartResultDto = null;
		if (Const.Definition.SEARCH_UNIT.DAY.equals(searchUnit)) {
			// 일별
			lineChartResultDto = acaasService.listEnterEventAlarmCurrentStateChart(reqOacEnterEventDayStatDto);
		} else {
			
		}
		
		if (lineChartResultDto == null) {
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_SEARCH_RESULT_LIST, lineChartResultDto));
        } else {
        	returnString = Const.Common.RESULT_CODE.SUCCESS;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, "", lineChartResultDto));
		}
		
		return resEntity;
	}
	
	
}
