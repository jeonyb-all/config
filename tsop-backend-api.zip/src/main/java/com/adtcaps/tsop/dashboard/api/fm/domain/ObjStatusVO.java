package com.adtcaps.tsop.dashboard.api.fm.domain;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class ObjStatusVO {
    private String bldId;                                   //빌딩Id
    private String objId;                                   //objectId
    private String facilityOrgName;                         //오리지날 명
    private String facilityName;                            //명
    private Integer facilityOperateCnt;                     //설비가동개수
    private String facilityOperateStartHourminute;          //설비가동시작시분
    private String facilityOperateSuspendHourminute;        //설비가동정지시분
    private Integer facilityOperateTm;                      //설비가동시간
    private Float chilledwaterSupplyTemprVal;               //냉수공급온도값
    private Float chilledwaterReturnTemprVal;               //냉수반환온도값
    private Float cowSupplyTemprVal;                        //냉각수공급온도값
    private Float cowReturnTemprVal;                        //냉각수반환온도값
    private Float chrCopVal;                                //냉동기CoP값
    private Float ahuReturnTemprVal;                        //공조기반환온도값
    private Float ahuReturnSetupTemprVal;                   //공조기반환설정온도값
    private Float ahuReturnHumidityVal;                     //공조기반환습도값
    private Float ahuGapTemprVal;                           //공조기 온도 갭
    private Float rtmAvgFloorH6Val;                         //층별 6시 실내온도
    private Float rtmAvgFloorH7Val;                         //층별 7시 실내온도
    private Float rtmAvgFloorH8Val;                         //층별 8시 실내온도
    private String locFloor;                                //위치층수
}
