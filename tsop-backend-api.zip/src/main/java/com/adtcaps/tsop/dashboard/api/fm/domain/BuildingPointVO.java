package com.adtcaps.tsop.dashboard.api.fm.domain;

import java.util.ArrayList;
import java.util.List;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class BuildingPointVO {
	private String bldId;
	private String objectId;                           //Object ID
	private String facilityName;                       //설비 장비 명
	private String locFloor;                           //층
	private String locFloorName;                       //층명
	private List<BuildingEquipHourVO> hourList = new ArrayList<BuildingEquipHourVO>();       //시간대별 정보
}
