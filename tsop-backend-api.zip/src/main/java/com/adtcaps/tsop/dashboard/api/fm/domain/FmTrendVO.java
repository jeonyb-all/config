package com.adtcaps.tsop.dashboard.api.fm.domain;

import java.io.Serializable;

import lombok.Data;
@Data
public class FmTrendVO implements Serializable{
	private String bldId;
	private String bldName;

	private String equipmentCd;
	private String equipmentCdName;
	private String startHour;
	private String endHour;
	private String operationHour;
	private String eqptTotalNum;
	private String eqptWorkNum;
	private String coolWaterTemperatureIn;
	private String coolWaterTemperatureOut;
	private String coolantTemperatureIn;
	private String coolantTemperatureOut;
	private String outerDamperOpenRate;
}
