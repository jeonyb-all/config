package com.adtcaps.tsop.dashboard.api.fm.domain;

import lombok.Getter;
import lombok.Setter;

/**
 * 
 * <ul>
 * <li>업무 그룹명 : tsop-backend-api</li>
 * <li>서브 업무명 : com.adtcaps.tsop.dashboard.api.fm.domain</li>
 * <li>설  명 : InTemprCellHourValueResultDto.java</li>
 * <li>작성일 : 2021. 10. 29.</li>
 * <li>작성자 : jeonyb4</li>
 * </ul>
 */
@Getter
@Setter
public class InTemprCellHourValueResultDto {
	private String objectId;
	private String locFloor;
	private String statHour;
	private Double curVal;
	private String overTemprColor;

}
