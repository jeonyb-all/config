package com.adtcaps.tsop.dashboard.api.fm.service;

import java.util.List;

import com.adtcaps.tsop.dashboard.api.fm.domain.BuildingInTemprCellRequestDto;
import com.adtcaps.tsop.dashboard.api.fm.domain.BuildingInTemprCellResultDto;
import com.adtcaps.tsop.dashboard.api.fm.domain.BuildingInTemprChartResultDto;
import com.adtcaps.tsop.dashboard.api.fm.domain.ChilledwaterTemprChartRequestDto;
import com.adtcaps.tsop.dashboard.api.fm.domain.ChilledwaterTemprChartResultDto;
import com.adtcaps.tsop.dashboard.api.fm.domain.FreezerSystemDetailResultDto;
import com.adtcaps.tsop.domain.fm.OfmFacilityObjectDto;

/**
 * 
 * <ul>
 * <li>업무 그룹명 : tsop-backend-api</li>
 * <li>서브 업무명 : com.adtcaps.tsop.dashboard.api.fm.service</li>
 * <li>설  명 : FacilityService.java</li>
 * <li>작성일 : 2021. 10. 26.</li>
 * <li>작성자 : jeonyb4</li>
 * </ul>
 */
public interface FacilityService {
	/**
     * 
     * listFreezerSystemOperateTime
     * 
     * @param reqOfmFacilityObjectDto
     * @return List<FreezerSystemDetailResultDto>
     * @throws Exception 
     */
	public List<FreezerSystemDetailResultDto> listFreezerSystemOperateTime(OfmFacilityObjectDto reqOfmFacilityObjectDto) throws Exception;
    
    /**
     * 
     * listChilledwaterTemprGapLineChart
     * 
     * @param chilledwaterTemprChartRequestDto
     * @return ChilledwaterTemprChartResultDto
     * @throws Exception 
     */
    public ChilledwaterTemprChartResultDto listChilledwaterTemprGapLineChart(ChilledwaterTemprChartRequestDto chilledwaterTemprChartRequestDto) throws Exception;
    
    /**
     * 
     * listBuildingInTemprLineChart
     * 
     * @param reqOfmFacilityObjectDto
     * @return BuildingInTemprChartResultDto
     * @throws Exception 
     */
    public BuildingInTemprChartResultDto listBuildingInTemprLineChart(OfmFacilityObjectDto reqOfmFacilityObjectDto) throws Exception;
    
    /**
     * 
     * listBuildingInTemprCellDetail
     * 
     * @param buildingInTemprCellRequestDto
     * @return BuildingInTemprCellResultDto
     * @throws Exception 
     */
    public BuildingInTemprCellResultDto listBuildingInTemprCellDetail(BuildingInTemprCellRequestDto buildingInTemprCellRequestDto) throws Exception;

}
