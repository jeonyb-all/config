package com.adtcaps.tsop.dashboard.api.fm.domain;

import java.util.ArrayList;
import java.util.List;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class EquipObjVO {
    private String bldId;
    private String objectId;
    private String facilityOrgName;
    private String superObjectId;
    private String facilityName;
    private String locFloor;    
    private List<EquipObjWeekVO> weekList = new ArrayList<EquipObjWeekVO>();           //
}
