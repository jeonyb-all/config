package com.adtcaps.tsop.dashboard.api.hvac.domain;

import java.util.List;

import javax.validation.constraints.Size;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@ApiModel(value = "DB에서 가져오는 빌딩 층의 이전 시간에대한 공기질(CO2) 값 ", description = "DB에서 가져오는빌딩/층의 이전 시간에대한 공기질(CO2) 값")
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class FloorPreHourAirQualityCO2AllVO { 
	 
	@ApiModelProperty(position = 1 , required = false, value="건물ID", example = "0000")
	@Size(min = 1, max = 4, message="건물ID는 4자리입니다")
    private String bldId;//건물ID

	@ApiModelProperty(position = 3 , required = false, value="층ID", example = "3")
	private Integer locId;//층정보
	@ApiModelProperty(position = 3 , required = false, value="층정보", example = "3F")
	private String locFloor;//	층정보
	
	@ApiModelProperty(position = 5 , required = false, value="통계시간", example = "13")
    private String sumDateHourminute;//  통계시간    현재시간-24~현재시간

	@ApiModelProperty(position = 5 , required = false, value="통계시간", example = "13")
	private String hourTime;//	통계시간	현재시간-24~현재시간

	//@ApiModelProperty(position = 7 , required = false, value="공기질(CO2) 값", example = "26")
	//private int occupantCnt;//	 	현재통계값(공기질(CO2) 값)
	private List<AirQualityCO2InfoVO>  airQualityCO2List;// 공기질(CO2) 값 목록
	 
	
 
    
}
