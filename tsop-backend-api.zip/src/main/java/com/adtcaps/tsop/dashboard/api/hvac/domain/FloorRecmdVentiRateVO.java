package com.adtcaps.tsop.dashboard.api.hvac.domain;

import javax.validation.constraints.Size;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@ApiModel(value = "층별권장 환기량", description = "건물의 층별 권장 환기량과 운영량(댐퍼개도율)을 비교하여 절감가능,쾌적수준,환기량 부족을 화면에 보여준다.")
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class FloorRecmdVentiRateVO { 
	 
	@ApiModelProperty(position = 1 , required = false, value="건물ID", example = "0000")
	@Size(min = 1, max = 4, message="건물ID는 4자리입니다")
    private String bldId;//건물ID
	 
	@ApiModelProperty(position = 3 , required = false, value="층정보", example = "3F")
	private String locFloor ;//층정보
	
	private String sumDateHourminute ;//년월일시분
    
	
	@ApiModelProperty(position = 5 , required = false, value="권장환기량값", example = "60")
	private Float recmdVentiRate ;//권장환기량값
	
	@ApiModelProperty(position = 7 , required = false, value="외기댐퍼개도율(운영량)", example = "40")
	private Float damperOeningRate ;//외기댐퍼개도율(운영량)

	@ApiModelProperty(position = 9 , required = false, value="환기량분석값", example = "1 : 절감가능  ,2 : 환기량부족,3 : 쾌적수준")
	private String ventiRateAnalysisVal ;//환기량분석값	1 : 절감가능  ,2 : 환기량부족,3 : 쾌적수준

	


    
}
