package com.adtcaps.tsop.dashboard.api.elevator.domain;

import java.util.List;

import lombok.Getter;
import lombok.Setter;

/**
 * 
 * <ul>
 * <li>업무 그룹명 : tsop-backend-api</li>
 * <li>서브 업무명 : com.adtcaps.tsop.dashboard.api.elevator.domain</li>
 * <li>설  명 : ElevatorEventChartResultDto.java</li>
 * <li>작성일 : 2020. 12. 4.</li>
 * <li>작성자 : jeonyb4</li>
 * </ul>
 */
@Getter
@Setter
public class ElevatorEventChartResultDto {
	private List<ElevatorEventResultDto> elevatorList;
	private List<EscalatorEventResultDto> escalatorList;
	private ElevatorDailyReportResultDto dailyReportInfo;

}
