package com.adtcaps.tsop.dashboard.api.inventory.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.adtcaps.tsop.dashboard.api.inventory.domain.DashboardLocationResultDto;
import com.adtcaps.tsop.dashboard.api.inventory.service.InventoryService;
import com.adtcaps.tsop.domain.inventory.OivBuildingDto;
import com.adtcaps.tsop.helper.domain.BasePageDto;
import com.adtcaps.tsop.mapper.inventory.OivBuildingMapper;
import com.adtcaps.tsop.mapper.inventory.OivLocationMapper;
import com.adtcaps.tsop.portal.api.building.domain.BuildingGridRequestDto;

/**
 * 
 * <ul>
 * <li>업무 그룹명 : tsop-backend-api</li>
 * <li>서브 업무명 : com.adtcaps.tsop.dashboard.api.inventory.service.impl</li>
 * <li>설  명 : InventoryServiceImpl.java</li>
 * <li>작성일 : 2020. 12. 4.</li>
 * <li>작성자 : jeonyb4</li>
 * </ul>
 */
@Service
public class InventoryServiceImpl implements InventoryService {
	
	@Autowired
	private OivBuildingMapper oivBuildingMapper;
	
	@Autowired
	private OivLocationMapper oivLocationMapper;
	
	/**
	 * 
	 * listBuilding
	 *
	 * @param reqBuildingGridRequestDto
	 * @return List<OivBuildingDto>
	 * @throws Exception 
	 */
	@Override
	public List<OivBuildingDto> listBuilding(BuildingGridRequestDto reqBuildingGridRequestDto) throws Exception {
		
		List<OivBuildingDto> rsltOivBuildingDtoList = null;
		
		try {
			// 빌딩 목록 조회...
			rsltOivBuildingDtoList = oivBuildingMapper.listOivBuilding(reqBuildingGridRequestDto);
			
		} catch (Exception e) {
			throw e;
		}
		return rsltOivBuildingDtoList;
		
	}
	
	/**
	 * 
	 * listDashboardLocation
	 * 
	 * @param reqBasePageDto
	 * @return List<DashboardLocationResultDto>
	 * @throws Exception 
	 */
	@Override
	public List<DashboardLocationResultDto> listDashboardLocation(BasePageDto reqBasePageDto) throws Exception {
		
		List<DashboardLocationResultDto> dashboardLocationResultDtoList = null;
		try {
			dashboardLocationResultDtoList = oivLocationMapper.listDashboardLocation(reqBasePageDto);
		} catch (Exception e) {
			throw e;
		}
		return dashboardLocationResultDtoList;
	}

}
