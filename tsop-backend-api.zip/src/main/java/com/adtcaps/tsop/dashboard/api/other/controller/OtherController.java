package com.adtcaps.tsop.dashboard.api.other.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.adtcaps.tsop.dashboard.api.other.domain.WeatherForcastResultDto;
import com.adtcaps.tsop.dashboard.api.other.service.OtherService;
import com.adtcaps.tsop.domain.other.OotWeatherForecastExtraShortDto;
import com.adtcaps.tsop.helper.constant.Const;
import com.adtcaps.tsop.helper.domain.ResultDto;

/**
 * 
 * <ul>
 * <li>업무 그룹명 : tsop-backend-api</li>
 * <li>서브 업무명 : com.adtcaps.tsop.dashboard.api.other.controller</li>
 * <li>설  명 : OtherController.java</li>
 * <li>작성일 : 2020. 12. 4.</li>
 * <li>작성자 : jeonyb4</li>
 * </ul>
 */
@RestController
@RequestMapping("/api/dashboard/others")
public class OtherController {
	
	private final String ERR_MSG_READ_FAIL = "조회에 실패하였습니다.";
	
	@Autowired
	private OtherService otherService;
	
	/**
	 * 
	 * readBuildingWeatherForcast
	 *
	 * @param bldId
	 * @return ResponseEntity
	 */
	@SuppressWarnings("rawtypes")
	@GetMapping(value="/buildings/{bldId}/weather-forecast", produces="application/json; charset=UTF-8")
	public ResponseEntity readBuildingWeatherForcast(@PathVariable("bldId") String bldId) throws Exception {
		
		ResponseEntity<ResultDto> resEntity = null;
		String returnString = "";
		
		OotWeatherForecastExtraShortDto reqOotWeatherForecastExtraShortDto = new OotWeatherForecastExtraShortDto();
		reqOotWeatherForecastExtraShortDto.setBldId(bldId);
		
		// 빌딩별 날씨정보 조회
		WeatherForcastResultDto weatherForcastResultDto = otherService.readBuildingWeatherForcast(reqOotWeatherForecastExtraShortDto);
		if (weatherForcastResultDto == null) {
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_READ_FAIL, weatherForcastResultDto));
        } else {
        	returnString = Const.Common.RESULT_CODE.SUCCESS;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, "", weatherForcastResultDto));
		}
		
		return resEntity;
	}

}
