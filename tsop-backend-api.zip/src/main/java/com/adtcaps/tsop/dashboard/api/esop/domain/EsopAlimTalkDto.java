package com.adtcaps.tsop.dashboard.api.esop.domain;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class EsopAlimTalkDto {
	private String bldId;
	private String esopStatus;
	private String esopDatetime;
	private String locFloorName;
	private String training;
	private String responseTeamName;
	private String esopStepName;
	private String fireGrade;
	private String esopMsg;
}
