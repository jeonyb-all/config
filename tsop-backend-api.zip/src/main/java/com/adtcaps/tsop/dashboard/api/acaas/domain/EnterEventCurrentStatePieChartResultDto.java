package com.adtcaps.tsop.dashboard.api.acaas.domain;

import lombok.Getter;
import lombok.Setter;

/**
 * 
 * <ul>
 * <li>업무 그룹명 : tsop-backend-api</li>
 * <li>서브 업무명 : com.adtcaps.tsop.dashboard.api.acaas.domain</li>
 * <li>설  명 : EnterEventCurrentStatePieChartResultDto.java</li>
 * <li>작성일 : 2020. 12. 18.</li>
 * <li>작성자 : jeonyb4</li>
 * </ul>
 */
@Getter
@Setter
public class EnterEventCurrentStatePieChartResultDto {
	private String bldId;
	private String bldName;
	private String sumDateHourminute;
	private Integer enterEmployeeCount;
	private Integer enterVisitorCount;
	private Integer enterBpCount;
	private Integer enterFailCount;
	private Integer totalEmployeeCount;

}
