package com.adtcaps.tsop.dashboard.api.fm.domain;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class EquipObjWeekVO {    
    private String bldId;
    private String objectId;
    private String facilityOrgName;
    private String superObjectId;
    private String facilityName;
    private String locFloor;    
    private String queryDate;
    private String dateFormat;
    private String dayWeek;
    private String dayWeekName;
    private Float chilledwaterSupplyTemprVal;
    private Float chilledwaterReturnTemprVal;
    private Float chilledwaterGapTemprVal;
    private Float cowSupplyTemprVal;
    private Float cowReturnTemprVal;
    private Float cowGapTemprVal;
    private Float chrCopVal;
}
