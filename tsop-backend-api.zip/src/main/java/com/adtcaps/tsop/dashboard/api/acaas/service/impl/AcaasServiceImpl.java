package com.adtcaps.tsop.dashboard.api.acaas.service.impl;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.CollectionUtils;

import com.adtcaps.tsop.dashboard.api.acaas.domain.EnterEventAlarmCurrentStateQueryResultDto;
import com.adtcaps.tsop.dashboard.api.acaas.domain.EnterEventCurrentStatePieChartResultDto;
import com.adtcaps.tsop.dashboard.api.acaas.service.AcaasService;
import com.adtcaps.tsop.domain.acaas.OacEnterEventDayStatDto;
import com.adtcaps.tsop.domain.acaas.OacEnterEventDto;
import com.adtcaps.tsop.helper.constant.Const;
import com.adtcaps.tsop.helper.domain.LineChartDataDto;
import com.adtcaps.tsop.helper.domain.LineChartResultDto;
import com.adtcaps.tsop.helper.util.CommonObjectUtil;
import com.adtcaps.tsop.mapper.acaas.OacEnterEventDayStatMapper;
import com.adtcaps.tsop.mapper.acaas.OacEnterEventMapper;


/**
 * 
 * <ul>
 * <li>업무 그룹명 : tsop-backend-api</li>
 * <li>서브 업무명 : com.adtcaps.tsop.dashboard.api.acaas.service.impl</li>
 * <li>설  명 : AcaasServiceImpl.java</li>
 * <li>작성일 : 2020. 12. 4.</li>
 * <li>작성자 : jeonyb4</li>
 * </ul>
 */
@Transactional
@Service
public class AcaasServiceImpl implements AcaasService {
	
	@Autowired
	private OacEnterEventMapper oacEnterEventMapper;
	
	@Autowired
	private OacEnterEventDayStatMapper oacEnterEventDayStatMapper;
	
	/**
	 * 
	 * readEnterEventCurrentStatePieChart
	 *
	 * @param reqOacEnterEventDto
	 * @return EnterEventCurrentStatePieChartResultDto
	 * @throws Exception 
	 */
	@Override
	public EnterEventCurrentStatePieChartResultDto readEnterEventCurrentStatePieChart(OacEnterEventDto reqOacEnterEventDto) throws Exception {
		
		EnterEventCurrentStatePieChartResultDto enterEventCurrentStatePieChartResultDto = null;
		
		try {
			enterEventCurrentStatePieChartResultDto = oacEnterEventMapper.readEnterEventCurrentStatePieChart(reqOacEnterEventDto);
		} catch (Exception e) {
			throw e;
		}
		
		return enterEventCurrentStatePieChartResultDto;
	}
//	@Override
//	public EnterEventCurrentStatePieChartResultDto listEnterEventCurrentStatePieChart(OacEnterEventDto reqOacEnterEventDto) throws Exception {
//		
//		EnterEventCurrentStatePieChartResultDto enterEventCurrentStatePieChartResultDto = null;
//		
//		try {
//			List<EnterEventCurrentStateQueryResultDto> enterEventCurrentStateQueryResultDtoList = oacEnterEventMapper.listEnterEventCurrentStatePieChart(reqOacEnterEventDto);
//			if (!CollectionUtils.isEmpty(enterEventCurrentStateQueryResultDtoList)) {
//				String bldName = "";
//				int totalEmployeeCount = 0;
//				int enterEmployeeCount = 0;
//				int enterOtherBldEmpCount = 0;
//				int enterVisitorCount = 0;
//				for (EnterEventCurrentStateQueryResultDto enterEventCurrentStateQueryResultDto : enterEventCurrentStateQueryResultDtoList) {
//					bldName = StringUtils.defaultString(enterEventCurrentStateQueryResultDto.getBldName());
//					String enterUserType = StringUtils.defaultString(enterEventCurrentStateQueryResultDto.getEnterUserType());
//					String bldGubun = StringUtils.defaultString(enterEventCurrentStateQueryResultDto.getBldGubun());
//					int enterCount = CommonObjectUtil.defaultNumber(enterEventCurrentStateQueryResultDto.getEnterCount());
//					if (Const.Definition.OAC_PIE_CHART_ENTER_USER_TYPE.VST.equals(enterUserType)) {
//						enterVisitorCount = enterCount;
//					} else {
//						if (Const.Definition.OAC_PIE_CHART_BLD_GUBUN.BLD.equals(bldGubun)) {
//							enterEmployeeCount = enterCount;
//						} else if (Const.Definition.OAC_PIE_CHART_BLD_GUBUN.OTB.equals(bldGubun)) {
//							enterOtherBldEmpCount = enterCount;
//						} else if (Const.Definition.OAC_PIE_CHART_BLD_GUBUN.TOT.equals(bldGubun)) {
//							totalEmployeeCount = enterCount;
//						}
//					}
//				}
//				enterEventCurrentStatePieChartResultDto = new EnterEventCurrentStatePieChartResultDto();
//				enterEventCurrentStatePieChartResultDto.setBldName(bldName);
//				enterEventCurrentStatePieChartResultDto.setTotalEmployeeCount(totalEmployeeCount);
//				enterEventCurrentStatePieChartResultDto.setEnterEmployeeCount(enterEmployeeCount);
//				enterEventCurrentStatePieChartResultDto.setEnterOtherBldEmpCount(enterOtherBldEmpCount);
//				enterEventCurrentStatePieChartResultDto.setEnterVisitorCount(enterVisitorCount);
//			}
//			
//		} catch (Exception e) {
//			throw e;
//		}
//		return enterEventCurrentStatePieChartResultDto;
//	}
	
	/**
	 * 
	 * listEnterEventAlarmCurrentStateChart
	 *
	 * @param reqOacEnterEventDayStatDto
	 * @return LineChartResultDto
	 * @throws Exception 
	 */
	@Override
	public LineChartResultDto listEnterEventAlarmCurrentStateChart(OacEnterEventDayStatDto reqOacEnterEventDayStatDto) throws Exception {
		
		LineChartResultDto lineChartResultDto = null;
		
		try {
			List<EnterEventAlarmCurrentStateQueryResultDto> enterEventAlarmCurrentStateQueryResultDtoList = oacEnterEventDayStatMapper.listEnterEventAlarmCurrentStateChart(reqOacEnterEventDayStatDto);
			if (!CollectionUtils.isEmpty(enterEventAlarmCurrentStateQueryResultDtoList)) {
				
				List<String> categories = new ArrayList<String>();
				List<LineChartDataDto> lineDatas = new ArrayList<LineChartDataDto>();
				List<Integer> barDatas = new ArrayList<Integer>();
				
				List<Integer> employees = new ArrayList<Integer>();
				List<Integer> bps = new ArrayList<Integer>();
				List<Integer> visits = new ArrayList<Integer>();
				
				for (EnterEventAlarmCurrentStateQueryResultDto enterEventAlarmCurrentStateQueryResultDto : enterEventAlarmCurrentStateQueryResultDtoList) {
					String baseDatetime = enterEventAlarmCurrentStateQueryResultDto.getBaseDatetime();
					int employeeCount = CommonObjectUtil.defaultNumber(enterEventAlarmCurrentStateQueryResultDto.getEmployeeCount());
					int visitorCount = CommonObjectUtil.defaultNumber(enterEventAlarmCurrentStateQueryResultDto.getVisitorCount());
					int bpCount = CommonObjectUtil.defaultNumber(enterEventAlarmCurrentStateQueryResultDto.getBpCount());
					int alarmCount = CommonObjectUtil.defaultNumber(enterEventAlarmCurrentStateQueryResultDto.getAlarmCount());
					
					categories.add(baseDatetime);
					employees.add(employeeCount);
					bps.add(bpCount);
					visits.add(visitorCount);
					barDatas.add(alarmCount);
				}
				
				LineChartDataDto lineChartDataDto = new LineChartDataDto();
				lineChartDataDto.setName(Const.Definition.LINE_CHART_TITLE.EMP);
				lineChartDataDto.setData(employees);
				lineDatas.add(lineChartDataDto);
				
				lineChartDataDto = new LineChartDataDto();
				lineChartDataDto.setName(Const.Definition.LINE_CHART_TITLE.BP);
				lineChartDataDto.setData(bps);
				lineDatas.add(lineChartDataDto);
				
				lineChartDataDto = new LineChartDataDto();
				lineChartDataDto.setName(Const.Definition.LINE_CHART_TITLE.VST);
				lineChartDataDto.setData(visits);
				lineDatas.add(lineChartDataDto);
				
				lineChartResultDto = new LineChartResultDto();
				lineChartResultDto.setCategories(categories);
				lineChartResultDto.setLineDatas(lineDatas);
				lineChartResultDto.setBarDatas(barDatas);
			}
			
		} catch (Exception e) {
			throw e;
		}
		return lineChartResultDto;
	}
	

}
