package com.adtcaps.tsop.dashboard.api.parking.service.impl;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.CollectionUtils;

import com.adtcaps.tsop.dashboard.api.parking.domain.ParkingInoutEventChartResultDto;
import com.adtcaps.tsop.dashboard.api.parking.domain.ParkingInoutEventCurrentStateQueryResultDto;
import com.adtcaps.tsop.dashboard.api.parking.domain.ParkingReportResultDto;
import com.adtcaps.tsop.dashboard.api.parking.service.ParkingService;
import com.adtcaps.tsop.domain.parking.OpaParkingInoutEventDto;
import com.adtcaps.tsop.helper.constant.Const;
import com.adtcaps.tsop.helper.domain.LineChartDataDto;
import com.adtcaps.tsop.helper.domain.LineChartResultDto;
import com.adtcaps.tsop.helper.util.CommonObjectUtil;
import com.adtcaps.tsop.mapper.parking.OpaParkingInoutEventMapper;

/**
 * 
 * <ul>
 * <li>업무 그룹명 : tsop-backend-api</li>
 * <li>서브 업무명 : com.adtcaps.tsop.dashboard.api.parking.service.impl</li>
 * <li>설  명 : ParkingServiceImpl.java</li>
 * <li>작성일 : 2020. 12. 4.</li>
 * <li>작성자 : jeonyb4</li>
 * </ul>
 */
@Transactional
@Service
public class ParkingServiceImpl implements ParkingService {
	
	@Autowired
	private OpaParkingInoutEventMapper opaParkingInoutEventMapper;
	
	/**
	 * 
	 * listParkingInoutEventCurrentStateLineChart
	 *
	 * @param reqOpaParkingInoutEventDto
	 * @return ParkingInoutEventChartResultDto
	 * @throws Exception 
	 */
	@Override
	public ParkingInoutEventChartResultDto listParkingInoutEventCurrentStateLineChart(OpaParkingInoutEventDto reqOpaParkingInoutEventDto) throws Exception {
		
		ParkingInoutEventChartResultDto parkingInoutEventChartResultDto = null;
		
		try {
			List<ParkingInoutEventCurrentStateQueryResultDto> parkingInoutEventCurrentStateQueryResultDtoList = opaParkingInoutEventMapper.listParkingInoutEventCurrentStateLineChart(reqOpaParkingInoutEventDto);
			if (!CollectionUtils.isEmpty(parkingInoutEventCurrentStateQueryResultDtoList)) {
				
				List<String> categories = new ArrayList<String>();
				List<LineChartDataDto> datas = new ArrayList<LineChartDataDto>();
				
				List<Integer> ins = new ArrayList<Integer>();
				List<Integer> outs = new ArrayList<Integer>();
				
				for (ParkingInoutEventCurrentStateQueryResultDto parkingInoutEventCurrentStateQueryResultDto : parkingInoutEventCurrentStateQueryResultDtoList) {
					String baseDatetime = parkingInoutEventCurrentStateQueryResultDto.getBaseDatetime();
					String baseHour = StringUtils.substring(baseDatetime, 8, 10);
					int invehicleCount = CommonObjectUtil.defaultNumber(parkingInoutEventCurrentStateQueryResultDto.getInvehicleCount());
					int outvehicleCount = CommonObjectUtil.defaultNumber(parkingInoutEventCurrentStateQueryResultDto.getOutvehicleCount());
					
					categories.add(baseHour);
					ins.add(invehicleCount);
					outs.add(outvehicleCount);
				}
				
				LineChartDataDto lineChartDataDto = new LineChartDataDto();
				lineChartDataDto.setName(Const.Definition.LINE_CHART_TITLE.IN);
				lineChartDataDto.setData(ins);
				datas.add(lineChartDataDto);
				
				lineChartDataDto = new LineChartDataDto();
				lineChartDataDto.setName(Const.Definition.LINE_CHART_TITLE.OUT);
				lineChartDataDto.setData(outs);
				datas.add(lineChartDataDto);
				
				LineChartResultDto lineChartResultDto = new LineChartResultDto();
				lineChartResultDto.setCategories(categories);
				lineChartResultDto.setLineDatas(datas);
				
				parkingInoutEventChartResultDto = new ParkingInoutEventChartResultDto();
				parkingInoutEventChartResultDto.setChart(lineChartResultDto);
			}
			
			ParkingReportResultDto parkingReportResultDto = opaParkingInoutEventMapper.readParkingReport(reqOpaParkingInoutEventDto);
			if (parkingReportResultDto != null) {
				int weekAvgPrkMinuteUnitTm = CommonObjectUtil.defaultNumber(parkingReportResultDto.getWeekAvgPrkMinuteUnitTm());
				if (weekAvgPrkMinuteUnitTm == 0) {
					parkingReportResultDto.setWeekAvgPrkHour(0);
					parkingReportResultDto.setWeekAvgPrkMinute(0);
				} else {
					int weekAvgPrkHour = weekAvgPrkMinuteUnitTm / 60;
					int weekAvgPrkMinute = weekAvgPrkMinuteUnitTm % 60;
					parkingReportResultDto.setWeekAvgPrkHour(weekAvgPrkHour);
					parkingReportResultDto.setWeekAvgPrkMinute(weekAvgPrkMinute);
				}
			}
			
			if (parkingInoutEventChartResultDto == null) {
				parkingInoutEventChartResultDto = new ParkingInoutEventChartResultDto();
			}
			parkingInoutEventChartResultDto.setParkingReportInfo(parkingReportResultDto);
			
			
		} catch (Exception e) {
			throw e;
		}
		return parkingInoutEventChartResultDto;
	}
	
}
