package com.adtcaps.tsop.dashboard.api.fm.domain;

import java.util.List;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class RoomCondition {
	private String bldId;
	private String bldName;
	private List<Float> periodHour;
	private List<Float> currentVal;
}
