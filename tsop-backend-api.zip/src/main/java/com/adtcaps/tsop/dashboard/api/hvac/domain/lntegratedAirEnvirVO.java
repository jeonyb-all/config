package com.adtcaps.tsop.dashboard.api.hvac.domain;

import java.util.Date;

import javax.validation.constraints.Size;

import com.fasterxml.jackson.annotation.JsonFormat;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@ApiModel(value = "대기질 의 실제값  외기엔탈피,미세먼지(PM10),초미세먼지(PM2.5)", description = "대기질기의 실제값  외기엔탈피,미세먼지(PM10),초미세먼지(PM2.5)입니다.")
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class lntegratedAirEnvirVO {

 
	


	@ApiModelProperty(position = 1 , required = false, value="	", example = "0000")
	@Size(min = 1, max = 4, message="건물ID는 4자리입니다")
	private	String	bldId	;//	건물ID
	
 
	@ApiModelProperty(position = 5 , required = false, value="집계일자시분", example = "202110280745") 
	private	String	sumDateHourminute	;//	집계일자시분

    private String  simpleHourminute   ;// 집계시분 HH시mm분
    private String  simpleHour         ;// 집계시분 HH시 
    
	
	@ApiModelProperty(position = 7 , required = false, value="최종변경일시", example = "2021-10-28 07:57:05")
	@JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "Asia/Seoul")
	private	Date	auditDatetime	;//	최종변경일시

	@ApiModelProperty(position = 9 , required = false, value="측정소명", example = "종로구") 
	private	String	measureStationName	;//	관측소명
	
	@ApiModelProperty(position = 11 , required = false, value="실외온도값", example = "26") 
	private	Float	outdoorTemprVal	;//	실외온도값
	
	@ApiModelProperty(position = 13 , required = false, value="실외습도값", example = "79") 
	private	Float	outdoorHumidityVal	;//	실외습도값

	@ApiModelProperty(position = 15 , required = false, value="실외엔탈피값", example = "68.93") 
	private	String	outdoorEnthalpyVal	;//	실외엔탈피값

	@ApiModelProperty(position = 21 , required = false, value="실외엔탈피명", example = " ")
	private String outdoorEnthalpyValName   ;//실외엔탈피명

	@ApiModelProperty(position = 17 , required = false, value="미세먼지농도값", example = "82") 
	private	String	fineDustVal	;//	미세먼지값
	

 	@ApiModelProperty(position = 23 , required = false, value="미세먼지농도명", example = "나쁨") 
    private String fineDustValName     ;//미세먼지농도명(나쁨)

 	@ApiModelProperty(position = 19 , required = false, value="초미세먼지농도값", example = "13") 
	private	String	ultraFineDustVal	;//	초미세먼지값


	@ApiModelProperty(position = 25 , required = false, value="초미세먼지농도명", example = "좋음") 
    private String ultraFineDustValName;//초미세먼지농도명(좋음)
    
	//Bar 그래프 값의  왼쪽부터 %
    private Integer outdoorEnthalpyValPer;//실외엔탈피값을 Bar의  %로 
    private Integer fineDustValPer;// 미세먼지 값을 Bar의  %로 
    private Integer ultraFineDustValPer;//초미세먼지 값을 Bar의  %로   
    private Integer bldInEnthalpyBaseValPer;//빌딩별 실내엔탈피기준값을  Bar의  %로 
    
    
 
}
