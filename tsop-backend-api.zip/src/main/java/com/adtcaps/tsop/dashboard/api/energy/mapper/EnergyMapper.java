package com.adtcaps.tsop.dashboard.api.energy.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import com.adtcaps.tsop.dashboard.api.energy.domain.BldTypeVO;
import com.adtcaps.tsop.dashboard.api.energy.domain.BuildingPowerTrendVO;
import com.adtcaps.tsop.dashboard.api.energy.domain.BuildingPowerVO;
import com.adtcaps.tsop.dashboard.api.energy.domain.BuildingVO;
import com.adtcaps.tsop.dashboard.api.energy.domain.CommonCodeDetailVO;
import com.adtcaps.tsop.dashboard.api.energy.domain.CustomerVO;
import com.adtcaps.tsop.dashboard.api.energy.domain.EnergyPowerQnttyVO;
import com.adtcaps.tsop.dashboard.api.energy.domain.PowerConsumptionTrendVO;
import com.adtcaps.tsop.dashboard.api.energy.domain.PowerKwhM2StatVO;
import com.adtcaps.tsop.dashboard.api.energy.domain.WeekendPowerStatVO;

@Mapper
public interface EnergyMapper {

	public List<BuildingVO> getBuildingList();
	public List<EnergyPowerQnttyVO> getPowerBaseList(String bldTypeCd);
	public List<PowerKwhM2StatVO> getPowerDensityList();
	public List<WeekendPowerStatVO> getWeekendPowerStat();
	public List<PowerConsumptionTrendVO> getPowerConsumptionTrend(String bldId);
	public List<CommonCodeDetailVO> getCodeDetail(String commonCd);
	public int countBuilding(String bldTypeCd);
	public List<PowerConsumptionTrendVO> getPowerConsumptionTrendChart(String bldId);
	public BuildingVO getBuildingInfo(String bldId);
	public List<BuildingPowerTrendVO> getBuildingPowerDayWeek(@Param("bldId") String bldId, @Param("bldType") String bldType);
	public List<BuildingPowerTrendVO> getBuildingPowerMonDayWeek(@Param("bldType") String bldType);
	public List<BuildingPowerTrendVO> getBuildingPowerHour(@Param("bldId") String bldId);
	public List<BldTypeVO> getBldTypeList();
	public List<BuildingPowerVO> getBuildingPowerUsage(@Param("bldType") String bldType, @Param("sort") String sort);
	public List<CustomerVO> getCustomerList(@Param("bldType") String bldType);
}
