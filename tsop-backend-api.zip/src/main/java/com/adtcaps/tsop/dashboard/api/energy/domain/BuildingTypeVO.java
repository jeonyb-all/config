package com.adtcaps.tsop.dashboard.api.energy.domain;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class BuildingTypeVO extends CommonCodeDetailVO {

	public BuildingTypeVO() {
	}

	public BuildingTypeVO(CommonCodeDetailVO codeDetailVO) {
		this.commonCd = codeDetailVO.commonCd;
		this.commonCdVal = codeDetailVO.commonCdVal;
		this.commonCdValName = codeDetailVO.commonCdValName;
		this.sortSeq = codeDetailVO.sortSeq;
	}

	public BuildingTypeVO(CommonCodeDetailVO codeDetailVO, int bldCount) {
		this.commonCd = codeDetailVO.commonCd;
		this.commonCdVal = codeDetailVO.commonCdVal;
		this.commonCdValName = codeDetailVO.commonCdValName;
		this.sortSeq = codeDetailVO.sortSeq;

		this.bldCount = bldCount;
	}

	private int bldCount;
}
