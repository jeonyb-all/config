package com.adtcaps.tsop.dashboard.api.fm.domain;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class BuildingEquipHourVO {
	private String bldId;
	private String bldName;			   //건물명
	private String objectId;           //object 아이디
	private String facilityName;       //설비 장비 포인트 명
	private String locFloor;           //층
	private String stateDate;          //통계시간
	private Float hour;                //통계시간
	private Float curVal;              //현재통계값

}
