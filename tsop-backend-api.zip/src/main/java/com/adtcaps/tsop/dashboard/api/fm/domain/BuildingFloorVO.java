package com.adtcaps.tsop.dashboard.api.fm.domain;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class BuildingFloorVO {
	private String bldId;
	private String bldName;			                   //건물명
	private String locFloor;                           //층
	private Float rtmAvgFloorH6Val;
	private Float rtmAvgFloorH12Val;
	private Float rtmAvgFloorH18Val;
}
