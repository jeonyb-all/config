package com.adtcaps.tsop.dashboard.api.fm.domain;

import java.io.Serializable;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@NoArgsConstructor
@Getter
@Setter
@ToString
public class FmVO implements Serializable{
	private String bldId;
	private String bldName;
	private String bldTypeCd;
	private Float bldTotalfloorareaSize;
	private String auditDateTime;

	private String equipmentCd;
	private String equipmentCdName;
	private Integer yesterdayEqptStartHour;
	private Integer yesterdayEqptEndHour;
	private Integer lastweekEqptStartHour;
	private Integer lastweekEqptEndHour;
	private Integer eqptTotalNum;
	private Integer eqptWorkNum;
	private Float coolWaterTemperatureIn;
	private Float coolWaterTemperatureOut;
	private Float coolantTemperatureIn;
	private Float coolantTemperatureOut;
	private Float outerDamperOpenRate;
	private String createTime;

	private Float periodHour;
	private Float currentVal;

}
