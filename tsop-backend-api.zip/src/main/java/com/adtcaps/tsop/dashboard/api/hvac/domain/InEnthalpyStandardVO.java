package com.adtcaps.tsop.dashboard.api.hvac.domain;

import javax.validation.constraints.Size;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@ApiModel(value = "층별로 실내엔탈피 기준또는 층별로 실내엔탈피", description = "층별로 실내엔탈피 기준(실내온도,실내습도,실내엔탈피)을 조회한다.")

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class InEnthalpyStandardVO {

	@ApiModelProperty(position = 1 , required = false, value="건물ID", example = "0000")
	@Size(min = 1, max = 4, message="건물ID는 4자리입니다") 
	private String bldId	;//	건물ID
	
	@ApiModelProperty(position = 3 , required = false, value="층정보", example = "1F")
	private String locFloor	;//	층정보
	
	@ApiModelProperty(position = 5 , required = false, value="환기온도값", example = "26") 
	private Float inTemprVal	;//	실내온도값(환기온도 값)
	
	@ApiModelProperty(position = 7 , required = false, value="환기습도값", example = "79") 
	private Float inHumidityVal	;//	실내습도(환기습도 값)
	
	@ApiModelProperty(position = 9 , required = false, value="실내엔탈피값", example = "68.93") 
	private Float inEnthalpyVal	;//	실내엔탈피 값


	@ApiModelProperty(position = 3 ,required = false, value="DB기준값여부-빌딩별 실내엔탈피기준 목록이 구성_관리기준값상세 에서 가져온 경우 Y,일반기준값인 경우 N", example = "Y")
    private String dbStandardYn;     //DB기준값여부-층별 실내엔탈피기준 목록이 구성_관리기준값상세 에서 가져온 경우 Y,일반기준값인 경우 N
}
