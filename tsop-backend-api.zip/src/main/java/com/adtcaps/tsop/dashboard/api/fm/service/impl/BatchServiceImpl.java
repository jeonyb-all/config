package com.adtcaps.tsop.dashboard.api.fm.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.adtcaps.tsop.dashboard.api.fm.mapper.BatchMapper;
import com.adtcaps.tsop.dashboard.api.fm.service.BatchService;

import lombok.extern.slf4j.Slf4j;
@Slf4j
@Transactional
@Service
public class BatchServiceImpl implements BatchService{
	@Autowired 
	private BatchMapper batchMapper;
	@Override
	public void fmOperationStatusBatch() {
		try {
			log.debug("fmOperationStatusBatch start");
			batchMapper.deleteFmOperationStatusBatch();
			batchMapper.insertFmOperationStatusBatch();
		} catch (Exception e) {
			log.error(e.getMessage());
		}
	}
	@Override
	public void powerUnitBatch() {
		try {
			log.debug("powerUnitBatch start");
			batchMapper.deletePowerUnitBatch();
			batchMapper.insertPowerUnitBatch();
		} catch (Exception e) {
			log.error(e.getMessage());
		}
	}
	@Override
	public void fmBatch() {
		try {
			log.debug("fmOperationStatusBatch start");
			batchMapper.deleteFmOperationStatusBatch();
			batchMapper.insertFmOperationStatusBatch();
			
			log.debug("powerUnitBatch start");
			batchMapper.deletePowerUnitBatch();
			batchMapper.insertPowerUnitBatch();
		} catch (Exception e) {
			log.error(e.getMessage());
		}
		
	}
	@Override
	public void fmEnvironmentBatch() {
		try {
			log.debug("fmEnvironmentRtm start");
//			batchMapper.deleteEnvBy0004();
//			batchMapper.fmEnvironmentBatch("RTM");
//			batchMapper.fmEnvironmentBatch("HMD");
			
//			batchMapper.fmEnvironmentRtmBatch();
//			batchMapper.fmEnvironmentHmdBatch();
			String[] bldArr = {"0002","0003","0004"};
			for(String bldId : bldArr) {
				batchMapper.fmEnvironmentRtmHmdBatch(bldId);
			}
		} catch (Exception e) {
			log.error(e.getMessage());
		}
		
	}
	@Override
	public void fmCollectWorkingTime() {
		try {
			String[] bldArr = {"0002","0003","0004"};
			String[] eqptArr = {"AHU","CHR","BLR"};
			for(String bldId : bldArr) {
				for(String equipmentCd : eqptArr) {
					batchMapper.insertMediationData(bldId, equipmentCd);
				}
				
				batchMapper.insertMinMediationData(bldId, "CLT");
			}
			
		}catch (Exception e) {
			log.error(e.getMessage());
		}
		
	}
	@Override
	public void fmBuildingPointStat() {
		try {
			String[] bldArr = {"0002","0003","0004"};
			String[] eqptArr = {"AHU","CHR","BLR"};
			for(String bldId : bldArr) {
				for(String equipmentCd : eqptArr) {
					//기동 : 0 , 정지 : 1
					batchMapper.fmBuildingPointStat(bldId, equipmentCd);
				}
				//냉각탑은 기동 : 1 , 정지 :0
				batchMapper.fmBuildingPointStatClt(bldId);
			}
			
		}catch (Exception e) {
			log.error(e.getMessage());
		}
		
	}

}
