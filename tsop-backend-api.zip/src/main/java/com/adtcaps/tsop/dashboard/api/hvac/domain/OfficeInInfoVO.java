package com.adtcaps.tsop.dashboard.api.hvac.domain;

import javax.validation.constraints.Size;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@ApiModel(value = "건물내 정보", description = "건물내 정보(건물내 총인원수)를 조회한다.")
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class OfficeInInfoVO { 
	 
	@ApiModelProperty(position = 1 , required = false, value="건물ID", example = "0000")
	@Size(min = 1, max = 4, message="건물ID는 4자리입니다")
    private String bldId;//건물ID
	
	@ApiModelProperty(position = 3 , required = false, value="건물내인원수", example = "368")
	private int officeTotalCnt;//건물내인원수


    private Integer  airQualityCo2BaseVal ;// 공기질CO2 기준값 900이상이면 빨간색
    private String   airQualityCo2Yn ;// 공기질CO2 연동 여부 
    

    //private String  currDateHourminute   ;//실시간    : 년월일시분
    //private String  currHourminute   ;// 실시간    : HH시mm분
    private String  sumDateHourminute   ;// 집계일자시분
    private String  simpleHourminute   ;// 집계시분 HH시mm분
        
         
    
}
