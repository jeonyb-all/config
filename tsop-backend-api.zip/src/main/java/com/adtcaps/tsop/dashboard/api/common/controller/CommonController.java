package com.adtcaps.tsop.dashboard.api.common.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.util.CollectionUtils;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.adtcaps.tsop.authentication.domain.JwtAuthResultDto;
import com.adtcaps.tsop.dashboard.api.common.domain.DashboardCardRequestDto;
import com.adtcaps.tsop.dashboard.api.common.domain.DashboardCardResultDto;
import com.adtcaps.tsop.dashboard.api.common.domain.DashboardCardTabResultDto;
import com.adtcaps.tsop.dashboard.api.common.domain.GuideScheduleRequestDto;
import com.adtcaps.tsop.dashboard.api.common.domain.GuideScheduleResultDto;
import com.adtcaps.tsop.dashboard.api.common.service.CommonService;
import com.adtcaps.tsop.domain.common.OcoGuideScheduleDto;
import com.adtcaps.tsop.domain.common.OcoUserDashboardCardDto;
import com.adtcaps.tsop.domain.inventory.OivBuildingDto;
import com.adtcaps.tsop.helper.constant.Const;
import com.adtcaps.tsop.helper.domain.ResultDto;
import com.adtcaps.tsop.helper.util.CommonObjectUtil;
import com.adtcaps.tsop.portal.api.board.domain.BulletinboardGridRequestDto;
import com.adtcaps.tsop.portal.api.board.domain.BulletinboardGridResultDto;

import lombok.extern.slf4j.Slf4j;

/**
 * 
 * <ul>
 * <li>업무 그룹명 : tsop-backend-api</li>
 * <li>서브 업무명 : com.adtcaps.tsop.dashboard.api.common.controller</li>
 * <li>설  명 : CommonController.java</li>
 * <li>작성일 : 2020. 12. 4.</li>
 * <li>작성자 : jeonyb4</li>
 * </ul>
 */
@Slf4j
@RestController
@RequestMapping("/api/dashboard/commons")
public class CommonController {
	
	private final String ERR_MSG_NULL_LOGIN_USER_ID = "로그인 사용자ID가 없습니다.";
	private final String ERR_MSG_NULL_LOGIN_ROLE_CL_CD = "로그인 사용자의 역할구분이 없습니다.";
	private final String ERR_MSG_NULL_BLD_ID = "빌딩ID가 없습니다.";
	private final String ERR_MSG_NULL_SELECT_YYYYMM = "selectYyyymm이 없습니다.";
	private final String ERR_MSG_NULL_SELECT_WEEK_NUM = "selectWeekNum이 없습니다.";
	private final String ERR_MSG_NULL_CHECK_YN = "checkYn이 없습니다.";
	private final String ERR_MSG_NULL_SERVICE_CARD_TAB_NAME = "서비스카드탭명이 없습니다.";
	private final String ERR_MSG_NULL_SERVICE_CARD_INDEX_VAL = "서비스카드인덱스값이 없습니다.";
	
	private final String ERR_MSG_NULL_READ_RESULT = "조회 결과가 없습니다.";
	private final String ERR_MSG_UPDATE_FAIL = "수정에 실패하였습니다.";
	
	@Autowired
	private CommonService commonService;
	
	/**
	 * 
	 * listDashboardCard
	 *
	 * @param reqOivBuildingDto
	 * @return ResponseEntity
	 */
	@SuppressWarnings("rawtypes")
	@GetMapping(value="/dashboard-cards", produces="application/json; charset=UTF-8")
	public ResponseEntity listDashboardCard(@AuthenticationPrincipal JwtAuthResultDto authResultDto, 
			DashboardCardRequestDto dashboardCardRequestDto) throws Exception {
		
		ResponseEntity<ResultDto> resEntity = null;
		String returnString = "";
		
		String loginUserId = StringUtils.defaultString(authResultDto.getUserId());
		if ("".equals(loginUserId)) {
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_LOGIN_USER_ID));
			return resEntity;
		}
		String userRoleClCd = StringUtils.defaultString(authResultDto.getRoleClCd());
		if ("".equals(userRoleClCd)) {
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_LOGIN_ROLE_CL_CD));
			return resEntity;
		}
		String loginUserName = StringUtils.defaultString(authResultDto.getUsername());
		
//		String loginUserId = "jhpark"; // 이후 세션에서 얻어올 값...
//		String userRoleClCd = "S40"; // 이후 세션에서 얻어올 값...
//		String loginUserName = "박준하"; // 이후 세션에서 얻어올 값...
//		String loginUserId = "jeonyb4"; // 이후 세션에서 얻어올 값...
//		String userRoleClCd = "S00"; // 이후 세션에서 얻어올 값...
//		String loginUserName = "전용배"; // 이후 세션에서 얻어올 값...
		
		String bldId = StringUtils.defaultString(dashboardCardRequestDto.getBldId());
		if ("".equals(bldId)) {
			log.error(">>>>>> bldId ERROR:{}", ERR_MSG_NULL_BLD_ID);
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_BLD_ID));
			return resEntity;
		}
		
		dashboardCardRequestDto.setUserId(loginUserId);
		dashboardCardRequestDto.setUserName(loginUserName);
		dashboardCardRequestDto.setRoleClCd(userRoleClCd);
		
		// 대시보드카드 목록조회...
		DashboardCardResultDto dashboardCardResultDto = null;
		List<DashboardCardTabResultDto> dashboardCardTabResultDtoList = commonService.listDashboardCard(dashboardCardRequestDto);
		if (CollectionUtils.isEmpty(dashboardCardTabResultDtoList)) {
			returnString = Const.Common.RESULT_CODE.SUCCESS;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_READ_RESULT, dashboardCardResultDto));
        } else {
        	dashboardCardResultDto = new DashboardCardResultDto();
        	dashboardCardResultDto.setCardList(dashboardCardTabResultDtoList);
        	// 사용자별 탭별 서비스카드 목록조회...
        	OcoUserDashboardCardDto reqOcoUserDashboardCardDto = new OcoUserDashboardCardDto();
        	reqOcoUserDashboardCardDto.setUserId(loginUserId);
        	reqOcoUserDashboardCardDto.setBldId(bldId);
        	List<OcoUserDashboardCardDto> rsltOcoUserDashboardCardDtoList = commonService.listUserDashboardCard(dashboardCardRequestDto, dashboardCardTabResultDtoList);
        	dashboardCardResultDto.setUserCardList(rsltOcoUserDashboardCardDtoList);
        	
        	returnString = Const.Common.RESULT_CODE.SUCCESS;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, "", dashboardCardResultDto));
		}
    	
		return resEntity;
	}
	
	/**
	 * 
	 * mergeOcoUserDashboardCard
	 *
	 * @param authResultDto
	 * @param reqOcoUserDashboardCardDto
	 * @return ResponseEntity
	 */
	@SuppressWarnings("rawtypes")
    @PostMapping(value="/dashboard-cards", produces="application/json; charset=UTF-8")
    public ResponseEntity mergeOcoUserDashboardCard(@AuthenticationPrincipal JwtAuthResultDto authResultDto, 
    		@RequestBody OcoUserDashboardCardDto reqOcoUserDashboardCardDto) throws Exception {
        
    	ResponseEntity<ResultDto> resEntity = null;
		String returnString = "";
    	
		String loginUserId = StringUtils.defaultString(authResultDto.getUserId());
		if ("".equals(loginUserId)) {
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_LOGIN_USER_ID));
			return resEntity;
		}
		String loginUserName = StringUtils.defaultString(authResultDto.getUsername());
//		String loginUserId = "admin"; // 이후 세션에서 얻어올 값...
//		String loginUserName = "어드민"; // 이후 세션에서 얻어올 값...
		
		String bldId = StringUtils.defaultString(reqOcoUserDashboardCardDto.getBldId());
		if ("".equals(bldId)) {
			log.error(">>>>>> bldId ERROR:{}", ERR_MSG_NULL_BLD_ID);
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_BLD_ID));
			return resEntity;
		}
		String serviceCardTabName = StringUtils.defaultString(reqOcoUserDashboardCardDto.getServiceCardTabName());
		if ("".equals(serviceCardTabName)) {
			log.error(">>>>>> serviceCardTabName ERROR:{}", ERR_MSG_NULL_SERVICE_CARD_TAB_NAME);
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_SERVICE_CARD_TAB_NAME));
			return resEntity;
		}
		int serviceCardIndexVal = CommonObjectUtil.defaultNumber(reqOcoUserDashboardCardDto.getServiceCardIndexVal());
		if (serviceCardIndexVal < 1) {
			log.error(">>>>>> serviceCardIndexVal ERROR:{}", ERR_MSG_NULL_SERVICE_CARD_INDEX_VAL);
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_SERVICE_CARD_INDEX_VAL));
			return resEntity;
		}
		
		reqOcoUserDashboardCardDto.setUserId(loginUserId);
		reqOcoUserDashboardCardDto.setAuditId(loginUserId);
		reqOcoUserDashboardCardDto.setAuditName(loginUserName);
		
		// 사용자별 서비스카드 merge 처리...
		int affectRowCount = commonService.mergeOcoUserDashboardCard(reqOcoUserDashboardCardDto);
		if (affectRowCount < 1) {
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_UPDATE_FAIL, affectRowCount));
		} else {
			returnString = Const.Common.RESULT_CODE.SUCCESS;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, "", affectRowCount));
		}
        
    	return resEntity;
    }
	
	/**
	 * 
	 * updateGuideScheduleCheckYn
	 *
	 * @param reqOcoGuideScheduleDto
	 * @return ResponseEntity
	 */
	@SuppressWarnings("rawtypes")
    @PutMapping(value="/guide-schedules/{scheduleSeq}", produces="application/json; charset=UTF-8")
    public ResponseEntity updateGuideScheduleCheckYn(@RequestBody OcoGuideScheduleDto reqOcoGuideScheduleDto) throws Exception {
        
    	ResponseEntity<ResultDto> resEntity = null;
		String returnString = "";
    	
		String checkYn = StringUtils.defaultString(reqOcoGuideScheduleDto.getCheckYn());
		if ("".equals(checkYn)) {
			log.error(">>>>>> checkYn ERROR:{}", ERR_MSG_NULL_CHECK_YN);
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_CHECK_YN));
			return resEntity;
		}
		// 일정관리 확인여부 수정...
		int affectRowCount = commonService.updateGuideScheduleCheckYn(reqOcoGuideScheduleDto);
		if (affectRowCount < 1) {
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_UPDATE_FAIL, affectRowCount));
		} else {
			returnString = Const.Common.RESULT_CODE.SUCCESS;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, "", affectRowCount));
		}
        
    	return resEntity;
    }
	
	/**
	 * 
	 * listDashboardNoticeBulletinboard
	 *
	 * @param reqOivBuildingDto
	 * @return ResponseEntity
	 */
	@SuppressWarnings("rawtypes")
	@GetMapping(value="/notice-bulletins", produces="application/json; charset=UTF-8")
	public ResponseEntity listDashboardNoticeBulletinboard(OivBuildingDto reqOivBuildingDto) throws Exception {
		
		ResponseEntity<ResultDto> resEntity = null;
		String returnString = "";
		
		String bldId = StringUtils.defaultString(reqOivBuildingDto.getBldId());
		if ("".equals(bldId)) {
			log.error(">>>>>> bldId ERROR:{}", ERR_MSG_NULL_BLD_ID);
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_BLD_ID));
			return resEntity;
		}
		
		BulletinboardGridRequestDto bulletinboardGridRequestDto = new BulletinboardGridRequestDto();
		bulletinboardGridRequestDto.setBldId(bldId);
		
		// 대시보드 공지사항 목록 조회...
		Map<String, Object> bulletinboardGridResultDtoListMap = new HashMap<String, Object>();
		List<BulletinboardGridResultDto> bulletinboardGridResultDtoList = commonService.listDashboardNoticeBulletinboard(bulletinboardGridRequestDto);
		if (CollectionUtils.isEmpty(bulletinboardGridResultDtoList)) {
			returnString = Const.Common.RESULT_CODE.SUCCESS;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_READ_RESULT, bulletinboardGridResultDtoListMap));
        } else {
        	returnString = Const.Common.RESULT_CODE.SUCCESS;
        	int totalCount = bulletinboardGridResultDtoList.size();
			Map<String, Object> totalCountMap = new HashMap<String, Object>();
			totalCountMap.put("totalCount", totalCount);
			
			bulletinboardGridResultDtoListMap.put(Const.Definition.PAGE.PAGER, totalCountMap);
			bulletinboardGridResultDtoListMap.put(Const.Definition.PAGE.LISTS, bulletinboardGridResultDtoList);
			resEntity = ResponseEntity.ok(new ResultDto(returnString, "", bulletinboardGridResultDtoListMap));
		}
		
		return resEntity;
	}
	
	
	
	/******************************* Old Version ***********************************************/
	
	/**
	 * 
	 * listCalendarYyyymm
	 *
	 * @param bldId
	 * @return ResponseEntity
	 */
	@SuppressWarnings("rawtypes")
	@GetMapping(value="/buildings/{bldId}/calendar-months", produces="application/json; charset=UTF-8")
	public ResponseEntity listCalendarYyyymm(@PathVariable("bldId") String bldId) throws Exception {
		
		ResponseEntity<ResultDto> resEntity = null;
		String returnString = "";
		
		bldId = StringUtils.defaultString(bldId);
		if ("".equals(bldId)) {
			log.error(">>>>>> bldId ERROR:{}", ERR_MSG_NULL_BLD_ID);
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_BLD_ID));
			return resEntity;
		}
		
		GuideScheduleRequestDto guideScheduleRequestDto = new GuideScheduleRequestDto();
		guideScheduleRequestDto.setBldId(bldId);
		
		// 캘린더 년월 목록 조회...
		List<String> yyyyMmList = commonService.listCalendarYyyymm(guideScheduleRequestDto);
		if (CollectionUtils.isEmpty(yyyyMmList)) {
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_READ_RESULT, yyyyMmList));
        } else {
        	returnString = Const.Common.RESULT_CODE.SUCCESS;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, "", yyyyMmList));
		}
		
		return resEntity;
	}
	
	/**
	 * 
	 * listCurrentGuideSchedule
	 *
	 * @param bldId
	 * @return ResponseEntity
	 */
	@SuppressWarnings("rawtypes")
	@GetMapping(value="/buildings/{bldId}/curr-guide-schedules", produces="application/json; charset=UTF-8")
	public ResponseEntity listCurrentGuideSchedule(@PathVariable("bldId") String bldId) throws Exception {
		
		ResponseEntity<ResultDto> resEntity = null;
		String returnString = "";
		
		bldId = StringUtils.defaultString(bldId);
		if ("".equals(bldId)) {
			log.error(">>>>>> bldId ERROR:{}", ERR_MSG_NULL_BLD_ID);
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_BLD_ID));
			return resEntity;
		}
		
		GuideScheduleRequestDto guideScheduleRequestDto = new GuideScheduleRequestDto();
		guideScheduleRequestDto.setBldId(bldId);
		
		// 캘린더 및 스케줄 목록 조회...
		GuideScheduleResultDto guideScheduleResultDto = commonService.listCurrentGuideSchedule(guideScheduleRequestDto);
		if (guideScheduleResultDto == null) {
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_READ_RESULT, guideScheduleResultDto));
        } else {
        	returnString = Const.Common.RESULT_CODE.SUCCESS;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, "", guideScheduleResultDto));
		}
		
		return resEntity;
	}
	
	/**
	 * 
	 * listGuideSchedule
	 *
	 * @param bldId
	 * @param guideScheduleRequestDto
	 * @return ResponseEntity
	 */
	@SuppressWarnings("rawtypes")
	@GetMapping(value="/buildings/{bldId}/guide-schedules", produces="application/json; charset=UTF-8")
	public ResponseEntity listGuideSchedule(@PathVariable("bldId") String bldId, GuideScheduleRequestDto guideScheduleRequestDto) throws Exception {
		
		ResponseEntity<ResultDto> resEntity = null;
		String returnString = "";
		
		bldId = StringUtils.defaultString(bldId);
		if ("".equals(bldId)) {
			log.error(">>>>>> bldId ERROR:{}", ERR_MSG_NULL_BLD_ID);
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_BLD_ID));
			return resEntity;
		}
		guideScheduleRequestDto.setBldId(bldId);
		
		String selectYyyymm = StringUtils.defaultString(guideScheduleRequestDto.getSelectYyyymm());
		if ("".equals(selectYyyymm)) {
			log.error(">>>>>> selectYyyymm ERROR:{}", ERR_MSG_NULL_SELECT_YYYYMM);
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_SELECT_YYYYMM));
			return resEntity;
		}
		int selectWeekNum = CommonObjectUtil.defaultNumber(guideScheduleRequestDto.getSelectWeekNum());
		if (selectWeekNum < 1) {
			log.error(">>>>>> selectWeekNum ERROR:{}", ERR_MSG_NULL_SELECT_WEEK_NUM);
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_SELECT_WEEK_NUM));
			return resEntity;
		}
		
		// 캘린더 및 스케줄 목록 조회...
		GuideScheduleResultDto guideScheduleResultDto = commonService.listGuideSchedule(guideScheduleRequestDto);
		if (guideScheduleResultDto == null) {
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_READ_RESULT, guideScheduleResultDto));
        } else {
        	returnString = Const.Common.RESULT_CODE.SUCCESS;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, "", guideScheduleResultDto));
		}
		
		return resEntity;
	}
	
}
