package com.adtcaps.tsop.dashboard.api.energy.domain;

public class SavingsVO {

	/* TBL_ENERGY_SAVINGS */
	private String buildingId;
	private String dayOfWeek;
	private String savingVal;
	private String createTime;
	
	public String getBuildingId() {
		return buildingId;
	}
	public void setBuildingId(String buildingId) {
		this.buildingId = buildingId;
	}
	public String getDayOfWeek() {
		return dayOfWeek;
	}
	public void setDayOfWeek(String dayOfWeek) {
		this.dayOfWeek = dayOfWeek;
	}
	public String getSavingVal() {
		return savingVal;
	}
	public void setSavingVal(String savingVal) {
		this.savingVal = savingVal;
	}
	public String getCreateTime() {
		return createTime;
	}
	public void setCreateTime(String createTime) {
		this.createTime = createTime;
	}
	
	@Override
	public String toString() {
		return "EnergySavingsVO [buildingId=" + buildingId + ", dayOfWeek=" + dayOfWeek + ", savingVal=" + savingVal
				+ ", createTime=" + createTime + "]";
	}
	
}
