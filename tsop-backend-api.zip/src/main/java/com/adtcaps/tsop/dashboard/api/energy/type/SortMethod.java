package com.adtcaps.tsop.dashboard.api.energy.type;

public enum SortMethod {
	ASC,
	DESC;

	public static SortMethod getSortMethod(String sort) {
		if (SortMethod.DESC.name().equalsIgnoreCase(sort)) {
			return DESC;
		}

		return ASC;
	}
}
