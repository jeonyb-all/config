package com.adtcaps.tsop.dashboard.api.energy.service.impl;

import static java.util.stream.Collectors.toList;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.adtcaps.tsop.dashboard.api.energy.domain.BldTypeVO;
import com.adtcaps.tsop.dashboard.api.energy.domain.BuildingPowerTrendVO;
import com.adtcaps.tsop.dashboard.api.energy.domain.BuildingPowerVO;
import com.adtcaps.tsop.dashboard.api.energy.domain.BuildingTypeVO;
import com.adtcaps.tsop.dashboard.api.energy.domain.BuildingVO;
import com.adtcaps.tsop.dashboard.api.energy.domain.CommonCodeDetailVO;
import com.adtcaps.tsop.dashboard.api.energy.domain.CustomerVO;
import com.adtcaps.tsop.dashboard.api.energy.domain.EnergyPowerQnttyVO;
import com.adtcaps.tsop.dashboard.api.energy.domain.PowerConsumptionTrendVO;
import com.adtcaps.tsop.dashboard.api.energy.domain.PowerKwhM2StatVO;
import com.adtcaps.tsop.dashboard.api.energy.domain.WeekendPowerStatVO;
import com.adtcaps.tsop.dashboard.api.energy.mapper.EnergyMapper;
import com.adtcaps.tsop.dashboard.api.energy.service.EnergyService;
import com.adtcaps.tsop.dashboard.api.energy.type.SortMethod;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
public class EnergyServiceImpl implements EnergyService {

	@Autowired
	private EnergyMapper energyMapper;

	@Override
	public List<BuildingVO> getBuildingList() {
		return energyMapper.getBuildingList();
	}

	/**
	 * 에너지 통합관제
	 */
	public List<EnergyPowerQnttyVO> getPowerList(final String bldTypeCd, final SortMethod sort) {
		log.debug("#### NEW getPowerList #######");
		List<EnergyPowerQnttyVO> powerBaseList =  energyMapper.getPowerBaseList(bldTypeCd);

		if (powerBaseList == null) {
			powerBaseList = Collections.emptyList();
		}

		List<PowerKwhM2StatVO> powerDensityList = getPowerDensityList();
		List<WeekendPowerStatVO> weekendPowerStatList = getWeekendPowerStat();

		powerBaseList = powerBaseList.stream().map(p -> {
			List<PowerKwhM2StatVO> tmpDensityList = powerDensityList.stream().filter(d -> d.getBldId().equals(p.getBldId())).collect(toList());
			p.setPowerDensityList(tmpDensityList);

			float powerDensity = tmpDensityList.stream().map(PowerKwhM2StatVO::getPowerVal).reduce(0.0f, Float::sum);
			float avgPowDensity = (float)(Math.round((powerDensity/tmpDensityList.size())*100)/100.0);
			p.setAvgPowerDensity(avgPowDensity);

			List<WeekendPowerStatVO> tmpPowerStatList = weekendPowerStatList.stream().filter(w -> w.getBldId().equals(p.getBldId())).collect(toList());
			p.setPowerStatList(tmpPowerStatList);

			return p;
		}).collect(toList());

		Comparator<EnergyPowerQnttyVO> sortComparator = SortMethod.DESC == sort ? Comparator.reverseOrder() : Comparator.naturalOrder();
		powerBaseList = powerBaseList.stream().sorted(sortComparator).collect(toList());

		return powerBaseList;
	}

	/**
	 * 주간 전력 원단위 조회
	 */
	@Override
	public List<PowerKwhM2StatVO> getPowerDensityList() {
		List<PowerKwhM2StatVO> powerKwhM2StatVOs = energyMapper.getPowerDensityList();
		return powerKwhM2StatVOs != null ? powerKwhM2StatVOs : Collections.emptyList();
	}

	public List<WeekendPowerStatVO> getWeekendPowerStat() {
		List<WeekendPowerStatVO> weekendPowerStatVOs = energyMapper.getWeekendPowerStat();
		return weekendPowerStatVOs != null ? weekendPowerStatVOs : Collections.emptyList();
	}

	/**
	 * 건물별 전력 소비량 조회(HeatMap 부분)
	 */
	public List<PowerConsumptionTrendVO> getPowerConsumptionTrend(String bldId) {
		return energyMapper.getPowerConsumptionTrend(bldId);
	}


	/**
	 * 상세 코드 조회 (빌딩 유형명 조회)
	 */
	public List<CommonCodeDetailVO> getCodeDetail(String commonCd) {
		List<CommonCodeDetailVO> commonCodeDetailVOs = energyMapper.getCodeDetail(commonCd);
		return commonCodeDetailVOs != null ? commonCodeDetailVOs : Collections.emptyList();
	}


	public int countBuilding(String bldTypeCd) {
		return energyMapper.countBuilding(bldTypeCd);
	}

	/**
	 * 빌딩 유형 정보(유형명[사무동, 교환, 복합??] , 소속 빌딩 개수등)
	 */
	public List<BuildingTypeVO> getBuildingTypeList() {
		List<CommonCodeDetailVO> codeDetailList =  getCodeDetail("bld_type_cd");
		log.debug("codeDetailList : {}", codeDetailList);

		List<BuildingTypeVO> outList = codeDetailList.stream().map(cd -> {
			BuildingTypeVO buildingTypeVO = new BuildingTypeVO(cd);
			buildingTypeVO.setBldCount(countBuilding(cd.getCommonCdVal()));
			return buildingTypeVO;
		}).collect(toList());

		return outList;
	}
	/**
	 * 건물별 전력 소비량 조회(HeatMap Highchart 부분)
	 */
	@Override
	public Map<String, Object> powerConsumptionTrendChart(String bldId) {
		List<PowerConsumptionTrendVO> powerConsumptionTrendList = energyMapper.getPowerConsumptionTrendChart(bldId);

		Set<String> dayOfWeekList = new LinkedHashSet<>();
		Set<HashMap<String, Object>> dateList = new LinkedHashSet<>();
		for(PowerConsumptionTrendVO vo : powerConsumptionTrendList) {
			dayOfWeekList.add(vo.getDayWeekEngName());
			
			HashMap<String, Object> map = new HashMap<>();
			
            map.put("dateFormat", vo.getDateFormat());
            map.put("dayofweek", vo.getDayOfWeek());
            map.put("dayWeekName", vo.getDayWeekName());
            map.put("dayWeekEngName", vo.getDayWeekEngName());
            map.put("dayWeekEngAbbrName", vo.getDayWeekEngAbbrName());
            dateList.add(map);
		}
		
		List<Number[]> heatMapList = new ArrayList<>();
		for (PowerConsumptionTrendVO trendVO : powerConsumptionTrendList) {
			Number[] arr = {trendVO.getXAxis(), trendVO.getHour(), trendVO.getPower()};
			heatMapList.add(arr);
		}
		Map<String, Object> resultMap = new HashMap<>();
		
		resultMap.put("heatMap", heatMapList);
		resultMap.put("dayOfWeekList", dayOfWeekList);
		resultMap.put("dateList", dateList);
		return resultMap;
	}
	
	/**
     * 
     * <pre>
     *  메소드명 : fmBuildingPowerTrendDayWeek
     *  설    명 : 빌딩 요일별 7일 평균 전력 트랜드 조회
     *  작 성 일 : 2020. 12. 22.
     *  작 성 자 : Jeong.HyunMin
     * </pre>
     * @param bldId
     * @return
     */
	@Override
	public BuildingVO fmBuildingPowerTrendDayWeek(String bldId) {
	    BuildingVO bldInfo =  energyMapper.getBuildingInfo(bldId);	    
	    bldInfo.setTrendList(energyMapper.getBuildingPowerDayWeek(bldId, null));
	    return bldInfo;
	}
	
	 /**
     * 
     * <pre>
     *  메소드명 : fmBuildingPowerTrendHour
     *  설    명 : 빌딩 시간대별 7일 평균 전력 트랜드 조회
     *  작 성 일 : 2020. 12. 22.
     *  작 성 자 : Jeong.HyunMin
     * </pre>
     * @param bldId
     * @return
     */
	@Override
	public BuildingVO fmBuildingPowerTrendHour(String bldId) {
	    BuildingVO bldInfo =  energyMapper.getBuildingInfo(bldId);
	    bldInfo.setTrendList(energyMapper.getBuildingPowerHour(bldId));
	    return bldInfo; 
	}
	
	/**
     * 
     * <pre>
     *  메소드명 : fmBldType
     *  설    명 : 빌딩 유형 목록 조회
     *  작 성 일 : 2021. 1. 11.
     *  작 성 자 : Jeong.HyunMin
     * </pre>
     * @return
     */
	@Override
    public List<BldTypeVO> fmBldType(){
        return energyMapper.getBldTypeList();
    }
	
	/**
	 * 
	 * <pre>
	 *  메소드명 : fmBuildingPowerUsage
	 *  설    명 : 빌딩별 전력 사용량 현황
	 *  작 성 일 : 2021. 1. 11.
	 *  작 성 자 : Jeong.HyunMin
	 * </pre>
	 * @param bldType
	 * @param order
	 * @return
	 */
	@Override
    public List<BuildingPowerVO> fmBuildingPowerUsage(String bldType, String sort){
	    if(sort != null) {
	        sort = sort.toUpperCase();
        }
	    
	    List<BuildingPowerVO> list = energyMapper.getBuildingPowerUsage(bldType, sort);
	    List<CustomerVO> cusList = energyMapper.getCustomerList(bldType);
	    List<BuildingPowerTrendVO> trendList = energyMapper.getBuildingPowerDayWeek(null, bldType);
	    for (BuildingPowerVO bldInfo : list) {
	        bldInfo.setCustomerList(cusList.stream().filter(cusInfo -> (bldInfo.getBldId()).equals(cusInfo.getBldId()) ).collect(toList()));
	        bldInfo.setTrendList(trendList.stream().filter(trendInfo -> (bldInfo.getBldId()).equals(trendInfo.getBldId()) ).collect(toList()));
        }
	            
	    return list;
    }
}
