package com.adtcaps.tsop.dashboard.api.hvac.domain;

import java.util.List;

import javax.validation.constraints.Size;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@ApiModel(value = "층별재실자수정보", description = "층별재실자수정보를 조회한다.")
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class FloorOccupantInfoVO { 
	 
	@ApiModelProperty(position = 1 , required = false, value="건물ID", example = "0000")
	@Size(min = 1, max = 4, message="건물ID는 4자리입니다")
    private String bldId;//건물ID
	  

	@ApiModelProperty(position = 3 , required = false, value="층정보", example = "1F")
	private String locFloor	;	//층정보
	//@ApiModelProperty(required = false, value="출입사용자유형코드", example = "1F")
	//private String  enterUserTypeCd	;//출입사용자유형코드
	
	@ApiModelProperty(position = 5, required = false, value="재실자수", example = "36")
	private String occupantCnt 	;//재실자수   통계낸경우는 숫자,0이지만  통계를 안낸경우 -를 줄경우로 대비<- int로 안함
	
	@ApiModelProperty(position = 5, required = false, value="현재 건물내 인원 ", example = "36")
	private int officeTotalCnt 	;//현재 건물내 인원 
	
	
	@ApiModelProperty(position = 7 , required = false, value="재실자최대여부", example = "Y")
	private String occupantMaxYn	;//재실자최대여부
   
    private String  sumDateHourminute   ;// 집계일자시분

    private String  simpleHourminute   ;// 집계시분 HH시mm분
    
    
	private List<AirQualityCO2InfoVO>  airQualityCO2List;//층별 공기질(CO2) 값 목록
    
    
}
