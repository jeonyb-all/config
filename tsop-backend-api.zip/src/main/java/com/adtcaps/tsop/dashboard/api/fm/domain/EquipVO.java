package com.adtcaps.tsop.dashboard.api.fm.domain;

import java.util.ArrayList;
import java.util.List;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class EquipVO {
	private String equipCd;                                                                 //설비공통코드
	private String equipName;                                                               //설비명
    private Integer sortSeq;                                                                //정렬순서
    private String facilityCd;                                                              //설비코드
    private Float facilityCnt;                                                              //설비대수
    private Float facilityOperateCnt;                                                       //설비가동개수
    private Integer facilityOperateStartHour;                                               //설비가동시작시
    private Integer facilityOperateSuspendHour;                                             //설비가동정지시
    private Float facilityOperateTm;                                                        //설비가동시간
    private Float chilledwaterSupplyTemprVal;                                               //냉수공급온도값
    private Float chilledwaterReturnTemprVal;                                               //냉각수반환온도값
    private Float cowSupplyTemprVal;                                                        //냉각수공급온도값
    private Float cowReturnTemprVal;                                                        //냉각수반환온도값
    private Float chrFlowrateVal;                                                           //냉동기유량값
    private Float chrCopVal;                                                                //냉동기CoP값   
    private Float ahuDamperOpeningRate;                                                     //공조기댐퍼개도율
	
    private List<BuildingStatusVO> statusList = new ArrayList<BuildingStatusVO>();        //
    
}
