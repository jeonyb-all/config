package com.adtcaps.tsop.dashboard.api.fm.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.adtcaps.tsop.dashboard.api.fm.service.BatchService;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Component
@RestController
@RequestMapping(value = "/api/batch")
public class BatchController {
	@Autowired
	private BatchService batchService;
	
	//15분전력데이터를 주단위 시간대별 데이터 쌓기
	@GetMapping(value="fmOperationStatusBatchRest", produces="application/json; charset=UTF-8")
	public void fmOperationStatusBatchRest() {
		batchService.fmOperationStatusBatch();
	}
	
	@GetMapping(value="powerUnitBatchRest", produces="application/json; charset=UTF-8")
	public void powerUnitBatchRest() {
		batchService.powerUnitBatch();
	}
	
	@GetMapping(value="fmBuildingPointStatRest", produces="application/json; charset=UTF-8")
	public void fmBuildingPointStatRest() {
		batchService.fmBuildingPointStat();
	}
}
