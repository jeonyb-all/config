package com.adtcaps.tsop.dashboard.api.hvac.controller;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.util.CollectionUtils;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.adtcaps.tsop.authentication.domain.JwtAuthResultDto;
import com.adtcaps.tsop.dashboard.api.hvac.domain.FloorAmbientAirCurrInfoVO;
import com.adtcaps.tsop.dashboard.api.hvac.domain.OutAirCoolAnalysisResultVO;
import com.adtcaps.tsop.dashboard.api.hvac.domain.OutAirCoolOperationResultVO;
import com.adtcaps.tsop.dashboard.api.hvac.domain.OutFloorAmbientAirResultVO;
import com.adtcaps.tsop.dashboard.api.hvac.service.OutAirCoolService;
import com.adtcaps.tsop.helper.constant.Const;
import com.adtcaps.tsop.helper.domain.ResultDto;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.extern.slf4j.Slf4j;


@Api(value = "대시보드업무 HVAC 외기냉방제어 API", tags = {"대시보드업무 HVAC 외기냉방제어  API"})
@Tag(name = "대시보드업무 HVAC 외기냉방제어  API", description = ""
		+ "```\n"
		+ "(1)외기 냉방 운영 현황  조회 요구사항\n" 
		+ "  1)층별로 외기냉방운영 현황을 보여준다.\n" 
		+ "  2)X축 표현 데이터 주기  15분\n" 
		+ "  3)실내엔탈피 기준(온도,습도,엔탈피)은  구성_관리기준값상세(경보지표관리)에서 조회해야한다.(층마다 달라진다)\n" 
		+ "    실내엔탈피  기준값이 저장된게 없을경우 기준default값으로 화면에 보내준다.\n"
		+ "       - 26도,70% ,63.96 (kJ/kg) \n"
		+ "  4)실시간으로  x축이 현재시간 -24시간 으로 shift개념으로 보여준다 \n"
		+ "  5)화면갱신 15분\n"
		 
		
		+ "(2)외기 냉방 운영 현황 분석 조회요구사항 \n" 
		+ "  1)실외 엔탈피 현황을 기상청 정보 기준(온도,습도,엔탈피)으로 보여준다 \n" 
		+ "  2)층을 클릭하면  층의실내온도,실내습도,실내엔탈피 및  실내엔탈피 기준의  온도,습도,실내엔탈피를 풍선도움말로 보여준다.\n" 
		+ "  3)실내 엔탈피 기준(온도,습도,엔탈피)는 구성_관리기준값상세(경보지표관리)에서 가져온다.(층마다 달라진다)\n" 
		+ "    실내엔탈피  기준값이 저장된게 없을경우 기준default값으로 화면에 보내준다.\n"
		+ "       - 26도,70% ,63.96 (kJ/kg) \n"
		+ "  4)화면갱신 15분\n" 
		+ "``` \n")
@Slf4j
@RestController
@RequestMapping(value = "/api/dashboard/hvac/outAir")
public class OutAirCoolController {
	private final String ERR_MSG_NULL_LOGIN_USER_ID = "로그인 사용자ID가 없습니다.";
	private final String ERR_MSG_NULL_BLD_ID = "빌딩ID가 없습니다."; 

	private final String ERR_MSG_NULL_SEARCH_RESULT_LIST = "조회 결과가 없습니다.";
	private final String ERR_MSG_READ_FAIL = "조회에 실패하였습니다.";
	private final String ERR_MSG_UPDATE_FAIL = "저장에 실패하였습니다.";
	private final String ERR_MSG_DELETE_FAIL = "삭제에 실패하였습니다.";
	
	@Autowired
	private OutAirCoolService outAirCoolService;
 
       //2021.11.24이전 전일외기냉방운영현황   /api/dashboard/fm/building/{bldId}/equipment/ambientAir/floor/{floor}/hourState
 	    //2021.11.24이후 전일외기냉방운영현황  /api/dashboard/hvac/outAir/building/{bldId}/outaircool/floor/{floor}/predayoperation
	   @SuppressWarnings("rawtypes")
	    @GetMapping(value="building/{bldId}/outaircool/floor/{floor}/predayoperation", produces="application/json; charset=UTF-8")
	    public @ResponseBody ResponseEntity  findOutAirCoolFloorOperationPreDay(
	            @AuthenticationPrincipal JwtAuthResultDto authResultDto, 
	            @ApiParam(value = "건물ID", required = true, example = "0000") 
	            @PathVariable(required = true) String bldId
	            
	            ,@ApiParam(value = "층수", required = true, example = "1F") 
	             @PathVariable(required = true) String floor
	            ) {

	        ResponseEntity<ResultDto> resEntity = null;
	        String returnString = "";
	        //로그인체크
	        String loginUserId = StringUtils.defaultString(authResultDto.getUserId());
	        if ("".equals(loginUserId)) {
	            returnString = Const.Common.RESULT_CODE.FAIL;
	            resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_LOGIN_USER_ID));
	            return resEntity;
	        }

	        //빌딩체크 
	        if (    bldId==null || "".equals(bldId)
	            ||  floor==null || "".equals(floor)
	                
	                ) {
	            log.error(">>>>>> bldId ERROR:{}", ERR_MSG_NULL_BLD_ID);
	            returnString = Const.Common.RESULT_CODE.FAIL;
	            resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_BLD_ID));
	            return resEntity;
	        }
	        OutFloorAmbientAirResultVO outFloorAmbientAirResultVO = outAirCoolService.findOutAirCoolFloorOperationPreDay(bldId,floor);
	        
 

	        if (outFloorAmbientAirResultVO == null || CollectionUtils.isEmpty(outFloorAmbientAirResultVO.getFloorAmientAirList() ) ) {
	            //오류가 아닌 데이터가 없을때 C0000
                String returnMesg = "";
	            if(CollectionUtils.isEmpty(outFloorAmbientAirResultVO.getFloorAmientAirList())){
                   returnString = Const.Common.RESULT_CODE.SUCCESS;
                   returnMesg = ERR_MSG_NULL_SEARCH_RESULT_LIST;
                }else { 
                   returnString = Const.Common.RESULT_CODE.FAIL;
                   returnMesg = ERR_MSG_READ_FAIL;
                } 
	            if(outFloorAmbientAirResultVO == null )  outFloorAmbientAirResultVO = new OutFloorAmbientAirResultVO();
	            
	            resEntity = ResponseEntity.ok(new ResultDto(returnString, returnMesg, outFloorAmbientAirResultVO ));
	        } else {
	            returnString = Const.Common.RESULT_CODE.SUCCESS; 
	            resEntity = ResponseEntity.ok(new ResultDto(returnString, "", outFloorAmbientAirResultVO));
	        }
	        
	        return resEntity;
	    }

	   
	   
	@ApiOperation(nickname = "외기 냉방 운영 현황  조회", value = "외기 냉방 운영 현황  조회"
			, notes = "``` \n"
					+"건물의 층별 외기냉방 현황(댐퍼개도율,환기온도,실내/실외엔탈피) 및 실내엔탈피 기준을 최근 시분으로 조회하여 보여준다. \n"
					+"``` \n"

		        +"```"
		        + "sequence\n"
		        + "User -> 외기냉방Controller: GET /api/dashboard/hvac/outAir/building/{bldId}/outaircool/floor/{floor}/operation \n"
		        + "외기냉방Controller -> 외기냉방Controller : 입력값 유효성체크\n"
		        + "외기냉방Controller -> 외기냉방Service: 조회요청\n"
				+ "외기냉방Service    -> 외기냉방Mapper: 조회요청\n"
				+ "외기냉방Mapper     -> Database: 조회요청\n"
				+ "Note right of Database :  구성_관리기준값상세(경보지표관리)-실내엔탈피 기준\\n설비_공조기설비15분집계\\n설비_외부환경15분집계 \n" 
				+ "Database        --> 외기냉방Mapper: return 조회결과 \n" 
				+ "외기냉방Mapper     --> 외기냉방Service: 조회결과List \n"
				+ "외기냉방Service    --> 외기냉방Controller: 조회결과List\n"
				+ "외기냉방Controller --> User : 외기 냉방 운영 현황  조회 결과 JSON Object\\n\\n-실내엔탈피  기준:건물ID,층,온도,습도,엔탈피\\n-외기냉방조회:건물ID, 층별로 시간별  댐퍼개도율,환기온도,실내엔탈피,외기엔탈피 \n"
				+ "```\n"					
					)
	//@ResponseBody OutAirCoolOperationResultVO 
	@SuppressWarnings("rawtypes")
	@GetMapping(value="building/{bldId}/outaircool/floor/{floor}/operation", produces="application/json; charset=UTF-8")
	public @ResponseBody ResponseEntity  findOutAirCoolFloorOperation(
			@AuthenticationPrincipal JwtAuthResultDto authResultDto, 
			@ApiParam(value = "건물ID", required = true, example = "0000") 
			@PathVariable(required = true) String bldId
			
			,@ApiParam(value = "층수", required = true, example = "1F") 
			 @PathVariable(required = true) String floor
			) {

    	ResponseEntity<ResultDto> resEntity = null;
		String returnString = "";
		//로그인체크
		String loginUserId = StringUtils.defaultString(authResultDto.getUserId());
		if ("".equals(loginUserId)) {
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_LOGIN_USER_ID));
			return resEntity;
		}

		//빌딩체크 
		if (    bldId==null || "".equals(bldId)
			||	floor==null || "".equals(floor)
				
				) {
			log.error(">>>>>> bldId ERROR:{}", ERR_MSG_NULL_BLD_ID);
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_BLD_ID));
			return resEntity;
		}
		OutAirCoolOperationResultVO outAirCoolOperationResultVO = outAirCoolService.findOutAirCoolFloorOperation(bldId,floor);

		if (outAirCoolOperationResultVO == null || CollectionUtils.isEmpty(outAirCoolOperationResultVO.getFloorAmientAirList() ) ) {
		    if(outAirCoolOperationResultVO == null )  outAirCoolOperationResultVO = new OutAirCoolOperationResultVO();
            //오류가 아닌 데이터가 없을때 C0000
            String returnMesg = "";
            if(CollectionUtils.isEmpty(outAirCoolOperationResultVO.getFloorAmientAirList())){
                returnString = Const.Common.RESULT_CODE.SUCCESS;
                returnMesg = ERR_MSG_NULL_SEARCH_RESULT_LIST;
             }else { 
                returnString = Const.Common.RESULT_CODE.FAIL;
                returnMesg = ERR_MSG_READ_FAIL;
             }  
			resEntity = ResponseEntity.ok(new ResultDto(returnString, returnMesg, outAirCoolOperationResultVO ));
		} else {
			returnString = Const.Common.RESULT_CODE.SUCCESS; 
			resEntity = ResponseEntity.ok(new ResultDto(returnString, "", outAirCoolOperationResultVO));
		}
    	
    	return resEntity;
	}

	@ApiOperation(nickname = "외기 냉방 운영 현황 분석 조회", value = "외기 냉방 운영 현황 분석  조회"
			, notes = "``` \n"
					+"건물의 층별 실내엔탈피와 실외엔탈피를 비교하여  실외엔탈피 초과,정상,에너지절약권장에 따른 색상을 보여준다.\n"
					+"``` \n"

		        +"```"
		        + "sequence\n"
		        + "User -> 외기냉방Controller: GET /api/dashboard/hvac/outAir/building/{bldId}/outaircool/operation/analysis \n"
		        + "외기냉방Controller -> 외기냉방Controller : 입력값 유효성체크\n"
		        + "외기냉방Controller -> 외기냉방Service: 조회요청\n"
				+ "외기냉방Service    -> 외기냉방Mapper: 조회요청\n"
				+ "외기냉방Mapper     -> Database: 조회요청\n"
				+ "Note right of Database :  구성_관리기준값상세(경보지표관리)-실내엔탈피 기준\\n설비_AI외기냉방운영현황15분집계\\n설비_외부환경15분집계 \n" 
				+ "Database        --> 외기냉방Mapper: return 조회결과 \n" 
				+ "외기냉방Mapper     --> 외기냉방Service: 조회결과List \n"
				+ "외기냉방Service    --> 외기냉방Controller: 조회결과List\n"
				+ "외기냉방Controller --> User : 외기 냉방 운영 현황 분석  조회 결과 JSON Object\\n-실내엔탈피  기준:건물ID,층,온도,습도,엔탈피\\n-외기냉방조회:건물,ID, 층별 ,실내엔탈피,외기엔탈피 \n"
				+ "```\n"							
					)
	//@ResponseBody OutAirCoolAnalysisResultVO 
	@SuppressWarnings("rawtypes")
	@GetMapping(value="building/{bldId}/outaircool/operation/analysis", produces="application/json; charset=UTF-8")
	public @ResponseBody ResponseEntity findOutAirCoolOperationAnalysis(
			@AuthenticationPrincipal JwtAuthResultDto authResultDto, 
			@ApiParam(value = "건물ID", required = true, example = "0000") 
			@PathVariable(required = true) String bldId
			 
			) {

    	ResponseEntity<ResultDto> resEntity = null;
		String returnString = "";
		//로그인체크
		String loginUserId = StringUtils.defaultString(authResultDto.getUserId());
		if ("".equals(loginUserId)) {
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_LOGIN_USER_ID));
			return resEntity;
		}
		//빌딩체크 
		if (bldId==null || "".equals(bldId)) {
			log.error(">>>>>> bldId ERROR:{}", ERR_MSG_NULL_BLD_ID);
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_BLD_ID));
			return resEntity;
		}

		OutAirCoolAnalysisResultVO outAirCoolAnalysisResultVO =  outAirCoolService.findOutAirCoolOperationAnalysis(bldId);

		//if (outAirCoolAnalysisResultVO == null || CollectionUtils.isEmpty(outAirCoolAnalysisResultVO.getFloorAmientAirAnalysisList() ) ) {
        //데이터가 없을때  기준시간은 출력되고  데이터가 없습니다.로 하기 위해    
        if (outAirCoolAnalysisResultVO == null  ) {
		    if(outAirCoolAnalysisResultVO == null )  outAirCoolAnalysisResultVO = new OutAirCoolAnalysisResultVO();

			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_SEARCH_RESULT_LIST, outAirCoolAnalysisResultVO  ));
		} else {
			returnString = Const.Common.RESULT_CODE.SUCCESS; 
			resEntity = ResponseEntity.ok(new ResultDto(returnString, "", outAirCoolAnalysisResultVO));
		}
    	
    	return resEntity;
	}
	/**
	 * 건물ID ,층별 현재상태,실내엔탈피 기준
	 * @param bldId
	 * @param floor
	 * @return
	 */
	//@ResponseBody FloorAmbientAirCurrInfoVO
	@SuppressWarnings("rawtypes")
	@GetMapping(value="building/{bldId}/outaircool/floor/{floor}/operation/analysis/popup", produces="application/json; charset=UTF-8")
	public @ResponseBody ResponseEntity findOutAirCoolOperationAnalysisPopup(
			@AuthenticationPrincipal JwtAuthResultDto authResultDto, 
			@ApiParam(value = "건물ID", required = true, example = "0000") 
			@PathVariable(required = true) String bldId

			,@ApiParam(value = "층수", required = true, example = "1F") 
			 @PathVariable(required = true) String floor
			) {

    	ResponseEntity<ResultDto> resEntity = null;
		String returnString = "";
		//로그인체크
		String loginUserId = StringUtils.defaultString(authResultDto.getUserId());
		if ("".equals(loginUserId)) {
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_LOGIN_USER_ID));
			return resEntity;
		}
		//빌딩체크 
		if (bldId==null || "".equals(bldId)
			||	floor==null || "".equals(floor)
				) {
			log.error(">>>>>> bldId ERROR:{}", ERR_MSG_NULL_BLD_ID);
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_BLD_ID));
			return resEntity;
		}

		FloorAmbientAirCurrInfoVO floorAmbientAirCurrInfoVO =  outAirCoolService.findOutAirCoolOperationAnalysisPopup(bldId,floor);


		if (floorAmbientAirCurrInfoVO == null     ) {
		    if(floorAmbientAirCurrInfoVO == null )  floorAmbientAirCurrInfoVO = new FloorAmbientAirCurrInfoVO();
	         
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_SEARCH_RESULT_LIST, floorAmbientAirCurrInfoVO ));
		} else {
			returnString = Const.Common.RESULT_CODE.SUCCESS; 
			resEntity = ResponseEntity.ok(new ResultDto(returnString, "", floorAmbientAirCurrInfoVO));
		}
    	
    	return resEntity;
	}
	

}
