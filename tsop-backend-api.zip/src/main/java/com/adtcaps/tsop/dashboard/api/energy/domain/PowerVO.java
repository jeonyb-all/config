package com.adtcaps.tsop.dashboard.api.energy.domain;

public class PowerVO {

	/* TBL_POWER_BY_HOUR_OF_WEEK */
	private String buildingId;
	private String dayOfWeek;
	private String hour;
	private float power;
	private String createTime;
	private int xAxis;
	private int yAxis;
	
	public String getBuildingId() {
		return buildingId;
	}
	public void setBuildingId(String buildingId) {
		this.buildingId = buildingId;
	}
	public String getDayOfWeek() {
		return dayOfWeek;
	}
	public void setDayOfWeek(String dayOfWeek) {
		this.dayOfWeek = dayOfWeek;
	}
	public String getHour() {
		return hour;
	}
	public void setHour(String hour) {
		this.hour = hour;
	}
	public float getPower() {
		return power;
	}
	public void setPower(float power) {
		this.power = power;
	}
	public String getCreateTime() {
		return createTime;
	}
	public void setCreateTime(String createTime) {
		this.createTime = createTime;
	}
	public int getxAxis() {
		return xAxis;
	}
	public void setxAxis(int xAxis) {
		this.xAxis = xAxis;
	}
	public int getyAxis() {
		return yAxis;
	}
	public void setyAxis(int yAxis) {
		this.yAxis = yAxis;
	}
	
	@Override
	public String toString() {
		return "PowerVO [buildingId=" + buildingId + ", dayOfWeek=" + dayOfWeek + ", hour=" + hour + ", power=" + power
				+ ", createTime=" + createTime + ", xAxis=" + xAxis + ", yAxis=" + yAxis + ", getBuildingId()="
				+ getBuildingId() + ", getDayOfWeek()=" + getDayOfWeek() + ", getHour()=" + getHour() + ", getPower()="
				+ getPower() + ", getCreateTime()=" + getCreateTime() + ", getxAxis()=" + getxAxis() + ", getyAxis()="
				+ getyAxis() + ", getClass()=" + getClass() + ", hashCode()=" + hashCode() + ", toString()="
				+ super.toString() + "]";
	}
	
}
