package com.adtcaps.tsop.dashboard.api.hvac.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.adtcaps.tsop.dashboard.api.fm.domain.FloorAmbientAirVO;
import com.adtcaps.tsop.dashboard.api.fm.mapper.FmMapper;
import com.adtcaps.tsop.dashboard.api.hvac.domain.FloorAmbientAirAnalysisVO;
import com.adtcaps.tsop.dashboard.api.hvac.domain.FloorAmbientAirCurrInfoVO;
import com.adtcaps.tsop.dashboard.api.hvac.domain.InEnthalpyStandardVO;
import com.adtcaps.tsop.dashboard.api.hvac.domain.OutAirCoolAnalysisResultVO;
import com.adtcaps.tsop.dashboard.api.hvac.domain.OutAirCoolFloorAmbientAirVO;
import com.adtcaps.tsop.dashboard.api.hvac.domain.OutAirCoolOperationResultVO;
import com.adtcaps.tsop.dashboard.api.hvac.domain.OutEnthalpyInfoVO;
import com.adtcaps.tsop.dashboard.api.hvac.domain.OutFloorAmbientAirResultVO;
import com.adtcaps.tsop.dashboard.api.hvac.domain.lntegratedAirEnvirVO;
import com.adtcaps.tsop.dashboard.api.hvac.mapper.HvacCommonMapper;
import com.adtcaps.tsop.dashboard.api.hvac.mapper.OutAirCoolMapper;
import com.adtcaps.tsop.dashboard.api.hvac.service.OutAirCoolService;
import com.adtcaps.tsop.domain.hvac.vo.HvacCurrentDateInfoVO;

import lombok.extern.slf4j.Slf4j;
@Slf4j
@Service
public class OutAirCoolServiceImpl implements OutAirCoolService{

	//@Autowired
	//private FmMapper fmMapper;

    @Autowired
    private FmMapper fmMapper;
    
   @Autowired
    private OutAirCoolMapper outAirCoolMapper;
   
   //현재시간  15분단위 : 년월일시분,15분단위 : HH시mm분
   @Autowired
   private HvacCommonMapper hvacCommonMapper;
 

    //기존 building/{bldId}/equipment/ambientAir/floor/{floor}/hourState
	//fmBuildingEquipAmbientAirFloorState
   /**  
    * <pre>
    *  메소드명 : findOutAirCoolFloorOperation
    *  설    명 : 전일외기 냉방 운영 현황  조회
    *  작 성 일 : 2021.10.13. 
    * </pre>
    * @return  
    */ 
   @Override
   public OutFloorAmbientAirResultVO findOutAirCoolFloorOperationPreDay(String bldId,String floor) {
       OutFloorAmbientAirResultVO outFloorAmbientAirResultVO= new OutFloorAmbientAirResultVO();
       
       InEnthalpyStandardVO inEnthalpyStandardVO = outAirCoolMapper.getInEnthalpyStandardInfo(bldId, floor);
       
       //List<FloorAmbientAirVO> dataList =  outAirCoolMapper.getBuildingEquipAmbientAirFloor(bldId, floor);
       List<FloorAmbientAirVO> floorAmientAirList =  fmMapper.getBuildingEquipAmbientAirFloor(bldId, floor);
      
       outFloorAmbientAirResultVO.setFloorAmientAirList(floorAmientAirList);
       outFloorAmbientAirResultVO.setInEnthalpyStandard(inEnthalpyStandardVO);
       return outFloorAmbientAirResultVO;
   } 
   
   

   
	/**  
     * <pre>
     *  메소드명 : findOutAirCoolFloorOperation
     *  설    명 : 외기 냉방 운영 현황  조회
     *  작 성 일 : 2021.10.13. 
     * </pre>
     * @return  
     */ 
	@Override
	public OutAirCoolOperationResultVO findOutAirCoolFloorOperation(String bldId,String floor) {
		OutAirCoolOperationResultVO outAirCoolOperationResultVO= new OutAirCoolOperationResultVO();
		
		InEnthalpyStandardVO inEnthalpyStandardVO = outAirCoolMapper.getInEnthalpyStandardInfo(bldId, floor);
		
		//List<FloorAmbientAirVO> dataList =  outAirCoolMapper.getBuildingEquipAmbientAirFloor(bldId, floor);
		List<OutAirCoolFloorAmbientAirVO> floorAmientAirList =  outAirCoolMapper.getBuildingOutAirCoolFloorAmbientAir(bldId, floor);
		
		outAirCoolOperationResultVO.setFloorAmientAirList(floorAmientAirList);
		outAirCoolOperationResultVO.setInEnthalpyStandard(inEnthalpyStandardVO);
		return outAirCoolOperationResultVO;
	} 
	
	

	/** 
     * <pre>
     *  메소드명 : findOutAirCoolOperationAnalysis
     *  설    명 : 외기 냉방 운영 현황 분석 조회
     *  작 성 일 : 2021.10.13. 
     * </pre>
     * @return  
     */ 
	@Override
	public OutAirCoolAnalysisResultVO findOutAirCoolOperationAnalysis(String bldId ) {
		OutAirCoolAnalysisResultVO outAirCoolAnalysisResultVO= new OutAirCoolAnalysisResultVO();
		
        HvacCurrentDateInfoVO hvacCurrentDateInfoVO = hvacCommonMapper.selectHvacCurrentDate();
        String baseDateHourminute        = hvacCurrentDateInfoVO.getBase15DateHourminute();//15분단위 : 년월일시분
        String base15KorSimpleHourminute = hvacCurrentDateInfoVO.getBase15KorSimpleHourminute();//15분단위 : HH시mm분

        String currDateHourminute      = hvacCurrentDateInfoVO.getCurrDateHourminute()     ;//실시간    : 년월일시분
        String currKorSimpleHourminute = hvacCurrentDateInfoVO.getCurrKorSimpleHourminute();//실시간    : HH시mm분
        String currDateHour            = hvacCurrentDateInfoVO.getCurrDateHour()           ;//실시간    : 년월일시
        String currKorSimpleHour       = hvacCurrentDateInfoVO.getCurrKorSimpleHour()      ;//실시간    : HH시
   
	        
		//실외엔탈피
		OutEnthalpyInfoVO outEnthalpyInfoVO = outAirCoolMapper.getOutEnthalpyInfo(  bldId );
		if(outEnthalpyInfoVO ==null) {
	            log.debug("외기 냉방 운영 현황 분석 조회 -  기준시간 null : 설비_외부환경15분집계 및  실외엔탈피 정보 확인 필요");
	            outEnthalpyInfoVO = new OutEnthalpyInfoVO();
	            outEnthalpyInfoVO.setSumDateHourminute(baseDateHourminute);
	            outEnthalpyInfoVO.setSimpleHourminute (base15KorSimpleHourminute); 
        }
		
		//외기 냉방 층별현황 분석목록
		List<FloorAmbientAirAnalysisVO> floorAmientAirAnalysisList = outAirCoolMapper.getFloorAmientAirAnalysisList(  bldId);
		//실외엔탈피  2,17,32,47분마다 돌고 ,외기 냉방 운영 현황 분석 15분마다 돌기 때문에  시간차가 생길수 있다.
		if(floorAmientAirAnalysisList!= null  && floorAmientAirAnalysisList.size()>0) {
		    FloorAmbientAirAnalysisVO  floorAmbientAirAnalysisVO = floorAmientAirAnalysisList.get(0);
		    outEnthalpyInfoVO.setSumDateHourminute( floorAmbientAirAnalysisVO.getQueryDate());
            outEnthalpyInfoVO.setSimpleHourminute( floorAmbientAirAnalysisVO.getDtFormat());
		}
		
		if(outEnthalpyInfoVO.getSumDateHourminute()==null) { 
            outEnthalpyInfoVO.setSumDateHourminute(baseDateHourminute);
            outEnthalpyInfoVO.setSimpleHourminute (base15KorSimpleHourminute);   
		} 
         
		outAirCoolAnalysisResultVO.setOutEnthalpyInfo(outEnthalpyInfoVO);
		outAirCoolAnalysisResultVO.setFloorAmientAirAnalysisList(floorAmientAirAnalysisList);
		
		return outAirCoolAnalysisResultVO;
	} 
 
	@Override
	public FloorAmbientAirCurrInfoVO findOutAirCoolOperationAnalysisPopup(String bldId ,String floor) {
		FloorAmbientAirCurrInfoVO floorAmbientAirCurrInfoVO= new FloorAmbientAirCurrInfoVO();
		
		 //실내엔탈피기준
		 InEnthalpyStandardVO inEnthalpyStandardVO = outAirCoolMapper.getInEnthalpyStandardInfo(bldId, floor);
		 //실내엔탈피
		 InEnthalpyStandardVO inEnthalpyVO = outAirCoolMapper.getInEnthalpyInfo(bldId, floor);
		 
		 floorAmbientAirCurrInfoVO.setBldId(bldId);
		 floorAmbientAirCurrInfoVO.setLocFloor(floor);
		 floorAmbientAirCurrInfoVO.setInTemprStndVal	(inEnthalpyStandardVO.getInTemprVal());//	실내온도 기준값 
		 floorAmbientAirCurrInfoVO.setInHumidityStndVal	(inEnthalpyStandardVO.getInHumidityVal());//	실내습도 기준값 
		 floorAmbientAirCurrInfoVO.setInEnthalpyStndVal	(inEnthalpyStandardVO.getInEnthalpyVal());//	실내엔탈피 기준값
		 floorAmbientAirCurrInfoVO.setDbStandardYn	(inEnthalpyStandardVO.getDbStandardYn());//	실내엔탈피 기준값
		 if(inEnthalpyVO!=null) {		
    		 floorAmbientAirCurrInfoVO.setInTemprVal	(inEnthalpyVO.getInTemprVal());//	실내온도 값 
    		 floorAmbientAirCurrInfoVO.setInHumidityVal	(inEnthalpyVO.getInHumidityVal());//	실내습도  값 
    		 floorAmbientAirCurrInfoVO.setInEnthalpyVal	(inEnthalpyVO.getInEnthalpyVal());//	실내엔탈피  값
		 }
			
		 
			
		return floorAmbientAirCurrInfoVO;
	} 
	
	 
 
}	 
