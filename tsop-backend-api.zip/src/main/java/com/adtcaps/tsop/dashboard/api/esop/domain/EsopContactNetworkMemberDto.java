package com.adtcaps.tsop.dashboard.api.esop.domain;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class EsopContactNetworkMemberDto {
	private String bldId;
	private String empId;
	private String empName;
	private String teamName;
	private String contactPhoneNum;
	private String contactNetworkId;
	private String contactNetworkName;
	private String responseTeamId;
	private String responseTeamName;
	private String empStateCd;
	private String empStateCdName;
	private String workCategoryCdName;
	private String workDate;
	private String userId;
}
