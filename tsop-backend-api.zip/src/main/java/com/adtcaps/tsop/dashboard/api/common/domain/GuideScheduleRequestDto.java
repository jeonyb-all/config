package com.adtcaps.tsop.dashboard.api.common.domain;

import lombok.Getter;
import lombok.Setter;

/**
 * 
 * <ul>
 * <li>업무 그룹명 : tsop-backend-api</li>
 * <li>서브 업무명 : com.adtcaps.tsop.dashboard.api.common.domain</li>
 * <li>설  명 : GuideScheduleRequestDto.java</li>
 * <li>작성일 : 2020. 12. 4.</li>
 * <li>작성자 : jeonyb4</li>
 * </ul>
 */
@Getter
@Setter
public class GuideScheduleRequestDto {
	private String bldId;					// ui
	private String selectYyyymm;			// ui
	private Integer selectWeekNum;			// ui
	private String selectDate;				// ui
	private String startWeekDate;			// select
	private String endWeekDate;				// select
	
	public GuideScheduleRequestDto() {
		this.bldId = "";
		this.selectYyyymm = "";
		this.selectWeekNum = 0;
		this.selectDate = "";
		this.startWeekDate = "";
		this.endWeekDate = "";
	}
	
}
