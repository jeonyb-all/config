package com.adtcaps.tsop.dashboard.api.fm.domain;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class FloorAmbientAirVO {
    private String queryDate;                      //날짜
    private String dtFormat;                        //날짜포맷
    private String locFloor;                        //층정보
    private Float avgEnthalpyOutVal;                //외기엔탈피
    private Float avgEnthalpyInVal;                 //실내엔탈피
    private Float avgVentilationTemprVal;           //환기온도
    private Float avgDamperOpeningRate;             //댐퍼개도율
}
