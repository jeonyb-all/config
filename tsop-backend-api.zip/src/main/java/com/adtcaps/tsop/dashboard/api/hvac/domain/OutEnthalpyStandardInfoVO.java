package com.adtcaps.tsop.dashboard.api.hvac.domain;

import javax.validation.constraints.Size;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@ApiModel(value = "실외 엔탈피 기준정보", description = "실외 엔탈피 기준 정보(실외온도,실외습도,실외엔탈피)을 조회한다.")

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class OutEnthalpyStandardInfoVO {

	@ApiModelProperty(position = 1 , required = false, value="건물ID", example = "0000")
	@Size(min = 1, max = 4, message="건물ID는 4자리입니다") 
	private String bldId	;//	건물ID
	

	
	@ApiModelProperty(position = 3 , required = false, value="실외온도값", example = "26") 
	private Float outdoorTemprVal	;//	실외온도값
	
	@ApiModelProperty(position = 5 , required = false, value="실외습도값", example = "79") 
	private Float outdoorHumidityVal	;//	실외습도값 
	
	@ApiModelProperty(position = 7 , required = false, value="실외엔탈피값", example = "68.93") 
	private Float outdoorEnthalpyVal	;//	실외엔탈피값
 

	 
}
