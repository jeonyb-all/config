package com.adtcaps.tsop.dashboard.api.hvac.service;

import com.adtcaps.tsop.dashboard.api.hvac.domain.PeakPowerResultVO;

public interface OperTimeService {
 
 
	public PeakPowerResultVO findBuildingPeakPowerManager();

}
