package com.adtcaps.tsop.dashboard.api.fm.service.impl;

import static java.util.stream.Collectors.toList;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import com.adtcaps.tsop.dashboard.api.fm.domain.BuildingInTemprCellRequestDto;
import com.adtcaps.tsop.dashboard.api.fm.domain.BuildingInTemprCellResultDto;
import com.adtcaps.tsop.dashboard.api.fm.domain.BuildingInTemprChartResultDto;
import com.adtcaps.tsop.dashboard.api.fm.domain.BuildingInTemprReportResultDto;
import com.adtcaps.tsop.dashboard.api.fm.domain.BuildingInTemprResultDto;
import com.adtcaps.tsop.dashboard.api.fm.domain.ChilledwaterTemprChartRequestDto;
import com.adtcaps.tsop.dashboard.api.fm.domain.ChilledwaterTemprChartResultDto;
import com.adtcaps.tsop.dashboard.api.fm.domain.FreezerSystemDetailResultDto;
import com.adtcaps.tsop.dashboard.api.fm.domain.InTemprCellHourValueResultDto;
import com.adtcaps.tsop.dashboard.api.fm.domain.InTemprFloorCellResultDto;
import com.adtcaps.tsop.dashboard.api.fm.service.FacilityService;
import com.adtcaps.tsop.domain.fm.OfmFacilityObjectDto;
import com.adtcaps.tsop.domain.inventory.OivBuildingDto;
import com.adtcaps.tsop.domain.inventory.OivManagementReferenceBaseDto;
import com.adtcaps.tsop.domain.inventory.OivManagementReferenceDetailDto;
import com.adtcaps.tsop.helper.constant.Const;
import com.adtcaps.tsop.helper.domain.ChartRequestDto;
import com.adtcaps.tsop.helper.domain.LineChartPointDataDto;
import com.adtcaps.tsop.helper.domain.LineChartResultDto;
import com.adtcaps.tsop.helper.service.HelperService;
import com.adtcaps.tsop.helper.util.CommonDateUtil;
import com.adtcaps.tsop.helper.util.CommonObjectUtil;
import com.adtcaps.tsop.mapper.fm.OfmBuildingEnvironmentStatMapper;
import com.adtcaps.tsop.mapper.fm.OfmFacilityObjectMapper;
import com.adtcaps.tsop.mapper.fm.OfmFrzmchCooltwrObj15minuteStatMapper;
import com.adtcaps.tsop.mapper.inventory.OivManagementReferenceBaseMapper;
import com.adtcaps.tsop.mapper.inventory.OivManagementReferenceDetailMapper;
import com.adtcaps.tsop.portal.api.building.domain.BuildingDetailResultDto;
import com.adtcaps.tsop.portal.api.building.service.BuildingService;

/**
 * 
 * <ul>
 * <li>업무 그룹명 : tsop-backend-api</li>
 * <li>서브 업무명 : com.adtcaps.tsop.dashboard.api.fm.service.impl</li>
 * <li>설  명 : FacilityServiceImpl.java</li>
 * <li>작성일 : 2021. 10. 26.</li>
 * <li>작성자 : jeonyb4</li>
 * </ul>
 */
@Service
public class FacilityServiceImpl implements FacilityService {
	
	@Autowired
	private OfmFacilityObjectMapper ofmFacilityObjectMapper;
	
	@Autowired
	private OfmFrzmchCooltwrObj15minuteStatMapper ofmFrzmchCooltwrObj15minuteStatMapper;
	
	@Autowired
	private OfmBuildingEnvironmentStatMapper ofmBuildingEnvironmentStatMapper;
	
	@Autowired
	private OivManagementReferenceBaseMapper oivManagementReferenceBaseMapper;
	
	@Autowired
	private OivManagementReferenceDetailMapper oivManagementReferenceDetailMapper;
	
	@Autowired
	private HelperService helperService;
	
	@Autowired
	private BuildingService buildingService;
	
	/**
	 * 
	 * listFreezerSystemOperateTime
	 * 
	 * @param reqOfmFacilityObjectDto
	 * @return List<FreezerSystemDetailResultDto>
	 * @throws Exception 
	 */
	@Override
	public List<FreezerSystemDetailResultDto> listFreezerSystemOperateTime(OfmFacilityObjectDto reqOfmFacilityObjectDto) throws Exception {
		
		List<FreezerSystemDetailResultDto> freezerSystemDetailResultDtoList = null;
		
		try {
			
			freezerSystemDetailResultDtoList = ofmFrzmchCooltwrObj15minuteStatMapper.listFreezerSystemOperateTime(reqOfmFacilityObjectDto);
			
		} catch (Exception e) {
			throw e;
		}
		
		return freezerSystemDetailResultDtoList;
	}
	
	/**
	 * 
	 * listChilledwaterTemprGapLineChart
	 * 
	 * @param chilledwaterTemprChartRequestDto
	 * @return ChilledwaterTemprChartResultDto
	 * @throws Exception 
	 */
	@Override
	public ChilledwaterTemprChartResultDto listChilledwaterTemprGapLineChart(ChilledwaterTemprChartRequestDto chilledwaterTemprChartRequestDto) throws Exception {
		
		ChilledwaterTemprChartResultDto chilledwaterTemprChartResultDto = null;
		
		try {
			LineChartResultDto lineChartResultDto = new LineChartResultDto();
			
			String bldId = chilledwaterTemprChartRequestDto.getBldId();
			int periodTime = chilledwaterTemprChartRequestDto.getPeriodTime();
			// 15분 단위로 절삭한 현재시분 구하기...
			String currentMinute = helperService.readCurrentMinuteFloor15Minute();
			chilledwaterTemprChartRequestDto.setCurrentMinute(currentMinute);
			
			ChartRequestDto chartRequestDto = new ChartRequestDto();
			chartRequestDto.setPeriodTime(periodTime);
			chartRequestDto.setCurrentMinute(currentMinute);
			List<String> categories = helperService.list15MinuteGap(chartRequestDto);
			lineChartResultDto.setCategories(categories);
			
			// 냉동기 장비 목록 구하기...
			OfmFacilityObjectDto reqOfmFacilityObjectDto = new OfmFacilityObjectDto();
			reqOfmFacilityObjectDto.setBldId(bldId);
			reqOfmFacilityObjectDto.setFacilityCategoryCd(Const.Code.FACILITY_CATEGORY_CD.FREEZER_STATUS);
			List<OfmFacilityObjectDto> rsltOfmFacilityObjectDtoList = ofmFacilityObjectMapper.listFacilityObject(reqOfmFacilityObjectDto);
			if (!CollectionUtils.isEmpty(rsltOfmFacilityObjectDtoList)) {
				List<LineChartPointDataDto> lineChartPointDataDtoList = new ArrayList<LineChartPointDataDto>();
				for (OfmFacilityObjectDto rsltOfmFacilityObjectDto : rsltOfmFacilityObjectDtoList) {
					String objectId = StringUtils.defaultString(rsltOfmFacilityObjectDto.getObjectId());
					String facilityName = StringUtils.defaultString(rsltOfmFacilityObjectDto.getFacilityName());
					
					// 장비별 냉수입출구 온도차 목록 구하기...
					chilledwaterTemprChartRequestDto.setObjectId(objectId);
					List<Double> temprGapList = ofmFrzmchCooltwrObj15minuteStatMapper.listChilledwaterTemprGapLineChart(chilledwaterTemprChartRequestDto);
					
					LineChartPointDataDto lineChartPointDataDto = new LineChartPointDataDto();
					lineChartPointDataDto.setName(facilityName);
					lineChartPointDataDto.setData(temprGapList);
					lineChartPointDataDtoList.add(lineChartPointDataDto);
				}
				lineChartResultDto.setLinePointDatas(lineChartPointDataDtoList);
			}
			
			chilledwaterTemprChartResultDto = new ChilledwaterTemprChartResultDto();
			chilledwaterTemprChartResultDto.setChart(lineChartResultDto);
			
		} catch (Exception e) {
			throw e;
		}
		
		return chilledwaterTemprChartResultDto;
	}
	
	/**
     * 
     * listBuildingInTemprLineChart
     * 
     * @param reqOfmFacilityObjectDto
     * @return BuildingInTemprChartResultDto
     * @throws Exception 
     */
	@Override
    public BuildingInTemprChartResultDto listBuildingInTemprLineChart(OfmFacilityObjectDto reqOfmFacilityObjectDto) throws Exception {
        
		BuildingInTemprChartResultDto buildingInTemprChartResultDto = null;
		
		try {
			LineChartResultDto lineChartResultDto = new LineChartResultDto();
			BuildingInTemprReportResultDto buildingInTemprReportResultDto = new BuildingInTemprReportResultDto();
			
			String bldId = reqOfmFacilityObjectDto.getBldId();
			String facilityCategoryCd = reqOfmFacilityObjectDto.getFacilityCategoryCd();
			
			String currentDatetime = helperService.readCalculateMinuteDatetime(-1);		// 1분전 날짜시간..
			
			List<String> categories = null;
			List<Double> datas = null;
			String bldName = "";
			String statisticsDatetime = "";
			Double currentTempr = null;
			String currentHour = "";
			// 실내온도..
			List<BuildingInTemprResultDto> buildingInTemprResultDtoList = ofmBuildingEnvironmentStatMapper.listBuildingInTemprLineChart(reqOfmFacilityObjectDto);
	        if (!CollectionUtils.isEmpty(buildingInTemprResultDtoList)) {
	        	categories = buildingInTemprResultDtoList.stream().map(BuildingInTemprResultDto::getStatHour).collect(toList());
	        	datas = buildingInTemprResultDtoList.stream().map(BuildingInTemprResultDto::getCurVal).collect(toList());
	        	
	        	BuildingInTemprResultDto buildingInTemprResultDto = buildingInTemprResultDtoList.get(buildingInTemprResultDtoList.size() - 1);
	        	bldName = buildingInTemprResultDto.getBldName();
	        	statisticsDatetime = buildingInTemprResultDto.getStatDate();
	        	currentHour = categories.get(categories.size() - 1);
	        	currentTempr = datas.get(datas.size() - 1);
	        	
	        	List<LineChartPointDataDto> lineChartPointDataDtoList = new ArrayList<LineChartPointDataDto>();
	        	LineChartPointDataDto lineChartPointDataDto = new LineChartPointDataDto();
	        	lineChartPointDataDto.setName(bldName);
	        	lineChartPointDataDto.setData(datas);
	        	lineChartPointDataDtoList.add(lineChartPointDataDto);
	        	
	        	lineChartResultDto.setCategories(categories);
	        	lineChartResultDto.setLinePointDatas(lineChartPointDataDtoList);
	        	
	        	buildingInTemprReportResultDto.setBldId(bldId);
	        	buildingInTemprReportResultDto.setBldName(bldName);
	        	buildingInTemprReportResultDto.setCurrentHour(currentHour);
	        	buildingInTemprReportResultDto.setCurrentTempr(currentTempr);
	        }
			
	        String currentDate = StringUtils.substring(currentDatetime, 0, 8);
	        String currentDateFormat = CommonDateUtil.makeDateToDateFormat(currentDate);
	        buildingInTemprReportResultDto.setCurrentDate(currentDateFormat);
	        
	        // 관리기준온도 평균..
	        int referenceMonth = Integer.parseInt(StringUtils.substring(currentDate, 4, 6));
	        OivManagementReferenceDetailDto reqOivManagementReferenceDetailDto = new OivManagementReferenceDetailDto();
	        reqOivManagementReferenceDetailDto.setBldId(bldId);
	        reqOivManagementReferenceDetailDto.setReferenceMonth(referenceMonth);
	        Double mgmtBaseTempr = oivManagementReferenceDetailMapper.readAvgMgmtBaseTempr(reqOivManagementReferenceDetailDto);
	        if (mgmtBaseTempr != null) {
	        	buildingInTemprReportResultDto.setMgmtBaseTempr(mgmtBaseTempr);
	        	
	        	// 범위 외 셀 수..
	        	BuildingInTemprCellRequestDto buildingInTemprCellRequestDto = new BuildingInTemprCellRequestDto();
	        	buildingInTemprCellRequestDto.setBldId(bldId);
	        	buildingInTemprCellRequestDto.setFacilityCategoryCd(facilityCategoryCd);
	        	buildingInTemprCellRequestDto.setStatisticsDatetime(statisticsDatetime);
	        	int overTemprCellCount = ofmBuildingEnvironmentStatMapper.readOverTemprCellCount(buildingInTemprCellRequestDto);
	        	buildingInTemprReportResultDto.setOverTemprCellCount(overTemprCellCount);
	        }
	        
	        buildingInTemprChartResultDto = new BuildingInTemprChartResultDto();
	        buildingInTemprChartResultDto.setChart(lineChartResultDto);
	        buildingInTemprChartResultDto.setBuildingInTemprReportInfo(buildingInTemprReportResultDto);
			
		} catch (Exception e) {
			throw e;
		}
		
		return buildingInTemprChartResultDto;
    }
	
	/**
	 * 
	 * listBuildingInTemprCellDetail
	 * 
	 * @param buildingInTemprCellRequestDto
	 * @return BuildingInTemprCellResultDto
	 * @throws Exception 
	 */
	@Override
    public BuildingInTemprCellResultDto listBuildingInTemprCellDetail(BuildingInTemprCellRequestDto buildingInTemprCellRequestDto) throws Exception {
        
		BuildingInTemprCellResultDto buildingInTemprCellResultDto = null;
		
		try {
			String currentDatetime = helperService.readCalculateMinuteDatetime(-1);		// 1분전 날짜시간..
			
			String bldId = buildingInTemprCellRequestDto.getBldId();
			
			// 빌딩정보..
			String bldName = "";
			OivBuildingDto reqOivBuildingDto = new OivBuildingDto();
			reqOivBuildingDto.setBldId(bldId);
			BuildingDetailResultDto buildingDetailResultDto = buildingService.readBuilding(reqOivBuildingDto);
			if (buildingDetailResultDto != null) {
				bldName = StringUtils.defaultString(buildingDetailResultDto.getBldAbbrName());
			}
			
			// 관리기준온도..
			String currentDate = StringUtils.substring(currentDatetime, 0, 8);
	        int referenceMonth = Integer.parseInt(StringUtils.substring(currentDate, 4, 6));
	        OivManagementReferenceDetailDto reqOivManagementReferenceDetailDto = new OivManagementReferenceDetailDto();
	        reqOivManagementReferenceDetailDto.setBldId(bldId);
	        reqOivManagementReferenceDetailDto.setReferenceMonth(referenceMonth);
	        Double mgmtBaseTempr = oivManagementReferenceDetailMapper.readAvgMgmtBaseTempr(reqOivManagementReferenceDetailDto);
	        
			// 초과기준값 정보..
			String excessReferenceVal = "";
			OivManagementReferenceBaseDto reqOivManagementReferenceBaseDto = new OivManagementReferenceBaseDto();
			reqOivManagementReferenceBaseDto.setBldId(bldId);
			reqOivManagementReferenceBaseDto.setManagementCategoryCd(Const.Code.MANAGEMENT_CATEGORY_CD.REF_TEMPR);
			OivManagementReferenceBaseDto rsltOivManagementReferenceBaseDto = oivManagementReferenceBaseMapper.readManagementReferenceBase(reqOivManagementReferenceBaseDto);
			if (rsltOivManagementReferenceBaseDto != null) {
				excessReferenceVal = StringUtils.defaultString(rsltOivManagementReferenceBaseDto.getExcessReferenceVal());
			}
			
			// 빌딩별 층별 셀 정보..
			List<InTemprFloorCellResultDto> inTemprFloorCellResultDtoList = ofmBuildingEnvironmentStatMapper.listBuildingInTemprCell(buildingInTemprCellRequestDto);
			
			// 셀별 시간별 온도 정보..
			List<InTemprCellHourValueResultDto> inTemprCellHourValueResultDtoList = ofmBuildingEnvironmentStatMapper.listBuildingInTemprCellHourValue(buildingInTemprCellRequestDto);
			
			// 시간정보..
			List<String> hourList = helperService.list12HourFromCurrentTime();
			
			if (!CollectionUtils.isEmpty(inTemprFloorCellResultDtoList)) {
				for (InTemprFloorCellResultDto inTemprFloorCellResultDto : inTemprFloorCellResultDtoList) {
					String objectId = StringUtils.defaultString(inTemprFloorCellResultDto.getObjectId());
					String locFloor = StringUtils.defaultString(inTemprFloorCellResultDto.getLocFloor());
					
					if (!"".equals(objectId)) {
						List<InTemprCellHourValueResultDto> hourValueList = new ArrayList<InTemprCellHourValueResultDto>();
						for (String statHour : hourList) {
							boolean findSameHour = false;
							String tempObjectId = "";
							String tempLocFloor = "";
							String tempStatHour = "";
							String tempOverTemprColor = "";
							double tempCurVal = 0;
							for (InTemprCellHourValueResultDto inTemprCellHourValueResultDto : inTemprCellHourValueResultDtoList) {
								tempObjectId = StringUtils.defaultString(inTemprCellHourValueResultDto.getObjectId());
								tempLocFloor = StringUtils.defaultString(inTemprCellHourValueResultDto.getLocFloor());
								tempStatHour = StringUtils.defaultString(inTemprCellHourValueResultDto.getStatHour());
								tempCurVal = CommonObjectUtil.defaultNumber(inTemprCellHourValueResultDto.getCurVal());
								tempOverTemprColor = StringUtils.defaultString(inTemprCellHourValueResultDto.getOverTemprColor());
								if (objectId.equals(tempObjectId) && locFloor.equals(tempLocFloor) && statHour.equals(tempStatHour)) {
									findSameHour = true;
									break;
								}
							}
							if (findSameHour) {
								InTemprCellHourValueResultDto inTemprCellHourValueResultDto = new InTemprCellHourValueResultDto();
								inTemprCellHourValueResultDto.setObjectId(objectId);
								inTemprCellHourValueResultDto.setLocFloor(locFloor);
								inTemprCellHourValueResultDto.setStatHour(statHour);
								inTemprCellHourValueResultDto.setCurVal(tempCurVal);
								inTemprCellHourValueResultDto.setOverTemprColor(tempOverTemprColor);
								hourValueList.add(inTemprCellHourValueResultDto);
							} else {
								
								InTemprCellHourValueResultDto inTemprCellHourValueResultDto = new InTemprCellHourValueResultDto();
								inTemprCellHourValueResultDto.setObjectId(objectId);
								inTemprCellHourValueResultDto.setLocFloor(locFloor);
								inTemprCellHourValueResultDto.setStatHour(statHour);
								hourValueList.add(inTemprCellHourValueResultDto);
							}
						}
						inTemprFloorCellResultDto.setHourValueList(hourValueList);
					} else {
						List<InTemprCellHourValueResultDto> hourValueList = new ArrayList<InTemprCellHourValueResultDto>();
						for (String statHour : hourList) {
							InTemprCellHourValueResultDto inTemprCellHourValueResultDto = new InTemprCellHourValueResultDto();
							inTemprCellHourValueResultDto.setStatHour(statHour);
							hourValueList.add(inTemprCellHourValueResultDto);
						}
						inTemprFloorCellResultDto.setHourValueList(hourValueList);
					}
				}
			}
			
			buildingInTemprCellResultDto = new BuildingInTemprCellResultDto();
			buildingInTemprCellResultDto.setBldId(bldId);
			buildingInTemprCellResultDto.setBldName(bldName);
			buildingInTemprCellResultDto.setMgmtBaseTempr(mgmtBaseTempr);
			buildingInTemprCellResultDto.setExcessReferenceVal(excessReferenceVal);
			buildingInTemprCellResultDto.setLocFloorObjectList(inTemprFloorCellResultDtoList);
			
		} catch (Exception e) {
			throw e;
		}
		
		return buildingInTemprCellResultDto;
    }

}
