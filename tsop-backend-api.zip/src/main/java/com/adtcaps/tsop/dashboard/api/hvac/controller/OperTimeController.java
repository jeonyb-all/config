package com.adtcaps.tsop.dashboard.api.hvac.controller;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.util.CollectionUtils;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.adtcaps.tsop.authentication.domain.JwtAuthResultDto;
import com.adtcaps.tsop.dashboard.api.hvac.domain.PeakPowerResultVO;
import com.adtcaps.tsop.dashboard.api.hvac.service.OperTimeService;
import com.adtcaps.tsop.helper.constant.Const;
import com.adtcaps.tsop.helper.domain.ResultDto;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.extern.slf4j.Slf4j;


@Api(value = "대시보드업무 HVAC 운전시간 활용 전력분석 API", tags = {"대시보드업무 HVAC 운전시간 활용 전력분석 API"})
@Tag(name = "대시보드업무 HVAC 운전시간 활용 전력분석 API", description = ""
		+ "``` \n"
		+ "(1)사옥별 Peak 전력관리 요구사항\n" 
		+ "  1)사옥별 전력사용현황 - X축 데이터를 1분 데이터기준으로 보여준다.(최근 1시간 표출), Y축에는 사용전력량,  기준선은 Peak기준전력을 보여준다 \n"
		+ "  2)사옥별 부하율이 높은순 먼저 보여주고 ,부하율 90% 이상이면  Red box를 표현 해준다. \n"
		+ "  3)Peak전력 기준이 건물마다 달라진다.(임계치)   \n"
		+ "  4)부하율 표기 (1분단위 갱신)   \n"
		+ "       (사옥별 현시간 전력소비량 / Peak요금 전력) 최근 1시간 데이터(60개 표출)   \n"
		+ "  5)화면 갱신주기 1분마다 갱신 ,데이터 갱신주기 1분 <= 다시한번 확인 필요 ( 화면은 15분마다 갱신,데이터 갱신주기는 1분) \n"
		
		+ "``` \n")




@Slf4j
@RestController
@RequestMapping(value = "/api/dashboard/hvac/operTime")
public class OperTimeController {
	private final String ERR_MSG_NULL_LOGIN_USER_ID = "로그인 사용자ID가 없습니다.";
	private final String ERR_MSG_NULL_BLD_ID = "빌딩ID가 없습니다."; 

	private final String ERR_MSG_NULL_SEARCH_RESULT_LIST = "조회 결과가 없습니다.";
	private final String ERR_MSG_READ_FAIL = "조회에 실패하였습니다.";
	private final String ERR_MSG_UPDATE_FAIL = "저장에 실패하였습니다.";
	private final String ERR_MSG_DELETE_FAIL = "삭제에 실패하였습니다.";
	
	@Autowired
	private OperTimeService operTimeService;

	@ApiOperation(nickname = "사옥별 Peak 전력관리", value = "사옥별 Peak 전력관리"
			, notes = "``` \n"
					+"전력관리	사옥별로 부하율이 높은 순서에서 낮은순서로 화면에 보여준다.(사옥별로 부하율 기준은 다르다) \n"
					+"``` \n"

		        +"```"
		        + "sequence\n"
		        + "User -> 운전시간활용Controller: GET /api/dashboard/hvac/operTime/peak/power/manager \n"
		        + "운전시간활용Controller -> 운전시간활용Controller : 입력값 유효성체크\n"
		        + "운전시간활용Controller -> 운전시간활용Service: 조회요청\n"
				+ "운전시간활용Service    -> 운전시간활용Mapper: 조회요청\n"
				+ "운전시간활용Mapper     -> Database: 조회요청\n"
				+ "Note right of Database :  NEW 분당 소비전력량내역 \n" 
				+ "Database                 --> 운전시간활용Mapper: return 조회결과 \n" 
				+ "운전시간활용Mapper     --> 운전시간활용Service: 조회결과List \n"
				+ "운전시간활용Service    --> 운전시간활용Controller: 조회결과List\n"
				+ "운전시간활용Controller --> User : SKT사옥 Peak 전력관리  조회 결과 JSON Object\\n-분별 전력사용량(소비량) : 건물ID,측정일자시분,전력소비량\\n-부하율(%)\\n-Peak 기준선 \n"
				+ "```\n"	
					
					)
	//@ResponseBody List<BldPowerConsumptionVO>
	@SuppressWarnings("rawtypes")
	@GetMapping(value="peak/power/manager", produces="application/json; charset=UTF-8")
	public @ResponseBody ResponseEntity findBuildingPeakPowerManager(
			@AuthenticationPrincipal JwtAuthResultDto authResultDto  
			//@ApiParam(value = "건물ID", required = true, example = "0000") 
			//@PathVariable(required = true) String bldId
			 
			) {
    	ResponseEntity<ResultDto> resEntity = null;
		String returnString = "";
		//로그인체크
		String loginUserId = StringUtils.defaultString(authResultDto.getUserId());
		if ("".equals(loginUserId)) {
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_LOGIN_USER_ID));
			return resEntity;
		}
 
	    PeakPowerResultVO peakPowerResultVO = operTimeService.findBuildingPeakPowerManager();
	    //
        //if (peakPowerResultVO == null || CollectionUtils.isEmpty(peakPowerResultVO.getBldPowerConsumptionDataList() ) ) {
        //데이터가 없을때  기준시간은 출력되고  데이터가 없습니다.로 하기 위해 
	    if (peakPowerResultVO == null   ) {
    
	        if(peakPowerResultVO == null )  peakPowerResultVO = new PeakPowerResultVO();
            
            returnString = Const.Common.RESULT_CODE.FAIL;
            resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_SEARCH_RESULT_LIST, peakPowerResultVO  ));
        } else {
            returnString = Const.Common.RESULT_CODE.SUCCESS; 
            resEntity = ResponseEntity.ok(new ResultDto(returnString, "", peakPowerResultVO));
        }        
    	return resEntity;
    	
	}
	
	

}
