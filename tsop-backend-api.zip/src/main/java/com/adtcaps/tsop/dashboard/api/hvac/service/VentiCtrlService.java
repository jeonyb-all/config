package com.adtcaps.tsop.dashboard.api.hvac.service;

import java.util.List;

import com.adtcaps.tsop.dashboard.api.hvac.domain.FloorOccupantResultVO;
import com.adtcaps.tsop.dashboard.api.hvac.domain.FloorRealTimeAirQualityCO2InfoVO;
import com.adtcaps.tsop.dashboard.api.hvac.domain.FloorRealTimeOccupantInfoVO;
import com.adtcaps.tsop.dashboard.api.hvac.domain.RecmdVentiResultVO;

public interface VentiCtrlService {
 
	 
	public FloorOccupantResultVO findOfficePerson(String bldId);
	public RecmdVentiResultVO findRecmdVentirate(String bldId);
	
	public List<FloorRealTimeOccupantInfoVO> findRealTimeOfficePerson(String bldId);
	
	 public List<FloorRealTimeAirQualityCO2InfoVO> findRealTimeAirQualityCO2(String bldId);
	    
}
