package com.adtcaps.tsop.dashboard.api.hvac.domain;

import java.util.List;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@ApiModel(value = "실시간 통합대기환경  분석  조회 Controller 에서의 결과값", description = "건물 외기의 엔탈피, 관측소에서 제공한 대기질(PM10,PM2.5) 수치를 조회한다.")

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class AirEnvirResultVO {
    
    @ApiModelProperty(position = 1 ,required = false, value="실제 통합대기환경값", example = " ")
    private lntegratedAirEnvirVO integratedAirEnvir;     //실제 통합대기환경값

    @ApiModelProperty(position = 2 ,required = false, value="실내엔탈피 기준", example = " ")
    private InEnthalpyStandardVO inEnthalpyStandardInfo;     //실내엔탈피 기준
    
    @ApiModelProperty(position = 2 ,required = false, value="대기질 기준 목록", example = " ")
    private List<AirQualityStandardVO> airQualityList;     //대기질 기준 목록

 	
	
 
}
