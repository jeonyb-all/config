package com.adtcaps.tsop.dashboard.api.fm.batch;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import com.adtcaps.tsop.dashboard.api.fm.service.BatchService;

import lombok.extern.slf4j.Slf4j;
@Slf4j
@Component
public class FmBatch {
	@Autowired
	private BatchService batchService;
	
	@Scheduled(cron = "*/5 * * * * *")
	public void testBatch() {	
		log.info("AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA");
	}
//	
//	
//	//에너지(07시,22시마다 에너지배치를 시작한다)
//	//한국시간 09시, 13, 05 시에 배치시작
//	//서버시간 00시, 04시, 20시
//	@Scheduled(cron = "0 5 0,4,20 * * *")
////	@Scheduled(cron = "0 30 5,9,13,15 * * *")
//	public void fmBatch() {	
//		log.debug("fmBatch start time");
//		//전력 데이터 가져오기
//		batchService.fmBatch();
//		
//		log.debug("fmBuildingPointStat start time");
//		//OFM_MEDIATION_DATA 에서 설비정보 merge
//		batchService.fmBuildingPointStat();
//	}
//	
//	@Scheduled(cron = "30 0,15,30,45 * * * *")
//	public void fmEnvironmentBatch() {	//매시 05분에 실행
//		log.debug("fmEnvironmentBatch start time");
//		//15분마다 온습도데이터를 15분테이블에저 조회해 merge
//		batchService.fmEnvironmentBatch();
//	}
//	
//	@Scheduled(cron = "30 0,15,30,45 * * * *")
//	public void fmCollectWorkingTime() {	
//		log.debug("fmCollectWorkingTime start time");
//		//설비가동시간
//		batchService.fmCollectWorkingTime();
//	}
}
