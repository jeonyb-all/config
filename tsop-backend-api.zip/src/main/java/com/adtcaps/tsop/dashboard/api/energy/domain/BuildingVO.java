package com.adtcaps.tsop.dashboard.api.energy.domain;

import java.util.ArrayList;
import java.util.List;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
/** 
 * OIV_BUILDING
 * @author USER
 *
 */
public class BuildingVO {
	
	private String bldId;
	private String bldName;
	private String bldTypeCd;
	private Float bldTotalfloorareaSize;
	private String auditDatetime;

	private List<SavingsVO> savingsList;	
	private List<BuildingPowerTrendVO> trendList = new ArrayList<BuildingPowerTrendVO>();
}
