package com.adtcaps.tsop.dashboard.api.elevator.controller;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.adtcaps.tsop.dashboard.api.elevator.domain.ElevatorEventChartResultDto;
import com.adtcaps.tsop.dashboard.api.elevator.service.ElevatorService;
import com.adtcaps.tsop.domain.elevator.OfmElevatorEventDto;
import com.adtcaps.tsop.helper.constant.Const;
import com.adtcaps.tsop.helper.domain.ResultDto;

import lombok.extern.slf4j.Slf4j;

/**
 * 
 * <ul>
 * <li>업무 그룹명 : tsop-backend-api</li>
 * <li>서브 업무명 : com.adtcaps.tsop.dashboard.api.elevator.controller</li>
 * <li>설  명 : ElevatorController.java</li>
 * <li>작성일 : 2020. 12. 4.</li>
 * <li>작성자 : jeonyb4</li>
 * </ul>
 */
@Slf4j
@RestController
@RequestMapping("/api/dashboard/elevator")
public class ElevatorController {
	
	private final String ERR_MSG_NULL_BLD_ID = "빌딩ID가 없습니다.";
	
	private final String ERR_MSG_NULL_SEARCH_RESULT_LIST = "조회 결과가 없습니다.";
	
	@Autowired
	private ElevatorService elevatorService;
	
	/**
	 * 
	 * listElevatorEventChart
	 *
	 * @param reqOfmElevatorEventDto
	 * @return ResponseEntity
	 */
	@SuppressWarnings("rawtypes")
	@GetMapping(value="/elevator-events/bar-chart", produces="application/json; charset=UTF-8")
	public ResponseEntity listElevatorEventChart(OfmElevatorEventDto reqOfmElevatorEventDto) throws Exception {
		
		ResponseEntity<ResultDto> resEntity = null;
		String returnString = "";
		
		String bldId = StringUtils.defaultString(reqOfmElevatorEventDto.getBldId());
		if ("".equals(bldId)) {
			log.error(">>>>>> bldId ERROR:{}", ERR_MSG_NULL_BLD_ID);
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_BLD_ID));
			return resEntity;
		}
		// 빌딩별 엘리베이터 현황 차트 조회
		ElevatorEventChartResultDto elevatorEventChartResultDto = elevatorService.listElevatorEventChart(reqOfmElevatorEventDto);
		if (elevatorEventChartResultDto == null) {
			returnString = Const.Common.RESULT_CODE.SUCCESS;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_SEARCH_RESULT_LIST, elevatorEventChartResultDto));
        } else {
        	returnString = Const.Common.RESULT_CODE.SUCCESS;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, "", elevatorEventChartResultDto));
		}
		
		return resEntity;
	}

}
