package com.adtcaps.tsop.dashboard.api.hvac.domain;

import io.swagger.annotations.ApiModel;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@ApiModel(value = "사옥별 전력사용 기본정보", description = "사옥별 전력사용 기본값을 조회한다.")

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class BldPowerBaseInfoVO {

 
    //private String  currDateHourminute   ;//실시간    : 년월일시분
    //private String  currHourminute   ;// 실시간    : HH시mm분
    private String  sumDateHourminute   ;//실시간    : 년월일시분
    private String  simpleHourminute   ;// 실시간    : HH시mm분
         
 

	 
}
