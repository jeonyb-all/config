package com.adtcaps.tsop.dashboard.api.mashup.controller;

import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.adtcaps.tsop.dashboard.api.mashup.domain.AlarmCurrentStateDto;
import com.adtcaps.tsop.dashboard.api.mashup.domain.AlarmGradeAlarmNoCheckResultDto;
import com.adtcaps.tsop.dashboard.api.mashup.domain.AlarmGradeAlarmTotalResultDto;
import com.adtcaps.tsop.dashboard.api.mashup.service.MashupService;
import com.adtcaps.tsop.helper.constant.Const;
import com.adtcaps.tsop.helper.domain.ResultDto;
import com.adtcaps.tsop.helper.util.CommonObjectUtil;

import lombok.extern.slf4j.Slf4j;

/**
 * 
 * <ul>
 * <li>업무 그룹명 : tsop-backend-api</li>
 * <li>서브 업무명 : com.adtcaps.tsop.dashboard.api.mashup.controller</li>
 * <li>설  명 : MashupController.java</li>
 * <li>작성일 : 2020. 12. 4.</li>
 * <li>작성자 : jeonyb4</li>
 * </ul>
 */
@Slf4j
@RestController
@RequestMapping("/api/dashboard/alarms")
public class MashupController {
	
	private final String ERR_MSG_NULL_BLD_ID = "bldId가 없습니다.";
	
	private final String ERR_MSG_NULL_ALARM_GRADE_CD = "alarmGradeCd가 없습니다.";
	
	private final String ERR_MSG_NULL_EVENT_SEQ = "eventSeq가 없습니다.";
	
	private final String ERR_MSG_NULL_SERVICE_CL_CD = "serviceClCd가 없습니다.";
	
	private final String ERR_MSG_NULL_EVENT_DATETIME = "eventDatetime이 없습니다.";
	
	private final String ERR_MSG_NULL_CHECK_YN = "checkYn이 없습니다.";
	
	private final String ERR_MSG_READ_FAIL = "조회에 실패하였습니다.";
	
	private final String ERR_MSG_UPDATE_FAIL = "Update에 실패하였습니다.";
	
	private final String ERR_MSG_PUSH_FAIL = "PUSH를 실패하였습니다.";
	
	@Autowired
	private MashupService mashupService;
	
	/**
	 * 
	 * listAlarmGradeAlarmTotalCount
	 *
	 * @param reqAlarmCurrentStateDto
	 * @return ResponseEntity
	 */
	@SuppressWarnings("rawtypes")
	@GetMapping(value="/alarm-grades/alarm-total-count", produces="application/json; charset=UTF-8")
	public ResponseEntity listAlarmGradeAlarmTotalCount(AlarmCurrentStateDto reqAlarmCurrentStateDto) throws Exception {
		
		ResponseEntity<ResultDto> resEntity = null;
		String returnString = "";
		
		String bldId = StringUtils.defaultString(reqAlarmCurrentStateDto.getBldId());
		if ("".equals(bldId)) {
			log.error(">>>>>> bldId ERROR:{}", ERR_MSG_NULL_BLD_ID);
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_BLD_ID));
			return resEntity;
		}
		
		reqAlarmCurrentStateDto.setCheckYn("");
		
		// 알람등급별 알람 건수 조회
		AlarmGradeAlarmTotalResultDto alarmGradeAlarmTotalResultDto = mashupService.listAlarmGradeAlarmTotalCount(reqAlarmCurrentStateDto);
		if (alarmGradeAlarmTotalResultDto == null) {
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_READ_FAIL, alarmGradeAlarmTotalResultDto));
        } else {
        	returnString = Const.Common.RESULT_CODE.SUCCESS;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, "", alarmGradeAlarmTotalResultDto));
		}

		return resEntity;
	}
	
	/**
	 * 
	 * listAlarmGradeAlarmNonCheck
	 *
	 * @param reqAlarmCurrentStateDto
	 * @return ResponseEntity
	 */
	@SuppressWarnings("rawtypes")
	@GetMapping(value="/alarm-grades/alarm-nocheck-count", produces="application/json; charset=UTF-8")
	public ResponseEntity listAlarmGradeAlarmNonCheck(AlarmCurrentStateDto reqAlarmCurrentStateDto) throws Exception {
		
		ResponseEntity<ResultDto> resEntity = null;
		String returnString = "";
		
		String bldId = StringUtils.defaultString(reqAlarmCurrentStateDto.getBldId());
		if ("".equals(bldId)) {
			log.error(">>>>>> bldId ERROR:{}", ERR_MSG_NULL_BLD_ID);
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_BLD_ID));
			return resEntity;
		}
		
		reqAlarmCurrentStateDto.setCheckYn("N");
		
		// 알람등급별 알람 건수 조회
		AlarmGradeAlarmNoCheckResultDto alarmGradeAlarmNoCheckResultDto = mashupService.listAlarmGradeAlarmNoCheck(reqAlarmCurrentStateDto);
		if (alarmGradeAlarmNoCheckResultDto == null) {
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_READ_FAIL, alarmGradeAlarmNoCheckResultDto));
        } else {
        	returnString = Const.Common.RESULT_CODE.SUCCESS;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, "", alarmGradeAlarmNoCheckResultDto));
		}

		return resEntity;
	}
	
	/**
	 * 
	 * listAlarmGradeCurrentState
	 *
	 * @param alarmGradeCd
	 * @return ResponseEntity
	 */
	@SuppressWarnings("rawtypes")
	@GetMapping(value="/alarm-grades/{alarmGradeCd}/current-state-list", produces="application/json; charset=UTF-8")
	public ResponseEntity listAlarmGradeCurrentState(@PathVariable("alarmGradeCd") String alarmGradeCd, AlarmCurrentStateDto reqAlarmCurrentStateDto) throws Exception {
		
		ResponseEntity<ResultDto> resEntity = null;
		String returnString = "";
		
		String bldId = StringUtils.defaultString(reqAlarmCurrentStateDto.getBldId());
		if ("".equals(bldId)) {
			log.error(">>>>>> bldId ERROR:{}", ERR_MSG_NULL_BLD_ID);
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_BLD_ID));
			return resEntity;
		}
		alarmGradeCd = StringUtils.defaultString(alarmGradeCd);
		if ("".equals(alarmGradeCd)) {
			log.error(">>>>>> alarmGradeCd ERROR:{}", ERR_MSG_NULL_ALARM_GRADE_CD);
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_ALARM_GRADE_CD));
			return resEntity;
		}
		
		reqAlarmCurrentStateDto.setAlarmGradeCd(alarmGradeCd);
		
		// 알람등급별 전체 알람 목록 조회
		List<AlarmCurrentStateDto> alarmCurrentStateDtoList = mashupService.listAlarmGradeCurrentState(reqAlarmCurrentStateDto);
		
		returnString = Const.Common.RESULT_CODE.SUCCESS;
		resEntity = ResponseEntity.ok(new ResultDto(returnString, "", alarmCurrentStateDtoList));
		
		return resEntity;
	}
	
	/**
	 * 
	 * updateNoCheckAlarmToCheck
	 *
	 * @param alarmGradeCd
	 * @param eventSeq
	 * @param reqAlarmCurrentStateDto
	 * @return ResponseEntity
	 */
	@SuppressWarnings("rawtypes")
	@PutMapping(value="/alarm-grades/{alarmGradeCd}/checks/alarm-events/{eventSeq}", produces="application/json; charset=UTF-8")
	public ResponseEntity updateNoCheckAlarmToCheck(@PathVariable("alarmGradeCd") String alarmGradeCd, 
			@PathVariable("eventSeq") int eventSeq, @RequestBody AlarmCurrentStateDto reqAlarmCurrentStateDto) throws Exception {
		
		ResponseEntity<ResultDto> resEntity = null;
		String returnString = "";
		
		alarmGradeCd = StringUtils.defaultString(alarmGradeCd);
		if ("".equals(alarmGradeCd)) {
			log.error(">>>>>> alarmGradeCd ERROR:{}", ERR_MSG_NULL_ALARM_GRADE_CD);
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_ALARM_GRADE_CD));
			return resEntity;
		}
		eventSeq = CommonObjectUtil.defaultNumber((eventSeq));
		if (eventSeq < 1) {
			log.error(">>>>>> eventSeq ERROR:{}", ERR_MSG_NULL_EVENT_SEQ);
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_EVENT_SEQ));
			return resEntity;
		}
		String bldId = StringUtils.defaultString(reqAlarmCurrentStateDto.getBldId());
		if ("".equals(bldId)) {
			log.error(">>>>>> bldId ERROR:{}", ERR_MSG_NULL_BLD_ID);
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_BLD_ID));
			return resEntity;
		}
		String serviceClCd = StringUtils.defaultString(reqAlarmCurrentStateDto.getServiceClCd());
		if ("".equals(serviceClCd)) {
			log.error(">>>>>> serviceClCd ERROR:{}", ERR_MSG_NULL_SERVICE_CL_CD);
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_SERVICE_CL_CD));
			return resEntity;
		}
		String eventDatetime = StringUtils.defaultString(reqAlarmCurrentStateDto.getEventDatetime());
		if ("".equals(eventDatetime)) {
			log.error(">>>>>> eventDatetime ERROR:{}", ERR_MSG_NULL_EVENT_DATETIME);
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_EVENT_DATETIME));
			return resEntity;
		}
		String checkYn = StringUtils.defaultString(reqAlarmCurrentStateDto.getCheckYn());
		if ("".equals(checkYn)) {
			log.error(">>>>>> checkYn ERROR:{}", ERR_MSG_NULL_CHECK_YN);
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_CHECK_YN));
			return resEntity;
		}
		reqAlarmCurrentStateDto.setAlarmGradeCd(alarmGradeCd);
		reqAlarmCurrentStateDto.setEventSeq(eventSeq);
		
		// 미확인 알람 확인 처리...
		int affectRowCount = mashupService.updateNoCheckAlarmToCheck(reqAlarmCurrentStateDto);
		if (affectRowCount < 1) {
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_UPDATE_FAIL, affectRowCount));
        } else {
        	if (affectRowCount == 9999) {
				returnString = Const.Common.RESULT_CODE.FAIL;
				resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_PUSH_FAIL, affectRowCount));
			} else {
				returnString = Const.Common.RESULT_CODE.SUCCESS;
				resEntity = ResponseEntity.ok(new ResultDto(returnString, "", affectRowCount));
			}
		}
    	
		return resEntity;
	}
	
}
