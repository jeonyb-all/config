package com.adtcaps.tsop.dashboard.api.hvac.domain;

import java.util.List;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@ApiModel(value = "층별 재실자 현황 조회 Controller 에서의 결과값", description = "건물의 층별 재실자 현황을 조회하여 보여준다")
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class FloorOccupantResultVO {

	@ApiModelProperty(position = 1 , required = false, value="실제 건물내 정보", example = " ")
    private OfficeInInfoVO officeInInfoVO;     //실제 건물내 정보
	
	@ApiModelProperty(position = 3 , required = false, value="층별재실자 목록", example = " ")
    private List<FloorOccupantInfoVO> floorOccupantInfoList;     //층별재실자 목록

 
}
