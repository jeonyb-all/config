package com.adtcaps.tsop.dashboard.api.mashup.domain;

import lombok.Getter;
import lombok.Setter;

/**
 * 
 * <ul>
 * <li>업무 그룹명 : tsop-backend-api</li>
 * <li>서브 업무명 : com.adtcaps.tsop.dashboard.api.mashup.domain</li>
 * <li>설  명 : AlarmCurrentStateDto.java</li>
 * <li>작성일 : 2020. 12. 4.</li>
 * <li>작성자 : jeonyb4</li>
 * </ul>
 */
@Getter
@Setter
public class AlarmCurrentStateDto {
	private String bldId;
	private String alarmGradeCd;
	private String alarmGradeCdName;
	private String serviceClCd;
	private String serviceClCdName;
	private String objectName;
	private String locFloor;
	private String serviceAlarmCd;
	private String serviceAlarmCdName;
	private String eventDatetime;
	private String checkYn;
	private Integer eventSeq;
	
}
