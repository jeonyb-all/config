package com.adtcaps.tsop.dashboard.api.hvac.domain;

import java.util.List;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@ApiModel(value = "외기 냉방 운영 현황  분석 조회 Controller 에서의 결과값", description = "건물의 층별 실내엔탈피와 실외엔탈피를 비교하여  실외엔탈피 초과,정상,에너지절약권장에 따른 색상을 보여준다.")

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class OutAirCoolAnalysisResultVO {

	@ApiModelProperty(position = 1 , required = false, value="실외 엔탈피 정보", example = " ")
    private OutEnthalpyInfoVO outEnthalpyInfo ;     //실외 엔탈피 정보

	@ApiModelProperty(position = 3 , required = false, value="외기 냉방 층별현황분석 목록", example = " ")
    private List<FloorAmbientAirAnalysisVO> floorAmientAirAnalysisList;     //외기 냉방 층별현황층별현황분석 목록
	
 
}
