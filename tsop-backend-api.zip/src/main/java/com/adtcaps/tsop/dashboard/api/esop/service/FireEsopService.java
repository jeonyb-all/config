package com.adtcaps.tsop.dashboard.api.esop.service;

import java.util.List;

import com.adtcaps.tsop.dashboard.api.esop.domain.EsopContactNetworkMemberDto;
import com.adtcaps.tsop.dashboard.api.esop.domain.EsopProcessResultDto;
import com.adtcaps.tsop.domain.common.OcoKakaoAlimTalkDto;
import com.adtcaps.tsop.domain.esop.EsopMemoDto;
import com.adtcaps.tsop.domain.esop.EsopScenarioDto;
import com.adtcaps.tsop.domain.esop.FireProcessResultDto;
import com.adtcaps.tsop.domain.esop.ProcessResultDetailDto;
import com.adtcaps.tsop.domain.esop.ProcessResultDto;
import com.adtcaps.tsop.domain.esop.ResponseTeamDto;
import com.adtcaps.tsop.domain.esop.WeakAreaDto;

/**
 * <ul>
 * <li>업무 그룹명 : tsop-backend-api</li>
 * <li>서브 업무명 : com.adtcaps.tsop.dashboard.api.esop.service</li>
 * <li>설  명 : FireEsopService.java</li>
 * <li>작성일 : 2021. 12. 20.</li>
 * <li>작성자 : vader</li>
 * </ul>
 */
public interface FireEsopService {
	/**
	 * checkFireProcessResult
	 * @param bldId
	 * @return List<FireProcessResultDto>
	 * @throws Exception
	 */
	public List<FireProcessResultDto> listOpenEsopResult(String bldId) throws Exception;

	/**
	 * listEsopScenarioStep
	 * @param bldId
	 * @return List<EsopScenarioDto>
	 * @throws Exception
	 */
	public List<EsopScenarioDto> listEsopScenarioStep(String bldId) throws Exception;

	/**
	 * listEsopProcessStep
	 * @param bldId
	 * @return List<EsopProcessDto>
	 * @throws Exception
	 */
	public List<EsopProcessResultDto> listEsopProcess(String bldId) throws Exception;

	/**
	 * listEsopMemo
	 * @param bldId
	 * @return List<EsopMemoDto>
	 * @throws Exception
	 */
	public List<EsopMemoDto> listEsopMemo(String bldId) throws Exception;

	/**
	 * listWeakArea
	 * @param weakAreaDto
	 * @return List<WeakAreaDto>
	 * @throws Exception
	 */
	public List<WeakAreaDto> listWeakArea(WeakAreaDto weakAreaDto) throws Exception;

	/**
	 * listWeakAreaAll
	 * @param weakAreaDto
	 * @return List<WeakAreaDto>
	 * @throws Exception
	 */
	public List<WeakAreaDto> listWeakAreaAll(WeakAreaDto weakAreaDto) throws Exception;

	/**
	 * createEsopProcessResult
	 * @param processResultDto
	 * @return int
	 * @throws Exception
	 */
	public int createEsopProcessResult(ProcessResultDto processResultDto) throws Exception;

	/**
	 * createEsopProcessResultDetail
	 * @param processResultDetailDto
	 * @return int
	 * @throws Exception
	 */
	public int createEsopProcessResultDetail(ProcessResultDetailDto processResultDetailDto) throws Exception;

	/**
	 * listEsopProcessResultDetail
	 * @param processResultDetailDto
	 * @return List<ProcessResultDetailDto>
	 * @throws Exception
	 */
	public List<ProcessResultDetailDto> listEsopProcessResultDetail(ProcessResultDetailDto processResultDetailDto) throws Exception;

	/**
	 * updateEsopProcessResult
	 * @param processResultDto
	 * @return int
	 * @throws Exception
	 */
	public int updateEsopProcessResult(ProcessResultDto processResultDto) throws Exception;

	/**
	 * listContactNetworkMember
	 * @param esopContactNetworkMemberDto
	 * @return List<EsopContactNetworkMemberDto>
	 * @throws Exception
	 */
	public List<EsopContactNetworkMemberDto> listContactNetworkMember(EsopContactNetworkMemberDto esopContactNetworkMemberDto) throws Exception;

	/**
	 * getEsopAlimTalkMessage
	 * @param ocoKakaoAlimTalkDto
	 * @return
	 * @throws Exception
	 */
	public OcoKakaoAlimTalkDto readEsopAlimTalkMessage(String fireResultId, String bldId, OcoKakaoAlimTalkDto ocoKakaoAlimTalkDto) throws Exception;

	/**
	 * readTraningEsopAlimTalkMessage
	 * @param fireResultId
	 * @param ocoKakaoAlimTalkDto
	 * @return OcoKakaoAlimTalkDto
	 * @throws Exception
	 */
	public OcoKakaoAlimTalkDto readTraningEsopAlimTalkMessage(String processId, String bldId, OcoKakaoAlimTalkDto ocoKakaoAlimTalkDto) throws Exception;

	/**
	 * setFireAlramManual
	 * @param processResultDto
	 * @return int
	 * @throws Exception
	 */
	public int setFireAlarmManual(ProcessResultDto processResultDto) throws Exception;

	/**
	 * setFireAlarmAuto
	 * @param processId
	 * @param processResultDto
	 * @return int
	 * @throws Exception
	 */
	public int setFireAlarmAuto(String processId, ProcessResultDto processResultDto) throws Exception;

	/**
	 * listProcessResultDetail
	 * @param processResultDetailDto
	 * @return List<ProcessResultDetailDto>
	 * @throws Exception
	 */
	public List<ProcessResultDetailDto> listProcessResultDetail(ProcessResultDetailDto processResultDetailDto) throws Exception;

	/**
	 * readEsopProcessResult
	 * @param processResultDto
	 * @return ProcessResultDto
	 * @throws Exception
	 */
	public ProcessResultDto readEsopProcessResult(ProcessResultDto processResultDto) throws Exception;

	/**
	 * readEsopScenario
	 * @param esopScenarioDto
	 * @return EsopScenarioDto
	 * @throws Exception
	 */
	public EsopScenarioDto readEsopScenario(EsopScenarioDto esopScenarioDto) throws Exception;

	/**
	 * listResponseTeamAll
	 * @param bldId
	 * @return List<ResponseTeamDto>
	 * @throws Exception
	 */
	public List<ResponseTeamDto> listResponseTeamAll(String bldId) throws Exception;
}
