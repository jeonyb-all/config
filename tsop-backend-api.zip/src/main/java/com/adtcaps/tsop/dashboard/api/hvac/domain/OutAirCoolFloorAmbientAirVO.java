package com.adtcaps.tsop.dashboard.api.hvac.domain;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@ApiModel(value = "층별로 외기엔탈피,실내엔탈피,환기온도,댐퍼개도율을 조회한다. ", description = "층별로 외기엔탈피,실내엔탈피,환기온도,댐퍼개도율을 조회한다.")
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class OutAirCoolFloorAmbientAirVO {

	@ApiModelProperty(position = 1 , required = false, value="날짜", example = "202110112312")
    private String queryDate;                      //날짜
	
	@ApiModelProperty(position = 3 , required = false, value="날짜포맷(MM-DD HH24시)", example = "MM-DD HH24시")
    private String dtFormat;                        //날짜포맷
	
	@ApiModelProperty(position = 5 , required = false, value="층정보", example = "2F")
    private String locFloor;                        //층정보

	@ApiModelProperty(position = 7 , required = false, value="외기엔탈피", example = "68.23")
    private Float avgEnthalpyOutVal;                //외기엔탈피
	
	@ApiModelProperty(position = 9 , required = false, value="실내엔탈피", example = "68.12")
    private Float avgEnthalpyInVal;                 //실내엔탈피

	@ApiModelProperty(position = 11 , required = false, value="환기온도", example = "25")
    private Float avgVentilationTemprVal;           //환기온도

	@ApiModelProperty(position = 13 , required = false, value="댐퍼개도율", example = "60")
    private Float avgDamperOpeningRate;             //댐퍼개도율
}
