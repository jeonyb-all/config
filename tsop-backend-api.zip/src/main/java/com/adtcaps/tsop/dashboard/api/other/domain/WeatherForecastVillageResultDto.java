package com.adtcaps.tsop.dashboard.api.other.domain;

import lombok.Getter;
import lombok.Setter;

/**
 * 
 * <ul>
 * <li>업무 그룹명 : tsop-backend-api</li>
 * <li>서브 업무명 : com.adtcaps.tsop.dashboard.api.other.domain</li>
 * <li>설  명 : WeatherForecastVillageResultDto.java</li>
 * <li>작성일 : 2020. 12. 18.</li>
 * <li>작성자 : jeonyb4</li>
 * </ul>
 */
@Getter
@Setter
public class WeatherForecastVillageResultDto {
	private String bldId;
	private String regionName;
	private String predDateHourminute;
	private String skyStatusVal;
	private String hr3TemprVal;
	private String minTemprVal;
	private String maxTemprVal;
	private String rainfallFormCd;
	private String rainfallProbabilityVal;
	private String windspeedVal;

}
