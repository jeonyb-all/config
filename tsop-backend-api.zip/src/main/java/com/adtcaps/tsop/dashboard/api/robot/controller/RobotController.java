package com.adtcaps.tsop.dashboard.api.robot.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.adtcaps.tsop.dashboard.api.robot.domain.RobotBatteryEventChartResultDto;
import com.adtcaps.tsop.dashboard.api.robot.service.RobotService;
import com.adtcaps.tsop.helper.constant.Const;
import com.adtcaps.tsop.helper.domain.ResultDto;

/**
 * 
 * <ul>
 * <li>업무 그룹명 : tsop-backend-api</li>
 * <li>서브 업무명 : com.adtcaps.tsop.dashboard.api.robot.controller</li>
 * <li>설  명 : RobotController.java</li>
 * <li>작성일 : 2020. 12. 4.</li>
 * <li>작성자 : jeonyb4</li>
 * </ul>
 */
@RestController
@RequestMapping("/api/dashboard/robot")
public class RobotController {
	
	private final String ERR_MSG_READ_FAIL = "조회에 실패하였습니다.";
	
	@Autowired
	private RobotService robotService;
	
	/**
	 * 
	 * listRobotBatteryEventChart
	 *
	 * @return ResponseEntity
	 */
	@SuppressWarnings("rawtypes")
	@GetMapping(value="/batteries/current-state-chart", produces="application/json; charset=UTF-8")
	public ResponseEntity listRobotBatteryEventChart() throws Exception {
		
		ResponseEntity<ResultDto> resEntity = null;
		String returnString = "";
		
		// 모든 로봇별 배터리 현황 조회
		RobotBatteryEventChartResultDto robotBatteryEventChartResultDto = robotService.listRobotBatteryEventChart();
		if (robotBatteryEventChartResultDto == null) {
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_READ_FAIL, robotBatteryEventChartResultDto));
        } else {
        	// 레거시 헬스체크 하드코딩
        	robotBatteryEventChartResultDto.setHealthCheckStatus("0");
        	returnString = Const.Common.RESULT_CODE.SUCCESS;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, "", robotBatteryEventChartResultDto));
		}
		
		return resEntity;
	}

}
