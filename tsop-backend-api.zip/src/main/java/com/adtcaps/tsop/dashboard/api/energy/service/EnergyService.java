package com.adtcaps.tsop.dashboard.api.energy.service;

import java.util.List;
import java.util.Map;

import com.adtcaps.tsop.dashboard.api.energy.domain.BldTypeVO;
import com.adtcaps.tsop.dashboard.api.energy.domain.BuildingPowerVO;
import com.adtcaps.tsop.dashboard.api.energy.domain.BuildingTypeVO;
import com.adtcaps.tsop.dashboard.api.energy.domain.BuildingVO;
import com.adtcaps.tsop.dashboard.api.energy.domain.CommonCodeDetailVO;
import com.adtcaps.tsop.dashboard.api.energy.domain.EnergyPowerQnttyVO;
import com.adtcaps.tsop.dashboard.api.energy.domain.PowerConsumptionTrendVO;
import com.adtcaps.tsop.dashboard.api.energy.domain.PowerKwhM2StatVO;
import com.adtcaps.tsop.dashboard.api.energy.domain.WeekendPowerStatVO;
import com.adtcaps.tsop.dashboard.api.energy.type.SortMethod;

public interface EnergyService {

	public List<BuildingVO> getBuildingList();

	public List<EnergyPowerQnttyVO> getPowerList(String bldTypeCd, SortMethod sort);
	public List<PowerKwhM2StatVO> getPowerDensityList();

	public List<WeekendPowerStatVO> getWeekendPowerStat();
	public List<PowerConsumptionTrendVO> getPowerConsumptionTrend(String bldId);
	public List<CommonCodeDetailVO> getCodeDetail(String commonCd);

	public int countBuilding(String bldTypeCd);
	public List<BuildingTypeVO> getBuildingTypeList();

	public Map<String, Object> powerConsumptionTrendChart(String bldId);
	
	
	/**
	 * 
	 * <pre>
	 *  메소드명 : fmBuildingPowerTrendDayWeek
	 *  설    명 : 빌딩 요일별 7일 평균 전력 트랜드 조회
	 *  작 성 일 : 2020. 12. 22.
	 *  작 성 자 : Jeong.HyunMin
	 * </pre>
	 * @param bldId
	 * @return
	 */
	BuildingVO fmBuildingPowerTrendDayWeek(String bldId);
	
	/**
	 * 
	 * <pre>
	 *  메소드명 : fmBuildingPowerTrendHour
	 *  설    명 : 빌딩 시간대별 7일 평균 전력 트랜드 조회
	 *  작 성 일 : 2020. 12. 22.
	 *  작 성 자 : Jeong.HyunMin
	 * </pre>
	 * @param bldId
	 * @return
	 */
	BuildingVO fmBuildingPowerTrendHour(String bldId);
	
	/**
	 * 
	 * <pre>
	 *  메소드명 : fmBldType
	 *  설    명 : 빌딩 유형 목록 조회
	 *  작 성 일 : 2021. 1. 11.
	 *  작 성 자 : Jeong.HyunMin
	 * </pre>
	 * @return
	 */
	List<BldTypeVO> fmBldType();
	
	/**
	 * 
	 * <pre>
	 *  메소드명 : fmBuildingPowerUsage
	 *  설    명 : 빌딩별 전력 사용량 현황
	 *  작 성 일 : 2021. 1. 11.
	 *  작 성 자 : Jeong.HyunMin
	 * </pre>
	 * @param bldType
	 * @param sort
	 * @return
	 */
	List<BuildingPowerVO> fmBuildingPowerUsage(String bldType, String sort);
}
