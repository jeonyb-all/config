package com.adtcaps.tsop.dashboard.api.hvac.domain;

import javax.validation.constraints.Size;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@ApiModel(value = "DB열원 상세정보", description = "건물의 각각 냉방설비에 대해 권장열원(냉수펌프,냉각수펌프), 사용열원(냉수펌프,냉각수펌프)을 조회하여 화면에 보여준다.")
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class BldHeatSourceAllVO { 
	
	@ApiModelProperty(position = 1 , required = false, value="건물ID", example = "0000")
	@Size(min = 1, max = 4, message="건물ID는 4자리입니다")
    private String bldId               ;//건물ID

	@ApiModelProperty(position = 3 , required = false, value="포인트코드", example = "02")
    private String pointCd;     //포인트코드 2100

	@ApiModelProperty(position = 5 , required = false, value="포인트명", example = "냉수펌프")
    private String pointName;     //포인트명 ex)	가동상태, 냉수펌프열원비율  , 냉각수펌프열원비율 
 
	
	@ApiModelProperty(position = 6 , required = false, value="포인트소트", example = "3")
    private Integer pointSortSeq   ;//포인트소트
	
	
	
	@ApiModelProperty(position = 5 , required = false, value="냉동기구분", example = "FM0000005638") 
    private String objectId        ;//오브젝트ID(냉동기구분)
	
	@ApiModelProperty(position = 7 , required = false, value="냉동기명", example = "고층용냉동기2") 
    private String facilityName    ;//장비명(냉동기명)	ex)냉동기1,냉동기2…

	@ApiModelProperty(position = 9 , required = false, value="현재값", example = "ON,OFF,90%,85%") 
	private String currVal        ;//현재값	ex) ON,OFF,90%,85%;//

    private String currStat        ;//현재값    ex) ON,OFF
	
    private String sumDateHour        ;//yyyyMMddHH
    private String sumHour        ;//HH시

	public BldHeatSourceInfoVO toBldHeatSourcInfoVo() {
		BldHeatSourceInfoVO bldHeatSourceVO = new BldHeatSourceInfoVO();
		
		bldHeatSourceVO.setObjectId(this.objectId);
		bldHeatSourceVO.setFacilityName(this.facilityName);
		bldHeatSourceVO.setCurrVal(this.currVal);
		bldHeatSourceVO.setCurrStat(this.currStat);
		
		return bldHeatSourceVO;
	}	
 
 
	 
}
