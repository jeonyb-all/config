package com.adtcaps.tsop.dashboard.api.fm.domain;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class DayWeekVO {
    private String col;
    private String colName;           //콜네임
    private Integer dayVal;           //날짜
    private Integer weekVal;          //데이트포맷
    private Integer totalFacilityCnt; //가동총갯수
}
