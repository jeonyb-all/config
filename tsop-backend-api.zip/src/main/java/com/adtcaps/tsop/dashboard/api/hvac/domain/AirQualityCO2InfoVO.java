package com.adtcaps.tsop.dashboard.api.hvac.domain;

import javax.validation.constraints.Size;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@ApiModel(value = "DB에서 가져오는 빌딩 층의 이전 시간에대한 공기질(CO2) 값 ", description = "DB에서 가져오는빌딩/층의 이전 시간에대한 공기질(CO2) 값")
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class AirQualityCO2InfoVO { 
	 
	@ApiModelProperty(position = 1 , required = false, value="건물ID", example = "0000")
	@Size(min = 1, max = 4, message="건물ID는 4자리입니다")
    private String bldId;//건물ID

	@ApiModelProperty(position = 3 , required = false, value="층ID", example = "3")
	private Integer locId;//층정보
	@ApiModelProperty(position = 3 , required = false, value="층정보", example = "3F")
	private String locFloor;//	층정보
	
	
	private String sumDateHourminute;//12자리  통계시간    현재시간-24~현재시간

 
	@ApiModelProperty(position = 5 , required = false, value="통계시간", example = "13")
	private String hourTime;//	통계시간	현재시간-24~현재시간

    private String deviceLocCd;//  공기질센서위치코드

    private String deviceLocName;//  공기질센서위치명

	@ApiModelProperty(position = 7 , required = false, value="공기질(CO2) 값", example = "26")
	private String airQualityCo2Val;//	 	공기질(CO2) 값

	
	
 

    
}
