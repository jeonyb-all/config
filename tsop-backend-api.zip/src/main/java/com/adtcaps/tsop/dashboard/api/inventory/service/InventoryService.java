package com.adtcaps.tsop.dashboard.api.inventory.service;

import java.util.List;

import com.adtcaps.tsop.dashboard.api.inventory.domain.DashboardLocationResultDto;
import com.adtcaps.tsop.domain.inventory.OivBuildingDto;
import com.adtcaps.tsop.helper.domain.BasePageDto;
import com.adtcaps.tsop.portal.api.building.domain.BuildingGridRequestDto;

/**
 * 
 * <ul>
 * <li>업무 그룹명 : tsop-backend-api</li>
 * <li>서브 업무명 : com.adtcaps.tsop.dashboard.api.inventory.service</li>
 * <li>설  명 : InventoryService.java</li>
 * <li>작성일 : 2020. 12. 4.</li>
 * <li>작성자 : jeonyb4</li>
 * </ul>
 */
public interface InventoryService {
	/**
	 * 
	 * listBuilding
	 *
	 * @param reqBuildingGridRequestDto
	 * @return List<OivBuildingDto>
	 * @throws Exception 
	 */
	public List<OivBuildingDto> listBuilding(BuildingGridRequestDto reqBuildingGridRequestDto) throws Exception;
	
	/**
	 * 
	 * listDashboardLocation
	 * 
	 * @param reqBasePageDto
	 * @return List<DashboardLocationResultDto>
	 * @throws Exception 
	 */
	public List<DashboardLocationResultDto> listDashboardLocation(BasePageDto reqBasePageDto) throws Exception;

}
