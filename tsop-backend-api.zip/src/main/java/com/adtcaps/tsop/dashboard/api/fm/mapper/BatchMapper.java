package com.adtcaps.tsop.dashboard.api.fm.mapper;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

@Mapper
public interface BatchMapper {

	void deleteFmOperationStatusBatch();

	void insertFmOperationStatusBatch();

	void deletePowerUnitBatch();

	void insertPowerUnitBatch();

	void fmEnvironmentBatch(@Param("equipmentCd")String equipmentCd);

	void deleteEnvBy0004();

	void fmEnvironmentRtmBatch();

	void fmEnvironmentHmdBatch();

	void insertMediationData(String bldId, String equipmentCd);

	void fmEnvironmentRtmHmdBatch(String bldId);

	void fmBuildingPointStat(String bldId, String equipmentCd);

	void fmBuildingPointStatClt(String bldId);

	void insertMinMediationData(String bldId, String equipmentCd);

}
