package com.adtcaps.tsop.dashboard.api.energy.domain;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class BuildingPowerTrendVO {
    private String bldId;
    private String bldName;             //건물명
    private String queryDate;           //날짜
    private String dateFormat;          //데이트포맷
    private String dayWeek;             //요일 코드
    private String dayWeekName;         //요일
    private String dayWeekEngName;  //요일
    private String dayWeekEngAbbrName;  //요일
    private String hour;             // 시간        
    private Integer seq;                //순번    
    private Float powerSum;             //전력량 합
    private Float powerAvg;             //전력량 평균
    private Float atpAvg;               //외기온도
}
