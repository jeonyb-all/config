package com.adtcaps.tsop.dashboard.api.hvac.domain;

import java.util.List;

import javax.validation.constraints.Size;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@ApiModel(value = "대기질기준", description = "경보지표 - 대기질기준 목록입니다(엔탈피,PM10,PM2.5)")
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class AirQualityStandardVO { 
	 
	@ApiModelProperty(position = 1 ,required = false, value="건물ID", example = "0000")
	@Size(min = 1, max = 4, message="건물ID는 4자리입니다")
    private String bldId;//건물ID
	
	@ApiModelProperty(position = 3 ,required = false, value="대기질구분코드", example = "01")
	@Size(min = 1, max = 2, message="대기질구분코드는 2자리 입니다.")
    private String managementCategoryCd;//대기질구분코드
	
	@ApiModelProperty(position = 5 ,required = false, value="대기질구분명", example = "초미세먼지(PM2.5)")
	@Size(min = 1, max = 100, message="대기질구분명은 100자리 입니다.")
    private String managementCategoryName;//대기질구분명    ex)엔탈피,PM10,PM2.5
	
	@ApiModelProperty(position = 8 ,required = false, value="대기질구분소트순서", example = "02")
    private Integer managementCategorySortSeq;//대기질구분소트순서
	
	@ApiModelProperty(position = 7 , required = false, value="단위코드명", example = "㎍/㎥")
	@Size(min = 1, max = 100, message="단위코드명은 100자리 입니다.")
    private String managementUnitName      ;//단위명
  
	@ApiModelProperty(position = 7 ,required = false, value="DB기준값여부-대기질기준목록이 구성_관리기준값상세 에서 가져온 경우 Y,환경부기준값인 경우 N", example = "Y")
    private String dbStandardYn;     //DB기준값여부-대기질기준목록이 구성_관리기준값상세 에서 가져온 경우 Y,환경부기준값인 경우 N


	
	@ApiModelProperty(position = 9 ,required = false, value="대기질 기준의 열", example = "")
    private List<AirQualityStatusVO> airQualitStatusList;//대기질 기준의 열

    
}
