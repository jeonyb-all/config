package com.adtcaps.tsop.dashboard.api.hvac.domain;

import java.util.List;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@ApiModel(value = "열원조합 최적화 운영 가이드  조회 Controller에서의 결과값", description = "건물의 각각 냉방설비에 대해 권장열원(냉수펌프,냉각수펌프), 사용열원(냉수펌프,냉각수펌프)을 조회하여 화면에 보여준다.")

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class HeatSourceOptiResultVO { 

	@ApiModelProperty(position = 1 , required = false, value="열원기본정보", example = " ")
    private HeatSourceBaseInfoVO heatSourceBaseInfoVO;     //열원기본정보

	@ApiModelProperty(position = 3 , required = false, value="상세열원정보", example = " ")
    private List<BldHeatSourcePointInfoVO> heatSourceList;     //상세열원
 
}
