package com.adtcaps.tsop.dashboard.api.energy.domain;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString

public class CustomerVO {
	
	private String bldId;                          //빌딩 Id
	private String ismartCustomerName;             //고객명
	private String bizcategoryName;                //업종 카테고리명
	private String contractTypeName;               //계약명
	private Integer useElecenergy;                 //전력사용량

}
