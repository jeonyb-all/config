package com.adtcaps.tsop.dashboard.api.esop.controller;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.adtcaps.tsop.authentication.domain.JwtAuthResultDto;
import com.adtcaps.tsop.dashboard.api.esop.domain.EsopContactNetworkMemberDto;
import com.adtcaps.tsop.dashboard.api.esop.domain.EsopProcessResultDto;
import com.adtcaps.tsop.dashboard.api.esop.service.FireEsopService;
import com.adtcaps.tsop.domain.common.OcoKakaoAlimTalkDto;
import com.adtcaps.tsop.domain.esop.ContactNetworkDto;
import com.adtcaps.tsop.domain.esop.EsopMemoDto;
import com.adtcaps.tsop.domain.esop.EsopScenarioDto;
import com.adtcaps.tsop.domain.esop.FireGradeDto;
import com.adtcaps.tsop.domain.esop.FireProcessResultDto;
import com.adtcaps.tsop.domain.esop.ProcessResultDetailDto;
import com.adtcaps.tsop.domain.esop.ProcessResultDto;
import com.adtcaps.tsop.domain.esop.ResponseTeamDto;
import com.adtcaps.tsop.domain.esop.WeakAreaDto;
import com.adtcaps.tsop.helper.constant.Const;
import com.adtcaps.tsop.helper.domain.ResultDto;
import com.adtcaps.tsop.portal.api.alimTalk.domain.AlimTalkDetailDto;
import com.adtcaps.tsop.portal.api.alimTalk.domain.AlimTalkRequestDto;
import com.adtcaps.tsop.portal.api.alimTalk.service.AlimTalkService;
import com.adtcaps.tsop.portal.api.esop.service.ContactNetworkService;
import com.adtcaps.tsop.portal.api.esop.service.ScenarioService;

@RestController
@RequestMapping("/api/dashboard/esop")
public class FireEsopController {
	private final String ERR_MSG_NULL_LOGIN_USER_ID = "로그인 사용자ID가 없습니다.";
	private final String ERR_MSG_ESOP_NOT_CLOSE = "진행중인 화재가 있습니다.";
	private final String ERR_MSG_ESOP_CREATE_FAIL = "등록에 실패하였습니다.";
	private final String ERR_MSG_UPDATE_FAIL = "수정에 실패하였습니다.";
	private final String ERR_MSG_ALIM_TALK_SEND_FAIL = "알림톡 발송에 실패했습니다.";

	@Autowired
	public FireEsopService fireEsopService;

	@Autowired
	public ContactNetworkService contactNetworkService;

	@Autowired
	public AlimTalkService alimTalkService;

	@Autowired
	public ScenarioService scenarioService;

	/**
	 * checkEsop
	 * @param bldId
	 * @return ResponseEntity
	 * @throws Exception
	 */
	@SuppressWarnings("rawtypes")
	@GetMapping(value="/{bldId}/checkEsop", produces="application/json; charset=UTF-8")
	public ResponseEntity checkEsop(@PathVariable("bldId") String bldId) throws Exception {
		List<FireProcessResultDto> openFireProcessResultDtoList = fireEsopService.listOpenEsopResult(bldId);
		String returnString = Const.Common.RESULT_CODE.SUCCESS;
		ResponseEntity<ResultDto> resEntity = ResponseEntity.ok(new ResultDto(returnString, "", openFireProcessResultDtoList));
		return resEntity;
	}

	/**
	 * getEsopStepsInfo
	 * @param bldId
	 * @return ResponseEntity
	 * @throws Exception
	 */
	@SuppressWarnings("rawtypes")
	@GetMapping(value="/{bldId}/scenarioSteps", produces="application/json; charset=UTF-8")
	public ResponseEntity getEsopScenarioStepsInfo(@PathVariable("bldId") String bldId) throws Exception {
		List<EsopScenarioDto> esopScenarioDtoList = fireEsopService.listEsopScenarioStep(bldId);
		String returnString = Const.Common.RESULT_CODE.SUCCESS;
		ResponseEntity<ResultDto> resEntity = ResponseEntity.ok(new ResultDto(returnString, "", esopScenarioDtoList));
		return resEntity;
	}

	/**
	 * getEsopScenarioStepInfo
	 * @param bldId
	 * @param stepId
	 * @return ResponseEntity
	 * @throws Exception
	 */
	@SuppressWarnings("rawtypes")
	@GetMapping(value="/{bldId}/scenario-step", produces="application/json; charset=UTF-8")
	public ResponseEntity getEsopScenarioStepInfo(@PathVariable("bldId") String bldId) throws Exception {
		ResponseEntity<ResultDto> resEntity = null;
		List<EsopScenarioDto> listEsopScenarioDto = fireEsopService.listEsopScenarioStep(bldId);
		resEntity = ResponseEntity.ok(new ResultDto(Const.Common.RESULT_CODE.SUCCESS, "", listEsopScenarioDto));
		return resEntity;
	}

	/**
	 * getEsopProcess
	 * @param bldId
	 * @return ResponseEntity
	 * @throws Exception
	 */
	@SuppressWarnings("rawtypes")
	@GetMapping(value="/{bldId}/fireSteps", produces="application/json; charset=UTF-8")
	public ResponseEntity getEsopProcess(@PathVariable("bldId") String bldId) throws Exception {
		List<EsopProcessResultDto> listEsopProcessResultDto = fireEsopService.listEsopProcess(bldId);
		String returnString = Const.Common.RESULT_CODE.SUCCESS;
		ResponseEntity<ResultDto> resEntity = ResponseEntity.ok(new ResultDto(returnString, "", listEsopProcessResultDto));
		return resEntity;
	}

	/**
	 * getEsopMemo
	 * @param bldId
	 * @return ResponseEntity
	 * @throws Exception
	 */
	@SuppressWarnings("rawtypes")
	@GetMapping(value="/{bldId}/memos", produces="application/json; charset=UTF-8")
	public ResponseEntity getEsopMemo(@PathVariable("bldId") String bldId) throws Exception {
		List<EsopMemoDto> esopMemoDtoList = fireEsopService.listEsopMemo(bldId);
		String returnString = Const.Common.RESULT_CODE.SUCCESS;
		ResponseEntity<ResultDto> resEntity = ResponseEntity.ok(new ResultDto(returnString, "", esopMemoDtoList));
		return resEntity;
	}

	/**
	 * listWeakArea
	 * @param bldId
	 * @param weakAreaClCd
	 * @return ResponseEntity
	 * @throws Exception
	 */
	@SuppressWarnings("rawtypes")
	@GetMapping(value="/{bldId}/weakArea/{weakAreaClCd}", produces="application/json; charset=UTF-8")
	public ResponseEntity listWeakArea(
			@PathVariable("bldId") String bldId,
			@PathVariable("weakAreaClCd") String weakAreaClCd
			) throws Exception {
		WeakAreaDto weakAreaDto = new WeakAreaDto();
		weakAreaDto.setBldId(bldId);
		weakAreaDto.setWeakAreaClCd(weakAreaClCd);
		List<WeakAreaDto> weakAreaDtoList = fireEsopService.listWeakArea(weakAreaDto);
		ResponseEntity<ResultDto> resEntity = ResponseEntity.ok(new ResultDto(Const.Common.RESULT_CODE.SUCCESS, "", weakAreaDtoList));
		return resEntity;
	}

	/**
	 * listWeakAreaAll
	 * @param bldId
	 * @return ResponseEntity
	 * @throws Exception
	 */
	@SuppressWarnings("rawtypes")
	@GetMapping(value="/{bldId}/weakArea", produces="application/json; charset=UTF-8")
	public ResponseEntity listWeakAreaAll(
			@PathVariable("bldId") String bldId
			) throws Exception {
		WeakAreaDto weakAreaDto = new WeakAreaDto();
		weakAreaDto.setBldId(bldId);
		List<WeakAreaDto> weakAreaDtoList = fireEsopService.listWeakAreaAll(weakAreaDto);
		ResponseEntity<ResultDto> resEntity = ResponseEntity.ok(new ResultDto(Const.Common.RESULT_CODE.SUCCESS, "", weakAreaDtoList));
		return resEntity;
	}

	/**
	 * listWeakArea
	 * @param bldId
	 * @return ResponseEntity
	 * @throws Exception
	 */
	@SuppressWarnings("rawtypes")
	@GetMapping(value="/{bldId}/contact-network", produces="application/json; charset=UTF-8")
	public ResponseEntity listContactNetwork(
			@PathVariable("bldId") String bldId
			) throws Exception {
		ContactNetworkDto contactNetworkDto = new ContactNetworkDto();
		contactNetworkDto.setBldId(bldId);
		List<ContactNetworkDto> contactNetworkDtoList = contactNetworkService.listContactNetwork(contactNetworkDto);
		ResponseEntity<ResultDto> resEntity = ResponseEntity.ok(new ResultDto(Const.Common.RESULT_CODE.SUCCESS, "", contactNetworkDtoList));
		return resEntity;
	}

	/**
	 * listContactNetworkMember
	 * @param bldId
	 * @param contactNetworkId
	 * @return ResponseEntity
	 * @throws Exception
	 */
	@SuppressWarnings("rawtypes")
	@GetMapping(value="/{bldId}/{contactNetworkId}/contact-network-member", produces="application/json; charset=UTF-8")
	public ResponseEntity listContactNetworkMember(
			@PathVariable("bldId") String bldId,
			@PathVariable("contactNetworkId") String contactNetworkId
			) throws Exception {
		EsopContactNetworkMemberDto esopContactNetworkMemberDto = new EsopContactNetworkMemberDto();
		esopContactNetworkMemberDto.setBldId(bldId);
		esopContactNetworkMemberDto.setContactNetworkId(contactNetworkId);
		List<EsopContactNetworkMemberDto> esopContactNetworkMemberDtoList = fireEsopService.listContactNetworkMember(esopContactNetworkMemberDto);
		ResponseEntity<ResultDto> resEntity = ResponseEntity.ok(new ResultDto(Const.Common.RESULT_CODE.SUCCESS, "", esopContactNetworkMemberDtoList));
		return resEntity;
	}

	/**
	 * listFireGrade
	 * @param bldId
	 * @return ResponseEntity
	 * @throws Exception
	 */
	@SuppressWarnings("rawtypes")
	@GetMapping(value="/{bldId}/fireGrades", produces="application/json; charset=UTF-8")
	public ResponseEntity listFireGrade(@PathVariable("bldId") String bldId) throws Exception {
		List<FireGradeDto> fireGradeDtoList = scenarioService.listFireGrade(bldId);
		ResponseEntity<ResultDto> resEntity = ResponseEntity.ok(new ResultDto(Const.Common.RESULT_CODE.SUCCESS, "", fireGradeDtoList));
		return resEntity;
	}

	/**
	 * createFireProcessResult
	 * @param bldId
	 * @param processResultDto
	 * @return ResponseEntity
	 * @throws Exception
	 */
	@SuppressWarnings("rawtypes")
	@PostMapping(value="/{bldId}/alarm", produces="application/json; charset=UTF-8")
	public ResponseEntity createManualAlarm(
			@PathVariable("bldId") String bldId,
			@AuthenticationPrincipal JwtAuthResultDto authResultDto) throws Exception {
		ResponseEntity<ResultDto> resEntity = null;
		String returnString = "";

		String loginUserId = StringUtils.defaultString(authResultDto.getUserId());
		if ("".equals(loginUserId)) {
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_LOGIN_USER_ID));
			return resEntity;
		}
		String loginUserName = StringUtils.defaultString(authResultDto.getUsername());

		ProcessResultDto processResultDto = new ProcessResultDto();
		processResultDto.setBldId(bldId);
		processResultDto.setAuditId(loginUserId);
		processResultDto.setAuditName(loginUserName);

		int affectRowCount = fireEsopService.setFireAlarmManual(processResultDto);
		if (affectRowCount < 1) {
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_ESOP_CREATE_FAIL, affectRowCount));
		} else if (affectRowCount == 999) {
			returnString = Const.Common.RESULT_CODE.SUCCESS;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_ESOP_NOT_CLOSE, affectRowCount));
		} else {
			returnString = Const.Common.RESULT_CODE.SUCCESS;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, "", affectRowCount));
		}
		return resEntity;
	}

	/**
	 * setProcess
	 * @param bldId
	 * @param processResultDetailDto
	 * @return ResponseEntity
	 * @throws Exception
	 */
	@SuppressWarnings("rawtypes")
	@PostMapping(value="/{bldId}/process", produces="application/json; charset=UTF-8")
	public ResponseEntity setProcess(
			@PathVariable("bldId") String bldId,
			@AuthenticationPrincipal JwtAuthResultDto authResultDto,
			@RequestBody ProcessResultDetailDto processResultDetailDto) throws Exception {
		ResponseEntity<ResultDto> resEntity = null;
		String returnString = "";

		String loginUserId = StringUtils.defaultString(authResultDto.getUserId());
		if ("".equals(loginUserId)) {
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_LOGIN_USER_ID));
			return resEntity;
		}
		String loginUserName = StringUtils.defaultString(authResultDto.getUsername());

		processResultDetailDto.setBldId(bldId);
		processResultDetailDto.setAuditId(loginUserId);
		processResultDetailDto.setAuditName(loginUserName);

		int affectRowCount = fireEsopService.createEsopProcessResultDetail(processResultDetailDto);
		if (affectRowCount < 1) {
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_UPDATE_FAIL, affectRowCount));
		} else {
			returnString = Const.Common.RESULT_CODE.SUCCESS;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, "", affectRowCount));
		}
		return resEntity;
	}

	/**
	 * listProcessResultDetail
	 * @param bldId
	 * @param fireResultId
	 * @return ResponseEntity
	 * @throws Exception
	 */
	@SuppressWarnings("rawtypes")
	@GetMapping(value="/{bldId}/{fireResultId}/process/list", produces="application/json; charset=UTF-8")
	public ResponseEntity listEsopProcessResultDetail(
			@PathVariable("bldId") String bldId,
			@PathVariable("fireResultId") String fireResultId) throws Exception {
		ProcessResultDetailDto processResultDetailDto = new ProcessResultDetailDto();
		processResultDetailDto.setBldId(bldId);
		processResultDetailDto.setFireResultId(fireResultId);

		List<ProcessResultDetailDto> processResultDetailDtoList = fireEsopService.listEsopProcessResultDetail(processResultDetailDto);
		ResponseEntity<ResultDto> resEntity = ResponseEntity.ok(new ResultDto(Const.Common.RESULT_CODE.SUCCESS, "", processResultDetailDtoList));
		return resEntity;
	}

	/**
	 * setFireGrade
	 * @param bldId
	 * @param processResultDto
	 * @return ResponseEntity
	 * @throws Exception
	 */
	@SuppressWarnings("rawtypes")
	@PostMapping(value="/{bldId}/fire-grade", produces="application/json; charset=UTF-8")
	public ResponseEntity setFireGrade(
			@PathVariable("bldId") String bldId,
			@AuthenticationPrincipal JwtAuthResultDto authResultDto,
			@RequestBody ProcessResultDto processResultDto) throws Exception {
		ResponseEntity<ResultDto> resEntity = null;
		String returnString = "";
		String loginUserId = StringUtils.defaultString(authResultDto.getUserId());
		if ("".equals(loginUserId)) {
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_LOGIN_USER_ID));
			return resEntity;
		}
		String loginUserName = StringUtils.defaultString(authResultDto.getUsername());
		processResultDto.setBldId(bldId);
		processResultDto.setAuditId(loginUserId);
		processResultDto.setAuditName(loginUserName);
		int affectRowCount = fireEsopService.updateEsopProcessResult(processResultDto);
		if (affectRowCount < 1) {
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_UPDATE_FAIL, affectRowCount));
		} else {
			returnString = Const.Common.RESULT_CODE.SUCCESS;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, "", affectRowCount));
		}
		return resEntity;
	}

	/**
	 * listProcessResultDetail
	 * @param bldId
	 * @param fireResultId
	 * @return ResponseEntity
	 * @throws Exception
	 */
	@SuppressWarnings("rawtypes")
	@GetMapping(value="/{bldId}/{fireResultId}/process/detail", produces="application/json; charset=UTF-8")
	public ResponseEntity listProcessResultDetail(
			@PathVariable("bldId") String bldId,
			@PathVariable("fireResultId") String fireResultId) throws Exception {
		ProcessResultDetailDto reqProcessResultDetailDto = new ProcessResultDetailDto();
		reqProcessResultDetailDto.setBldId(bldId);
		reqProcessResultDetailDto.setFireResultId(fireResultId);
		List<ProcessResultDetailDto> processResultDetailDtoList = fireEsopService.listProcessResultDetail(reqProcessResultDetailDto);
		ResponseEntity<ResultDto> resEntity = ResponseEntity.ok(new ResultDto(Const.Common.RESULT_CODE.SUCCESS, "", processResultDetailDtoList));
		return resEntity;
	}

	/**
	 * readProcessResult
	 * @param bldId
	 * @param fireResultId
	 * @return ResponseEntity
	 * @throws Exception
	 */
	@SuppressWarnings("rawtypes")
	@GetMapping(value="/{bldId}/{fireResultId}/result", produces="application/json; charset=UTF-8")
	public ResponseEntity readProcessResult(
			@PathVariable("bldId") String bldId,
			@PathVariable("fireResultId") String fireResultId) throws Exception {
		ProcessResultDto reqProcessResultDto = new ProcessResultDto();
		reqProcessResultDto.setBldId(bldId);
		reqProcessResultDto.setFireResultId(fireResultId);
		ProcessResultDto resProcessResultDto = fireEsopService.readEsopProcessResult(reqProcessResultDto);
		ResponseEntity<ResultDto> resEntity = ResponseEntity.ok(new ResultDto(Const.Common.RESULT_CODE.SUCCESS, "", resProcessResultDto));
		return resEntity;
	}

	/**
	 * readEsopKakaoAlimTalk
	 * @param bldId
	 * @return ResponseEntity
	 * @throws Exception
	 */
	@SuppressWarnings("rawtypes")
	@GetMapping(value="/{bldId}/{fireResultId}/alim-talk", produces="application/json; charset=UTF-8")
	public ResponseEntity readEsopKakaoAlimTalk(
			@PathVariable("bldId") String bldId,
			@PathVariable("fireResultId") String fireResultId,
			OcoKakaoAlimTalkDto reqOcoKakaoAlimTalkDto) throws Exception {
		reqOcoKakaoAlimTalkDto.setSmsCreateCd(Const.Code.SMS_CREATE_CD.ESOP);
		OcoKakaoAlimTalkDto resOcoKakaoAlimTalkDto = fireEsopService.readEsopAlimTalkMessage(fireResultId, bldId, reqOcoKakaoAlimTalkDto);
		ResponseEntity<ResultDto> resEntity = ResponseEntity.ok(new ResultDto(Const.Common.RESULT_CODE.SUCCESS, "", resOcoKakaoAlimTalkDto));
		return resEntity;
	}

	/**
	 * readTraningEsopKakaoAlimTalk
	 * @param bldId
	 * @param processId
	 * @param reqOcoKakaoAlimTalkDto
	 * @return ResponseEntity
	 * @throws Exception
	 */
	@SuppressWarnings("rawtypes")
	@GetMapping(value="/{bldId}/{processId}/alim-talk/training", produces="application/json; charset=UTF-8")
	public ResponseEntity readTraningEsopKakaoAlimTalk(
			@PathVariable("bldId") String bldId,
			@PathVariable("processId") String processId,
			OcoKakaoAlimTalkDto reqOcoKakaoAlimTalkDto) throws Exception {
		reqOcoKakaoAlimTalkDto.setSmsCreateCd(Const.Code.SMS_CREATE_CD.ESOP);
		OcoKakaoAlimTalkDto resOcoKakaoAlimTalkDto = fireEsopService.readTraningEsopAlimTalkMessage(processId, bldId, reqOcoKakaoAlimTalkDto);
		ResponseEntity<ResultDto> resEntity = ResponseEntity.ok(new ResultDto(Const.Common.RESULT_CODE.SUCCESS, "", resOcoKakaoAlimTalkDto));
		return resEntity;
	}

	/**
	 * sendAlimTalk
	 * @param bldId
	 * @param alimTalkRequestDto
	 * @param request
	 * @return ResponseEntity
	 * @throws Exception
	 */
	@SuppressWarnings("rawtypes")
	@PostMapping(value="/{bldId}/alim-talk", produces="application/json; charset=UTF-8")
	public ResponseEntity sendAlimTalk(
			@PathVariable("bldId") String bldId,
			@RequestBody AlimTalkRequestDto alimTalkRequestDto,
			@AuthenticationPrincipal JwtAuthResultDto authResultDto,
			HttpServletRequest request) throws Exception {
		ResponseEntity<ResultDto> resEntity = null;
		alimTalkRequestDto.setSmsCreateCd(Const.Code.SMS_CREATE_CD.ESOP);
		String returnString = "";
		alimTalkRequestDto.setBldId(bldId);
		alimTalkRequestDto.setSmsCreateCd(Const.Code.SMS_CREATE_CD.ESOP);

		String loginUserId = StringUtils.defaultString(authResultDto.getUserId());
		if ("".equals(loginUserId)) {
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_LOGIN_USER_ID));
			return resEntity;
		}
		String loginUserName = StringUtils.defaultString(authResultDto.getUsername());
		alimTalkRequestDto.setAuditId(loginUserId);
		alimTalkRequestDto.setAuditName(loginUserName);

		List<AlimTalkDetailDto> alimTalkDetailDtoList = new ArrayList<AlimTalkDetailDto>();

		String[] recipientList = alimTalkRequestDto.getRecipient().split(",");
		String[] rcverIdList = alimTalkRequestDto.getRcverIdList();
		String[] empIdList = alimTalkRequestDto.getEmpIdList();
		String[] rcverNameList = alimTalkRequestDto.getRcverNameList();

		int i = 0;
		for (String target : recipientList) {
			AlimTalkDetailDto alimTalkDetailDto = new AlimTalkDetailDto();

			if (!"".equals(StringUtils.defaultString(rcverIdList[i]))) {
				alimTalkDetailDto.setRcverId(rcverIdList[i]);
			}

			alimTalkDetailDto.setRcverName(rcverNameList[i]);
			alimTalkDetailDto.setRcvPhoneNum(target);

			if ("".equals(StringUtils.defaultString(rcverIdList[i])) && !"".equals(StringUtils.defaultString(empIdList[i]))) {
				alimTalkDetailDto.setEmpId(empIdList[i]);
			}

			alimTalkDetailDtoList.add(alimTalkDetailDto);
			i++;
		}

		alimTalkRequestDto.setDetailList(alimTalkDetailDtoList);

		String alarmNoticeResultCd = alimTalkService.sendAlimTalk(alimTalkRequestDto);

		if (alarmNoticeResultCd.equals(Const.Code.ALARM_NOTICE_RESULT_CD.SMS) || alarmNoticeResultCd.equals(Const.Code.ALARM_NOTICE_RESULT_CD.ALIMTALK)) {
			returnString = Const.Common.RESULT_CODE.SUCCESS;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, "", alarmNoticeResultCd));
		} else {
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_ALIM_TALK_SEND_FAIL, alarmNoticeResultCd));
		}
		return resEntity;
	}

	/**
	 * listResponseTeam
	 * @param bldId
	 * @return ResponseEntity
	 * @throws Exception
	 */
	@SuppressWarnings("rawtypes")
	@GetMapping(value="/{bldId}/responseteam", produces="application/json; charset=UTF-8")
	public ResponseEntity listResponseTeam(
			@PathVariable("bldId") String bldId) throws Exception {
		List<ResponseTeamDto> responseTeamDtoList = fireEsopService.listResponseTeamAll(bldId);
		ResponseEntity<ResultDto> resEntity = ResponseEntity.ok(new ResultDto(Const.Common.RESULT_CODE.SUCCESS, "", responseTeamDtoList));
		return resEntity;
	}
}
