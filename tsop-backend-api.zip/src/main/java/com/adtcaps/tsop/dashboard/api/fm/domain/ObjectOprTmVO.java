package com.adtcaps.tsop.dashboard.api.fm.domain;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class ObjectOprTmVO {
	private String bldId;
	private String objId;			                   //objectId
	private String facilityOrgName;                    //오리지날 명
	private String facilityName;                       //명
	private Integer opertateTmDay;                     //어제 가동시간
	private Integer opertateTmMonth;                   //기준달 가동시간
}
