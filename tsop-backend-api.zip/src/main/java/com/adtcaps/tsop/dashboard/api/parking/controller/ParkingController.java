package com.adtcaps.tsop.dashboard.api.parking.controller;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.adtcaps.tsop.dashboard.api.parking.domain.ParkingInoutEventChartResultDto;
import com.adtcaps.tsop.dashboard.api.parking.service.ParkingService;
import com.adtcaps.tsop.domain.parking.OpaParkingInoutEventDto;
import com.adtcaps.tsop.helper.constant.Const;
import com.adtcaps.tsop.helper.domain.ResultDto;

import lombok.extern.slf4j.Slf4j;

/**
 * 
 * <ul>
 * <li>업무 그룹명 : tsop-backend-api</li>
 * <li>서브 업무명 : com.adtcaps.tsop.dashboard.api.parking.controller</li>
 * <li>설  명 : ParkingController.java</li>
 * <li>작성일 : 2020. 12. 4.</li>
 * <li>작성자 : jeonyb4</li>
 * </ul>
 */
@Slf4j
@RestController
@RequestMapping("/api/dashboard/parking")
public class ParkingController {
	
	private final String ERR_MSG_NULL_BLD_ID = "bldId가 없습니다.";
	
	private final String ERR_MSG_NULL_SEARCH_RESULT_LIST = "조회 결과가 없습니다.";
	
	@Autowired
	private ParkingService parkingService;
	
	/**
	 * 
	 * listParkingInoutEventCurrentStateLineChart
	 *
	 * @param reqOpaParkingInoutEventDto
	 * @return ResponseEntity
	 */
	@SuppressWarnings("rawtypes")
	@GetMapping(value="/inout-events/line-chart", produces="application/json; charset=UTF-8")
	public ResponseEntity listParkingInoutEventCurrentStateLineChart(OpaParkingInoutEventDto reqOpaParkingInoutEventDto) throws Exception {
		
		ResponseEntity<ResultDto> resEntity = null;
		String returnString = "";
		
		String bldId = StringUtils.defaultString(reqOpaParkingInoutEventDto.getBldId());
		if ("".equals(bldId)) {
			log.error(">>>>>> bldId ERROR:{}", ERR_MSG_NULL_BLD_ID);
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_BLD_ID));
			return resEntity;
		}
		
		// 빌딩별 주차 입출차현황 Line 차트 조회
		ParkingInoutEventChartResultDto parkingInoutEventChartResultDto = parkingService.listParkingInoutEventCurrentStateLineChart(reqOpaParkingInoutEventDto);
		if (parkingInoutEventChartResultDto == null) {
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_SEARCH_RESULT_LIST, parkingInoutEventChartResultDto));
        } else {
        	returnString = Const.Common.RESULT_CODE.SUCCESS;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, "", parkingInoutEventChartResultDto));
		}
		
		return resEntity;
	}
	
}
