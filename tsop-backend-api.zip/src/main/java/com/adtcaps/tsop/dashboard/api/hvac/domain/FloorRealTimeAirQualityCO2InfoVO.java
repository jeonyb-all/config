package com.adtcaps.tsop.dashboard.api.hvac.domain;

import java.util.List;

import javax.validation.constraints.Size;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@ApiModel(value = "층별 재실자 현황 상세-공기질(CO2) 현황", description = "건물의 층별 최근 시간부터 24시간 전까지의 공기질(CO2)현황을 보여준다.")
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class FloorRealTimeAirQualityCO2InfoVO { 
	 
	@ApiModelProperty(position = 1 , required = false, value="건물ID", example = "0000")
	@Size(min = 1, max = 4, message="건물ID는 4자리입니다")
    private String bldId;//건물ID
	@ApiModelProperty(position = 3 , required = false, value="층ID", example = "3")
	private Integer locId;//층정보

	@ApiModelProperty(position = 3 , required = false, value="층정보", example = "3F")
	private String locFloor;//층정보

    private Integer  airQualityCo2BaseVal ;// 공기질CO2 기준값 900이상이면 빨간색
    
	@ApiModelProperty(position = 5 , required = false, value="층별 이전24시 공기질(CO2) 값	", example = "")
	private List<FloorPreHourAirQualityCO2AllVO> hourList;//층별 이전24시 공기질(CO2) 값   현재시간-24~현재시간

    
}
