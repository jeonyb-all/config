package com.adtcaps.tsop.dashboard.api.hvac.domain;

import io.swagger.annotations.ApiModel;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@ApiModel(value = "층별권장환기량 기본정보", description = "층별권장환기량 기본정보을 조회한다.")

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class RecmdVentiBaseInfoVO {

 
    private String  sumDateHourminute   ;//기준시간    : 년월일시분
    private String  simpleHourminute   ;// 기준시간    : HH시mm분
	     
 

	 
}
