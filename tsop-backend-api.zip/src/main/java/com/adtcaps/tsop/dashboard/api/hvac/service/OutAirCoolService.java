package com.adtcaps.tsop.dashboard.api.hvac.service;

import com.adtcaps.tsop.dashboard.api.hvac.domain.FloorAmbientAirCurrInfoVO;
import com.adtcaps.tsop.dashboard.api.hvac.domain.OutAirCoolAnalysisResultVO;
import com.adtcaps.tsop.dashboard.api.hvac.domain.OutAirCoolOperationResultVO;
import com.adtcaps.tsop.dashboard.api.hvac.domain.OutFloorAmbientAirResultVO;

public interface OutAirCoolService {
 
    public OutFloorAmbientAirResultVO findOutAirCoolFloorOperationPreDay(String bldId,String floor);
    
	public OutAirCoolOperationResultVO findOutAirCoolFloorOperation(String bldId,String floor);
	 
	public OutAirCoolAnalysisResultVO findOutAirCoolOperationAnalysis(String bldId);
	public FloorAmbientAirCurrInfoVO findOutAirCoolOperationAnalysisPopup(String bldId,String floor);
	 
 
	 
}
