package com.adtcaps.tsop.dashboard.api.fm.service;

public interface BatchService {

	void fmOperationStatusBatch();

	void powerUnitBatch();

	void fmBatch();

	void fmEnvironmentBatch();

	void fmCollectWorkingTime();

	void fmBuildingPointStat();

}
