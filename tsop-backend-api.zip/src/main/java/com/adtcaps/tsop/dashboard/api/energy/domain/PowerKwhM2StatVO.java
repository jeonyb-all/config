package com.adtcaps.tsop.dashboard.api.energy.domain;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class PowerKwhM2StatVO {

	private String bldId;
	private int dayOfWeek;
	private String dayOfWeekName;
	private Float powerVal;
	private String statDate;
}
