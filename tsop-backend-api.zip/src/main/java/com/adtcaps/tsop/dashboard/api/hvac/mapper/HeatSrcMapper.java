package com.adtcaps.tsop.dashboard.api.hvac.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;

import com.adtcaps.tsop.dashboard.api.hvac.domain.AirQualityStatusAllVO;
import com.adtcaps.tsop.dashboard.api.hvac.domain.BldHeatSourceAllVO;
import com.adtcaps.tsop.dashboard.api.hvac.domain.InEnthalpyStandardVO;
import com.adtcaps.tsop.dashboard.api.hvac.domain.lntegratedAirEnvirVO;

@Mapper
public interface HeatSrcMapper {
	/**
	 * 실시간 통합대기환경 분석 조회
	 * @param bldId
	 * @return
	 */
	//통합대기환경값
	public lntegratedAirEnvirVO getlntegratedAirEnvirInfo(String bldId);
	
	//실내엔탈피 기준 
    public InEnthalpyStandardVO getInEnthalpyStandardInfo(String bldId);
	

	//대기질 기준 목록
	public List<AirQualityStatusAllVO> getAirQualityStatusList(String bldId);
	
	/**
	 * 열원조합 최적화 운영 가이드 조회
	 * @param bldId
	 * @return
	 */ 
	public List<BldHeatSourceAllVO> getHeatSourceList(String bldId); 
    
 
	 
}
