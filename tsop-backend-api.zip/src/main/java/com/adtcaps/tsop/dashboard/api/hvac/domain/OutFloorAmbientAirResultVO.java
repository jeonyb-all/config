package com.adtcaps.tsop.dashboard.api.hvac.domain;

import java.util.List;

import com.adtcaps.tsop.dashboard.api.fm.domain.FloorAmbientAirVO;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@ApiModel(value = "외기 냉방 운영 현황  조회 Controller 에서의 결과값", description = "건물의 층별 외기냉방 현황(댐퍼개도율,환기온도,실내/실외엔탈피) 및 실내엔탈피 기준을 최근 시분으로 조회하여 보여준다.")

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class OutFloorAmbientAirResultVO {

	@ApiModelProperty(position = 1 , required = false, value="실내엔탈피 기준", example = " ")
    private InEnthalpyStandardVO inEnthalpyStandard;     //실내엔탈피 기준

	@ApiModelProperty(position = 3 , required = false, value="외기 냉방 층별현황 목록", example = " ")
    private List<FloorAmbientAirVO> floorAmientAirList;     //전일외기 냉방 층별현황 목록

}
