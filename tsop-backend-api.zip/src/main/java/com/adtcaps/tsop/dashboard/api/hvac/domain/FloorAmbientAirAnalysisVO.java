package com.adtcaps.tsop.dashboard.api.hvac.domain;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@ApiModel(value = "층별로 실내엔탈피 기준,실내엔탈피,외기냉방분석값 조회", description = "층별로 실내엔탈피 기준,실내엔탈피,외기냉방분석값 조회을 조회한다.")

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class FloorAmbientAirAnalysisVO {

	@ApiModelProperty(position = 1 , required = false, value="날짜", example = "202110112312")
    private String queryDate;                      //날짜
	
	@ApiModelProperty(position = 3 , required = false, value="날짜포맷(MM-DD HH24시)", example = "MM-DD HH24시")
    private String dtFormat;                        //날짜포맷
	
	@ApiModelProperty(position = 5 , required = false, value="층정보", example = "2F")
    private String locFloor;                        //층정보


	@ApiModelProperty(position = 7 , required = false, value="실내온도값", example = "26") 
	private String inTemprVal	;//	실내온도값(환기온도 값)  , - 를 주기 위해 String으로 변경
	//private Integer inTemprVal ;// 실내온도값(환기온도 값)
	
	@ApiModelProperty(position = 9 , required = false, value="실내습도값", example = "79") 
	private String inHumidityVal	;//	실내습도값(환기습도 값) , - 를 주기 위해 String으로 변경
    //private Integer inHumidityVal ;// 실내습도값(환기습도 값)
	
	@ApiModelProperty(position = 11 , required = false, value="실내엔탈피값", example = "68.93") 
	private String inEnthalpyVal	;//	실내엔탈피값 , - 를 주기 위해 String으로 변경
    //private Float inEnthalpyVal   ;// 실내엔탈피값
	

	@ApiModelProperty(position = 13 , required = false, value="실내온도 기준값", example = "26") 
	private Integer inTemprStndVal	;//	실내온도 기준값 
	
	@ApiModelProperty(position = 15 , required = false, value="실내습도 기준값", example = "79") 
	private Integer inHumidityStndVal	;//	실내습도 기준값 
	
	@ApiModelProperty(position = 17 , required = false, value="실내엔탈피 기준값", example = "68.93") 
	private Float inEnthalpyStndVal	;//	실내엔탈피 기준값
	
	
    private String dbStandardYn ;//DB기준여부
		
	 

	@ApiModelProperty(position = 21 , required = false, value="외기냉방분석값", example = "1:정상,2:실외엔탈피 초과,3:에너지세이빙권장,4:기타")
    private String airCoolAnalysisVal;                 //외기냉방분석값
 

	 
}
