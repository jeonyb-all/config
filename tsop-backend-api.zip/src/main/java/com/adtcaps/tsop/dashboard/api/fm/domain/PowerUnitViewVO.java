package com.adtcaps.tsop.dashboard.api.fm.domain;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@NoArgsConstructor
@Getter
@Setter
@ToString
public class PowerUnitViewVO {
	private String groupName;
	private String buildingName;
	private String maxBldAbbrName;
	private String minBldAbbrName;
	private float avg;
	private float val;
	
}
