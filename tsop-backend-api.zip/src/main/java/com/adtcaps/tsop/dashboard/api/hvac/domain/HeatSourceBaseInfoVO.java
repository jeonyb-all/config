package com.adtcaps.tsop.dashboard.api.hvac.domain;

import javax.validation.constraints.Size;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@ApiModel(value = "열원기본정보", description = "사용시분,사용년월일시분")

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class HeatSourceBaseInfoVO { 

	@ApiModelProperty(position = 1 , required = false, value="건물ID", example = "0000")
	@Size(min = 1, max = 4, message="건물ID는 4자리입니다")
    private String bldId               ;//건물ID

    private String bldName               ;//건물명
	  
	//@ApiModelProperty(position = 3 , required = false, value="사용년월일시분(12자리)", example = "2021-10-13 22:30")
    //private String useDateHourminute;     //사용년월일시분(12자리)

	//@ApiModelProperty(position = 5 , required = false, value="사용시분", example = "22:30")
    //private String useHourminute;     //사용시분
    private String currDateHour     ;     //실시간    : 년월일시
    private String currHour;     //실시간    : HH시
    
 
}
