package com.adtcaps.tsop.dashboard.api.hvac.service.impl;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.adtcaps.tsop.dashboard.api.hvac.domain.AirEnvirResultVO;
import com.adtcaps.tsop.dashboard.api.hvac.domain.AirQualityStandardVO;
import com.adtcaps.tsop.dashboard.api.hvac.domain.AirQualityStatusAllVO;
import com.adtcaps.tsop.dashboard.api.hvac.domain.AirQualityStatusVO;
import com.adtcaps.tsop.dashboard.api.hvac.domain.BldHeatSourceAllVO;
import com.adtcaps.tsop.dashboard.api.hvac.domain.BldHeatSourceInfoVO;
import com.adtcaps.tsop.dashboard.api.hvac.domain.BldHeatSourcePointInfoVO;
import com.adtcaps.tsop.dashboard.api.hvac.domain.HeatSourceBaseInfoVO;
import com.adtcaps.tsop.dashboard.api.hvac.domain.HeatSourceOptiResultVO;
import com.adtcaps.tsop.dashboard.api.hvac.domain.InEnthalpyStandardVO;
import com.adtcaps.tsop.dashboard.api.hvac.domain.OutEnthalpyStandardInfoVO;
import com.adtcaps.tsop.dashboard.api.hvac.domain.lntegratedAirEnvirVO;
import com.adtcaps.tsop.dashboard.api.hvac.mapper.HeatSrcMapper;
import com.adtcaps.tsop.dashboard.api.hvac.mapper.HvacCommonMapper;
import com.adtcaps.tsop.dashboard.api.hvac.service.HeatSrcOptimService;
import com.adtcaps.tsop.dashboard.api.hvac.util.StreamMapUtil;
import com.adtcaps.tsop.domain.hvac.vo.HvacCurrentDateInfoVO;

import io.swagger.annotations.ApiModelProperty;
import lombok.extern.slf4j.Slf4j;
@Slf4j
@Service
public class HeatSrcOptimServiceImpl implements HeatSrcOptimService{

    @Autowired
    private HeatSrcMapper heatSrcMapper;

    //현재시간  15분단위 : 년월일시분,15분단위 : HH시mm분
    @Autowired
    private HvacCommonMapper hvacCommonMapper;
  
    /** 
     * <pre>
     *  메소드명 : findRealTimeIntegratedAir
     *  설    명 : 실시간 통합대기환경  분석  조회
     *  작 성 일 : 2021.10.13. 
     * </pre>
     * @return  
     */ 
    @Override
    public AirEnvirResultVO findRealTimeIntegratedAir(String bldId) {
        AirEnvirResultVO airEnvirResultVO= new AirEnvirResultVO();
         
        HvacCurrentDateInfoVO hvacCurrentDateInfoVO = hvacCommonMapper.selectHvacCurrentDate();
        String baseDateHourminute        = hvacCurrentDateInfoVO.getBase15DateHourminute();//15분단위 : 년월일시분
        String base15KorSimpleHourminute = hvacCurrentDateInfoVO.getBase15KorSimpleHourminute();//15분단위 : HH시mm분

        String currDateHourminute      = hvacCurrentDateInfoVO.getCurrDateHourminute()     ;//실시간    : 년월일시분
        String currKorSimpleHourminute = hvacCurrentDateInfoVO.getCurrKorSimpleHourminute();//실시간    : HH시mm분
        String currDateHour            = hvacCurrentDateInfoVO.getCurrDateHour()           ;//실시간    : 년월일시
        String currKorSimpleHour       = hvacCurrentDateInfoVO.getCurrKorSimpleHour()      ;//실시간    : HH시
  
        
        //통합대기환경값
        lntegratedAirEnvirVO integratedAirEnvirVO = heatSrcMapper.getlntegratedAirEnvirInfo( bldId);
        if(integratedAirEnvirVO ==null) {
            log.debug("실시간 통합대기환경  분석  조회 -  기준시간 null : 설비_외부환경15분집계 및  실외엔탈피 정보 확인 필요");
            integratedAirEnvirVO = new lntegratedAirEnvirVO();
            integratedAirEnvirVO.setSumDateHourminute(currDateHourminute);
            integratedAirEnvirVO.setSimpleHourminute (currKorSimpleHourminute);
            integratedAirEnvirVO.setSimpleHour       (currKorSimpleHour); 
        } 
        //측정소명
        if(   integratedAirEnvirVO.getMeasureStationName() == null
                || "".equals(integratedAirEnvirVO.getMeasureStationName())
              ) {
                integratedAirEnvirVO.setMeasureStationName("-");
        }
        //외부엔탈피,미세,초미세 농도값이 null값일때  -값으로
        if(             integratedAirEnvirVO.getOutdoorEnthalpyVal() == null
           || "".equals(integratedAirEnvirVO.getOutdoorEnthalpyVal())
         ) {
           integratedAirEnvirVO.setOutdoorEnthalpyVal("-");
        }
        if(           integratedAirEnvirVO.getOutdoorEnthalpyValName() == null
         || "".equals(integratedAirEnvirVO.getOutdoorEnthalpyValName())
         ) {
           integratedAirEnvirVO.setOutdoorEnthalpyValName("데이터 없음");
        } 
        //미세먼지값
        if(           integratedAirEnvirVO.getFineDustVal() == null
         || "".equals(integratedAirEnvirVO.getFineDustVal())
         ) {
           integratedAirEnvirVO.setFineDustVal("-");
        } 
        //미세먼지명
        if(           integratedAirEnvirVO.getFineDustValName() == null
         || "".equals(integratedAirEnvirVO.getFineDustValName())
          ) {
           integratedAirEnvirVO.setFineDustValName("데이터 없음");
        } 
        //초미세먼지값
        if(            integratedAirEnvirVO.getUltraFineDustVal() == null
          || "".equals(integratedAirEnvirVO.getUltraFineDustVal())
           ){
           integratedAirEnvirVO.setUltraFineDustVal("-");
        } 
        //초미세먼지명
        if(            integratedAirEnvirVO.getUltraFineDustValName() == null 
          || "".equals(integratedAirEnvirVO.getUltraFineDustValName())                
                ) {
           integratedAirEnvirVO.setUltraFineDustValName("데이터 없음");
        } 
  
        //실외엔탈피 기준 
        InEnthalpyStandardVO inEnthalpyStandardVO = heatSrcMapper.getInEnthalpyStandardInfo( bldId);
        
        //대기질 기준 DB 목록
        List<AirQualityStatusAllVO> dbAirQualityStatusAllList = heatSrcMapper.getAirQualityStatusList( bldId);
  
        //대기질 기준 목록
        List<AirQualityStandardVO> airQualityList = new ArrayList<AirQualityStandardVO>();

        //1:미세먼지,2:초미세먼지,3:실외엔탈피 목록 가져오기
        List<AirQualityStatusAllVO>  categoryList 
            = dbAirQualityStatusAllList.stream() 
                              .filter(StreamMapUtil.distinctByKeys( AirQualityStatusAllVO::getManagementCategoryCd
                                                                   ,AirQualityStatusAllVO::getManagementCategoryName
                                                   )
                                 ) .collect(Collectors.toList());
       
        //1:미세먼지,2:초미세먼지,3:실외엔탈피 목록  3번 루프
        categoryList.forEach(categoryInfo->{

            //대기질구분코드 상세목록
            List<AirQualityStatusAllVO>  detailList 
               = dbAirQualityStatusAllList.stream().filter(detailInfo ->   
                                                //categoryInfo.getBldId().equals(exceptionDetailInfo.getBldId() )  
                                                 categoryInfo.getManagementCategoryCd().equals(detailInfo.getManagementCategoryCd() )
                                     )
                 .collect(Collectors.toList());
            
            //DB기준값여부
            List<AirQualityStatusAllVO>  dbStandardYnList 
                = detailList.stream() 
                              .filter(StreamMapUtil.distinctByKeys( AirQualityStatusAllVO::getManagementCategoryCd
                                                                   ,AirQualityStatusAllVO::getDbStandardYn
                                                   )
                                 ) .collect(Collectors.toList());
            //DB기준값여부-대기질기준목록이 구성_관리기준값상세 에서 가져온 경우 Y,환경부기준값인 경우 N
            String dbStandardYn = null;
            if(dbStandardYnList==null || dbStandardYnList.isEmpty())  {
            	dbStandardYn = "N";
            }else {
            	dbStandardYn = dbStandardYnList.get(0).getDbStandardYn();
            }
            
            //화면에서보여주는 기준값
            List<AirQualityStatusVO>  airQualitStatusList 
                =  detailList.stream()
                    .map(AirQualityStatusAllVO::toAirQualityStatusVo)
            		.collect(Collectors.toList());
            
            AirQualityStandardVO airQualityStandardVO  = new AirQualityStandardVO(); 
            
            //대기질 구분(실외엔탈피,PM10,PM2.5) 별 각각 상세 데이터   
            airQualityStandardVO.setBldId(categoryInfo.getBldId());
            airQualityStandardVO.setManagementCategoryCd(categoryInfo.getManagementCategoryCd());
            airQualityStandardVO.setManagementCategoryName(categoryInfo.getManagementCategoryName());
            airQualityStandardVO.setManagementUnitName(categoryInfo.getManagementUnitName());
            airQualityStandardVO.setManagementCategorySortSeq(categoryInfo.getManagementCategorySortSeq());
            airQualityStandardVO.setDbStandardYn(dbStandardYn);
            airQualityStandardVO.setAirQualitStatusList(airQualitStatusList); 
            
            // 
            airQualityList.add(airQualityStandardVO); 

        //}
        });//forEach
        
        //대기질 구분(실외엔탈피,PM10,PM2.5)별 소트 
        Comparator<AirQualityStandardVO> compare 
           = Comparator .comparing(AirQualityStandardVO::getBldId)
	                   .thenComparingInt(AirQualityStandardVO::getManagementCategorySortSeq)
 		           // .thenComparing(AirQualityStandardVO::getAlarmExceptionId)
         	       // .thenComparing(AirQualityStandardVO::getAlarmExceptionCategoryCd)
 	         	//.thenComparingInt(OivAlarmExceptionAllDto::getAlarmExceptionSeq)
         	        ; 
        List<AirQualityStandardVO>  resultAirQualityList = airQualityList.stream()
	               .sorted( compare).collect(Collectors.toList());
        
  
        airEnvirResultVO.setIntegratedAirEnvir(integratedAirEnvirVO);//대기질 기준 목록
        airEnvirResultVO.setInEnthalpyStandardInfo(inEnthalpyStandardVO);//실외엔탈피 기준 
        airEnvirResultVO.setAirQualityList(resultAirQualityList);  //실제 통합대기환경값
         
        
        return airEnvirResultVO;
    }

    /** 
     * <pre>
     *  메소드명 : findHeatSourceOptimize
     *  설    명 : 열원조합 최적화 운영 가이드  조회
     *  작 성 일 : 2021.10.13. 
     * </pre>
     * @return  
     */ 
    @Override
    public HeatSourceOptiResultVO findHeatSourceOptimize(String bldId,String bldName) {
        HeatSourceOptiResultVO heatSourceOptiResultVO= new HeatSourceOptiResultVO();
 
        HvacCurrentDateInfoVO hvacCurrentDateInfoVO = hvacCommonMapper.selectHvacCurrentDate();
        String currDateHourminute = hvacCurrentDateInfoVO.getCurrDateHourminute();//실시간    : 년월일시분
        String currKorSimpleHourminute = hvacCurrentDateInfoVO.getCurrKorSimpleHourminute();//실시간    : HH시mm분
        String currDateHour = hvacCurrentDateInfoVO.getCurrDateHour();//실시간    : 년월일시
        String currKorSimpleHour = hvacCurrentDateInfoVO.getCurrKorSimpleHour();//실시간    : HH시
        
        
        HeatSourceBaseInfoVO heatSourceBaseInfoVO= new HeatSourceBaseInfoVO();
        heatSourceBaseInfoVO.setBldId(bldId);
        heatSourceBaseInfoVO.setBldName(bldName);
        //heatSourceBaseInfoVO.setCurrDateHour(currDateHour);
        //heatSourceBaseInfoVO.setCurrHour(currKorSimpleHour);
        
        
        List<BldHeatSourceAllVO>  dbHeatSourceList= heatSrcMapper.getHeatSourceList( bldId); 
        

        //Point 목록
        List<BldHeatSourcePointInfoVO> heatSourceList = new ArrayList<BldHeatSourcePointInfoVO>();

        //01:가동상태,02:냉수펌프열원비율,03:냉각수펌프열원비율
        List<BldHeatSourceAllVO>  pointList 
            = dbHeatSourceList.stream() 
                              .filter(StreamMapUtil.distinctByKeys( BldHeatSourceAllVO::getPointCd
                                                                   ,BldHeatSourceAllVO::getPointName
                                                   )
                                 ) .collect(Collectors.toList());
       
        //01:가동상태,02:냉수펌프열원비율,03:냉각수펌프열원비율  3번 루프
        pointList.forEach(categoryInfo->{
            String _sumDateHour = categoryInfo.getSumDateHour();
            String _sumHour     = categoryInfo.getSumHour();
            if(_sumDateHour !=null)     heatSourceBaseInfoVO.setCurrDateHour(_sumDateHour);
            if(_sumHour     !=null)     heatSourceBaseInfoVO.setCurrHour    (_sumHour    );

            
        	BldHeatSourcePointInfoVO bldHeatSourcePointInfoVO  = new BldHeatSourcePointInfoVO(); 
            //포인트구분코드 상세목록
            List<BldHeatSourceAllVO>  detailList 
               = dbHeatSourceList.stream().filter(detailInfo ->   
                                                   categoryInfo.getBldId().equals(detailInfo.getBldId() )  
                                                && categoryInfo.getPointCd().equals(detailInfo.getPointCd() )
                                     )
                 .collect(Collectors.toList());
            

            //화면에서보여주는 포인트별 냉방기의 가동상태,열원비율
            List<BldHeatSourceInfoVO>  heatSourceObjectList 
                =  detailList.stream()
                    .map(BldHeatSourceAllVO::toBldHeatSourcInfoVo)
            		.collect(Collectors.toList());
          
            
            //포인트구분코드(01:가동상태,02:냉수펌프열원비율,03:냉각수펌프열원비율) 별 각각 상세 데이터    
            bldHeatSourcePointInfoVO.setBldId(categoryInfo.getBldId());
            bldHeatSourcePointInfoVO.setPointCd(categoryInfo.getPointCd() );
            bldHeatSourcePointInfoVO.setPointName(categoryInfo.getPointName());
            bldHeatSourcePointInfoVO.setPointSortSeq(categoryInfo.getPointSortSeq()); 
            bldHeatSourcePointInfoVO.setHeatSourceObjectList(heatSourceObjectList);
            
            
            //point구분별 열원리스트
            heatSourceList.add(bldHeatSourcePointInfoVO); 
 
        });//forEach
        
        //point구분별 정렬 
        Comparator<BldHeatSourcePointInfoVO> compare 
        = Comparator .comparing(BldHeatSourcePointInfoVO::getBldId)
	                 .thenComparingInt(BldHeatSourcePointInfoVO::getPointSortSeq)
 		           // .thenComparing(AirQualityStandardVO::getAlarmExceptionId)
         	       // .thenComparing(AirQualityStandardVO::getAlarmExceptionCategoryCd)
 	         	    //.thenComparingInt(OivAlarmExceptionAllDto::getAlarmExceptionSeq)
         	        ; 
        List<BldHeatSourcePointInfoVO>  resultHeatSourceList = heatSourceList.stream()
	               .sorted( compare).collect(Collectors.toList());
        
        if(  heatSourceBaseInfoVO.getCurrDateHour()==null
           ||heatSourceBaseInfoVO.getCurrHour()    ==null) {
            log.debug("화면에 보여줄 currDateHOur,currHour is null");
        }
        
        if(heatSourceBaseInfoVO.getCurrDateHour()==null) heatSourceBaseInfoVO.setCurrDateHour(currDateHour);
        if(heatSourceBaseInfoVO.getCurrHour()    ==null) heatSourceBaseInfoVO.setCurrHour(currKorSimpleHour);
        
        
        //열원기본정보
        heatSourceOptiResultVO.setHeatSourceBaseInfoVO(heatSourceBaseInfoVO);
        //상세열원정보
        heatSourceOptiResultVO.setHeatSourceList(resultHeatSourceList);
                
        return heatSourceOptiResultVO;
    } 

     
 
}     
