package com.adtcaps.tsop.dashboard.api.energy.domain;

import java.util.List;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class CommonCodeDetailVO {
	protected String commonCd;
	protected String commonCdVal;
	protected String commonCdValName;
	protected int sortSeq;
}
