package com.adtcaps.tsop.dashboard.api.energy.controller;

import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.adtcaps.tsop.dashboard.api.energy.domain.BldTypeVO;
import com.adtcaps.tsop.dashboard.api.energy.domain.BuildingPowerVO;
import com.adtcaps.tsop.dashboard.api.energy.domain.BuildingTypeVO;
import com.adtcaps.tsop.dashboard.api.energy.domain.BuildingVO;
import com.adtcaps.tsop.dashboard.api.energy.domain.CommonCodeDetailVO;
import com.adtcaps.tsop.dashboard.api.energy.domain.EnergyPowerQnttyVO;
import com.adtcaps.tsop.dashboard.api.energy.domain.PowerConsumptionTrendVO;
import com.adtcaps.tsop.dashboard.api.energy.service.EnergyService;
import com.adtcaps.tsop.dashboard.api.energy.type.SortMethod;

import lombok.extern.slf4j.Slf4j;


@Slf4j
@RestController
@RequestMapping(value = "/api/dashboard/energy")
public class EnergyRestController {

	@Autowired
	private EnergyService energyService;

	/**
	 * building 기본 정보
	 * @param model
	 * @param request
	 * @return
	 */
	@GetMapping(value="building", produces="application/json; charset=UTF-8")
	public @ResponseBody List<BuildingVO> getBuildingList(Model model, HttpServletRequest request) {
		log.info("getBuildingList() start !!! ");
		return energyService.getBuildingList();
	}

	/**
	 * building 기본 정보
	 * @param model
	 * @param request
	 * @return
	 */
	@GetMapping(value="code/{commonCd}", produces="application/json; charset=UTF-8")
	public @ResponseBody List<CommonCodeDetailVO> getCodeDetails(Model model, @PathVariable String commonCd) {
		log.info("getCodeDetails() start !!! ");
		return energyService.getCodeDetail(commonCd);
	}

	/**
	 *
	 * @param model
	 * @param request
	 * @return
	 */
	@GetMapping(value="building/energy", produces="application/json; charset=UTF-8")
	public @ResponseBody List<EnergyPowerQnttyVO> getEnergyStatList(Model model, HttpServletRequest request) {
		log.info("getEnergyStatList() start !!! ");
		return energyService.getPowerList("ALL", SortMethod.getSortMethod("asc"));
	}

	/**
	 * // 에너지 통합관제
	 * @param model
	 * @param request
	 * @return
	 */
	@GetMapping(value="integrated/monitoring/bldtype/{bldTypeCd}", produces="application/json; charset=UTF-8")
	public @ResponseBody List<EnergyPowerQnttyVO> getEnergyStatByBldTypeList(
			@PathVariable String bldTypeCd
			, @RequestParam(required=false, defaultValue="asc") String sort) {
		log.info("getEnergyStatByBldTypeList() start !!! ");
		return energyService.getPowerList(bldTypeCd, SortMethod.getSortMethod(sort));
	}

	/**
	 * // 보라매사옥 전력소비/설비운영 Trend
	 * ex) http://localhost:9191/api/energy/integrated/monitoring/powerConsumptionTrend?bldId=0001
	 * @param bldId
	 * @return
	 */
	@GetMapping(value="integrated/monitoring/powerConsumptionTrend", produces="application/json; charset=UTF-8")
    @ResponseBody
	public List<PowerConsumptionTrendVO> getPowerConsumptionTrend(String bldId) {
		return energyService.getPowerConsumptionTrend(bldId);
	}

    // 에너지 통합관제 - 빌딩 유형
	@GetMapping(value="integrated/bldtypecd", produces="application/json; charset=UTF-8")
    @ResponseBody
	public List<BuildingTypeVO> getBuildingTypeList() {
		return energyService.getBuildingTypeList();
	}
	//전력소비/설비운영 Trend Highchart용
	@GetMapping(value="integrated/monitoring/powerConsumptionTrendChart", produces="application/json; charset=UTF-8")
    @ResponseBody
	public Map<String, Object> powerConsumptionTrendChart(String bldId) {
		return energyService.powerConsumptionTrendChart(bldId);
	}
	
	/**
	 * 
	 * <pre>
	 *  메소드명 : fmBuildingPowerTrendDayWeek
	 *  설    명 : 빌딩 요일별 7일 평균 전력 트랜드 조회
	 *  작 성 일 : 2020. 12. 22.
	 *  작 성 자 : Jeong.HyunMin
	 * </pre>
	 * @param bldId
	 * @return
	 */
	@GetMapping(value="/building/{bldId}/powerTrend/dayweek", produces="application/json; charset=UTF-8")
    public @ResponseBody BuildingVO fmBuildingPowerTrendDayWeek(@PathVariable("bldId") String bldId) {
        return energyService.fmBuildingPowerTrendDayWeek(bldId);
    }
	
	
	/**
	 * 
	 * <pre>
	 *  메소드명 : fmBuildingPowerTrendHour
	 *  설    명 : 빌딩 시간대별 7일 평균 전력 트랜드 조회
	 *  작 성 일 : 2020. 12. 22.
	 *  작 성 자 : Jeong.HyunMin
	 * </pre>
	 * @param bldId
	 * @return
	 */
	@GetMapping(value="/building/{bldId}/powerTrend/24hr", produces="application/json; charset=UTF-8")
    public @ResponseBody BuildingVO fmBuildingPowerTrendHour(@PathVariable("bldId") String bldId) {
        return energyService.fmBuildingPowerTrendHour(bldId);
    }

	/**
	 * 
	 * <pre>
	 *  메소드명 : fmBldType
	 *  설    명 : 빌딩 타입 조회
	 *  작 성 일 : 2021. 1. 11.
	 *  작 성 자 : Jeong.HyunMin
	 * </pre>
	 * @return
	 */
	@GetMapping(value="/bldType", produces="application/json; charset=UTF-8")
    public @ResponseBody List<BldTypeVO> fmBldType() {
        return energyService.fmBldType();
    }
	
	/**
	 * 
	 * <pre>
	 *  메소드명 : fmBuildingPowerUsage
	 *  설    명 : 빌딩별 전력 현황
	 *  작 성 일 : 2021. 1. 11.
	 *  작 성 자 : Jeong.HyunMin
	 * </pre>
	 * @param bldType
	 * @return
	 */
	@GetMapping(value="/bldType/{bldType}/building/power", produces="application/json; charset=UTF-8")
	public @ResponseBody List<BuildingPowerVO> fmBuildingPowerUsage(@PathVariable("bldType") String bldType, String sort) {
        return energyService.fmBuildingPowerUsage(bldType, sort);
    }
}
