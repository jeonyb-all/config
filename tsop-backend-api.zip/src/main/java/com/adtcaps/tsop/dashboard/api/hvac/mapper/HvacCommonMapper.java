package com.adtcaps.tsop.dashboard.api.hvac.mapper;

import org.apache.ibatis.annotations.Mapper;

import com.adtcaps.tsop.domain.hvac.vo.HvacCurrentDateInfoVO;

@Mapper
public interface HvacCommonMapper {
    //현재시간  15분단위 : 년월일시분,15분단위 : HH시mm분
    public HvacCurrentDateInfoVO selectHvacCurrentDate();
   
	 
}
