package com.adtcaps.tsop.dashboard.api.hvac.service.impl;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.adtcaps.tsop.dashboard.api.hvac.domain.BldPowerBaseInfoVO;
import com.adtcaps.tsop.dashboard.api.hvac.domain.BldPowerConsumptionVO;
import com.adtcaps.tsop.dashboard.api.hvac.domain.PeakPowerResultVO;
import com.adtcaps.tsop.dashboard.api.hvac.domain.PowerMinuteConsumptionAllVO;
import com.adtcaps.tsop.dashboard.api.hvac.domain.PowerMinuteConsumptionVO;
import com.adtcaps.tsop.dashboard.api.hvac.mapper.HvacCommonMapper;
import com.adtcaps.tsop.dashboard.api.hvac.mapper.OperTimeMapper;
import com.adtcaps.tsop.dashboard.api.hvac.service.OperTimeService;
import com.adtcaps.tsop.domain.hvac.vo.HvacCurrentDateInfoVO;

import lombok.extern.slf4j.Slf4j;
@Slf4j
@Service
public class OperTimeServiceImpl implements OperTimeService{

	@Autowired
	private OperTimeMapper operTimeMapper;
    //현재시간  15분단위 : 년월일시분,15분단위 : HH시mm분
    @Autowired
    private HvacCommonMapper hvacCommonMapper;
  

	/** 
     * <pre>
     *  메소드명 : findBuildingPeakPowerManager
     *  설    명 : 사옥별 Peak 전력관리
     *  작 성 일 : 2021.10.13. 
     * </pre>
     * @return  
     */ 
	@Override
	public PeakPowerResultVO findBuildingPeakPowerManager() {
		//List<BldPowerConsumptionVO> bldPowerConsumptionVO= new ArrayList<BldPowerConsumptionVO>();
	    Date logStartDate = new Date();
	      
	    HvacCurrentDateInfoVO hvacCurrentDateInfoVO = hvacCommonMapper.selectHvacCurrentDate();
	    String baseDateHourminute = hvacCurrentDateInfoVO.getCurrDateHourminute();//yyyyMMddHHmm
	    String baseHourminute = hvacCurrentDateInfoVO.getCurrKorSimpleHourminute();//HH시mm분
	    
	    //사옥별 Peak 전력관리  
		List<BldPowerConsumptionVO> bldPowerConsumptionDataList = operTimeMapper.getBldPowerConsumptionList();
 
		//사옥별 Peak 전력관리  빌딩별 전력사용량 조회
		List<PowerMinuteConsumptionAllVO> dbPowerMinuteConsumptionAllList =  operTimeMapper.getPowerMinuteConsumptionList();
		
 
        //빌딩 루프
		bldPowerConsumptionDataList.forEach(categoryInfo->{

            //빌딩에 대한 화면에사용할 분당전력소비량 데이터 가져오기
            List<PowerMinuteConsumptionAllVO>  detailMinutePowerUseValList 
               = dbPowerMinuteConsumptionAllList.stream().filter(detailInfo ->   
                                                   categoryInfo.getBldId().equals(detailInfo.getBldId() )  
                                     )
                 .collect(Collectors.toList());
            

            //빌딩에 대한 화면에사용할 분당전력소비량 데이터 가져오기
            List<PowerMinuteConsumptionVO>  resultDetailHourList 
                =  detailMinutePowerUseValList.stream()
                    .map(PowerMinuteConsumptionAllVO::toPowerMinuteConsumptionVO)
            		.collect(Collectors.toList());
             
            
            categoryInfo.setPowerMinuteConsumptionList(resultDetailHourList);
 
        });//forEach

	     //모든 빌딩의 전력소비량의 마지막 집계시간 가져오기
        String collectDateHourminute = null;	
       
		if(   bldPowerConsumptionDataList != null
          && !bldPowerConsumptionDataList.isEmpty()
		        ) {
		    BldPowerConsumptionVO bldPowerConsumptionVO=  bldPowerConsumptionDataList.get(0);
		    collectDateHourminute = bldPowerConsumptionVO.getMaxCollectDateHourminute();
		    
		    log.debug(" 모든 빌딩의 전력소비량의 마지막 집계시간 가져오기  bldPowerConsumptionVO.getMaxCollectDateHourminute() : {}" , collectDateHourminute);
            
		    
		    /*
		    //첫번째 빌딩의 전력소비량 
		    List<PowerMinuteConsumptionVO> powerMinuteConsumptionList =  bldPowerConsumptionDataList.get(0).getPowerMinuteConsumptionList();

            log.debug(" 첫번째 빌딩의    빌딩약어 : {}" , bldPowerConsumptionDataList.get(0).getBldAbbrName());

            if(powerMinuteConsumptionList != null && powerMinuteConsumptionList.size()!=0 ) {
                //마지막 데이터중 전력소비량이 있는 기준시간 가져오기
                for(int i =powerMinuteConsumptionList.size() ; i>0 ;i--) {
                    PowerMinuteConsumptionVO powerMinuteConsumptionVO =  powerMinuteConsumptionList.get(i-1);
                    
                    log.debug(" 전력소비량 데이터 정보  powerMinuteConsumptionVO : {}" , powerMinuteConsumptionVO);
                    
                    if(powerMinuteConsumptionVO.getPowerUseVal() != null) { 
                        if(              powerMinuteConsumptionVO.getCollectDateHourminute() !=null
                           && !"".equals(powerMinuteConsumptionVO.getCollectDateHourminute()) 
                            ) {
                            collectDateHourminute = powerMinuteConsumptionVO.getCollectDateHourminute();
                            break;
                        }
                    }
                }
            }
            */
        }
		 
            
		Date collectDate  = new Date();
        if(collectDateHourminute!= null) {
           String TIME_FORMAT = "yyyyMMddHHmm";
	       try {
	            SimpleDateFormat df = new SimpleDateFormat(TIME_FORMAT.substring(0, collectDateHourminute.length()));
	            collectDate =  df.parse(collectDateHourminute);
	            
	            baseDateHourminute = new SimpleDateFormat("yyyyMMddHHmm").format(collectDate);//yyyyMMddHHmm
	            baseHourminute = new SimpleDateFormat("HH시mm분").format(collectDate);///HH시mm분
                log.debug(" 전력소비량 데이터로 집계시간 가져오기 collectDateHourminute : " + collectDateHourminute);
                log.debug("  baseDateHourminute : " + baseDateHourminute);
                log.debug("  baseHourminute : " + baseHourminute);
	            
	        }
	        catch (ParseException ex) {
	            log.debug("collectDateHourminute 의 parseDate ### ParseException ###: " + collectDateHourminute);
	            //return null;
	        } 
        }
        
        Date logEndDate = new Date();
        long diffTime2 = logEndDate.getTime() - logStartDate.getTime();
        long diffSec2 = diffTime2 / 1000;
        log.debug("[SKT사옥별 전력사용 현황]findBuildingPeakPowerManager  조회후 사옥별로 차트 데이터  넣는 시간 ::{}초",diffSec2) ;
       
	       
		BldPowerBaseInfoVO bldPowerBaseInfo = new BldPowerBaseInfoVO();
		bldPowerBaseInfo.setSumDateHourminute(baseDateHourminute);
		bldPowerBaseInfo.setSimpleHourminute(baseHourminute);
		
		PeakPowerResultVO peakPowerResultVO = new  PeakPowerResultVO();
		peakPowerResultVO.setBldPowerConsumptionDataList(bldPowerConsumptionDataList);
		peakPowerResultVO.setBldPowerBaseInfo(bldPowerBaseInfo);
		return peakPowerResultVO;
	} 
  
 
}	 
