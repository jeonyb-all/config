package com.adtcaps.tsop.dashboard.api.energy.domain;



import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class PowerConsumptionTrendVO {
	private String bldId;
	private String dayOfWeek;
	private String dayOfWeekName;
	private String dayWeekEngAbbrName;
	private String dayWeekEngName;
	private String dayWeekName;	
	private String dateFormat;
	private int hour;
	private Float power;
	private int xAxis;
}
