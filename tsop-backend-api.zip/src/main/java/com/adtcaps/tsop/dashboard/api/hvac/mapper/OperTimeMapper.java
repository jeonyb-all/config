package com.adtcaps.tsop.dashboard.api.hvac.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;

import com.adtcaps.tsop.dashboard.api.hvac.domain.BldPowerConsumptionVO;
import com.adtcaps.tsop.dashboard.api.hvac.domain.PowerMinuteConsumptionAllVO;

@Mapper
public interface OperTimeMapper {
	/**
	 * 사옥별 Peak 전력관리 빌딩별
	 * @param bldId
	 * @return
	 */ 
	public List<BldPowerConsumptionVO> getBldPowerConsumptionList();
	/**
	 * 사옥별 Peak 전력관리 빌딩별 전력사용현황
	 * @param bldId
	 * @return
	 */ 
	public List<PowerMinuteConsumptionAllVO> getPowerMinuteConsumptionList();
	 
}
