package com.adtcaps.tsop.dashboard.api.hvac.domain;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@ApiModel(value = "빌딩 층의 이전 시간에대한 재실자수 ", description = "빌딩/층의 이전 시간에대한 재실자수")
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class FloorPreHourOccupantVO { 
	 
	 

	@ApiModelProperty(position = 5 , required = false, value="통계시간", example = "13")
	private String hourTime;//	통계시간	현재시간-24~현재시간

	@ApiModelProperty(position = 7 , required = false, value="재실자수", example = "26")
	private String occupantCnt;//	 	현재통계값(재실자수) 통계낸경우는 숫자,0이지만  통계를 안낸경우 -를 줄경우로 대비<- int로 안함

	
	


    
}
