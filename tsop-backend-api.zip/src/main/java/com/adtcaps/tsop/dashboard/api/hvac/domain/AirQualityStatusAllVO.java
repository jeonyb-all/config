package com.adtcaps.tsop.dashboard.api.hvac.domain;

import javax.validation.constraints.Size;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@ApiModel(value = "DB에서 가져오는대기질기준 좋음,보통,나쁨,매우나쁨을 세로로 ", description = "DB에서 가져오는 대기질기준 좋음,보통,나쁨,매우나쁨을 세로로  ")
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class AirQualityStatusAllVO {

	@ApiModelProperty(position = 1 , required = false, value="건물ID", example = "0000")
	@Size(min = 1, max = 4, message="건물ID는 4자리입니다")
    private String bldId               ;//건물ID
	
	@ApiModelProperty(position = 3 , required = false, value="대기질구분코드", example = "1")
    private String managementCategoryCd;//대기질구분코드 1:미세먼지,2:초미세먼지,3:실외엔탈피
	
	@ApiModelProperty(position = 5 ,required = false, value="대기질구분명", example = "초미세먼지(PM2.5)")
	@Size(min = 1, max = 100, message="대기질구분명은 100자리 입니다.")
    private String managementCategoryName;//대기질구분명   1:미세먼지,2:초미세먼지,3:실외엔탈피 , ex)엔탈피,PM10,PM2.5
	
	@ApiModelProperty(position = 6 , required = false, value="대기질소트", example = "3")
    private Integer managementCategorySortSeq   ;//대기질소트
	
	
	@ApiModelProperty(position = 7 , required = false, value="단위코드명", example = "㎍/㎥")
	@Size(min = 1, max = 100, message="단위코드명은 100자리 입니다.")
    private String managementUnitName      ;//단위명
  
	@ApiModelProperty(position = 9 , required = false, value="대기질상세코드", example = "01")
	@Size(min = 1, max = 2, message="대기질상세코드는 2자리 입니다.")
    private String managementDetailCd   ;//대기질상태코드
	

	@ApiModelProperty(position = 11 , required = false, value="대기질상세코드명", example = "좋음")
	@Size(min = 1, max = 100, message="대기질상세코드명은 100자리 입니다.")
    private String managementDetailName ;//대기질상태명	ex)좋음,나쁨
	

	@ApiModelProperty(position = 13 , required = false, value="from값", example = "0") 
    private Integer referenceValFirst    ;//from값
	
	@ApiModelProperty(position = 15 , required = false, value="to값", example = "30") 
    private Integer referenceValSecond   ;//to값

	@ApiModelProperty(position = 17 ,required = false, value="DB기준값여부-대기질기준목록이 구성_관리기준값상세 에서 가져온 경우 Y,환경부기준값인 경우 N", example = "Y")
    private String dbStandardYn;     //DB기준값여부-대기질기준목록이 구성_관리기준값상세 에서 가져온 경우 Y,환경부기준값인 경우 N

 
	public AirQualityStatusVO toAirQualityStatusVo() {
		AirQualityStatusVO airQualityStatusVo = new AirQualityStatusVO();
		
		airQualityStatusVo.setManagementDetailCd(this.managementDetailCd);
		airQualityStatusVo.setManagementDetailName(this.managementDetailName);
		airQualityStatusVo.setReferenceValFirst(this.referenceValFirst);
		airQualityStatusVo.setReferenceValSecond(this.referenceValSecond);
		airQualityStatusVo.setManagementUnitName(this.managementUnitName);
		return airQualityStatusVo;
	}

 
}
