package com.adtcaps.tsop.dashboard.api.hvac.service.impl;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.adtcaps.tsop.dashboard.api.hvac.domain.AirQualityCO2InfoVO;
import com.adtcaps.tsop.dashboard.api.hvac.domain.FloorOccupantInfoVO;
import com.adtcaps.tsop.dashboard.api.hvac.domain.FloorOccupantResultVO;
import com.adtcaps.tsop.dashboard.api.hvac.domain.FloorPreHourAirQualityCO2AllVO;
import com.adtcaps.tsop.dashboard.api.hvac.domain.FloorPreHourOccupantAllVO;
import com.adtcaps.tsop.dashboard.api.hvac.domain.FloorPreHourOccupantVO;
import com.adtcaps.tsop.dashboard.api.hvac.domain.FloorRealTimeAirQualityCO2InfoVO;
import com.adtcaps.tsop.dashboard.api.hvac.domain.FloorRealTimeOccupantInfoVO;
import com.adtcaps.tsop.dashboard.api.hvac.domain.FloorRecmdVentiRateVO;
import com.adtcaps.tsop.dashboard.api.hvac.domain.OfficeInInfoVO;
import com.adtcaps.tsop.dashboard.api.hvac.domain.RecmdVentiBaseInfoVO;
import com.adtcaps.tsop.dashboard.api.hvac.domain.RecmdVentiResultVO;
import com.adtcaps.tsop.dashboard.api.hvac.mapper.HvacCommonMapper;
import com.adtcaps.tsop.dashboard.api.hvac.mapper.VentiCtrlMapper;
import com.adtcaps.tsop.dashboard.api.hvac.service.VentiCtrlService;
import com.adtcaps.tsop.dashboard.api.hvac.util.StreamMapUtil;
import com.adtcaps.tsop.domain.hvac.vo.HvacCurrentDateInfoVO;
import com.adtcaps.tsop.domain.hvac.vo.OcoBuildingAddInfoCollectVO;
import com.adtcaps.tsop.helper.constant.Const;
import com.adtcaps.tsop.portal.api.hvac.service.OcoBuildingAddInfoCollectService;

import lombok.extern.slf4j.Slf4j;
@Slf4j
@Service
public class VentiCtrlServiceImpl implements VentiCtrlService{

	@Autowired
	private VentiCtrlMapper ventiCtrlMapper;
	

    //현재시간  15분단위 : 년월일시분,15분단위 : HH시mm분
    @Autowired
    private HvacCommonMapper hvacCommonMapper;
    
    @Autowired
    private OcoBuildingAddInfoCollectService ocoBuildingAddInfoCollectService;
	
	/** 
     * <pre>
     *  메소드명 : findOfficePerson
     *  설    명 : 층별 재실자 현황 조회
     *  작 성 일 : 2021.10.13. 
     * </pre>
     * @return  
     */ 
	@Override
	public FloorOccupantResultVO findOfficePerson(String bldId ) {

	    HvacCurrentDateInfoVO hvacCurrentDateInfoVO = hvacCommonMapper.selectHvacCurrentDate();
	    String baseDateHourminute = hvacCurrentDateInfoVO.getBase15DateHourminute();//15분단위 : 년월일시분
	    String baseHourminute    = hvacCurrentDateInfoVO.getBase15KorSimpleHourminute();  //15분단위 : HH시mm분
	        
	        
		FloorOccupantResultVO floorOccupantResultVO= new FloorOccupantResultVO();
		
		//층별인원수
		List<FloorOccupantInfoVO>  floorOccupantInfoList  = ventiCtrlMapper.getFloorOccupantInfoList(bldId);
		
	    //층별 공기질(CO2) 목록조회
        List<AirQualityCO2InfoVO>  airQualityCO2AllList  = ventiCtrlMapper.getFloorAirQualityCO2AllListForOccupant(bldId);
      
        //건물내정보
        OfficeInInfoVO officeInInfoVO = new OfficeInInfoVO(); 
        
		//건물내인원구하기
		int officeTotalCnt = 0;
		if(floorOccupantInfoList != null  && floorOccupantInfoList.size()>0 ) {
			FloorOccupantInfoVO floorOccupantInfoVO = floorOccupantInfoList.get(0);
			officeTotalCnt = floorOccupantInfoVO.getOfficeTotalCnt();
			
            String sumDateHourminute = floorOccupantInfoVO.getSumDateHourminute();
            String simpleHourminute  = floorOccupantInfoVO.getSimpleHourminute();
            if(sumDateHourminute !=null)     officeInInfoVO.setSumDateHourminute(sumDateHourminute);
            if(simpleHourminute  !=null)     officeInInfoVO.setSimpleHourminute   (simpleHourminute    );
                   
          
            
            
		}

        //층 루프
		floorOccupantInfoList.forEach(categoryInfo->{
 

            List<AirQualityCO2InfoVO>  detailAirQualityCO2List 
            = airQualityCO2AllList.stream().filter(detailCo2Info ->   
                                                categoryInfo.getBldId()   .equals(detailCo2Info.getBldId() )  
                                             && categoryInfo.getLocFloor().equals(detailCo2Info.getLocFloor() )
                                  )
              .collect(Collectors.toList());
            
            //층에대한 CO2목록
            categoryInfo.setAirQualityCO2List(detailAirQualityCO2List);  
 
        });//forEach
        
 
        // 공기질CO2 기준값 900이상이면 빨간색
        //int AIR_QUALITY_CO2_BASE_VAL =  ocoBuildingAddInfoCollectService.getAirQualityCo2BaseVal(bldId);
		String AIR_QUALITY_CO2_YN = "N";//공기질CO2 연동 사용여부
        int AIR_QUALITY_CO2_BASE_VAL = Const.Definition.AIR_QUALITY_CO2.AIR_QUALITY_CO2_BASE_VAL;
        OcoBuildingAddInfoCollectVO ocoBuildingAddInfoCollectVO = new OcoBuildingAddInfoCollectVO();
        ocoBuildingAddInfoCollectVO.setBldId(bldId);
        //OcoBuildingAddInfoCollectVO resultOcoBuildingAddInfoCollectVO= ocoBuildingAddInfoCollectService.getBldIdDataForAzurePaaS(ocoBuildingAddInfoCollectVO);
        OcoBuildingAddInfoCollectVO resultOcoBuildingAddInfoCollectVO= ocoBuildingAddInfoCollectService.getServiceDataForBldId(ocoBuildingAddInfoCollectVO);
        // 공기질CO2 기준값
        if(resultOcoBuildingAddInfoCollectVO != null) {
            if(resultOcoBuildingAddInfoCollectVO.getAirQualityCo2BaseVal()!=null) {
               AIR_QUALITY_CO2_BASE_VAL =  resultOcoBuildingAddInfoCollectVO.getAirQualityCo2BaseVal();//공기질CO2기준값
            }
            AIR_QUALITY_CO2_YN = resultOcoBuildingAddInfoCollectVO.getAirQualityCo2Yn();//공기질CO2 연동 사용여부
            AIR_QUALITY_CO2_YN = AIR_QUALITY_CO2_YN == null?"N": AIR_QUALITY_CO2_YN;
            
        }
        
        
        
        //건물내정보
        //OfficeInInfoVO officeInInfoVO = new OfficeInInfoVO(); 
		officeInInfoVO.setBldId(bldId);
	    officeInInfoVO.setAirQualityCo2BaseVal(AIR_QUALITY_CO2_BASE_VAL);
        officeInInfoVO.setAirQualityCo2Yn(AIR_QUALITY_CO2_YN);
	    
		officeInInfoVO.setOfficeTotalCnt(officeTotalCnt);//건물내인원수
        if(  officeInInfoVO.getSumDateHourminute()==null
           ||officeInInfoVO.getSimpleHourminute()    ==null) {
                log.debug("화면에 보여줄 currDateHourminute,currHourminute is null");
            }
            
        if(officeInInfoVO.getSumDateHourminute() ==null) officeInInfoVO.setSumDateHourminute(baseDateHourminute);//실시간    : 년월일시분
        if(officeInInfoVO.getSimpleHourminute()  ==null) officeInInfoVO.setSimpleHourminute(baseHourminute);// 실시간    : HH시mm분
	            
 
	 
		floorOccupantResultVO.setOfficeInInfoVO(officeInInfoVO);//건물내정보
		floorOccupantResultVO.setFloorOccupantInfoList(floorOccupantInfoList);//층별재실자 목록
		
		return floorOccupantResultVO;
	} 
	/** 
     * <pre>
     *  메소드명 : findRecmdVentirate
     *  설    명 : 층별권장 환기량(외기댐퍼 개도율)
     *  작 성 일 : 2021.10.13. 
     * </pre>
     * @return  
     */ 
	@Override
	public RecmdVentiResultVO findRecmdVentirate(String bldId ) {

        HvacCurrentDateInfoVO hvacCurrentDateInfoVO = hvacCommonMapper.selectHvacCurrentDate();
        String baseDateHourminute = hvacCurrentDateInfoVO.getBase15DateHourminute();
        String baseHourminute = hvacCurrentDateInfoVO.getBase15KorSimpleHourminute();

        
		List<FloorRecmdVentiRateVO> floorRecmdVentiRateList =  ventiCtrlMapper.getRecmdVentirateList( bldId);

		RecmdVentiBaseInfoVO recmdVentiBaseInfo = new RecmdVentiBaseInfoVO();
		recmdVentiBaseInfo.setSumDateHourminute(baseDateHourminute);
		recmdVentiBaseInfo.setSimpleHourminute(baseHourminute);
		         
		    
        RecmdVentiResultVO recmdVentiResultVO = new  RecmdVentiResultVO();
        recmdVentiResultVO.setFloorRecmdVentiRateList(floorRecmdVentiRateList);
        recmdVentiResultVO.setRecmdVentiBaseInfo(recmdVentiBaseInfo);
        return recmdVentiResultVO;
		
 
	} 
	/** 
     * <pre>
     *  메소드명 : findRealTimeOfficePerson
     *  설    명 : 층별 재실자 현황 상세-실시간 재실자 현황
     *  작 성 일 : 2021.10.13. 
     * </pre>
     * @return  
     */ 
	@Override
	public List<FloorRealTimeOccupantInfoVO> findRealTimeOfficePerson(String bldId ) {
		
		List<FloorPreHourOccupantAllVO> dbFloorPreHourOccupantAllList = ventiCtrlMapper.getFloorPreHourOccupantList( bldId);
		

        //층 목록
        List<FloorRealTimeOccupantInfoVO> floorDataList = new ArrayList<FloorRealTimeOccupantInfoVO>();

        //층 목록 distinct
        List<FloorPreHourOccupantAllVO>  locFoorList 
            = dbFloorPreHourOccupantAllList.stream() 
                              .filter(StreamMapUtil.distinctByKeys( FloorPreHourOccupantAllVO::getBldId
                                                                   ,FloorPreHourOccupantAllVO::getLocFloor
                                                   )
                                 ) .collect(Collectors.toList());
       
        //층 루프
        locFoorList.forEach(categoryInfo->{

            //층에대한 시간 목록 가져오기
            List<FloorPreHourOccupantAllVO>  detailHourList 
               = dbFloorPreHourOccupantAllList.stream().filter(detailInfo ->   
                                                   categoryInfo.getBldId().equals(detailInfo.getBldId() )  
                                                && categoryInfo.getLocFloor().equals(detailInfo.getLocFloor() )
                                     )
                 .collect(Collectors.toList());
            

            //층에 대한 화면에사용할 시간 데이터 가져오기
            List<FloorPreHourOccupantVO>  resultDetailHourList 
                =  detailHourList.stream()
                    .map(FloorPreHourOccupantAllVO::toFloorPreHourOccupantVO)
            		.collect(Collectors.toList());
             
            
            //층 데이터
            FloorRealTimeOccupantInfoVO floorOccupantInfoVO  = new FloorRealTimeOccupantInfoVO(); 
            floorOccupantInfoVO.setBldId(categoryInfo.getBldId());
            floorOccupantInfoVO.setLocId(categoryInfo.getLocId() ); 
            floorOccupantInfoVO.setLocFloor(categoryInfo.getLocFloor() ); 
            floorOccupantInfoVO.setHourList(resultDetailHourList);//층에 대한 간 리스트
            
            //층에 대한 데이터 담기
            floorDataList.add(floorOccupantInfoVO); 
 
        });//forEach
        
        //층 정렬 
        Comparator<FloorRealTimeOccupantInfoVO> compare 
        = Comparator .comparing(FloorRealTimeOccupantInfoVO::getBldId)
	                 .thenComparingInt(FloorRealTimeOccupantInfoVO::getLocId)
 		           // .thenComparing(AirQualityStandardVO::getAlarmExceptionId)
         	       // .thenComparing(AirQualityStandardVO::getAlarmExceptionCategoryCd)
 	         	    //.thenComparingInt(OivAlarmExceptionAllDto::getAlarmExceptionSeq)
         	        ; 
        List<FloorRealTimeOccupantInfoVO>  resultFloorDataList = floorDataList.stream()
	               .sorted( compare).collect(Collectors.toList());
         
		
		return resultFloorDataList;
	} 
	 
	
	

    /** 
     * <pre>
     *  메소드명 : findRealTimeAirQualityCO2
     *  설    명 : 층별 재실자 현황 상세-실시간 공기질(CO2) 현황
     *  작 성 일 : 2021.10.13. 
     * </pre>
     * @return  
     */ 
    @Override
    public List<FloorRealTimeAirQualityCO2InfoVO> findRealTimeAirQualityCO2(String bldId ) {
        Date logStartDate = new Date();
        
        //층별 시간별 상세조회
        List<FloorPreHourAirQualityCO2AllVO> dbFloorPreHourAirQualityCO2AllList = ventiCtrlMapper.getFloorPreHourAirQualityCO2List( bldId);
        
        //층별 공기질(CO2) 목록조회
        List<AirQualityCO2InfoVO>  airQualityCO2AllList  = ventiCtrlMapper.getFloorAirQualityCO2AllListForDetail(bldId);
      
        //층 목록
        List<FloorRealTimeAirQualityCO2InfoVO> floorDataList = new ArrayList<FloorRealTimeAirQualityCO2InfoVO>();

        //층 목록 distinct
        List<FloorPreHourAirQualityCO2AllVO>  locFoorList 
            = dbFloorPreHourAirQualityCO2AllList.stream() 
                              .filter(StreamMapUtil.distinctByKeys( FloorPreHourAirQualityCO2AllVO::getBldId
                                                                   ,FloorPreHourAirQualityCO2AllVO::getLocFloor
                                                   )
                                 ) .collect(Collectors.toList());
       
        
        // 공기질CO2 기준값 900이상이면 빨간색
        int AIR_QUALITY_CO2_BASE_VAL =  ocoBuildingAddInfoCollectService.getAirQualityCo2BaseVal(bldId);
            
        //층 루프
        locFoorList.forEach(categoryInfo->{

            //층에대한 시간 목록 가져오기
            List<FloorPreHourAirQualityCO2AllVO>  detailHourList 
               = dbFloorPreHourAirQualityCO2AllList.stream().filter(detailInfo ->   
                                                   categoryInfo.getBldId().equals(detailInfo.getBldId() )  
                                                && categoryInfo.getLocFloor().equals(detailInfo.getLocFloor() )
                                     )
                 .collect(Collectors.toList());
           
            
            detailHourList.forEach(hourInfo->{
                List<AirQualityCO2InfoVO>  detailAirQualityCO2List 
                = airQualityCO2AllList.stream().filter(detailCo2Info ->   
                                                    hourInfo.getBldId().equals(detailCo2Info.getBldId() )  
                                                 && hourInfo.getLocFloor().equals(detailCo2Info.getLocFloor() )
                                                 && hourInfo.getSumDateHourminute().equals(detailCo2Info.getSumDateHourminute() )
                                      )
                  .collect(Collectors.toList());
                
                hourInfo.setAirQualityCO2List(detailAirQualityCO2List); 
                
            });


  
            //층 데이터
            FloorRealTimeAirQualityCO2InfoVO floorAirQualityCO2InfoVO  = new FloorRealTimeAirQualityCO2InfoVO(); 
            floorAirQualityCO2InfoVO.setBldId(categoryInfo.getBldId());

            floorAirQualityCO2InfoVO.setAirQualityCo2BaseVal(AIR_QUALITY_CO2_BASE_VAL);
            floorAirQualityCO2InfoVO.setLocId(categoryInfo.getLocId() ); 
            floorAirQualityCO2InfoVO.setLocFloor(categoryInfo.getLocFloor() ); 
            floorAirQualityCO2InfoVO.setHourList(detailHourList);//층에 대한 간 리스트
            
            //층에 대한 데이터 담기
            floorDataList.add(floorAirQualityCO2InfoVO); 
 
        });//forEach
        
        //층 정렬 
        Comparator<FloorRealTimeAirQualityCO2InfoVO> compare 
        = Comparator .comparing(FloorRealTimeAirQualityCO2InfoVO::getBldId)
                     .thenComparingInt(FloorRealTimeAirQualityCO2InfoVO::getLocId)
                   // .thenComparing(AirQualityStandardVO::getAlarmExceptionId)
                   // .thenComparing(AirQualityStandardVO::getAlarmExceptionCategoryCd)
                    //.thenComparingInt(OivAlarmExceptionAllDto::getAlarmExceptionSeq)
                    ; 
        List<FloorRealTimeAirQualityCO2InfoVO>  resultFloorDataList = floorDataList.stream()
                   .sorted( compare).collect(Collectors.toList());
        
        Date logEndDate = new Date();
        long diffTime2 = logEndDate.getTime() - logStartDate.getTime();
        long diffSec2 = diffTime2 / 1000;
        log.debug("[실시간 공기질(CO2) 현황-대시보드]findRealTimeAirQualityCO2  조회후 층별시간별로 공기질 (CO2)목록 넣는 시간 ::{}초",diffSec2) ;
       
        //List<FloorRealTimeAirQualityCO2InfoVO>  resultFloorDataList = new ArrayList<FloorRealTimeAirQualityCO2InfoVO>();
        return resultFloorDataList;
    } 
     
	 
 
}	 
