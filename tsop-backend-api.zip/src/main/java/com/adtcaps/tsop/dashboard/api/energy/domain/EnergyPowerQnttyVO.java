package com.adtcaps.tsop.dashboard.api.energy.domain;

import java.math.BigDecimal;
import java.util.List;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class EnergyPowerQnttyVO implements Comparable<EnergyPowerQnttyVO> {

    private String bldId;
	private String bldName;
	private String bldTypeCd;
	private String bldTypeName;
	private Float bldTotalfloorareaSize;
	private String siteId;
	private String ictg;
	private BigDecimal ikw;
	private String controlPower;
	private String billYyyymm;
	private String year;
	private String month;
	private String baseBill;
	private String kwhBill;

	private Float avgPowerDensity;
	private List<PowerKwhM2StatVO> powerDensityList;

	private List<WeekendPowerStatVO> powerStatList;
	
	 @Override
	 public int hashCode() {
	     return 1;
	 }

	 @Override
	 public int compareTo(final EnergyPowerQnttyVO otherVO) {
	     return (int)(avgPowerDensity - otherVO.avgPowerDensity);
	 }
	
	 @Override
	 public boolean equals(Object obj) {
	     return super.equals(obj);
	 }
}
