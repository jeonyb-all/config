package com.adtcaps.tsop.dashboard.api.energy.domain;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class BldTypeVO {
	
	private String bldTypeCd;
	private String bldTypeCdName;
	private Integer bldCnt;

}
