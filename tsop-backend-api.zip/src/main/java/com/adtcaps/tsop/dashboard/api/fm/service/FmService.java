package com.adtcaps.tsop.dashboard.api.fm.service;

import java.util.List;

import com.adtcaps.tsop.dashboard.api.fm.domain.BuildingHeatVO;
import com.adtcaps.tsop.dashboard.api.fm.domain.BuildingSummaryVO;
import com.adtcaps.tsop.dashboard.api.fm.domain.BuildingVO;
import com.adtcaps.tsop.dashboard.api.fm.domain.EquipObjVO;
import com.adtcaps.tsop.dashboard.api.fm.domain.EquipVO;
import com.adtcaps.tsop.dashboard.api.fm.domain.FloorAmbientAirVO;
import com.adtcaps.tsop.dashboard.api.fm.domain.FmTrendVO;
import com.adtcaps.tsop.dashboard.api.fm.domain.FmVO;
import com.adtcaps.tsop.dashboard.api.fm.domain.PowerUnitViewVO;
import com.adtcaps.tsop.dashboard.api.fm.domain.RoomCondition;

public interface FmService {

	public List<FmVO> getFmEquipment();

	public List<PowerUnitViewVO> getPowerUnit();

	public List<RoomCondition> roomEnvironmentNew(String equipmentCd);

	public List<BuildingSummaryVO> getWorkingTimeNUsedPower(String bldId);
	
	public List<FmTrendVO> fmBuildingPointStatAvg(String bldId);
	
	/**
	 * 
	 * <pre>
	 *  메소드명 : fmBuildingEquipHour
	 *  설    명 : 빌딩 최근 24시간 온습도 조회 
	 *  작 성 일 : 2020. 12. 21.
	 *  작 성 자 : Jeong.HyunMin
	 * </pre>
	 * @param bldId
	 * @param equipment
	 * @return BuildingVO
	 */
	BuildingVO fmBuildingEquipHour(String bldId, String equipment);

	/**
	 * 
	 * <pre>
	 *  메소드명 : fmBuildingEquipPointHour
	 *  설    명 : 빌딩 포인트별 24시간 온습도 조회
	 *  작 성 일 : 2020. 12. 21.
	 *  작 성 자 : Jeong.HyunMin
	 * </pre>
	 * @param bldId
	 * @param equipment
	 * @return BuildingVO
	 */
	BuildingVO fmBuildingEquipPointHour(String bldId, String equipment);
		
	/**
	 * 
	 * <pre>
	 *  메소드명 : fmBuildingEquipDayWeek
	 *  설    명 : 빌딩 별 최근 7일간 온습도 조회
	 *  작 성 일 : 2020. 12. 21.
	 *  작 성 자 : Jeong.HyunMin
	 * </pre>
	 * @param equipment
	 * @return List<BuildingVO>
	 */
	List<BuildingVO> fmBuildingEquipDayWeek(String equipment);
	
	/**
	 * 
	 * <pre>
	 *  메소드명 : getBuildingWorkingTimeNUsedPower
	 *  설    명 : 빌딩군관리자 빌딩별 전력사용 및 사용시간 조회
	 *  작 성 일 : 2020. 12. 23.
	 *  작 성 자 : Jeong.HyunMin
	 * </pre>
	 * @return List<BuildingSummaryVO>
	 */
	List<BuildingSummaryVO> getBuildingWorkingTimeNUsedPower();
	
	/**
	 * 
	 * <pre>
	 *  메소드명 : getBuildingWorkingTimeNUsedPower
	 *  설    명 : 빌딩 전력사용 및 사용시간 조회
	 *  작 성 일 : 2020. 12. 23.
	 *  작 성 자 : Jeong.HyunMin
	 * </pre>
	 * @param bldId
	 * @return BuildingSummaryVO
	 */
	BuildingSummaryVO getBuildingWorkingTimeNUsedPower(String bldId);
	
	/**
	 * 
	 * <pre>
	 *  메소드명 : fmBuildingEquipRefrigerationStatus
	 *  설    명 : 빌딩별 냉방시스템 현황
	 *  작 성 일 : 2020. 12. 29.
	 *  작 성 자 : Jeong.HyunMin
	 * </pre>
	 * @param bldId
	 * @return BuildingVO
	 */
	BuildingVO fmBuildingEquipRefrigerationStatus(String bldId);
	
	/**
	 * 
	 * <pre>
	 *  메소드명 : fmBuildingEquipAirhandlingStatus
	 *  설    명 : 빌딩별 공조기 현황
	 *  작 성 일 : 2020. 12. 31.
	 *  작 성 자 : Jeong.HyunMin
	 * </pre>
	 * @param bldId
	 * @return BuildingVO
	 */
	BuildingVO fmBuildingEquipAirhandlingStatus(String bldId);
	
	/**
	 * 
	 * <pre>
	 *  메소드명 : fmBuildingEquipHeatingStatus
	 *  설    명 : 빌딩 난방 시스템 현황
	 *  작 성 일 : 2021. 1. 5.
	 *  작 성 자 : Jeong.HyunMin
	 * </pre>
	 * @param bldId
	 * @return BuildingVO
	 */
	BuildingVO fmBuildingEquipHeatingStatus(String bldId);
	
	/**
	 * 
	 * <pre>
	 *  메소드명 : fmBuildingEquipHeatingDetail
	 *  설    명 : 빌딩 난방 시스템 현황 상세
	 *  작 성 일 : 2021. 1. 5.
	 *  작 성 자 : Jeong.HyunMin
	 * </pre>
	 * @param bldId
	 * @return BuildingHeatVO
	 */
	BuildingHeatVO fmBuildingEquipHeatingDetail(String bldId);
	
	/**
	 * 
	 * <pre>
	 *  메소드명 : fmBuildingEquipOperateTime
	 *  설    명 : 냉방시스템별 운전 현황
	 *  작 성 일 : 2020. 12. 29.
	 *  작 성 자 : Jeong.HyunMin
	 * </pre>
	 * @param bldId
	 * @param equipment
	 * @return BuildingVO
	 */
	BuildingVO fmBuildingEquipOperateTime(String bldId, String equipment);
	
	/**
	 * 
	 * <pre>
	 *  메소드명 : fmBldTypeEquipStatus
	 *  설    명 : 설비별 빌딩군 현황
	 *  작 성 일 : 2020. 12. 30.
	 *  작 성 자 : Jeong.HyunMin
	 * </pre>
	 * @return List<EquipVO>
	 */
	List<EquipVO> fmBldTypeEquipStatus();
	
	/**
	 * 
	 * <pre>
	 *  메소드명 : fmBuildingEquipStatus
	 *  설    명 : 설비별 빌딩 현황
	 *  작 성 일 : 2020. 12. 30.
	 *  작 성 자 : Jeong.HyunMin
	 * </pre>
	 * @return List<EquipVO>
	 */
	List<EquipVO> fmBuildingEquipStatus();
	
	/**
	 * 
	 * <pre>
	 *  메소드명 : fmBuildingEquipStatus
	 *  설    명 : 설비별 빌딩 현황
	 *  작 성 일 : 2021. 1. 11.
	 *  작 성 자 : Jeong.HyunMin
	 * </pre>
	 * @param bldId
	 * @return
	 */
	List<EquipVO> fmBuildingEquipStatus(String bldId);
	
	/**
	 * 
	 * <pre>
	 *  메소드명 : fmBuildingAirhandlingSummary
	 *  설    명 : 빌딩 공조기 현황
	 *  작 성 일 : 2021. 1. 4.
	 *  작 성 자 : Jeong.HyunMin
	 * </pre>
	 * @param bldId
	 * @return BuildingVO
	 */
	BuildingVO fmBuildingAirhandlingSummary(String bldId);
	
	/**
	 * 
	 * <pre>
	 *  메소드명 : fmBuildingFloor
	 *  설    명 : 빌딩 층 목록 조회
	 *  작 성 일 : 2021. 1. 4.
	 *  작 성 자 : Jeong.HyunMin
	 * </pre>
	 * @param bldId
	 * @return BuildingVO
	 */
	BuildingVO fmBuildingFloor(String bldId);
	
	/**
	 * 
	 * <pre>
	 *  메소드명 : fmBuildingEquipRefrigerationWeek
	 *  설    명 : 빌딩 냉동기별 Week Trend 조회
	 *  작 성 일 : 2021. 1. 5.
	 *  작 성 자 : Jeong.HyunMin
	 * </pre>
	 * @param bldId
	 * @return List<EquipObjVO>
	 */
	List<EquipObjVO> fmBuildingEquipRefrigerationWeek(String bldId);
	
	/**
	 * 
	 * <pre>
	 *  메소드명 : fmBuildingEquipAmbientAirFloorState
	 *  설    명 : 빌딩 외기 냉방 운영 현황 조회
	 *  작 성 일 : 2021. 1. 6.
	 *  작 성 자 : Jeong.HyunMin
	 * </pre>
	 * @param bldId
	 * @param floor
	 * @return List<FloorAmbientAirVO>
	 */
	List<FloorAmbientAirVO> fmBuildingEquipAmbientAirFloorState(String bldId, String floor);
	
	/**
	 * 
	 * <pre>
	 *  메소드명 : fmBldTypeRefrigerationWeek
	 *  설    명 : 빌딩별 냉동기 Week Trend 조회
	 *  작 성 일 : 2021. 1. 7.
	 *  작 성 자 : Jeong.HyunMin
	 * </pre>
	 * @return List<BuildingVO>
	 */
    List<BuildingVO> fmBldTypeRefrigerationWeek();
}
