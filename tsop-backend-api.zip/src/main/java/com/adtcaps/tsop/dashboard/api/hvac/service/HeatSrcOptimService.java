package com.adtcaps.tsop.dashboard.api.hvac.service;

import com.adtcaps.tsop.dashboard.api.hvac.domain.AirEnvirResultVO;
import com.adtcaps.tsop.dashboard.api.hvac.domain.HeatSourceOptiResultVO;

public interface HeatSrcOptimService {
 
	public AirEnvirResultVO findRealTimeIntegratedAir(String bldId);
	public HeatSourceOptiResultVO findHeatSourceOptimize(String bldId,String bldName);
	 
}
