package com.adtcaps.tsop.dashboard.api.esop.domain;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class EsopAlarmContentDto {
	private String bldId;
	private String esoYn;
	private String fireResultId;
}
