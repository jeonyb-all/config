package com.adtcaps.tsop.dashboard.api.fm.service.impl;

import static java.util.stream.Collectors.toList;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import com.adtcaps.tsop.dashboard.api.fm.domain.BuildingEquipDayWeekVO;
import com.adtcaps.tsop.dashboard.api.fm.domain.BuildingEquipHourVO;
import com.adtcaps.tsop.dashboard.api.fm.domain.BuildingEquipWorkTimeVO;
import com.adtcaps.tsop.dashboard.api.fm.domain.BuildingHeatVO;
import com.adtcaps.tsop.dashboard.api.fm.domain.BuildingPointVO;
import com.adtcaps.tsop.dashboard.api.fm.domain.BuildingStatusVO;
import com.adtcaps.tsop.dashboard.api.fm.domain.BuildingSummaryVO;
import com.adtcaps.tsop.dashboard.api.fm.domain.BuildingVO;
import com.adtcaps.tsop.dashboard.api.fm.domain.EquipObjVO;
import com.adtcaps.tsop.dashboard.api.fm.domain.EquipObjWeekVO;
import com.adtcaps.tsop.dashboard.api.fm.domain.EquipVO;
import com.adtcaps.tsop.dashboard.api.fm.domain.FloorAmbientAirVO;
import com.adtcaps.tsop.dashboard.api.fm.domain.FmTrendVO;
import com.adtcaps.tsop.dashboard.api.fm.domain.FmVO;
import com.adtcaps.tsop.dashboard.api.fm.domain.InTemprCellHourValueResultDto;
import com.adtcaps.tsop.dashboard.api.fm.domain.InTemprFloorCellResultDto;
import com.adtcaps.tsop.dashboard.api.fm.domain.PowerUnitVO;
import com.adtcaps.tsop.dashboard.api.fm.domain.PowerUnitViewVO;
import com.adtcaps.tsop.dashboard.api.fm.domain.RoomCondition;
import com.adtcaps.tsop.dashboard.api.fm.mapper.FmMapper;
import com.adtcaps.tsop.dashboard.api.fm.service.FmService;
import com.adtcaps.tsop.helper.service.HelperService;
import com.adtcaps.tsop.helper.util.CommonObjectUtil;

@Service
public class FmServiceImpl implements FmService{

	@Autowired
	private FmMapper fmMapper;
	
	@Autowired
	private HelperService helperService;
	
	@Override
	public List<FmVO> getFmEquipment() {
		return fmMapper.getFmEquipment();
	}

	@Override
	public List<PowerUnitViewVO> getPowerUnit() {

		List<PowerUnitVO> powerUnilList = fmMapper.getPowerUnit();
		List<PowerUnitViewVO> resultList = new ArrayList<>();
		
		for (PowerUnitVO FmVO : powerUnilList) {
            //max
            PowerUnitViewVO maxVo = new PowerUnitViewVO();
            maxVo.setGroupName(FmVO.getBldTypeCdName());
            maxVo.setBuildingName(FmVO.getMaxBldName());
            maxVo.setMaxBldAbbrName(FmVO.getMaxBldAbbrName());
            maxVo.setAvg(FmVO.getAvgVal());
            maxVo.setVal(FmVO.getMaxVal());
            resultList.add(maxVo);

            //min
            PowerUnitViewVO minVo = new PowerUnitViewVO();
            minVo.setGroupName(FmVO.getBldTypeCdName());
            minVo.setBuildingName(FmVO.getMinBldName());
            minVo.setMinBldAbbrName(FmVO.getMinBldAbbrName());
            minVo.setAvg(FmVO.getAvgVal());
            minVo.setVal(FmVO.getMinVal());
            resultList.add(minVo);
        }
		
		return resultList;
	}

	public List<RoomCondition> roomEnvironmentNew(final String equipmentCd) {
		List<FmVO> bldList = fmMapper.getRoomEnvironmentBldList(equipmentCd);

		if (bldList == null) {
			return Collections.emptyList();
		}

		List<RoomCondition> roomConditions = bldList.stream().map(b -> {
			List<FmVO> fmList = fmMapper.roomEnvironment(b.getBldId(), b.getBldName(), equipmentCd);
			for (int i = 1; i < fmList.size() - 1; i++) {
				if (fmList.get(i).getCurrentVal() == null) {
					fmList.get(i).setCurrentVal(fmList.get(i - 1).getCurrentVal());
				}
			}
			fmList.remove(0);

			RoomCondition roomCondition = new RoomCondition();
			roomCondition.setBldId(b.getBldId());
			roomCondition.setBldName(b.getBldName());
			roomCondition.setPeriodHour(fmList.stream().map(FmVO::getPeriodHour).collect(toList()));
			roomCondition.setCurrentVal(fmList.stream().map(FmVO::getCurrentVal).collect(toList()));
			return roomCondition;
		}).collect(toList());

		return roomConditions;
	}

	public List<BuildingSummaryVO> getWorkingTimeNUsedPower(String bldId) {
		return fmMapper.getBuildingSummary();
	}

	@Override
	public List<FmTrendVO> fmBuildingPointStatAvg(String bldId) {
		List<FmTrendVO> fmTrendList= fmMapper.fmBuildingPointStatAvg(bldId);
		String[] bldArr = {"0001","0002","0003","0004"};
		List<String> bldList = Arrays.asList(bldArr);
		for(FmTrendVO vo : fmTrendList) {
			if(!bldList.contains(vo.getBldId())) {
				vo.setStartHour("-");
				vo.setEndHour("-");
				vo.setOperationHour("-");
			}
			vo.setStartHour(StringUtils.defaultString(vo.getStartHour(), "-"));
			vo.setEndHour(StringUtils.defaultString(vo.getEndHour(), "-"));
			vo.setOperationHour(StringUtils.defaultString(vo.getOperationHour(), "-"));
			
			if("AHU".equals(vo.getEquipmentCd())) {	//공조기
				if(!bldList.contains(vo.getBldId())) {
					vo.setOuterDamperOpenRate("-");
				} else {
					vo.setOuterDamperOpenRate(StringUtils.defaultString(vo.getOuterDamperOpenRate(), "-"));
				}
			}
			
			if("CHR".equals(vo.getEquipmentCd())) {	//냉동기
				if(!bldList.contains(vo.getBldId())) {
					vo.setEqptWorkNum("-");
					vo.setEqptTotalNum("-");
					vo.setCoolWaterTemperatureIn("-");
					vo.setCoolWaterTemperatureOut("-");
				} else {
					vo.setEqptWorkNum(StringUtils.defaultString(vo.getEqptWorkNum(), "-"));
					vo.setEqptTotalNum(StringUtils.defaultString(vo.getEqptTotalNum(), "-"));
					vo.setCoolWaterTemperatureIn(StringUtils.defaultString(vo.getCoolWaterTemperatureIn(), "-"));
					vo.setCoolWaterTemperatureOut(StringUtils.defaultString(vo.getCoolWaterTemperatureOut(), "-"));
				}
				
			}
			
			if("CLT".equals(vo.getEquipmentCd())) {	//냉각탑
				if(!bldList.contains(vo.getBldId())) {
					vo.setEqptWorkNum("-");
					vo.setEqptTotalNum("-");
					vo.setCoolantTemperatureIn("-");
					vo.setCoolantTemperatureOut("-");
				} else {
					vo.setEqptWorkNum(StringUtils.defaultString(vo.getEqptWorkNum(), "-"));
					vo.setEqptTotalNum(StringUtils.defaultString(vo.getEqptTotalNum(), "-"));
					vo.setCoolantTemperatureIn(StringUtils.defaultString(vo.getCoolantTemperatureIn(), "-"));
					vo.setCoolantTemperatureOut(StringUtils.defaultString(vo.getCoolantTemperatureOut(), "-"));
				}
				
			}
		}
		
		return fmTrendList;
	}
	
	/**
	 * <pre>
	 *  메소드명 : fmBuildingEquipHour
	 *  설    명 : 빌딩 최근 24시간 온습도 조회
	 *  작 성 일 : 2020. 12. 21.
	 *  작 성 자 : Jeong.HyunMin
	 * </pre>
	 * @param bldId
	 * @param equipment
	 * @return BuildingVO
	 */
	@Override
    public BuildingVO fmBuildingEquipHour(String bldId, String equipment){
        BuildingVO bldInfo = fmMapper.getBuildingInfo(bldId);
        List<BuildingEquipHourVO> hourList = fmMapper.getBuildingEquipHour(bldId, equipment);
        
        bldInfo.setPeriodHour(hourList.stream().map(BuildingEquipHourVO::getHour).collect(toList()));       //시간대
        bldInfo.setCurrentVal(hourList.stream().map(BuildingEquipHourVO::getCurVal).collect(toList()));     //값
        
        return bldInfo;
    }
		
	 /**
     * 
     * <pre>
     *  메소드명 : fmBuildingEquipPointHour
     *  설    명 : 빌딩 포인트별 24시간 온습도 조회
     *  작 성 일 : 2020. 12. 21.
     *  작 성 자 : Jeong.HyunMin
     * </pre>
     * @param bldId
     * @param equipment
     * @return BuildingVO
     */
	@Override
	public BuildingVO fmBuildingEquipPointHour(String bldId, String equipment){
	    BuildingVO bldInfo = fmMapper.getBuildingInfo(bldId);
	    List<BuildingPointVO> objectList = fmMapper.getBuildingEquipPoint(bldId, equipment);
	    List<BuildingEquipHourVO> equipHourList = fmMapper.getBuildingEquipPointHour(bldId, equipment);
	    
	    // 시간정보..
	 	List<String> hourList = helperService.list12HourFromCurrentTime();
	    
	 	if (!CollectionUtils.isEmpty(objectList)) {
			for (BuildingPointVO buildingPointVO : objectList) {
				String objectId = StringUtils.defaultString(buildingPointVO.getObjectId());
				String locFloor = StringUtils.defaultString(buildingPointVO.getLocFloor());
				
				if (!"".equals(objectId)) {
					List<BuildingEquipHourVO> hourValueList = new ArrayList<BuildingEquipHourVO>();
					for (String statHour : hourList) {
						boolean findSameHour = false;
						String tempObjectId = "";
						String tempLocFloor = "";
						String tempStatHour = "";
						float tempCurVal = 0;
						for (BuildingEquipHourVO buildingEquipHourVO : equipHourList) {
							tempObjectId = StringUtils.defaultString(buildingEquipHourVO.getObjectId());
							tempLocFloor = StringUtils.defaultString(buildingEquipHourVO.getLocFloor());
							if (buildingEquipHourVO.getHour() != null) {
								tempStatHour = String.valueOf(buildingEquipHourVO.getHour()).replaceAll(".0", "");
							}
							if (buildingEquipHourVO.getCurVal() != null) {
								tempCurVal = buildingEquipHourVO.getCurVal();
							}
							if (objectId.equals(tempObjectId) && locFloor.equals(tempLocFloor) && statHour.equals(tempStatHour)) {
								findSameHour = true;
								break;
							}
						}
						if (findSameHour) {
							BuildingEquipHourVO buildingEquipHourVO = new BuildingEquipHourVO();
							buildingEquipHourVO.setObjectId(objectId);
							buildingEquipHourVO.setLocFloor(locFloor);
							buildingEquipHourVO.setHour(Float.parseFloat(statHour));
							buildingEquipHourVO.setCurVal(tempCurVal);
							hourValueList.add(buildingEquipHourVO);
						} else {
							
							BuildingEquipHourVO buildingEquipHourVO = new BuildingEquipHourVO();
							buildingEquipHourVO.setObjectId(objectId);
							buildingEquipHourVO.setLocFloor(locFloor);
							buildingEquipHourVO.setHour(Float.parseFloat(statHour));
							hourValueList.add(buildingEquipHourVO);
						}
					}
					buildingPointVO.setHourList(hourValueList);
				} else {
					List<BuildingEquipHourVO> hourValueList = new ArrayList<BuildingEquipHourVO>();
					for (String statHour : hourList) {
						BuildingEquipHourVO buildingEquipHourVO = new BuildingEquipHourVO();
						buildingEquipHourVO.setHour(Float.parseFloat(statHour));
						hourValueList.add(buildingEquipHourVO);
					}
					buildingPointVO.setHourList(hourValueList);
				}
			}
		}
	 	
	 	bldInfo.setObjectList(objectList);
	 	
//	    for (BuildingPointVO objInfo : objectList) {
//	        if(objInfo.getObjectId() != null) {
//	            objInfo.setHourList(hourList.stream().filter(hour -> (objInfo.getObjectId()).equals(hour.getObjectId()) && (objInfo.getLocFloor()).equals(hour.getLocFloor()) ).collect(toList()));
//	        }
//	    }
//	    bldInfo.setObjectList(objectList);
	    
	    return bldInfo;
	}
	
	/**
     * 
     * <pre>
     *  메소드명 : fmBuildingEquipDayWeek
     *  설    명 : 빌딩 별 최근 7일간 온습도 조회
     *  작 성 일 : 2020. 12. 21.
     *  작 성 자 : Jeong.HyunMin
     * </pre>
     * @param equipment
     * @return List<BuildingVO>
     */
	@Override
	public List<BuildingVO> fmBuildingEquipDayWeek(String equipment){
	    List<BuildingVO> bldList = fmMapper.getBuildingInfo();	    
	    for (BuildingVO bldInfo : bldList) {
	        bldInfo.setWeekDayList(fmMapper.getBuildingEquipDayWeek(bldInfo.getBldId(), equipment));
        }
	    return bldList;
	}

	/**
     * 
     * <pre>
     *  메소드명 : getBuildingWorkingTimeNUsedPower
     *  설    명 : 빌딩군관리자 빌딩별 전력사용 및 사용시간 조회
     *  작 성 일 : 2020. 12. 23.
     *  작 성 자 : Jeong.HyunMin
     * </pre>
     * @return List<BuildingSummaryVO>
     */
	@Override
	public List<BuildingSummaryVO> getBuildingWorkingTimeNUsedPower(){
	    List<BuildingSummaryVO> bldList = fmMapper.getBuildingWorkingTimeNUsedPower();
	    List<BuildingEquipWorkTimeVO> equipList = fmMapper.getBuildingEquipWorkTime(null);
	    for (BuildingSummaryVO bldInfo : bldList) {
	        bldInfo.setEquipment(equipList.stream().filter(equip -> (bldInfo.getBldId()).equals(equip.getBldId())).collect(toList()));
	    }	    
	    return bldList;
	}
	
	/**
     * 
     * <pre>
     *  메소드명 : getBuildingWorkingTimeNUsedPower
     *  설    명 : 빌딩 전력사용 및 사용시간 조회
     *  작 성 일 : 2020. 12. 23.
     *  작 성 자 : Jeong.HyunMin
     * </pre>
     * @param bldId
     * @return BuildingSummaryVO
     */
	@Override
	public BuildingSummaryVO getBuildingWorkingTimeNUsedPower(String bldId) {
	    BuildingSummaryVO bldInfo = fmMapper.getBuildingWorkingTimeNUsedPower(bldId);
	    bldInfo.setEquipment(fmMapper.getBuildingEquipWorkTime(bldInfo.getBldId()));
	    return bldInfo;
	}
	
	/**
     * 
     * <pre>
     *  메소드명 : fmBuildingEquipRefrigerationStatus
     *  설    명 : 빌딩별 냉방시스템 현황
     *  작 성 일 : 2020. 12. 29.
     *  작 성 자 : Jeong.HyunMin
     * </pre>
     * @param bldId
     * @return BuildingVO
     */
	@Override
	public BuildingVO fmBuildingEquipRefrigerationStatus(String bldId){
	    BuildingVO bldInfo = fmMapper.getBuildingInfo(bldId);
	    bldInfo.setChrDayWeekList(fmMapper.getBuildingCHRDayWeek(bldId));
	    bldInfo.setCltDayWeekList(fmMapper.getBuildingCLTDayWeek(bldId));
	    return bldInfo;
	}
	
	/**
     * 
     * <pre>
     *  메소드명 : fmBuildingEquipAirhandlingStatus
     *  설    명 : 빌딩별 공조기 현황
     *  작 성 일 : 2020. 12. 31.
     *  작 성 자 : Jeong.HyunMin
     * </pre>
     * @param bldId
     * @return BuildingVO
     */
	@Override
    public BuildingVO fmBuildingEquipAirhandlingStatus(String bldId){
        BuildingVO bldInfo = fmMapper.getBuildingInfo(bldId);
        bldInfo.setAhuDayWeekList(fmMapper.getBuildingAHUDayWeek(bldId));
        return bldInfo;
    }
	
	
	/**
     * 
     * <pre>
     *  메소드명 : fmBuildingEquipHeatingStatus
     *  설    명 : 빌딩 난방 시스템 현황
     *  작 성 일 : 2021. 1. 5.
     *  작 성 자 : Jeong.HyunMin
     * </pre>
     * @param bldId
     * @return BuildingVO
     */
	@Override
	public BuildingVO fmBuildingEquipHeatingStatus(String bldId){
        BuildingVO bldInfo = fmMapper.getBuildingInfo(bldId);
        bldInfo.setBlrDayWeekList(fmMapper.getBuildingBLRDayWeek(bldId));       //보일러
        bldInfo.setHexDayWeekList(fmMapper.getBuildingHEXDayWeek(bldId));       //열교환기
        return bldInfo;
    }
	
	
	/**
     * 
     * <pre>
     *  메소드명 : fmBuildingEquipHeatingDetail
     *  설    명 : 빌딩 난방 시스템 현황 상세
     *  작 성 일 : 2021. 1. 5.
     *  작 성 자 : Jeong.HyunMin
     * </pre>
     * @param bldId
     * @return BuildingHeatVO
     */
	@Override
	public BuildingHeatVO fmBuildingEquipHeatingDetail(String bldId) {
	    BuildingHeatVO bldHeatInfo = new BuildingHeatVO();
	    bldHeatInfo.setBldId(bldId);
	    
	    BuildingVO bldInfo = fmMapper.getBuildingInfo(bldId);
	    bldHeatInfo.setBldName(bldInfo.getBldName());
	    
	    bldHeatInfo.setBlrTmList(fmMapper.getEquipOperateTm(bldId, "4100"));       //보일러
	    bldHeatInfo.setHexTmList(fmMapper.getEquipOperateTm(bldId, "4200"));       //열교환기
	    bldHeatInfo.setFloorList(fmMapper.getBuildingFloorEnv(bldId));             //츨별 온도
	    return bldHeatInfo;
	}
	
	/**
     * 
     * <pre>
     *  메소드명 : fmBuildingEquipOperateTime
     *  설    명 : 냉방시스템별 운전 현황
     *  작 성 일 : 2020. 12. 29.
     *  작 성 자 : Jeong.HyunMin
     * </pre>
     * @param bldId
     * @param equipment
     * @return BuildingVO
     */
	@Override
	public BuildingVO fmBuildingEquipOperateTime(String bldId, String equipment) {
	    BuildingVO bldInfo = fmMapper.getBuildingInfo(bldId);
	    bldInfo.setOprTmList(fmMapper.getEquipOperateTm(bldId, equipment));
	    return bldInfo;
	}
	
	/**
     * 
     * <pre>
     *  메소드명 : fmBldTypeEquipStatus
     *  설    명 : 설비별 빌딩군 현황
     *  작 성 일 : 2020. 12. 30.
     *  작 성 자 : Jeong.HyunMin
     * </pre>
     * @return List<EquipVO>
     */
	@Override
	public List<EquipVO> fmBldTypeEquipStatus(){
	    List<EquipVO> equipList = fmMapper.getEquipList();	    
	    List<BuildingStatusVO> bldTypeList = fmMapper.getBldTypeEquipStatus(); 
	    for (EquipVO equipInfo : equipList) {
	        equipInfo.setStatusList(bldTypeList.stream().filter( bldType -> (equipInfo.getFacilityCd()).equals(bldType.getFacilityMcategoryCd())).collect(toList()));	        
	    }
	    return equipList;
	}
	
	/**
     * 
     * <pre>
     *  메소드명 : fmBuildingEquipStatus
     *  설    명 : 설비별 빌딩 현황
     *  작 성 일 : 2020. 12. 30.
     *  작 성 자 : Jeong.HyunMin
     * </pre>
     * 
     * @return List<EquipVO>
     */
	@Override
	public List<EquipVO> fmBuildingEquipStatus(){
	    List<EquipVO> equipList = fmMapper.getEquipList();
	    List<BuildingStatusVO> buildingList = fmMapper.getBuildingEquipStatus(); 
        for (EquipVO equipInfo : equipList) {
            equipInfo.setStatusList(buildingList.stream().filter( bldInfo -> (equipInfo.getFacilityCd()).equals(bldInfo.getFacilityMcategoryCd())).collect(toList()));          
        }
	    return equipList;
	}
	
	/**
	 * <pre>
	 *  메소드명 : fmBuildingEquipStatus
	 *  설    명 : 설비별 빌딩 현황
	 *  작 성 일 : 2021. 1. 11.
	 *  작 성 자 : Jeong.HyunMin
	 * </pre>
	 * @param bldId
	 * @return
	 */
    @Override
    public List<EquipVO> fmBuildingEquipStatus(String bldId){
        return fmMapper.getBldEquipList(bldId);
    }
	
	/**
     * 
     * <pre>
     *  메소드명 : fmBuildingAirhandlingSummary
     *  설    명 : 빌딩 공조기 현황
     *  작 성 일 : 2021. 1. 4.
     *  작 성 자 : Jeong.HyunMin
     * </pre>
     * @param bldId
     * @return BuildingVO
     */
	@Override
	public BuildingVO fmBuildingAirhandlingSummary(String bldId) {
	    BuildingVO bldInfo = fmMapper.getBuildingInfo(bldId);
	    bldInfo.setStatusList(fmMapper.getBuildingAirhandlingSummary(bldId));
	    return bldInfo;
	}
	
	/**
     * 
     * <pre>
     *  메소드명 : fmBuildingFloor
     *  설    명 : 빌딩 층 목록 조회
     *  작 성 일 : 2021. 1. 4.
     *  작 성 자 : Jeong.HyunMin
     * </pre>
     * @param bldId
     * @return BuildingVO
     */
	@Override
	public BuildingVO fmBuildingFloor(String bldId) {
	    BuildingVO bldInfo = fmMapper.getBuildingInfo(bldId);
	    bldInfo.setFloorList(fmMapper.getBuildingFoorList(bldId));
	    return bldInfo;
	}
	
	/**
     * 
     * <pre>
     *  메소드명 : fmBuildingEquipRefrigerationWeek
     *  설    명 : 빌딩 냉동기별 Week Trend 조회
     *  작 성 일 : 2021. 1. 5.
     *  작 성 자 : Jeong.HyunMin
     * </pre>
     * @param bldId
     * @return List<EquipObjVO>
     */
	@Override
	public List<EquipObjVO> fmBuildingEquipRefrigerationWeek(String bldId){
	    String equipmentCHR = "2110";
	    List<EquipObjVO> equipList = fmMapper.getBuildingEquipObjList(bldId, equipmentCHR);
	    List<EquipObjWeekVO> weekList = fmMapper.getBuildingEquipObjWeekList(bldId, equipmentCHR);
	    for (EquipObjVO equipInfo : equipList) {
	        equipInfo.setWeekList(weekList.stream().filter(weekInfo -> (equipInfo.getObjectId()).equals(weekInfo.getObjectId()) ).collect(toList()));
	    }
	    return equipList;
	}
	
	/**
     * 
     * <pre>
     *  메소드명 : fmBuildingEquipAmbientAirFloorState
     *  설    명 : 빌딩 외기 냉방 운영 현황 조회
     *  작 성 일 : 2021. 1. 6.
     *  작 성 자 : Jeong.HyunMin
     * </pre>
     * @param bldId
     * @param floor
     * @return List<FloorAmbientAirVO>
     */
	@Override
	public List<FloorAmbientAirVO> fmBuildingEquipAmbientAirFloorState(String bldId, String floor){
	    return fmMapper.getBuildingEquipAmbientAirFloor(bldId, floor);
	}
	
	/**
     * 
     * <pre>
     *  메소드명 : fmBldTypeRefrigerationWeek
     *  설    명 : 빌딩별 냉동기 Week Trend 조회
     *  작 성 일 : 2021. 1. 7.
     *  작 성 자 : Jeong.HyunMin
     * </pre>
     * @return List<BuildingVO>
     */
	@Override
    public List<BuildingVO> fmBldTypeRefrigerationWeek(){
	    List<BuildingVO> bldList = fmMapper.getBuildingInfo();
	    List<BuildingEquipDayWeekVO> bldStatusList = fmMapper.getBuildingEquipDayWeekStatus();
	    for (BuildingVO bldInfo : bldList) {
	        bldInfo.setWeekDayList(bldStatusList.stream().filter(bldStatusInfo -> (bldInfo.getBldId()).equals(bldStatusInfo.getBldId()) ).collect(toList()));
	    }
	    return bldList;
    }
}
