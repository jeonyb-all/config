package com.adtcaps.tsop.dashboard.api.fm.domain;

import java.util.ArrayList;
import java.util.List;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class BuildingHeatVO {
	private String bldId;
	private String bldName;
	private List<ObjectOprTmVO> blrTmList  = new ArrayList<ObjectOprTmVO>();        //보일러      가동시간
	private List<ObjectOprTmVO> hexTmList  = new ArrayList<ObjectOprTmVO>();        //열교환기     가동시간
	private List<BuildingFloorVO> floorList =  new ArrayList<BuildingFloorVO>();        //층별 온도
}
