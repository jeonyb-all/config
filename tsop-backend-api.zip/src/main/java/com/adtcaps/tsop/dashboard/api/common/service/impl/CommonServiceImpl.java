package com.adtcaps.tsop.dashboard.api.common.service.impl;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.CollectionUtils;

import com.adtcaps.tsop.dashboard.api.common.domain.DashboardCardRequestDto;
import com.adtcaps.tsop.dashboard.api.common.domain.DashboardCardTabNameResultDto;
import com.adtcaps.tsop.dashboard.api.common.domain.DashboardCardTabResultDto;
import com.adtcaps.tsop.dashboard.api.common.domain.GuideScheduleRequestDto;
import com.adtcaps.tsop.dashboard.api.common.domain.GuideScheduleResultDto;
import com.adtcaps.tsop.dashboard.api.common.domain.ScheduleDateDto;
import com.adtcaps.tsop.dashboard.api.common.service.CommonService;
import com.adtcaps.tsop.domain.common.OcoDashboardCardDto;
import com.adtcaps.tsop.domain.common.OcoGuideScheduleDto;
import com.adtcaps.tsop.domain.common.OcoUserDashboardCardDto;
import com.adtcaps.tsop.helper.constant.Const;
import com.adtcaps.tsop.helper.domain.WeekMinMaxDateDto;
import com.adtcaps.tsop.helper.service.HelperService;
import com.adtcaps.tsop.helper.util.CommonDateUtil;
import com.adtcaps.tsop.mapper.common.OcoBulletinboardMapper;
import com.adtcaps.tsop.mapper.common.OcoDashboardCardMapper;
import com.adtcaps.tsop.mapper.common.OcoGuideScheduleMapper;
import com.adtcaps.tsop.mapper.common.OcoHolidayMapper;
import com.adtcaps.tsop.mapper.common.OcoUserDashboardCardMapper;
import com.adtcaps.tsop.portal.api.board.domain.BulletinboardGridRequestDto;
import com.adtcaps.tsop.portal.api.board.domain.BulletinboardGridResultDto;
import com.adtcaps.tsop.portal.api.calendar.domain.CalendarDto;

/**
 * 
 * <ul>
 * <li>업무 그룹명 : tsop-backend-api</li>
 * <li>서브 업무명 : com.adtcaps.tsop.dashboard.api.common.service.impl</li>
 * <li>설  명 : CommonServiceImpl.java</li>
 * <li>작성일 : 2020. 12. 4.</li>
 * <li>작성자 : jeonyb4</li>
 * </ul>
 */
@Transactional
@Service
public class CommonServiceImpl implements CommonService {
	
	@Autowired
	private OcoGuideScheduleMapper ocoGuideScheduleMapper;
	
	@Autowired
	private OcoHolidayMapper ocoHolidayMapper;
	
	@Autowired
	private OcoDashboardCardMapper ocoDashboardCardMapper;
	
	@Autowired
	private OcoBulletinboardMapper ocoBulletinboardMapper;
	
	@Autowired
	private OcoUserDashboardCardMapper ocoUserDashboardCardMapper;
	
	@Autowired
	private HelperService helperService;
	
	/**
	 * 
	 * updateGuideScheduleCheckYn
	 *
	 * @param reqOcoGuideScheduleDto
	 * @return int
	 * @throws Exception 
	 */
	@Override
	public int updateGuideScheduleCheckYn(OcoGuideScheduleDto reqOcoGuideScheduleDto) throws Exception {
		
		int affectRowCount = 0;
		
		try {
			// 일정관리 확인여부 수정...
			int updateRow = ocoGuideScheduleMapper.updateOcoGuideScheduleCheckYn(reqOcoGuideScheduleDto);
			affectRowCount = affectRowCount + updateRow;
			
		} catch (Exception e) {
			throw e;
		}
		
		return affectRowCount;
	}
	
	/**
	 * 
	 * listDashboardNoticeBulletinboard
	 *
	 * @param bulletinboardGridRequestDto
	 * @return List<BulletinboardGridResultDto>
	 * @throws Exception 
	 */
	@Override
	public List<BulletinboardGridResultDto> listDashboardNoticeBulletinboard(BulletinboardGridRequestDto bulletinboardGridRequestDto) throws Exception {
		
		List<BulletinboardGridResultDto> bulletinboardGridResultDtoList = null;
		
		try {
			// 공지사항 목록 조회...
			bulletinboardGridResultDtoList = ocoBulletinboardMapper.listDashboardNoticeBulletinboard(bulletinboardGridRequestDto);
			if (!CollectionUtils.isEmpty(bulletinboardGridResultDtoList)) {
				for (int idx = 0; idx < bulletinboardGridResultDtoList.size(); idx++) {
					BulletinboardGridResultDto bulletinboardGridResultDto = bulletinboardGridResultDtoList.get(idx);
					
					String registDatetime = StringUtils.defaultString(bulletinboardGridResultDto.getRegistDatetime());
					String bulletinStartDate = StringUtils.defaultString(bulletinboardGridResultDto.getBulletinStartDatetime());
					String bulletinEndDate = StringUtils.defaultString(bulletinboardGridResultDto.getBulletinEndDatetime());
					
    				registDatetime = CommonDateUtil.makeDatetimeToDateFormat(registDatetime);
    				bulletinStartDate = CommonDateUtil.makeDatetimeToDateFormat(bulletinStartDate);
    				bulletinEndDate = CommonDateUtil.makeDatetimeToDateFormat(bulletinEndDate);
    				
    				bulletinboardGridResultDto.setRegistDate(registDatetime);
    				bulletinboardGridResultDto.setBulletinStartDate(bulletinStartDate);
    				bulletinboardGridResultDto.setBulletinEndDate(bulletinEndDate);
    				
    				bulletinboardGridResultDtoList.set(idx, bulletinboardGridResultDto);
				}
			}
			
		} catch (Exception e) {
			throw e;
		}
		
		return bulletinboardGridResultDtoList;
	}
	
	/**
	 * 
	 * listDashboardCard
	 *
	 * @param dashboardCardRequestDto
	 * @return List<DashboardCardTabResultDto>
	 * @throws Exception 
	 */
	@Override
	public List<DashboardCardTabResultDto> listDashboardCard(DashboardCardRequestDto dashboardCardRequestDto) throws Exception {
		
		List<DashboardCardTabResultDto> dashboardCardTabResultDtoList = null;
		
		try {
			String roleClCd = StringUtils.defaultString(dashboardCardRequestDto.getRoleClCd());
			if (Const.Code.ROLE_CL_CD.PORTAL_MANAGER.equals(roleClCd) || Const.Code.ROLE_CL_CD.BUILDING_TYPE_MANAGER.equals(roleClCd)) {
				dashboardCardRequestDto.setGroupmgmtYn("Y");
			} else {
				dashboardCardRequestDto.setBldmgmtYn("Y");
			}
			List<DashboardCardTabNameResultDto> dashboardCardTabNameResultDtoList = ocoDashboardCardMapper.listDashboardCardTabName(dashboardCardRequestDto);
			if (!CollectionUtils.isEmpty(dashboardCardTabNameResultDtoList)) {
				dashboardCardTabResultDtoList = new ArrayList<DashboardCardTabResultDto>();
				for (DashboardCardTabNameResultDto dashboardCardTabNameResultDto : dashboardCardTabNameResultDtoList) {
					// tab별로 카드정보 조회..
					String dashboardTabCd = StringUtils.defaultString(dashboardCardTabNameResultDto.getDashboardTabCd());
					dashboardCardRequestDto.setDashboardTabCd(dashboardTabCd);
					List<OcoDashboardCardDto> rsltOcoDashboardCardDtoList = ocoDashboardCardMapper.listDashboardCardByTabCode(dashboardCardRequestDto);
					if (!CollectionUtils.isEmpty(rsltOcoDashboardCardDtoList)) {
						if (Const.Code.ROLE_CL_CD.PORTAL_MANAGER.equals(roleClCd) || Const.Code.ROLE_CL_CD.BUILDING_TYPE_MANAGER.equals(roleClCd)) {
							for (int idx = rsltOcoDashboardCardDtoList.size()-1; idx >= 0; idx--) {
								OcoDashboardCardDto rsltOcoDashboardCardDto = rsltOcoDashboardCardDtoList.get(idx);
								if (Const.Code.DASHBOARD_TAB_CD.HVAC.equals(dashboardTabCd) || Const.Code.DASHBOARD_TAB_CD.ENERGY.equals(dashboardTabCd)) {
									String groupmgmtPageYn = StringUtils.defaultString(rsltOcoDashboardCardDto.getGroupmgmtPageYn());
									if (!"Y".equals(groupmgmtPageYn)) {
										rsltOcoDashboardCardDtoList.remove(idx);
									}
								}
							}
							if (!CollectionUtils.isEmpty(rsltOcoDashboardCardDtoList)) {
								DashboardCardTabResultDto dashboardCardTabResultDto = new DashboardCardTabResultDto();
								dashboardCardTabResultDto.setTabInfo(dashboardCardTabNameResultDto);		// tab 정보 넣고..
								dashboardCardTabResultDto.setCardList(rsltOcoDashboardCardDtoList);			// tab별로 카드정보 넣고..
								dashboardCardTabResultDtoList.add(dashboardCardTabResultDto);
							}
						} else {
							DashboardCardTabResultDto dashboardCardTabResultDto = new DashboardCardTabResultDto();
							dashboardCardTabResultDto.setTabInfo(dashboardCardTabNameResultDto);		// tab 정보 넣고..
							dashboardCardTabResultDto.setCardList(rsltOcoDashboardCardDtoList);			// tab별로 카드정보 넣고..
							dashboardCardTabResultDtoList.add(dashboardCardTabResultDto);
						}
						
					}
				}
			}
		} catch (Exception e) {
			throw e;
		}
		
		return dashboardCardTabResultDtoList;
	}
	
	/**
	 * 
	 * listUserDashboardCard
	 * 
	 * @param dashboardCardRequestDto
	 * @param dashboardCardTabResultDtoList
	 * @return List<OcoUserDashboardCardDto>
	 * @throws Exception 
	 */
	@Override
	public List<OcoUserDashboardCardDto> listUserDashboardCard(DashboardCardRequestDto dashboardCardRequestDto, List<DashboardCardTabResultDto> dashboardCardTabResultDtoList) throws Exception {
		
		List<OcoUserDashboardCardDto> rsltOcoUserDashboardCardDtoList = null;
		try {
			int totalTabCardCount = 0;
			int hvacTabCardCount = 0;
			int elecTabCardCount = 0;
			int drmTabCardCount = 0;
			
			rsltOcoUserDashboardCardDtoList = ocoUserDashboardCardMapper.listUserDashboardCard(dashboardCardRequestDto);
			
			if (CollectionUtils.isEmpty(rsltOcoUserDashboardCardDtoList)) {
				// 조회된 데이터가 없을 때...
				createUserDashboardCard(dashboardCardRequestDto, dashboardCardTabResultDtoList, totalTabCardCount, hvacTabCardCount, elecTabCardCount, drmTabCardCount);
				// 등록 후 재조회...
				rsltOcoUserDashboardCardDtoList = ocoUserDashboardCardMapper.listUserDashboardCard(dashboardCardRequestDto);
			} else {
				// 데이터가 있지만 탭별로 건수가 채워지지 않았을 때...
				for (OcoUserDashboardCardDto rsltOcoUserDashboardCardDto : rsltOcoUserDashboardCardDtoList) {
					String serviceCardTabName = StringUtils.defaultString(rsltOcoUserDashboardCardDto.getServiceCardTabName());
					if (Const.Definition.DASHBOARD_TAB_NAME.TOTAL.equals(serviceCardTabName)) {
						totalTabCardCount = totalTabCardCount + 1;
					}
					if (Const.Definition.DASHBOARD_TAB_NAME.HVAC.equals(serviceCardTabName)) {
						hvacTabCardCount = hvacTabCardCount + 1;
					}
					if (Const.Definition.DASHBOARD_TAB_NAME.ELEC.equals(serviceCardTabName)) {
						elecTabCardCount = elecTabCardCount + 1;
					}
					if (Const.Definition.DASHBOARD_TAB_NAME.DRM.equals(serviceCardTabName)) {
						drmTabCardCount = drmTabCardCount + 1;
					}
				}
				if (totalTabCardCount < 6 || hvacTabCardCount < 3 || elecTabCardCount < 3 || drmTabCardCount < 3) {
					createUserDashboardCard(dashboardCardRequestDto, dashboardCardTabResultDtoList, totalTabCardCount, hvacTabCardCount, elecTabCardCount, drmTabCardCount);
					// 등록 후 재조회...
					rsltOcoUserDashboardCardDtoList = ocoUserDashboardCardMapper.listUserDashboardCard(dashboardCardRequestDto);
				}
			}
    		
		} catch (Exception e) {
			throw e;
		}
		return rsltOcoUserDashboardCardDtoList;
	}
	
	/**
	 * 
	 * createUserDashboardCard
	 * 
	 * @param dashboardCardRequestDto
	 * @param dashboardCardTabResultDtoList
	 * @param totalTabExistYn
	 * @return int
	 * @throws Exception 
	 */
	private int createUserDashboardCard(DashboardCardRequestDto dashboardCardRequestDto, List<DashboardCardTabResultDto> dashboardCardTabResultDtoList, 
			int totalTabCardCount, int hvacTabCardCount, int elecTabCardCount, int drmTabCardCount) throws Exception {
		
		int affectRowCount = 0;
		
		try {
			String bldId = dashboardCardRequestDto.getBldId();
			String userId = dashboardCardRequestDto.getUserId();
			String userName = dashboardCardRequestDto.getUserName();
			
			if (!CollectionUtils.isEmpty(dashboardCardTabResultDtoList)) {
				int totalServiceCardIndexVal = totalTabCardCount;
				int hvacServiceCardIndexVal = hvacTabCardCount;
				int elecServiceCardIndexVal = elecTabCardCount;
				int drmServiceCardIndexVal = drmTabCardCount;
				// HVAC, ELEC, DRM 처리
				for (DashboardCardTabResultDto dashboardCardTabResultDto : dashboardCardTabResultDtoList) {
					DashboardCardTabNameResultDto dashboardCardTabNameResultDto = dashboardCardTabResultDto.getTabInfo();
					String dashboardTabCd = dashboardCardTabNameResultDto.getDashboardTabCd();
					String serviceCardTabName = dashboardCardTabNameResultDto.getServiceCardTabName();
					if (Const.Code.DASHBOARD_TAB_CD.TOTAL.equals(dashboardTabCd)) {
						if (totalTabCardCount == 0) {
							// 최초 조회로 간주...
							List<OcoDashboardCardDto> ocoDashboardCardDtoList = dashboardCardTabResultDto.getCardList();
							for (OcoDashboardCardDto ocoDashboardCardDto : ocoDashboardCardDtoList) {
								String serviceCardId = ocoDashboardCardDto.getServiceCardId();
								
								OcoUserDashboardCardDto reqOcoUserDashboardCardDto = new OcoUserDashboardCardDto();
								reqOcoUserDashboardCardDto.setUserId(userId);
								reqOcoUserDashboardCardDto.setBldId(bldId);
								reqOcoUserDashboardCardDto.setAuditId(userId);
								reqOcoUserDashboardCardDto.setAuditName(userName);
								reqOcoUserDashboardCardDto.setServiceCardId(serviceCardId);
								reqOcoUserDashboardCardDto.setServiceCardTabName(serviceCardTabName);
								totalServiceCardIndexVal = totalServiceCardIndexVal + 1;
								if (totalServiceCardIndexVal > 6) {
									continue;
								}
								reqOcoUserDashboardCardDto.setServiceCardIndexVal(totalServiceCardIndexVal);
								int insertRow = ocoUserDashboardCardMapper.createOcoUserDashboardCard(reqOcoUserDashboardCardDto);
								affectRowCount = affectRowCount + insertRow;
							}
						}
						// 6개가 안 채워질 경우.. 빈값으로라도 채워 넣는다..
						if (totalServiceCardIndexVal < 6) {
							for (int idx = totalServiceCardIndexVal; idx < 6; idx++) {
								OcoUserDashboardCardDto reqOcoUserDashboardCardDto = new OcoUserDashboardCardDto();
								reqOcoUserDashboardCardDto.setUserId(userId);
								reqOcoUserDashboardCardDto.setBldId(bldId);
								reqOcoUserDashboardCardDto.setAuditId(userId);
								reqOcoUserDashboardCardDto.setAuditName(userName);
								reqOcoUserDashboardCardDto.setServiceCardTabName(serviceCardTabName);
								totalServiceCardIndexVal = totalServiceCardIndexVal + 1;
								reqOcoUserDashboardCardDto.setServiceCardIndexVal(totalServiceCardIndexVal);
								int insertRow = ocoUserDashboardCardMapper.createOcoUserDashboardCard(reqOcoUserDashboardCardDto);
								affectRowCount = affectRowCount + insertRow;
							}
						}
					} else if (Const.Code.DASHBOARD_TAB_CD.HVAC.equals(dashboardTabCd)) {
						if (hvacTabCardCount == 0) {
							// 최초 조회로 간주...
							List<OcoDashboardCardDto> ocoDashboardCardDtoList = dashboardCardTabResultDto.getCardList();
							for (OcoDashboardCardDto ocoDashboardCardDto : ocoDashboardCardDtoList) {
								String serviceCardId = ocoDashboardCardDto.getServiceCardId();
								
								OcoUserDashboardCardDto reqOcoUserDashboardCardDto = new OcoUserDashboardCardDto();
								reqOcoUserDashboardCardDto.setUserId(userId);
								reqOcoUserDashboardCardDto.setBldId(bldId);
								reqOcoUserDashboardCardDto.setAuditId(userId);
								reqOcoUserDashboardCardDto.setAuditName(userName);
								reqOcoUserDashboardCardDto.setServiceCardId(serviceCardId);
								reqOcoUserDashboardCardDto.setServiceCardTabName(serviceCardTabName);
								hvacServiceCardIndexVal = hvacServiceCardIndexVal + 1;
								if (hvacServiceCardIndexVal > 3) {
									continue;
								}
								reqOcoUserDashboardCardDto.setServiceCardIndexVal(hvacServiceCardIndexVal);
								int insertRow = ocoUserDashboardCardMapper.createOcoUserDashboardCard(reqOcoUserDashboardCardDto);
								affectRowCount = affectRowCount + insertRow;
							}
						}
						// 3개가 안 채워질 경우.. 빈값으로라도 채워 넣는다..
						if (hvacServiceCardIndexVal < 3) {
							for (int idx = hvacServiceCardIndexVal; idx < 3; idx++) {
								OcoUserDashboardCardDto reqOcoUserDashboardCardDto = new OcoUserDashboardCardDto();
								reqOcoUserDashboardCardDto.setUserId(userId);
								reqOcoUserDashboardCardDto.setBldId(bldId);
								reqOcoUserDashboardCardDto.setAuditId(userId);
								reqOcoUserDashboardCardDto.setAuditName(userName);
								reqOcoUserDashboardCardDto.setServiceCardTabName(serviceCardTabName);
								hvacServiceCardIndexVal = hvacServiceCardIndexVal + 1;
								reqOcoUserDashboardCardDto.setServiceCardIndexVal(hvacServiceCardIndexVal);
								int insertRow = ocoUserDashboardCardMapper.createOcoUserDashboardCard(reqOcoUserDashboardCardDto);
								affectRowCount = affectRowCount + insertRow;
							}
						}
					} else if (Const.Code.DASHBOARD_TAB_CD.ENERGY.equals(dashboardTabCd)) {
						if (elecTabCardCount == 0) {
							// 최초 조회로 간주...
							List<OcoDashboardCardDto> ocoDashboardCardDtoList = dashboardCardTabResultDto.getCardList();
							for (OcoDashboardCardDto ocoDashboardCardDto : ocoDashboardCardDtoList) {
								String serviceCardId = ocoDashboardCardDto.getServiceCardId();
								
								OcoUserDashboardCardDto reqOcoUserDashboardCardDto = new OcoUserDashboardCardDto();
								reqOcoUserDashboardCardDto.setUserId(userId);
								reqOcoUserDashboardCardDto.setBldId(bldId);
								reqOcoUserDashboardCardDto.setAuditId(userId);
								reqOcoUserDashboardCardDto.setAuditName(userName);
								reqOcoUserDashboardCardDto.setServiceCardId(serviceCardId);
								reqOcoUserDashboardCardDto.setServiceCardTabName(serviceCardTabName);
								elecServiceCardIndexVal = elecServiceCardIndexVal + 1;
								if (elecServiceCardIndexVal > 3) {
									continue;
								}
								reqOcoUserDashboardCardDto.setServiceCardIndexVal(elecServiceCardIndexVal);
								int insertRow = ocoUserDashboardCardMapper.createOcoUserDashboardCard(reqOcoUserDashboardCardDto);
								affectRowCount = affectRowCount + insertRow;
							}
						}
						// 3개가 안 채워질 경우.. 빈값으로라도 채워 넣는다..
						if (elecServiceCardIndexVal < 3) {
							for (int idx = elecServiceCardIndexVal; idx < 3; idx++) {
								OcoUserDashboardCardDto reqOcoUserDashboardCardDto = new OcoUserDashboardCardDto();
								reqOcoUserDashboardCardDto.setUserId(userId);
								reqOcoUserDashboardCardDto.setBldId(bldId);
								reqOcoUserDashboardCardDto.setAuditId(userId);
								reqOcoUserDashboardCardDto.setAuditName(userName);
								reqOcoUserDashboardCardDto.setServiceCardTabName(serviceCardTabName);
								elecServiceCardIndexVal = elecServiceCardIndexVal + 1;
								reqOcoUserDashboardCardDto.setServiceCardIndexVal(elecServiceCardIndexVal);
								int insertRow = ocoUserDashboardCardMapper.createOcoUserDashboardCard(reqOcoUserDashboardCardDto);
								affectRowCount = affectRowCount + insertRow;
							}
						}
					} else if (Const.Code.DASHBOARD_TAB_CD.DRM.equals(dashboardTabCd)) {
						if (drmTabCardCount == 0) {
							// 최초 조회로 간주...
							List<OcoDashboardCardDto> ocoDashboardCardDtoList = dashboardCardTabResultDto.getCardList();
							for (OcoDashboardCardDto ocoDashboardCardDto : ocoDashboardCardDtoList) {
								String serviceCardId = ocoDashboardCardDto.getServiceCardId();
								
								OcoUserDashboardCardDto reqOcoUserDashboardCardDto = new OcoUserDashboardCardDto();
								reqOcoUserDashboardCardDto.setUserId(userId);
								reqOcoUserDashboardCardDto.setBldId(bldId);
								reqOcoUserDashboardCardDto.setAuditId(userId);
								reqOcoUserDashboardCardDto.setAuditName(userName);
								reqOcoUserDashboardCardDto.setServiceCardId(serviceCardId);
								reqOcoUserDashboardCardDto.setServiceCardTabName(serviceCardTabName);
								drmServiceCardIndexVal = drmServiceCardIndexVal + 1;
								if (drmServiceCardIndexVal > 3) {
									continue;
								}
								reqOcoUserDashboardCardDto.setServiceCardIndexVal(drmServiceCardIndexVal);
								int insertRow = ocoUserDashboardCardMapper.createOcoUserDashboardCard(reqOcoUserDashboardCardDto);
								affectRowCount = affectRowCount + insertRow;
							}
						}
						// 3개가 안 채워질 경우.. 빈값으로라도 채워 넣는다..
						if (drmServiceCardIndexVal < 3) {
							for (int idx = drmServiceCardIndexVal; idx < 3; idx++) {
								OcoUserDashboardCardDto reqOcoUserDashboardCardDto = new OcoUserDashboardCardDto();
								reqOcoUserDashboardCardDto.setUserId(userId);
								reqOcoUserDashboardCardDto.setBldId(bldId);
								reqOcoUserDashboardCardDto.setAuditId(userId);
								reqOcoUserDashboardCardDto.setAuditName(userName);
								reqOcoUserDashboardCardDto.setServiceCardTabName(serviceCardTabName);
								drmServiceCardIndexVal = drmServiceCardIndexVal + 1;
								reqOcoUserDashboardCardDto.setServiceCardIndexVal(drmServiceCardIndexVal);
								int insertRow = ocoUserDashboardCardMapper.createOcoUserDashboardCard(reqOcoUserDashboardCardDto);
								affectRowCount = affectRowCount + insertRow;
							}
						}
					}
				}
			}
		} catch (Exception e) {
			throw e;
		}
		
		return affectRowCount;
	}
	
	/**
	 * 
	 * mergeOcoUserDashboardCard
	 *
	 * @param reqOcoUserDashboardCardDto
	 * @return int
	 * @throws Exception 
	 */
	@Override
	public int mergeOcoUserDashboardCard(OcoUserDashboardCardDto reqOcoUserDashboardCardDto) throws Exception {
		
		int affectRowCount = 0;
		
		try {
			int mergeRow = ocoUserDashboardCardMapper.mergeOcoUserDashboardCard(reqOcoUserDashboardCardDto);
			affectRowCount = affectRowCount + mergeRow;
			
		} catch (Exception e) {
			throw e;
		}
		
		return affectRowCount;
	}
	
	/**
	 * 
	 * deleteUserDashboardCardElecTabHvacTab
	 *
	 * @param reqOcoUserDashboardCardDto
	 * @return int
	 * @throws Exception 
	 */
	@Override
	public int deleteUserDashboardCardElecTabHvacTab(OcoUserDashboardCardDto reqOcoUserDashboardCardDto) throws Exception {
		
		int affectRowCount = 0;
		
		try {
			int deleteRow = ocoUserDashboardCardMapper.deleteUserDashboardCardElecTabHvacTab(reqOcoUserDashboardCardDto);
			affectRowCount = affectRowCount + deleteRow;
			
		} catch (Exception e) {
			throw e;
		}
		
		return affectRowCount;
	}
	
	/******************************* Old Version ***********************************************/
	
	/**
	 * 
	 * listCalendarYyyymm
	 *
	 * @param guideScheduleRequestDto
	 * @return List<String>
	 * @throws Exception 
	 */
	@Override
	public List<String> listCalendarYyyymm(GuideScheduleRequestDto guideScheduleRequestDto) throws Exception {
		
		List<String> yyyymmList = null;
		
		try {
			
			yyyymmList = helperService.listCalendarYyyymm(guideScheduleRequestDto);
			
		} catch (Exception e) {
			throw e;
		}
		
		return yyyymmList;
	}
	
	/**
	 * 
	 * listCurrentGuideSchedule
	 *
	 * @param guideScheduleRequestDto
	 * @return GuideScheduleResultDto
	 * @throws Exception 
	 */
	@Override
	public GuideScheduleResultDto listCurrentGuideSchedule(GuideScheduleRequestDto guideScheduleRequestDto) throws Exception {
		
		GuideScheduleResultDto guideScheduleResultDto = null;
		
		try {
			// 현재날짜 조회...
			String currentYyyymmdd = helperService.readCurrentDate();
			// 현재날짜가 몇번째 주 인지 조회...
			int currentWeekNum = helperService.readCurrentWeek(currentYyyymmdd);
			// 현재날짜(년월)이 몇번째주까지 있는지 조회...
			StringBuilder firstYyyymmddBuilder = new StringBuilder();
			firstYyyymmddBuilder.append(StringUtils.substring(currentYyyymmdd, 0, 6));
			firstYyyymmddBuilder.append("01");
			int maxWeekNum = helperService.readMaxWeek(firstYyyymmddBuilder.toString());
			// 해당 주차의 startWeekDate, startWeekDate 조회... 
			StringBuilder inputYyyyMmWeekBuilder = new StringBuilder();
			inputYyyyMmWeekBuilder.append(StringUtils.substring(currentYyyymmdd, 0, 6));
			inputYyyyMmWeekBuilder.append("0");
			inputYyyyMmWeekBuilder.append(String.valueOf(currentWeekNum));
			WeekMinMaxDateDto rsltWeekMinMaxDateDto = helperService.readWeekMinMaxDate(inputYyyyMmWeekBuilder.toString());
			// 조회 조건 Setting...
			guideScheduleRequestDto.setStartWeekDate(rsltWeekMinMaxDateDto.getStartWeekDate());
			String endWeekDate = StringUtils.defaultString(rsltWeekMinMaxDateDto.getEndWeekDate());
			endWeekDate = CommonDateUtil.makeToDatetime(endWeekDate);
			guideScheduleRequestDto.setEndWeekDate(endWeekDate);
			// 캘린더 목록 조회...
			List<CalendarDto> rsltCalendarDtoList = ocoHolidayMapper.listCalendar(guideScheduleRequestDto);
			List<ScheduleDateDto> scheduleDateDtoList = new ArrayList<ScheduleDateDto>();
			if (!CollectionUtils.isEmpty(rsltCalendarDtoList)) {
				for (CalendarDto rsltCalendarDto : rsltCalendarDtoList) {
					String calendarDate = StringUtils.defaultString(rsltCalendarDto.getCalendarDate());
					guideScheduleRequestDto.setStartWeekDate(calendarDate);
					// 스케줄 목록 조회...
					List<OcoGuideScheduleDto> rsltOcoGuideScheduleDtoList = ocoGuideScheduleMapper.listGuideScheduleStartDate(guideScheduleRequestDto);
					ScheduleDateDto scheduleDateDto = new ScheduleDateDto();
					scheduleDateDto.setDate(calendarDate);
					scheduleDateDto.setScheduleList(rsltOcoGuideScheduleDtoList);
					scheduleDateDtoList.add(scheduleDateDto);
				}
			}
			
			guideScheduleResultDto = new GuideScheduleResultDto();
			guideScheduleResultDto.setCurrentDate(currentYyyymmdd);
			guideScheduleResultDto.setSelectWeekNum(currentWeekNum);
			guideScheduleResultDto.setMaxWeekNum(maxWeekNum);
			guideScheduleResultDto.setCalendarList(rsltCalendarDtoList);
			guideScheduleResultDto.setDateList(scheduleDateDtoList);
			
		} catch (Exception e) {
			throw e;
		}
		
		return guideScheduleResultDto;
	}
	
	
	@Override
	public GuideScheduleResultDto listGuideSchedule(GuideScheduleRequestDto guideScheduleRequestDto) throws Exception {
		
		GuideScheduleResultDto guideScheduleResultDto = null;
		
		try {
			// UI에서 받은 년월
			String selectYyyymm = guideScheduleRequestDto.getSelectYyyymm();
			// UI에서 받은 주차
			int selectWeekNum = guideScheduleRequestDto.getSelectWeekNum();
			// UI에서 받은 년월이 몇번째주까지 있는지 조회...
			StringBuilder firstYyyymmddBuilder = new StringBuilder();
			firstYyyymmddBuilder.append(selectYyyymm);
			firstYyyymmddBuilder.append("01");
			int maxWeekNum = helperService.readMaxWeek(firstYyyymmddBuilder.toString());
			if (selectWeekNum > maxWeekNum) {
				// UI에서 입력한 주차가 max 주차보다 크면..  max 주차로 대체...
				selectWeekNum = maxWeekNum;
			}
			// 해당 주차의 startWeekDate, startWeekDate 조회... 
			StringBuilder inputYyyyMmWeekBuilder = new StringBuilder();
			inputYyyyMmWeekBuilder.append(selectYyyymm);
			inputYyyyMmWeekBuilder.append("0");
			inputYyyyMmWeekBuilder.append(String.valueOf(selectWeekNum));
			WeekMinMaxDateDto rsltWeekMinMaxDateDto = helperService.readWeekMinMaxDate(inputYyyyMmWeekBuilder.toString());
			// 조회 조건 Setting...
			guideScheduleRequestDto.setStartWeekDate(rsltWeekMinMaxDateDto.getStartWeekDate());
			String endWeekDate = StringUtils.defaultString(rsltWeekMinMaxDateDto.getEndWeekDate());
			endWeekDate = CommonDateUtil.makeToDatetime(endWeekDate);
			guideScheduleRequestDto.setEndWeekDate(endWeekDate);
			// 캘린더 목록 조회...
			List<CalendarDto> rsltCalendarDtoList = ocoHolidayMapper.listCalendar(guideScheduleRequestDto);
			List<ScheduleDateDto> scheduleDateDtoList = new ArrayList<ScheduleDateDto>();
			if (!CollectionUtils.isEmpty(rsltCalendarDtoList)) {
				for (CalendarDto rsltCalendarDto : rsltCalendarDtoList) {
					String calendarDate = StringUtils.defaultString(rsltCalendarDto.getCalendarDate());
					guideScheduleRequestDto.setStartWeekDate(calendarDate);
					// 스케줄 목록 조회...
					List<OcoGuideScheduleDto> rsltOcoGuideScheduleDtoList = ocoGuideScheduleMapper.listGuideScheduleStartDate(guideScheduleRequestDto);
					ScheduleDateDto scheduleDateDto = new ScheduleDateDto();
					scheduleDateDto.setDate(calendarDate);
					scheduleDateDto.setScheduleList(rsltOcoGuideScheduleDtoList);
					scheduleDateDtoList.add(scheduleDateDto);
				}
			}
			
			guideScheduleResultDto = new GuideScheduleResultDto();
			guideScheduleResultDto.setSelectWeekNum(selectWeekNum);
			guideScheduleResultDto.setMaxWeekNum(maxWeekNum);
			guideScheduleResultDto.setCalendarList(rsltCalendarDtoList);
			guideScheduleResultDto.setDateList(scheduleDateDtoList);
			
		} catch (Exception e) {
			throw e;
		}
		
		return guideScheduleResultDto;
	}
	
}
