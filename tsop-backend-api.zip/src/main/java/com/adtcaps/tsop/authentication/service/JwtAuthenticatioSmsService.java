package com.adtcaps.tsop.authentication.service;

import com.adtcaps.tsop.authentication.domain.JwtAuthSmsDto;

import org.springframework.stereotype.Service;


/**
 * 
 * <ul>
 * <li>업무 그룹명 : tsop-backend-api</li>
 * <li>서브 업무명 : com.adtcaps.tsop.authentication.service</li>
 * <li>설  명 : JwtAuthenticatioSmsService.java</li>
 * <li>작성일 : 2021. 01. 06.</li>
 * <li>작성자 : kang</li>
 * </ul>
 */

public interface JwtAuthenticatioSmsService {
    
    /**
	 * 
	 * sendAuthenticationSms
	 *
	 * @param JwtAuthSmsDto
	 * @return int
	 * @throws Exception 
	 */
    public void sendAuthenticationSms(JwtAuthSmsDto request, boolean sendFlag) throws Exception;

    /**
	 * 
	 * readAuthenticationSmsToken
	 *
	 * @param JwtAuthSmsDto
	 * @return String
	 * @throws Exception 
	 */
    public String readAuthenticationSmsToken(JwtAuthSmsDto request) throws Exception;

	/**
	 * 
	 * sendInitSms
	 *
	 * @param JwtAuthSmsDto
	 * @return int
	 * @throws Exception 
	 */
    public void sendInitSms(JwtAuthSmsDto request, boolean sendFlag) throws Exception;

    /**
	 * 
	 * readInitSmsToken
	 *
	 * @param JwtAuthSmsDto
	 * @return String
	 * @throws Exception 
	 */
    public String readInitSmsToken(JwtAuthSmsDto request) throws Exception;

    
    
}
