package com.adtcaps.tsop.authentication.service;


import com.adtcaps.tsop.authentication.domain.JwtAuthResultDto;
import com.adtcaps.tsop.authentication.domain.JwtRequest;
import com.adtcaps.tsop.authentication.mapper.JwtAuthenticationMapper;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

@Service
public class JwtAuthenticationServiceImpl implements UserDetailsService{

  @Autowired
  JwtAuthenticationMapper jwtAuthenticationMapper;

    @Override
    public JwtAuthResultDto loadUserByUsername(String userid) throws UsernameNotFoundException {
      
      JwtAuthResultDto jwtAuthResultDto = jwtAuthenticationMapper.readAuthUserByUserid(userid);

      if(jwtAuthResultDto != null){
        jwtAuthResultDto.setBldIdList(jwtAuthenticationMapper.readBiuldingList(userid));
      }
      
			return jwtAuthResultDto;
    }

    public JwtAuthResultDto loadUserByUsernamePassword(JwtRequest reuqest) throws UsernameNotFoundException{
     
      JwtAuthResultDto jwtAuthResultDto = jwtAuthenticationMapper.readAuthUserByPassword(reuqest);
     
      return jwtAuthResultDto;
     
    }   
}
