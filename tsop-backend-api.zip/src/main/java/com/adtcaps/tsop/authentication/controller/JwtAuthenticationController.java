package com.adtcaps.tsop.authentication.controller;


import javax.naming.LimitExceededException;
import javax.security.sasl.AuthenticationException;
import javax.servlet.http.HttpServletRequest;

import com.adtcaps.tsop.authentication.domain.JwtAuthResultDto;
import com.adtcaps.tsop.authentication.domain.JwtAuthSmsDto;
import com.adtcaps.tsop.authentication.domain.JwtRequest;
import com.adtcaps.tsop.authentication.domain.JwtResponse;
import com.adtcaps.tsop.authentication.service.JwtAuthenticatioSmsService;
import com.adtcaps.tsop.authentication.service.JwtAuthenticationServiceImpl;
import com.adtcaps.tsop.config.JwtTokenUtil;
import com.adtcaps.tsop.domain.common.OcoUserDto;
import com.adtcaps.tsop.helper.constant.Const;
import com.adtcaps.tsop.helper.domain.ResultDto;
import com.adtcaps.tsop.portal.api.user.service.UserService;

import org.apache.commons.lang3.RandomUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.AccountExpiredException;
import org.springframework.security.authentication.LockedException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

@RestController
@CrossOrigin
@RequestMapping(value = "/api", method = RequestMethod.POST)
public class JwtAuthenticationController {
	
	private final String ERR_NULL_USER_INFO = "로그인 정보를 확인 바랍니다.";
	
	private final String ERR_MSG_UPDATE_FAIL = "수정에 실패하였습니다.";
	private final String ERR_MSG_SMS_SEND_FAIL = "알림톡 발송에 실패하였습니다.";
	
	@Value("${service-mode}")
    private String mode;

	@Autowired
	private AuthenticationManager authenticationManager;

	@Autowired
	private JwtTokenUtil jwtTokenUtil;

	@Autowired
	private JwtAuthenticatioSmsService jwtAuthenticationSms;

	@Autowired
	private JwtAuthenticationServiceImpl userDetailsService;
	
	@Autowired
	private UserService userService;
		
	@PostMapping(value="/login/authenticate", produces="application/json; charset=UTF-8")
	public ResponseEntity<?> createAuthenticationToken(@RequestBody JwtRequest authenticationRequest) throws AuthenticationException {
		ResponseEntity<ResultDto> resEntity = null;
		try{
			authenticate(authenticationRequest.getUserId(), authenticationRequest.getPassword());
		
			final JwtAuthResultDto userDetails = userDetailsService.loadUserByUsername(authenticationRequest.getUserId());
			final String token = jwtTokenUtil.generateToken(userDetails);
			resEntity = ResponseEntity.ok(new ResultDto(Const.Common.RESULT_CODE.SUCCESS ,new JwtResponse(token)));
			
		} catch (LockedException e) {
			resEntity = ResponseEntity.ok(new ResultDto(Const.Common.RESULT_CODE.NOTAVAILABLE ,e.getMessage()));
		} catch (BadCredentialsException e) {
			resEntity = ResponseEntity.ok(new ResultDto(Const.Common.RESULT_CODE.UNAUTORIZED ,e.getMessage()));
		} catch (Exception e) {
			resEntity = ResponseEntity.ok(new ResultDto(Const.Common.RESULT_CODE.FAIL ,e.getMessage()));
		}
		return resEntity;
	}

	@PostMapping(value="/login/createauthsms", produces="application/json; charset=UTF-8")
	public ResponseEntity<?> createAuthenticationSms(@RequestBody JwtRequest authenticationRequest, HttpServletRequest ip) throws Exception {
		ResponseEntity<ResultDto> resEntity = null;
		if(ip.getRemoteAddr() == null || ip.getRemoteAddr().equalsIgnoreCase("")){
			authenticationRequest.setIp("unknown");
		}else{
			authenticationRequest.setIp(getClientIpAddr(ip));
		}
		try{
			authenticate(authenticationRequest.getUserId(), authenticationRequest.getPassword());
			
			final JwtAuthResultDto userDetails = userDetailsService.loadUserByUsername(authenticationRequest.getUserId());
			final String token = jwtTokenUtil.generateToken(userDetails);
			final String Authsms = Integer.toString(RandomUtils.nextInt(100000, 1000000));

			JwtAuthSmsDto sendrequest = new JwtAuthSmsDto(authenticationRequest.getUserId(), token, Authsms, authenticationRequest.getIp());
			if(userDetails.getPhoneNm()== null) {
				return ResponseEntity.ok(new ResultDto(Const.Common.RESULT_CODE.FAIL ,"인증받을 휴대폰을 등록해주세요."));
			}
			sendrequest.setPhoneNm(userDetails.getPhoneNm());
			
			if(mode.equalsIgnoreCase(Const.Common.TEST)){
				jwtAuthenticationSms.sendAuthenticationSms(sendrequest, false);
				resEntity = ResponseEntity.ok(new ResultDto(Const.Common.RESULT_CODE.SUCCESS ,Authsms));
			} else {
				jwtAuthenticationSms.sendAuthenticationSms(sendrequest, true);
				resEntity = ResponseEntity.ok(new ResultDto(Const.Common.RESULT_CODE.SUCCESS ,"인증번호가 발송되었습니다."));
			}
		
		} catch (LimitExceededException e) {
			resEntity = ResponseEntity.ok(new ResultDto(Const.Common.RESULT_CODE.EXCESSSENDSMS ,e.getMessage()));
		} catch (LockedException e) {
			resEntity = ResponseEntity.ok(new ResultDto(Const.Common.RESULT_CODE.NOTAVAILABLE ,e.getMessage()));
		} catch (BadCredentialsException e) {
			resEntity = ResponseEntity.ok(new ResultDto(Const.Common.RESULT_CODE.UNAUTORIZED ,e.getMessage()));
		} catch (Exception e) {
			resEntity = ResponseEntity.ok(new ResultDto(Const.Common.RESULT_CODE.FAIL ,"운용자에게 문의해 주세요."));
		}
		return resEntity;
	}

	@PostMapping(value="/login/readauthsmstoken", produces="application/json; charset=UTF-8")
	public ResponseEntity<?> readAuthenticationSmsToken(@RequestBody JwtAuthSmsDto request, HttpServletRequest ip) throws Exception {
		ResponseEntity<ResultDto> resEntity = null;
		if(ip.getRemoteAddr() == null || ip.getRemoteAddr().equalsIgnoreCase("")){
			request.setIp("unknown");
		}else{
			request.setIp(getClientIpAddr(ip));
		}
		
		try {
			String token  = jwtAuthenticationSms.readAuthenticationSmsToken(request);
			resEntity = ResponseEntity.ok(new ResultDto(Const.Common.RESULT_CODE.SUCCESS ,new JwtResponse(token)));
		}catch (BadCredentialsException e) {
			resEntity = ResponseEntity.ok(new ResultDto(Const.Common.RESULT_CODE.UNAUTHORIZEDSMS, e.getMessage()));
		}catch (AccountExpiredException e) {
			resEntity = ResponseEntity.ok(new ResultDto(Const.Common.RESULT_CODE.EXPIREDSMS, "인증번호 입력시간을 초과하셨습니다. "));
		}catch (Exception e) {
			resEntity = ResponseEntity.ok(new ResultDto(Const.Common.RESULT_CODE.FAIL ,e.getMessage()));
		}	
		
		
		return resEntity;
	}
	
	@PostMapping(value="/authentication/reissueToken", produces="application/json; charset=UTF-8")
	public ResponseEntity<?> reissueToken(@RequestHeader("Authorization") String request) throws Exception {
		ResponseEntity<ResultDto> resEntity = null;
		try {
			String jwtToken = request.substring(7);
			String userid = jwtTokenUtil.getUsernameFromToken(jwtToken);
			final JwtAuthResultDto userDetails = userDetailsService.loadUserByUsername(userid);
			final String token = jwtTokenUtil.generateToken(userDetails);
			resEntity = ResponseEntity.ok(new ResultDto(Const.Common.RESULT_CODE.SUCCESS ,new JwtResponse(token)));
		}catch (BadCredentialsException e) {
			resEntity = ResponseEntity.ok(new ResultDto(Const.Common.RESULT_CODE.UNAUTHORIZEDSMS, e.getMessage()));
		}catch (Exception e) {
			resEntity = ResponseEntity.ok(new ResultDto(Const.Common.RESULT_CODE.FAIL ,e.getMessage()));
		}	
		
		
		return resEntity;
	}

	@PostMapping(value="/authentication/authenticateToken", produces="application/json; charset=UTF-8")
	public ResponseEntity<?> authenticateToken(@RequestHeader("Authorization") String request) throws Exception {
		ResponseEntity<ResultDto> resEntity = null;
		try {
			String token  = request.substring(7);
			resEntity = ResponseEntity.ok(new ResultDto(Const.Common.RESULT_CODE.SUCCESS ,new JwtResponse(token)));
		}catch (BadCredentialsException e) {
			resEntity = ResponseEntity.ok(new ResultDto(Const.Common.RESULT_CODE.UNAUTHORIZEDSMS, e.getMessage()));
		}catch (Exception e) {
			resEntity = ResponseEntity.ok(new ResultDto(Const.Common.RESULT_CODE.FAIL ,e.getMessage()));
		}	
		
		
		return resEntity;
	}

	@PostMapping(value="/login/createinitsms", produces="application/json; charset=UTF-8")
	public ResponseEntity<?> createInitSms(@RequestBody JwtRequest authenticationRequest, HttpServletRequest ip) throws Exception {
		ResponseEntity<ResultDto> resEntity = null;
		if(ip.getRemoteAddr() == null || ip.getRemoteAddr().equalsIgnoreCase("")){
			authenticationRequest.setIp("unknown");
		}else{
			authenticationRequest.setIp(getClientIpAddr(ip));
		}
		try{
			final JwtAuthResultDto userDetails = userDetailsService.loadUserByUsername(authenticationRequest.getUserId());
			if(userDetails== null) throw new BadCredentialsException(ERR_NULL_USER_INFO);
			final String Authsms = Integer.toString(RandomUtils.nextInt(100000, 1000000));

			JwtAuthSmsDto sendrequest = new JwtAuthSmsDto(authenticationRequest.getUserId(), "InitPassword", Authsms, authenticationRequest.getIp());
			if(userDetails.getPhoneNm()== null) {
				return ResponseEntity.ok(new ResultDto(Const.Common.RESULT_CODE.FAIL ,"인증받을 휴대폰을 등록해주세요."));
			}
			sendrequest.setPhoneNm(userDetails.getPhoneNm());
			
			if(mode.equalsIgnoreCase(Const.Common.TEST)){
				jwtAuthenticationSms.sendInitSms(sendrequest, false);
				resEntity = ResponseEntity.ok(new ResultDto(Const.Common.RESULT_CODE.SUCCESS ,Authsms));
			} else {
				jwtAuthenticationSms.sendInitSms(sendrequest, true);
				resEntity = ResponseEntity.ok(new ResultDto(Const.Common.RESULT_CODE.SUCCESS ,"인증번호가 발송되었습니다."));
			}
		
		} catch (LimitExceededException e) {
			resEntity = ResponseEntity.ok(new ResultDto(Const.Common.RESULT_CODE.EXCESSSENDSMS ,e.getMessage()));
		} catch (LockedException e) {
			resEntity = ResponseEntity.ok(new ResultDto(Const.Common.RESULT_CODE.NOTAVAILABLE ,e.getMessage()));
		} catch (BadCredentialsException e) {
			resEntity = ResponseEntity.ok(new ResultDto(Const.Common.RESULT_CODE.UNAUTORIZED ,e.getMessage()));
		} catch (Exception e) {
			resEntity = ResponseEntity.ok(new ResultDto(Const.Common.RESULT_CODE.FAIL ,e.getMessage()));
		}
		return resEntity;
	}

	@PostMapping(value="/login/readinitsmstoken", produces="application/json; charset=UTF-8")
	public ResponseEntity<?> readInitSmsToken(@RequestBody JwtAuthSmsDto request, HttpServletRequest ip) throws Exception {
		ResponseEntity<ResultDto> resEntity = null;
		if(ip.getRemoteAddr() == null || ip.getRemoteAddr().equalsIgnoreCase("")){
			request.setIp("unknown");
		}else{
			request.setIp(getClientIpAddr(ip));
		}
		
		try {
			//String token  = jwtAuthenticationSms.readInitSmsToken(request);
			
			final JwtAuthResultDto userDetails = userDetailsService.loadUserByUsername(request.getUserId());
			if (userDetails != null) {
				String userId = request.getUserId();
				String userName = StringUtils.defaultString(userDetails.getUsername());
				String contactPhoneNum = StringUtils.defaultString(userDetails.getPhoneNm());
				OcoUserDto reqOcoUserDto = new OcoUserDto();
				reqOcoUserDto.setUserId(userId);
				reqOcoUserDto.setAuditId(userId);
				reqOcoUserDto.setAuditName(userName);
				reqOcoUserDto.setContactPhoneNum(contactPhoneNum);
				int affectRowCount = userService.updateUserInitialPassword(reqOcoUserDto);
				if (affectRowCount < 1) {
					if (affectRowCount < 0) {
						resEntity = ResponseEntity.ok(new ResultDto(Const.Common.RESULT_CODE.FAIL, ERR_MSG_SMS_SEND_FAIL, affectRowCount));
					} else {
						resEntity = ResponseEntity.ok(new ResultDto(Const.Common.RESULT_CODE.FAIL, ERR_MSG_UPDATE_FAIL, affectRowCount));
					}
				} else {
					resEntity = ResponseEntity.ok(new ResultDto(Const.Common.RESULT_CODE.SUCCESS ,"암호가 초기화 되었습니다. "));
				}
			} else {
				resEntity = ResponseEntity.ok(new ResultDto(Const.Common.RESULT_CODE.FAIL, ERR_NULL_USER_INFO, ""));
			}
		}catch (BadCredentialsException e) {
			resEntity = ResponseEntity.ok(new ResultDto(Const.Common.RESULT_CODE.UNAUTHORIZEDSMS, e.getMessage()));
		}catch (AccountExpiredException e) {
			resEntity = ResponseEntity.ok(new ResultDto(Const.Common.RESULT_CODE.EXPIREDSMS, "인증번호 입력시간을 초과하셨습니다. "));
		}catch (Exception e) {
			resEntity = ResponseEntity.ok(new ResultDto(Const.Common.RESULT_CODE.FAIL ,e.getMessage()));
		}	
		
		
		return resEntity;
	}

	private void authenticate(String username, String password) throws AuthenticationException {
		
		authenticationManager.authenticate(new UsernamePasswordAuthenticationToken(username, password));
		
	}

	public static String getClientIpAddr(HttpServletRequest request) {
		String ip = request.getHeader("X-Forwarded-For");
	 
		if(ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip)) {
			ip = request.getHeader("Proxy-Client-IP");
		}
		if(ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip)) {
			ip = request.getHeader("WL-Proxy-Client-IP");
		}
		if(ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip)) {
			ip = request.getHeader("HTTP_CLIENT_IP");
		}
		if(ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip)) {
			ip = request.getHeader("HTTP_X_FORWARDED_FOR");
		}
		if(ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip)) {
			ip = request.getRemoteAddr();
		}
		
		if(ip !=null && ip.indexOf(":") >= 1){
			ip  = ip.substring(0, ip.indexOf(":"));
		}
	 
		return ip;
	}
	
	
	
}