package com.adtcaps.tsop.authentication.domain;

import java.util.Collection;
import java.util.List;

import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;

public class JwtAuthResultDto implements UserDetails {
    
    private static final long serialVersionUID = 3504042155966107697L;

    private String userId;
    private String userName;
    private String password;
    private String passwordYn;
	private String useYn;
	private String lockYn;
    private String tenantId;
    private String tenantName;
	private String roleClCd;
	private String roleClName;
	private String phoneNm;
	private String partCategoryCd;


    private List<String> bldIdList;
    
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	
	@Override
	public String getUsername() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}
	
	@Override
    public String getPassword() {
        return password;
    }
    public void setPassword(String password) {
        this.password = password;
    }
	
    public String getPasswordYn() {
		return passwordYn;
	}
	public void setPasswordYn(String passwordYn) {
		this.passwordYn = passwordYn;
	}

	public String getPhoneNm() {
		return this.phoneNm;
	}

	public void setPhoneNm(String phoneNm) {
		this.phoneNm = phoneNm;
	}
	
	public String getUseYn() {
		return useYn;
	}
	public void setUseYn(String useYn) {
		this.useYn = useYn;
	}

	public String getLockYn() {
		return this.lockYn;
	}

	public void setLockYn(String lockYn) {
		this.lockYn = lockYn;
	}
	
	public String getTenantId() {
		return tenantId;
	}
	public void setTenantId(String tenantId) {
		this.tenantId = tenantId;
	}
	
	public String getTenantName() {
		return tenantName;
	}
	public void setTenantName(String tenantName) {
		this.tenantName = tenantName;
	}
	
	public String getRoleClCd() {
		return roleClCd;
	}
	public void setRoleClCd(String roleClCd) {
		this.roleClCd = roleClCd;
	}
	
	public String getRoleClName() {
		return roleClName;
	}
	public void setRoleClName(String roleClName) {
		this.roleClName = roleClName;
	}
	
	public String getPartCategoryCd() {
		return partCategoryCd;
	}
	public void setPartCategoryCd(String partCategoryCd) {
		this.partCategoryCd = partCategoryCd;
	}
	
	public List<String> getBldIdList() {
		return bldIdList;
	}
	public void setBldIdList(List<String> bldIdList) {
		this.bldIdList = bldIdList;
	}
	
	@Override
    public boolean isAccountNonExpired() {
        return false;
    }

    @Override
    public boolean isAccountNonLocked() {
        return false;
    }

    @Override
    public boolean isEnabled() {
        if(this.useYn== null ) return false;
        return this.useYn.equalsIgnoreCase("y");
    }

    @Override
    public boolean isCredentialsNonExpired() {
        return false;
    }

    @Override
    public Collection<? extends GrantedAuthority> getAuthorities() {
        return null;
    }
}
