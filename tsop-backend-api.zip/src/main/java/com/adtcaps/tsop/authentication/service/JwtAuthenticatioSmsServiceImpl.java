package com.adtcaps.tsop.authentication.service;

import java.util.ArrayList;
import java.util.List;

import javax.naming.LimitExceededException;

import com.adtcaps.tsop.authentication.domain.JwtAuthSmsDto;
import com.adtcaps.tsop.authentication.mapper.JwtAuthenticationMapper;
import com.adtcaps.tsop.domain.common.OcoKakaoAlimTalkDto;
import com.adtcaps.tsop.helper.constant.Const;
import com.adtcaps.tsop.mapper.common.OcoKakaoAlimTalkMapper;
import com.adtcaps.tsop.portal.api.alimTalk.domain.AlimTalkDetailDto;
import com.adtcaps.tsop.portal.api.alimTalk.domain.AlimTalkRequestDto;
import com.adtcaps.tsop.portal.api.alimTalk.service.AlimTalkService;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.AccountExpiredException;
import org.springframework.stereotype.Service;

@Service
public class JwtAuthenticatioSmsServiceImpl implements JwtAuthenticatioSmsService{
    @Value("${jwt.sms.limituserid}")
    private Integer limitUserId;

    @Value("${jwt.sms.limitip}")
    private Integer limitIp;

    @Autowired
    private JwtAuthenticationMapper jwtAuthenticationMapper;
    
    @Autowired
    private OcoKakaoAlimTalkMapper ocoKakaoAlimTalkMapper;
    
    @Autowired
    private AlimTalkService alimTalkService;
    
    @Override
    public void sendAuthenticationSms(JwtAuthSmsDto request, boolean sendFlag) throws Exception {

         //인증번호 요청 시도 수 제한 체크
         checkAuthSendHist(request);
         //인증 번호 임시 저장
         jwtAuthenticationMapper.createAuthSms(request);
         
         if(sendFlag) {
        	// 알림톡 발송 처리...
     		String contactPhoneNum = StringUtils.defaultString(request.getPhoneNm());
     		OcoKakaoAlimTalkDto reqOcoKakaoAlimTalkDto = new OcoKakaoAlimTalkDto();
     		reqOcoKakaoAlimTalkDto.setTmpltCode(Const.Definition.MSG_TEMPLATE_CODE.TSOP_003);
     		reqOcoKakaoAlimTalkDto.setSmsCreateCd(Const.Code.SMS_CREATE_CD.AUTH);
     		OcoKakaoAlimTalkDto ocoKakaoAlimTalkDto = ocoKakaoAlimTalkMapper.readKakaoAlimTalk(reqOcoKakaoAlimTalkDto);
     		if (ocoKakaoAlimTalkDto != null) {
     			List<AlimTalkDetailDto> alimTalkDetailDtoList = new ArrayList<AlimTalkDetailDto>();
     			String rcverId = request.getUserId();
     			String rcvPhoneNum = contactPhoneNum;
     			AlimTalkDetailDto alimTalkDetailDto = new AlimTalkDetailDto();
     			alimTalkDetailDto.setRcverId(rcverId);
     			alimTalkDetailDto.setRcvPhoneNum(rcvPhoneNum);
     			alimTalkDetailDtoList.add(alimTalkDetailDto);
     			
     			String message = ocoKakaoAlimTalkDto.getMessage();
     			message = message.replaceAll("#\\{\"123456\"\\}", request.getAuthSms());
     			
     			// 카카오 알림톡 발송 처리..
     			AlimTalkRequestDto alimTalkRequestDto = new AlimTalkRequestDto();
     			alimTalkRequestDto.setTmpltCode(Const.Definition.MSG_TEMPLATE_CODE.TSOP_003);
     			alimTalkRequestDto.setRecipient(contactPhoneNum);
     			alimTalkRequestDto.setMessage(message);
     			alimTalkRequestDto.setSmsCreateCd(Const.Code.SMS_CREATE_CD.AUTH);
     			alimTalkRequestDto.setAuditId(request.getUserId());
     			alimTalkRequestDto.setDetailList(alimTalkDetailDtoList);
     			String alarmNoticeResultCd = alimTalkService.sendAlimTalk(alimTalkRequestDto);
     			if (alarmNoticeResultCd.equalsIgnoreCase("7") || alarmNoticeResultCd.equalsIgnoreCase("4")) {
     				throw new Exception("잠시 후 다시 인증번호를 요청해 주세요.");
                } else if (alarmNoticeResultCd.equalsIgnoreCase("2") || alarmNoticeResultCd.equalsIgnoreCase("5")) {
                	throw new Exception("운용자에게 문의해 주세요.");
                }
     		}
         }
    }


    @Override
    public String readAuthenticationSmsToken(JwtAuthSmsDto request) throws Exception {
        JwtAuthSmsDto result = jwtAuthenticationMapper.readAuthSmsToken(request);
        if(result == null) throw new BadCredentialsException("인증번호를 다시 요청 해 주세요.");
        if(result.getPasswordYn().equalsIgnoreCase("0")) throw new BadCredentialsException("로그인 정보를 확인 바랍니다.");
        if(!result.getAuthSms().equalsIgnoreCase(request.getAuthSms()))throw new BadCredentialsException("인증번호를 확인 바랍니다.");
        if(result.getExpirYn().equalsIgnoreCase("N")) throw new AccountExpiredException("JWT token is invalid");

        String token = result.getToken();

        jwtAuthenticationMapper.createAuthHist(result);
        jwtAuthenticationMapper.updateAuthHist(result);
        jwtAuthenticationMapper.updateAuthUseYn(result);
        return token;
    }

    public void checkAuthSendHist(JwtAuthSmsDto request) throws Exception{
        int checkUserid = jwtAuthenticationMapper.checkAuthSmsCntByUserid(request);
        int checkIp = jwtAuthenticationMapper.checkAuthSmsCntByIp(request);

        if(checkUserid > limitUserId || checkIp > limitIp) throw new LimitExceededException("잠시 후 다시 인증 요청하세요.");

    }

    @Override
    public void sendInitSms(JwtAuthSmsDto request, boolean sendFlag) throws Exception {
    	//인증번호 요청 시도 수 제한 체크
        checkAuthSendHist(request);
        //인증 번호 임시 저장
        jwtAuthenticationMapper.createInithSms(request);
    	
        if(sendFlag) {
        	// 알림톡 발송 처리...
      		String contactPhoneNum = StringUtils.defaultString(request.getPhoneNm());
      		OcoKakaoAlimTalkDto reqOcoKakaoAlimTalkDto = new OcoKakaoAlimTalkDto();
      		reqOcoKakaoAlimTalkDto.setTmpltCode(Const.Definition.MSG_TEMPLATE_CODE.TSOP_003);
      		reqOcoKakaoAlimTalkDto.setSmsCreateCd(Const.Code.SMS_CREATE_CD.AUTH);
      		OcoKakaoAlimTalkDto ocoKakaoAlimTalkDto = ocoKakaoAlimTalkMapper.readKakaoAlimTalk(reqOcoKakaoAlimTalkDto);
      		if (ocoKakaoAlimTalkDto != null) {
      			List<AlimTalkDetailDto> alimTalkDetailDtoList = new ArrayList<AlimTalkDetailDto>();
      			String rcverId = request.getUserId();
      			String rcvPhoneNum = contactPhoneNum;
      			AlimTalkDetailDto alimTalkDetailDto = new AlimTalkDetailDto();
      			alimTalkDetailDto.setRcverId(rcverId);
      			alimTalkDetailDto.setRcvPhoneNum(rcvPhoneNum);
      			alimTalkDetailDtoList.add(alimTalkDetailDto);
      			
      			String message = ocoKakaoAlimTalkDto.getMessage();
      			message = message.replaceAll("#\\{\"123456\"\\}", request.getAuthSms());
      			
      			// 카카오 알림톡 발송 처리..
      			AlimTalkRequestDto alimTalkRequestDto = new AlimTalkRequestDto();
      			alimTalkRequestDto.setTmpltCode(Const.Definition.MSG_TEMPLATE_CODE.TSOP_003);
      			alimTalkRequestDto.setRecipient(contactPhoneNum);
      			alimTalkRequestDto.setMessage(message);
      			alimTalkRequestDto.setSmsCreateCd(Const.Code.SMS_CREATE_CD.AUTH);
      			alimTalkRequestDto.setAuditId(request.getUserId());
      			alimTalkRequestDto.setDetailList(alimTalkDetailDtoList);
      			String alarmNoticeResultCd = alimTalkService.sendAlimTalk(alimTalkRequestDto);
      			if (alarmNoticeResultCd.equalsIgnoreCase("7") || alarmNoticeResultCd.equalsIgnoreCase("4")) {
      				throw new Exception("잠시 후 다시 인증번호를 요청해 주세요.");
                 } else if (alarmNoticeResultCd.equalsIgnoreCase("2") || alarmNoticeResultCd.equalsIgnoreCase("5")) {
                 	throw new Exception("운용자에게 문의해 주세요.");
                 }
      		}
        }
        
    }


    @Override
    public String readInitSmsToken(JwtAuthSmsDto request) throws Exception {
        JwtAuthSmsDto result = jwtAuthenticationMapper.readInitSmsToken(request);
        if(result == null) throw new BadCredentialsException("인증번호를 다시 요청 해 주세요.");
        if(!result.getAuthSms().equalsIgnoreCase(request.getAuthSms()))throw new BadCredentialsException("인증번호를 확인 바랍니다.");
        if(result.getExpirYn().equalsIgnoreCase("N")) throw new AccountExpiredException("JWT token is invalid");

        String token = result.getToken();

        jwtAuthenticationMapper.updateAuthUseYn(result);
        return token;
    }



}

