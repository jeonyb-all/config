package com.adtcaps.tsop.mapper.work;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;

import com.adtcaps.tsop.domain.work.OwkReportDto;
import com.adtcaps.tsop.helper.domain.BasePageDto;
import com.adtcaps.tsop.portal.api.report.domain.ReportComboResultDto;

/**
 * 
 * <ul>
 * <li>업무 그룹명 : tsop-backend-api</li>
 * <li>서브 업무명 : com.adtcaps.tsop.mapper.work</li>
 * <li>설  명 : OwkReportMapper.java</li>
 * <li>작성일 : 2021. 12. 6.</li>
 * <li>작성자 : jeonyb4</li>
 * </ul>
 */
@Mapper
public interface OwkReportMapper {
	/**
	 * 
	 * listReportForCombo
	 * 
	 * @param reqBasePageDto
	 * @return List<ReportComboResultDto>
	 */
	public List<ReportComboResultDto> listReportForCombo(BasePageDto reqBasePageDto);
	
	/**
	 * 
	 * readReport
	 * 
	 * @param reqOwkReportDto
	 * @return OwkReportDto
	 */
	public OwkReportDto readReport(OwkReportDto reqOwkReportDto);

}
