package com.adtcaps.tsop.mapper.work;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;

import com.adtcaps.tsop.domain.work.OwkReportResultDto;
import com.adtcaps.tsop.portal.api.report.domain.ReportProcessingDto;
import com.adtcaps.tsop.portal.api.report.domain.ReportResultGridRequestDto;
import com.adtcaps.tsop.portal.api.report.domain.ReportResultGridResultDto;

/**
 * 
 * <ul>
 * <li>업무 그룹명 : tsop-backend-api</li>
 * <li>서브 업무명 : com.adtcaps.tsop.mapper.work</li>
 * <li>설  명 : OwkReportResultMapper.java</li>
 * <li>작성일 : 2021. 12. 6.</li>
 * <li>작성자 : jeonyb4</li>
 * </ul>
 */
@Mapper
public interface OwkReportResultMapper {
	/**
	 * 
	 * listPageReportResult
	 * 
	 * @param reportResultGridRequestDto
	 * @return List<ReportResultGridResultDto>
	 */
	public List<ReportResultGridResultDto> listPageReportResult(ReportResultGridRequestDto reportResultGridRequestDto);
	
	/**
	 * 
	 * createOwkReportResult
	 * 
	 * @param reqOwkReportResultDto
	 * @return int
	 */
	public int createOwkReportResult(OwkReportResultDto reqOwkReportResultDto);
	
	/**
	 * 
	 * readOwkReportResultAttachFile
	 * 
	 * @param reqOwkReportResultDto
	 * @return OwkReportResultDto
	 */
	public OwkReportResultDto readOwkReportResultAttachFile(OwkReportResultDto reqOwkReportResultDto);
	
	/**
	 * 
	 * readOwkReportResult
	 * 
	 * @param reqOwkReportResultDto
	 * @return ReportProcessingDto
	 */
	public ReportProcessingDto readOwkReportResult(OwkReportResultDto reqOwkReportResultDto);
	
	/**
	 * 
	 * updateOwkReportResult
	 * 
	 * @param reqOwkReportResultDto
	 * @return int
	 */
	public int updateOwkReportResult(OwkReportResultDto reqOwkReportResultDto);
	
	/**
	 * 
	 * deleteOwkReportResult
	 * 
	 * @param reqOwkReportResultDto
	 * @return int
	 */
	public int deleteOwkReportResult(OwkReportResultDto reqOwkReportResultDto);
	
	/**
	 * 
	 * readYesterdayIncomingTransferReport
	 * 
	 * @param reqOwkReportResultDto
	 * @return OwkReportResultDto
	 */
	public OwkReportResultDto readYesterdayIncomingTransferReport(OwkReportResultDto reqOwkReportResultDto);

}
