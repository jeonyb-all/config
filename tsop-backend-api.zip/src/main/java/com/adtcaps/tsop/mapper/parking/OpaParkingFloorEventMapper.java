package com.adtcaps.tsop.mapper.parking;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;

/**
 * 
 * <ul>
 * <li>업무 그룹명 : tsop-backend-api</li>
 * <li>서브 업무명 : com.adtcaps.tsop.mapper.parking</li>
 * <li>설  명 : OpaParkingFloorEventMapper.java</li>
 * <li>작성일 : 2020. 12. 4.</li>
 * <li>작성자 : jeonyb4</li>
 * </ul>
 */
@Mapper
public interface OpaParkingFloorEventMapper {
	
	/**
	 * 
	 * readMaxParkingFloor
	 *
	 * @return int
	 */
	public int readMaxParkingFloor();
	
	/**
	 * 
	 * listParkingFloor
	 *
	 * @return List<String>
	 */
	public List<String> listParkingFloor();
	
}
