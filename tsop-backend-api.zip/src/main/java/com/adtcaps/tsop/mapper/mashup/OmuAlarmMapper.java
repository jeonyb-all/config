package com.adtcaps.tsop.mapper.mashup;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.session.ResultHandler;

import com.adtcaps.tsop.dashboard.api.mashup.domain.AlarmCurrentStateDto;
import com.adtcaps.tsop.dashboard.api.mashup.domain.AlarmGradeAlarmCountDto;
import com.adtcaps.tsop.dashboard.api.mashup.domain.AlarmGradeServiceClassCountQueryResultDto;
import com.adtcaps.tsop.domain.mashup.OmuAlarmHistDto;
import com.adtcaps.tsop.domain.mashup.OmuFaultDto;
import com.adtcaps.tsop.domain.mashup.OmuFaultWorkDto;
import com.adtcaps.tsop.portal.api.alarm.domain.AlarmGridRequestDto;
import com.adtcaps.tsop.portal.api.alarm.domain.AlarmGridResultDto;
import com.adtcaps.tsop.portal.api.fault.domain.FaultDetailResultDto;
import com.adtcaps.tsop.portal.api.fault.domain.FaultWorkDetailResultDto;

/**
 * 
 * <ul>
 * <li>업무 그룹명 : tsop-backend-api</li>
 * <li>서브 업무명 : com.adtcaps.tsop.mapper.mashup</li>
 * <li>설  명 : OmuAlarmMapper.java</li>
 * <li>작성일 : 2020. 12. 4.</li>
 * <li>작성자 : jeonyb4</li>
 * </ul>
 */
@Mapper
public interface OmuAlarmMapper {
	
	/**
	 * 
	 * listPageAlarm
	 *
	 * @param alarmGridRequestDto
	 * @return List<AlarmGridResultDto>
	 */
	public List<AlarmGridResultDto> listPageAlarm(AlarmGridRequestDto alarmGridRequestDto);
	
	/**
	 * 
	 * listExcelAlarm
	 * 
	 * @param alarmGridRequestDto
	 * @param resultHandler
	 */
	public void listExcelAlarm(AlarmGridRequestDto alarmGridRequestDto, ResultHandler<AlarmGridResultDto> resultHandler);
	
	/**
	 * 
	 * readAlarmForFault
	 *
	 * @param reqOmuFaultDto
	 * @return FaultDetailResultDto
	 */
	public FaultDetailResultDto readAlarmForFault(OmuFaultDto reqOmuFaultDto);
	
	/**
	 * 
	 * readAlarmForFaultWork
	 * 
	 * @param reqOmuFaultWorkDto
	 * @return FaultWorkDetailResultDto
	 */
	public FaultWorkDetailResultDto readAlarmForFaultWork(OmuFaultWorkDto reqOmuFaultWorkDto);
	
	/**
	 * 
	 * readAlarmForFaultSmsMessage
	 *
	 * @param reqOmuFaultDto
	 * @return AlarmGridResultDto
	 */
	public AlarmGridResultDto readAlarmForFaultSmsMessage(OmuFaultDto reqOmuFaultDto);
	
	/**
	 * 
	 * updateAlarmExceptionUsedYn
	 * 
	 * @param reqOmuAlarmHistDto
	 * @return int
	 */
	public int updateAlarmExceptionUsedYn(OmuAlarmHistDto reqOmuAlarmHistDto);
	
	
	/***************************** Dashboard *****************************/
	
	/**
	 * 
	 * listAlarmGradeAlarmCount
	 *
	 * @param reqAlarmCurrentStateDto
	 * @return List<AlarmGradeAlarmCountDto>
	 */
	public List<AlarmGradeAlarmCountDto> listAlarmGradeAlarmCount(AlarmCurrentStateDto reqAlarmCurrentStateDto);
	
	/**
	 * 
	 * listAlarmGradeServiceClassAlarmCount
	 *
	 * @return List<AlarmGradeServiceClassCountQueryResultDto>
	 */
	public List<AlarmGradeServiceClassCountQueryResultDto> listAlarmGradeServiceClassAlarmCount(AlarmCurrentStateDto reqAlarmCurrentStateDto);
	
	/**
	 * 
	 * listAlarmCurrentSate
	 *
	 * @param reqAlarmCurrentStateDto
	 * @return List<AlarmCurrentStateDto>
	 */
	public List<AlarmCurrentStateDto> listAlarmCurrentSate(AlarmCurrentStateDto reqAlarmCurrentStateDto);
	
	/**
	 * 
	 * updateNoCheckAlarmToCheck
	 *
	 * @param reqAlarmCurrentStateDto
	 * @return int
	 */
	public int updateNoCheckAlarmToCheck(AlarmCurrentStateDto reqAlarmCurrentStateDto);
	
}
