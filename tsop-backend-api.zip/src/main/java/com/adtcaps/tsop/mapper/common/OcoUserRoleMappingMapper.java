package com.adtcaps.tsop.mapper.common;

import org.apache.ibatis.annotations.Mapper;

import com.adtcaps.tsop.domain.common.OcoUserHistDto;
import com.adtcaps.tsop.domain.common.OcoUserRoleMappingDto;

/**
 * 
 * <ul>
 * <li>업무 그룹명 : tsop-backend-api</li>
 * <li>서브 업무명 : com.adtcaps.tsop.mapper.common</li>
 * <li>설  명 : OcoUserRoleMappingMapper.java</li>
 * <li>작성일 : 2020. 12. 23.</li>
 * <li>작성자 : jeonyb4</li>
 * </ul>
 */
@Mapper
public interface OcoUserRoleMappingMapper {
	/**
	 * 
	 * createOcoUserRoleMapping
	 *
	 * @param reqOcoUserRoleMappingDto
	 * @return int
	 */
	public int createOcoUserRoleMapping(OcoUserRoleMappingDto reqOcoUserRoleMappingDto);
	
	/**
	 * 
	 * updateOcoUserRoleMapping
	 *
	 * @param reqOcoUserRoleMappingDto
	 * @return int
	 */
	public int updateOcoUserRoleMapping(OcoUserRoleMappingDto reqOcoUserRoleMappingDto);
	
	/**
	 * 
	 * readOcoUserRoleMappingCount
	 *
	 * @param reqOcoUserRoleMappingDto
	 * @return int
	 */
	public int readOcoUserRoleMappingCount(OcoUserRoleMappingDto reqOcoUserRoleMappingDto);
	
	/**
	 * 
	 * deleteOcoUserRoleMapping
	 * 
	 * @param reqOcoUserRoleMappingDto
	 * @return int
	 */
	public int deleteOcoUserRoleMapping(OcoUserRoleMappingDto reqOcoUserRoleMappingDto);
	
	/**
	 * 
	 * readUserRoleMappingForHist
	 * 
	 * @param reqOcoUserHistDto
	 * @return OcoUserRoleMappingDto
	 */
	public OcoUserRoleMappingDto readUserRoleMappingForHist(OcoUserHistDto reqOcoUserHistDto);
	
	
}
