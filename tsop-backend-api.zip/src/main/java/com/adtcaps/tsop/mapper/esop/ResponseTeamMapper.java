package com.adtcaps.tsop.mapper.esop;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;

import com.adtcaps.tsop.domain.esop.ResponseTeamDto;
import com.adtcaps.tsop.domain.esop.ResponseTeamHistDto;
import com.adtcaps.tsop.portal.api.esop.domain.ResponseTeamGridRequestDto;
import com.adtcaps.tsop.portal.api.esop.domain.ResponseTeamGridResultDto;
import com.adtcaps.tsop.portal.api.esop.domain.ResponseTeamHistGridRequestDto;
import com.adtcaps.tsop.portal.api.esop.domain.ResponseTeamHistGridResultDto;
import com.adtcaps.tsop.portal.api.statistics.domain.VocRecvHistoryDto;

@Mapper
public interface ResponseTeamMapper {
	/**
	 * listPageResponseTeam
	 * @param responseTeamGridRequestDto
	 * @return List<ResponseTeamGridResultDto>
	 */
	public List<ResponseTeamGridResultDto> listPageResponseTeam(ResponseTeamGridRequestDto responseTeamGridRequestDto);

	/**
	 * listResponseTeamAll
	 * @param bldId
	 * @return List<ResponseTeamDto>
	 */
	public List<ResponseTeamDto> listResponseTeamAll(String bldId);

	/**
	 * readResponseTeam
	 * @param responseTeamDto
	 * @return ResponseTeamDto
	 */
	public ResponseTeamDto readResponseTeam(ResponseTeamDto responseTeamDto);

	/**
	 * createResponseTeam
	 * @param responseTeamDto
	 * @return int
	 */
	public int createResponseTeam(ResponseTeamDto responseTeamDto);

	/**
	 * updateResponseTeam
	 * @param responseTeamDto
	 * @return int
	 */
	public int updateResponseTeam(ResponseTeamDto responseTeamDto);

	/**
	 * deleteResponseTeam
	 * @param responseTeamDto
	 * @return int
	 */
	public int deleteResponseTeam(ResponseTeamDto responseTeamDto);

	/**
	 * createResponseTeamHist
	 * @param responseTeamHistDto
	 * @return int
	 */
	public int createResponseTeamHist(ResponseTeamHistDto responseTeamHistDto);

	/**
	 * listPageResponseTeamHist
	 * @param responseTeamHistGridRequestDto
	 * @return List<ResponseTeamHistGridResultDto>
	 */
	public List<ResponseTeamHistGridResultDto> listPageResponseTeamHist(ResponseTeamHistGridRequestDto responseTeamHistGridRequestDto);

	/**
	 * listPageResponseTeamHistExcel
	 * @param responseTeamHistGridRequestDto
	 * @return List<ResponseTeamHistGridResultDto>
	 */
	public List<ResponseTeamHistGridRequestDto> listPageResponseTeamHistExcel(ResponseTeamGridRequestDto responseTeamGridRequestDto);
}
