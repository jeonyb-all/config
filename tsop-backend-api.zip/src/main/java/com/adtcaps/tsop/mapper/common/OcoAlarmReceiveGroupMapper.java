package com.adtcaps.tsop.mapper.common;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;

import com.adtcaps.tsop.domain.common.OcoAlarmReceiveGroupDto;
import com.adtcaps.tsop.portal.api.alarm.domain.AlarmReceiveGroupDetailResultDto;
import com.adtcaps.tsop.portal.api.alarm.domain.AlarmReceiveGroupGridRequestDto;
import com.adtcaps.tsop.portal.api.alarm.domain.AlarmReceiveGroupGridResultDto;
import com.adtcaps.tsop.portal.api.alarm.domain.BuildingAlarmReceiveGroupForComboResultDto;

/**
 * 
 * <ul>
 * <li>업무 그룹명 : tsop-backend-api</li>
 * <li>서브 업무명 : com.adtcaps.tsop.mapper.common</li>
 * <li>설  명 : OcoAlarmReceiveGroupMapper.java</li>
 * <li>작성일 : 2020. 12. 14.</li>
 * <li>작성자 : jeonyb4</li>
 * </ul>
 */
@Mapper
public interface OcoAlarmReceiveGroupMapper {
	/**
	 * 
	 * listBuildingAlarmReceiveGroupForCombo
	 *
	 * @param reqOcoAlarmReceiveGroupDto
	 * @return List<BuildingAlarmReceiveGroupForComboResultDto>
	 */
	public List<BuildingAlarmReceiveGroupForComboResultDto> listBuildingAlarmReceiveGroupForCombo(OcoAlarmReceiveGroupDto reqOcoAlarmReceiveGroupDto);
	
	/**
	 * 
	 * listPageAlarmReceiveGroup
	 *
	 * @param alarmNoticeConditionGridRequestDto
	 * @return List<AlarmReceiveGroupGridResultDto>
	 */
	public List<AlarmReceiveGroupGridResultDto> listPageAlarmReceiveGroup(AlarmReceiveGroupGridRequestDto alarmNoticeConditionGridRequestDto);
	
	/**
	 * 
	 * createOcoAlarmReceiveGroup
	 *
	 * @param reqOcoAlarmReceiveGroupDto
	 * @return int
	 */
	public int createOcoAlarmReceiveGroup(OcoAlarmReceiveGroupDto reqOcoAlarmReceiveGroupDto);
	
	/**
	 * 
	 * readAlarmReceiveGroup
	 *
	 * @param reqOcoAlarmReceiveGroupDto
	 * @return AlarmReceiveGroupDetailResultDto
	 */
	public AlarmReceiveGroupDetailResultDto readAlarmReceiveGroup(OcoAlarmReceiveGroupDto reqOcoAlarmReceiveGroupDto);
	
	/**
	 * 
	 * updateOcoAlarmReceiveGroup
	 *
	 * @param reqOcoAlarmReceiveGroupDto
	 * @return int
	 */
	public int updateOcoAlarmReceiveGroup(OcoAlarmReceiveGroupDto reqOcoAlarmReceiveGroupDto);
	
	/**
	 * 
	 * deleteOcoAlarmReceiveGroup
	 *
	 * @param reqOcoAlarmReceiveGroupDto
	 * @return int
	 */
	public int deleteOcoAlarmReceiveGroup(OcoAlarmReceiveGroupDto reqOcoAlarmReceiveGroupDto);
	
	/**
	 * 
	 * updateAlarmReceiveGroupReuse
	 *
	 * @param reqOcoAlarmReceiveGroupDto
	 * @return int
	 */
	public int updateAlarmReceiveGroupReuse(OcoAlarmReceiveGroupDto reqOcoAlarmReceiveGroupDto);
	
	
	/***************************** Dashboard *****************************/
	
	
	
	/**
	 * 
	 * getAlarmReceiveGroupCount
	 * 
	 * @param reqOcoAlarmReceiveGroupDto
	 * @return int
	 */
	public int getAlarmReceiveGroupCount(OcoAlarmReceiveGroupDto reqOcoAlarmReceiveGroupDto);
	
	/***************************** Portal *****************************/

}
