package com.adtcaps.tsop.mapper.common;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;

import com.adtcaps.tsop.domain.common.OcoUserDto;
import com.adtcaps.tsop.domain.common.OcoUserHistDto;
import com.adtcaps.tsop.helper.domain.BasePageDto;
import com.adtcaps.tsop.portal.api.user.domain.UserDetailResultDto;
import com.adtcaps.tsop.portal.api.user.domain.UserForShortGridResultDto;
import com.adtcaps.tsop.portal.api.user.domain.UserGridRequestDto;
import com.adtcaps.tsop.portal.api.user.domain.UserGridResultDto;

/**
 * 
 * <ul>
 * <li>업무 그룹명 : tsop-backend-api</li>
 * <li>서브 업무명 : com.adtcaps.tsop.mapper.common</li>
 * <li>설  명 : OcoUserMapper.java</li>
 * <li>작성일 : 2020. 12. 21.</li>
 * <li>작성자 : jeonyb4</li>
 * </ul>
 */
@Mapper
public interface OcoUserMapper {
	/**
	 * 
	 * listUserForShortGrid
	 *
	 * @param reqBasePageDto
	 * @return List<UserForShortGridResultDto>
	 */
	public List<UserForShortGridResultDto> listUserForShortGrid(BasePageDto reqBasePageDto);
	
	/**
	 * 
	 * listBuildingUserForShortGrid
	 *
	 * @param reqBasePageDto
	 * @return List<UserForShortGridResultDto>
	 */
	public List<UserForShortGridResultDto> listBuildingUserForShortGrid(BasePageDto reqBasePageDto);
	
	/**
	 * 
	 * listPageUser
	 *
	 * @param userGridRequestDto
	 * @return List<UserGridResultDto>
	 */
	public List<UserGridResultDto> listPageUser(UserGridRequestDto userGridRequestDto);
	
	/**
	 * 
	 * createOcoUser
	 *
	 * @param reqOcoUserDto
	 * @return int
	 */
	public int createOcoUser(OcoUserDto reqOcoUserDto);
	
	/**
	 * 
	 * readUserDuplicationCheck
	 *
	 * @param reqOcoUserDto
	 * @return int
	 */
	public int readUserDuplicationCheck(OcoUserDto reqOcoUserDto);
	
	/**
	 * 
	 * readUserPasswordEqualCheck
	 *
	 * @param reqOcoUserDto
	 * @return int
	 */
	public int readUserPasswordEqualCheck(OcoUserDto reqOcoUserDto);
	
	/**
	 * 
	 * updateUserPassword
	 *
	 * @param reqOcoUserDto
	 * @return int
	 */
	public int updateUserPassword(OcoUserDto reqOcoUserDto);
	
	/**
	 * 
	 * readOcoUser
	 *
	 * @param reqOcoUserDto
	 * @return UserDetailResultDto
	 */
	public UserDetailResultDto readOcoUser(OcoUserDto reqOcoUserDto);
	
	/**
	 * 
	 * updateOcoUser
	 *
	 * @param reqOcoUserDto
	 * @return int
	 */
	public int updateOcoUser(OcoUserDto reqOcoUserDto);
	
	/**
	 * 
	 * updateOcoUserByEmployee
	 * 
	 * @param reqOcoUserDto
	 * @return int
	 */
	public int updateOcoUserByEmployee(OcoUserDto reqOcoUserDto);
	
	/**
	 * 
	 * deleteOcoUser
	 *
	 * @param reqOcoUserDto
	 * @return int
	 */
	public int deleteOcoUser(OcoUserDto reqOcoUserDto);
	
	/**
	 * 
	 * readOcoUserForHist
	 * 
	 * @param reqOcoUserDto
	 * @return OcoUserDto
	 */
	public OcoUserDto readOcoUserForHist(OcoUserHistDto reqOcoUserHistDto);
	
}
