package com.adtcaps.tsop.mapper.mashup;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;

import com.adtcaps.tsop.domain.mashup.OmuFaultWorkDto;
import com.adtcaps.tsop.portal.api.fault.domain.FaultWorkDetailResultDto;
import com.adtcaps.tsop.portal.api.fault.domain.FaultWorkGridRequestDto;
import com.adtcaps.tsop.portal.api.fault.domain.FaultWorkGridResultDto;

/**
 * 
 * <ul>
 * <li>업무 그룹명 : tsop-backend-api</li>
 * <li>서브 업무명 : com.adtcaps.tsop.mapper.mashup</li>
 * <li>설  명 : OmuFaultWorkMapper.java</li>
 * <li>작성일 : 2021. 12. 29.</li>
 * <li>작성자 : jeonyb4</li>
 * </ul>
 */
@Mapper
public interface OmuFaultWorkMapper {
	/**
	 * 
	 * listPageFaultWork
	 *
	 * @param faultGridRequestDto
	 * @return List<FaultWorkGridResultDto>
	 */
	public List<FaultWorkGridResultDto> listPageFaultWork(FaultWorkGridRequestDto faultGridRequestDto);
	
	/**
	 * 
	 * createOmuFaultWork
	 *
	 * @param reqOmuFaultWorkDto
	 * @return int
	 */
	public int createOmuFaultWork(OmuFaultWorkDto reqOmuFaultWorkDto);
	
	/**
	 * 
	 * readOmuFaultWork
	 *
	 * @param reqOmuFaultWorkDto
	 * @return FaultWorkDetailResultDto
	 */
	public FaultWorkDetailResultDto readOmuFaultWork(OmuFaultWorkDto reqOmuFaultWorkDto);
	
	/**
	 * 
	 * updateOmuFaultWork
	 *
	 * @param reqOmuFaultWorkDto
	 * @return int
	 */
	public int updateOmuFaultWork(OmuFaultWorkDto reqOmuFaultWorkDto);
	
	/**
	 * 
	 * readOmuFaultWorkDuplicationCheck
	 *
	 * @param reqOmuFaultWorkDto
	 * @return FaultWorkDetailResultDto
	 */
	public FaultWorkDetailResultDto readOmuFaultWorkDuplicationCheck(OmuFaultWorkDto reqOmuFaultWorkDto);
	
	/**
	 * 
	 * readFaultWorkCountForAlarm
	 *
	 * @param reqOmuFaultWorkDto
	 * @return int
	 */
	public int readFaultWorkCountForAlarm(OmuFaultWorkDto reqOmuFaultWorkDto);
	
	/**
	 * 
	 * deleteOmuFaultWork
	 * 
	 * @param reqOmuFaultWorkDto
	 * @return int
	 */
	public int deleteOmuFaultWork(OmuFaultWorkDto reqOmuFaultWorkDto);
	
	/***************************** Dashboard *****************************/
	

}
