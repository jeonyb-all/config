package com.adtcaps.tsop.mapper.work;

import java.util.List;
import java.util.Map;

import org.apache.ibatis.annotations.Mapper;

import com.adtcaps.tsop.domain.staffMgmt.OwkTeamDto;
import com.adtcaps.tsop.portal.api.staffMgmt.domain.EmployeeMgmtGridDto;
import com.adtcaps.tsop.portal.api.staffMgmt.domain.TeamMgmtDto;
import com.adtcaps.tsop.portal.api.staffMgmt.domain.TeamMgmtGridDto;
import com.adtcaps.tsop.portal.api.staffMgmt.domain.TeamMgmtReqDto;

/**
 * 
 * <ul>
 * <li>업무 그룹명 : tsop-backend-api</li>
 * <li>서브 업무명 : com.adtcaps.tsop.mapper.work</li>
 * <li>설  명 : OwkTeamMgmtMapper.java</li>
 * <li>작성일 : 2021. 12. 3.</li>
 * <li>작성자 : ricky</li>
 * </ul>
 */
@Mapper
public interface OwkTeamMgmtMapper {
	/**
	 * 
	 * listPageEmployee 
	 *
	 * @param EmployeeDto
	 * @return List<EmployeeDto>
	 */
	public List<EmployeeMgmtGridDto> listPageEmployeeMgmt(EmployeeMgmtGridDto employeeMgmtGridDto);
	
	
	/**
	 * listPageTeamMgmt
	 * @param teamMgmtGridDto
	 * @return List<TeamMgmtGridDto>
	 */
	public List<TeamMgmtGridDto> listPageTeamMgmt(TeamMgmtGridDto teamMgmtGridDto);
	
	/**
	 * listTeamMgmt
	 * @param teamMgmtGridDto
	 * @return List<TeamMgmtGridDto>
	 */
	public List<TeamMgmtDto> listTeamMgmt(TeamMgmtDto teamMgmtDto);
	
	/**
	 * listTeam
	 * @param OwkTeamDto
	 * @return List<OwkTeamDto>
	 */
	public List<OwkTeamDto> listTeam(OwkTeamDto owkTeamDto);
	
	/**
	 * createTeam
	 * @param TeamMgmtReqDto
	 * @return List<OwkTeamDto>
	 */
	public int createTeam(TeamMgmtReqDto teamMgmtReqDto);
	
	/**
	 * updateTeam
	 * @param TeamMgmtReqDto
	 * @return List<OwkTeamDto>
	 */
	public int updateTeam(TeamMgmtReqDto teamMgmtReqDto);
	
	/**
	 * countTeamName
	 * @param owkTeamDto
	 * @return
	 */
	public int countTeamName(TeamMgmtReqDto teamMgmtReqDto);


	/**
	 * listTeamMgmtDepth
	 * @param teamMgmtDto
	 * @return
	 */
	public List<TeamMgmtDto> listTeamMgmtDepth(TeamMgmtDto teamMgmtDto);


	/**
	 * deleteTeam
	 * @param teamMgmtDto
	 * @return
	 */
	public int deleteTeam(TeamMgmtDto teamMgmtDto);


	/**
	 * countEmployeeInTeam
	 * @param param
	 * @return
	 */
	public int countEmployeeInTeam(Map<String, Object> param);

	/**
	 * 
	 * @param teamMgmtDto
	 * @return
	 */
	public List<TeamMgmtDto> listTeamMgmtRelated(TeamMgmtDto teamMgmtDto);
}
