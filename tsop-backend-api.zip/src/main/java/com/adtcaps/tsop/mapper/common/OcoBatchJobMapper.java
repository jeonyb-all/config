package com.adtcaps.tsop.mapper.common;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;

import com.adtcaps.tsop.domain.common.OcoBatchJobDto;
import com.adtcaps.tsop.portal.api.batch.domain.BatchJobDetailResultDto;
import com.adtcaps.tsop.portal.api.batch.domain.BatchJobGridRequestDto;
import com.adtcaps.tsop.portal.api.batch.domain.BatchJobGridResultDto;

/**
 * 
 * <ul>
 * <li>업무 그룹명 : tsop-backend-api</li>
 * <li>서브 업무명 : com.adtcaps.tsop.mapper.common</li>
 * <li>설  명 : OcoBatchJobMapper.java</li>
 * <li>작성일 : 2020. 12. 28.</li>
 * <li>작성자 : jeonyb4</li>
 * </ul>
 */
@Mapper
public interface OcoBatchJobMapper {
	/**
	 * 
	 * listPageBatchJob
	 *
	 * @param batchJobGridRequestDto
	 * @return List<BatchJobGridResultDto>
	 */
	public List<BatchJobGridResultDto> listPageBatchJob(BatchJobGridRequestDto batchJobGridRequestDto);
	
	/**
	 * 
	 * createOcoBatchJob
	 *
	 * @param reqBatchJobDetailResultDto
	 * @return int
	 */
	public int createOcoBatchJob(BatchJobDetailResultDto reqBatchJobDetailResultDto);
	
	/**
	 * 
	 * readOcoBatchJob
	 *
	 * @param reqOcoBatchJobDto
	 * @return BatchJobDetailResultDto
	 */
	public BatchJobDetailResultDto readOcoBatchJob(OcoBatchJobDto reqOcoBatchJobDto);
	
	/**
	 * 
	 * updateOcoBatchJob
	 *
	 * @param reqBatchJobDetailResultDto
	 * @return int
	 */
	public int updateOcoBatchJob(BatchJobDetailResultDto reqBatchJobDetailResultDto);
	
	/**
	 * 
	 * deleteOcoBatchJob
	 *
	 * @param reqOcoBatchJobDto
	 * @return int
	 */
	public int deleteOcoBatchJob(OcoBatchJobDto reqOcoBatchJobDto);
	
	/**
	 * 
	 * updateBatchJobReuse
	 *
	 * @param reqOcoBatchJobDto
	 * @return int
	 */
	public int updateBatchJobReuse(OcoBatchJobDto reqOcoBatchJobDto);

}
