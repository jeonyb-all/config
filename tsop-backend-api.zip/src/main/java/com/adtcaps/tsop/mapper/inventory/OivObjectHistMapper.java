package com.adtcaps.tsop.mapper.inventory;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;

import com.adtcaps.tsop.domain.inventory.OivObjectHistDto;
import com.adtcaps.tsop.portal.api.object.domain.ObjectHistDetailResultDto;
import com.adtcaps.tsop.portal.api.object.domain.ObjectHistGridRequestDto;
import com.adtcaps.tsop.portal.api.object.domain.ObjectHistGridResultDto;

/**
 * 
 * <ul>
 * <li>업무 그룹명 : tsop-backend-api</li>
 * <li>서브 업무명 : com.adtcaps.tsop.mapper.inventory</li>
 * <li>설  명 : OivObjectHistMapper.java</li>
 * <li>작성일 : 2021. 1. 19.</li>
 * <li>작성자 : jeonyb4</li>
 * </ul>
 */
@Mapper
public interface OivObjectHistMapper {
	/**
	 * 
	 * listPageObjectHist
	 *
	 * @param objectHistGridRequestDto
	 * @return List<ObjectHistGridResultDto>
	 */
	public List<ObjectHistGridResultDto> listPageObjectHist(ObjectHistGridRequestDto objectHistGridRequestDto);
	
	/**
	 * 
	 * readOivObjectHist
	 *
	 * @param reqOivObjectHistDto
	 * @return ObjectHistDetailResultDto
	 */
	public ObjectHistDetailResultDto readOivObjectHist(OivObjectHistDto reqOivObjectHistDto);

}
