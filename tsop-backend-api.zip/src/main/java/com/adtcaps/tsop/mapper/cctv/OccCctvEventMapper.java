package com.adtcaps.tsop.mapper.cctv;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;

import com.adtcaps.tsop.portal.api.search.domain.CctvCongestionGridResultDto;
import com.adtcaps.tsop.portal.api.search.domain.CctvEquipStatusAlarmResultDto;
import com.adtcaps.tsop.portal.api.search.domain.CctvSearchRequestDto;
import com.adtcaps.tsop.portal.api.search.domain.CctvTimeBarEventResultDto;
import com.adtcaps.tsop.portal.api.search.domain.CctvTimeBarResultDto;


/**
 * 
 * <ul>
 * <li>업무 그룹명 : tsop-backend-api</li>
 * <li>서브 업무명 : com.adtcaps.tsop.mapper.cctv</li>
 * <li>설  명 : OccCctvEventMapper.java</li>
 * <li>작성일 : 2021. 1. 17.</li>
 * <li>작성자 : song</li>
 * </ul>
 */

@Mapper
public interface OccCctvEventMapper {
	public List<CctvEquipStatusAlarmResultDto> listEquipStatusAlarmSearch(CctvSearchRequestDto reqCctvSearch);
	public List<CctvTimeBarResultDto> listCctvTimebarSearch(CctvSearchRequestDto reqCctvSearch);
	public List<CctvTimeBarEventResultDto> listCctvTimebarEventSearch(CctvSearchRequestDto reqCctvSearch);
	public List<CctvCongestionGridResultDto> listCongestionGridSearch(CctvSearchRequestDto reqCctvSearch);
}
