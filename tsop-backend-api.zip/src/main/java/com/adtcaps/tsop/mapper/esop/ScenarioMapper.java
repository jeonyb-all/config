package com.adtcaps.tsop.mapper.esop;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;

import com.adtcaps.tsop.domain.esop.EsopMemoDto;
import com.adtcaps.tsop.domain.esop.EsopProcessDto;
import com.adtcaps.tsop.domain.esop.EsopScenarioDto;
import com.adtcaps.tsop.domain.esop.FireGradeDto;
import com.adtcaps.tsop.portal.api.esop.domain.EsopScenarioGridRequestDto;
import com.adtcaps.tsop.portal.api.esop.domain.EsopScenarioGridResultDto;

/**
 * <ul>
 * <li>업무 그룹명 : tsop-backend-api</li>
 * <li>서브 업무명 : com.adtcaps.tsop.mapper.esop</li>
 * <li>설  명 : ScenarioMapper.java</li>
 * <li>작성일 : 2021. 12. 7.</li>
 * <li>작성자 : vader</li>
 * </ul>
 */
@Mapper
public interface ScenarioMapper {
	/**
	 * listPageEsopScenario
	 * @param esopScenarioGridRequestDto
	 * @return List<EsopScenarioGridResultDto>
	 */
	public List<EsopScenarioGridResultDto> listPageEsopScenario(EsopScenarioGridRequestDto esopScenarioGridRequestDto);

	/**
	 * readEsopMemo
	 * @param esopMemoDto
	 * @return EsopMemoDto
	 */
	public EsopMemoDto readEsopMemo(EsopMemoDto esopMemoDto);

	/**
	 * updateEsopMemo
	 * @param esopMemoDto
	 * @return int
	 */
	public int updateEsopMemo(EsopMemoDto esopMemoDto);

	/**
	 * readProcessStep
	 * @param esopProcessDto
	 * @return EsopProcessDto
	 */
	public EsopProcessDto readProcessStep(EsopProcessDto esopProcessDto);

	/**
	 * updateProcessStep
	 * @param esopProcessDto
	 * @return int
	 */
	public int updateProcessStep(EsopProcessDto esopProcessDto);

	/**
	 * listEsopScenario
	 * @param esopScenarioDto
	 * @return List<EsopScenarioDto>
	 */
	public List<EsopScenarioDto> listEsopScenario(String bldId);

	/**
	 * readEsopScenario
	 * @param esopScenarioDto
	 * @return EsopScenarioDto
	 */
	public EsopScenarioDto readEsopScenario(EsopScenarioDto esopScenarioDto);

	/**
	 * listFireGrade
	 * @param bldId
	 * @return List<FireGradeDto>
	 */
	public List<FireGradeDto> listFireGrade(String bldId);

	/**
	 * updateFireGrede
	 * @param fireGradeDto
	 * @return int
	 */
	public int updateFireGrade(FireGradeDto fireGradeDto);

	/**
	 * updateEsopScenario
	 * @param esopScenarioDto
	 * @return int
	 */
	public int updateEsopScenario(EsopScenarioDto esopScenarioDto);
}
