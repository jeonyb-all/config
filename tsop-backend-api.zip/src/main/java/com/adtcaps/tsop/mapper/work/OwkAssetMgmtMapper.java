package com.adtcaps.tsop.mapper.work;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;

import com.adtcaps.tsop.domain.assetMgmt.OwkAssetDto;
import com.adtcaps.tsop.domain.assetMgmt.OwkAssetFeatureDto;
import com.adtcaps.tsop.domain.common.OcoCommonCodeDetailDto;
import com.adtcaps.tsop.domain.staffMgmt.OwkEmployeeDto;
import com.adtcaps.tsop.portal.api.assetMgmt.domain.AssetMgmtGridDto;
import com.adtcaps.tsop.portal.api.code.domain.CommonCodeDetailRequestDto;

/**
 * 
 * <ul>
 * <li>업무 그룹명 : tsop-backend-api</li>
 * <li>서브 업무명 : com.adtcaps.tsop.mapper.asset</li>
 * <li>설  명 : OwkAssetMgmtMapper.java</li>
 * <li>작성일 : 2021. 12. 7.</li>
 * <li>작성자 : ricky</li>
 * </ul>
 */
@Mapper
public interface OwkAssetMgmtMapper {

	int countEmpIdInAssetManager(OwkEmployeeDto owkEmployeeDto);

	List<AssetMgmtGridDto> listPageAsset(AssetMgmtGridDto asetMgmtGridDto);

	int createAsset(AssetMgmtGridDto assetMgmtGridDto);

	int countAssetId(AssetMgmtGridDto assetMgmtGridDto);

	List<AssetMgmtGridDto> detailAsset(AssetMgmtGridDto asetMgmtGridDto);

	int updateAsset(AssetMgmtGridDto assetMgmtGridDto);

	List<OwkAssetFeatureDto> listAssetFeature(AssetMgmtGridDto asetMgmtGridDto);

	int createAssetFeature(OwkAssetFeatureDto owkAssetFeatureDto);

	int deleteAssetFeatures(AssetMgmtGridDto assetMgmtGridDto);

	List<AssetMgmtGridDto> listAsset(AssetMgmtGridDto asetMgmtGridDto);

	List<OcoCommonCodeDetailDto> assetCagetoryList(CommonCodeDetailRequestDto commonCodeDetailRequestDto);

	int deleteAsset(AssetMgmtGridDto assetMgmtGridDto);

	int updateAssetManageYn(AssetMgmtGridDto assetMgmtGridDto);

	int countWorkOrderInAsset(AssetMgmtGridDto asetMgmtGridDto);

	String createAssetIdNew();

	List<AssetMgmtGridDto> listAssetSimple(AssetMgmtGridDto assetMgmtGridDto);
}
