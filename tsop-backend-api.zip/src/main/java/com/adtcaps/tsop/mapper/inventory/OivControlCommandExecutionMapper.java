package com.adtcaps.tsop.mapper.inventory;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;

import com.adtcaps.tsop.domain.inventory.OivControlCommandExecutionDto;
import com.adtcaps.tsop.portal.api.control.domain.ControlCommandExecutionDetailResultDto;
import com.adtcaps.tsop.portal.api.control.domain.ControlCommandExecutionGridRequestDto;
import com.adtcaps.tsop.portal.api.control.domain.ControlCommandExecutionGridResultDto;

/**
 * 
 * <ul>
 * <li>업무 그룹명 : tsop-backend-api</li>
 * <li>서브 업무명 : com.adtcaps.tsop.mapper.inventory</li>
 * <li>설  명 : OivControlCommandExecutionMapper.java</li>
 * <li>작성일 : 2021. 1. 15.</li>
 * <li>작성자 : jeonyb4</li>
 * </ul>
 */
@Mapper
public interface OivControlCommandExecutionMapper {
	/**
	 * 
	 * createOivControlCommandExecution
	 *
	 * @param reqOivControlCommandExecutionDto
	 * @return int
	 */
	public int createOivControlCommandExecution(OivControlCommandExecutionDto reqOivControlCommandExecutionDto);
	
	/**
	 * 
	 * listPageControlCommandExecution
	 *
	 * @param controlCommandExecutionGridRequestDto
	 * @return List<ControlCommandExecutionGridResultDto>
	 */
	public List<ControlCommandExecutionGridResultDto> listPageControlCommandExecution(ControlCommandExecutionGridRequestDto controlCommandExecutionGridRequestDto);
	
	/**
	 * 
	 * readOivControlCommandExecution
	 *
	 * @param reqOivControlCommandExecutionDto
	 * @return ControlCommandExecutionDetailResultDto
	 */
	public ControlCommandExecutionDetailResultDto readOivControlCommandExecution(OivControlCommandExecutionDto reqOivControlCommandExecutionDto);

}
