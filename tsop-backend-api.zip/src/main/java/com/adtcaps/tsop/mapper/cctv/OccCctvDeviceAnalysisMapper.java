package com.adtcaps.tsop.mapper.cctv;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;

import com.adtcaps.tsop.portal.api.search.domain.CctvCongestionResultDto;
import com.adtcaps.tsop.portal.api.search.domain.CctvSearchRequestDto;

/**
 * 
 * <ul>
 * <li>업무 그룹명 : tsop-backend-api</li>
 * <li>서브 업무명 : com.adtcaps.tsop.mapper.cctv</li>
 * <li>설  명 : OccCctvDeviceAnalysisMapper.java</li>
 * <li>작성일 : 2021. 1. 17.</li>
 * <li>작성자 : song</li>
 * </ul>
 */

@Mapper
public interface OccCctvDeviceAnalysisMapper {
	public List<CctvCongestionResultDto> listCongestionSearch(CctvSearchRequestDto reqCctvSearch);
}
