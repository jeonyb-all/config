package com.adtcaps.tsop.mapper.common;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;

import com.adtcaps.tsop.domain.common.OcoAlarmReceiveGroupDetailDto;
import com.adtcaps.tsop.domain.common.OcoAlarmReceiveGroupDto;
import com.adtcaps.tsop.portal.api.alarm.domain.AlarmReceiveGroupDetailDetailResultDto;

/**
 * 
 * <ul>
 * <li>업무 그룹명 : tsop-backend-api</li>
 * <li>서브 업무명 : com.adtcaps.tsop.mapper.common</li>
 * <li>설  명 : OcoAlarmReceiveGroupDetailMapper.java</li>
 * <li>작성일 : 2020. 12. 21.</li>
 * <li>작성자 : jeonyb4</li>
 * </ul>
 */
@Mapper
public interface OcoAlarmReceiveGroupDetailMapper {
	/**
	 * 
	 * createOcoAlarmReceiveGroupDetail
	 *
	 * @param reqOcoAlarmReceiveGroupDetailDto
	 * @return int
	 */
	public int createOcoAlarmReceiveGroupDetail(OcoAlarmReceiveGroupDetailDto reqOcoAlarmReceiveGroupDetailDto);
	
	/**
	 * 
	 * listAlarmReceiveGroupDetail
	 *
	 * @param reqOcoAlarmReceiveGroupDetailDto
	 * @return List<AlarmReceiveGroupDetailDetailResultDto>
	 */
	public List<AlarmReceiveGroupDetailDetailResultDto> listAlarmReceiveGroupDetail(OcoAlarmReceiveGroupDetailDto reqOcoAlarmReceiveGroupDetailDto);
	
	/**
	 * 
	 * deleteAlarmReceiveGroupDetail
	 *
	 * @param reqOcoAlarmReceiveGroupDetailDto
	 * @return int
	 */
	public int deleteAlarmReceiveGroupDetail(OcoAlarmReceiveGroupDetailDto reqOcoAlarmReceiveGroupDetailDto);
	
	
	/**
	 * 
	 * deleteAlarmReceiveGroupDetailByUser
	 * 
	 * @param reqOcoAlarmReceiveGroupDetailDto
	 * @return int
	 */
	public int deleteAlarmReceiveGroupDetailByUser(OcoAlarmReceiveGroupDetailDto reqOcoAlarmReceiveGroupDetailDto);
	
	/**
	 * 
	 * listEmptyAlarmReceiveGroup
	 * 
	 * @param reqOcoAlarmReceiveGroupDetailDto
	 * @return List<OcoAlarmReceiveGroupDto>
	 */
	public List<OcoAlarmReceiveGroupDto> listEmptyAlarmReceiveGroup(OcoAlarmReceiveGroupDetailDto reqOcoAlarmReceiveGroupDetailDto);
	
}
