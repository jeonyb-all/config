package com.adtcaps.tsop.mapper.parking;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;

import com.adtcaps.tsop.domain.parking.OpaParkingFloorDto;
import com.adtcaps.tsop.portal.api.object.domain.ParkingFloorAndZoneResultDto;

/**
 * 
 * <ul>
 * <li>업무 그룹명 : tsop-backend-api</li>
 * <li>서브 업무명 : com.adtcaps.tsop.mapper.parking</li>
 * <li>설  명 : OpaParkingFloorMapper.java</li>
 * <li>작성일 : 2021. 1. 12.</li>
 * <li>작성자 : jeonyb4</li>
 * </ul>
 */
@Mapper
public interface OpaParkingFloorMapper {
	/**
	 * 
	 * listParkingFloorAndZone
	 *
	 * @param reqOpaParkingFloorDto
	 * @return List<ParkingFloorAndZoneResultDto>
	 */
	public List<ParkingFloorAndZoneResultDto> listParkingFloorAndZone(OpaParkingFloorDto reqOpaParkingFloorDto);
	
	
	/***************************** Dashboard *****************************/

}
