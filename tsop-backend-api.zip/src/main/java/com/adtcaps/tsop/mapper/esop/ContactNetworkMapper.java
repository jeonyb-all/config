package com.adtcaps.tsop.mapper.esop;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;

import com.adtcaps.tsop.domain.esop.ContactNetworkDto;
import com.adtcaps.tsop.domain.esop.ContactNetworkHistDto;
import com.adtcaps.tsop.portal.api.esop.domain.ContactNetworkGridRequestDto;
import com.adtcaps.tsop.portal.api.esop.domain.ContactNetworkGridResultDto;
import com.adtcaps.tsop.portal.api.esop.domain.ContactNetworkHistGridRequestDto;
import com.adtcaps.tsop.portal.api.esop.domain.ContactNetworkHistGridResultDto;

@Mapper
public interface ContactNetworkMapper {
	/**
	 * listPageContactNetwork
	 * @param contactNetworkGridRequestDto
	 * @return List<ContactNetworkGridResultDto>
	 */
	public List<ContactNetworkGridResultDto> listPageContactNetwork(ContactNetworkGridRequestDto contactNetworkGridRequestDto);

	/**
	 * readContactNetwork
	 * @param contactNetworkDto
	 * @return ContactNetworkDto
	 */
	public ContactNetworkDto readContactNetwork(ContactNetworkDto contactNetworkDto);

	/**
	 * createContactNetwork
	 * @param contactNetworkDto
	 * @return int
	 */
	public int createContactNetwork(ContactNetworkDto contactNetworkDto);

	/**
	 * updateContactNetwork
	 * @param contactNetworkDto
	 * @return int
	 */
	public int updateContactNetwork(ContactNetworkDto contactNetworkDto);

	/**
	 * listContactNetwork
	 * @param contactNetworkDto
	 * @return List<ContactNetworkDto>
	 */
	public List<ContactNetworkDto> listContactNetwork(ContactNetworkDto contactNetworkDto);

	/**
	 * deleteContactNetwork
	 * @param contactNetworkDto
	 * @return int
	 */
	public int deleteContactNetwork(ContactNetworkDto contactNetworkDto);

	/**
	 * createContactNetworkHist
	 * @param contactNetworkHistDto
	 * @return int
	 */
	public int createContactNetworkHist(ContactNetworkHistDto contactNetworkHistDto);

	/**
	 * listPageContactNetworkHist
	 * @param contactNetworkHistGridRequestDto
	 * @return List<ContactNetworkHistGridResultDto>
	 */
	public List<ContactNetworkHistGridResultDto> listPageContactNetworkHist(ContactNetworkHistGridRequestDto contactNetworkHistGridRequestDto);

	public List<ContactNetworkGridRequestDto> contentEsopContactExcels(ContactNetworkGridRequestDto contactNetworkGridRequestDto);
}
