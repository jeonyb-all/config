package com.adtcaps.tsop.mapper.fm;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;

import com.adtcaps.tsop.domain.fm.OfmFacilityObjectDto;
import com.adtcaps.tsop.domain.mashup.OmuAlarmcodeMappingDto;
import com.adtcaps.tsop.portal.api.alarm.domain.AlarmcodeMappingForShortGridResultDto;
import com.adtcaps.tsop.portal.api.alarm.domain.AlarmcodeMappingGridRequestDto;

/**
 * 
 * <ul>
 * <li>업무 그룹명 : tsop-backend-api</li>
 * <li>서브 업무명 : com.adtcaps.tsop.mapper.fm</li>
 * <li>설  명 : OfmFacilityObjectMapper.java</li>
 * <li>작성일 : 2021. 10. 21.</li>
 * <li>작성자 : jeonyb4</li>
 * </ul>
 */
@Mapper
public interface OfmFacilityObjectMapper {
	/**
	 * 
	 * listFmAlarmcodeMappingForShortGrid
	 * 
	 * @param alarmcodeMappingGridRequestDto
	 * @return List<AlarmcodeMappingForShortGridResultDto>
	 */
	public List<AlarmcodeMappingForShortGridResultDto> listFmAlarmcodeMappingForShortGrid(AlarmcodeMappingGridRequestDto alarmcodeMappingGridRequestDto);
	
	/**
	 * 
	 * readFmAlarmcodeInfoCheck
	 * 
	 * @param reqOmuAlarmcodeMappingDto
	 * @return OmuAlarmcodeMappingDto
	 */
	public OmuAlarmcodeMappingDto readFmAlarmcodeInfoCheck(OmuAlarmcodeMappingDto reqOmuAlarmcodeMappingDto);
	
	/***************************** Dashboard *****************************/
	
	/**
	 * 
	 * listFacilityObject
	 * 
	 * @param reqOfmFacilityObjectDto
	 * @return List<OfmFacilityObjectDto>
	 */
	public List<OfmFacilityObjectDto> listFacilityObject(OfmFacilityObjectDto reqOfmFacilityObjectDto);
	
}
