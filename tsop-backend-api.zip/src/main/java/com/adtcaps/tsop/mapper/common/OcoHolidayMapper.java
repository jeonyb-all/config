package com.adtcaps.tsop.mapper.common;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;

import com.adtcaps.tsop.dashboard.api.common.domain.GuideScheduleRequestDto;
import com.adtcaps.tsop.portal.api.calendar.domain.CalendarDto;

/**
 * 
 * <ul>
 * <li>업무 그룹명 : tsop-backend-api</li>
 * <li>서브 업무명 : com.adtcaps.tsop.mapper.common</li>
 * <li>설  명 : OcoHolidayMapper.java</li>
 * <li>작성일 : 2021. 12. 31.</li>
 * <li>작성자 : jeonyb4</li>
 * </ul>
 */
@Mapper
public interface OcoHolidayMapper {
	/**
	 * 
	 * listCalendar
	 * 
	 * @param guideScheduleRequestDto
	 * @return List<CalendarDto>
	 */
	public List<CalendarDto> listCalendar(GuideScheduleRequestDto guideScheduleRequestDto);

}
