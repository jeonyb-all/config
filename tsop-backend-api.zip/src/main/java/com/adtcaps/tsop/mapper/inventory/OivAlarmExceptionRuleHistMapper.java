package com.adtcaps.tsop.mapper.inventory;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;

import com.adtcaps.tsop.domain.inventory.OivAlarmExceptionRuleHistDto;
import com.adtcaps.tsop.portal.api.alarm.domain.AlarmExceptionRuleHistDetailDto;
import com.adtcaps.tsop.portal.api.alarm.domain.AlarmExceptionRuleHistGridRequestDto;
import com.adtcaps.tsop.portal.api.alarm.domain.AlarmExceptionRuleHistGridResultDto;

/**
 * 
 * <ul>
 * <li>업무 그룹명 : tsop-backend-api</li>
 * <li>서브 업무명 : com.adtcaps.tsop.mapper.inventory</li>
 * <li>설  명 : OivAlarmExceptionRuleHistMapper.java</li>
 * <li>작성일 : 2021. 11. 30.</li>
 * <li>작성자 : jeonyb4</li>
 * </ul>
 */
@Mapper
public interface OivAlarmExceptionRuleHistMapper {
	/**
	 * 
	 * createAlarmExceptionRuleHist
	 * 
	 * @param reqOivAlarmExceptionRuleHistDto
	 * @return int
	 */
	public int createAlarmExceptionRuleHist(OivAlarmExceptionRuleHistDto reqOivAlarmExceptionRuleHistDto);
	
	/**
	 * 
	 * listPageAlarmExceptionRuleHist
	 * 
	 * @param alarmExceptionRuleHistGridRequestDto
	 * @return List<AlarmExceptionRuleHistGridResultDto>
	 */
	public List<AlarmExceptionRuleHistGridResultDto> listPageAlarmExceptionRuleHist(AlarmExceptionRuleHistGridRequestDto alarmExceptionRuleHistGridRequestDto);
	
	/**
	 * 
	 * readAlarmExceptionRuleHist
	 * 
	 * @param reqOivAlarmExceptionRuleHistDto
	 * @return AlarmExceptionRuleHistDetailDto
	 */
	public AlarmExceptionRuleHistDetailDto readAlarmExceptionRuleHist(OivAlarmExceptionRuleHistDto reqOivAlarmExceptionRuleHistDto);

}
