package com.adtcaps.tsop.mapper.common;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;

import com.adtcaps.tsop.domain.common.OcoSmsHistDto;
import com.adtcaps.tsop.portal.api.send.domain.SmsHistDetailResultDto;
import com.adtcaps.tsop.portal.api.send.domain.SmsHistGridRequestDto;
import com.adtcaps.tsop.portal.api.send.domain.SmsHistGridResultDto;

/**
 * 
 * <ul>
 * <li>업무 그룹명 : tsop-backend-api</li>
 * <li>서브 업무명 : com.adtcaps.tsop.mapper.common</li>
 * <li>설  명 : OcoSmsHistMapper.java</li>
 * <li>작성일 : 2021. 2. 25.</li>
 * <li>작성자 : jeonyb4</li>
 * </ul>
 */
@Mapper
public interface OcoSmsHistMapper {
	/**
	 * 
	 * createOcoSmsHist
	 *
	 * @param reqOcoSmsHistDto
	 * @return int
	 */
	public int createOcoSmsHist(OcoSmsHistDto reqOcoSmsHistDto);
	
	/**
	 * 
	 * listPageSmsHist
	 *
	 * @param reqSmsHistGridRequestDto
	 * @return List<SmsHistGridResultDto>
	 */
	public List<SmsHistGridResultDto> listPageSmsHist(SmsHistGridRequestDto reqSmsHistGridRequestDto);
	
	/**
	 * 
	 * readOcoSmsHist
	 *
	 * @param reqOcoSmsHistDto
	 * @return SmsHistDetailResultDto
	 */
	public SmsHistDetailResultDto readOcoSmsHist(OcoSmsHistDto reqOcoSmsHistDto);

}
