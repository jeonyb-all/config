package com.adtcaps.tsop.mapper.common;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;

import com.adtcaps.tsop.dashboard.api.common.domain.GuideScheduleRequestDto;
import com.adtcaps.tsop.domain.common.OcoGuideScheduleDto;
import com.adtcaps.tsop.portal.api.schedule.domain.GuideScheduleDetailResultDto;
import com.adtcaps.tsop.portal.api.schedule.domain.GuideScheduleGridRequestDto;
import com.adtcaps.tsop.portal.api.schedule.domain.GuideScheduleGridResultDto;

/**
 * 
 * <ul>
 * <li>업무 그룹명 : tsop-backend-api</li>
 * <li>서브 업무명 : com.adtcaps.tsop.mapper.common</li>
 * <li>설  명 : OcoGuideScheduleMapper.java</li>
 * <li>작성일 : 2020. 12. 4.</li>
 * <li>작성자 : jeonyb4</li>
 * </ul>
 */
@Mapper
public interface OcoGuideScheduleMapper {
	/**
	 * 
	 * listPageGuideSchedule
	 *
	 * @param guideScheduleGridRequestDto
	 * @return List<GuideScheduleGridResultDto>
	 */
	public List<GuideScheduleGridResultDto> listPageGuideSchedule(GuideScheduleGridRequestDto guideScheduleGridRequestDto);
	
	/**
	 * 
	 * createOcoGuideSchedule
	 *
	 * @param reqOcoGuideScheduleDto
	 * @return int
	 */
	public int createOcoGuideSchedule(OcoGuideScheduleDto reqOcoGuideScheduleDto);
	
	/**
	 * 
	 * readGuideSchedule
	 *
	 * @param reqOcoGuideScheduleDto
	 * @return GuideScheduleDetailResultDto
	 */
	public GuideScheduleDetailResultDto readGuideSchedule(OcoGuideScheduleDto reqOcoGuideScheduleDto);
	
	/**
	 * 
	 * updateOcoGuideSchedule
	 *
	 * @param reqOcoGuideScheduleDto
	 * @return int
	 */
	public int updateOcoGuideSchedule(OcoGuideScheduleDto reqOcoGuideScheduleDto);
	
	/**
	 * 
	 * deleteOcoGuideSchedule
	 *
	 * @param reqOcoGuideScheduleDto
	 * @return int
	 */
	public int deleteOcoGuideSchedule(OcoGuideScheduleDto reqOcoGuideScheduleDto);
	
	/**
	 * 
	 * listGuideScheduleStartDate
	 *
	 * @param guideScheduleRequestDto
	 * @return List<OcoGuideScheduleDto>
	 */
	public List<OcoGuideScheduleDto> listGuideScheduleStartDate(GuideScheduleRequestDto guideScheduleRequestDto);
	
	
	/***************************** Dashboard *****************************/
	
	/**
	 * 
	 * updateOcoGuideScheduleCheckYn
	 *
	 * @param reqOcoGuideScheduleDto
	 * @return int
	 */
	public int updateOcoGuideScheduleCheckYn(OcoGuideScheduleDto reqOcoGuideScheduleDto);

}
