package com.adtcaps.tsop.mapper.mobile;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;

import com.adtcaps.tsop.portal.api.mobileWorkOrder.domain.MobileWorkOrderMgmtControllDto;
import com.adtcaps.tsop.portal.api.mobileWorkOrder.domain.MobileWorkOrderMgmtDto;
import com.adtcaps.tsop.portal.api.mobileWorkOrder.domain.MobileWorkerDto;
import com.adtcaps.tsop.portal.api.mobileWorkOrder.domain.MobileWorkerFormatDto;
/**
 * 
 * <ul>
 * <li>업무 그룹명 : tsop-backend-api</li>
 * <li>서브 업무명 : com.adtcaps.tsop.mapper.mobile</li>
 * <li>설  명 : OwkMobileWorkOrderMgmtMapper.java</li>
 * <li>작성일 : 2021. 12. 29.</li>
 * <li>작성자 : leembn</li>
 * </ul>
 */

@Mapper
public interface OwkMobileWorkOrderMgmtMapper {
	
	
	/**
	 * @param mobileWorkOrderMgmtDto
	 * @return List<MobileWorkOrderMgmtDto>
	 */
	public List<MobileWorkOrderMgmtDto> listMobileWorkOrderMgmt(MobileWorkOrderMgmtControllDto mobileWorkOrderMgmtControllDto);
	
	/**
	 * @param mobileWorkOrderMgmtControllDto
	 * @return MobileWorkerDto
	 */
	public MobileWorkerDto MobileWorkerDetail(MobileWorkOrderMgmtControllDto mobileWorkOrderMgmtControllDto);
	
	
	/**
	 * @param mobileWorkOrderMgmtControllDto
	 * @return MobileWorkerDto
	 */
	public MobileWorkerDto countMobileWorkOrder(MobileWorkOrderMgmtControllDto mobileWorkOrderMgmtControllDto);
	
	/**
	 * @param mobileWorkOrderMgmtControllDto
	 * @return MobileWorkOrderMgmtDto
	 */
	public MobileWorkOrderMgmtDto MobileWorkOrderMgmtDetail(MobileWorkOrderMgmtControllDto mobileWorkOrderMgmtControllDto);
	
	/**
	 * @param mobileWorkOrderMgmtControllDto
	 * @return MobileWorkerFormatDto
	 */
	public MobileWorkerFormatDto MobileWorkOrderMgmtDetailFormat(MobileWorkOrderMgmtControllDto mobileWorkOrderMgmtControllDto);
	
	
	/**
	 * @param mobileWorkOrderMgmtControllDto
	 * @return MobileWorkerFormatDto
	 */
	public int updateMobileWorkOrderStatus(MobileWorkOrderMgmtControllDto mobileWorkOrderMgmtControllDto);
	
	/**
	 * @param mobileWorkOrderMgmtControllDto
	 * @return MobileWorkOrderMgmtDto
	 */
	public MobileWorkOrderMgmtDto MobileWorkOrderAlarmMgmtDetail(MobileWorkOrderMgmtControllDto mobileWorkOrderMgmtControllDto);
	
}
