package com.adtcaps.tsop.mapper.fm;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;

import com.adtcaps.tsop.portal.api.report.domain.CondiMachineOperHourResultDto;
import com.adtcaps.tsop.portal.api.report.domain.CoolerOperHourResultDto;
import com.adtcaps.tsop.portal.api.report.domain.TemprHumidResultDto;
import com.adtcaps.tsop.portal.api.report.domain.WeekReportMakeRequestDto;

/**
 * 
 * <ul>
 * <li>업무 그룹명 : tsop-backend-api</li>
 * <li>서브 업무명 : com.adtcaps.tsop.mapper.fm</li>
 * <li>설  명 : OfmBuildingHvacDetailStatMapper.java</li>
 * <li>작성일 : 2021. 12. 14.</li>
 * <li>작성자 : jeonyb4</li>
 * </ul>
 */
@Mapper
public interface OfmBuildingHvacDetailStatMapper {
	
	
	
	/***************************** Week Report *****************************/
	
	/**
	 * 
	 * listReportFloorTemprHumidThisYearSummary
	 * 
	 * @param weekReportMakeRequestDto
	 * @return List<TemprHumidResultDto>
	 */
	public List<TemprHumidResultDto> listReportFloorTemprHumidThisYearSummary(WeekReportMakeRequestDto weekReportMakeRequestDto);
	
	/**
	 * 
	 * listReportFloorTemprHumidLastYearSummary
	 * 
	 * @param weekReportMakeRequestDto
	 * @return List<TemprHumidResultDto>
	 */
	public List<TemprHumidResultDto> listReportFloorTemprHumidLastYearSummary(WeekReportMakeRequestDto weekReportMakeRequestDto);
	
	/**
	 * 
	 * listReportCoolerMachineSummary
	 * 
	 * @param weekReportMakeRequestDto
	 * @return List<CoolerOperHourResultDto>
	 */
	public List<CoolerOperHourResultDto> listReportCoolerMachineSummary(WeekReportMakeRequestDto weekReportMakeRequestDto);
	
	/**
	 * 
	 * listReportCoolerTowerSummary
	 * 
	 * @param weekReportMakeRequestDto
	 * @return List<CoolerOperHourResultDto>
	 */
	public List<CoolerOperHourResultDto> listReportCoolerTowerSummary(WeekReportMakeRequestDto weekReportMakeRequestDto);
	
	/**
	 * 
	 * listReportFloorCondiMachineThisYearSummary
	 * 
	 * @param weekReportMakeRequestDto
	 * @return List<CondiMachineOperHourResultDto>
	 */
	public List<CondiMachineOperHourResultDto> listReportFloorCondiMachineThisYearSummary(WeekReportMakeRequestDto weekReportMakeRequestDto);
	
	/**
	 * 
	 * listReportFloorCondiMachineLastYearSummary
	 * 
	 * @param weekReportMakeRequestDto
	 * @return List<CondiMachineOperHourResultDto>
	 */
	public List<CondiMachineOperHourResultDto> listReportFloorCondiMachineLastYearSummary(WeekReportMakeRequestDto weekReportMakeRequestDto);
	

}
