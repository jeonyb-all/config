package com.adtcaps.tsop.mapper.other;

import org.apache.ibatis.annotations.Mapper;

import com.adtcaps.tsop.dashboard.api.other.domain.WeatherForecastExtraShortResultDto;
import com.adtcaps.tsop.domain.other.OotWeatherForecastExtraShortDto;

/**
 * 
 * <ul>
 * <li>업무 그룹명 : tsop-backend-api</li>
 * <li>서브 업무명 : com.adtcaps.tsop.mapper.other</li>
 * <li>설  명 : OotWeatherForecastExtraShortMapper.java</li>
 * <li>작성일 : 2020. 12. 18.</li>
 * <li>작성자 : jeonyb4</li>
 * </ul>
 */
@Mapper
public interface OotWeatherForecastExtraShortMapper {
	/**
	 * 
	 * readReportBuildingWeather
	 * 
	 * @param reqOotWeatherForecastExtraShortDto
	 * @return WeatherForecastExtraShortResultDto
	 */
	public WeatherForecastExtraShortResultDto readReportBuildingWeather(OotWeatherForecastExtraShortDto reqOotWeatherForecastExtraShortDto);
	
	/***************************** Dashboard *****************************/
	
	/**
	 * 
	 * readBuildingWeatherForecastExtraShort
	 *
	 * @param reqOotWeatherForecastExtraShortDto
	 * @return WeatherForecastExtraShortResultDto
	 */
	public WeatherForecastExtraShortResultDto readBuildingWeatherForecastExtraShort(OotWeatherForecastExtraShortDto reqOotWeatherForecastExtraShortDto);

}
