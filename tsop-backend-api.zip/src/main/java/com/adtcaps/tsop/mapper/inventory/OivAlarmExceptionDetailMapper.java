package com.adtcaps.tsop.mapper.inventory;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;

import com.adtcaps.tsop.domain.inventory.OivAlarmExceptionCategoryDto;
import com.adtcaps.tsop.domain.inventory.OivAlarmExceptionDetailDto;
import com.adtcaps.tsop.domain.inventory.OivAlarmExceptionDto;
import com.adtcaps.tsop.portal.api.alarm.domain.AlarmExceptionAlarmCodeValueDto;
import com.adtcaps.tsop.portal.api.alarm.domain.AlarmExceptionDateDto;
import com.adtcaps.tsop.portal.api.alarm.domain.AlarmExceptionHhDto;
import com.adtcaps.tsop.portal.api.alarm.domain.AlarmExceptionItemDto;
import com.adtcaps.tsop.portal.api.alarm.domain.AlarmExceptionObjectDto;

/**
 * 
 * <ul>
 * <li>업무 그룹명 : tsop-backend-api</li>
 * <li>서브 업무명 : com.adtcaps.tsop.mapper.inventory</li>
 * <li>설  명 : OivAlarmExceptionDetailMapper.java</li>
 * <li>작성일 : 2021. 10. 15.</li>
 * <li>작성자 : jeonyb4</li>
 * </ul>
 */
@Mapper
public interface OivAlarmExceptionDetailMapper {
	/**
	 * 
	 * createAlarmExceptionDetail
	 * 
	 * @param reqOivAlarmExceptionDetailDto
	 * @return int
	 */
	public int createAlarmExceptionDetail(OivAlarmExceptionDetailDto reqOivAlarmExceptionDetailDto);
	
	/**
	 * 
	 * readAlarmExceptionDetail
	 * 
	 * @param reqOivAlarmExceptionCategoryDto
	 * @return AlarmExceptionItemDto
	 */
	public AlarmExceptionItemDto readAlarmExceptionDetail(OivAlarmExceptionCategoryDto reqOivAlarmExceptionCategoryDto);
	
	/**
	 * 
	 * listAlarmExceptionDetail3
	 * 
	 * @param reqOivAlarmExceptionCategoryDto
	 * @return List<AlarmExceptionObjectDto>
	 */
	public List<AlarmExceptionObjectDto> listAlarmExceptionDetail3(OivAlarmExceptionCategoryDto reqOivAlarmExceptionCategoryDto);
	
	/**
	 * 
	 * listAlarmExceptionDetail4
	 * 
	 * @param reqOivAlarmExceptionCategoryDto
	 * @return List<AlarmExceptionAlarmCodeValueDto>
	 */
	public List<AlarmExceptionAlarmCodeValueDto> listAlarmExceptionDetail4(OivAlarmExceptionCategoryDto reqOivAlarmExceptionCategoryDto);
	
	/**
	 * 
	 * listFmAlarmExceptionDetail4
	 * 
	 * @param reqOivAlarmExceptionCategoryDto
	 * @return List<AlarmExceptionAlarmCodeValueDto>
	 */
	public List<AlarmExceptionAlarmCodeValueDto> listFmAlarmExceptionDetail4(OivAlarmExceptionCategoryDto reqOivAlarmExceptionCategoryDto);
	
	/**
	 * 
	 * listAlarmExceptionDetail2
	 * 
	 * @param reqOivAlarmExceptionCategoryDto
	 * @return List<String>
	 */
	public List<String> listAlarmExceptionDetail2(OivAlarmExceptionCategoryDto reqOivAlarmExceptionCategoryDto);
	
	/**
	 * 
	 * listAlarmExceptionDetail6
	 * 
	 * @param reqOivAlarmExceptionCategoryDto
	 * @return List<AlarmExceptionHhDto>
	 */
	public List<AlarmExceptionHhDto> listAlarmExceptionDetail6(OivAlarmExceptionCategoryDto reqOivAlarmExceptionCategoryDto);
	
	/**
	 * 
	 * listAlarmExceptionDetail7
	 * 
	 * @param reqOivAlarmExceptionCategoryDto
	 * @return List<AlarmExceptionDateDto>
	 */
	public List<AlarmExceptionDateDto> listAlarmExceptionDetail7(OivAlarmExceptionCategoryDto reqOivAlarmExceptionCategoryDto);
	
	/**
	 * 
	 * deleteAlarmExceptionDetail
	 * 
	 * @param reqOivAlarmExceptionDto
	 * @return int
	 */
	public int deleteAlarmExceptionDetail(OivAlarmExceptionDto reqOivAlarmExceptionDto);
	
	/**
	 * 
	 * readAlarmExceptionDetailCount
	 * 
	 * @param reqAlarmExceptionItemDto
	 * @return int
	 */
	public int readAlarmExceptionDetailCount(AlarmExceptionItemDto reqAlarmExceptionItemDto);

}
