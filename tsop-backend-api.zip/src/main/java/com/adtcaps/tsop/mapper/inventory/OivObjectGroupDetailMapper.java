package com.adtcaps.tsop.mapper.inventory;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;

import com.adtcaps.tsop.domain.inventory.OivObjectGroupDetailDto;
import com.adtcaps.tsop.domain.inventory.OivObjectGroupDto;
import com.adtcaps.tsop.portal.api.object.domain.ObjectGroupDetailGridRequestDto;
import com.adtcaps.tsop.portal.api.object.domain.ObjectGroupDetailGridResultDto;
import com.adtcaps.tsop.portal.api.object.domain.ObjectGroupDetailProcessDto;

/**
 * 
 * <ul>
 * <li>업무 그룹명 : tsop-backend-api</li>
 * <li>서브 업무명 : com.adtcaps.tsop.mapper.inventory</li>
 * <li>설  명 : OivObjectGroupDetailMapper.java</li>
 * <li>작성일 : 2020. 12. 14.</li>
 * <li>작성자 : jeonyb4</li>
 * </ul>
 */
@Mapper
public interface OivObjectGroupDetailMapper {
	/**
	 * 
	 * listPageObjectGroupDetail
	 *
	 * @param objectGroupDetailGridRequestDto
	 * @return List<ObjectGroupDetailGridResultDto>
	 */
	public List<ObjectGroupDetailGridResultDto> listPageObjectGroupDetail(ObjectGroupDetailGridRequestDto objectGroupDetailGridRequestDto);
	
	/**
	 * 
	 * createOivObjectGroupDetail
	 *
	 * @param reqOivObjectGroupDetailDto
	 * @return int
	 */
	public int createOivObjectGroupDetail(OivObjectGroupDetailDto reqOivObjectGroupDetailDto);
	
	/**
	 * 
	 * listObjectGroupDetail
	 *
	 * @param reqOivObjectGroupDetailDto
	 * @return List<ObjectGroupDetailProcessDto>
	 */
	public List<ObjectGroupDetailProcessDto> listObjectGroupDetail(OivObjectGroupDto reqOivObjectGroupDto);
	
	/**
	 * 
	 * deleteOivObjectGroupDetail
	 *
	 * @param reqOivObjectGroupDto
	 * @return int
	 */
	public int deleteOivObjectGroupDetail(OivObjectGroupDto reqOivObjectGroupDto);
	
	/**
	 * 
	 * readMasterObjectCount
	 *
	 * @param reqOivObjectGroupDetailDto
	 * @return int
	 */
	public int readMasterObjectCount(OivObjectGroupDetailDto reqOivObjectGroupDetailDto);

}
