/**
 *
 */
package com.adtcaps.tsop.mapper.work;

import org.apache.ibatis.annotations.Mapper;

import com.adtcaps.tsop.domain.work.OwkCheckCycleDto;
import com.adtcaps.tsop.domain.work.OwkWorkFormatDto;

/**
 * <ul>
 * <li>업무 그룹명 : com.adtcaps.tsop.mapper.work</li>
 * <li>서브 업무명 : com.adtcaps.tsop.mapper.work</li>
 * <li>설  명 : OwkCheckCycleMapper.java</li>
 * <li>작성일 : 2021. 12. 22.</li>
 * <li>작성자 : msham</li>
 * </ul>
 */
@Mapper
public interface OwkCheckCycleMapper {

	/**
	 * pageCheckCycle
	 *
	 * @param owkCheckCycleDto
	 * @return OwkCheckCycleDto
	 */
	OwkCheckCycleDto pageCheckCycle(OwkCheckCycleDto owkCheckCycleDto);

	/**
	 * insertOwkCheckCycle
	 *
	 * @param owkCheckCycleDto void
	 */
	void insertOwkCheckCycle(OwkCheckCycleDto owkCheckCycleDto);

	/**
	 * pageCheckModyfyCycle
	 *
	 * @param owkWorkFormatDto
	 * @return String
	 */
	String pageCheckModyfyCycle(OwkWorkFormatDto owkWorkFormatDto);

}
