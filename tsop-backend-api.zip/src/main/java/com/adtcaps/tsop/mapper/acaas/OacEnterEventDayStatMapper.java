package com.adtcaps.tsop.mapper.acaas;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;

import com.adtcaps.tsop.dashboard.api.acaas.domain.EnterEventAlarmCurrentStateQueryResultDto;
import com.adtcaps.tsop.domain.acaas.OacEnterEventDayStatDto;
import com.adtcaps.tsop.helper.domain.BasePageDto;
import com.adtcaps.tsop.portal.api.acaas.domain.PortalDashboardEnterEventDayStatResultDto;
import com.adtcaps.tsop.portal.api.statistics.domain.AcaasEnterEventStatisticsResultDto;

/**
 * 
 * <ul>
 * <li>업무 그룹명 : tsop-backend-api</li>
 * <li>서브 업무명 : com.adtcaps.tsop.mapper.acaas</li>
 * <li>설  명 : OacEnterEventDayStatMapper.java</li>
 * <li>작성일 : 2020. 12. 24.</li>
 * <li>작성자 : jeonyb4</li>
 * </ul>
 */
@Mapper
public interface OacEnterEventDayStatMapper {
	/**
	 * 
	 * listEnterEventAlarmCurrentStateChart
	 *
	 * @param reqOacEnterEventDayStatDto
	 * @return List<EnterEventAlarmCurrentStateQueryResultDto>
	 */
	public List<EnterEventAlarmCurrentStateQueryResultDto> listEnterEventAlarmCurrentStateChart(OacEnterEventDayStatDto reqOacEnterEventDayStatDto);

	/**
	 * listAcaasEventStatisticsDaily
	 * 
	 * @param reqAcaasStatistics
	 * @return List<AcaasEnterEventStatisticsResultDto>
	 */
	public List<AcaasEnterEventStatisticsResultDto> listAcaasEnterEventStatisticsDaily(BasePageDto reqAcaasStatistics);
	
	
	/***************************** Portal Main *****************************/
	
	/**
	 * 
	 * listPortalDashboardEnterEventDayStatChart
	 *
	 * @param reqOacEnterEventDayStatDto
	 * @return List<PortalDashboardEnterEventDayStatResultDto>
	 */
	public List<PortalDashboardEnterEventDayStatResultDto> listPortalDashboardEnterEventDayStatChart(OacEnterEventDayStatDto reqOacEnterEventDayStatDto);
	
}
