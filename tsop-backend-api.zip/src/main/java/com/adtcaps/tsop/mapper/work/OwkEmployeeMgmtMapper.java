package com.adtcaps.tsop.mapper.work;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;

import com.adtcaps.tsop.domain.staffMgmt.OwkEmployeeDto;
import com.adtcaps.tsop.portal.api.mobileWorkOrder.domain.MobileUserInfoDto;
import com.adtcaps.tsop.portal.api.staffMgmt.domain.EmployeeMgmtGridDto;
import com.adtcaps.tsop.portal.api.staffMgmt.domain.EmployeeMgmtUpdateDto;
import com.adtcaps.tsop.portal.api.workorder.domain.WorkOrderEmployeeMgmtGridDto;

/**
 *
 * <ul>
 * <li>업무 그룹명 : tsop-backend-api</li>
 * <li>서브 업무명 : com.adtcaps.tsop.mapper.work</li>
 * <li>설  명 : OwkEmployeeMgmtMapper.java</li>
 * <li>작성일 : 2021. 12. 3.</li>
 * <li>작성자 : ricky</li>
 * </ul>
 */
@Mapper
public interface OwkEmployeeMgmtMapper {
	/**
	 *
	 * listPageEmployee
	 *
	 * @param EmployeeDto
	 * @return List<EmployeeDto>
	 */
	public List<EmployeeMgmtGridDto> listPageEmployeeMgmt(EmployeeMgmtGridDto employeeMgmtGridDto);

	/**
	 * countEmpIdCount
	 * @param owkEmployeeDto
	 * @return
	 */
	public int countEmpIdCount(OwkEmployeeDto owkEmployeeDto);

	/**
	 * createEmployee
	 * @param owkEmployeeDto
	 * @return
	 */
	public int createEmployee(OwkEmployeeDto owkEmployeeDto);

	/**
	 * updateEmployee
	 * @param owkEmployeeDto
	 * @return
	 */
	public int updateEmployee(OwkEmployeeDto owkEmployeeDto);

	/**
	 *
	 * @param deleteEmployee
	 * @return
	 */
	public int deleteEmployee(OwkEmployeeDto owkEmployeeDto);

	/**
	 * countEmpName
	 * @param owkEmployeeDto
	 * @return
	 */
	public int countEmpName(OwkEmployeeDto owkEmployeeDto);

	/**
	 * listEmployeeMgmt
	 * @param employeeMgmtGridDto
	 * @return
	 */
	public List<EmployeeMgmtGridDto> listEmployeeMgmt(EmployeeMgmtGridDto employeeMgmtGridDto);

	/**
	 * listEmployeeSimpleMgmt
	 * @param employeeMgmtGridDto
	 * @return
	 */
	public List<EmployeeMgmtGridDto> listEmployeeSimpleMgmt(EmployeeMgmtGridDto employeeMgmtGridDto);


	/***************************** 사용자관리용 *****************************/
	/**
	 *
	 * readEmployeeByUserId
	 *
	 * @param reqOwkEmployeeDto
	 * @return OwkEmployeeDto
	 */
	public OwkEmployeeDto readEmployeeByUserId(OwkEmployeeDto reqOwkEmployeeDto);

	/**
	 *
	 * updateEmployeeUserId
	 *
	 * @param reqOwkEmployeeDto
	 * @return int
	 */
	public int updateEmployeeUserId(OwkEmployeeDto reqOwkEmployeeDto);

	/**
	 * deleteEmployeeUserId
	 * @param owkEmployeeDto
	 * @return
	 */
	public int deleteEmployeeUserId(OwkEmployeeDto owkEmployeeDto);

	/**
	 * listWorkEmployeeMgmt
	 *
	 * @param employeeMgmtGridDto
	 * @return List<EmployeeMgmtGridDto>
	 */
	public List<EmployeeMgmtGridDto> listWorkEmployeeMgmt(WorkOrderEmployeeMgmtGridDto workOrderEmployeeMgmtGridDto);

	/**
	 * lht
	 * checkOrderBy
	 *
	 * @param bldId
	 * @return String
	 */
	public String checkOrderBy(String bldId);

	/**
	 * lht
	 * listNewWorkEmployeeMgmt
	 *
	 * @param employeeMgmtGridDto
	 * @return List<EmployeeMgmtGridDto>
	 */
	public List<EmployeeMgmtGridDto> listNewWorkEmployeeMgmt(WorkOrderEmployeeMgmtGridDto workOrderEmployeeMgmtGridDto);

	/**
	 *
	 * @param employeeMgmtUpdateDto
	 * @return
	 */
	public int createEmployeeHist(EmployeeMgmtUpdateDto employeeMgmtUpdateDto);

	/**
	 *
	 * @param dp
	 * @return
	 */
	public List<OwkEmployeeDto> listEmployeeSimpleMgmt2(OwkEmployeeDto dp);

	/**
	 * pageMobileUserInfo
	 *
	 * @param userId
	 * @return MobileUserInfoDto
	 */
	public MobileUserInfoDto pageMobileUserInfo(String userId);
	
	
	/***************************** jeonyb4 *****************************/
	/**
	 * 
	 * listUserMgmtEmployee
	 * 
	 * @param employeeMgmtGridDto
	 * @return List<EmployeeMgmtGridDto>
	 */
	public List<EmployeeMgmtGridDto> listUserMgmtEmployee(EmployeeMgmtGridDto employeeMgmtGridDto);
	

}
