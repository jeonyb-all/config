package com.adtcaps.tsop.mapper.common;

import org.apache.ibatis.annotations.Mapper;

import com.adtcaps.tsop.domain.common.OcoTechSupportRequestBuildingDto;

/**
 * 
 * <ul>
 * <li>업무 그룹명 : tsop-backend-api</li>
 * <li>서브 업무명 : com.adtcaps.tsop.mapper.common</li>
 * <li>설  명 : OcoTechSupportRequestBuildingMapper.java</li>
 * <li>작성일 : 2020. 12. 16.</li>
 * <li>작성자 : jeonyb4</li>
 * </ul>
 */
@Mapper
public interface OcoTechSupportRequestBuildingMapper {
	/**
	 * 
	 * createOcoTechSupportRequestBuilding
	 *
	 * @param reqOcoTechSupportRequestBuildingDto
	 * @return int
	 */
	public int createOcoTechSupportRequestAddBuilding(OcoTechSupportRequestBuildingDto reqOcoTechSupportRequestBuildingDto);
	
	/**
	 * 
	 * createOcoTechSupportRequestModifyBuilding
	 *
	 * @param reqOcoTechSupportRequestBuildingDto
	 * @return int
	 */
	public int createOcoTechSupportRequestModifyBuilding(OcoTechSupportRequestBuildingDto reqOcoTechSupportRequestBuildingDto);
	
	/**
	 * 
	 * readOcoTechSupportRequestBuilding
	 *
	 * @param reqOcoTechSupportRequestBuildingDto
	 * @return OcoTechSupportRequestBuildingDto
	 */
	public OcoTechSupportRequestBuildingDto readOcoTechSupportRequestBuilding(OcoTechSupportRequestBuildingDto reqOcoTechSupportRequestBuildingDto);

}
