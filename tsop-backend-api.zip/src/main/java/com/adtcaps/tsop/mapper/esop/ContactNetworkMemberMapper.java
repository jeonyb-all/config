package com.adtcaps.tsop.mapper.esop;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;

import com.adtcaps.tsop.domain.esop.ContactNetworkMemberDto;
import com.adtcaps.tsop.domain.staffMgmt.OwkEmployeeDto;
import com.adtcaps.tsop.portal.api.esop.domain.ContactNetworkMemberHistGridRequestDto;
import com.adtcaps.tsop.portal.api.esop.domain.ContactNetworkMemberHistGridResultDto;
import com.adtcaps.tsop.portal.api.esop.domain.EmployeeDto;

@Mapper
public interface ContactNetworkMemberMapper {
	/**
	 * listContactNetworkEmployee
	 * @param contactNetworkMemberDto
	 * @return List<EmployeeDto>
	 */
	public List<EmployeeDto> listEsopEmployee(ContactNetworkMemberDto contactNetworkMemberDto);

	/**
	 * listContactNetworkMemberEmpId
	 * @param contactNetworkMemberDto
	 * @return List<ContactNetworkMemberDto>
	 */
	public List<ContactNetworkMemberDto> listContactNetworkMemberEmpId(ContactNetworkMemberDto contactNetworkMemberDto);

	/**
	 * listEmployee
	 * @param employeeDto
	 * @return List<EmployeeDto>
	 */
	public List<EmployeeDto> listEmployee(EmployeeDto employeeDto);

	/**
	 * listContactNetworkMember
	 * @param employeeDto
	 * @return List<EmployeeDto>
	 */
	public List<EmployeeDto> listContactNetworkMember(EmployeeDto employeeDto);

	/**
	 * listInsertMember
	 * @param employeeDto
	 * @return List<EmployeeDto>
	 */
	public List<EmployeeDto> listInsertMember(ContactNetworkMemberDto contactNetworkMemberDto);

	/**
	 * listUpdateMember
	 * @param employeeDto
	 * @return List<EmployeeDto>
	 */
	public List<EmployeeDto> listUpdateMember(ContactNetworkMemberDto contactNetworkMemberDto);

	/**
	 * listDeleteMember
	 * @param employeeDto
	 * @return List<EmployeeDto>
	 */
	public List<EmployeeDto> listDeleteMember(ContactNetworkMemberDto contactNetworkMemberDto);

	/**
	 * listRemoveMember
	 * @param contactNetworkMemberDto
	 * @return List<EmployeeDto>
	 */
	public List<EmployeeDto> listRemoveMember(ContactNetworkMemberDto contactNetworkMemberDto);

	/**
	 * createContactNetworkMember
	 * @param contactNetworkMemberDto
	 * @return int
	 */
	public int createContactNetworkMember(ContactNetworkMemberDto contactNetworkMemberDto);

	/**
	 * updateContactNetworkMember
	 * @param contactNetworkMemberDto
	 * @return int
	 */
	public int updateContactNetworkMember(ContactNetworkMemberDto contactNetworkMemberDto);

	/**
	 * updateContactNetworkMemberSetResponseTeamNull
	 * @param contactNetworkMemberDto
	 * @return int
	 */
	public int updateContactNetworkMemberSetResponseTeamNull(ContactNetworkMemberDto contactNetworkMemberDto);

	/**
	 * updateContactNetworkMemberSetContactNetworkNull
	 * @param contactNetworkMemberDto
	 * @return int
	 */
	public int updateContactNetworkMemberSetContactNetworkNull(ContactNetworkMemberDto contactNetworkMemberDto);

	/**
	 * deleteContactNetworkMember
	 * @param contactNetworkMemberDto
	 * @return int
	 */
	public int deleteContactNetworkMember(ContactNetworkMemberDto contactNetworkMemberDto);

	/**
	 * readContactNetworkMember
	 * @param contactNetworkMemberDto
	 * @return ContactNetworkMemberDto
	 */
	public ContactNetworkMemberDto readContactNetworkMember(ContactNetworkMemberDto contactNetworkMemberDto);

	/**
	 * listPageContactNetworkMemberHist
	 * @param contactNetworkMemberHistGridRequestDto
	 * @return List<ContactNetworkMemberHistGridResultDto>
	 */
	public List<ContactNetworkMemberHistGridResultDto> listPageContactNetworkMemberHist(ContactNetworkMemberHistGridRequestDto contactNetworkMemberHistGridRequestDto);

	/**
	 * readEmployee
	 * @param owkEmployeeDto
	 * @return OwkEmployeeDto
	 */
	public OwkEmployeeDto readEmployee(OwkEmployeeDto owkEmployeeDto);
}
