package com.adtcaps.tsop.mapper.mashup;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.session.ResultHandler;

import com.adtcaps.tsop.domain.mashup.OmuAlarmHistDto;
import com.adtcaps.tsop.portal.api.alarm.domain.AlarmHistDetailResultDto;
import com.adtcaps.tsop.portal.api.alarm.domain.AlarmHistGridRequestDto;
import com.adtcaps.tsop.portal.api.alarm.domain.AlarmHistGridResultDto;
import com.adtcaps.tsop.portal.api.report.domain.AppendixAlarmResultDto;
import com.adtcaps.tsop.portal.api.report.domain.ServiceAlarmCountResultDto;
import com.adtcaps.tsop.portal.api.report.domain.WeekReportAlarmChartResultDto;
import com.adtcaps.tsop.portal.api.report.domain.WeekReportMakeRequestDto;

/**
 * 
 * <ul>
 * <li>업무 그룹명 : tsop-backend-api</li>
 * <li>서브 업무명 : com.adtcaps.tsop.mapper.mashup</li>
 * <li>설  명 : OmuAlarmHistMapper.java</li>
 * <li>작성일 : 2021. 10. 13.</li>
 * <li>작성자 : jeonyb4</li>
 * </ul>
 */
@Mapper
public interface OmuAlarmHistMapper {
	/**
	 * 
	 * listPageAlarmHist
	 * 
	 * @param alarmHistGridRequestDto
	 * @return List<AlarmHistGridResultDto>
	 */
	public List<AlarmHistGridResultDto> listPageAlarmHist(AlarmHistGridRequestDto alarmHistGridRequestDto);
	
	/**
	 * 
	 * listExcelAlarmHist
	 * 
	 * @param alarmHistGridRequestDto
	 * @param resultHandler void
	 */
	public void listExcelAlarmHist(AlarmHistGridRequestDto alarmHistGridRequestDto, ResultHandler<AlarmHistGridResultDto> resultHandler);
	
	/**
	 * 
	 * readOmuAlarmHist
	 * 
	 * @param reqOmuAlarmHistDto
	 * @return AlarmHistDetailResultDto
	 */
	public AlarmHistDetailResultDto readOmuAlarmHist(OmuAlarmHistDto reqOmuAlarmHistDto);
	
	/**
	 * 
	 * updateAlarmHistExceptionEscape
	 * 
	 * @param reqOmuAlarmHistDto
	 * @return int
	 */
	public int updateAlarmHistExceptionEscape(OmuAlarmHistDto reqOmuAlarmHistDto);
	
	
	/***************************** Week Report *****************************/
	/**
	 * 
	 * listReportServiceSummaryAlarm
	 * 
	 * @param weekReportMakeRequestDto
	 * @return List<ServiceAlarmCountResultDto>
	 */
	public List<ServiceAlarmCountResultDto> listReportServiceSummaryAlarm(WeekReportMakeRequestDto weekReportMakeRequestDto);
	
	/**
	 * 
	 * listWeekReportServiceAlarmChart
	 * 
	 * @param weekReportMakeRequestDto
	 * @return List<WeekReportAlarmChartResultDto>
	 */
	public List<WeekReportAlarmChartResultDto> listWeekReportServiceAlarmChart(WeekReportMakeRequestDto weekReportMakeRequestDto);
	
	/**
	 * 
	 * listReportAppendixAlarm
	 * 
	 * @param weekReportMakeRequestDto
	 * @return List<AppendixAlarmResultDto>
	 */
	public List<AppendixAlarmResultDto> listReportAppendixAlarm(WeekReportMakeRequestDto weekReportMakeRequestDto);
	
}
