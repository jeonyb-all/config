package com.adtcaps.tsop.mapper.common;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;

import com.adtcaps.tsop.domain.common.OcoBulletinboardDto;
import com.adtcaps.tsop.portal.api.board.domain.BulletinboardDetailResultDto;
import com.adtcaps.tsop.portal.api.board.domain.BulletinboardGridRequestDto;
import com.adtcaps.tsop.portal.api.board.domain.BulletinboardGridResultDto;
import com.adtcaps.tsop.portal.api.board.domain.PortalDashboardBulletinboardRequestDto;
import com.adtcaps.tsop.portal.api.board.domain.PortalDashboardBulletinboardResultDto;

/**
 * 
 * <ul>
 * <li>업무 그룹명 : tsop-backend-api</li>
 * <li>서브 업무명 : com.adtcaps.tsop.mapper.common</li>
 * <li>설  명 : OcoBulletinboardMapper.java</li>
 * <li>작성일 : 2020. 12. 4.</li>
 * <li>작성자 : jeonyb4</li>
 * </ul>
 */
@Mapper
public interface OcoBulletinboardMapper {
	/**
	 * 
	 * listPageBulletinboard
	 *
	 * @param bulletinboardGridRequestDto
	 * @return List<BulletinboardGridResultDto>
	 */
	public List<BulletinboardGridResultDto> listPageBulletinboard(BulletinboardGridRequestDto bulletinboardGridRequestDto);
	
	/**
	 * 
	 * createOcoBulletinboard
	 *
	 * @param reqOcoBulletinboardDto
	 * @return int
	 */
	public int createOcoBulletinboard(OcoBulletinboardDto reqOcoBulletinboardDto);
	
	/**
	 * 
	 * readOcoBulletinboard
	 *
	 * @param reqOcoBulletinboardDto
	 * @return BulletinboardDetailResultDto
	 */
	public BulletinboardDetailResultDto readOcoBulletinboard(OcoBulletinboardDto reqOcoBulletinboardDto);
	
	/**
	 * 
	 * readOcoBulletinboardAttachFile
	 *
	 * @param reqOcoBulletinboardDto
	 * @return BulletinboardDetailResultDto
	 */
	public BulletinboardDetailResultDto readOcoBulletinboardAttachFile(OcoBulletinboardDto reqOcoBulletinboardDto);
	
	/**
	 * 
	 * updateBrowseCnt
	 *
	 * @param reqOcoBulletinboardDto
	 * @return int
	 */
	public int updateBrowseCnt(OcoBulletinboardDto reqOcoBulletinboardDto);
	
	/**
	 * 
	 * updateBulletinboardAttachFileNum
	 *
	 * @param reqOcoBulletinboardDto
	 * @return int
	 */
	public int updateBulletinboardAttachFileNum(OcoBulletinboardDto reqOcoBulletinboardDto);
	
	/**
	 * 
	 * updateOcoBulletinboard
	 *
	 * @param reqOcoBulletinboardDto
	 * @return int
	 */
	public int updateOcoBulletinboard(OcoBulletinboardDto reqOcoBulletinboardDto);
	
	/**
	 * 
	 * deleteOcoBulletinboard
	 *
	 * @param reqOcoBulletinboardDto
	 * @return int
	 */
	public int deleteOcoBulletinboard(OcoBulletinboardDto reqOcoBulletinboardDto);
	
	/**
	 * 
	 * listPortalDashboardBulletinboard
	 *
	 * @param portalDashboardBulletinboardRequestDto
	 * @return List<PortalDashboardBulletinboardResultDto>
	 */
	public List<PortalDashboardBulletinboardResultDto> listPortalDashboardBulletinboard(PortalDashboardBulletinboardRequestDto portalDashboardBulletinboardRequestDto);
	
	
	/***************************** Remote Callee *****************************/
	
	/**
	 * 
	 * readOcoBulletinboardRemote
	 *
	 * @param reqOcoBulletinboardDto
	 * @return BulletinboardDetailResultDto
	 */
	public BulletinboardDetailResultDto readOcoBulletinboardRemote(OcoBulletinboardDto reqOcoBulletinboardDto);
	
	/**
	 * 
	 * readOcoBulletinboardRemoteAttachFile
	 *
	 * @param reqOcoBulletinboardDto
	 * @return BulletinboardDetailResultDto
	 */
	public BulletinboardDetailResultDto readOcoBulletinboardRemoteAttachFile(OcoBulletinboardDto reqOcoBulletinboardDto);
	
	
	/***************************** Dashboard *****************************/
	
	
	public List<BulletinboardGridResultDto> listDashboardNoticeBulletinboard(BulletinboardGridRequestDto bulletinboardGridRequestDto);
	

}
