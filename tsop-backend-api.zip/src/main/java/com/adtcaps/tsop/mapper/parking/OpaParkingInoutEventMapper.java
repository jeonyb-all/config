package com.adtcaps.tsop.mapper.parking;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;

import com.adtcaps.tsop.dashboard.api.parking.domain.ParkingInoutEventCurrentStateQueryResultDto;
import com.adtcaps.tsop.dashboard.api.parking.domain.ParkingReportResultDto;
import com.adtcaps.tsop.domain.parking.OpaParkingInoutEventDto;
import com.adtcaps.tsop.portal.api.search.domain.ParkingInOutSearchResultDto;
import com.adtcaps.tsop.portal.api.search.domain.ParkingSearchRequestDto;

/**
 * 
 * <ul>
 * <li>업무 그룹명 : tsop-backend-api</li>
 * <li>서브 업무명 : com.adtcaps.tsop.mapper.parking</li>
 * <li>설  명 : OpaParkingInoutEventMapper.java</li>
 * <li>작성일 : 2020. 12. 18.</li>
 * <li>작성자 : jeonyb4</li>
 * </ul>
 */

@Mapper
public interface OpaParkingInoutEventMapper {
	/**
	 * 
	 * listParkingInoutEventCurrentStateLineChart
	 *
	 * @param reqOpaParkingInoutEventDto
	 * @return List<ParkingInoutEventCurrentStateQueryResultDto>
	 */
	public List<ParkingInoutEventCurrentStateQueryResultDto> listParkingInoutEventCurrentStateLineChart(OpaParkingInoutEventDto reqOpaParkingInoutEventDto);
	
	/**
	 * 
	 * readParkingReport
	 *
	 * @param reqOpaParkingInoutEventDto
	 * @return ParkingReportResultDto
	 */
	public ParkingReportResultDto readParkingReport(OpaParkingInoutEventDto reqOpaParkingInoutEventDto);
	
	/**
	 * 
	 * listCarInOutInfoSearch
	 * 
	 * @param reqParkingSearch
	 * @return List<ParkingInOutSearchResultDto>
	 */
	public List<ParkingInOutSearchResultDto> listParkingInOutSearch(ParkingSearchRequestDto reqParkingSearch);

}
