package com.adtcaps.tsop.mapper.inventory;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;

import com.adtcaps.tsop.domain.inventory.OivBuildingDto;
import com.adtcaps.tsop.portal.api.building.domain.BuildingDetailResultDto;
import com.adtcaps.tsop.portal.api.building.domain.BuildingForComboResultDto;
import com.adtcaps.tsop.portal.api.building.domain.BuildingForShortGridResultDto;
import com.adtcaps.tsop.portal.api.building.domain.BuildingGridRequestDto;
import com.adtcaps.tsop.portal.api.building.domain.BuildingGridResultDto;

/**
 * 
 * <ul>
 * <li>업무 그룹명 : tsop-backend-api</li>
 * <li>서브 업무명 : com.adtcaps.tsop.mapper.inventory</li>
 * <li>설  명 : OivBuildingMapper.java</li>
 * <li>작성일 : 2020. 12. 4.</li>
 * <li>작성자 : jeonyb4</li>
 * </ul>
 */
@Mapper
public interface OivBuildingMapper {
	/**
	 * 
	 * listBuildingForCombo
	 *
	 * @param buildingGridRequestDto
	 * @return List<BuildingForComboResultDto>
	 */
	public List<BuildingForComboResultDto> listBuildingForCombo(BuildingGridRequestDto buildingGridRequestDto);
	
	/**
	 * 
	 * listBuildingForShortGrid
	 *
	 * @param buildingGridRequestDto
	 * @return List<BuildingForShortGridResultDto>
	 */
	public List<BuildingForShortGridResultDto> listBuildingForShortGrid(BuildingGridRequestDto buildingGridRequestDto);
	
	/**
	 * 
	 * listPageBuildingForShortGrid
	 *
	 * @param buildingGridRequestDto
	 * @return List<BuildingForShortGridResultDto>
	 */
	public List<BuildingForShortGridResultDto> listPageBuildingForShortGrid(BuildingGridRequestDto buildingGridRequestDto);
	
	/**
	 * 
	 * listPageBuildingForTechSupport
	 *
	 * @param buildingGridRequestDto
	 * @return List<BuildingForShortGridResultDto>
	 */
	public List<BuildingForShortGridResultDto> listPageBuildingForTechSupport(BuildingGridRequestDto buildingGridRequestDto);
	
	/**
	 * 
	 * listPageBuilding
	 *
	 * @param buildingGridRequestDto
	 * @return List<BuildingGridResultDto>
	 */
	public List<BuildingGridResultDto> listPageBuilding(BuildingGridRequestDto buildingGridRequestDto);
	
	/**
	 * 
	 * updateBuildingBldType
	 *
	 * @param reqOivBuildingDto
	 * @return int
	 */
	public int updateBuildingBldType(OivBuildingDto reqOivBuildingDto);
	
	/**
	 * 
	 * listBuildingHaveBldType
	 *
	 * @param reqOivBuildingDto
	 * @return List<BuildingForComboResultDto>
	 */
	public List<BuildingForComboResultDto> listBuildingHaveBldType(OivBuildingDto reqOivBuildingDto);
	
	/**
	 * 
	 * updateBuildingBldTypeNull
	 *
	 * @param reqOivBuildingDto
	 * @return int
	 */
	public int updateBuildingBldTypeNull(OivBuildingDto reqOivBuildingDto);
	
	/**
	 * 
	 * createOivBuilding
	 *
	 * @param reqOivBuildingDto
	 * @return int
	 */
	public int createOivBuilding(OivBuildingDto reqOivBuildingDto);
	
	/**
	 * 
	 * readOivBuilding
	 *
	 * @param reqOivBuildingDto
	 * @return BuildingDetailResultDto
	 */
	public BuildingDetailResultDto readOivBuilding(OivBuildingDto reqOivBuildingDto);
	
	/**
	 * 
	 * updateOivBuilding
	 *
	 * @param reqOivBuildingDto
	 * @return int
	 */
	public int updateOivBuilding(OivBuildingDto reqOivBuildingDto);
	
	
	
	/***************************** Dashboard *****************************/
	
	/**
	 * 
	 * listOivBuilding
	 *
	 * @param reqBuildingGridRequestDto
	 * @return List<OivBuildingDto>
	 */
	public List<OivBuildingDto> listOivBuilding(BuildingGridRequestDto reqBuildingGridRequestDto);

}
