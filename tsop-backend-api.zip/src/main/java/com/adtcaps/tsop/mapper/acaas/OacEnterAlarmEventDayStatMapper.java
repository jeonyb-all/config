package com.adtcaps.tsop.mapper.acaas;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;

import com.adtcaps.tsop.helper.domain.BasePageDto;
import com.adtcaps.tsop.portal.api.statistics.domain.AcaasAlarmEventStatisticsResultDto;

/**
 * 
 * <ul>
 * <li>업무 그룹명 : tsop-backend-api</li>
 * <li>서브 업무명 : com.adtcaps.tsop.mapper.acaas</li>
 * <li>설  명 : OacEnterAlarmEventDayStatMapper.java</li>
 * <li>작성일 : 2021. 01. 14.</li>
 * <li>작성자 : song</li>
 * </ul>
 */
@Mapper
public interface OacEnterAlarmEventDayStatMapper {

	/**
	 * 
	 * listAcaasAlarmEventStatistics
	 * 
	 * @param reqAcaasSearch
	 * @return List<AcaasAlarmEventStatisticsResultDto>
	 */
	public List<AcaasAlarmEventStatisticsResultDto> listAcaasAlarmEventStatistics(BasePageDto reqAcaasStatistics);
}
