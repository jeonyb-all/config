/**
 *
 */
package com.adtcaps.tsop.mapper.work;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;

import com.adtcaps.tsop.domain.work.OwkReportFormatChangePossibleDto;

/**
 * <ul>
 * <li>업무 그룹명 : com.adtcaps.tsop.mapper.work</li>
 * <li>서브 업무명 : com.adtcaps.tsop.mapper.work</li>
 * <li>설  명 : OwkReportFormatChangePossibleMapper.java</li>
 * <li>작성일 : 2022. 1. 21.</li>
 * <li>작성자 : msham</li>
 * </ul>
 */
@Mapper
public interface OwkReportFormatChangePossibleMapper {

	/**
	 * pageOwkReportFormatChangePossible
	 *
	 * @param owkReportFormatChangePossibleDto
	 * @return OwkReportFormatChangePossibleDto
	 */
	OwkReportFormatChangePossibleDto pageOwkReportFormatChangePossible(
			OwkReportFormatChangePossibleDto owkReportFormatChangePossibleDto);

	/**
	 * pageOwkReportFormatLimitPossible
	 *
	 * @param owkReportFormatChangePossibleDto
	 * @return List<OwkReportFormatChangePossibleDto>
	 */
	List<OwkReportFormatChangePossibleDto> pageOwkReportFormatLimitPossible(
			OwkReportFormatChangePossibleDto owkReportFormatChangePossibleDto);

}
