package com.adtcaps.tsop.mapper.common;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;

import com.adtcaps.tsop.domain.common.OcoRoleMenuDto;
import com.adtcaps.tsop.portal.api.user.domain.RoleMenuTreeResultDto;
import com.adtcaps.tsop.portal.api.user.domain.UserRoleMenuAuthorityRequestDto;

/**
 * 
 * <ul>
 * <li>업무 그룹명 : tsop-backend-api</li>
 * <li>서브 업무명 : com.adtcaps.tsop.mapper.common</li>
 * <li>설  명 : OcoRoleMenuMapper.java</li>
 * <li>작성일 : 2020. 12. 24.</li>
 * <li>작성자 : jeonyb4</li>
 * </ul>
 */
@Mapper
public interface OcoRoleMenuMapper {
	/**
	 * 
	 * createOcoRoleMenu
	 *
	 * @param reqOcoRoleMenuDto
	 * @return int
	 */
	public int createOcoRoleMenu(OcoRoleMenuDto reqOcoRoleMenuDto);
	
	/**
	 * 
	 * listRoleMenuTree
	 *
	 * @param reqOcoRoleMenuDto
	 * @return List<RoleMenuTreeResultDto>
	 */
	public List<RoleMenuTreeResultDto> listRoleMenuTree(OcoRoleMenuDto reqOcoRoleMenuDto);
	
	/**
	 * 
	 * deleteOcoRoleMenu
	 *
	 * @param reqOcoRoleMenuDto
	 * @return int
	 */
	public int deleteOcoRoleMenu(OcoRoleMenuDto reqOcoRoleMenuDto);
	
	/**
	 * 
	 * readRoleMenuAuthority
	 * 
	 * @param userRoleMenuAuthorityRequestDto
	 * @return OcoRoleMenuDto
	 */
	public OcoRoleMenuDto readRoleMenuAuthority(UserRoleMenuAuthorityRequestDto userRoleMenuAuthorityRequestDto);
	
	/**
	 * 
	 * readRoleMenuAuthorityBuildingManager
	 * 
	 * @param userRoleMenuAuthorityRequestDto
	 * @return OcoRoleMenuDto
	 */
	public OcoRoleMenuDto readRoleMenuAuthorityBuildingManager(UserRoleMenuAuthorityRequestDto userRoleMenuAuthorityRequestDto);
	
}
