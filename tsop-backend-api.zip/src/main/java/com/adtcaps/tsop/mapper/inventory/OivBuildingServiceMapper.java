package com.adtcaps.tsop.mapper.inventory;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;

import com.adtcaps.tsop.domain.inventory.OivBuildingServiceDto;
import com.adtcaps.tsop.portal.api.building.domain.BuildingServiceDetailResultDto;
import com.adtcaps.tsop.portal.api.building.domain.BuildingServiceForComboResultDto;
import com.adtcaps.tsop.portal.api.building.domain.BuildingServiceHealthCheckResultDto;
import com.adtcaps.tsop.portal.api.building.domain.BuildingServiceUseYnResultDto;

/**
 * 
 * <ul>
 * <li>업무 그룹명 : tsop-backend-api</li>
 * <li>서브 업무명 : com.adtcaps.tsop.mapper.inventory</li>
 * <li>설  명 : OivBuildingServiceMapper.java</li>
 * <li>작성일 : 2020. 12. 17.</li>
 * <li>작성자 : jeonyb4</li>
 * </ul>
 */
@Mapper
public interface OivBuildingServiceMapper {
	/**
	 * 
	 * listBuildingServiceForComboForBatch
	 * 
	 * @param reqOivBuildingServiceDto
	 * @return List<BuildingServiceForComboResultDto>
	 */
	public List<BuildingServiceForComboResultDto> listBuildingServiceForComboForBatch(OivBuildingServiceDto reqOivBuildingServiceDto);
	
	/**
	 * 
	 * listBuildingServiceForCombo
	 *
	 * @param reqOivBuildingServiceDto
	 * @return List<BuildingServiceForComboResultDto>
	 */
	public List<BuildingServiceForComboResultDto> listBuildingServiceForCombo(OivBuildingServiceDto reqOivBuildingServiceDto);
	
	/**
	 * 
	 * listBuildingNotServiceForCombo
	 *
	 * @param reqOivBuildingServiceDto
	 * @return List<BuildingServiceForComboResultDto>
	 */
	public List<BuildingServiceForComboResultDto> listBuildingNotServiceForCombo(OivBuildingServiceDto reqOivBuildingServiceDto);
	
	/**
	 * 
	 * listBuildingServiceUseYn
	 *
	 * @param reqOivBuildingServiceDto
	 * @return List<BuildingServiceUseYnResultDto>
	 */
	public List<BuildingServiceUseYnResultDto> listBuildingServiceUseYn(OivBuildingServiceDto reqOivBuildingServiceDto);
	
	/**
	 * 
	 * readBuildingService
	 *
	 * @param reqOivBuildingServiceDto
	 * @return BuildingServiceDetailResultDto
	 */
	public BuildingServiceDetailResultDto readBuildingService(OivBuildingServiceDto reqOivBuildingServiceDto);
	
	/**
	 * 
	 * listBuildingServiceHealthCheck
	 *
	 * @param reqOivBuildingServiceDto
	 * @return List<BuildingServiceHealthCheckResultDto>
	 */
	public List<BuildingServiceHealthCheckResultDto> listBuildingServiceHealthCheck(OivBuildingServiceDto reqOivBuildingServiceDto);

}
