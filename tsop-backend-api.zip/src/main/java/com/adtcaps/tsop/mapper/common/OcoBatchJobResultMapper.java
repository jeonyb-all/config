package com.adtcaps.tsop.mapper.common;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;

import com.adtcaps.tsop.portal.api.batch.domain.BatchJobResultGridRequestDto;
import com.adtcaps.tsop.portal.api.batch.domain.BatchJobResultGridResultDto;

/**
 * 
 * <ul>
 * <li>업무 그룹명 : tsop-backend-api</li>
 * <li>서브 업무명 : com.adtcaps.tsop.mapper.common</li>
 * <li>설  명 : OcoBatchJobResultMapper.java</li>
 * <li>작성일 : 2020. 12. 8.</li>
 * <li>작성자 : jeonyb4</li>
 * </ul>
 */
@Mapper
public interface OcoBatchJobResultMapper {
	/**
	 * 
	 * listPageBatchJobResult
	 *
	 * @param batchJobResultGridRequestDto
	 * @return List<BatchJobResultGridResultDto>
	 */
	public List<BatchJobResultGridResultDto> listPageBatchJobResult(BatchJobResultGridRequestDto batchJobResultGridRequestDto);

}
