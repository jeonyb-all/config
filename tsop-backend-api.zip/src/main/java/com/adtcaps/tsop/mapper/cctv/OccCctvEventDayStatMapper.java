package com.adtcaps.tsop.mapper.cctv;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;

import com.adtcaps.tsop.domain.cctv.OccCctvEventDayStatDto;
import com.adtcaps.tsop.portal.api.cctv.domain.PortalDashboardCctvEventDayStatResultDto;
import com.adtcaps.tsop.portal.api.statistics.domain.CctvEventStatisticsResultDto;
import com.adtcaps.tsop.portal.api.statistics.domain.CctvStatisticsRequestDto;


/**
 * 
 * <ul>
 * <li>업무 그룹명 : tsop-backend-api</li>
 * <li>서브 업무명 : com.adtcaps.tsop.mapper.cctv</li>
 * <li>설  명 : OccCctvEventDayStatMapper.java</li>
 * <li>작성일 : 2021. 1. 19.</li>
 * <li>작성자 : song</li>
 * </ul>
 */

@Mapper
public interface OccCctvEventDayStatMapper {
	
	public List<CctvEventStatisticsResultDto> listCctvEventStatistics(CctvStatisticsRequestDto reqCctvStatistics);
	
	/***************************** Portal Main *****************************/
	
	/**
	 * 
	 * listPortalDashboardCctvEventDayStatChart
	 *
	 * @param reqOccCctvEventDayStatDto
	 * @return List<PortalDashboardCctvEventDayStatResultDto>
	 */
	public List<PortalDashboardCctvEventDayStatResultDto> listPortalDashboardCctvEventDayStatChart(OccCctvEventDayStatDto reqOccCctvEventDayStatDto);
}
