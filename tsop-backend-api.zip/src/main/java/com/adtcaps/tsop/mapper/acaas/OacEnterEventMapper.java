package com.adtcaps.tsop.mapper.acaas;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;

import com.adtcaps.tsop.dashboard.api.acaas.domain.EnterEventCurrentStatePieChartResultDto;
import com.adtcaps.tsop.domain.acaas.OacEnterEventDto;
import com.adtcaps.tsop.portal.api.search.domain.AcaasSearchRequestDto;
import com.adtcaps.tsop.portal.api.search.domain.AcaasTimeBarEventResultDto;
import com.adtcaps.tsop.portal.api.search.domain.AcaasTimeBarResultDto;
import com.adtcaps.tsop.portal.api.search.domain.AcaasVisitorHistoryResultDto;

/**
 * 
 * <ul>
 * <li>업무 그룹명 : tsop-backend-api</li>
 * <li>서브 업무명 : com.adtcaps.tsop.mapper.acaas</li>
 * <li>설  명 : OacEnterEventMapper.java</li>
 * <li>작성일 : 2020. 12. 4.</li>
 * <li>작성자 : jeonyb4</li>
 * </ul>
 */
@Mapper
public interface OacEnterEventMapper {
	/**
	 * 
	 * readEnterEventCurrentStatePieChart
	 *
	 * @param reqOacEnterEventDto
	 * @return EnterEventCurrentStatePieChartResultDto
	 */
	public EnterEventCurrentStatePieChartResultDto readEnterEventCurrentStatePieChart(OacEnterEventDto reqOacEnterEventDto);
	
	
	/**
	 * 
	 * listVisitorHistorySearch
	 * 
	 * @param reqAcaasSearch
	 * @return List<AcaasVisitorHistoryResultDto>
	 */
	public List<AcaasVisitorHistoryResultDto> listVisitorHistorySearch(AcaasSearchRequestDto reqAcaasSearch);
	
	
	/**
	 * 
	 * listGatewayTimeBarSearch
	 * 
	 * @param reqAcaasSearch
	 * @return List<AcaasTimeBarResultDto>
	 */
	public List<AcaasTimeBarResultDto> listGatewayTimeBarSearch(AcaasSearchRequestDto reqAcaasSearch);
	
	/**
	 * 
	 * listConsoleTimeBarSearch
	 * 
	 * @param reqAcaasSearch
	 * @return List<AcaasTimeBarResultDto>
	 */
	public List<AcaasTimeBarResultDto> listConsoleTimeBarSearch(AcaasSearchRequestDto reqAcaasSearch);
	
	/**
	 * 
	 * listGatewayTimeBarEventSearch
	 * 
	 * @param reqAcaasSearch
	 * @return List<AcaasTimeBarResultDto>
	 */
	public List<AcaasTimeBarEventResultDto> listGatewayTimeBarEventSearch(AcaasSearchRequestDto reqAcaasSearch);
	
	/**
	 * 
	 * listConsoleTimeBarEventSearch
	 * 
	 * @param reqAcaasSearch
	 * @return List<AcaasTimeBarResultDto>
	 */
	public List<AcaasTimeBarEventResultDto> listConsoleTimeBarEventSearch(AcaasSearchRequestDto reqAcaasSearch);
}
