package com.adtcaps.tsop.mapper.inventory;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;

import com.adtcaps.tsop.domain.inventory.OivAlarmExceptionRuleCategoryHistDto;
import com.adtcaps.tsop.domain.inventory.OivAlarmExceptionRuleDetailHistDto;
import com.adtcaps.tsop.portal.api.alarm.domain.AlarmExceptionAlarmCodeValueDto;
import com.adtcaps.tsop.portal.api.alarm.domain.AlarmExceptionDateDto;
import com.adtcaps.tsop.portal.api.alarm.domain.AlarmExceptionHhDto;
import com.adtcaps.tsop.portal.api.alarm.domain.AlarmExceptionItemDto;
import com.adtcaps.tsop.portal.api.alarm.domain.AlarmExceptionObjectDto;

/**
 * 
 * <ul>
 * <li>업무 그룹명 : tsop-backend-api</li>
 * <li>서브 업무명 : com.adtcaps.tsop.mapper.inventory</li>
 * <li>설  명 : OivAlarmExceptionRuleDetailHistMapper.java</li>
 * <li>작성일 : 2021. 11. 30.</li>
 * <li>작성자 : jeonyb4</li>
 * </ul>
 */
@Mapper
public interface OivAlarmExceptionRuleDetailHistMapper {
	/**
	 * 
	 * createAlarmExceptionRuleDetailHist
	 * 
	 * @param reqOivAlarmExceptionRuleDetailHistDto
	 * @return int
	 */
	public int createAlarmExceptionRuleDetailHist(OivAlarmExceptionRuleDetailHistDto reqOivAlarmExceptionRuleDetailHistDto);
	
	/**
	 * 
	 * createAfterAlarmExceptionRuleDetailHist
	 * 
	 * @param reqOivAlarmExceptionRuleDetailHistDto
	 * @return int
	 */
	public int createAfterAlarmExceptionRuleDetailHist(OivAlarmExceptionRuleDetailHistDto reqOivAlarmExceptionRuleDetailHistDto);
	
	/**
	 * 
	 * readAlarmExceptionRuleDetailHist
	 * 
	 * @param reqOivAlarmExceptionRuleCategoryHistDto
	 * @return AlarmExceptionItemDto
	 */
	public AlarmExceptionItemDto readAlarmExceptionRuleDetailHist(OivAlarmExceptionRuleCategoryHistDto reqOivAlarmExceptionRuleCategoryHistDto);
	
	/**
	 * 
	 * listAlarmExceptionRuleDetailHist3
	 * 
	 * @param reqOivAlarmExceptionRuleCategoryHistDto
	 * @return List<AlarmExceptionObjectDto>
	 */
	public List<AlarmExceptionObjectDto> listAlarmExceptionRuleDetailHist3(OivAlarmExceptionRuleCategoryHistDto reqOivAlarmExceptionRuleCategoryHistDto);
	
	/**
	 * 
	 * listAlarmExceptionRuleDetailHist4
	 * 
	 * @param reqOivAlarmExceptionRuleCategoryHistDto
	 * @return List<AlarmExceptionAlarmCodeValueDto>
	 */
	public List<AlarmExceptionAlarmCodeValueDto> listAlarmExceptionRuleDetailHist4(OivAlarmExceptionRuleCategoryHistDto reqOivAlarmExceptionRuleCategoryHistDto);
	
	/**
	 * 
	 * listFmAlarmExceptionRuleDetailHist4
	 * 
	 * @param reqOivAlarmExceptionRuleCategoryHistDto
	 * @return List<AlarmExceptionAlarmCodeValueDto>
	 */
	public List<AlarmExceptionAlarmCodeValueDto> listFmAlarmExceptionRuleDetailHist4(OivAlarmExceptionRuleCategoryHistDto reqOivAlarmExceptionRuleCategoryHistDto);
	
	/**
	 * 
	 * listAlarmExceptionRuleDetailHist2
	 * 
	 * @param reqOivAlarmExceptionRuleCategoryHistDto
	 * @return List<String>
	 */
	public List<String> listAlarmExceptionRuleDetailHist2(OivAlarmExceptionRuleCategoryHistDto reqOivAlarmExceptionRuleCategoryHistDto);
	
	/**
	 * 
	 * listAlarmExceptionRuleDetailHist6
	 * 
	 * @param reqOivAlarmExceptionRuleCategoryHistDto
	 * @return List<AlarmExceptionHhDto>
	 */
	public List<AlarmExceptionHhDto> listAlarmExceptionRuleDetailHist6(OivAlarmExceptionRuleCategoryHistDto reqOivAlarmExceptionRuleCategoryHistDto);
	
	/**
	 * 
	 * listAlarmExceptionRuleDetailHist7
	 * 
	 * @param reqOivAlarmExceptionRuleCategoryHistDto
	 * @return List<AlarmExceptionDateDto>
	 */
	public List<AlarmExceptionDateDto> listAlarmExceptionRuleDetailHist7(OivAlarmExceptionRuleCategoryHistDto reqOivAlarmExceptionRuleCategoryHistDto);

}
