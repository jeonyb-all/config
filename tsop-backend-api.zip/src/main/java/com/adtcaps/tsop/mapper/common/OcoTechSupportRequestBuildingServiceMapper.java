package com.adtcaps.tsop.mapper.common;

import org.apache.ibatis.annotations.Mapper;

import com.adtcaps.tsop.domain.common.OcoTechSupportRequestBuildingServiceDto;

/**
 * 
 * <ul>
 * <li>업무 그룹명 : tsop-backend-api</li>
 * <li>서브 업무명 : com.adtcaps.tsop.mapper.common</li>
 * <li>설  명 : OcoTechSupportRequestBuildingServiceMapper.java</li>
 * <li>작성일 : 2021. 1. 2.</li>
 * <li>작성자 : jeonyb4</li>
 * </ul>
 */
@Mapper
public interface OcoTechSupportRequestBuildingServiceMapper {
	/**
	 * 
	 * createOcoTechSupportRequestBuildingService
	 *
	 * @param reqOcoTechSupportRequestBuildingServiceDto
	 * @return int
	 */
	public int createOcoTechSupportRequestBuildingService(OcoTechSupportRequestBuildingServiceDto reqOcoTechSupportRequestBuildingServiceDto);
	
	/**
	 * 
	 * readOcoTechSupportRequestBuildingService
	 *
	 * @param reqOcoTechSupportRequestBuildingServiceDto
	 * @return OcoTechSupportRequestBuildingServiceDto
	 */
	public OcoTechSupportRequestBuildingServiceDto readOcoTechSupportRequestBuildingService(OcoTechSupportRequestBuildingServiceDto reqOcoTechSupportRequestBuildingServiceDto);

}
