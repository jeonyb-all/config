package com.adtcaps.tsop.mapper.mashup;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;

import com.adtcaps.tsop.domain.mashup.OmuFaultDto;
import com.adtcaps.tsop.portal.api.fault.domain.FaultDetailResultDto;
import com.adtcaps.tsop.portal.api.fault.domain.FaultGridRequestDto;
import com.adtcaps.tsop.portal.api.fault.domain.FaultGridResultDto;

/**
 * 
 * <ul>
 * <li>업무 그룹명 : tsop-backend-api</li>
 * <li>서브 업무명 : com.adtcaps.tsop.mapper.mashup</li>
 * <li>설  명 : OmuFaultMapper.java</li>
 * <li>작성일 : 2020. 12. 10.</li>
 * <li>작성자 : jeonyb4</li>
 * </ul>
 */
@Mapper
public interface OmuFaultMapper {
	/**
	 * 
	 * listPageFault
	 *
	 * @param faultGridRequestDto
	 * @return List<FaultGridResultDto>
	 */
	public List<FaultGridResultDto> listPageFault(FaultGridRequestDto faultGridRequestDto);
	
	/**
	 * 
	 * createOmuFault
	 *
	 * @param reqOmuFaultDto
	 * @return int
	 */
	public int createOmuFault(OmuFaultDto reqOmuFaultDto);
	
	/**
	 * 
	 * readOmuFault
	 *
	 * @param reqOmuFaultDto
	 * @return FaultDetailResultDto
	 */
	public FaultDetailResultDto readOmuFault(OmuFaultDto reqOmuFaultDto);
	
	/**
	 * 
	 * readOmuFaultAttachFile
	 *
	 * @param reqOmuFaultDto
	 * @return FaultDetailResultDto
	 */
	public FaultDetailResultDto readOmuFaultAttachFile(OmuFaultDto reqOmuFaultDto);
	
	/**
	 * 
	 * updateFaultAttachFileNum
	 *
	 * @param reqOmuFaultDto
	 * @return int
	 */
	public int updateFaultAttachFileNum(OmuFaultDto reqOmuFaultDto);
	
	/**
	 * 
	 * updateOmuFault
	 *
	 * @param reqOmuFaultDto
	 * @return int
	 */
	public int updateOmuFault(OmuFaultDto reqOmuFaultDto);
	
	/**
	 * 
	 * readOmuFaultDuplicationCheck
	 *
	 * @param reqOmuFaultDto
	 * @return FaultDetailResultDto
	 */
	public FaultDetailResultDto readOmuFaultDuplicationCheck(OmuFaultDto reqOmuFaultDto);
	
	/**
	 * 
	 * readFalutCountForAlarm
	 *
	 * @param reqOmuFaultDto
	 * @return int
	 */
	public int readFalutCountForAlarm(OmuFaultDto reqOmuFaultDto);
	
	
	/***************************** Dashboard *****************************/
	

}
