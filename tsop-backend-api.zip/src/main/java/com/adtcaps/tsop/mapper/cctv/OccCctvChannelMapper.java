package com.adtcaps.tsop.mapper.cctv;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;

import com.adtcaps.tsop.domain.cctv.OccCctvChannelDto;
import com.adtcaps.tsop.portal.api.object.domain.CcCctvChannelResultDto;

/**
 * 
 * <ul>
 * <li>업무 그룹명 : tsop-backend-api</li>
 * <li>서브 업무명 : com.adtcaps.tsop.mapper.cctv</li>
 * <li>설  명 : OccCctvChannelMapper.java</li>
 * <li>작성일 : 2021. 1. 12.</li>
 * <li>작성자 : jeonyb4</li>
 * </ul>
 */
@Mapper
public interface OccCctvChannelMapper {
	/**
	 * 
	 * listCcObjectCctvChannel
	 *
	 * @param reqOccCctvChannelDto
	 * @return List<CcCctvChannelResultDto>
	 */
	public List<CcCctvChannelResultDto> listCcObjectCctvChannel(OccCctvChannelDto reqOccCctvChannelDto);
	
	
	/***************************** Dashboard *****************************/

}
