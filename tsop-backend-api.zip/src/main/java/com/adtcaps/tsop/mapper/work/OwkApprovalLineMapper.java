package com.adtcaps.tsop.mapper.work;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;

import com.adtcaps.tsop.helper.domain.BasePageDto;
import com.adtcaps.tsop.portal.api.report.domain.ApprovalLineComboResultDto;

/**
 * 
 * <ul>
 * <li>업무 그룹명 : tsop-backend-api</li>
 * <li>서브 업무명 : com.adtcaps.tsop.mapper.work</li>
 * <li>설  명 : OwkApprovalLineMapper.java</li>
 * <li>작성일 : 2021. 12. 6.</li>
 * <li>작성자 : jeonyb4</li>
 * </ul>
 */
@Mapper
public interface OwkApprovalLineMapper {
	/**
	 * 
	 * listApprovalLineForCombo
	 * 
	 * @param reqBasePageDto
	 * @return List<ApprovalLineComboResultDto>
	 */
	public List<ApprovalLineComboResultDto> listApprovalLineForCombo(BasePageDto reqBasePageDto);

}
