package com.adtcaps.tsop.mapper.robot;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;

import com.adtcaps.tsop.dashboard.api.robot.domain.RobotBatteryEventQueryResultDto;

/**
 * 
 * <ul>
 * <li>업무 그룹명 : tsop-backend-api</li>
 * <li>서브 업무명 : com.adtcaps.tsop.mapper.robot</li>
 * <li>설  명 : OrbRobotBatteryEventMapper.java</li>
 * <li>작성일 : 2020. 12. 4.</li>
 * <li>작성자 : jeonyb4</li>
 * </ul>
 */
@Mapper
public interface OrbRobotBatteryEventMapper {
	/**
	 * 
	 * readCountRobot
	 *
	 * @return int
	 */
	public int readCountRobot();
	
	/**
	 * 
	 * listRobotBatteryEventChart
	 *
	 * @return List<RobotBatteryEventQueryResultDto>
	 */
	public List<RobotBatteryEventQueryResultDto> listRobotBatteryEventChart();

}
