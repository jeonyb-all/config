package com.adtcaps.tsop.mapper.common;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;

import com.adtcaps.tsop.domain.common.OcoUserHistDto;
import com.adtcaps.tsop.portal.api.user.domain.UserHistGridRequestDto;
import com.adtcaps.tsop.portal.api.user.domain.UserHistGridResultDto;

/**
 * 
 * <ul>
 * <li>업무 그룹명 : tsop-backend-api</li>
 * <li>서브 업무명 : com.adtcaps.tsop.mapper.common</li>
 * <li>설  명 : OcoUserHistMapper.java</li>
 * <li>작성일 : 2021. 12. 2.</li>
 * <li>작성자 : jeonyb4</li>
 * </ul>
 */
@Mapper
public interface OcoUserHistMapper {
	/**
	 * 
	 * createOcoUserHist
	 * 
	 * @param reqOcoUserHistDto
	 * @return int
	 */
	public int createOcoUserHist(OcoUserHistDto reqOcoUserHistDto);
	
	/**
	 * 
	 * listPageUserHist
	 * 
	 * @param userHistGridRequestDto
	 * @return UserHistGridResultDto
	 */
	public List<UserHistGridResultDto> listPageUserHist(UserHistGridRequestDto userHistGridRequestDto);

}
