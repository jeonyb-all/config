package com.adtcaps.tsop.mapper.fm;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;

import com.adtcaps.tsop.dashboard.api.fm.domain.BuildingInTemprCellRequestDto;
import com.adtcaps.tsop.dashboard.api.fm.domain.BuildingInTemprResultDto;
import com.adtcaps.tsop.dashboard.api.fm.domain.InTemprCellHourValueResultDto;
import com.adtcaps.tsop.dashboard.api.fm.domain.InTemprFloorCellResultDto;
import com.adtcaps.tsop.domain.fm.OfmFacilityObjectDto;

/**
 * 
 * <ul>
 * <li>업무 그룹명 : tsop-backend-api</li>
 * <li>서브 업무명 : com.adtcaps.tsop.mapper.fm</li>
 * <li>설  명 : OfmBuildingEnvironmentStatMapper.java</li>
 * <li>작성일 : 2021. 10. 28.</li>
 * <li>작성자 : jeonyb4</li>
 * </ul>
 */
@Mapper
public interface OfmBuildingEnvironmentStatMapper {
	/**
	 * 
	 * listBuildingInTemprLineChart
	 * 
	 * @param reqOfmFacilityObjectDto
	 * @return List<BuildingInTemprResultDto>
	 */
	public List<BuildingInTemprResultDto> listBuildingInTemprLineChart(OfmFacilityObjectDto reqOfmFacilityObjectDto);
	
	/**
	 * 
	 * readOverTemprCellCount
	 * 
	 * @param buildingInTemprCellRequestDto
	 * @return int
	 */
	public int readOverTemprCellCount(BuildingInTemprCellRequestDto buildingInTemprCellRequestDto);
	
	/**
	 * 
	 * listBuildingInTemprCell
	 * 
	 * @param buildingInTemprCellRequestDto
	 * @return List<InTemprFloorCellResultDto>
	 */
	public List<InTemprFloorCellResultDto> listBuildingInTemprCell(BuildingInTemprCellRequestDto buildingInTemprCellRequestDto);
	
	/**
	 * 
	 * listBuildingInTemprCellHourValue
	 * 
	 * @param buildingInTemprCellRequestDto
	 * @return List<InTemprCellHourValueResultDto>
	 */
	public List<InTemprCellHourValueResultDto> listBuildingInTemprCellHourValue(BuildingInTemprCellRequestDto buildingInTemprCellRequestDto);
	
}
