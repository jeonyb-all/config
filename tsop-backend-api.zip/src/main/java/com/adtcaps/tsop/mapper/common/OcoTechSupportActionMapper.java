package com.adtcaps.tsop.mapper.common;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;

import com.adtcaps.tsop.domain.common.OcoTechSupportActionDto;
import com.adtcaps.tsop.portal.api.support.domain.TechSupportActionGridResultDto;

/**
 * 
 * <ul>
 * <li>업무 그룹명 : tsop-backend-api</li>
 * <li>서브 업무명 : com.adtcaps.tsop.mapper.common</li>
 * <li>설  명 : OcoTechSupportActionMapper.java</li>
 * <li>작성일 : 2021. 1. 4.</li>
 * <li>작성자 : jeonyb4</li>
 * </ul>
 */
@Mapper
public interface OcoTechSupportActionMapper {
	/**
	 * 
	 * listTechSupportAction
	 *
	 * @param reqOcoTechSupportActionDto
	 * @return List<TechSupportActionGridResultDto>
	 */
	public List<TechSupportActionGridResultDto> listTechSupportAction(OcoTechSupportActionDto reqOcoTechSupportActionDto);
	
	/**
	 * 
	 * createOcoTechSupportAction
	 *
	 * @param reqOcoTechSupportActionDto
	 * @return int
	 */
	public int createOcoTechSupportAction(OcoTechSupportActionDto reqOcoTechSupportActionDto);
	
	/**
	 * 
	 * updateTechSupportActionAttachFileNum
	 *
	 * @param reqOcoTechSupportActionDto
	 * @return int
	 */
	public int updateTechSupportActionAttachFileNum(OcoTechSupportActionDto reqOcoTechSupportActionDto);
	
	/**
	 * 
	 * deleteOcoTechSupportAction
	 *
	 * @param reqOcoTechSupportActionDto
	 * @return int
	 */
	public int deleteOcoTechSupportAction(OcoTechSupportActionDto reqOcoTechSupportActionDto);

}
