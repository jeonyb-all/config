package com.adtcaps.tsop.mapper.common;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;

import com.adtcaps.tsop.portal.api.address.domain.CtPvcNameForComboResultDto;
import com.adtcaps.tsop.portal.api.address.domain.StreetnameAddressGridRequestDto;
import com.adtcaps.tsop.portal.api.address.domain.StreetnameAddressGridResultDto;

/**
 * 
 * <ul>
 * <li>업무 그룹명 : tsop-backend-api</li>
 * <li>서브 업무명 : com.adtcaps.tsop.mapper.common</li>
 * <li>설  명 : OcoStreetnameAddressMapper.java</li>
 * <li>작성일 : 2021. 1. 14.</li>
 * <li>작성자 : jeonyb4</li>
 * </ul>
 */
@Mapper
public interface OcoStreetnameAddressMapper {
	/**
	 * 
	 * listCtPvcNameForCombo
	 *
	 * @return List<CtPvcNameForComboResultDto>
	 */
	public List<CtPvcNameForComboResultDto> listCtPvcNameForCombo();
	
	/**
	 * 
	 * listCtGunGuNameForCombo
	 *
	 * @param ctPvcNameForComboResultDto
	 * @return List<CtPvcNameForComboResultDto>
	 */
	public List<CtPvcNameForComboResultDto> listCtGunGuNameForCombo(CtPvcNameForComboResultDto ctPvcNameForComboResultDto);
	
	/**
	 * 
	 * listPageStreetnameAddress
	 *
	 * @param streetnameAddressGridRequestDto
	 * @return List<StreetnameAddressGridResultDto>
	 */
	public List<StreetnameAddressGridResultDto> listPageStreetnameAddress(StreetnameAddressGridRequestDto streetnameAddressGridRequestDto);

}
