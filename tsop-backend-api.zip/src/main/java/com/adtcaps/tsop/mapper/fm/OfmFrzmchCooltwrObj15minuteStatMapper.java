package com.adtcaps.tsop.mapper.fm;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;

import com.adtcaps.tsop.dashboard.api.fm.domain.ChilledwaterTemprChartRequestDto;
import com.adtcaps.tsop.dashboard.api.fm.domain.FreezerSystemDetailResultDto;
import com.adtcaps.tsop.domain.fm.OfmFacilityObjectDto;

/**
 * 
 * <ul>
 * <li>업무 그룹명 : tsop-backend-api</li>
 * <li>서브 업무명 : com.adtcaps.tsop.mapper.fm</li>
 * <li>설  명 : OfmFrzmchCooltwrObj15minuteStatMapper.java</li>
 * <li>작성일 : 2021. 10. 26.</li>
 * <li>작성자 : jeonyb4</li>
 * </ul>
 */
@Mapper
public interface OfmFrzmchCooltwrObj15minuteStatMapper {
	/**
	 * 
	 * listFreezerSystemOperateTime
	 * 
	 * @param reqOfmFacilityObjectDto
	 * @return List<FreezerSystemDetailResultDto>
	 */
	public List<FreezerSystemDetailResultDto> listFreezerSystemOperateTime(OfmFacilityObjectDto reqOfmFacilityObjectDto);
	
	/**
	 * 
	 * listChilledwaterTemprGapLineChart
	 * 
	 * @param chilledwaterTemprChartRequestDto
	 * @return List<Double>
	 */
	public List<Double> listChilledwaterTemprGapLineChart(ChilledwaterTemprChartRequestDto chilledwaterTemprChartRequestDto);

}
