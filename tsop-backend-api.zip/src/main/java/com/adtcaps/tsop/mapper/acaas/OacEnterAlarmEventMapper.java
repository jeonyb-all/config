package com.adtcaps.tsop.mapper.acaas;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;

import com.adtcaps.tsop.portal.api.search.domain.AcaasAlarmEventResultDto;
import com.adtcaps.tsop.portal.api.search.domain.AcaasSearchRequestDto;

/**
 * 
 * <ul>
 * <li>업무 그룹명 : tsop-backend-api</li>
 * <li>서브 업무명 : com.adtcaps.tsop.mapper.acaas</li>
 * <li>설  명 : OacEnterAlarmEventMapper.java</li>
 * <li>작성일 : 2021. 01. 14.</li>
 * <li>작성자 : song</li>
 * </ul>
 */
@Mapper
public interface OacEnterAlarmEventMapper {

	/**
	 * 
	 * listAlarmEventSearch
	 * 
	 * @param reqAcaasSearch
	 * @return List<AcaasAlarmEventResultDto>
	 */
	public List<AcaasAlarmEventResultDto> listAlarmEventSearch(AcaasSearchRequestDto reqAcaasSearch);
}
