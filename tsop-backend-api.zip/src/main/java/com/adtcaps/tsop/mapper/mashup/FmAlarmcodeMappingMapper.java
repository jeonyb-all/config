package com.adtcaps.tsop.mapper.mashup;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;

import com.adtcaps.tsop.domain.mashup.FmAlarmMappingDto;
import com.adtcaps.tsop.domain.mashup.OmuAlarmcodeMappingDto;

/**
 * 
 * <ul>
 * <li>업무 그룹명 : tsop-backend-api</li>
 * <li>서브 업무명 : com.adtcaps.tsop.mapper.mashup</li>
 * <li>설  명 : FmAlarmcodeMappingMapper.java</li>
 * <li>작성일 : 2021. 2. 19.</li>
 * <li>작성자 : song</li>
 * </ul>
 * 
 */
@Mapper
public interface FmAlarmcodeMappingMapper {

	public List<FmAlarmMappingDto> listFmAlarmCdCombo(OmuAlarmcodeMappingDto reqOmuAlarmcodeMappingDto);
	public List<FmAlarmMappingDto> listFmAlarmCdPopupCombo(OmuAlarmcodeMappingDto reqOmuAlarmcodeMappingDto);
	public List<FmAlarmMappingDto> listFmAlarmValCombo(OmuAlarmcodeMappingDto reqOmuAlarmcodeMappingDto);
	public int updateFmAlarmcodeMapping(OmuAlarmcodeMappingDto reqOmuAlarmcodeMappingDto);
	public int deleteFmAlarmcodeMapping(OmuAlarmcodeMappingDto reqOmuAlarmcodeMappingDto);

	/***************************** alarmCodeMapping (FM) *****************************/

}
