package com.adtcaps.tsop.mapper.common;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;

import com.adtcaps.tsop.domain.common.OcoBulletinboardBuildingDto;
import com.adtcaps.tsop.domain.common.OcoBulletinboardDto;
import com.adtcaps.tsop.portal.api.board.domain.BulletinboardBuildingResultDto;

/**
 * 
 * <ul>
 * <li>업무 그룹명 : tsop-backend-api</li>
 * <li>서브 업무명 : com.adtcaps.tsop.mapper.common</li>
 * <li>설  명 : OcoBulletinboardBuildingMapper.java</li>
 * <li>작성일 : 2020. 12. 17.</li>
 * <li>작성자 : jeonyb4</li>
 * </ul>
 */
@Mapper
public interface OcoBulletinboardBuildingMapper {
	/**
	 * 
	 * createOcoBulletinboardBuilding
	 *
	 * @param reqOcoBulletinboardBuildingDto
	 * @return int
	 */
	public int createOcoBulletinboardBuilding(OcoBulletinboardBuildingDto reqOcoBulletinboardBuildingDto);
	
	/**
	 * 
	 * listBulletinboardBuilding
	 *
	 * @param reqOcoBulletinboardDto
	 * @return List<BulletinboardBuildingResultDto>
	 */
	public List<BulletinboardBuildingResultDto> listBulletinboardBuilding(OcoBulletinboardDto reqOcoBulletinboardDto);
	
	/**
	 * 
	 * deleteOcoBulletinboardBuilding
	 *
	 * @param reqOcoBulletinboardDto
	 * @return int
	 */
	public int deleteOcoBulletinboardBuilding(OcoBulletinboardDto reqOcoBulletinboardDto);

}
