package com.adtcaps.tsop.mapper.inventory;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;

import com.adtcaps.tsop.domain.inventory.OivServiceConnectionApiListDto;
import com.adtcaps.tsop.portal.api.service.domain.ServiceConnectionApiListResultDto;

/**
 * 
 * <ul>
 * <li>업무 그룹명 : tsop-backend-api</li>
 * <li>서브 업무명 : com.adtcaps.tsop.mapper.inventory</li>
 * <li>설  명 : OivServiceConnectionApiListMapper.java</li>
 * <li>작성일 : 2021. 1. 23.</li>
 * <li>작성자 : jeonyb4</li>
 * </ul>
 */
@Mapper
public interface OivServiceConnectionApiListMapper {
	/**
	 * 
	 * listServiceConnectionApi
	 *
	 * @param reqOivServiceConnectionApiListDto
	 * @return List<ServiceConnectionApiListResultDto>
	 */
	public List<ServiceConnectionApiListResultDto> listServiceConnectionApi(OivServiceConnectionApiListDto reqOivServiceConnectionApiListDto);

}
