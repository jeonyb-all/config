package com.adtcaps.tsop.mapper.common;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;

import com.adtcaps.tsop.domain.common.OcoKakaoAlimTalkDto;
import com.adtcaps.tsop.portal.api.alimTalk.domain.AlimTalkGridRequestDto;
import com.adtcaps.tsop.portal.api.alimTalk.domain.AlimTalkGridResultDto;
import com.adtcaps.tsop.portal.api.statistics.domain.VocRecvHistoryDto;

/**
 * <ul>
 * <li>업무 그룹명 : tsop-backend-api</li>
 * <li>서브 업무명 : com.adtcaps.tsop.mapper.common</li>
 * <li>설  명 : OcoKakaoAlimTalkMapper.java</li>
 * <li>작성일 : 2021. 12. 7.</li>
 * <li>작성자 : vader</li>
 * </ul>
 */
@Mapper
public interface OcoKakaoAlimTalkMapper {
	/**
	 * createOcoKakaoAlimTalk
	 * @param ocoKakaoAlimTalkDto
	 * @return int
	 */
	public int createOcoKakaoAlimTalk(OcoKakaoAlimTalkDto ocoKakaoAlimTalkDto);

	/**
	 * listPageKakaoAlimTalk
	 * @param alimTalkGridRequestDto
	 * @return List<AlimTalkGridResultDto>
	 */
	public List<AlimTalkGridResultDto> listPageKakaoAlimTalk(AlimTalkGridRequestDto alimTalkGridRequestDto);

	/**
	 * readKakaoAlimTalk
	 * @param ocoKakaoAlimTalkDto
	 * @return OcoKakaoAlimTalkDto
	 */
	public OcoKakaoAlimTalkDto readKakaoAlimTalk(OcoKakaoAlimTalkDto ocoKakaoAlimTalkDto);

	/**
	 * checkAlimTalk
	 * @param ocoKakaoAlimTalkDto
	 * @return int
	 */
	public int checkAlimTalk(OcoKakaoAlimTalkDto ocoKakaoAlimTalkDto);

	/**
	 * updateOcoKakaoAlimTalk
	 * @param ocoKakaoAlimTalkDto
	 * @return int
	 */
	public int updateOcoKakaoAlimTalk(OcoKakaoAlimTalkDto ocoKakaoAlimTalkDto);

	/**
	 * deleteKakaoAlimTalk
	 * @param tmpltCode
	 * @return int
	 */
	public int deleteKakaoAlimTalk(OcoKakaoAlimTalkDto ocoKakaoAlimTalkDto);

	public List<AlimTalkGridResultDto> alimTalkExcel(AlimTalkGridResultDto alimTalkGridResultDto);
}
