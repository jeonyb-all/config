package com.adtcaps.tsop.mapper.mashup;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;

import com.adtcaps.tsop.domain.mashup.OmuAlarmcodeMappingDto;
import com.adtcaps.tsop.portal.api.alarm.domain.AlarmcodeForComboResultDto;
import com.adtcaps.tsop.portal.api.alarm.domain.AlarmcodeMappingDetailResultDto;
import com.adtcaps.tsop.portal.api.alarm.domain.AlarmcodeMappingForShortGridResultDto;
import com.adtcaps.tsop.portal.api.alarm.domain.AlarmcodeMappingGridRequestDto;
import com.adtcaps.tsop.portal.api.alarm.domain.AlarmcodeMappingGridResultDto;

/**
 * 
 * <ul>
 * <li>업무 그룹명 : tsop-backend-api</li>
 * <li>서브 업무명 : com.adtcaps.tsop.mapper.mashup</li>
 * <li>설  명 : OmuAlarmcodeMappingMapper.java</li>
 * <li>작성일 : 2020. 12. 28.</li>
 * <li>작성자 : jeonyb4</li>
 * </ul>
 */
@Mapper
public interface OmuAlarmcodeMappingMapper {
	/**
	 * 
	 * listAlarmcodeForCombo
	 * 
	 * @param reqOmuAlarmcodeMappingDto
	 * @return List<AlarmcodeForComboResultDto>
	 */
	public List<AlarmcodeForComboResultDto> listAlarmcodeForCombo(OmuAlarmcodeMappingDto reqOmuAlarmcodeMappingDto);
	
	/**
	 * 
	 * listAlarmcodeMappingForShortGrid
	 * 
	 * @param alarmcodeMappingGridRequestDto
	 * @return List<AlarmcodeMappingForShortGridResultDto>
	 */
	public List<AlarmcodeMappingForShortGridResultDto> listAlarmcodeMappingForShortGrid(AlarmcodeMappingGridRequestDto alarmcodeMappingGridRequestDto);
	
	/**
	 * 
	 * listPageAlarmcodeMapping
	 *
	 * @param alarmcodeMappingGridRequestDto
	 * @return List<AlarmcodeMappingGridResultDto>
	 */
	public List<AlarmcodeMappingGridResultDto> listPageAlarmcodeMapping(AlarmcodeMappingGridRequestDto alarmcodeMappingGridRequestDto);
	
	/**
	 * 
	 * createOmuAlarmcodeMapping
	 *
	 * @param reqOmuAlarmcodeMappingDto
	 * @return int
	 */
	public int createOmuAlarmcodeMapping(OmuAlarmcodeMappingDto reqOmuAlarmcodeMappingDto);
	
	/**
	 * 
	 * readOmuAlarmcodeMapping
	 *
	 * @param reqOmuAlarmcodeMappingDto
	 * @return AlarmcodeMappingDetailResultDto
	 */
	public AlarmcodeMappingDetailResultDto readOmuAlarmcodeMapping(OmuAlarmcodeMappingDto reqOmuAlarmcodeMappingDto);
	
	/**
	 * 
	 * updateOmuAlarmcodeMapping
	 *
	 * @param reqOmuAlarmcodeMappingDto
	 * @return int
	 */
	public int updateOmuAlarmcodeMapping(OmuAlarmcodeMappingDto reqOmuAlarmcodeMappingDto);
	
	/**
	 * 
	 * deleteOmuAlarmcodeMapping
	 *
	 * @param reqOmuAlarmcodeMappingDto
	 * @return int
	 */
	public int deleteOmuAlarmcodeMapping(OmuAlarmcodeMappingDto reqOmuAlarmcodeMappingDto);
	
	/**
	 * 
	 * readAlarmcodeInfoCheck
	 * 
	 * @param reqOmuAlarmcodeMappingDto
	 * @return OmuAlarmcodeMappingDto
	 */
	public OmuAlarmcodeMappingDto readAlarmcodeInfoCheck(OmuAlarmcodeMappingDto reqOmuAlarmcodeMappingDto);
	
	
	/***************************** Dashboard *****************************/
	
}
