package com.adtcaps.tsop.mapper.esop;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;

import com.adtcaps.tsop.portal.api.esop.domain.ProcessResultGridResultDto;
import com.adtcaps.tsop.portal.api.esop.domain.ProcessResultRequestDto;

@Mapper
public interface ProcessResultMapper {
	/**
	 * listPageProcessResult
	 * @param processResultRequestDto
	 * @return List<ProcessResultGridResultDto>
	 */
	public List<ProcessResultGridResultDto> listPageProcessResult(ProcessResultRequestDto processResultRequestDto);

	public List<ProcessResultGridResultDto> listProcessResultStatExcel(ProcessResultRequestDto processResultRequestDto);
}
