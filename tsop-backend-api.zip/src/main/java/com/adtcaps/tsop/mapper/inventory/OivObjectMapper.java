package com.adtcaps.tsop.mapper.inventory;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.session.ResultHandler;

import com.adtcaps.tsop.domain.inventory.OivObjectDto;
import com.adtcaps.tsop.portal.api.object.domain.AcObjectGridResultDto;
import com.adtcaps.tsop.portal.api.object.domain.CcObjectGridResultDto;
import com.adtcaps.tsop.portal.api.object.domain.ElObjectGridResultDto;
import com.adtcaps.tsop.portal.api.object.domain.ObjectCountResultDto;
import com.adtcaps.tsop.portal.api.object.domain.ObjectForShortGridResultDto;
import com.adtcaps.tsop.portal.api.object.domain.ObjectGridRequestDto;
import com.adtcaps.tsop.portal.api.object.domain.PaObjectGridResultDto;

/**
 * 
 * <ul>
 * <li>업무 그룹명 : tsop-backend-api</li>
 * <li>서브 업무명 : com.adtcaps.tsop.mapper.inventory</li>
 * <li>설  명 : OivObjectMapper.java</li>
 * <li>작성일 : 2020. 12. 21.</li>
 * <li>작성자 : jeonyb4</li>
 * </ul>
 */
@Mapper
public interface OivObjectMapper {
	/**
	 * 
	 * listPageObjectForShortGrid
	 *
	 * @param objectGridRequestDto
	 * @return List<ObjectForShortGridResultDto>
	 */
	public List<ObjectForShortGridResultDto> listPageObjectForShortGrid(ObjectGridRequestDto objectGridRequestDto);
	
	/**
	 * 
	 * listObjectForShortGrid
	 * 
	 * @param objectGridRequestDto
	 * @return List<ObjectForShortGridResultDto>
	 */
	public List<ObjectForShortGridResultDto> listObjectForShortGrid(ObjectGridRequestDto objectGridRequestDto);
	
	/**
	 * 
	 * listObjectCount
	 *
	 * @param objectGridRequestDto
	 * @return List<ObjectCountResultDto>
	 */
	public List<ObjectCountResultDto> listObjectCount(ObjectGridRequestDto objectGridRequestDto);
	
	/**
	 * 
	 * listPageAcObject
	 *
	 * @param objectGridRequestDto
	 * @return List<AcObjectGridResultDto>
	 */
	public List<AcObjectGridResultDto> listPageAcObject(ObjectGridRequestDto objectGridRequestDto);
	
	/**
	 * 
	 * listExcelAcObject
	 *
	 * @param objectGridRequestDto
	 * @param resultHandler void
	 */
	public void listExcelAcObject(ObjectGridRequestDto objectGridRequestDto, ResultHandler<AcObjectGridResultDto> resultHandler);
	
	/**
	 * 
	 * listPageCcObject
	 *
	 * @param objectGridRequestDto
	 * @return List<CcObjectGridResultDto>
	 */
	public List<CcObjectGridResultDto> listPageCcObject(ObjectGridRequestDto objectGridRequestDto);
	
	/**
	 * 
	 * listPagePaObject
	 *
	 * @param objectGridRequestDto
	 * @return List<PaObjectGridResultDto>
	 */
	public List<PaObjectGridResultDto> listPagePaObject(ObjectGridRequestDto objectGridRequestDto);
	
	/**
	 * 
	 * listPageElObject
	 *
	 * @param objectGridRequestDto
	 * @return List<ElObjectGridResultDto>
	 */
	public List<ElObjectGridResultDto> listPageElObject(ObjectGridRequestDto objectGridRequestDto);
	
	/**
	 * 
	 * readObjectInfoCheck
	 * 
	 * @param reqOivObjectDto
	 * @return OivObjectDto
	 */
	public OivObjectDto readObjectInfoCheck(OivObjectDto reqOivObjectDto);
	
	/***************************** Dashboard *****************************/
	
	/**
	 * List<String>
	 * @param bldId
	 * @return
	 */
	public List<String> listFloorInfo(String bldId);
}
