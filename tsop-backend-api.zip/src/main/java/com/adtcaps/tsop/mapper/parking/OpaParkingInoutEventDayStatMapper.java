package com.adtcaps.tsop.mapper.parking;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;

import com.adtcaps.tsop.domain.parking.OpaParkingInoutEventDayStatDto;
import com.adtcaps.tsop.helper.domain.BasePageDto;
import com.adtcaps.tsop.portal.api.parking.domain.PortalDashboardParkingEventDayStatResultDto;
import com.adtcaps.tsop.portal.api.report.domain.WeekReportMakeRequestDto;
import com.adtcaps.tsop.portal.api.report.domain.WeekReportParkingChartResultDto;
import com.adtcaps.tsop.portal.api.report.domain.WeekReportServiceDto;
import com.adtcaps.tsop.portal.api.statistics.domain.ParkingInOutStatisticsResultDto;

/**
 * 
 * <ul>
 * <li>업무 그룹명 : tsop-backend-api</li>
 * <li>서브 업무명 : com.adtcaps.tsop.mapper.parking</li>
 * <li>설  명 : OpaParkingInoutEventDayStatMapper.java</li>
 * <li>작성일 : 2021. 1. 17.</li>
 * <li>작성자 : song</li>
 * </ul>
 */

@Mapper
public interface OpaParkingInoutEventDayStatMapper {
	
	public List<ParkingInOutStatisticsResultDto> listParkingInOutStatistics(BasePageDto reqParkingStatistics);
	
	/***************************** Portal Main *****************************/
	
	/**
	 * 
	 * listPortalDashboardParkingEventDayStatChart
	 *
	 * @param reqOpaParkingInoutEventDayStatDto
	 * @return List<PortalDashboardParkingEventDayStatResultDto>
	 */
	public List<PortalDashboardParkingEventDayStatResultDto> listPortalDashboardParkingEventDayStatChart(OpaParkingInoutEventDayStatDto reqOpaParkingInoutEventDayStatDto);
	
	/***************************** Week Report *****************************/
	
	/**
	 * 
	 * readReportServiceSummaryParking
	 * 
	 * @param weekReportMakeRequestDto
	 * @return WeekReportServiceDto
	 */
	public WeekReportServiceDto readReportServiceSummaryParking(WeekReportMakeRequestDto weekReportMakeRequestDto);
	
	/**
	 * 
	 * listWeekReportServiceParkingChart
	 * 
	 * @param weekReportMakeRequestDto
	 * @return List<WeekReportParkingChartResultDto>
	 */
	public List<WeekReportParkingChartResultDto> listWeekReportServiceParkingChart(WeekReportMakeRequestDto weekReportMakeRequestDto);
	
	
}
