package com.adtcaps.tsop.mapper.common;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;

import com.adtcaps.tsop.domain.common.OcoAlarmNoticeConditionDto;
import com.adtcaps.tsop.portal.api.alarm.domain.AlarmNoticeConditionDetailResultDto;
import com.adtcaps.tsop.portal.api.alarm.domain.AlarmNoticeConditionGridRequestDto;
import com.adtcaps.tsop.portal.api.alarm.domain.AlarmNoticeConditionGridResultDto;

/**
 * 
 * <ul>
 * <li>업무 그룹명 : tsop-backend-api</li>
 * <li>서브 업무명 : com.adtcaps.tsop.mapper.common</li>
 * <li>설  명 : OcoAlarmNoticeConditionMapper.java</li>
 * <li>작성일 : 2020. 12. 14.</li>
 * <li>작성자 : jeonyb4</li>
 * </ul>
 */
@Mapper
public interface OcoAlarmNoticeConditionMapper {
	
	/**
	 * 
	 * listPageAlarmNoticeCondition
	 *
	 * @param alarmNoticeConditionGridRequestDto
	 * @return List<AlarmNoticeConditionGridResultDto>
	 */
	public List<AlarmNoticeConditionGridResultDto> listPageAlarmNoticeCondition(AlarmNoticeConditionGridRequestDto alarmNoticeConditionGridRequestDto);
	
	/**
	 * 
	 * readAlarmNoticeDuplicationCheck
	 *
	 * @param reqOcoAlarmNoticeConditionDto
	 * @return OcoAlarmNoticeConditionDto
	 */
	public OcoAlarmNoticeConditionDto readAlarmNoticeDuplicationCheck(OcoAlarmNoticeConditionDto reqOcoAlarmNoticeConditionDto);
	
	/**
	 * 
	 * createOcoAlarmNoticeCondition
	 *
	 * @param reqOcoAlarmNoticeConditionDto
	 * @return int
	 */
	public int createOcoAlarmNoticeCondition(OcoAlarmNoticeConditionDto reqOcoAlarmNoticeConditionDto);
	
	/**
	 * 
	 * readAlarmNoticeCondition
	 *
	 * @param reqOcoAlarmNoticeConditionDto
	 * @return AlarmNoticeConditionDetailResultDto
	 */
	public AlarmNoticeConditionDetailResultDto readAlarmNoticeCondition(OcoAlarmNoticeConditionDto reqOcoAlarmNoticeConditionDto);
	
	/**
	 * 
	 * updateOcoAlarmNoticeCondition
	 *
	 * @param reqOcoAlarmNoticeConditionDto
	 * @return int
	 */
	public int updateOcoAlarmNoticeCondition(OcoAlarmNoticeConditionDto reqOcoAlarmNoticeConditionDto);
	
	/**
	 * 
	 * deleteOcoAlarmNoticeCondition
	 *
	 * @param reqOcoAlarmNoticeConditionDto
	 * @return int
	 */
	public int deleteOcoAlarmNoticeCondition(OcoAlarmNoticeConditionDto reqOcoAlarmNoticeConditionDto);
	
	/**
	 * 
	 * readAlarmNoticeCountForReceiveGroup
	 *
	 * @param reqOcoAlarmNoticeConditionDto
	 * @return int
	 */
	public int readAlarmNoticeCountForReceiveGroup(OcoAlarmNoticeConditionDto reqOcoAlarmNoticeConditionDto);
	
	/**
	 * 
	 * updateAlarmNoticeConditionReuse
	 *
	 * @param reqOcoAlarmNoticeConditionDto
	 * @return int
	 */
	public int updateAlarmNoticeConditionReuse(OcoAlarmNoticeConditionDto reqOcoAlarmNoticeConditionDto);
	
	
	/***************************** Dashboard *****************************/

}
