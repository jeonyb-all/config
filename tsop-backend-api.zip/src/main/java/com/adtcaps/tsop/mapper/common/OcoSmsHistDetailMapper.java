package com.adtcaps.tsop.mapper.common;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;

import com.adtcaps.tsop.domain.common.OcoSmsHistDetailDto;
import com.adtcaps.tsop.portal.api.send.domain.NoticeSendReceiverDto;

/**
 *
 * <ul>
 * <li>업무 그룹명 : tsop-backend-api</li>
 * <li>서브 업무명 : com.adtcaps.tsop.mapper.common</li>
 * <li>설  명 : OcoSmsHistDetailMapper.java</li>
 * <li>작성일 : 2021. 2. 25.</li>
 * <li>작성자 : jeonyb4</li>
 * </ul>
 */
@Mapper
public interface OcoSmsHistDetailMapper {
	/**
	 *
	 * createOcoSmsHistDetail
	 *
	 * @param reqOcoSmsHistDetailDto
	 * @return int
	 */
	public int createOcoSmsHistDetail(OcoSmsHistDetailDto reqOcoSmsHistDetailDto);

	/**
	 *
	 * listSmsHistDetail
	 *
	 * @param reqOcoSmsHistDetailDto
	 * @return List<NoticeSendReceiverDto>
	 */
	public List<NoticeSendReceiverDto> listSmsHistDetail(OcoSmsHistDetailDto reqOcoSmsHistDetailDto);

	/**
	 * updateOcoSmsHistDetail
	 * @param reqOcoSmsHistDetailDto
	 * @return int
	 */
	public int updateOcoSmsHistDetail(OcoSmsHistDetailDto reqOcoSmsHistDetailDto);
}
