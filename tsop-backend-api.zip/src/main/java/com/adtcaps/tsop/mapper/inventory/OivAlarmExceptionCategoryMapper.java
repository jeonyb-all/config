package com.adtcaps.tsop.mapper.inventory;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;

import com.adtcaps.tsop.domain.inventory.OivAlarmExceptionCategoryDto;
import com.adtcaps.tsop.domain.inventory.OivAlarmExceptionDto;

/**
 * 
 * <ul>
 * <li>업무 그룹명 : tsop-backend-api</li>
 * <li>서브 업무명 : com.adtcaps.tsop.mapper.inventory</li>
 * <li>설  명 : OivAlarmExceptionCategoryMapper.java</li>
 * <li>작성일 : 2021. 10. 15.</li>
 * <li>작성자 : jeonyb4</li>
 * </ul>
 */
@Mapper
public interface OivAlarmExceptionCategoryMapper {
	/**
	 * 
	 * createAlarmExceptionCategory
	 * 
	 * @param reqOivAlarmExceptionCategoryDto
	 * @return int
	 */
	public int createAlarmExceptionCategory(OivAlarmExceptionCategoryDto reqOivAlarmExceptionCategoryDto);
	
	/**
	 * 
	 * listAlarmExceptionCategory
	 * 
	 * @param reqOivAlarmExceptionCategoryDto
	 * @return List<OivAlarmExceptionCategoryDto>
	 */
	public List<OivAlarmExceptionCategoryDto> listAlarmExceptionCategory(OivAlarmExceptionDto reqOivAlarmExceptionDto);
	
	/**
	 * 
	 * deleteAlarmExceptionCategory
	 * 
	 * @param reqOivAlarmExceptionDto
	 * @return int
	 */
	public int deleteAlarmExceptionCategory(OivAlarmExceptionDto reqOivAlarmExceptionDto);

}
