/**
 *
 */
package com.adtcaps.tsop.mapper.work;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;

import com.adtcaps.tsop.domain.paymgmt.OwkApprovalLineDetailDto;
import com.adtcaps.tsop.domain.paymgmt.OwkApprovalLineDto;
import com.adtcaps.tsop.domain.paymgmt.OwkApprovalLineHistDto;
import com.adtcaps.tsop.domain.staffMgmt.OwkEmployeeDto;
import com.adtcaps.tsop.portal.api.approval.domain.PaymentMgmtDto;
import com.adtcaps.tsop.portal.api.approval.domain.PaymentMgmtGridResultDto;
import com.adtcaps.tsop.portal.api.approval.domain.PaymentMgmtRequestDto;

/**
 * <ul>
 * <li>업무 그룹명 : com.adtcaps.tsop.mapper.work</li>
 * <li>서브 업무명 : com.adtcaps.tsop.mapper.work</li>
 * <li>설  명 : OwkPaymentMgmtMapper.java</li>
 * <li>작성일 : 2021. 12. 2.</li>
 * <li>작성자 : msham</li>
 * </ul>
 */
@Mapper
public interface OwkPaymentMgmtMapper {

	/**
	 * listPagePaymentMgmt
	 *
	 * @param paymentMgmtDto
	 * @return List<PaymentMgmtGridResultDto>
	 */
	List<PaymentMgmtGridResultDto> listPagePaymentMgmt(PaymentMgmtDto paymentMgmtDto);

	/**
	 * listPagePaymentMgmtDetail
	 *
	 * @param approvalLineId
	 * @return List<OwkApprovalLineDetailDto>
	 */
	List<OwkApprovalLineDetailDto> listPagePaymentMgmtDetail(OwkApprovalLineDto owkApprovalLineDto);

	/**
	 * updatePaymentMgmt
	 *
	 * @param paymentMgmtRequestDto void
	 */
	int updatePaymentMgmt(PaymentMgmtRequestDto paymentMgmtRequestDto);

	/**
	 * insertPaymentDetailMgmt
	 *
	 * @param paymentMgmtRequestDto void
	 */
	int insertPaymentDetailMgmt(OwkApprovalLineDetailDto owkApprovalLineDetailDto);

	/**
	 * deletePaymentDetailMgmt
	 *
	 * @param paymentMgmtRequestDto
	 * @return int
	 */
	int deletePaymentDetailMgmt(PaymentMgmtRequestDto paymentMgmtRequestDto);

	/**
	 * insertPaymentHistMgmt
	 *
	 * @param paymentMgmtRequestDto
	 * @return int
	 */
	int insertPaymentHistMgmt(OwkApprovalLineHistDto owkApprovalLineHistDto);

	/**
	 * selectRowPaymentMgmt
	 *
	 * @param paymentMgmtRequestDto
	 * @return OwkApprovalLineDto
	 */
	OwkApprovalLineDto selectRowPaymentMgmt(PaymentMgmtRequestDto paymentMgmtRequestDto);

	/**
	 * selectRowPaymentHistMgmt
	 *
	 * @param paymentMgmtRequestDto
	 * @return OwkApprovalLineDetailDto
	 */
	String selectRowPaymentHistMgmt(OwkApprovalLineDto owkApprovalLineDto);

	/**
	 * insertPaymentMgmt
	 *
	 * @param paymentMgmtRequestDto
	 * @return int
	 */
	int insertPaymentMgmt(PaymentMgmtRequestDto paymentMgmtRequestDto);

	/**
	 * deletePaymentMgmt
	 *
	 * @param owkApprovalLineDto
	 * @return int
	 */
	int deletePaymentMgmt(OwkApprovalLineDto owkApprovalLineDto);

	/**
	 * deletePaymentHistMgmt
	 *
	 * @param owkApprovalLineDto
	 * @return int
	 */
	int deletePaymentHistMgmt(OwkApprovalLineDto owkApprovalLineDto);

	/**
	 * updateFireEmpId
	 *
	 * @param employeeDto
	 * @return int
	 */
	int updateFireEmpId(OwkEmployeeDto owkEmployeeDto);

	/**
	 * listPageApprovalLineDetail
	 *
	 * @param owkEmployeeDto
	 * @return List<OwkApprovalLineDetailDto>
	 */
	List<OwkApprovalLineDetailDto> listPageApprovalLineDetail(OwkEmployeeDto owkEmployeeDto);

	/**
	 * dupcheckApprovalLineName
	 *
	 * @param owkApprovalLineDto
	 * @return String
	 */
	String dupcheckApprovalLineName(OwkApprovalLineDto owkApprovalLineDto);

}
