package com.adtcaps.tsop.mapper.common;

import org.apache.ibatis.annotations.Mapper;

import com.adtcaps.tsop.domain.common.OcoUserPasswordInitializeDto;

/**
 * 
 * <ul>
 * <li>업무 그룹명 : tsop-backend-api</li>
 * <li>서브 업무명 : com.adtcaps.tsop.mapper.common</li>
 * <li>설  명 : OcoUserPasswordInitializeMapper.java</li>
 * <li>작성일 : 2020. 12. 24.</li>
 * <li>작성자 : jeonyb4</li>
 * </ul>
 */
@Mapper
public interface OcoUserPasswordInitializeMapper {
	/**
	 * 
	 * createOcoUserPasswordInitialize
	 *
	 * @param reqOcoUserPasswordInitializeDto
	 * @return int
	 */
	public int createOcoUserPasswordInitialize(OcoUserPasswordInitializeDto reqOcoUserPasswordInitializeDto);

}
