package com.adtcaps.tsop.mapper.inventory;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;

import com.adtcaps.tsop.domain.inventory.OivObjectGroupDto;
import com.adtcaps.tsop.helper.domain.BasePageDto;
import com.adtcaps.tsop.portal.api.object.domain.ObjectGroupGridResultDto;

/**
 * 
 * <ul>
 * <li>업무 그룹명 : tsop-backend-api</li>
 * <li>서브 업무명 : com.adtcaps.tsop.mapper.inventory</li>
 * <li>설  명 : OivObjectGroupMapper.java</li>
 * <li>작성일 : 2020. 12. 14.</li>
 * <li>작성자 : jeonyb4</li>
 * </ul>
 */
@Mapper
public interface OivObjectGroupMapper {
	/**
	 * 
	 * listPageObjectGroup
	 *
	 * @param reqBasePageDto
	 * @return List<ObjectGroupGridResultDto>
	 */
	public List<ObjectGroupGridResultDto> listPageObjectGroup(BasePageDto reqBasePageDto);
	
	/**
	 * 
	 * createOivObjectGroup
	 *
	 * @param reqOivObjectGroupDto
	 * @return int
	 */
	public int createOivObjectGroup(OivObjectGroupDto reqOivObjectGroupDto);
	
	/**
	 * 
	 * readObjectGroup
	 *
	 * @param reqOivObjectGroupDto
	 * @return OivObjectGroupDto
	 */
	public OivObjectGroupDto readObjectGroup(OivObjectGroupDto reqOivObjectGroupDto);
	
	/**
	 * 
	 * updateOivObjectGroup
	 *
	 * @param reqOivObjectGroupDto
	 * @return int
	 */
	public int updateOivObjectGroup(OivObjectGroupDto reqOivObjectGroupDto);
	
	/**
	 * 
	 * deleteOivObjectGroup
	 *
	 * @param reqOivObjectGroupDto
	 * @return int
	 */
	public int deleteOivObjectGroup(OivObjectGroupDto reqOivObjectGroupDto);
	
	/**
	 * 
	 * readObjectGroupByNameCount
	 *
	 * @param reqOivObjectGroupDto
	 * @return int
	 */
	public int readObjectGroupByNameCount(OivObjectGroupDto reqOivObjectGroupDto);

}
