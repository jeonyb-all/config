package com.adtcaps.tsop.mapper.common;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;

import com.adtcaps.tsop.domain.common.OcoUserRoleMappingDetailDto;
import com.adtcaps.tsop.helper.domain.BasePageDto;
import com.adtcaps.tsop.portal.api.building.domain.BuildingForComboResultDto;
import com.adtcaps.tsop.portal.api.user.domain.UserRoleMappingDetailGridResultDto;

/**
 * 
 * <ul>
 * <li>업무 그룹명 : tsop-backend-api</li>
 * <li>서브 업무명 : com.adtcaps.tsop.mapper.common</li>
 * <li>설  명 : OcoUserRoleMappingDetailMapper.java</li>
 * <li>작성일 : 2020. 12. 16.</li>
 * <li>작성자 : jeonyb4</li>
 * </ul>
 */
@Mapper
public interface OcoUserRoleMappingDetailMapper {
	/**
	 * 
	 * listUserRoleBuilding
	 *
	 * @param reqOcoUserRoleMappingDetailDto
	 * @return List<BuildingForComboResultDto>
	 */
	public List<BuildingForComboResultDto> listUserRoleBuilding(OcoUserRoleMappingDetailDto reqOcoUserRoleMappingDetailDto);
	
	/**
	 * 
	 * listPageUserRoleMappingDetail
	 *
	 * @param reqBasePageDto
	 * @return List<UserRoleMappingDetailGridResultDto>
	 */
	public List<UserRoleMappingDetailGridResultDto> listPageUserRoleMappingDetail(BasePageDto reqBasePageDto);
	
	/**
	 * 
	 * createOcoUserRoleMappingDetail
	 *
	 * @param reqOcoUserRoleMappingDetailDto
	 * @return int
	 */
	public int createOcoUserRoleMappingDetail(OcoUserRoleMappingDetailDto reqOcoUserRoleMappingDetailDto);
	
	/**
	 * 
	 * deleteOcoUserRoleMappingDetail
	 *
	 * @param reqOcoUserRoleMappingDetailDto
	 * @return int
	 */
	public int deleteOcoUserRoleMappingDetail(OcoUserRoleMappingDetailDto reqOcoUserRoleMappingDetailDto);

}
