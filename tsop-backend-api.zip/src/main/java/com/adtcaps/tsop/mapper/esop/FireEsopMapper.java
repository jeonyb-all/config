package com.adtcaps.tsop.mapper.esop;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;

import com.adtcaps.tsop.dashboard.api.esop.domain.EsopContactNetworkMemberDto;
import com.adtcaps.tsop.dashboard.api.esop.domain.EsopProcessResultDto;
import com.adtcaps.tsop.domain.esop.EsopMemoDto;
import com.adtcaps.tsop.domain.esop.EsopScenarioDto;
import com.adtcaps.tsop.domain.esop.FireProcessResultDto;
import com.adtcaps.tsop.domain.esop.ProcessResultDetailDto;
import com.adtcaps.tsop.domain.esop.ProcessResultDto;
import com.adtcaps.tsop.domain.esop.WeakAreaDto;

@Mapper
public interface FireEsopMapper {
	/**
	 * checkFireProcessResult
	 * @param bldId
	 * @return int
	 */
	public List<FireProcessResultDto> listOpenEsopResult(String bldId);

	/**
	 * listEsopScenarioStep
	 * @param bldId
	 * @return List<EsopScenarioDto>
	 */
	public List<EsopScenarioDto> listEsopScenarioStep(String bldId);

	/**
	 * listEsopProcessStep
	 * @param bldId
	 * @return List<EsopProcessDto>
	 */
	public List<EsopProcessResultDto> listEsopProcessStep(String bldId);

	/**
	 * listEsopMemo
	 * @param bldId
	 * @return List<EsopMemoDto>
	 */
	public List<EsopMemoDto> listEsopMemo(String bldId);

	/**
	 * listWeakArea
	 * @param weakAreaDto
	 * @return List<WeakAreaDto>
	 */
	public List<WeakAreaDto> listWeakArea(WeakAreaDto weakAreaDto);

	/**
	 * listWeakAreaAll
	 * @param weakAreaDto
	 * @return List<WeakAreaDto>
	 */
	public List<WeakAreaDto> listWeakAreaAll(WeakAreaDto weakAreaDto);

	/**
	 * readEsopProcessResult
	 * @param processResultDto
	 * @return ProcessResultDto
	 */
	public ProcessResultDto readEsopProcessResult(ProcessResultDto processResultDto);

	/**
	 * createEsopProcessResult
	 * @param processResultDto
	 * @return int
	 */
	public int createEsopProcessResult(ProcessResultDto processResultDto);

	/**
	 * createEsopProcessResultDetail
	 * @param processResultDetailDto
	 * @return int
	 */
	public int createEsopProcessResultDetail(ProcessResultDetailDto processResultDetailDto);

	/**
	 * listEsopProcessResultDetail
	 * @param processResultDetailDto
	 * @return List<ProcessResultDetailDto>
	 */
	public List<ProcessResultDetailDto> listEsopProcessResultDetail(ProcessResultDetailDto processResultDetailDto);

	/**
	 * updateEsopProcessResult
	 * @param processResultDto
	 * @return int
	 */
	public int updateEsopProcessResult(ProcessResultDto processResultDto);

	/**
	 * listContactNetworkMember
	 * @param esopContactNetworkMemberDto
	 * @return List<EsopContactNetworkMemberDto>
	 */
	public List<EsopContactNetworkMemberDto> listContactNetworkMember(EsopContactNetworkMemberDto esopContactNetworkMemberDto);

	/**
	 * listProcessResultDetail
	 * @param processResultDetailDto
	 * @return List<ProcessResultDetailDto>
	 */
	public List<ProcessResultDetailDto> listProcessResultDetail(ProcessResultDetailDto processResultDetailDto);

	/**
	 * readEsopScenario
	 * @param esopScenarioDto
	 * @return EsopScenarioDto
	 */
	public EsopScenarioDto readEsopScenario(EsopScenarioDto esopScenarioDto);

	/**
	 * readProcessScenario
	 * @param esopProcessResultDto
	 * @return EsopScenarioDto
	 */
	public EsopScenarioDto readProcessScenario(EsopProcessResultDto esopProcessResultDto);
}
