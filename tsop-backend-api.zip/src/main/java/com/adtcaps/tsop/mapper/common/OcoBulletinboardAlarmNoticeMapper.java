package com.adtcaps.tsop.mapper.common;

import org.apache.ibatis.annotations.Mapper;

import com.adtcaps.tsop.domain.common.OcoBulletinboardAlarmNoticeDto;
import com.adtcaps.tsop.domain.common.OcoBulletinboardDto;
import com.adtcaps.tsop.portal.api.send.domain.AlarmNoticeSendDetailResultDto;

/**
 * 
 * <ul>
 * <li>업무 그룹명 : tsop-backend-api</li>
 * <li>서브 업무명 : com.adtcaps.tsop.mapper.common</li>
 * <li>설  명 : OcoBulletinboardAlarmNoticeMapper.java</li>
 * <li>작성일 : 2020. 12. 17.</li>
 * <li>작성자 : jeonyb4</li>
 * </ul>
 */
@Mapper
public interface OcoBulletinboardAlarmNoticeMapper {
	/**
	 * 
	 * createOcoBulletinboardAlarmNotice
	 *
	 * @param reqOcoBulletinboardAlarmNoticeDto
	 * @return int
	 */
	public int createOcoBulletinboardAlarmNotice(OcoBulletinboardAlarmNoticeDto reqOcoBulletinboardAlarmNoticeDto);
	
	/**
	 * 
	 * deleteOcoBulletinboardAlarmNotice
	 *
	 * @param reqOcoBulletinboardDto
	 * @return int
	 */
	public int deleteOcoBulletinboardAlarmNotice(OcoBulletinboardDto reqOcoBulletinboardDto);
	
	/**
	 * 
	 * readBulletinboardAlarmNotice
	 *
	 * @param reqOcoBulletinboardAlarmNoticeDto
	 * @return AlarmNoticeSendDetailResultDto
	 */
	public AlarmNoticeSendDetailResultDto readBulletinboardAlarmNotice(OcoBulletinboardAlarmNoticeDto reqOcoBulletinboardAlarmNoticeDto);

}
