package com.adtcaps.tsop.mapper.common;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;

import com.adtcaps.tsop.dashboard.api.common.domain.DashboardCardRequestDto;
import com.adtcaps.tsop.domain.common.OcoUserDashboardCardDto;

/**
 * 
 * <ul>
 * <li>업무 그룹명 : tsop-backend-api</li>
 * <li>서브 업무명 : com.adtcaps.tsop.mapper.common</li>
 * <li>설  명 : OcoUserDashboardCardMapper.java</li>
 * <li>작성일 : 2021. 1. 22.</li>
 * <li>작성자 : jeonyb4</li>
 * </ul>
 */
@Mapper
public interface OcoUserDashboardCardMapper {
	/**
	 * 
	 * deleteUserDashboardCard
	 * 
	 * @param reqOcoUserDashboardCardDto
	 * @return int
	 */
	public int deleteUserDashboardCard(OcoUserDashboardCardDto reqOcoUserDashboardCardDto);
	
	/***************************** Dashboard *****************************/
	
	/**
	 * 
	 * listUserDashboardCard
	 *
	 * @param dashboardCardRequestDto
	 * @return List<OcoUserDashboardCardDto>
	 */
	public List<OcoUserDashboardCardDto> listUserDashboardCard(DashboardCardRequestDto dashboardCardRequestDto);
	
	/**
	 * 
	 * mergeOcoUserDashboardCard
	 *
	 * @param reqOcoUserDashboardCardDto
	 * @return int
	 */
	public int mergeOcoUserDashboardCard(OcoUserDashboardCardDto reqOcoUserDashboardCardDto);
	
	/**
	 * 
	 * createOcoUserDashboardCard
	 *
	 * @param reqOcoUserDashboardCardDto
	 * @return int
	 */
	public int createOcoUserDashboardCard(OcoUserDashboardCardDto reqOcoUserDashboardCardDto);
	
	/**
	 * 
	 * deleteUserDashboardCardElecTabHvacTab
	 *
	 * @param reqOcoUserDashboardCardDto
	 * @return int
	 */
	public int deleteUserDashboardCardElecTabHvacTab(OcoUserDashboardCardDto reqOcoUserDashboardCardDto);

}
