package com.adtcaps.tsop.mapper.inventory;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;

import com.adtcaps.tsop.portal.api.alarm.domain.AlarmcontentsApprovalLineHistDto;

@Mapper
public interface OivAlarmcontentsApprovalLineHistMapper {
	
	List<AlarmcontentsApprovalLineHistDto> getAlarmcontentsApprovalLineHistMapper(AlarmcontentsApprovalLineHistDto alarmcontentsApprovalLineHistDto);

	List<AlarmcontentsApprovalLineHistDto> approvalExcels(AlarmcontentsApprovalLineHistDto alarmcontentsApprovalLineHistDto);

}
