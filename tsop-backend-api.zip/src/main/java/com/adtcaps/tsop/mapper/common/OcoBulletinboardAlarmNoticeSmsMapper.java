package com.adtcaps.tsop.mapper.common;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;

import com.adtcaps.tsop.domain.common.OcoBulletinboardAlarmNoticeSmsDto;
import com.adtcaps.tsop.domain.common.OcoBulletinboardDto;
import com.adtcaps.tsop.portal.api.board.domain.BulletinboardAlarmNoticeSmsGridResultDto;

/**
 * 
 * <ul>
 * <li>업무 그룹명 : tsop-backend-api</li>
 * <li>서브 업무명 : com.adtcaps.tsop.mapper.common</li>
 * <li>설  명 : OcoBulletinboardAlarmNoticeSmsMapper.java</li>
 * <li>작성일 : 2020. 12. 17.</li>
 * <li>작성자 : jeonyb4</li>
 * </ul>
 */
@Mapper
public interface OcoBulletinboardAlarmNoticeSmsMapper {
	/**
	 * 
	 * createOcoBulletinboardAlarmNoticeSms
	 *
	 * @param reqOcoBulletinboardAlarmNoticeSmsDto
	 * @return int
	 */
	public int createOcoBulletinboardAlarmNoticeSms(OcoBulletinboardAlarmNoticeSmsDto reqOcoBulletinboardAlarmNoticeSmsDto);
	
	/**
	 * 
	 * listBulletinboardAlarmNoticeSms
	 *
	 * @param reqOcoBulletinboardDto
	 * @return List<BulletinboardAlarmNoticeSmsGridResultDto>
	 */
	public List<BulletinboardAlarmNoticeSmsGridResultDto> listBulletinboardAlarmNoticeSms(OcoBulletinboardDto reqOcoBulletinboardDto);
	
	/**
	 * 
	 * deleteOcoBulletinboardAlarmNoticeSms
	 *
	 * @param reqOcoBulletinboardDto
	 * @return int
	 */
	public int deleteOcoBulletinboardAlarmNoticeSms(OcoBulletinboardDto reqOcoBulletinboardDto);
	
	/**
	 * 
	 * deleteOcoBulletinboardAlarmNoticeSmsByUser
	 * 
	 * @param reqOcoBulletinboardAlarmNoticeSmsDto
	 * @return int
	 */
	public int deleteOcoBulletinboardAlarmNoticeSmsByUser(OcoBulletinboardAlarmNoticeSmsDto reqOcoBulletinboardAlarmNoticeSmsDto);

}
