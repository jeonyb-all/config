package com.adtcaps.tsop.mapper.elevator;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;

import com.adtcaps.tsop.dashboard.api.elevator.domain.ElevatorDailyReportResultDto;
import com.adtcaps.tsop.dashboard.api.elevator.domain.ElevatorEventResultDto;
import com.adtcaps.tsop.dashboard.api.elevator.domain.EscalatorEventDataResultDto;
import com.adtcaps.tsop.domain.elevator.OfmElevatorEventDto;
import com.adtcaps.tsop.portal.api.search.domain.ElevatorEventAlarmSearchResultDto;
import com.adtcaps.tsop.portal.api.search.domain.ElevatorSearchRequestDto;
import com.adtcaps.tsop.portal.api.search.domain.ElevatorStatusSearchResultDto;

/**
 * 
 * <ul>
 * <li>업무 그룹명 : tsop-backend-api</li>
 * <li>서브 업무명 : com.adtcaps.tsop.mapper.elevator</li>
 * <li>설  명 : OfmElevatorEventMapper.java</li>
 * <li>작성일 : 2020. 12. 4.</li>
 * <li>작성자 : jeonyb4</li>
 * </ul>
 */
@Mapper
public interface OfmElevatorEventMapper {
	/**
	 * 
	 * listElevatorEventChart
	 *
	 * @param reqOfmElevatorEventDto
	 * @return List<ElevatorEventResultDto>
	 */
	public List<ElevatorEventResultDto> listElevatorEventChart(OfmElevatorEventDto reqOfmElevatorEventDto);
	
	/**
	 * 
	 * listEscalatorEventChart
	 *
	 * @param reqOfmElevatorEventDto
	 * @return List<EscalatorEventDataResultDto>
	 */
	public List<EscalatorEventDataResultDto> listEscalatorEventChart(OfmElevatorEventDto reqOfmElevatorEventDto);
	
	/**
	 * 
	 * readElevatorDailyReport
	 *
	 * @param reqOfmElevatorEventDto
	 * @return ElevatorDailyReportResultDto
	 */
	public ElevatorDailyReportResultDto readElevatorDailyReport(OfmElevatorEventDto reqOfmElevatorEventDto);

	
	/**
	 * listElevatorStatusSearch
	 * 
	 * @param reqElevatorSearch
	 * @return List<ElevatorStatusSearchResultDto>
	 */
	public List<ElevatorStatusSearchResultDto> listElevatorStatusSearch(ElevatorSearchRequestDto reqElevatorSearch);
	
	/**
	 * listElevatorEventAlarmSearch
	 * 
	 * @param reqElevatorSearch
	 * @return List<ElevatorEventAlarmSearchResultDto>
	 */
	public List<ElevatorEventAlarmSearchResultDto> listElevatorEventAlarmSearch(ElevatorSearchRequestDto reqElevatorSearch);
	
}
