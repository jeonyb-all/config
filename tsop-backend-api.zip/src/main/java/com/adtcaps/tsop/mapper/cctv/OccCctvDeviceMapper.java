package com.adtcaps.tsop.mapper.cctv;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;

import com.adtcaps.tsop.portal.api.search.domain.CctvEquipSearchResultDto;
import com.adtcaps.tsop.portal.api.search.domain.CctvRtspUrlResultDto;
import com.adtcaps.tsop.portal.api.search.domain.CctvSearchRequestDto;

/**
 *
 * <ul>
 * <li>업무 그룹명 : tsop-backend-api</li>
 * <li>서브 업무명 : com.adtcaps.tsop.mapper.cctv</li>
 * <li>설  명 : OccCctvDeviceMapper.java</li>
 * <li>작성일 : 2021. 1. 17.</li>
 * <li>작성자 : song</li>
 * </ul>
 */
@Mapper
public interface OccCctvDeviceMapper {
	public List<CctvEquipSearchResultDto> listCctvEquipSearch(CctvSearchRequestDto reqCctvSearch);
	public List<CctvRtspUrlResultDto> listCctvRtspUrlSearch(CctvSearchRequestDto reqCctvSearch);
	public List<CctvEquipSearchResultDto> listCctv(CctvSearchRequestDto cctvSearchRequestDto);
}
