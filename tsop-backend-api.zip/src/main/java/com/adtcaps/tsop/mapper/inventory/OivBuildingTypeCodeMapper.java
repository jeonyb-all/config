package com.adtcaps.tsop.mapper.inventory;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;

import com.adtcaps.tsop.domain.inventory.OivBuildingTypeCodeDto;
import com.adtcaps.tsop.portal.api.building.domain.BuildingTypeCodeDetailResultDto;
import com.adtcaps.tsop.portal.api.building.domain.BuildingTypeCodeForComboResultDto;
import com.adtcaps.tsop.portal.api.building.domain.BuildingTypeCodeGridRequestDto;
import com.adtcaps.tsop.portal.api.building.domain.BuildingTypeCodeGridResultDto;

/**
 * 
 * <ul>
 * <li>업무 그룹명 : tsop-backend-api</li>
 * <li>서브 업무명 : com.adtcaps.tsop.mapper.inventory</li>
 * <li>설  명 : OivBuildingTypeCodeMapper.java</li>
 * <li>작성일 : 2020. 12. 8.</li>
 * <li>작성자 : jeonyb4</li>
 * </ul>
 */
@Mapper
public interface OivBuildingTypeCodeMapper {
	/**
	 * 
	 * listBuildingTypeCodeForCombo
	 *
	 * @return List<BuildingTypeCodeForComboResultDto>
	 */
	public List<BuildingTypeCodeForComboResultDto> listBuildingTypeCodeForCombo();
	
	/**
	 * 
	 * listPageBuildingTypeCode
	 *
	 * @param buildingTypeCodeGridRequestDto
	 * @return List<BuildingTypeCodeGridResultDto>
	 */
	public List<BuildingTypeCodeGridResultDto> listPageBuildingTypeCode(BuildingTypeCodeGridRequestDto buildingTypeCodeGridRequestDto);
	
	/**
	 * 
	 * readBuildingTypeCodeDuplicationCheck
	 *
	 * @param reqOivBuildingTypeCodeDto
	 * @return int
	 */
	public int readBuildingTypeCodeDuplicationCheck(OivBuildingTypeCodeDto reqOivBuildingTypeCodeDto);
	
	/**
	 * 
	 * createOivBuildingTypeCode
	 *
	 * @param reqOivBuildingTypeCodeDto
	 * @return int
	 */
	public int createOivBuildingTypeCode(OivBuildingTypeCodeDto reqOivBuildingTypeCodeDto);
	
	/**
	 * 
	 * readBuildingTypeCode
	 *
	 * @param reqOivBuildingTypeCodeDto
	 * @return BuildingTypeCodeDetailResultDto
	 */
	public BuildingTypeCodeDetailResultDto readBuildingTypeCode(OivBuildingTypeCodeDto reqOivBuildingTypeCodeDto);
	
	/**
	 * 
	 * updateOivBuildingTypeCode
	 *
	 * @param reqOivBuildingTypeCodeDto
	 * @return int
	 */
	public int updateOivBuildingTypeCode(OivBuildingTypeCodeDto reqOivBuildingTypeCodeDto);
	
	/**
	 * 
	 * deleteOivBuildingTypeCode
	 *
	 * @param reqOivBuildingTypeCodeDto
	 * @return int
	 */
	public int deleteOivBuildingTypeCode(OivBuildingTypeCodeDto reqOivBuildingTypeCodeDto);
	
	/**
	 * 
	 * updateBuildingTypeCodeReuse
	 *
	 * @param reqOivBuildingTypeCodeDto
	 * @return int
	 */
	public int updateBuildingTypeCodeReuse(OivBuildingTypeCodeDto reqOivBuildingTypeCodeDto);

}
