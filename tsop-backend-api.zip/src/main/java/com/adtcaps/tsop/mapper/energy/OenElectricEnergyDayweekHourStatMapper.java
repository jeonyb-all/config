package com.adtcaps.tsop.mapper.energy;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;

import com.adtcaps.tsop.dashboard.api.energy.domain.BuildingPowerTrendVO;
import com.adtcaps.tsop.portal.api.report.domain.ElecUseAmountResultDto;
import com.adtcaps.tsop.portal.api.report.domain.WeekReportMakeRequestDto;

/**
 * 
 * <ul>
 * <li>업무 그룹명 : tsop-backend-api</li>
 * <li>서브 업무명 : com.adtcaps.tsop.mapper.energy</li>
 * <li>설  명 : OenElectricEnergyDayweekHourStatMapper.java</li>
 * <li>작성일 : 2021. 12. 14.</li>
 * <li>작성자 : jeonyb4</li>
 * </ul>
 */
@Mapper
public interface OenElectricEnergyDayweekHourStatMapper {
	
	
	
	/***************************** Week Report *****************************/
	/**
	 * 
	 * readReportServiceSummaryElec
	 * 
	 * @param weekReportMakeRequestDto
	 * @return Double
	 */
	public Double readReportServiceSummaryElec(WeekReportMakeRequestDto weekReportMakeRequestDto);
	
	/**
	 * 
	 * listReportElecUseAmountDaySummary
	 * 
	 * @param weekReportMakeRequestDto
	 * @return ElecUseAmountResultDto
	 */
	public List<ElecUseAmountResultDto> listReportElecUseAmountDaySummary(WeekReportMakeRequestDto weekReportMakeRequestDto);
	
	/**
	 * 
	 * readReportElecUseAmountMonthSummary
	 * 
	 * @param weekReportMakeRequestDto
	 * @return ElecUseAmountResultDto
	 */
	public ElecUseAmountResultDto readReportElecUseAmountMonthSummary(WeekReportMakeRequestDto weekReportMakeRequestDto);
	
	/**
	 * 
	 * listReportBuildingPowerDayWeekChart
	 * 
	 * @param weekReportMakeRequestDto
	 * @return List<BuildingPowerTrendVO>
	 */
	public List<BuildingPowerTrendVO> listReportBuildingPowerDayWeekChart(WeekReportMakeRequestDto weekReportMakeRequestDto);

}
