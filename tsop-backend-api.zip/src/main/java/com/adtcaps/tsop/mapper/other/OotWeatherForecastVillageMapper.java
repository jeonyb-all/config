package com.adtcaps.tsop.mapper.other;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;

import com.adtcaps.tsop.dashboard.api.other.domain.WeatherForecastVillageResultDto;
import com.adtcaps.tsop.dashboard.api.other.domain.WeatherMinMaxTemprResultDto;
import com.adtcaps.tsop.domain.other.OotWeatherForecastVillageDto;

/**
 * 
 * <ul>
 * <li>업무 그룹명 : tsop-backend-api</li>
 * <li>서브 업무명 : com.adtcaps.tsop.mapper.other</li>
 * <li>설  명 : OotWeatherForecastVillageMapper.java</li>
 * <li>작성일 : 2020. 12. 18.</li>
 * <li>작성자 : jeonyb4</li>
 * </ul>
 */
@Mapper
public interface OotWeatherForecastVillageMapper {
	
	/**
	 * 
	 * readInputDateMinMaxTemprVal
	 * 
	 * @param reqOotWeatherForecastVillageDto
	 * @return WeatherMinMaxTemprResultDto
	 */
	public WeatherMinMaxTemprResultDto readInputDateMinMaxTemprVal(OotWeatherForecastVillageDto reqOotWeatherForecastVillageDto);
	
	/***************************** Dashboard *****************************/
	
	/**
	 * 
	 * listBuildingWeatherForecastVillage
	 *
	 * @param reqOotWeatherForecastVillageDto
	 * @return List<WeatherForecastVillageResultDto>
	 */
	public List<WeatherForecastVillageResultDto> listBuildingWeatherForecastVillage(OotWeatherForecastVillageDto reqOotWeatherForecastVillageDto);
	
	/**
	 * 
	 * readMinMaxTemprVal
	 *
	 * @param reqOotWeatherForecastVillageDto
	 * @return WeatherMinMaxTemprResultDto
	 */
	public WeatherMinMaxTemprResultDto readMinMaxTemprVal(OotWeatherForecastVillageDto reqOotWeatherForecastVillageDto);

}
