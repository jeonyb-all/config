package com.adtcaps.tsop.mapper.common;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;

import com.adtcaps.tsop.portal.api.menu.domain.MenuRequestDto;
import com.adtcaps.tsop.portal.api.menu.domain.MenuResultDto;
import com.adtcaps.tsop.portal.api.menu.domain.MenuTreeResultDto;

/**
 * 
 * <ul>
 * <li>업무 그룹명 : tsop-backend-api</li>
 * <li>서브 업무명 : com.adtcaps.tsop.mapper.common</li>
 * <li>설  명 : OcoMenuMapper.java</li>
 * <li>작성일 : 2020. 12. 22.</li>
 * <li>작성자 : jeonyb4</li>
 * </ul>
 */
@Mapper
public interface OcoMenuMapper {
	/**
	 * 
	 * listMenu
	 *
	 * @param menuRequestDto
	 * @return List<MenuResultDto>
	 */
	public List<MenuResultDto> listMenu(MenuRequestDto menuRequestDto);
	
	/**
	 * 
	 * listAdminMenu
	 *
	 * @param menuRequestDto
	 * @return List<MenuResultDto>
	 */
	public List<MenuResultDto> listAdminMenu(MenuRequestDto menuRequestDto);
	
	/**
	 * 
	 * listHiddenMenu
	 *
	 * @param menuRequestDto
	 * @return List<MenuResultDto>
	 */
	public List<MenuResultDto> listHiddenMenu(MenuRequestDto menuRequestDto);
	
	/**
	 * 
	 * listHiddenAdminMenu
	 *
	 * @param menuRequestDto
	 * @return List<MenuResultDto>
	 */
	public List<MenuResultDto> listHiddenAdminMenu(MenuRequestDto menuRequestDto);
	
	/**
	 * 
	 * listMenuTree
	 *
	 * @return List<MenuTreeResultDto>
	 */
	public List<MenuTreeResultDto> listMenuTree();
	
	/**
	 * 
	 * readBuildingMenuExistCheck
	 * 
	 * @param menuRequestDto
	 * @return String
	 */
	public String readBuildingMenuExistCheck(MenuRequestDto menuRequestDto);

}
