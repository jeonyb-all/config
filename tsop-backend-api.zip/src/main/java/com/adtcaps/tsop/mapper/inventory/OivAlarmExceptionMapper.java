package com.adtcaps.tsop.mapper.inventory;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;

import com.adtcaps.tsop.domain.inventory.OivAlarmExceptionDto;
import com.adtcaps.tsop.portal.api.alarm.domain.AlarmExceptionGridRequestDto;
import com.adtcaps.tsop.portal.api.alarm.domain.AlarmExceptionGridResultDto;
import com.adtcaps.tsop.portal.api.alarm.domain.AlarmExceptionProcessingDto;

/**
 * 
 * <ul>
 * <li>업무 그룹명 : tsop-backend-api</li>
 * <li>서브 업무명 : com.adtcaps.tsop.mapper.inventory</li>
 * <li>설  명 : OivAlarmExceptionMapper.java</li>
 * <li>작성일 : 2021. 10. 14.</li>
 * <li>작성자 : jeonyb4</li>
 * </ul>
 */
@Mapper
public interface OivAlarmExceptionMapper {
	/**
	 * 
	 * listPageAlarmException
	 * 
	 * @param alarmExceptionGridRequestDto
	 * @return List<AlarmExceptionGridResultDto>
	 */
	public List<AlarmExceptionGridResultDto> listPageAlarmException(AlarmExceptionGridRequestDto alarmExceptionGridRequestDto);
	
	/**
	 * 
	 * updateAlarmExceptionUseYn
	 * 
	 * @param reqOivAlarmExceptionDto
	 * @return int
	 */
	public int updateAlarmExceptionUseYn(OivAlarmExceptionDto reqOivAlarmExceptionDto);
	
	/**
	 * 
	 * createAlarmException
	 * 
	 * @param reqOivAlarmExceptionDto
	 * @return int
	 */
	public int createAlarmException(OivAlarmExceptionDto reqOivAlarmExceptionDto);
	
	/**
	 * 
	 * readOivAlarmException
	 * 
	 * @param reqOivAlarmExceptionDto
	 * @return AlarmExceptionProcessingDto
	 */
	public AlarmExceptionProcessingDto readAlarmException(OivAlarmExceptionDto reqOivAlarmExceptionDto);
	
	/**
	 * 
	 * updateAlarmException
	 * 
	 * @param reqOivAlarmExceptionDto
	 * @return int
	 */
	public int updateAlarmException(OivAlarmExceptionDto reqOivAlarmExceptionDto);
	
	/**
	 * 
	 * deleteOivAlarmException
	 * 
	 * @param reqOivAlarmExceptionDto
	 * @return int
	 */
	public int deleteAlarmException(OivAlarmExceptionDto reqOivAlarmExceptionDto);
	
	/**
	 * 
	 * listAlarmExceptionNameDupCheck
	 * 
	 * @param reqOivAlarmExceptionDto
	 * @return List<OivAlarmExceptionDto>
	 */
	public List<OivAlarmExceptionDto> listAlarmExceptionNameDupCheck(OivAlarmExceptionDto reqOivAlarmExceptionDto);

}
