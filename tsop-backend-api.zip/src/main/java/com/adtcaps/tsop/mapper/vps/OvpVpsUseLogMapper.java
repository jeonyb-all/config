package com.adtcaps.tsop.mapper.vps;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;

import com.adtcaps.tsop.helper.domain.BasePageDto;
import com.adtcaps.tsop.portal.api.search.domain.VpsHistorySearchResultDto;

/**
 * 
 * <ul>
 * <li>업무 그룹명 : tsop-backend-api</li>
 * <li>서브 업무명 : com.adtcaps.tsop.mapper.vps</li>
 * <li>설  명 : OvpVpsUseLogMapper.java</li>
 * <li>작성일 : 2021. 1. 19.</li>
 * <li>작성자 : song</li>
 * </ul>
 */
@Mapper
public interface OvpVpsUseLogMapper {

/**
 * listVpsHistorySearch
 * 
 * @param reqVpsSearch
 * @return List<VpsHistorySearchResultDto>
 */
	public List<VpsHistorySearchResultDto> listVpsHistorySearch(BasePageDto reqVpsSearch);
	
}
