package com.adtcaps.tsop.mapper.esop;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;

import com.adtcaps.tsop.domain.esop.WeakAreaCctvDto;
import com.adtcaps.tsop.domain.esop.WeakAreaDto;
import com.adtcaps.tsop.portal.api.esop.domain.WeakAreaGridRequestDto;
import com.adtcaps.tsop.portal.api.esop.domain.WeakAreaGridResultDto;
import com.adtcaps.tsop.portal.api.esop.domain.WeakAreaRequestDto;
import com.adtcaps.tsop.portal.api.statistics.domain.VocRecvHistoryDto;

@Mapper
public interface WeakAreaMapper {
	/**
	 * listPageWeakArea
	 * @param weakAreaRequestDto
	 * @return List<WeakAreaGridResultDto>
	 */
	public List<WeakAreaGridResultDto> listPageWeakArea(WeakAreaGridRequestDto weakAreaGridRequestDto);

	/**
	 * readWeakArea
	 * @param weakAreaDto
	 * @return WeakAreaDto
	 */
	public WeakAreaDto readWeakArea(WeakAreaDto weakAreaDto);

	/**
	 * createWeakAreaCctv
	 * @param weakAreaCctvDto
	 * @return int
	 */
	public int createWeakAreaCctv(WeakAreaCctvDto weakAreaCctvDto);

	/**
	 * deleteWeakAreaCctv
	 * @param weakAreaCctvDto
	 * @return int
	 */
	public int deleteWeakAreaCctv(WeakAreaCctvDto weakAreaCctvDto);

	/**
	 * createWeakArea
	 * @param weakAreaRequestDto
	 * @return int
	 */
	public int createWeakArea(WeakAreaRequestDto weakAreaRequestDto);

	/**
	 * updateWeakArea
	 * @param weakAreaDto
	 * @return int
	 */
	public int updateWeakArea(WeakAreaRequestDto weakAreaRequestDto);

	/**
	 * deleteWeakArea
	 * @param weakAreaDto
	 * @return int
	 */
	public int deleteWeakArea(WeakAreaDto weakAreaDto);

	/**
	 * listWeakAreaCctv
	 * @param weakAreaCctvDto
	 * @return List<WeakAreaCctvDto>
	 */
	public List<WeakAreaCctvDto> listWeakAreaCctv(WeakAreaCctvDto weakAreaCctvDto);

	/**
	 * listWeakAreaExcel
	 * @param WeakAreaGridResultDto
	 * @return List<WeakAreaGridResultDto>
	 */
	public List<WeakAreaGridResultDto> listWeakAreaExcel(WeakAreaGridRequestDto weakAreaGridResultDto);
}
