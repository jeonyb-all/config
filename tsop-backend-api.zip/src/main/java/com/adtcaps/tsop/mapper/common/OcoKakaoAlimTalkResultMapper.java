package com.adtcaps.tsop.mapper.common;

import org.apache.ibatis.annotations.Mapper;

import com.adtcaps.tsop.domain.common.OcoKakaoAlimTalkResultDto;

/**
 * <ul>
 * <li>업무 그룹명 : tsop-backend-api</li>
 * <li>서브 업무명 : com.adtcaps.tsop.mapper.common</li>
 * <li>설  명 : OcoKakaoAlimTalkResultMapper.java</li>
 * <li>작성일 : 2021. 12. 29.</li>
 * <li>작성자 : vader</li>
 * </ul>
 */
@Mapper
public interface OcoKakaoAlimTalkResultMapper {
	/**
	 * createOcoKakaoAlimTalkResult
	 * @param ocoKakaoAlimTalkResultDto
	 * @return int
	 */
	public int createOcoKakaoAlimTalkResult(OcoKakaoAlimTalkResultDto ocoKakaoAlimTalkResultDto);

	/**
	 * updateOcoKakaoAlimTalkResult
	 * @param ocoKakaoAlimTalkResultDto
	 * @return int
	 */
	public int updateOcoKakaoAlimTalkResult(OcoKakaoAlimTalkResultDto ocoKakaoAlimTalkResultDto);
}
