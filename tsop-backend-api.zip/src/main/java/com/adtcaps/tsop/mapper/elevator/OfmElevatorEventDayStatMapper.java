package com.adtcaps.tsop.mapper.elevator;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;

import com.adtcaps.tsop.domain.elevator.OfmElevatorEventDayStatDto;
import com.adtcaps.tsop.portal.api.elevator.domain.PortalDashboardElevatorEventDayStatResultDto;
import com.adtcaps.tsop.portal.api.statistics.domain.ElevatorStatisticsRequestDto;
import com.adtcaps.tsop.portal.api.statistics.domain.ElevatorStatusStatisticsResultDto;

/**
 * 
 * <ul>
 * <li>업무 그룹명 : tsop-backend-api</li>
 * <li>서브 업무명 : com.adtcaps.tsop.mapper.elevator</li>
 * <li>설  명 : OfmElevatorEventDayStatMapper.java</li>
 * <li>작성일 : 2021. 1. 19.</li>
 * <li>작성자 : song</li>
 * </ul>
 */
@Mapper
public interface OfmElevatorEventDayStatMapper {
	
	/***************************** Statistics *****************************/
	
	/**
	 * listElevatorEventAlarmSearch
	 * 
	 * @param reqElevatorSearch
	 * @return List<ElevatorEventAlarmSearchResultDto>
	 */
	public List<ElevatorStatusStatisticsResultDto> listElevatorStatusStatistics(ElevatorStatisticsRequestDto reqElevatorStatistics);
	
	
	/***************************** Portal Main *****************************/
	
	/**
	 * 
	 * listPortalDashboardElevatorEventDayStatChart
	 *
	 * @param reqOfmElevatorEventDayStatDto
	 * @return List<PortalDashboardElevatorEventDayStatResultDto>
	 */
	public List<PortalDashboardElevatorEventDayStatResultDto> listPortalDashboardElevatorEventDayStatChart(OfmElevatorEventDayStatDto reqOfmElevatorEventDayStatDto);
	
}
