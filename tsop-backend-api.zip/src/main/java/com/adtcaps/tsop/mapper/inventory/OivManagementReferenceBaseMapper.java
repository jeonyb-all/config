package com.adtcaps.tsop.mapper.inventory;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;

import com.adtcaps.tsop.domain.inventory.OivManagementReferenceBaseDto;
import com.adtcaps.tsop.portal.api.alert.domain.AlertIndicatorProcessingDto;

/**
 * 
 * <ul>
 * <li>업무 그룹명 : tsop-backend-api</li>
 * <li>서브 업무명 : com.adtcaps.tsop.mapper.inventory</li>
 * <li>설  명 : OivManagementReferenceBaseMapper.java</li>
 * <li>작성일 : 2021. 10. 19.</li>
 * <li>작성자 : jeonyb4</li>
 * </ul>
 */
@Mapper
public interface OivManagementReferenceBaseMapper {
	/**
	 * 
	 * createManagementReferenceBase
	 * 
	 * @param reqOivManagementReferenceBaseDto
	 * @return int
	 */
	public int createManagementReferenceBase(OivManagementReferenceBaseDto reqOivManagementReferenceBaseDto);
	
	/**
	 * 
	 * listManagementReferenceBase
	 * 
	 * @param reqOivManagementReferenceBaseDto
	 * @return List<AlertIndicatorProcessingDto>
	 */
	public List<AlertIndicatorProcessingDto> listManagementReferenceBase(OivManagementReferenceBaseDto reqOivManagementReferenceBaseDto);
	
	/**
	 * 
	 * updateManagementReferenceBase
	 * 
	 * @param reqOivManagementReferenceBaseDto
	 * @return int
	 */
	public int updateManagementReferenceBase(OivManagementReferenceBaseDto reqOivManagementReferenceBaseDto);
	
	/***************************** Dashboard *****************************/
	
	/**
	 * 
	 * readManagementReferenceBase
	 * 
	 * @param reqOivManagementReferenceBaseDto
	 * @return OivManagementReferenceBaseDto
	 */
	public OivManagementReferenceBaseDto readManagementReferenceBase(OivManagementReferenceBaseDto reqOivManagementReferenceBaseDto);

}
