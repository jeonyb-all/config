package com.adtcaps.tsop.mapper.common;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;

import com.adtcaps.tsop.domain.common.OcoUserRoleDto;
import com.adtcaps.tsop.helper.domain.BasePageDto;
import com.adtcaps.tsop.portal.api.user.domain.UserRoleForComboResultDto;
import com.adtcaps.tsop.portal.api.user.domain.UserRoleGridResultDto;

/**
 * 
 * <ul>
 * <li>업무 그룹명 : tsop-backend-api</li>
 * <li>서브 업무명 : com.adtcaps.tsop.mapper.common</li>
 * <li>설  명 : OcoUserRoleMapper.java</li>
 * <li>작성일 : 2020. 12. 23.</li>
 * <li>작성자 : jeonyb4</li>
 * </ul>
 */
@Mapper
public interface OcoUserRoleMapper {
	/**
	 * 
	 * listUserRoleForCombo
	 *
	 * @return List<UserRoleForComboResultDto>
	 */
	public List<UserRoleForComboResultDto> listUserRoleForCombo();
	
	/**
	 * 
	 * listPageUserRole
	 *
	 * @param reqBasePageDto
	 * @return List<UserRoleGridResultDto>
	 */
	public List<UserRoleGridResultDto> listPageUserRole(BasePageDto reqBasePageDto);
	
	/**
	 * 
	 * readUserRoleDuplicationByName
	 *
	 * @param reqOcoUserRoleDto
	 * @return int
	 */
	public int readUserRoleDuplicationByName(OcoUserRoleDto reqOcoUserRoleDto);
	
	/**
	 * 
	 * createOcoUserRole
	 *
	 * @param reqOcoUserRoleDto
	 * @return int
	 */
	public int createOcoUserRole(OcoUserRoleDto reqOcoUserRoleDto);
	
	/**
	 * 
	 * readOcoUserRole
	 *
	 * @param reqOcoUserRoleDto
	 * @return OcoUserRoleDto
	 */
	public OcoUserRoleDto readOcoUserRole(OcoUserRoleDto reqOcoUserRoleDto);
	
	/**
	 * 
	 * updateOcoUserRole
	 *
	 * @param reqOcoUserRoleDto
	 * @return int
	 */
	public int updateOcoUserRole(OcoUserRoleDto reqOcoUserRoleDto);
	
	/**
	 * 
	 * deleteOcoUserRole
	 *
	 * @param reqOcoUserRoleDto
	 * @return int
	 */
	public int deleteOcoUserRole(OcoUserRoleDto reqOcoUserRoleDto);

}
