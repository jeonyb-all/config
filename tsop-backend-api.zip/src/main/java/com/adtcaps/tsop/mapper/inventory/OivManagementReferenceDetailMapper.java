package com.adtcaps.tsop.mapper.inventory;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;

import com.adtcaps.tsop.domain.inventory.OivManagementReferenceBaseDto;
import com.adtcaps.tsop.domain.inventory.OivManagementReferenceDetailDto;
import com.adtcaps.tsop.portal.api.alert.domain.AlertIndicatorDetailDto;
import com.adtcaps.tsop.portal.api.alert.domain.FloorAlertIndicatorDetailDto;
import com.adtcaps.tsop.portal.api.alert.domain.MonthAlertIndicatorDetailDto;

/**
 * 
 * <ul>
 * <li>업무 그룹명 : tsop-backend-api</li>
 * <li>서브 업무명 : com.adtcaps.tsop.mapper.inventory</li>
 * <li>설  명 : OivManagementReferenceDetailMapper.java</li>
 * <li>작성일 : 2021. 10. 20.</li>
 * <li>작성자 : jeonyb4</li>
 * </ul>
 */
@Mapper
public interface OivManagementReferenceDetailMapper {
	/**
	 * 
	 * listManagementReferenceDetail
	 * 
	 * @param reqOivManagementReferenceDetailDto
	 * @return List<AlertIndicatorDetailDto>
	 */
	public List<AlertIndicatorDetailDto> listManagementReferenceDetail(OivManagementReferenceDetailDto reqOivManagementReferenceDetailDto);
	
	/**
	 * 
	 * listFloorManagementReferenceDetail
	 * 
	 * @param reqOivManagementReferenceDetailDto
	 * @return List<FloorAlertIndicatorDetailDto>
	 */
	public List<FloorAlertIndicatorDetailDto> listFloorManagementReferenceDetail(OivManagementReferenceDetailDto reqOivManagementReferenceDetailDto);
	
	/**
	 * 
	 * listMonthManagementReferenceDetail
	 * 
	 * @param reqOivManagementReferenceDetailDto
	 * @return List<MonthAlertIndicatorDetailDto>
	 */
	public List<MonthAlertIndicatorDetailDto> listMonthManagementReferenceDetail(OivManagementReferenceDetailDto reqOivManagementReferenceDetailDto);
	
	/**
	 * 
	 * listEnthalpyManagementReferenceDetail
	 * 
	 * @param reqOivManagementReferenceDetailDto
	 * @return List<AlertIndicatorDetailDto>
	 */
	public List<AlertIndicatorDetailDto> listEnthalpyManagementReferenceDetail(OivManagementReferenceDetailDto reqOivManagementReferenceDetailDto);
	
	/**
	 * 
	 * createManagementReferenceDetail
	 * 
	 * @param reqOivManagementReferenceDetailDto
	 * @return int
	 */
	public int createManagementReferenceDetail(OivManagementReferenceDetailDto reqOivManagementReferenceDetailDto);
	
	/**
	 * 
	 * deleteManagementReferenceDetail
	 * 
	 * @param reqOivManagementReferenceBaseDto
	 * @return int
	 */
	public int deleteManagementReferenceDetail(OivManagementReferenceBaseDto reqOivManagementReferenceBaseDto);
	
	/***************************** Dashboard *****************************/
	
	/**
	 * 
	 * readAvgMgmtBaseTempr
	 * 
	 * @param reqOivManagementReferenceDetailDto
	 * @return Double
	 */
	public Double readAvgMgmtBaseTempr(OivManagementReferenceDetailDto reqOivManagementReferenceDetailDto);
	
	/***************************** Dashboard *****************************/
	/**
	 * 
	 * readFloorInEnthalpyInfo
	 * 
	 * @param reqOivManagementReferenceDetailDto
	 * @return String
	 */
	public String readFloorInEnthalpyInfo(OivManagementReferenceDetailDto reqOivManagementReferenceDetailDto);

}
