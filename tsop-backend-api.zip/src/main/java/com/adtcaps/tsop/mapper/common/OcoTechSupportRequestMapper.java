package com.adtcaps.tsop.mapper.common;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;

import com.adtcaps.tsop.domain.common.OcoTechSupportRequestDto;
import com.adtcaps.tsop.portal.api.support.domain.TechSupportRequestGridRequestDto;
import com.adtcaps.tsop.portal.api.support.domain.TechSupportRequestGridResultDto;
import com.adtcaps.tsop.portal.api.support.domain.TechSupportRequestPortalDashboardRequestDto;
import com.adtcaps.tsop.portal.api.support.domain.TechSupportRequestPortalDashboardResultDto;
import com.adtcaps.tsop.portal.api.support.domain.TechSupportResultDetailResultDto;

/**
 * 
 * <ul>
 * <li>업무 그룹명 : tsop-backend-api</li>
 * <li>서브 업무명 : com.adtcaps.tsop.mapper.common</li>
 * <li>설  명 : OcoTechSupportRequestMapper.java</li>
 * <li>작성일 : 2020. 12. 16.</li>
 * <li>작성자 : jeonyb4</li>
 * </ul>
 */
@Mapper
public interface OcoTechSupportRequestMapper {
	/**
	 * 
	 * listPageTechSupportRequest
	 *
	 * @param techSupportRequestGridRequestDto
	 * @return List<TechSupportRequestGridResultDto>
	 */
	public List<TechSupportRequestGridResultDto> listPageTechSupportRequest(TechSupportRequestGridRequestDto techSupportRequestGridRequestDto);
	
	/**
	 * 
	 * createOcoTechSupportRequest
	 *
	 * @param reqOcoTechSupportRequestDto
	 * @return int
	 */
	public int createOcoTechSupportRequest(OcoTechSupportRequestDto reqOcoTechSupportRequestDto);
	
	/**
	 * 
	 * readOcoTechSupportRequest
	 *
	 * @param reqOcoTechSupportRequestDto
	 * @return TechSupportResultDetailResultDto
	 */
	public TechSupportResultDetailResultDto readOcoTechSupportRequest(OcoTechSupportRequestDto reqOcoTechSupportRequestDto);
	
	/**
	 * 
	 * updateTechSupportStatus
	 *
	 * @param reqOcoTechSupportRequestDto
	 * @return int
	 */
	public int updateTechSupportStatus(OcoTechSupportRequestDto reqOcoTechSupportRequestDto);
	
	/**
	 * 
	 * listPortalDashboardTechSupportRequest
	 *
	 * @param techSupportRequestPortalDashboardRequestDto
	 * @return List<TechSupportRequestPortalDashboardResultDto>
	 */
	public List<TechSupportRequestPortalDashboardResultDto> listPortalDashboardTechSupportRequest(TechSupportRequestPortalDashboardRequestDto techSupportRequestPortalDashboardRequestDto);
	
	
}
