package com.adtcaps.tsop.mapper.inventory;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;

import com.adtcaps.tsop.domain.inventory.OivThresholdDto;
import com.adtcaps.tsop.portal.api.threshold.domain.ThresholdDetailResultDto;
import com.adtcaps.tsop.portal.api.threshold.domain.ThresholdGridRequestDto;
import com.adtcaps.tsop.portal.api.threshold.domain.ThresholdGridResultDto;

/**
 * 
 * <ul>
 * <li>업무 그룹명 : tsop-backend-api</li>
 * <li>서브 업무명 : com.adtcaps.tsop.mapper.inventory</li>
 * <li>설  명 : OivThresholdMapper.java</li>
 * <li>작성일 : 2020. 12. 21.</li>
 * <li>작성자 : jeonyb4</li>
 * </ul>
 */
@Mapper
public interface OivThresholdMapper {
	/**
	 * 
	 * listPageThreshold
	 *
	 * @param thresholdGridRequestDto
	 * @return List<ThresholdGridResultDto>
	 */
	public List<ThresholdGridResultDto> listPageThreshold(ThresholdGridRequestDto thresholdGridRequestDto);
	
	/**
	 * 
	 * createOivThreshold
	 *
	 * @param reqOivThresholdDto
	 * @return int
	 */
	public int createOivThreshold(OivThresholdDto reqOivThresholdDto);
	
	/**
	 * 
	 * readThreshold
	 *
	 * @param reqOivThresholdDto
	 * @return ThresholdDetailResultDto
	 */
	public ThresholdDetailResultDto readThreshold(OivThresholdDto reqOivThresholdDto);
	
	/**
	 * 
	 * updateOivThreshold
	 *
	 * @param reqOivThresholdDto
	 * @return int
	 */
	public int updateOivThreshold(OivThresholdDto reqOivThresholdDto);
	
	/**
	 * 
	 * deleteOivThreshold
	 *
	 * @param reqOivThresholdDto
	 * @return int
	 */
	public int deleteOivThreshold(OivThresholdDto reqOivThresholdDto);

}
