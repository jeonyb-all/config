package com.adtcaps.tsop.map3d.api.service;

import java.util.List;
import java.util.Map;

import com.adtcaps.tsop.map3d.api.domain.Map3dDeviceCmnVO;
import com.adtcaps.tsop.map3d.api.domain.Map3dDeviceStatusVO;

public interface Map3dService {

	public List<Map<String, Object>> getMap3dFmDeviceInfo(Map3dDeviceStatusVO pMap3dDeviceStatusVO) throws Exception;

	List<Map<String, Object>> getMap3dCctvList(Map3dDeviceStatusVO pMap3dDeviceStatusVO) throws Exception;

	public Map3dDeviceCmnVO getMap3dObjectInfo(String objectId) throws Exception;
}
