package com.adtcaps.tsop.map3d.api.domain;

import java.io.Serializable;
import java.util.List;
import java.util.Map;

import com.fasterxml.jackson.annotation.JsonInclude;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

/**
*
* <ul>
* <li>업무 그룹명 : tsop-backend-api</li>
* <li>서브 업무명 : com.adtcaps.tsop.map3d.controller</li>
* <li>설  명 : Map3dController.java</li>
* <li>작성일 : </li>
* <li>작성자 : </li>
* </ul>
*/
@Getter
@Setter
@ToString
//@JsonInclude(JsonInclude.Include.NON_NULL)
public class Map3dDeviceStatusVO implements Serializable {

	private static final long serialVersionUID = 1L;

	@JsonInclude(JsonInclude.Include.NON_EMPTY)
	private String building_id = "";

	@JsonInclude(JsonInclude.Include.NON_EMPTY)
	private String service_type = "";

	@JsonInclude(JsonInclude.Include.NON_EMPTY)
	private String object_id = "";

	@JsonInclude(JsonInclude.Include.NON_NULL)
	private List<Map<String, Object>> timestamp_list;

	private boolean success;

	private int code;

	private String message = "";

	private String detail = "";

	private List<Map<String, Object>> url_list;

	private List<Map<String, Object>> info_list;
}
