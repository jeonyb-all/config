package com.adtcaps.tsop.map3d.api.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;

import com.adtcaps.tsop.map3d.api.domain.Map3dDeviceCmnVO;

/**
 *
 * <ul>
 * <li>업무 그룹명 : tsop-backend-api</li>
 * <li>서브 업무명 : com.adtcaps.tsop.map3d.mapper</li>
 * <li>설  명 : Map3dMapper.java</li>
 * <li>작성일 : </li>
 * <li>작성자 : </li>
 * </ul>
 */
@Mapper
public interface Map3dMapper {

	public List<Map3dDeviceCmnVO> getMap3dFmDeviceInfo(Map3dDeviceCmnVO pMap3dDeviceCmnVO) throws Exception;

	public Map3dDeviceCmnVO getMap3dElDeviceInfo(Map3dDeviceCmnVO pMap3dDeviceCmnVO) throws Exception;

	public Map3dDeviceCmnVO getMap3dAcEntdoorInfo(Map3dDeviceCmnVO pMap3dDeviceCmnVO) throws Exception;

	public List<Map3dDeviceCmnVO> getMap3dAcEntdoorListByMaindevice(String bbjectId) throws Exception;

	public Map3dDeviceCmnVO getMap3dAcEntdoorListByConsole(String objectId) throws Exception;

	public List<Map3dDeviceCmnVO> getMap3dMappingCctvList(String objectId) throws Exception;

	public List<Map3dDeviceCmnVO> getMap3dCctvList(String objectId) throws Exception;

	public Map3dDeviceCmnVO getMap3dObjectInfo(String objectId) throws Exception;
}
