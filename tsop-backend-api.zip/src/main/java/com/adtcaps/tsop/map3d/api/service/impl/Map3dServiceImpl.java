package com.adtcaps.tsop.map3d.api.service.impl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.adtcaps.tsop.config.InterfaceConfig;
import com.adtcaps.tsop.map3d.api.domain.Map3dDeviceCmnVO;
import com.adtcaps.tsop.map3d.api.domain.Map3dDeviceStatusVO;
import com.adtcaps.tsop.map3d.api.mapper.Map3dMapper;
import com.adtcaps.tsop.map3d.api.service.Map3dService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponents;
import org.springframework.web.util.UriComponentsBuilder;


/**
*
* <ul>
* <li>업무 그룹명 : tsop-backend-api</li>
* <li>서브 업무명 : com.adtcaps.tsop.map3d.service.impl</li>
* <li>설  명 : Map3dServiceImpl.java</li>
* <li>작성일 : </li>
* <li>작성자 : </li>
* </ul>
*/
@Service
public class Map3dServiceImpl implements Map3dService {

	/**
	 *  Map3dMapper mapper
	 */
	@Autowired
	private Map3dMapper map3dMapper;
	
	@Autowired
	private InterfaceConfig interfaceConfig;

	final private String cctvEndPoint = "/api/video/rtsp-url";

	/**
	 *
	 * <pre>
	 *  메소드명 : getMap3dDeviceInfo
	 *  설    명 : 3D맵 장비 정보 조회
	 *  작 성 일 :
	 *  작 성 자 :
	 * </pre>
	 * @param pMap3dDeviceStatusVO
	 * @return
	 */
	public List<Map<String, Object>> getMap3dFmDeviceInfo(Map3dDeviceStatusVO pMap3dDeviceStatusVO) throws Exception {
		List<Map<String, Object>> deviceList = new ArrayList<Map<String, Object>>();
		Map3dDeviceCmnVO pMap3dDeviceCmnVO = new Map3dDeviceCmnVO();
		pMap3dDeviceCmnVO.setBldId(pMap3dDeviceStatusVO.getBuilding_id());
		pMap3dDeviceCmnVO.setServiceClCd(pMap3dDeviceStatusVO.getService_type());
		pMap3dDeviceCmnVO.setObjectId(pMap3dDeviceStatusVO.getObject_id());

		if("FM".equals(pMap3dDeviceStatusVO.getService_type())) { // FM설비
			List<Map3dDeviceCmnVO> resultList = map3dMapper.getMap3dFmDeviceInfo(pMap3dDeviceCmnVO);
			resultList.forEach(result -> {
				Map<String, Object> map = new HashMap<String, Object>();
				map.put("info_name", result.getObjectName());
				map.put("info_value", result.getFacilityCurrentValue());
				map.put("info_unit", result.getMeasureUnitVal());
				deviceList.add(map);
			});

		} else if("EL".equals(pMap3dDeviceStatusVO.getService_type())) { // 엘리베이터
			Map3dDeviceCmnVO result = map3dMapper.getMap3dElDeviceInfo(pMap3dDeviceCmnVO);
			if(result != null) {
				// 위치
				Map<String, Object> map1 = new HashMap<String, Object>();
				map1.put("info_name", "위치");
				String elLocFloor = result.getElevatorLocFloorVal();
				if(elLocFloor.startsWith("0B")) {
					elLocFloor = elLocFloor.substring(1, 2);
				} else {
					int elLocFloorNo = Integer.parseInt(elLocFloor);
					elLocFloor = Integer.toString(elLocFloorNo)+"F";
				}
				map1.put("info_value", elLocFloor);
				map1.put("info_unit", "");
				deviceList.add(map1);
				// 방향
				Map<String, Object> map2 = new HashMap<String, Object>();
				map2.put("info_name", "방향");
				map2.put("info_value", result.getElevatorDirectionVal());
				map2.put("info_unit", "");
				deviceList.add(map2);
				// 도어
				Map<String, Object> map3 = new HashMap<String, Object>();
				map3.put("info_name", "도어");
				map3.put("info_value", result.getElevdoorStatusCd());
				map3.put("info_unit", "");
				deviceList.add(map3);
				// 상태
				Map<String, Object> map4 = new HashMap<String, Object>();
				map4.put("info_name", "상태");
				map4.put("info_value", result.getElevatorStatusCd());
				map4.put("info_unit", "");
				deviceList.add(map4);
			}

		} else if("AC".equals(pMap3dDeviceStatusVO.getService_type())) { // 출입통제
			// 출입통제 타입별 조회
			Map3dDeviceCmnVO map3dDeviceCmnVO = map3dMapper.getMap3dObjectInfo(pMap3dDeviceStatusVO.getObject_id());
			String objectTypeCd = map3dDeviceCmnVO.getObjectTypeCd();
			if ("31".equals(objectTypeCd)) {
				// 주장치 조회
				List<Map3dDeviceCmnVO> resultList = map3dMapper.getMap3dAcEntdoorListByMaindevice(pMap3dDeviceStatusVO.getObject_id());
				resultList.forEach(result -> {
					Map<String, Object> map = new HashMap<String, Object>();
					map.put("info_name", "연결 출입문");
					map.put("info_value", result.getEntdoorName());
					map.put("info_unit", "");
					deviceList.add(map);
				});
			} else if ("32".equals(objectTypeCd)) {
				// 출입문 조회
				Map3dDeviceCmnVO result = map3dMapper.getMap3dAcEntdoorInfo(pMap3dDeviceCmnVO);
				if(result != null) {
					// 주장치명
					Map<String, Object> map1 = new HashMap<String, Object>();
					map1.put("info_name", "주장치명");
					map1.put("info_value", result.getMaindeviceObjectId());
					map1.put("info_unit", "");
					deviceList.add(map1);
					// 도어명
					Map<String, Object> map2 = new HashMap<String, Object>();
					map2.put("info_name", "도어명");
					map2.put("info_value", result.getObjectName());
					map2.put("info_unit", "");
					deviceList.add(map2);
					// 출입문 모드
					Map<String, Object> map3 = new HashMap<String, Object>();
					map3.put("info_name", "출입문 모드");
					map3.put("info_value", result.getEntdoorModeCd());
					map3.put("info_unit", "");
					deviceList.add(map3);
					// 출입문 락
					Map<String, Object> map4 = new HashMap<String, Object>();
					map4.put("info_name", "출입문 락");
					map4.put("info_value", result.getEntdoorLockStatusCd());
					map4.put("info_unit", "");
					deviceList.add(map4);
					// 출입문 센서 상태
					Map<String, Object> map5 = new HashMap<String, Object>();
					map5.put("info_name", "출입문 센서 상태");
					map5.put("info_value", result.getEntdoorSensorStatusCd());
					map5.put("info_unit", "");
					deviceList.add(map5);
				}
			} else if ("33".equals(objectTypeCd)) {
				// 인식기 조회
				Map3dDeviceCmnVO result = map3dMapper.getMap3dAcEntdoorListByConsole(pMap3dDeviceStatusVO.getObject_id());
				if(result != null) {
					Map<String, Object> map1 = new HashMap<String, Object>();
					map1.put("info_name", "연결 출입문");
					map1.put("info_value", result.getEntdoorName());
					map1.put("info_unit", "");
					deviceList.add(map1);
				}
			}
		}

		return deviceList;
	}

	/**
	 *
	 * <pre>
	 *  메소드명 : getMap3dCctvList
	 *  설    명 : 3D맵 CCTV RTSP url 조회
	 *  작 성 일 :
	 *  작 성 자 :
	 * </pre>
	 * @param pMap3dDeviceStatusVO
	 * @return
	 */
	public List<Map<String, Object>> getMap3dCctvList(Map3dDeviceStatusVO pMap3dDeviceStatusVO) throws Exception {
		List<Map<String, Object>> urlList = new ArrayList<Map<String, Object>>();
		
		String cctvUrl = interfaceConfig.getCctvServerInfo().getUrl();
		
		String objectId = pMap3dDeviceStatusVO.getObject_id();
		String serviceType = pMap3dDeviceStatusVO.getService_type();
		String buildingId = pMap3dDeviceStatusVO.getBuilding_id();
		List<Map3dDeviceCmnVO> resultList = new ArrayList<Map3dDeviceCmnVO>();
		// cctv 리스트
		resultList = ("CC".equals(serviceType))? map3dMapper.getMap3dCctvList(objectId):map3dMapper.getMap3dMappingCctvList(objectId);
		resultList.forEach(result -> {
			String devSerial = result.getCctvEquipId();
			String dchCh = result.getChannelId();
			String dchmSerial = "0";
			String restUrl = cctvUrl + cctvEndPoint+"/"+devSerial+"/"+dchCh+"/"+dchmSerial;

			List<Map<String, Object>> timestamp_list = pMap3dDeviceStatusVO.getTimestamp_list();
			timestamp_list.forEach(rtsp -> {
				String rtspTitle = rtsp.get("rtsp_title").toString();
				String speed = rtsp.get("speed").toString();
				String timestamp = rtsp.get("timestamp").toString();
				String queryString = "?speed="+speed;
				queryString += ("realtime".equals(timestamp))? "":"&timestamp="+timestamp;

				/*
				HttpComponentsClientHttpRequestFactory factory = new HttpComponentsClientHttpRequestFactory();
	            factory.setConnectTimeout(5000);
	            factory.setReadTimeout(5000);
	            RestTemplate restTemplate = new RestTemplate(factory);
	            */
				RestTemplate restTemplate = new RestTemplate();
	            HttpHeaders header = new HttpHeaders();
	            header.set("building_id", buildingId);
	            HttpEntity<?> entity = new HttpEntity<>(header);
	            UriComponents uri = UriComponentsBuilder.fromHttpUrl(restUrl+queryString).build();

	            System.out.println("uri.toString()"+uri.toString());
	            @SuppressWarnings("rawtypes")
				ResponseEntity<Map> resultMap = restTemplate.exchange(uri.toString(), HttpMethod.GET, entity, Map.class);
				@SuppressWarnings("unchecked")
				Map<String, Object> content = (Map<String, Object>) resultMap.getBody().get("content");
				boolean success = (boolean) content.get("success");
				if(success) {
					@SuppressWarnings("unchecked")
					Map<String, Object> results = (Map<String, Object>) content.get("results");
					String url = results.get("url").toString();

					Map<String, Object> map = new HashMap<String, Object>();
					map.put("rtsp_title", rtspTitle);
					map.put("url", url);
					urlList.add(map);
				}
			});
		});

		return urlList;
	}

	public Map3dDeviceCmnVO getMap3dObjectInfo(String objectId) throws Exception {
		return map3dMapper.getMap3dObjectInfo(objectId);
	}

}
