package com.adtcaps.tsop.map3d.api.domain;

import java.io.Serializable;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class Map3dDeviceCmnVO implements Serializable {

	private static final long serialVersionUID = 1L;

	// 공통
	private String bldId = "";
	private String serviceClCd = "";
	private String objectId = "";
	private String objectTypeCd = "";

	// FM
	private String superObjectId = "";
	private String objectName = "";
	private String measureUnitVal = "";
	private String facilityCurrentValue = "";

	// AC
	private String maindeviceObjectId = "";
	private String entdoorObjectId = "";
	private String entdoorModeCd = "";
	private String entdoorLockStatusCd = "";
	private String entdoorSensorStatusCd = "";
	private String entdoorName = "";

	// EL
	private String elevatorLocFloorVal = "";
	private String elevatorDirectionVal = "";
	private String elevdoorStatusCd = "";
	private String elevatorStatusCd = "";

	// CCTV
	private String cctvEquipId = "";
	private String channelId = "";

}
