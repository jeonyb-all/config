package com.adtcaps.tsop.map3d.api.controller;

import com.adtcaps.tsop.map3d.api.domain.Map3dDeviceCmnVO;
import com.adtcaps.tsop.map3d.api.domain.Map3dDeviceStatusVO;
import com.adtcaps.tsop.map3d.api.service.Map3dService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import lombok.extern.slf4j.Slf4j;

/**
 *
 * <ul>
 * <li>업무 그룹명 : tsop-backend-api</li>
 * <li>서브 업무명 : com.adtcaps.tsop.map3d.controller</li>
 * <li>설  명 : Map3dController.java</li>
 * <li>작성일 : </li>
 * <li>작성자 : </li>
 * </ul>
 */
@Slf4j
@RestController
@RequestMapping(value = "/api/3d")
public class Map3dController {

	/**
	 * Map3dService service
	 */
	@Autowired
	private Map3dService map3dService;

	// 3d맵 api key 고정
	final private String authApiKey = "d0569057-2f97-4d51-87b6-da61c0147801";

	/**
	 *
	 * <pre>
	 *  메소드명 : getMap3dDeviceInfo
	 *  설    명 : 3D맵 장비 정보 조회
	 *  작 성 일 :
	 *  작 성 자 :
	 * </pre>
	 * @param callKey
	 * @param pMap3dDeviceStatusVO
	 * @return
	 */
	@PostMapping(value="/device/status", produces="application/json; charset=UTF-8")
	public Map3dDeviceStatusVO getMap3dDeviceInfo(@RequestHeader(value="Call-Key") String callKey,
			@RequestBody Map3dDeviceStatusVO pMap3dDeviceStatusVO) throws Exception {

		boolean success;
		int code;
		String message = "";
		String detail = "";
		String serviceType = pMap3dDeviceStatusVO.getService_type();

		if(!authApiKey.equals(callKey)) {
			success = false;
			code = 200;
			message = "Fail";
			detail = "Key Fail";
		} else {
			try {
				// 장비 현재 상태 조회
				if("FM".equals(serviceType)
						|| "EL".equals(serviceType)
						|| "AC".equals(serviceType)) {
					pMap3dDeviceStatusVO.setInfo_list(map3dService.getMap3dFmDeviceInfo(pMap3dDeviceStatusVO));
				}

				// CCTV 조회
				if(pMap3dDeviceStatusVO.getTimestamp_list().size() > 0) {
					pMap3dDeviceStatusVO.setUrl_list(map3dService.getMap3dCctvList(pMap3dDeviceStatusVO));
				}

				success = true;
				code = 200;
				message = "Success";
				detail = "Success to get info";
			} catch(DataAccessException se) {
				success = false;
				code = 200;
				message = "Fail";
				detail = "SQLException";
				log.error(se.getMessage());
			} catch(Exception e) {
				success = false;
				code = 200;
				message = "Fail";
				detail = "Exception";
				log.error(e.getMessage());
			}
	    }

		pMap3dDeviceStatusVO.setTimestamp_list(null);
		pMap3dDeviceStatusVO.setObject_id("");
		pMap3dDeviceStatusVO.setSuccess(success);
		pMap3dDeviceStatusVO.setCode(code);
		pMap3dDeviceStatusVO.setMessage(message);
		pMap3dDeviceStatusVO.setDetail(detail);

		return pMap3dDeviceStatusVO;
	}

	/**
	 *
	 * <pre>
	 *  메소드명 : getMap3dSuperObject
	 *  설    명 : 3D맵 FM 상위 오브젝트 아이디 조회
	 *  작 성 일 :
	 *  작 성 자 :
	 * </pre>
	 * @param callKey
	 * @param objectId
	 * @return
	 */
	@GetMapping(value="/device/objectId/{objectId}", produces="application/json; charset=UTF-8")
	public Map3dDeviceStatusVO getMap3dSuperObject(@RequestHeader(value="Call-Key") String callKey,
			@PathVariable("objectId") String objectId) throws Exception {

		Map3dDeviceStatusVO map3dDeviceStatusVO = new Map3dDeviceStatusVO();
		boolean success;
		String message = "";
		String detail = "";

		if(!authApiKey.equals(callKey)) {
			success = false;
			message = "fail";
			detail = "Key Fail";
		} else {
			try {
				Map3dDeviceCmnVO map3dDeviceCmnVO = map3dService.getMap3dObjectInfo(objectId);
				map3dDeviceStatusVO.setObject_id(map3dDeviceCmnVO.getSuperObjectId());

				success = true;
				message = "Success";
				detail = "";
			} catch(DataAccessException se) {
				success = false;
				message = "fail";
				detail = "SQLException";
				log.error(se.getMessage());
			} catch(Exception e) {
				success = false;
				message = "fail";
				detail = "Exception";
				log.error(e.getMessage());
			}
		}

		map3dDeviceStatusVO.setSuccess(success);
		map3dDeviceStatusVO.setMessage(message);
		map3dDeviceStatusVO.setDetail(detail);

		return map3dDeviceStatusVO;
	}


}
