package com.adtcaps.tsop.config;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.adtcaps.tsop.config.domain.InterfaceDto;

/**
 * 
 * <ul>
 * <li>업무 그룹명 : tsop-backend-api</li>
 * <li>서브 업무명 : com.adtcaps.tsop.config</li>
 * <li>설  명 : InterfaceConfig.java</li>
 * <li>작성일 : 2021. 1. 25.</li>
 * <li>작성자 : jeonyb4</li>
 * </ul>
 */
@Configuration
public class InterfaceConfig {
	
	private static String OS = System.getProperty("os.name").toLowerCase();
	
	/**
	 * 
	 * getInterfaceMyConfig
	 *
	 * @return InterfaceDto
	 */
	@Bean
    @ConfigurationProperties("interface.my")
    public InterfaceDto getInterfaceMyConfig() {
		return new InterfaceDto();
    }
	
	@Bean
	public InterfaceDto getMyServerInfo() {
		InterfaceDto interfaceDto = getInterfaceMyConfig();
		return interfaceDto;
	}
	
	/**
	 * 
	 * getInterfaceOnmConfig
	 *
	 * @return InterfaceDto
	 */
	@Bean
    @ConfigurationProperties("interface.onm")
    public InterfaceDto getInterfaceOnmConfig() {
		return new InterfaceDto();
    }
	
	@Bean
	public InterfaceDto getOnmServerInfo() {
		InterfaceDto interfaceDto = getInterfaceOnmConfig();
		if (OS.indexOf("win") >= 0) {
			interfaceDto.setUrl(interfaceDto.getTestUrl());
		}
		return interfaceDto;
	}
	
	/**
	 * 
	 * getInterfaceSmsConfig
	 *
	 * @return InterfaceDto
	 */
	@Bean
    @ConfigurationProperties("interface.sms")
    public InterfaceDto getInterfaceSmsConfig() {
		return new InterfaceDto();
    }
	
	@Bean
	public InterfaceDto getSmsServerInfo() {
		InterfaceDto interfaceDto = getInterfaceSmsConfig();
		return interfaceDto;
	}
	
	/**
	 * 
	 * getInterfaceDownlinkConfig
	 *
	 * @return InterfaceDto
	 */
	@Bean
    @ConfigurationProperties("interface.downlink")
    public InterfaceDto getInterfaceDownlinkConfig() {
		return new InterfaceDto();
    }
	
	@Bean
	public InterfaceDto getDownlinkServerInfo() {
		InterfaceDto interfaceDto = getInterfaceDownlinkConfig();
		return interfaceDto;
	}
	
	/**
	 * 
	 * getInterfaceBatchConfig
	 *
	 * @return InterfaceDto
	 */
	@Bean
    @ConfigurationProperties("interface.batch")
    public InterfaceDto getInterfaceBatchConfig() {
		return new InterfaceDto();
    }
	
	@Bean
	public InterfaceDto getBatchServerInfo() {
		InterfaceDto interfaceDto = getInterfaceBatchConfig();
		return interfaceDto;
	}
	
	/**
	 * 
	 * getInterfacePushConfig
	 * 
	 * @return InterfaceDto
	 */
	@Bean
    @ConfigurationProperties("interface.push")
    public InterfaceDto getInterfacePushConfig() {
		return new InterfaceDto();
    }
	
	@Bean
	public InterfaceDto getPushServerInfo() {
		InterfaceDto interfaceDto = getInterfacePushConfig();
		return interfaceDto;
	}
	
	/**
	 * 
	 * getInterfaceCctvConfig
	 *
	 * @return InterfaceDto
	 */
	@Bean
    @ConfigurationProperties("interface.cctv")
    public InterfaceDto getInterfaceCctvConfig() {
		return new InterfaceDto();
    }
	
	@Bean
	public InterfaceDto getCctvServerInfo() {
		InterfaceDto interfaceDto = getInterfaceCctvConfig();
		return interfaceDto;
	}
	
	/**
	 * 
	 * getInterfaceParkingConfig
	 *
	 * @return InterfaceDto
	 */
	@Bean
    @ConfigurationProperties("interface.parking")
    public InterfaceDto getInterfaceParkingConfig() {
		return new InterfaceDto();
    }
	
	@Bean
	public InterfaceDto getParkingServerInfo() {
		InterfaceDto interfaceDto = getInterfaceParkingConfig();
		return interfaceDto;
	}

}
