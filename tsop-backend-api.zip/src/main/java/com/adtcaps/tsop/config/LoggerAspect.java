package com.adtcaps.tsop.config;

import lombok.extern.slf4j.Slf4j;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.springframework.stereotype.Component;

/**
 * 
 * <ul>
 * <li>업무 그룹명 : tsop-backend-api</li>
 * <li>서브 업무명 : com.adtcaps.tsop.config</li>
 * <li>설  명 : LoggerAspect.java</li>
 * <li>작성일 : 2020. 12. 4.</li>
 * <li>작성자 : jeonyb4</li>
 * </ul>
 */
@Slf4j
@Component
@Aspect
public class LoggerAspect {

    @Around("bean(*ServiceImpl)")
    public Object logPrint(ProceedingJoinPoint joinPoint) throws Throwable {
        log.debug("{}.{} called", joinPoint.getSignature().getDeclaringTypeName(), joinPoint.getSignature().getName());
        return joinPoint.proceed();
    }
}