package com.adtcaps.tsop.config;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.adtcaps.tsop.config.domain.AzureBlobDto;
import com.azure.storage.blob.BlobServiceClient;
import com.azure.storage.blob.BlobServiceClientBuilder;
import com.azure.storage.common.StorageSharedKeyCredential;

/**
 * 
 * <ul>
 * <li>업무 그룹명 : tsop-backend-api</li>
 * <li>서브 업무명 : com.adtcaps.tsop.config</li>
 * <li>설  명 : AzureBlobConfig.java</li>
 * <li>작성일 : 2020. 12. 4.</li>
 * <li>작성자 : jeonyb4</li>
 * </ul>
 */
@Configuration
public class AzureBlobConfig {
	
	private static String OS = System.getProperty("os.name").toLowerCase();
	
	/**
	 * 
	 * getAzureBlobConfig
	 *
	 * @return AzureBlobDto
	 */
	@Bean
    @ConfigurationProperties("azure.blob")
    public AzureBlobDto getAzureBlobConfig() {
		return new AzureBlobDto();
    }
	
	/**
	 * 
	 * getAzureBlobInfo
	 *
	 * @return AzureBlobDto
	 */
	@Bean
	public AzureBlobDto getAzureBlobInfo() {
		
		AzureBlobDto azureBlobDto = getAzureBlobConfig();
		if (OS.indexOf("win") >= 0) {
			azureBlobDto.setUploadTempBasePath(azureBlobDto.getWinUploadTempBasePath());
			azureBlobDto.setDownloadTempBasePath(azureBlobDto.getWinDownloadTempBasePath());
		}
		
		// 계정 키를 사용하여 연결
		StorageSharedKeyCredential storageSharedKeyCredential = new StorageSharedKeyCredential(azureBlobDto.getAccountName(), azureBlobDto.getAccountKey());
		
		StringBuilder endpointBuilder = new StringBuilder();
	    endpointBuilder.append("https://");
	    endpointBuilder.append(azureBlobDto.getAccountName());
	    endpointBuilder.append(".blob.core.windows.net");
	    
		BlobServiceClient blobServiceClient = new BlobServiceClientBuilder().endpoint(endpointBuilder.toString()).credential(storageSharedKeyCredential).buildClient();
		
		azureBlobDto.setBlobServiceClient(blobServiceClient);
		
		return azureBlobDto;
	}

}
