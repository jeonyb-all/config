package com.adtcaps.tsop.config;

import java.util.Arrays;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Import;
import org.springframework.web.servlet.HandlerInterceptor;
import org.springframework.web.servlet.config.annotation.EnableWebMvc;
import org.springframework.web.servlet.config.annotation.InterceptorRegistry;
import org.springframework.web.servlet.config.annotation.ResourceHandlerRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

import springfox.documentation.builders.ApiInfoBuilder;
import springfox.documentation.builders.PathSelectors;
import springfox.documentation.builders.RequestHandlerSelectors;
import springfox.documentation.service.ApiKey;
import springfox.documentation.service.AuthorizationScope;
import springfox.documentation.service.SecurityReference;
import springfox.documentation.spi.DocumentationType;
import springfox.documentation.spi.service.contexts.SecurityContext;
import springfox.documentation.spring.data.rest.configuration.SpringDataRestConfiguration;
import springfox.documentation.spring.web.plugins.Docket;
import springfox.documentation.swagger2.annotations.EnableSwagger2;

@Configuration
@EnableSwagger2
@EnableWebMvc
@Import(SpringDataRestConfiguration.class)
public class SwaggerConfig implements WebMvcConfigurer, HandlerInterceptor {
	
    @Bean
    public Docket apiV2() {
        return new Docket(DocumentationType.SWAGGER_2)
        		.groupName("grp")
                .apiInfo(new ApiInfoBuilder()
                        .title("TSOP Backend 서비스 APIs")
                        .description("TSOP Backend 서비스 API")
                        .version("v1")
                        .build())
                .securityContexts(Arrays.asList(securityContext()))
                //.securitySchemes(Arrays.asList(apiKey()))
                .select()
                //.apis(RequestHandlerSelectors.basePackage("com.adtcaps.tsop"))
                //.apis(RequestHandlerSelectors.basePackage("com.adtcaps.tsop.portal.api.hvac.controller"))
                .apis(RequestHandlerSelectors.basePackage("com.adtcaps.tsop.portal.api.staffMgmt.controller"))
                .paths(PathSelectors.any())
                .build();
    }
    
    @Bean
    public Docket apiV21() {
        return new Docket(DocumentationType.SWAGGER_2)
        		.groupName("grp2")
                .apiInfo(new ApiInfoBuilder()
                        .title("TSOP Backend 서비스 APIsxx")
                        .description("TSOP Backend 서비스 APIxx")
                        .version("v2")
                        .build())
                .securityContexts(Arrays.asList(securityContext()))
                //.securitySchemes(Arrays.asList(apiKey()))
                .select()
                //.apis(RequestHandlerSelectors.basePackage("com.adtcaps.tsop"))
                //.apis(RequestHandlerSelectors.basePackage("com.adtcaps.tsop.portal.api.hvac.controller"))
                //.apis(RequestHandlerSelectors.basePackage("com.adtcaps.tsop.portal.api.staffMgmt.controller"))
                .paths(PathSelectors.any())
                .build();
    }
    private ApiKey apiKey() {
        return new ApiKey("JWT", "Authorization", "header");
    }

    private SecurityContext securityContext() {
        return springfox
                .documentation
                .spi.service
                .contexts
                .SecurityContext
                .builder()
                .securityReferences(defaultAuth()).build();
    }

    List<SecurityReference> defaultAuth() {
        AuthorizationScope authorizationScope = new AuthorizationScope("global", "accessEverything");
        AuthorizationScope[] authorizationScopes = new AuthorizationScope[1];
        authorizationScopes[0] = authorizationScope;
        return Arrays.asList(new SecurityReference("JWT", authorizationScopes));
    }
    
    @Override
    public void addResourceHandlers(ResourceHandlerRegistry registry) {
    	registry.addResourceHandler("swagger-ui.html").addResourceLocations("classpath:/META-INF/resources/");
    	registry.addResourceHandler("/webjars/**") .addResourceLocations("classpath:/META-INF/resources/webjars/");
    }
    
    @Override
    public void addInterceptors(InterceptorRegistry registry) {
		registry.addInterceptor(this)
        .addPathPatterns("/swagger-ui/**") //해당 경로에 접근하기 전에 인터셉터가 가로챈다.
        .addPathPatterns("/v2/api*/**")
        .addPathPatterns("/configuration/**")
        .addPathPatterns("/webjars/**")
		;
		return;
	}
    
    @Override
    public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler ) throws Exception {
        String clientIp = request.getRemoteAddr();
        String url = request.getRequestURI();
        
        //swagger는 local에서만 접근하도록 block
        if(url != null) {
        	if(url.startsWith("/swagger-ui") ||
        		url.startsWith("/v2/api") ||
        		url.startsWith("/configuration") ||
        		url.startsWith("/webjars")
        		) {
        		if("0:0:0:0:0:0:0:1".equals(clientIp) || "127.0.0.1".equals(clientIp) || "localhost".equals(clientIp)) {
        			return true;
        		}
        	}
        }
        return true;
    }
}