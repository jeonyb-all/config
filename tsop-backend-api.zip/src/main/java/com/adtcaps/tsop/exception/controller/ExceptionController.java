package com.adtcaps.tsop.exception.controller;

import java.util.HashMap;
import java.util.Map;

import org.springframework.http.HttpStatus;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestControllerAdvice;

import com.adtcaps.tsop.helper.constant.Const;
import com.adtcaps.tsop.helper.domain.ResultDto;
import com.google.gson.Gson;

import lombok.extern.slf4j.Slf4j;

/**
 * 
 * <ul>
 * <li>업무 그룹명 : tsop-backend-api</li>
 * <li>서브 업무명 : com.adtcaps.tsop.exception.controller</li>
 * <li>설 명 : ExceptionController.java</li>
 * <li>작성일 : 2021. 2. 8.</li>
 * <li>작성자 : jeonyb4</li>
 * </ul>
 */
@Slf4j
@RestControllerAdvice
public class ExceptionController {

//	@ResponseStatus(HttpStatus.BAD_REQUEST)
//	@ExceptionHandler(MethodArgumentNotValidException.class)
//	public Map<String, String> handleValidationExceptions(MethodArgumentNotValidException ex) {
//		Map<String, String> errors = new HashMap<>();
//		ex.getBindingResult().getAllErrors().forEach((error) -> {
//			String fieldName = ((FieldError) error).getField();
//			String errorMessage = error.getDefaultMessage();
//			errors.put(fieldName, errorMessage);
//		});
//		return errors;
//	}
	@ResponseStatus(HttpStatus.BAD_REQUEST)
	@ExceptionHandler(MethodArgumentNotValidException.class)
	public @ResponseBody ResultDto handleValidationExceptions(MethodArgumentNotValidException ex) {
		log.error(ex.getMessage(), ex);
		
		Map<String, String> errors = new HashMap<>();
		ex.getBindingResult().getAllErrors().forEach((error) -> {
			String fieldName = ((FieldError) error).getField();
			String errorMessage = error.getDefaultMessage();
			errors.put(fieldName, errorMessage);
		});

		Gson gson = new Gson();
	    String errorString = gson.toJson(errors);

		ResultDto resultDto = new ResultDto(Const.Common.RESULT_CODE.FAIL, errorString);
		return resultDto;
	}
	
	@ExceptionHandler
	public @ResponseBody ResultDto handleAll(final Exception ex) {
		log.error(ex.getMessage(), ex);
		ResultDto resultDto = new ResultDto(Const.Common.RESULT_CODE.FAIL, "서버 오류가 발생하였습니다. 관리자에게 문의해 주세요.");
		return resultDto;
	}
}
