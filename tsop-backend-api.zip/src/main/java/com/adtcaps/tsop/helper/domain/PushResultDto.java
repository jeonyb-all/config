package com.adtcaps.tsop.helper.domain;

import lombok.Getter;
import lombok.Setter;

/**
 * 
 * <ul>
 * <li>업무 그룹명 : tsop-backend-api</li>
 * <li>서브 업무명 : com.adtcaps.tsop.helper.domain</li>
 * <li>설  명 : PushResultDto.java</li>
 * <li>작성일 : 2021. 11. 16.</li>
 * <li>작성자 : jeonyb4</li>
 * </ul>
 */
@Getter
@Setter
public class PushResultDto {
	private String result;
	private String resultMsg;

}
