package com.adtcaps.tsop.helper.util;

import java.util.List;
import org.springframework.beans.BeanUtils;
import org.springframework.util.CollectionUtils;

import com.adtcaps.tsop.helper.domain.BasePageDto;

/**
 * 
 * <ul>
 * <li>업무 그룹명 : tsop-backend-api</li>
 * <li>서브 업무명 : com.adtcaps.tsop.helper.util</li>
 * <li>설  명 : PageUtil.java</li>
 * <li>작성일 : 2020. 12. 4.</li>
 * <li>작성자 : jeonyb4</li>
 * </ul>
 */
public class PageUtil {
	/**
	 * 
	 * getPageInfo
	 *
	 * @param list
	 * @return BasePageDto
	 */
	public static BasePageDto getPageInfo(List<?> list) {
		if (CollectionUtils.isEmpty(list)) {
			return null;
		}
		Object object = list.get(0);
		BasePageDto basePageDto = new BasePageDto();
		BeanUtils.copyProperties(object, basePageDto);
		
		return basePageDto;
	}

}
