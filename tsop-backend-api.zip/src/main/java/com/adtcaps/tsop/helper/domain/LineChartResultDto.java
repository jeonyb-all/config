package com.adtcaps.tsop.helper.domain;

import java.util.List;

import lombok.Getter;
import lombok.Setter;

/**
 * 
 * <ul>
 * <li>업무 그룹명 : tsop-backend-api</li>
 * <li>서브 업무명 : com.adtcaps.tsop.helper.domain</li>
 * <li>설  명 : LineChartResultDto.java</li>
 * <li>작성일 : 2020. 12. 21.</li>
 * <li>작성자 : jeonyb4</li>
 * </ul>
 */
@Getter
@Setter
public class LineChartResultDto {
	private List<String> categories;
	private List<LineChartDataDto> lineDatas;
	private List<LineChartPointDataDto> linePointDatas;
	private List<Integer> barDatas;
	private List<Double> barPointDatas;
	private List<Double> barOtherPointDatas;
	private Integer totalCount;

}
