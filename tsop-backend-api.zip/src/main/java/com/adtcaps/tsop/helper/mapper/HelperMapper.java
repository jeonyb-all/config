package com.adtcaps.tsop.helper.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;

import com.adtcaps.tsop.dashboard.api.common.domain.GuideScheduleRequestDto;
import com.adtcaps.tsop.helper.domain.ChartRequestDto;
import com.adtcaps.tsop.helper.domain.DateCalculateRequestDto;
import com.adtcaps.tsop.helper.domain.WeekMinMaxDateDto;

/**
 * 
 * <ul>
 * <li>업무 그룹명 : tsop-backend-api</li>
 * <li>서브 업무명 : com.adtcaps.tsop.helper.mapper</li>
 * <li>설  명 : HelperMapper.java</li>
 * <li>작성일 : 2020. 12. 4.</li>
 * <li>작성자 : jeonyb4</li>
 * </ul>
 */
@Mapper
public interface HelperMapper {
	
	/**
	 * 
	 * readCurrentDate
	 *
	 * @return String
	 */
	public String readCurrentDate();
	
	/**
	 * 
	 * readCurrentTime
	 *
	 * @return String
	 */
	public String readCurrentTime();
	
	/**
	 * 
	 * readCalculateMinuteDatetime
	 * 
	 * @param addMinute
	 * @return String
	 */
	public String readCalculateMinuteDatetime(int addMinute);
	
	/**
	 * 
	 * readCalculateSomeDate
	 *
	 * @param dateCalculateRequestDto
	 * @return String
	 */
	public String readCalculateSomeDate(DateCalculateRequestDto dateCalculateRequestDto);
	
	/**
	 * 
	 * readCalculateSomeYearDate
	 * 
	 * @param dateCalculateRequestDto
	 * @return String
	 */
	public String readCalculateSomeYearDate(DateCalculateRequestDto dateCalculateRequestDto);
	
	/**
	 * 
	 * readCurrentDatetimeRoundupHour
	 *
	 * @return String
	 */
	public String readCurrentDatetimeRoundupHour();
	
	/**
	 * 
	 * readCurrentMinuteFloor15Minute
	 * 
	 * @return String
	 */
	public String readCurrentMinuteFloor15Minute();
	
	/**
	 * 
	 * readBeforeWeekDate
	 *
	 * @return String
	 */
	public String readBeforeWeekDate();
	
	/**
	 * 
	 * readBeforeMonthDate
	 *
	 * @return String
	 */
	public String readBeforeMonthDate();
	
	/**
	 * 
	 * readBeforeYearDate
	 *
	 * @return String
	 */
	public String readBeforeYearDate();
	
	/**
	 * 
	 * readBeforeYearSomeDate
	 * 
	 * @return String
	 */
	public String readBeforeYearSomeDate(String someDate);
	
	/**
	 * 
	 * readCurrentDatetime
	 *
	 * @return String
	 */
	public String readCurrentDatetime();
	
	/**
	 * 
	 * readCurrentMilliSeconds
	 *
	 * @return String
	 */
	public String readCurrentMilliSeconds();
	
	/**
	 * 
	 * readCurrentWeek
	 *
	 * @param currentYyyymmdd
	 * @return Integer
	 */
	public Integer readCurrentWeek(String currentYyyymmdd);
	
	/**
	 * 
	 * readMaxWeek
	 *
	 * @param firstYyyymmdd
	 * @return Integer
	 */
	public Integer readMaxWeek(String firstYyyymmdd);
	
	/**
	 * 
	 * readWeekMinMaxDate
	 *
	 * @param inputYyyyMmWeek
	 * @return WeekMinMaxDateDto
	 */
	public WeekMinMaxDateDto readWeekMinMaxDate(String inputYyyyMmWeek);
	
	/**
	 * 
	 * readWeekMinMaxDateFromMondayToSunday
	 * 
	 * @param inputYyyyMmWeek
	 * @return WeekMinMaxDateDto
	 */
	public WeekMinMaxDateDto readWeekMinMaxDateFromMondayToSunday(String inputYyyyMmWeek);
	
	/**
	 * 
	 * list15MinuteGap
	 * 
	 * @param chartRequestDto
	 * @return List<String>
	 */
	public List<String> list15MinuteGap(ChartRequestDto chartRequestDto);
	
	/**
	 * 
	 * readMonthFirstDate
	 * 
	 * @param inputDate
	 * @return String
	 */
	public String readMonthFirstDate(String inputDate);
	
	/**
	 * 
	 * readMonthLastDate
	 * 
	 * @param inputDate
	 * @return String
	 */
	public String readMonthLastDate(String inputDate);
	
	/**
	 * 
	 * readQuarterFirstDate
	 * 
	 * @param inputDate
	 * @return String
	 */
	public String readQuarterFirstDate(String inputDate);
	
	/**
	 * 
	 * readQuarterLastDate
	 * 
	 * @param inputDate
	 * @return String
	 */
	public String readQuarterLastDate(String inputDate);
	
	/**
	 * 
	 * readYearFirstDate
	 * 
	 * @param inputDate
	 * @return String
	 */
	public String readYearFirstDate(String inputDate);
	
	/**
	 * 
	 * readYearLastDate
	 * 
	 * @param inputDate
	 * @return String
	 */
	public String readYearLastDate(String inputDate);
	
	/**
	 * 
	 * readHangulDay
	 * 
	 * @param inputDate
	 * @return String
	 */
	public String readHangulDay(String inputDate);
	
	/**
	 * 
	 * listCalendarYyyymm
	 * 
	 * @param guideScheduleRequestDto
	 * @return List<String>
	 */
	public List<String> listCalendarYyyymm(GuideScheduleRequestDto guideScheduleRequestDto);
	
	/**
	 * 
	 * list12HourFromCurrentTime
	 * 
	 * @return List<String>
	 */
	public List<String> list12HourFromCurrentTime();
	
}
