package com.adtcaps.tsop.helper.domain;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

import lombok.Getter;
import lombok.Setter;

/**
 * 
 * <ul>
 * <li>업무 그룹명 : tsop-backend-api</li>
 * <li>서브 업무명 : com.adtcaps.tsop.helper.domain</li>
 * <li>설  명 : BasePageDto.java</li>
 * <li>작성일 : 2020. 12. 4.</li>
 * <li>작성자 : jeonyb4</li>
 * </ul>
 */
@Getter
@Setter
@JsonInclude(Include.NON_EMPTY)
public class BasePageDto {
	// 검색조건옵션명 (제목, 내용, 작성자 등)
	private String searchOptionName;
	// 검색조건옵션값 (검색조건옵션명에 대한 값)
	private String searchOptionValue;
	// 검색입력값
	private String searchKeyword;
	// 조회시작시간
	private String fromDate;
	// 조회시작시간
	private String toDate;
	// 빌딩ID
	private String bldId;
	// 엑셀다운로드 여부
	private String excelYn;
	// 표시할 페이지 번호
	private Integer pageNumber;
	// 한페이지에 표시할 데이터의 건수
	private Integer rowPerPage;
	// 조회된 총 데이터의 건수
	private Long totalCount;
	// 표시할 총 페이지의 건수
	private Integer totalPage;
	// 정렬
	private String orderBy;
	
	public BasePageDto() {
		this.searchOptionName = "";
		this.searchOptionValue = "";
		this.searchKeyword = "";
		this.fromDate = "";
		this.toDate = "";
		this.bldId = "";
		this.excelYn = "N";
		this.pageNumber = 0;
		this.rowPerPage = 10;
		this.orderBy = "";
	}
	
}
