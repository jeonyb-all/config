package com.adtcaps.tsop.helper.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.adtcaps.tsop.dashboard.api.common.domain.GuideScheduleRequestDto;
import com.adtcaps.tsop.helper.domain.ChartRequestDto;
import com.adtcaps.tsop.helper.domain.DateCalculateRequestDto;
import com.adtcaps.tsop.helper.domain.WeekMinMaxDateDto;
import com.adtcaps.tsop.helper.mapper.HelperMapper;
import com.adtcaps.tsop.helper.service.HelperService;

/**
 * 
 * <ul>
 * <li>업무 그룹명 : tsop-backend-api</li>
 * <li>서브 업무명 : com.adtcaps.tsop.helper.service.impl</li>
 * <li>설  명 : HelperServiceImpl.java</li>
 * <li>작성일 : 2020. 12. 4.</li>
 * <li>작성자 : jeonyb4</li>
 * </ul>
 */
@Service
public class HelperServiceImpl implements HelperService {
	
	@Autowired
	private HelperMapper helperMapper;
	
	/**
	 * 
	 * readCurrentDate
	 *
	 * @return String
	 */
	@Override
	public String readCurrentDate() {
		return helperMapper.readCurrentDate();
	}
	
	/**
	 * 
	 * readCurrentTime
	 *
	 * @return String
	 */
	@Override
	public String readCurrentTime() {
		return helperMapper.readCurrentTime();
	}
	
	/**
	 * 
	 * readCalculateMinuteDatetime
	 * 
	 * @param addMinute
	 * @return String
	 */
	@Override
	public String readCalculateMinuteDatetime(int addMinute) {
		return helperMapper.readCalculateMinuteDatetime(addMinute);
	}
	
	/**
	 * 
	 * readCalculateSomeDate
	 *
	 * @param dateCalculateRequestDto
	 * @return String
	 */
	@Override
	public String readCalculateSomeDate(DateCalculateRequestDto dateCalculateRequestDto) {
		return helperMapper.readCalculateSomeDate(dateCalculateRequestDto);
	}
	
	/**
	 * 
	 * readCalculateSomeYearDate
	 * 
	 * @param dateCalculateRequestDto
	 * @return String
	 */
	@Override
	public String readCalculateSomeYearDate(DateCalculateRequestDto dateCalculateRequestDto) {
		return helperMapper.readCalculateSomeYearDate(dateCalculateRequestDto);
	}
	
	/**
	 * 
	 * readCurrentDatetimeRoundupHour
	 *
	 * @return String
	 */
	@Override
	public String readCurrentDatetimeRoundupHour() {
		return helperMapper.readCurrentDatetimeRoundupHour();
	}
	
	/**
	 * 
	 * readCurrentMinuteFloor15Minute
	 * 
	 * @return String
	 */
	@Override
	public String readCurrentMinuteFloor15Minute() {
		return helperMapper.readCurrentMinuteFloor15Minute();
	}
	
	/**
	 * 
	 * readBeforeWeekDate
	 *
	 * @return String
	 */
	@Override
	public String readBeforeWeekDate() {
		return helperMapper.readBeforeWeekDate();
	}
	
	/**
	 * 
	 * readBeforeMonthDate
	 *
	 * @return String
	 */
	@Override
	public String readBeforeMonthDate() {
		return helperMapper.readBeforeMonthDate();
	}
	
	/**
	 * 
	 * readBeforeYearDate
	 *
	 * @return String
	 */
	@Override
	public String readBeforeYearDate() {
		return helperMapper.readBeforeYearDate();
	}
	
	/**
	 * 
	 * readBeforeYearSomeDate
	 * 
	 * @param someDate
	 * @return String
	 */
	@Override
	public String readBeforeYearSomeDate(String someDate) {
		return helperMapper.readBeforeYearSomeDate(someDate);
	}
	
	/**
	 * 
	 * readCurrentDatetime
	 *
	 * @return String
	 */
	@Override
	public String readCurrentDatetime() {
		return helperMapper.readCurrentDatetime();
	}
	
	/**
	 * 
	 * readCurrentMilliSeconds
	 *
	 * @return String
	 */
	@Override
	public String readCurrentMilliSeconds() {
		return helperMapper.readCurrentMilliSeconds();
	}
	
	/**
	 * 
	 * readCurrentWeek
	 *
	 * @param currentYyyymmdd
	 * @return Integer
	 */
	@Override
	public Integer readCurrentWeek(String currentYyyymmdd) {
		return helperMapper.readCurrentWeek(currentYyyymmdd);
	}
	
	/**
	 * 
	 * readMaxWeek
	 *
	 * @param firstYyyymmdd
	 * @return Integer
	 */
	@Override
	public Integer readMaxWeek(String firstYyyymmdd) {
		return helperMapper.readMaxWeek(firstYyyymmdd);
	}
	
	/**
	 * 
	 * readWeekMinMaxDate
	 *
	 * @param inputYyyyMmWeek
	 * @return WeekMinMaxDateDto
	 */
	@Override
	public WeekMinMaxDateDto readWeekMinMaxDate(String inputYyyyMmWeek) {
		return helperMapper.readWeekMinMaxDate(inputYyyyMmWeek);
	}
	
	/**
	 * 
	 * readWeekMinMaxDateFromMondayToSunday
	 * 
	 * @param inputYyyyMmWeek
	 * @return WeekMinMaxDateDto
	 */
	@Override
	public WeekMinMaxDateDto readWeekMinMaxDateFromMondayToSunday(String inputYyyyMmWeek) {
		return helperMapper.readWeekMinMaxDateFromMondayToSunday(inputYyyyMmWeek);
	}
	
	/**
	 * 
	 * list15MinuteGap
	 * 
	 * @param chartRequestDto
	 * @return List<String>
	 */
	@Override
	public List<String> list15MinuteGap(ChartRequestDto chartRequestDto) {
		return helperMapper.list15MinuteGap(chartRequestDto);
	}
	
	/**
	 * 
	 * readMonthFirstDate
	 * 
	 * @param inputDate
	 * @return String
	 */
	@Override
	public String readMonthFirstDate(String inputDate) {
		return helperMapper.readMonthFirstDate(inputDate);
	}
	
	/**
	 * 
	 * readMonthLastDate
	 * 
	 * @param inputDate
	 * @return String
	 */
	@Override
	public String readMonthLastDate(String inputDate) {
		return helperMapper.readMonthLastDate(inputDate);
	}
	
	/**
	 * 
	 * readQuarterFirstDate
	 * 
	 * @param inputDate
	 * @return String
	 */
	@Override
	public String readQuarterFirstDate(String inputDate) {
		return helperMapper.readQuarterFirstDate(inputDate);
	}
	
	/**
	 * 
	 * readQuarterLastDate
	 * 
	 * @param inputDate
	 * @return String
	 */
	@Override
	public String readQuarterLastDate(String inputDate) {
		return helperMapper.readQuarterLastDate(inputDate);
	}
	
	/**
	 * 
	 * readYearFirstDate
	 * 
	 * @param inputDate
	 * @return String
	 */
	@Override
	public String readYearFirstDate(String inputDate) {
		return helperMapper.readYearFirstDate(inputDate);
	}
	
	/**
	 * 
	 * readYearLastDate
	 * 
	 * @param inputDate
	 * @return String
	 */
	@Override
	public String readYearLastDate(String inputDate) {
		return helperMapper.readYearLastDate(inputDate);
	}
	
	/**
	 * 
	 * readHangulDay
	 * 
	 * @param inputDate
	 * @return String
	 */
	@Override
	public String readHangulDay(String inputDate) {
		return helperMapper.readHangulDay(inputDate);
	}
	
	/**
	 * 
	 * listCalendarYyyymm
	 * 
	 * @param guideScheduleRequestDto
	 * @return List<String>
	 */
	@Override
	public List<String> listCalendarYyyymm(GuideScheduleRequestDto guideScheduleRequestDto) {
		return helperMapper.listCalendarYyyymm(guideScheduleRequestDto);
	}
	
	/**
	 * 
	 * list12HourFromCurrentTime
	 * 
	 * @return List<String>
	 */
	@Override
	public List<String> list12HourFromCurrentTime() {
		return helperMapper.list12HourFromCurrentTime();
	}

}
