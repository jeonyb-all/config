package com.adtcaps.tsop.helper.util;

import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.text.DecimalFormat;
import java.util.Iterator;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.commons.lang3.StringUtils;
import org.springframework.context.MessageSource;

import com.fasterxml.jackson.databind.ObjectMapper;

/**
 * 
 * <ul>
 * <li>업무 그룹명 : tsop-backend-api</li>
 * <li>서브 업무명 : com.adtcaps.tsop.helper.util</li>
 * <li>설  명 : CommonObjectUtil.java</li>
 * <li>작성일 : 2020. 12. 4.</li>
 * <li>작성자 : jeonyb4</li>
 * </ul>
 */
public class CommonObjectUtil {
	/**
	 * 
	 * convertMapToObject
	 * 
	 * @param map
	 * @param objClass
	 * @return Object
	 */
	public static Object convertMapToObject(Map<String, Object> map, Object objClass) {
		String keyAttribute = null;
		String setMethodString = "set";
		String methodString = null;
		Iterator<?> itr = map.keySet().iterator();
		while (itr.hasNext()) {
			keyAttribute = (String)itr.next();
			methodString = setMethodString + keyAttribute.substring(0, 1).toUpperCase() + keyAttribute.substring(1);
			try {
				Method[] methods = objClass.getClass().getDeclaredMethods();
				for (int i=0; i <= methods.length-1; i++) {
					if (methodString.equals(methods[i].getName())) {
						Field field = objClass.getClass().getDeclaredField(keyAttribute);
						String fieldType = field.getType().toString();
						if (fieldType.indexOf("String") > -1) {
							methods[i].invoke(objClass, map.get(keyAttribute).toString());
						} else if (fieldType.indexOf("int") > -1) {
							methods[i].invoke(objClass, Integer.parseInt(map.get(keyAttribute).toString()));
						} else if (fieldType.indexOf("long") > -1) {
							methods[i].invoke(objClass, Long.parseLong(map.get(keyAttribute).toString()));
						} else if (fieldType.indexOf("double") > -1) {
							methods[i].invoke(objClass, Double.parseDouble(map.get(keyAttribute).toString()));
						} else {
							methods[i].invoke(objClass, map.get(keyAttribute).toString());
						}
					}
				}
			} catch (SecurityException e) {
				return null;
			} catch (IllegalAccessException e) {
				return null;
			} catch (IllegalArgumentException e) {
				return null;
			} catch (InvocationTargetException e) {
				return null;
			} catch (NoSuchFieldException e) {
				return null;
			}
		}
		return objClass;
	}
	
	/**
	 * 
	 * objectMapperQparam
	 *
	 * @param q
	 * @param clazz
	 * @param messageSource
	 * @return Object
	 */
	public static Object objectMapperQparam(String q, Class<?> clazz, MessageSource messageSource) {
        ObjectMapper mapper = new ObjectMapper();
        Object object = null;
        try {
            object =  mapper.readValue(q, clazz);
        } catch (Exception e) {
            return null;
        }
        
        return object;
    }
	
	/**
	 * 
	 * defaultNumber
	 * 
	 * @param intValue
	 * @return Integer
	 */
	public static Integer defaultNumber(Integer intValue) {
		if (intValue == null) {
			return 0;
		} else {
			return intValue;
		}
	}
	
	/**
	 * 
	 * defaultNumber
	 * 
	 * @param longValue
	 * @return Long
	 */
	public static Long defaultNumber(Long longValue) {
		if (longValue == null) {
			return 0L;
		} else {
			return longValue;
		}
	}
	
	/**
	 * 
	 * defaultNumber
	 * 
	 * @param doubleValue
	 * @return Double
	 */
	public static Double defaultNumber(Double doubleValue) {
		if (doubleValue == null) {
			return 0D;
		} else {
			return doubleValue;
		}
	}
	
	/**
	 * 
	 * getPegValFormat
	 * 
	 * @param object
	 * @return String
	 */
	public static String getPegValFormat(Object object) {
		if (object == null) {
			return "";
		}
		String pegValFormat = "";
		if (object instanceof Integer) {
			int intValue = (Integer)object;
			DecimalFormat df = new DecimalFormat("#,##0");
			pegValFormat = df.format(intValue);
		} else if (object instanceof Long) {
			long longValue = (Long)object;
			DecimalFormat df = new DecimalFormat("#,##0");
			pegValFormat = df.format(longValue);
		} else if (object instanceof Float) {
			float floatValue = (Float)object;
			double roundFloatValue = Math.round(floatValue * 100) / 100.0;
			DecimalFormat df = new DecimalFormat("#,##0.00");
			pegValFormat = df.format(roundFloatValue);
		} else if (object instanceof Double) {
			double doubleValue = (Double)object;
			double roundDoubleValue = Math.round(doubleValue * 100) / 100.0;
			DecimalFormat df = new DecimalFormat("#,##0.00");
			pegValFormat = df.format(roundDoubleValue);
		} else {
			return "";
		}
		
		return pegValFormat;
	}
	
	/**
	 * 
	 * isNumericType
	 * 
	 * @param object
	 * @return boolean
	 */
	public static boolean isNumericType(Object object) {
		if (object instanceof Integer) {
			return true;
		} else if (object instanceof Long) {
			return true;
		} else if (object instanceof Float) {
			return true;
		} else if (object instanceof Double) {
			return true;
		} else {
			return false;
		}
	}
	
	/**
	 * 
	 * makeRandomPassword
	 *
	 * @return String
	 */
	public static String makeRandomPassword() {
		char pwCollection[] = new char[] {
                '1','2','3','4','5','6','7','8','9','0',
                'A','B','C','D','E','F','G','H','I','J','K','L','M','N','O','P','Q','R','S','T','U','V','W','X','Y','Z',
                'a','b','c','d','e','f','g','h','i','j','k','l','m','n','o','p','q','r','s','t','u','v','w','x','y','z'};
		
		String randomPassword = "";
		for (int i = 0; i < 10; i++) {
			int selectRandomPw = (int)(Math.random()*(pwCollection.length));
			randomPassword += pwCollection[selectRandomPw];
		}
		
		return randomPassword;
		
	}
	
	/**
	 * 
	 * checkPasswordPattern
	 *
	 * @param userId
	 * @param userPassword
	 * @return String
	 */
	public static String checkPasswordPattern(String userId, String userPassword) {
		
		String returnMsg = "";
		
		Pattern pAlphabetLow = null;
		Pattern pAlphabetUp = null;
		Pattern pNumber = null;
		Pattern pSpecialChar = null;
		Pattern pThreeChar = null;
		Matcher matcher;
		int nCharType = 0;
		
		pAlphabetLow = Pattern.compile("[a-z]");
		pAlphabetUp = Pattern.compile("[A-Z]");
		pNumber = Pattern.compile("[0-9]");
		pSpecialChar = Pattern.compile("\\p{Punct}");
		pThreeChar = Pattern.compile("(\\p{Alnum})\\1{3,}");
		
		matcher = pAlphabetLow.matcher(userPassword);
		if (matcher.find()) {
			nCharType = nCharType + 1;
		}
		matcher = pAlphabetUp.matcher(userPassword);
		if (matcher.find()) {
			nCharType = nCharType + 1;
		}
		matcher = pNumber.matcher(userPassword);
		if (matcher.find()) {
			nCharType = nCharType + 1;
		}
		matcher = pSpecialChar.matcher(userPassword);
		if (matcher.find()) {
			nCharType = nCharType + 1;
		}
		
		matcher = pThreeChar.matcher(userPassword);
		if (matcher.find()) {
			returnMsg = "같은 영문 혹은 숫자를 4개 이상을 사용할 수 없습니다.";
			return returnMsg;
		}
		int strLen = StringUtils.length(userPassword);
		if (strLen < 7 || strLen > 13) {
			returnMsg = "비밀번호는 6자리 이상 12자리 이하이어야 합니다.";
			return returnMsg;
		}
		if (nCharType < 3) {
			returnMsg = "비밀번호는 숫자, 특수기호, 소문자, 대문자 중 3가지 이상을 조합하여야 합니다.";
			return returnMsg;
		}
		if(userPassword.contains(userId)){
			returnMsg = "비밀번호에 사용자ID를 포함시킬 수 없습니다.";
			return returnMsg;
		}
		if(userPassword.contains(" ")){
			returnMsg = "비밀번호에 공백문자를 사용할 수 없습니다.";
			return returnMsg;
		}
		
		return returnMsg;
	}
	
	/**
	 * 
	 * replaceAllCertainSection
	 *
	 * @param srcStr
	 * @param findChar
	 * @param replaceStr
	 * @return String
	 */
	public static String replaceAllCertainSection(String srcStr, char findChar, String replaceStr) {
		int charCount = 0;
        for (int i = 0; i < srcStr.length(); i++) {
            if (srcStr.charAt(i) == findChar) {
            	charCount++;
            }
        }
        if (charCount > 0) {
        	String findStr = String.valueOf(findChar);
            StringBuilder newReplaceStrBuilder = new StringBuilder();
            for (int i = 0; i < charCount; i++) {
            	newReplaceStrBuilder.append(replaceStr);
            }
        	
            int lastIndexVal = StringUtils.lastIndexOf(srcStr, findStr);
            String remainStr = StringUtils.substring(srcStr, lastIndexVal+1);
            
            StringBuilder returnStrBuilder = new StringBuilder();
            returnStrBuilder.append(newReplaceStrBuilder.toString());
            returnStrBuilder.append(remainStr);
            
            srcStr = returnStrBuilder.toString();
        }
        
		return srcStr;
	}
	
}
