package com.adtcaps.tsop.helper.controller;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.adtcaps.tsop.config.InterfaceConfig;
import com.adtcaps.tsop.helper.constant.Const;
import com.adtcaps.tsop.helper.domain.ResultDto;

/**
 * 
 * <ul>
 * <li>업무 그룹명 : tsop-backend-api</li>
 * <li>서브 업무명 : com.adtcaps.tsop.helper.controller</li>
 * <li>설  명 : HealthCheckController.java</li>
 * <li>작성일 : 2021. 2. 15.</li>
 * <li>작성자 : jeonyb4</li>
 * </ul>
 */
@RestController
@RequestMapping("/api/health-checks")
public class HealthCheckController {
	
	private final String ERR_MSG_NULL_KEY = "Key값이 없습니다.";
	private final String ERR_MSG_KEY_AUTH_FAIL = "Key 인증에 실패하였습니다.";
	
	@Autowired
	private InterfaceConfig interfaceConfig;
	
	/**
	 * 
	 * readCurrentDate
	 *
	 * @return ResponseEntity
	 * @throws Exception 
	 */
	@SuppressWarnings("rawtypes")
    @GetMapping(value="", produces="application/json; charset=UTF-8")
    public ResponseEntity readCurrentDate(HttpServletRequest request) throws Exception {
        
    	ResponseEntity<ResultDto> resEntity = null;
		String returnString = "";
		
		String callKey = StringUtils.defaultString(request.getHeader("Call-Key"));
		String key = StringUtils.defaultString(interfaceConfig.getMyServerInfo().getKey());
		if ("".equals(callKey) || "".equals(key)) {
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_NULL_KEY));
			return resEntity;
		}
		if (!callKey.equals(key)) {
			returnString = Const.Common.RESULT_CODE.FAIL;
			resEntity = ResponseEntity.ok(new ResultDto(returnString, ERR_MSG_KEY_AUTH_FAIL));
			return resEntity;
		}
		
		returnString = Const.Common.RESULT_CODE.SUCCESS;
		resEntity = ResponseEntity.ok(new ResultDto(returnString, "", ""));
    	
    	return resEntity;
    }

}
