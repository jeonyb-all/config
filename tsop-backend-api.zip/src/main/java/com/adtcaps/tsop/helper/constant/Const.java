package com.adtcaps.tsop.helper.constant;

/**
 *
 * <ul>
 * <li>업무 그룹명 : tsop-backend-api</li>
 * <li>서브 업무명 : com.adtcaps.tsop.helper.constant</li>
 * <li>설  명 : Const.java</li>
 * <li>작성일 : 2020. 12. 4.</li>
 * <li>작성자 : jeonyb4</li>
 * </ul>
 */
public class Const {

	public static class Common {
         // 서비스 모드
         public static final String TEST = "TB";
         public static final String SERVICE = "AS";

        // 공통 Y,N 벨류
        public static final String VALUE_Y = "Y";
        public static final String VALUE_N = "N";
        public static final String VALUE_ALL = "ALL";

        // 기본 페이지 사이즈
        public static final int VALUE_DEFUALT_PAGE_SIZE = 10;

        // 통신 결과 코드
        public static class HTTP_RESPONSE_CODE {
            public static final String SUCCESS = "200";
            public static final String INVALID_REQUEST = "400";
            public static final String UNAUTORIZED = "401";
            public static final String REQUEST_TIMEOUT = "408";
            public static final String SERVER_ERROR = "500";
            public static final String FAIL = "-1";
        }
        // RESEULT CODE
        public static class RESULT_CODE {
            public static final String SUCCESS = "C0000";
            public static final String FAIL = "C9999";
            public static final String NOT_LOGIN = "NOT_LOGIN";
            public static final String UNAUTORIZED = "UNAUTORIZED";
            public static final String NOTAVAILABLE = "NOTAVAILABLE";
            public static final String UNAUTHORIZEDSMS = "UNAUTHORIZEDSMS";
            public static final String EXPIREDSMS = "EXPIREDSMSSMS";
            public static final String EXCESSSENDSMS = "EXCESSSENDSMS";
            public static final String SERVER_ERROR = "Server Error";
        }
    }

	/**
	 *
	 * <ul>
	 * <li>업무 그룹명 : tsop-backend-api</li>
	 * <li>서브 업무명 : com.adtcaps.tsop.helper.constant</li>
	 * <li>설  명 : Const.java</li>
	 * <li>작성일 : 2020. 12. 4.</li>
	 * <li>작성자 : jeonyb4</li>
	 * </ul>
	 */
	// 각종 정의
	public static class Definition {

		public static class HIDDEN_SUPER_MENU_ID {
			public static final String SERVICE_NOTI = "M0018";
		}

		public static class ADMIN_MENU_ID {
			public static final String USER_MGMT = "M0017";
		}

		public static class ADMIN_MENU_ID_2 {
			public static final String USER_MGMT_2 = "M0041";
		}

		public static class MENU_ID {
			public static final String ALARM_EXCEPTION_RULE = "M0035";
		}

		public static class VIRTUAL_ASSET {
			public static final String VIRTUAL_ASSET_ID = "vasset";
			public static final String VIRTUAL_ASSET_NAME = "vasset";
		}

		public static class ACCEPT_CONTENT_TYPE {
			public static final String GIF = "image/gif";
			public static final String PNG = "image/png";
			public static final String JPG = "image/jpeg";
			public static final String PDF = "application/pdf";
			public static final String XLS = "application/vnd.ms-excel";
			public static final String XLS1 = "application/x-msexcel";
			public static final String XLS2 = "application/x-dos_ms_excel";
			public static final String XLS3 = "application/haansoftxlsx";
			public static final String PPT = "application/vnd.ms-powerpoint";
			public static final String DOC = "application/msword";
			public static final String PPTX = "application/vnd.openxmlformats-officedocument.presentationml.presentation";
			public static final String XLSX = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";
			public static final String DOCX = "application/vnd.openxmlformats-officedocument.wordprocessingml.document";
			public static final String ZIP1 = "application/zip";
			public static final String ZIP2 = "multipart/x-zip";
			public static final String ZIP3 = "application/zip-compressed";
			public static final String ZIP4 = "application/x-zip-compressed";
		}

		public static class USE_YN {
			public static final String USE = "사용";
			public static final String NO_USE = "미사용";
		}

		public static class DASHBOARD_TAB_NAME {
            public static final String TOTAL = "totalTab";
            public static final String HVAC = "hvacTab";
            public static final String ELEC = "elecTab";
            public static final String DRM = "drmTab";
		}

		public static class DEFAULT_USER {
            public static final String SYSTEM = "SYSTEM";
		}

		public static class PAGE {
            public static final String PAGER = "pager";
            public static final String LISTS = "lists";
		}

		public static class FILE_EXTENTION {
            public static final String EXCEL = "xlsx";
            public static final String PDF = "pdf";
		}

		public static class BLOB_CONTAINER {
            public static final String FILE = "file";
		}

		public static class BLOB_BASEDIR {
            public static final String BOARD = "board";
            public static final String FAULT = "fault";
            public static final String SUPPORT = "support";
            public static final String EDITOR = "editor";
            public static final String ORDER = "order";
            public static final String REPORT = "report";
            public static final String WEEK = "week";
            public static final String ESOP = "esop";
            public static final String FORMAT = "format";
            public static final String ORDER_FORMAT = "orderformat";
		}

		public static class COMMON_VAL {
			public static final String TOTAL = "전체";
			public static final String SYSTEM_USER_ID = "SYSTEM";
		}

		public static class SEARCH_UNIT {
            public static final String DAY = "DAY";
            public static final String WEEK = "WEEK";
            public static final String MONTH = "MONTH";
            public static final String YEAR = "YEAR";
		}

		public static class CHECK_VAL {
            public static final String CHECK = "확인";
            public static final String NO_CHECK = "미확인";
		}

		public static class BOARD_STATUS_VAL {
            public static final String POST = "게시";
            public static final String DELETE = "삭제";
		}

		public static class WORK_STATUS_VAL {
            public static final String WORKING = "처리중";
            public static final String FINISH = "완료";
		}

		public static class OAC_PIE_CHART_ENTER_USER_TYPE {
            public static final String EMP = "EMP";			// 임직원
            public static final String VST = "VST";			// 방문자
		}

		public static class OAC_PIE_CHART_BLD_GUBUN {
            public static final String BLD = "BLD";			// 현사옥 임직원 구분
            public static final String OTB = "OTB";			// 타사옥 임직원 구분
            public static final String TOT = "TOT";			// 전체
		}

		public static class LINE_CHART_TITLE {
            public static final String EMP = "임직원";
            public static final String BP = "협력업체";
            public static final String VST = "방문자";

            public static final String IN = "입차";
            public static final String OUT = "출차";

            public static final String EVENT = "이벤트";

            public static final String PLAN = "계획";
            public static final String PROCEEDING = "진행";
            public static final String END = "완료";
            public static final String ACCEPT = "접수";
            public static final String HANDLE = "처리";
            
            public static final String LONG_TERM_PARKING1 = "1일~2일";
            public static final String LONG_TERM_PARKING2 = "2일~3일";
            public static final String LONG_TERM_PARKING3 = "3일이상";
		}

		public static class BATCH_UNIT_TYPE {
            public static final String EVERY_MONTH = "매월";
            public static final String EVERY_WEEK = "모든요일";
            public static final String EVERY_DAY = "매일";
            public static final String EVERY_HOUR = "매시";
            public static final String EVERY_MINUTE = "매분";
            public static final String EVERY_5_MINUTE = "5분주기";
		}

		public static class PORTAL_DASHBOARD_TECH_SUPPORT_STATUS {
            public static final String PROCESSING = "P";
            public static final String FINISH = "F";
		}

		// 관리상세코드명
        public static class MANAGEMENT_DETAIL_NAME {
        	public static final String GOOD = "좋음";
        	public static final String GENERAL = "보통";
        	public static final String BAD = "나쁨";
        	public static final String TOO_BAD = "매우나쁨";
        }

        // 관리상세코드 정부표준값
		public static class GOVERNMENT_STANDARD_INDICATOR {
            public static final String FINE_DUST_GOOD_FROM = "0";
            public static final String FINE_DUST_GOOD_TO = "30";
            public static final String FINE_DUST_GENERAL_FROM = "31";
            public static final String FINE_DUST_GENERAL_TO = "80";
            public static final String FINE_DUST_BAD_FROM = "81";
            public static final String FINE_DUST_BAD_TO = "150";
            public static final String FINE_DUST_TOO_BAD_FROM = "151";
            public static final String ULTRA_FINE_DUST_GOOD_FROM = "0";
            public static final String ULTRA_FINE_DUST_GOOD_TO = "15";
            public static final String ULTRA_FINE_DUST_GENERAL_FROM = "16";
            public static final String ULTRA_FINE_DUST_GENERAL_TO = "35";
            public static final String ULTRA_FINE_DUST_BAD_FROM = "36";
            public static final String ULTRA_FINE_DUST_BAD_TO = "75";
            public static final String ULTRA_FINE_DUST_TOO_BAD_FROM = "76";
		}

		// 법정보고서ID
        public static class REPORT_ID {
        	public static final String R001 = "R001";
        	public static final String R002 = "R002";
        	public static final String R003 = "R003";
        	public static final String R004 = "R004";
        	public static final String R005 = "R005";
        	public static final String R006 = "R006";
        	public static final String R007 = "R007";
        	public static final String R008 = "R008";
        	public static final String R009 = "R009";
        	public static final String R010 = "R010";
        	public static final String R011 = "R011";
        	public static final String R012 = "R012";
        	public static final String R013 = "R013";
        }

		// 분기명
        public static class QUARTER_NAME {
        	public static final String FIRST_QUARTER = "1";
        	public static final String SECOND_QUARTER = "2";
        	public static final String THIRD_QUARTER = "3";
        	public static final String FOURTH_QUARTER = "4";
        }

        // 반기명
        public static class HALF_YEAR_NAME {
        	public static final String FIRST_HALF_YEAR = "1";
        	public static final String SECOND_HALF_YEAR = "2";
        }

        // 분기별 대표월일
        public static class QUARTER_DATE {
        	public static final String FIRST_QUARTER_MMDD = "0101";
        	public static final String SECOND_QUARTER_MMDD = "0401";
        	public static final String THIRD_QUARTER_MMDD = "0701";
        	public static final String FOURTH_QUARTER_MMDD = "1001";
        }

        // 반기별 대표월일
        public static class HALF_YEAR_DATE {
        	public static final String FIRST_HALF_YEAR_MMDD_START = "0101";
        	public static final String FIRST_HALF_YEAR_MMDD_END = "0630";
        	public static final String SECOND_HALF_YEAR_MMDD_START = "0701";
        	public static final String SECOND_HALF_YEAR_MMDD_END = "1231";
        }

        // 기타단위
        public static class ETC_UNIT {
        	public static final String TEMPERATURE = "℃";
        	public static final String HUMIDITY = "%";
        }

        // 주간보고서 보고목차ID
        public static class WEEK_REPORT_TITLE_ID {
        	public static final String SERVICE = "R001";
        	public static final String ELEC_USE = "R002";
        	public static final String TEMPR_HUMID = "R003";
        	public static final String HVAC_OPER = "R004";
        	public static final String WORK_HANDLE = "R005";
        	public static final String APPENDIX = "R006";
        }

        // 주간보고서 서비스통계 VoC관리 Chart Title
        public static class WEEK_REPORT_VOC_CHART_TITLE {
        	public static final String CLIENT = "고객";
        	public static final String SELF = "자체";
        	public static final String NO_HANDLE = "미처리";
        }

        // 주간보고서 서비스통계 장기주차관리 Chart Title
        public static class WEEK_REPORT_PARKING_CHART_TITLE {
        	public static final String LONG_TERM_PARKING_1 = "1일~2일";
        	public static final String LONG_TERM_PARKING_2 = "2일~3일";
        	public static final String LONG_TERM_PARKING_3 = "3일이상";
        }

        // 기타날짜단위명
        public static class ETC_DATE_UNIT_NAME {
        	public static final String WEEK = "째주";
        	public static final String QUARTER = "분기";
        	public static final String FIRST_HALF_YEAR = "상반기";
        	public static final String SECOND_HALF_YEAR = "하반기";
        	public static final String YEAR = "년";
        }

        // 주간보고서 템플릿 파일명
        public static class WEEK_REPORT_TEMPLATE {
        	public static final String FILE_NAME = "SUMITS 주간 운영 Report.xlsx";
        }

        // 공기질(CO2)기준 : 공통_빌딩부가정보연동(OCO_BUILDING_ADD_INFO_COLLECT) 에서 설정하지 않았을때 대비
        public static class AIR_QUALITY_CO2 {
            public static final int AIR_QUALITY_CO2_BASE_VAL = 900;
        }

        // 메시지 템플릿코드
        public static class MSG_TEMPLATE_CODE {
        	public static final String TSOP_001 = "TSOP_001";		// 시스템 알람 공지
        	public static final String TSOP_002 = "TSOP_002";		// 공지사항 등록/변경 공지
        	public static final String TSOP_003 = "TSOP_003";		// 로그인 2차 인증 번호 발송
        	public static final String TSOP_004 = "TSOP_004";		// 비밀번호 최초/초기화 발송
        	public static final String TSOP_005 = "TSOP_005";		// 화재 ESOP 발송
        	public static final String TSOP_008 = "TSOP_008";		// 작업 오더 발송
        }
        
        // 날씨(하늘상태)
        public static class SKY_STATUS_VAL {
        	public static final String CLEAR = "1";		// 맑음
        	public static final String CLOUDY = "3";	// 구름많음
        	public static final String FADE = "4";		// 흐림
        }
        
        // 날씨명(하늘상태)
        public static class SKY_STATUS_VAL_NAME {
        	public static final String CLEAR = "맑음";		// 맑음
        	public static final String CLOUDY = "구름많음";	// 구름많음
        	public static final String FADE = "흐림";			// 흐림
        }
        
        // 날씨(강수형태코드)
        public static class RAIN_FALL_FORM_CODE {
        	public static final String NOTHING = "0";				// 없음
        	public static final String RAIN = "1";					// 비
        	public static final String SLEET = "2";					// 비/눈
        	public static final String SNOW = "3";					// 눈
        	public static final String SHOWER = "4";				// 소나기
        	public static final String RAIN_DROP = "5";				// 빗방울
        	public static final String RAIN_SNOW_DRIFT = "6";		// 빗방울/눈날림
        	public static final String SNOW_DRIFT = "7";			// 눈날림
        }
        
        // 날씨명(강수형태코드)
        public static class RAIN_FALL_FORM_CODE_NAME {
        	public static final String NOTHING = "없음";						// 없음
        	public static final String RAIN = "비";							// 비
        	public static final String SLEET = "비/눈";						// 비/눈
        	public static final String SNOW = "눈";							// 눈
        	public static final String SHOWER = "소나기";						// 소나기
        	public static final String RAIN_DROP = "빗방울";					// 빗방울
        	public static final String RAIN_SNOW_DRIFT = "빗방울/눈날림";		// 빗방울/눈날림
        	public static final String SNOW_DRIFT = "눈날림";					// 눈날림
        }
	}

	/**
	 *
	 * <ul>
	 * <li>업무 그룹명 : tsop-backend-api</li>
	 * <li>서브 업무명 : com.adtcaps.tsop.helper.constant</li>
	 * <li>설  명 : Const.java</li>
	 * <li>작성일 : 2020. 12. 4.</li>
	 * <li>작성자 : jeonyb4</li>
	 * </ul>
	 */
	public static class Code {
		// 역할구분코드
        public static class ROLE_CL_CD {
            public static final String PORTAL_MANAGER = "S00";			// 서비스 Admin
            public static final String BUILDING_TYPE_MANAGER = "S10";	// 서비스 군관리자
            public static final String BUILDING_MANAGER = "S20";		// 빌딩 관리자
            public static final String MIDDLE_MANAGER = "S30";			// 중간 관리자
            public static final String WORKER = "S40";					// 작업자
            public static final String MIDDLE_MANAGER_GRADE = "S10,S20,S30"; // 관리자를 제외한 중간관리자 권한.
        }

		// 게시유형코드
        public static class BULLETIN_TYPE_CD {
            public static final String NOTICE = "1";		// 공지사항
            public static final String REFERENCE = "2";		// 자료실
        }

        // 게시구분코드
        public static class BULLETIN_CL_CD {
            public static final String NORMAL = "1";		// 일반
            public static final String EMERGENCY = "2";		// 긴급
            public static final String SYSTEM = "9";		// 시스템
        }

        // 알람통지방법구분코드
        public static class ALARM_NOTICE_METHOD_CL_CD {
            public static final String SMS = "1";
            public static final String PUSH = "2";
            public static final String ALL = "9";
        }

        // 알람통지결과코드
        public static class ALARM_NOTICE_RESULT_CD {
            public static final String SMS = "1";
            public static final String FAIL = "2";
            public static final String ALIMTALK = "3";
        }

        // 첨부파일구분코드
        public static class ATTACH_FILE_CL_CD {
        	public static final String BOARD = "1";			// 게시물 첨부파일
        	public static final String FAULT = "2";			// 장애처리 첨부파일
            public static final String SUPPORT = "3";		// 기술지원요청 첨부파일
        }

        // 장애조치상태코드
        public static class FAULT_ACTION_STATUS_CD {
        	public static final String REGISTER = "R";		// 등록
        	public static final String PROCESS = "P";		// 처리중
            public static final String FINISH = "F";		// 처리완료
        }

        // 서비스구분코드
        public static class SERVICE_CL_CD {
            public static final String AC = "AC";		// 출입관제
            public static final String CB = "CB";		// 챗봇
            public static final String CC = "CC";		// CCTV
            public static final String CO = "CO";		// 공통
            public static final String EN = "EN";		// 에너지
            public static final String FM = "FM";		// 설비
            public static final String IV = "IV";		// 구성
            public static final String MU = "MU";		// Mashup
            public static final String OM = "OM";		// O&M
            public static final String PA = "PA";		// 주차
            public static final String RB = "RB";		// 로봇
            public static final String VP = "VP";		// VPS
            public static final String EL = "EL";		// 엘리베이터
            public static final String ETC = "ETC";		// 기타
        }

        // 포털 메인 대시보드 차트용 서비스구분코드
        public static class PORTAL_DASHBOARD_CHART_SERVICE_CL_CD {
            public static final String AC = "AC";		// 출입관제
            public static final String CC = "CC";		// CCTV
            public static final String PA = "PA";		// 주차
            public static final String EL = "EL";		// 엘리베이터
        }

        // 오브젝트유형코드
        public static class OBJECT_TYPE_CD {
            public static final String OBJ_10 = "10";		// 설비
            public static final String OBJ_11 = "11";		// 장비(Equipment)
            public static final String OBJ_12 = "12";		// 포인트
            public static final String OBJ_13 = "13";		// 가상포인트
            public static final String OBJ_14 = "14";		// 엘리베이터
            public static final String OBJ_30 = "30";		// 출입관제
            public static final String OBJ_31 = "31";		// 출입주장치
            public static final String OBJ_32 = "32";		// 출입문
            public static final String OBJ_33 = "33";		// 출입인식기
            public static final String OBJ_40 = "40";		// CCTV
            public static final String OBJ_42 = "42";		// CCTV VMS
            public static final String OBJ_44 = "44";		// CCTV Channel
            public static final String OBJ_50 = "50";		// 주차
            public static final String OBJ_70 = "70";		// 로봇
            public static final String OBJ_71 = "71";		// 안내로봇
            public static final String OBJ_80 = "80";		// 챗봇
        }

        // 기술지원요청유형코드
        public static class TECH_SUPPORT_REQ_TYPE_CD {
            public static final String BLD_ADD = "11";		// 빌딩추가
            public static final String BLD_MOD = "12";		// 빌딩변경
            public static final String BLD_DEL = "13";		// 빌딩삭제
            public static final String SVC_ADD = "21";		// 빌딩서비스추가
            public static final String SVC_DEL = "22";		// 빌딩서비스삭제
            public static final String ETC = "99";			// 기타
        }

        // 기술지원상태코드
        public static class TECH_SUPPORT_STATUS_CD {
            public static final String REQUEST = "1";		// 신청
            public static final String APPROVAL = "2";		// 승인
            public static final String PROCESSING = "3";	// 진행중
            public static final String FINISH = "4";		// 완료
            public static final String RETURN = "5";		// 반려
        }

        // 오브젝트그룹구분코드
        public static class OBJECT_GROUP_CL_CD {
            public static final String MASTER = "M";
            public static final String SUB = "S";
        }

        // SMS생성코드
        public static class SMS_CREATE_CD {
        	public static final String ALARM = "1";
        	public static final String ORDER = "2";
        	public static final String BOARD = "3";
        	public static final String AUTH = "4";
        	public static final String PASSWORD = "5";
        	public static final String ESOP = "6";
        }

        // 예외구분코드
        public static class ALARM_EXCEPTION_CATEGORY_CD {
        	public static final String SERVICE = "1";
        	public static final String EQUIPMENT = "3";
        	public static final String ALARM_CODE = "4";
        	public static final String FLOOR = "2";
        	public static final String ALARM_GRADE = "5";
        	public static final String TIME = "6";
        	public static final String DATE = "7";
        }

        // SMS신규변경구분코드
        public static class NEW_CHANGE_CL_CD {
        	public static final String CREATE = "C";
        	public static final String UPDATE = "U";
        	public static final String DELETE = "D";
        }

        // 예외변경항목코드
        public static class EXCEPTION_CHANGE_ITEM_CD {
        	public static final String USE_YN = "1";
        	public static final String EXCEPTION_NAME = "2";
        	public static final String EXCEPTION_RULE = "3";
        }

        // 사용자변경항목코드
        public static class USER_CHANGE_ITEM_CD {
        	public static final String USER_NAME = "1";
        	public static final String PHONE_NUMBER = "2";
        	public static final String EMAIL = "3";
        	public static final String COMPANY_NAME = "4";
        	public static final String MENU_GROUP = "5";
        	public static final String ROLE = "6";
        	public static final String PART_CATEGORY = "7";
        	public static final String BUILDING_LIST = "8";
        	public static final String PASSWD_INIT = "9";
        	public static final String PASSWD_CHANGE = "10";
        }

        // 연락망변경항목코드
        public static class CONTACT_NETWORK_CHANGE_ITEM_CD {
        	public static final String CONTACT_NETWORK = "1";
        	public static final String CONTACT_NETWORK_MEMBER = "2";
        }

        // 대응팀변경항목코드
        public static class RESPONSE_TEAM_CHANGE_ITEM_CD {
        	public static final String RESPONSE_TEAM = "1";
        	public static final String RESPONSE_TEAM_MEMBER = "2";
        	public static final String MAIN_TASK = "3";
        	public static final String ORGANIZATION = "4";
        	public static final String STEP1_TASK = "5";
        	public static final String STEP2_TASK = "6";
        	public static final String STEP3_TASK = "7";
        	public static final String STEP4_TASK = "8";
        }

        // 변경전후코드
        public static class BEFORE_AFTER_CD {
        	public static final String BEFORE = "B";
        	public static final String AFTER = "A";
        }

        // 관리분류코드
        public static class MANAGEMENT_CATEGORY_CD {
        	public static final String FINE_DUST = "1";
        	public static final String ULTRA_FINE_DUST = "2";
        	public static final String BLD_IN_ENTHALPY = "3";
        	public static final String IN_ENTHALPY = "4";
        	public static final String PEAK_POWER = "5";
        	public static final String REF_TEMPR = "6";
        }

        // 관리상세코드
        public static class MANAGEMENT_DETAIL_CD {
        	public static final String FINE_DUST_GOOD = "1";
        	public static final String FINE_DUST_GENERAL = "2";
        	public static final String FINE_DUST_BAD = "3";
        	public static final String FINE_DUST_TOO_BAD = "4";
        	public static final String ULTRA_FINE_DUST_GOOD = "5";
        	public static final String ULTRA_FINE_DUST_GENERAL = "6";
        	public static final String ULTRA_FINE_DUST_BAD = "7";
        	public static final String ULTRA_FINE_DUST_TOO_BAD = "8";
        	public static final String BLD_TEMPERATURE = "9";
        	public static final String BLD_HUMIDITY = "10";
        	public static final String BLD_ENTHALPY = "11";
        	public static final String TEMPERATURE = "13";
        	public static final String HUMIDITY = "14";
        	public static final String ENTHALPY = "15";
        }

        // 설비분류코드
        public static class FACILITY_CATEGORY_CD {
        	public static final String FREEZER_STATUS = "2110";		// 냉방기 상태
        	public static final String IN_TEMPERATURE = "6101";		// 실내온도
        }

        // 결재선변경항목코드
        public static class APPROVAL_CHANGE_ITEM_CD {
        	public static final String LINE_NAME = "1";				// 결재선명
        	public static final String LINE_DETAIL_APPROVE = "2";	// 결재선세부사항
        }

        // 점검주기코드
        public static class CHECK_CYCLE_CD {
        	public static final String DAY = "1";
        	public static final String WEEK = "2";
        	public static final String MONTH = "3";
        	public static final String QUARTER = "4";
        	public static final String HALF_YEAR = "5";
        	public static final String YEAR = "6";
        	public static final String USER_DEFINE = "7";
        }

        // 보고서단계코드
        public static class REPORT_STEP_CD {
        	public static final String FINISH = "1";		// 완료
        	public static final String WORKING = "2";		// 작업중
        }

        // 작업상태코드
        public static class WORK_STATUS_CD {
        	public static final String WORK_REQUEST = "1";//작업요청
        	public static final String WORK_RECEPT = "2";//작업접수
        	public static final String WORK_APPROVE = "3";        	//작업완료(승인요청)
        	public static final String WORK_FINISH = "4";//작업완료(승인완료)
        }


        // 작업구분코드
        public static class WORK_TYPE_CD {
        	public static final String WORK_FORM = "1";//주기
        	public static final String WORK_VOC = "2";//voc
        	public static final String WORK_FAULT = "3";//장애
        }

        // 서식변경항목코드
        public static class FORMAT_CHANGE_ITEM_CD {
        	public static final String ITEM_1 = "1";//서식명
        	public static final String ITEM_2 = "2";//법정유무
        	public static final String ITEM_3 = "3";//파트구분
        	public static final String ITEM_4 = "4";//임계치여부
        	public static final String ITEM_5 = "5";//자산목록
        	public static final String ITEM_6 = "6";//점검대상
        	public static final String ITEM_7 = "7";//점검항목
        	public static final String ITEM_8 = "8";//작업주기
        }

        // 대시보드탭코드
        public static class DASHBOARD_TAB_CD {
        	public static final String TOTAL = "1";
        	public static final String HVAC = "2";
        	public static final String ENERGY = "3";
        	public static final String DRM = "4";
        }

        // 서식 점검값 구분코드
        public static class CHECK_VALUE_CATEGORY_CD {
        	public static final String ITEM_TEXT = "1";//TEXT
        	public static final String ITEM_NUMBER = "2";//정수
        	public static final String ITEM_DOUBLE = "3";//소수
        	public static final String ITEM_TEXTAREA = "4";//TEXTAREA
        	public static final String ITEM_COMBO = "5";//Combo
        	public static final String ITEM_IMAGE = "6";//이미지
        }
	}

}
