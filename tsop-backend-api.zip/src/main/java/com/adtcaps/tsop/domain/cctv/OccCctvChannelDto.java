package com.adtcaps.tsop.domain.cctv;

import lombok.Getter;
import lombok.Setter;

/**
 * 
 * <ul>
 * <li>업무 그룹명 : tsop-backend-api</li>
 * <li>서브 업무명 : com.adtcaps.tsop.domain.cctv</li>
 * <li>설  명 : OccCctvChannelDto.java</li>
 * <li>작성일 : 2021. 1. 12.</li>
 * <li>작성자 : jeonyb4</li>
 * </ul>
 */
@Getter
@Setter
public class OccCctvChannelDto {
	private String bldId;
	private String objectId;
	private String channelObjectId;
	private String auditDatetime;
	private String channelId;
	private String channelName;

}
