package com.adtcaps.tsop.domain.work;

import lombok.Getter;
import lombok.Setter;

/**
 *
 * <ul>
 * <li>업무 그룹명 : tsop-backend-api</li>
 * <li>서브 업무명 : com.adtcaps.tsop.domain.work</li>
 * <li>설  명 : OwkWorkOrderResultDto.java</li>
 * <li>작성일 : 2021. 12. 8.</li>
 * <li>작성자 : jeonyb4</li>
 * </ul>
 */
@Getter
@Setter
public class OwkWorkOrderResultDto {
	private String bldId;
	private Integer formDetailSeq;
	private Integer workOrderId;
	private String assetId;
	private Integer checkTargetId;
	private String auditDatetime;
	private String checkItemLcategoryName;
	private String checkItemMcategoryName;
	private String checkItemScategoryName;
	private String checkUnitVal;
	private String checkValueCategoryCd;
	private String thresholdCategoryCd;
	private Double thresholdValFirst;
	private Double thresholdValSecond;
	private String checkVal;
	private String checkTargetFullName;
	private String assetName;
	private String comboVal;
	private Integer checkSeq;
	private String vAssetId;
	private Integer formId;

}
