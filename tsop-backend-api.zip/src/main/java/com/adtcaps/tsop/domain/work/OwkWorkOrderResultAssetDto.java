/**
 *
 */
package com.adtcaps.tsop.domain.work;

import lombok.Getter;
import lombok.Setter;

/**
 * <ul>
 * <li>업무 그룹명 : com.adtcaps.tsop.domain.work</li>
 * <li>서브 업무명 : com.adtcaps.tsop.domain.work</li>
 * <li>설  명 : OwkWorkOrderResultAssetDto.java</li>
 * <li>작성일 : 2022. 1. 15.</li>
 * <li>작성자 : msham</li>
 * </ul>
 */
@Getter
@Setter
public class OwkWorkOrderResultAssetDto {
	private String assetId;
	private String bldId;
	private Integer workOrderId;
	private String auditDatetime;
	private String assetName;
	private String assetKindCategoryName;
	private String locFloor;
	private Integer checkSeq;
}
