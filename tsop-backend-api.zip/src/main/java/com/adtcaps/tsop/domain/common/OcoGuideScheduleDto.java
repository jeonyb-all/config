package com.adtcaps.tsop.domain.common;

import lombok.Getter;
import lombok.Setter;

/**
 * 
 * <ul>
 * <li>업무 그룹명 : tsop-backend-api</li>
 * <li>서브 업무명 : com.adtcaps.tsop.domain.common</li>
 * <li>설  명 : OcoGuideScheduleDto.java</li>
 * <li>작성일 : 2020. 12. 7.</li>
 * <li>작성자 : jeonyb4</li>
 * </ul>
 */
@Getter
@Setter
public class OcoGuideScheduleDto {
	private String bldId;
	private Integer scheduleSeq;
	private String startDateHourminute;
	private String auditDatetime;
	private String endDateHourminute;
	private String scheduleTitleName;
	private String scheduleContent;
	private String checkYn;
	private String registDatetime;
	private String registerId;
	private String registerName;

}
