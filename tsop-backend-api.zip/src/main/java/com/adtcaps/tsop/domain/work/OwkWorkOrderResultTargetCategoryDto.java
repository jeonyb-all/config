/**
 *
 */
package com.adtcaps.tsop.domain.work;

import lombok.Getter;
import lombok.Setter;

/**
 * <ul>
 * <li>업무 그룹명 : com.adtcaps.tsop.domain.work</li>
 * <li>서브 업무명 : com.adtcaps.tsop.domain.work</li>
 * <li>설  명 : OwkWorkOrderResultTargetCategoryDto.java</li>
 * <li>작성일 : 2022. 1. 13.</li>
 * <li>작성자 : msham</li>
 * </ul>
 */
@Getter
@Setter
public class OwkWorkOrderResultTargetCategoryDto {
	private Integer workOrderId;
	private String bldId;
	private String auditDatetime;
	private String assetInspectTargetFullTitle;
	private String formName;
	private Integer attachFileNum;
	private String partCategoryCd;
	private String courtYn;
	private String thresholdYn;
	private String partCategoryCdName;
}
