package com.adtcaps.tsop.domain.esop;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class ProcessResultDto {
	private String bldId;
	private String fireResultId;
	private String processStartDate;
	private String processEndDate;
	private String fireGradeCd;
	private String auditDatetime;
	private String hProcessStartDate;
	private String hProcessEndDate;
	/*private String traningYn;*/
	private String auditId;
	private String auditName;
}
