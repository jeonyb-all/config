package com.adtcaps.tsop.domain.cctv;

import lombok.Getter;
import lombok.Setter;

/**
 * 
 * <ul>
 * <li>업무 그룹명 : tsop-backend-api</li>
 * <li>서브 업무명 : com.adtcaps.tsop.domain.cctv</li>
 * <li>설  명 : OccCctvEventDayStatDto.java</li>
 * <li>작성일 : 2021. 1. 21.</li>
 * <li>작성자 : jeonyb4</li>
 * </ul>
 */
@Getter
@Setter
public class OccCctvEventDayStatDto {
	private String bldId;
	private String cctvAlarmClCd;
	private String cctvAlarmContent;
	private String cctvAlarmObjName;
	private String sumDate;
	private String auditDatetime;
	private Integer eventCnt;

}
