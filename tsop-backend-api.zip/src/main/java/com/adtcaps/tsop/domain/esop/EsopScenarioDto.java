package com.adtcaps.tsop.domain.esop;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class EsopScenarioDto {
	private String stepId;
	private String bldId;
	private String stepTitle;
	private String stepName;
	private String checkPoint;
	private Integer attachFileNum;
	private String attachFileLocUrlAddr;
	private String auditDatetime;
	private String fireResultId;
}
