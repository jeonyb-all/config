package com.adtcaps.tsop.domain.common;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

import lombok.Getter;
import lombok.Setter;

/**
 * 
 * <ul>
 * <li>업무 그룹명 : tsop-backend-api</li>
 * <li>서브 업무명 : com.adtcaps.tsop.domain.common</li>
 * <li>설  명 : OcoCommonCodeDetailDto.java</li>
 * <li>작성일 : 2020. 12. 15.</li>
 * <li>작성자 : jeonyb4</li>
 * </ul>
 */
@Getter
@Setter
@JsonInclude(Include.NON_EMPTY)
public class OcoCommonCodeDetailDto {
	private String commonCdName;
	private String commonCd;
	private String commonCdVal;
	private String auditDatetime;
	private String commonCdValName;
	private String commonCdValDesc;
	private String effectStartDatetime;
	private String effectEndDatetime;
	private Integer sortSeq;
	private String superCommonCd;
	private String superCommonCdVal;

}
