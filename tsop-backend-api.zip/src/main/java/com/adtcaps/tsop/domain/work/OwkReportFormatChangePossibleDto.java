/**
 *
 */
package com.adtcaps.tsop.domain.work;

import lombok.Getter;
import lombok.Setter;

/**
 * <ul>
 * <li>업무 그룹명 : com.adtcaps.tsop.domain.work</li>
 * <li>서브 업무명 : com.adtcaps.tsop.domain.work</li>
 * <li>설  명 : OwkReportFormatChangePossibleDto.java</li>
 * <li>작성일 : 2022. 1. 21.</li>
 * <li>작성자 : msham</li>
 * </ul>
 */
@Getter
@Setter
public class OwkReportFormatChangePossibleDto {
	private Integer formId;
	private String bldId;
	private String auditDatetime;
	private Integer formDetailSeq;
	private Integer maxNumberVal;
}
