package com.adtcaps.tsop.domain.inventory;

import lombok.Getter;
import lombok.Setter;

/**
 * 
 * <ul>
 * <li>업무 그룹명 : tsop-backend-api</li>
 * <li>서브 업무명 : com.adtcaps.tsop.domain.inventory</li>
 * <li>설  명 : OivObjectHistDto.java</li>
 * <li>작성일 : 2021. 1. 15.</li>
 * <li>작성자 : jeonyb4</li>
 * </ul>
 */
@Getter
@Setter
public class OivObjectHistDto {
	private String bldId;
	private String objectId;
	private Integer objectChangeSeq;
	private String auditDatetime;
	private String auditId;
	private String auditName;
	private String objectName;
	private String objectTypeCd;
	private String objectDesc;
	private String measureUnitVal;
	private String registDate;
	private String changeDate;
	private String serviceClCd;
	private String serviceObjectId;
	private String superObjectId;
	private String superObjectRelCd;
	private String locFloor;
	private String locDongName;
	private String locZoneName;
	private String locRoomName;
	private Double locXCodnVal;
	private Double locYCodnVal;
	private Double locZCodnVal;
	private String objectCategoryCd;
	private String deleteYn;
	private String deleteDate;
	private String newChangeClCd;

}
