package com.adtcaps.tsop.domain.parking;

import lombok.Getter;
import lombok.Setter;

/**
 * 
 * <ul>
 * <li>업무 그룹명 : tsop-backend-api</li>
 * <li>서브 업무명 : com.adtcaps.tsop.domain.parking</li>
 * <li>설  명 : OpaParkingInoutEventDayStatDto.java</li>
 * <li>작성일 : 2021. 1. 21.</li>
 * <li>작성자 : jeonyb4</li>
 * </ul>
 */
@Getter
@Setter
public class OpaParkingInoutEventDayStatDto {
	private String bldId;
	private String objectId;
	private String sumDate;
	private String auditDatetime;
	private Integer invehicleCnt;
	private Integer uvInvehicleCnt;
	private Integer outVehicleCnt;
	private Integer uvOutvehicleCnt;
	private Double totPrkMunitTm;

}
