package com.adtcaps.tsop.domain.common;

import lombok.Getter;
import lombok.Setter;

/**
 * 
 * <ul>
 * <li>업무 그룹명 : tsop-backend-api</li>
 * <li>서브 업무명 : com.adtcaps.tsop.domain.common</li>
 * <li>설  명 : OcoAlarmReceiveGroupDetailDto.java</li>
 * <li>작성일 : 2020. 12. 21.</li>
 * <li>작성자 : jeonyb4</li>
 * </ul>
 */
@Getter
@Setter
public class OcoAlarmReceiveGroupDetailDto {
	private String bldId;
	private Integer alarmNoticeGroupId;
	private Integer alarmNoticeGroupSeq;
	private String auditDatetime;
	private String rcverId;
	private String rcverName;
	private String rcvPhoneNum;
	private String rcvEmailAddr;
	private String registDatetime;
	private String registerId;
	private String registerName;
	private String useYn;

}
