/**
 *
 */
package com.adtcaps.tsop.domain.paymgmt;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

import lombok.Getter;
import lombok.Setter;

/**
 * <ul>
 * <li>업무 그룹명 : com.adtcaps.tsop.domain.paymgmt</li>
 * <li>서브 업무명 : com.adtcaps.tsop.domain.paymgmt</li>
 * <li>설  명 : OwkApprovalLineDto.java</li>
 * <li>작성일 : 2021. 12. 2.</li>
 * <li>작성자 : msham</li>
 * </ul>
 */
@Getter
@Setter
@JsonInclude(Include.NON_EMPTY)
public class OwkApprovalLineDto {
	private Integer approvalLineId;
	private String bldId;
	private String auditDatetime;
	private String approvalLineName;
	private String auditId;
	private String auditName;
	private String registerId;
	private String registerName;
	private String registDatetime;
	private Integer approvalLineSeq;

}
