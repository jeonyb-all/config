package com.adtcaps.tsop.domain.esop;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class EsopMemoDto {
	private String memoId;
	private String bldId;
	private String stepId;
	private String stepName;
	private String taskStep;
	private String taskTitle;
	private String memoContent;
	private String auditDatetime;
	private String auditId;
	private String auditName;
}
