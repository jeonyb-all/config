package com.adtcaps.tsop.domain.parking;

import lombok.Getter;
import lombok.Setter;

/**
 * 
 * <ul>
 * <li>업무 그룹명 : tsop-backend-api</li>
 * <li>서브 업무명 : com.adtcaps.tsop.domain.parking</li>
 * <li>설  명 : OpaParkingSiteDetailDto.java</li>
 * <li>작성일 : 2021. 1. 12.</li>
 * <li>작성자 : jeonyb4</li>
 * </ul>
 */
@Getter
@Setter
public class OpaParkingSiteDetailDto {
	private String bldId;
	private String objectId;
	private Integer prksiteDetailSeq;
	private String auditDatetime;
	private String prkPossibilityVehicleTypeCd;
	private String prksiteImageVal;

}
