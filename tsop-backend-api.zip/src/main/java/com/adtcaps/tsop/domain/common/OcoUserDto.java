package com.adtcaps.tsop.domain.common;

import lombok.Getter;
import lombok.Setter;

/**
 * 
 * <ul>
 * <li>업무 그룹명 : tsop-backend-api</li>
 * <li>서브 업무명 : com.adtcaps.tsop.domain.common</li>
 * <li>설  명 : OcoUserDto.java</li>
 * <li>작성일 : 2020. 12. 21.</li>
 * <li>작성자 : jeonyb4</li>
 * </ul>
 */
@Getter
@Setter
public class OcoUserDto {
	private String userId;
	private String auditDatetime;
	private String auditId;
	private String auditName;
	private String userName;
	private String loginPassword;
	private String useYn;
	private String contactPhoneNum;
	private String emailAddr;
	private String effectStartDatetime;
	private String effectEndDatetime;
	private String tenantId;
	private String postCompanyName;
	private String roleClCd;
	private String lockYn;
	private String loginDatetime;
	private String partCategoryCd;

}
