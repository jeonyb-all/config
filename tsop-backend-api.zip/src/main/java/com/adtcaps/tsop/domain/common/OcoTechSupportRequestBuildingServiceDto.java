package com.adtcaps.tsop.domain.common;

import lombok.Getter;
import lombok.Setter;

/**
 * 
 * <ul>
 * <li>업무 그룹명 : tsop-backend-api</li>
 * <li>서브 업무명 : com.adtcaps.tsop.domain.common</li>
 * <li>설  명 : OcoTechSupportRequestBuildingServiceDto.java</li>
 * <li>작성일 : 2020. 12. 31.</li>
 * <li>작성자 : jeonyb4</li>
 * </ul>
 */
@Getter
@Setter
public class OcoTechSupportRequestBuildingServiceDto {
	private Integer techSupportReqId;
	private String auditDatetime;
	private String bldId;
	private String bldName;
	private String serviceClCd;
	private String useYn;

}
