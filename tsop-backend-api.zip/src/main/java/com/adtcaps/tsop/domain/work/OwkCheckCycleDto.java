/**
 *
 */
package com.adtcaps.tsop.domain.work;

import lombok.Getter;
import lombok.Setter;

/**
 * <ul>
 * <li>업무 그룹명 : com.adtcaps.tsop.domain.work</li>
 * <li>서브 업무명 : com.adtcaps.tsop.domain.work</li>
 * <li>설  명 : OwkCheckCycleDto.java</li>
 * <li>작성일 : 2021. 12. 22.</li>
 * <li>작성자 : msham</li>
 * </ul>
 */
@Getter
@Setter
public class OwkCheckCycleDto {
	private Integer checkCycleId;
	private String auditDatetime;
	private String checkCycleName;
	private String checkCycleCd;
	private String check01PerformVal;
	private String check02PerformVal;
	private String check03PerformVal;
	private String check04PerformVal;
	private String bldId;
}
