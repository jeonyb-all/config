package com.adtcaps.tsop.domain.parking;

import lombok.Getter;
import lombok.Setter;

/**
 * 
 * <ul>
 * <li>업무 그룹명 : tsop-backend-api</li>
 * <li>서브 업무명 : com.adtcaps.tsop.domain.parking</li>
 * <li>설  명 : OpaParkingInoutEventDto.java</li>
 * <li>작성일 : 2020. 12. 18.</li>
 * <li>작성자 : jeonyb4</li>
 * </ul>
 */
@Getter
@Setter
public class OpaParkingInoutEventDto {
	private String bldId;
	private String objectId;
	private String eventDatetime;
	private Integer inoutvehicleEventSeq;
	private String auditDatetime;
	private String invehicleTypeCd;
	private String outvehicleTypeCd;
	private String vehicleNum;
	private String invehicleDatetime;
	private String outvehicleDatetime;
	private Double prkMunitTm;

}
