package com.adtcaps.tsop.domain.mashup;

import lombok.Getter;
import lombok.Setter;

/**
 * 
 * <ul>
 * <li>업무 그룹명 : tsop-backend-api</li>
 * <li>서브 업무명 : com.adtcaps.tsop.domain.mashup</li>
 * <li>설  명 : OmuFaultDto.java</li>
 * <li>작성일 : 2020. 12. 10.</li>
 * <li>작성자 : jeonyb4</li>
 * </ul>
 */
@Getter
@Setter
public class OmuFaultDto {
	private String bldId;
	private Integer faultId;
	private String auditDatetime;
	private String auditId;
	private String auditName;
	private String serviceClCd;
	private String eventDatetime;
	private Integer eventSeq;
	private String faultContent;
	private Integer alarmNoticeGroupId;
	private String faultReleaseDatetime;
	private String faultCategoryCd;
	private String registerId;
	private String registerName;
	private String faultActionStatusCd;
	private Integer attachFileNum;
	private String locFloor;
	private String objectName;
	private String serviceAlarmCdVal;
	private String serviceAlarmCdValName;
	private String objectId;
	private String alarmGradeCd;
	private String serviceAlarmCd;
	private String serviceAlarmCdName;

}
