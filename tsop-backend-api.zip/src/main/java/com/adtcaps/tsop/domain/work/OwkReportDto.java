package com.adtcaps.tsop.domain.work;

import lombok.Getter;
import lombok.Setter;

/**
 * 
 * <ul>
 * <li>업무 그룹명 : tsop-backend-api</li>
 * <li>서브 업무명 : com.adtcaps.tsop.domain.work</li>
 * <li>설  명 : OwkReportDto.java</li>
 * <li>작성일 : 2021. 12. 8.</li>
 * <li>작성자 : jeonyb4</li>
 * </ul>
 */
@Getter
@Setter
public class OwkReportDto {
	private String reportId;
	private Integer checkCycleId;
	private String bldId;
	private Integer approvalLineId;
	private String auditDatetime;
	private String reportName;
	private String titleImage;
	private String reportImageUrlAddr;
	private String approvalLineYn;

}
