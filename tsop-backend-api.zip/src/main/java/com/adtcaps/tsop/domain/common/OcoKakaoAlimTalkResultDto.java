package com.adtcaps.tsop.domain.common;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class OcoKakaoAlimTalkResultDto {
	private String msgIdx;
	private String bldId;
	private String tmpltCode;
	private String message;
	private String messageSendDate;
	private String recipient;
	private String sendResult;
	private String sendResultMsg;
	private String auditDatetime;
	private String auditId;
	private String auditName;
}
