package com.adtcaps.tsop.domain.common;

import lombok.Getter;
import lombok.Setter;

/**
 * 
 * <ul>
 * <li>업무 그룹명 : tsop-backend-api</li>
 * <li>서브 업무명 : com.adtcaps.tsop.domain.common</li>
 * <li>설  명 : OcoStreetnameAddressDto.java</li>
 * <li>작성일 : 2021. 1. 14.</li>
 * <li>작성자 : jeonyb4</li>
 * </ul>
 */
@Getter
@Setter
public class OcoStreetnameAddressDto {
	private String streetnameCd;
	private String undergroundYn;
	private Integer bldMlotnum;
	private Integer bldNlotnum;
	private String ldongCd;
	private String auditDatetime;
	private String auditId;
	private String auditName;
	private String ctGunGuCd;
	private String ctPvcName;
	private String ctGunGuName;
	private String upmyundongName;
	private String streetnameAddr;
	private String bldName;
	private String zipcode;
	private String bldUsageCategoryName;
	private String bldGroupYn;
	private String controlHdongCd;
	private String controlHdongName;
	private Double xCodnVal;
	private Double yCodnVal;
	private Double weatherForecastXCodnVal;
	private Double weatherForecastYCodnVal;
	private Double latitudeVal;
	private Double longitudeVal;

}
