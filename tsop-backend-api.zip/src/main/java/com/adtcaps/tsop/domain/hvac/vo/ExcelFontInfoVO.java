package com.adtcaps.tsop.domain.hvac.vo;

import io.swagger.annotations.ApiModel;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@ApiModel(value = "실시간 통합대기환경  분석  조회 Controller 에서의 결과값", description = "건물 외기의 엔탈피, 관측소에서 제공한 대기질(PM10,PM2.5) 수치를 조회한다.")

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class ExcelFontInfoVO {
    private Integer startIndex;     
    private Integer endIndex;
 
 
}
