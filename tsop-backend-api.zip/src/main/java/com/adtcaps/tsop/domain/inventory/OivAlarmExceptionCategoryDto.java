package com.adtcaps.tsop.domain.inventory;

import lombok.Getter;
import lombok.Setter;

/**
 * 
 * <ul>
 * <li>업무 그룹명 : tsop-backend-api</li>
 * <li>서브 업무명 : com.adtcaps.tsop.domain.inventory</li>
 * <li>설  명 : OivAlarmExceptionCategoryDto.java</li>
 * <li>작성일 : 2021. 10. 15.</li>
 * <li>작성자 : jeonyb4</li>
 * </ul>
 */
@Getter
@Setter
public class OivAlarmExceptionCategoryDto {
	private String bldId;
	private Integer alarmExceptionId;
	private String alarmExceptionCategoryCd;
	private String auditDatetime;
	private String includingYn;
	
}
