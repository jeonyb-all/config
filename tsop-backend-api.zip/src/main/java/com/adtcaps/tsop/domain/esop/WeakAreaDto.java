package com.adtcaps.tsop.domain.esop;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class WeakAreaDto {
	private String bldId;
	private String weakAreaId;
	private String weakAreaName;
	private String weakAreaClCd;
	private String weakAreaClCdName;
	private String weakAreaLoc;
	private String weakAreaLocName;
	private String locName;
	private Integer peopleCnt;
	private String checkList;
	private String weakAreaIcon;
	private String auditDatetime;
	private String auditId;
	private String auditName;
	private Integer cctvCnts;
}
