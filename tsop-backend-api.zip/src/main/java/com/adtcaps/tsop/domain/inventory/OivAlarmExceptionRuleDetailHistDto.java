package com.adtcaps.tsop.domain.inventory;

import lombok.Getter;
import lombok.Setter;

/**
 * 
 * <ul>
 * <li>업무 그룹명 : tsop-backend-api</li>
 * <li>서브 업무명 : com.adtcaps.tsop.domain.inventory</li>
 * <li>설  명 : OivAlarmExceptionRuleDetailHistDto.java</li>
 * <li>작성일 : 2021. 11. 30.</li>
 * <li>작성자 : jeonyb4</li>
 * </ul>
 */
@Getter
@Setter
public class OivAlarmExceptionRuleDetailHistDto {
	private Integer histSeq;
	private String bldId;
	private Integer alarmExceptionId;
	private String alarmExceptionCategoryCd;
	private Integer alarmExceptionSeq;
	private String beforeAfterCd;
	private String alarmExceptionValFirst;
	private String alarmExceptionValSecond;

}
