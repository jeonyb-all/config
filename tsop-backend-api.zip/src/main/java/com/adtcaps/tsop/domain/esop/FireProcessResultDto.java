package com.adtcaps.tsop.domain.esop;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class FireProcessResultDto {
	private String bldId;
	private String fireResultId;
	private String processStartDate;
	private String processEndDate;
	private String fireGradeCd;
	private String auditDatetime;
	/*private String traningYn;*/
}
