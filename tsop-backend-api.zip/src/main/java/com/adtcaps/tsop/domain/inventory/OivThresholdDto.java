package com.adtcaps.tsop.domain.inventory;

import lombok.Getter;
import lombok.Setter;

/**
 * 
 * <ul>
 * <li>업무 그룹명 : tsop-backend-api</li>
 * <li>서브 업무명 : com.adtcaps.tsop.domain.inventory</li>
 * <li>설  명 : OivThresholdDto.java</li>
 * <li>작성일 : 2020. 12. 21.</li>
 * <li>작성자 : jeonyb4</li>
 * </ul>
 */
@Getter
@Setter
public class OivThresholdDto {
	private String bldId;
	private Integer thresholdId;
	private String auditDatetime;
	private String auditId;
	private String auditName;
	private String serviceClCd;
	private String eventId;
	private String itemId;
	private String grade1AlarmStandardVal;
	private String grade2AlarmStandardVal;
	private String grade3AlarmStandardVal;
	private String grade4AlarmStandardVal;
	private String eventTypeCd;

}
