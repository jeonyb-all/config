package com.adtcaps.tsop.domain.common;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

import lombok.Getter;
import lombok.Setter;

/**
 * 
 * <ul>
 * <li>업무 그룹명 : tsop-backend-api</li>
 * <li>서브 업무명 : com.adtcaps.tsop.domain.common</li>
 * <li>설  명 : OcoDashboardCardDto.java</li>
 * <li>작성일 : 2020. 12. 18.</li>
 * <li>작성자 : jeonyb4</li>
 * </ul>
 */
@Getter
@Setter
@JsonInclude(Include.NON_EMPTY)
public class OcoDashboardCardDto {
	private String serviceCardId;
	private String auditDatetime;
	private String auditId;
	private String auditName;
	private String serviceCardName;
	private String serviceCardWebUrlAddr;
	private String serviceClCd;
	private Double popupWidthSize;
	private Double popupLengthSize;
	private String groupmgmtPageYn;
	private String useYn;
	private String registDatetime;
	private String registerId;
	private String registerName;
	private String totalYn;
	private String dashboardTabCd;

}
