package com.adtcaps.tsop.domain.work;

import lombok.Getter;
import lombok.Setter;

/**
 * 
 * <ul>
 * <li>업무 그룹명 : tsop-backend-api</li>
 * <li>서브 업무명 : com.adtcaps.tsop.domain.work</li>
 * <li>설  명 : OwkReportResultDto.java</li>
 * <li>작성일 : 2021. 12. 6.</li>
 * <li>작성자 : jeonyb4</li>
 * </ul>
 */
@Getter
@Setter
public class OwkReportResultDto {
	private String reportId;
	private String checkCycleCd;
	private String checkCycleVal;
	private String bldId;
	private String auditDatetime;
	private String auditId;
	private String auditName;
	private String registDatetime;
	private String registerId;
	private String registerName;
	private String reportStepCd;
	private String reportContents;
	private String reportStartDate;
	private String reportEndDate;
	private Integer attachFileNum;
	
}
