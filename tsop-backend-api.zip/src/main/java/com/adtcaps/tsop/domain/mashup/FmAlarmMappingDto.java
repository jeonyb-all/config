package com.adtcaps.tsop.domain.mashup;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

import lombok.Getter;
import lombok.Setter;

/**
 * 
 * <ul>
 * <li>업무 그룹명 : tsop-backend-api</li>
 * <li>서브 업무명 : com.adtcaps.tsop.domain.mashup</li>
 * <li>설  명 : FmAlarmMappingDto.java</li>
 * <li>작성일 : 2021. 2. 20.</li>
 * <li>작성자 : song</li>
 * </ul>
 */
@Getter
@Setter
@JsonInclude(Include.NON_EMPTY)
public class FmAlarmMappingDto {
	private String commonCd;
	private String commonCdName;
	private String commonCdVal;
	private String commonCdValName;
	private String serviceAlarmCdVal;
}
