package com.adtcaps.tsop.domain.esop;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class ResponseTeamHistDto {
	private Integer histSeq;
	private String bldId;
	private String responseTeamId;
	private String responseTeamChangeItemCd;
	private String newChangeClCd;
	private String changeBeforVal;
	private String changeAfterVal;
	private String auditId;
	private String auditName;
	private String auditDatetime;
	private String orgName;
	private String empId;
}
