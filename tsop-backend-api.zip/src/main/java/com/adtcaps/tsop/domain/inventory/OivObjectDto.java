package com.adtcaps.tsop.domain.inventory;

import lombok.Getter;
import lombok.Setter;

/**
 * 
 * <ul>
 * <li>업무 그룹명 : tsop-backend-api</li>
 * <li>서브 업무명 : com.adtcaps.tsop.domain.inventory</li>
 * <li>설  명 : OivObjectDto.java</li>
 * <li>작성일 : 2020. 12. 28.</li>
 * <li>작성자 : jeonyb4</li>
 * </ul>
 */
@Getter
@Setter
public class OivObjectDto {
	private String bldId;
	private String objectId;
	private String auditDatetime;
	private String objectName;
	private String objectTypeCd;
	private String objectDesc;
	private String measureUnitVal;
	private String registDate;
	private String changeDate;
	private String serviceClCd;
	private String serviceObjectId;
	private String superObjectId;
	private String superObjectRelCd;
	private String locFloor;
	private String locDongName;
	private String locZoneName;
	private String locRoomName;
	private String locXCodnVal;
	private String locYCodnVal;
	private String locZCodnVal;
	private String objectCategoryCd;
	private String deleteYn;
	private String deleteDate;

}
