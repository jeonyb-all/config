package com.adtcaps.tsop.domain.other;

import lombok.Getter;
import lombok.Setter;

/**
 * 
 * <ul>
 * <li>업무 그룹명 : tsop-backend-api</li>
 * <li>서브 업무명 : com.adtcaps.tsop.domain.other</li>
 * <li>설  명 : OotEarthquakeNoticeDto.java</li>
 * <li>작성일 : 2020. 12. 18.</li>
 * <li>작성자 : jeonyb4</li>
 * </ul>
 */
@Getter
@Setter
public class OotEarthquakeNoticeDto {
	private String equakeOccrDatetime;
	private Double latitudeVal;
	private Double longitudeVal;
	private String auditDatetime;
	private String equakeNotiSpotCd;
	private String equakeNotiKindCd;
	private String equakeNotiDateHourminute;
	private Integer equakeNotiSnum;
	private Integer refNum;
	private Integer equakeOccrTimesMsec;
	private String equakeOccrLocVal;
	private String equakeOccrLocImageVal;
	private Double equakeMagnitudeVal;
	private String equakeIntensiteVal;
	private Double equakeDepth;
	private String refInfo;
	private String updateInfo;

}
