/**
 *
 */
package com.adtcaps.tsop.domain.work;

import lombok.Getter;
import lombok.Setter;

/**
 * <ul>
 * <li>업무 그룹명 : com.adtcaps.tsop.domain.order</li>
 * <li>서브 업무명 : com.adtcaps.tsop.domain.order</li>
 * <li>설  명 : OwkWorkOrderDto.java</li>
 * <li>작성일 : 2021. 12. 7.</li>
 * <li>작성자 : msham</li>
 * </ul>
 */
@Getter
@Setter
public class OwkWorkOrderDto {
	private Integer workOrderId;
	private String bldId;
	private Integer formId;
	private String auditDatetime;
	private String workIndicatorId;
	private String workOrderDate;
	private Integer faultId;
	private String vocId;
	private String workDeadlineDate;
	private String workOrderComment;
	private String receiptDate;
	private String workStatusCd;
	private String workEndDate;
	private String partCategoryCd;
	private String workIndicatorName;
	private String worker01Name;
	private Integer checkCycleId;
	private String workPlanDate;
	private String workOrderName;
	private String workTypeCd;
	private String actionDetails;
	private Integer attachFileNum;
	private String worker02Name;
	private String worker03Name;
	private String locFloor;
	private String worker01Id;
	private String worker02Id;
	private String worker03Id;
	private String auditId;
	private String auditName;
	private String workResultYn;
}
