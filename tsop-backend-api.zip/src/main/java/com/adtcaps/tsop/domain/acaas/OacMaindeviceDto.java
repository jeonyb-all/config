package com.adtcaps.tsop.domain.acaas;

import lombok.Getter;
import lombok.Setter;

/**
 * 
 * <ul>
 * <li>업무 그룹명 : tsop-backend-api</li>
 * <li>서브 업무명 : com.adtcaps.tsop.domain.acaas</li>
 * <li>설  명 : OacMaindeviceDto.java</li>
 * <li>작성일 : 2021. 1. 11.</li>
 * <li>작성자 : jeonyb4</li>
 * </ul>
 */
@Getter
@Setter
public class OacMaindeviceDto {
	private String bldId;
	private String objectId;
	private String auditDatetime;
	private String maindeviceId;
	private String maindeviceName;
	private String maindeviceTypeCd;
	private String maindeviceNum;
	private String superObjectId;
	private String enterLocId;
	private String locFloor;

}
