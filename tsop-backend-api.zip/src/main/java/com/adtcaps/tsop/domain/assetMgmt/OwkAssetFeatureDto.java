package com.adtcaps.tsop.domain.assetMgmt;

import lombok.Getter;
import lombok.Setter;

/**
 * 
 * <ul>
 * <li>업무 그룹명 : tsop-backend-api</li>
 * <li>서브 업무명 : com.adtcaps.tsop.domain.assetMgmt</li>
 * <li>설  명 : OwkAssetFeatureDto.java</li>
 * <li>작성일 : 2021. 12. 15.</li>
 * <li>작성자 : ricky</li>
 * </ul>
 */

@Getter
@Setter
public class OwkAssetFeatureDto {
	private String bldId;
	private String assetId;
	private String assetFeatureId;
	private String auditDatetime;
	private String assetFeatureKey;
	private String assetFeatureVal;
	private String assetDistinctionUnit;
	private String assetName;
}