package com.adtcaps.tsop.domain.inventory;

import lombok.Getter;
import lombok.Setter;

/**
 * 
 * <ul>
 * <li>업무 그룹명 : tsop-backend-api</li>
 * <li>서브 업무명 : com.adtcaps.tsop.domain.inventory</li>
 * <li>설  명 : OivBuildingDto.java</li>
 * <li>작성일 : 2020. 12. 4.</li>
 * <li>작성자 : jeonyb4</li>
 * </ul>
 */
@Getter
@Setter
public class OivBuildingDto {
	private String bldId;
	private String auditDatetime;
	private String tenantId;
	private String bldName;
	private String bldAbbrName;
	private String lotnumAddr;
	private String streetnameAddr;
	private String ldongCd;
	private Double latitudeVal;
	private Double longitudeVal;
	private Double bldTotalfloorareaSize;
	private Double condAreaSize;
	private Double prksiteAreaSize;
	private Integer groundFloor;
	private Integer undergroundFloor;
	private String completDate;
	private Double weatherForecastXCodnVal;
	private Double weatherForecastYCodnVal;
	private String bldTypeCd;
	private String serviceStartDate;
	private String serviceEndDate;
	private String useYn;
	private Double mapXCodnVal;
	private Double mapYCodnVal;
	private String bldImageAddr;

}
