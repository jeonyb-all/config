package com.adtcaps.tsop.domain.staffMgmt;

import lombok.Getter;
import lombok.Setter;

/**
 * 
 * <ul>
 * <li>업무 그룹명 : tsop-backend-api</li>
 * <li>서브 업무명 : com.adtcaps.tsop.domain.staffMgmt</li>
 * <li>설  명 : OwkTeamDto.java</li>
 * <li>작성일 : 2021. 12. 7.</li>
 * <li>작성자 : ricky</li>
 * </ul>
 */

@Getter
@Setter
public class OwkTeamDto {
	private String bldId;
	private String teamId;
	private String auditDatetime;
	private String teamName;
	private String upperTeamId;
}