package com.adtcaps.tsop.domain.work;

import lombok.Getter;
import lombok.Setter;

/**
 * 
 * <ul>
 * <li>업무 그룹명 : tsop-backend-api</li>
 * <li>서브 업무명 : com.adtcaps.tsop.domain.work</li>
 * <li>설  명 : OwkWaterSubstationCheckDayStatDto.java</li>
 * <li>작성일 : 2022. 1. 4.</li>
 * <li>작성자 : jeonyb4</li>
 * </ul>
 */
@Getter
@Setter
public class OwkWaterSubstationCheckDayStatDto {
	private String bldId;
	private String sumDate;
	private String auditDatetime;
	private Double normalAvailableMidLoadPowerCheck;
	private Double normalAvailableMaxLoadPowerCheck;
	private Double normalAvailableLeastLoadPowerCheck;
	private Double normalInvalidityMidLoadPowerCheck;
	private Double normalInvalidityMaxLoadPowerCheck;
	private Double dikeHeatEtcPowerCheck;
	private Double dikeHeatleastPowerCheck;
	private Double septicTankMidLoadPowerCheck;
	private Double septicTankMaxLoadPowerCheck;
	private Double septicTankLeastLoadPowerCheck;
	private Double normalAvailableMidLoadPower;
	private Double normalAvailableMaxLoadPower;
	private Double normalAvailableLeastLoadPower;
	private Double normalInvalidityMidLoadPower;
	private Double normalInvalidityMaxLoadPower;
	private Double dikeHeatEtcPower;
	private Double dikeHeatleastPower;
	private Double septicTankMidLoadPower;
	private Double septicTankMaxLoadPower;
	private Double septicTankLeastLoadPower;
	private Double dikeHeatFrzmchDayUseTiem;
	private Double dikeHeatFrzmchNightUseTiem;
	private Double eh16CorrectionBeforPower;
	private Double lv11CorrectionBeforPower;
	private Double lv21CorrectionBeforPower;
	private Double lv31CorrectionBeforPower;
	private Double lv41CorrectionBeforPower;
	private Double lv51CorrectionBeforPower;
	private Double lv61CorrectionBeforPower;
	private Double hcmCorrectionBeforPower;
	private Double eh16CorrectionAfterPower;
	private Double lv11CorrectionAfterPower;
	private Double lv21CorrectionAfterPower;
	private Double lv31CorrectionAfterPower;
	private Double lv41CorrectionAfterPower;
	private Double lv51CorrectionAfterPower;
	private Double lv61CorrectionAfterPower;
	private Double hcmCorrectionAfterPower;

}
