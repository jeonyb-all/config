package com.adtcaps.tsop.domain.assetMgmt;

import lombok.Getter;
import lombok.Setter;

/**
 * 
 * <ul>
 * <li>업무 그룹명 : tsop-backend-api</li>
 * <li>서브 업무명 : com.adtcaps.tsop.domain.work</li>
 * <li>설  명 : OwkAssetDto.java</li>
 * <li>작성일 : 2021. 12. 15.</li>
 * <li>작성자 : ricky</li>
 * </ul>
 */

@Getter
@Setter
public class OwkAssetDto {
	private String bldId;
	private String assetId;
	private String assetName;
	private String assetCategoryLvl01Cd;
	private String assetCategoryLvl02Cd;
	private String assetCategoryLvl03Cd;
	private String assetCategoryLvl04Cd;
	private String assetModelName;
	private String assetStatusCd;
	private String manageYn;
	private String auditDatetime;
	private String assetMangementAdminId;
	private String assetMangementDeputyId;
	private String assetMangementAdminName;
	private String assetMangementDeputyName;
	private String locFloor;
	private String installationDate;
	private String assetProducer;
	private String repairCycleCd;
	private String checkCycleCd;
	private String noteVal;
	private String auditId;
	private String auditName;
}