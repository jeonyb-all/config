package com.adtcaps.tsop.domain.hvac.vo;

import java.util.List;

import javax.validation.constraints.Size;

import com.adtcaps.tsop.dashboard.api.hvac.domain.AirQualityCO2InfoVO;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@ApiModel(value = "층별 공기질CO2 정보", description = "층별 공기질CO2정보")

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class FloorAirQualityCO2MergeInfoVO {
	@ApiModelProperty(position = 1 , required = false, value="건물ID", example = "0000")
	@Size(min = 1, max = 4, message="건물ID는 4자리입니다") 
	private String bldId	;//	건물ID

	@ApiModelProperty(position = 1 , required = false, value="건물ID", example = "T타워") 
	private String bldName	;//	건물명

	@ApiModelProperty(position = 3 , required = false, value="층정보", example = "2F")
	private String locFloor;//층정보
 
    private String deviceLocCd;//센서위치코드
    private String deviceLocName;//센서위치명

	@ApiModelProperty(position = 7 , required = false, value="총건수", example = "232")
	private Integer totalCount;//	

    @ApiModelProperty(position = 7 , required = false, value="시간00", example = "00")
    private List<AirQualityCO2InfoVO> hour00;// 

    @ApiModelProperty(position = 7 , required = false, value="시간01", example = "01")
    private List<AirQualityCO2InfoVO> hour01;// 

    @ApiModelProperty(position = 7 , required = false, value="시간02", example = "02")
    private List<AirQualityCO2InfoVO> hour02;// 

    @ApiModelProperty(position = 7 , required = false, value="시간03", example = "03")
    private List<AirQualityCO2InfoVO> hour03;// 
    

    @ApiModelProperty(position = 7 , required = false, value="시간04", example = "04")
    private List<AirQualityCO2InfoVO> hour04;// 

    @ApiModelProperty(position = 7 , required = false, value="시간05", example = "05")
    private List<AirQualityCO2InfoVO> hour05;// 

    @ApiModelProperty(position = 7 , required = false, value="시간06", example = "06")
    private List<AirQualityCO2InfoVO> hour06;// 

    @ApiModelProperty(position = 7 , required = false, value="시간07", example = "07")
    private List<AirQualityCO2InfoVO> hour07;// 

    @ApiModelProperty(position = 7 , required = false, value="시간08", example = "08")
    private List<AirQualityCO2InfoVO> hour08;// 

    @ApiModelProperty(position = 7 , required = false, value="시간09", example = "09")
    private List<AirQualityCO2InfoVO> hour09;// 
    

    @ApiModelProperty(position = 7 , required = false, value="시간10", example = "10")
    private List<AirQualityCO2InfoVO> hour10;// 

    @ApiModelProperty(position = 7 , required = false, value="시간11", example = "11")
    private List<AirQualityCO2InfoVO> hour11;// 

    @ApiModelProperty(position = 7 , required = false, value="시간12", example = "12")
    private List<AirQualityCO2InfoVO> hour12;// 

    @ApiModelProperty(position = 7 , required = false, value="시간13", example = "13")
    private List<AirQualityCO2InfoVO> hour13;// 
    

    @ApiModelProperty(position = 7 , required = false, value="시간14", example = "14")
    private List<AirQualityCO2InfoVO> hour14;// 

    @ApiModelProperty(position = 7 , required = false, value="시간15", example = "15")
    private List<AirQualityCO2InfoVO> hour15;// 

    @ApiModelProperty(position = 7 , required = false, value="시간16", example = "16")
    private List<AirQualityCO2InfoVO> hour16;// 

    @ApiModelProperty(position = 7 , required = false, value="시간17", example = "17")
    private List<AirQualityCO2InfoVO> hour17;// 

    @ApiModelProperty(position = 7 , required = false, value="시간18", example = "18")
    private List<AirQualityCO2InfoVO> hour18;// 

    @ApiModelProperty(position = 7 , required = false, value="시간19", example = "19")
    private List<AirQualityCO2InfoVO> hour19;// 
    
    
    @ApiModelProperty(position = 7 , required = false, value="시간20", example = "20")
    private List<AirQualityCO2InfoVO> hour20;// 

    @ApiModelProperty(position = 7 , required = false, value="시간21", example = "21")
    private List<AirQualityCO2InfoVO> hour21;// 

    @ApiModelProperty(position = 7 , required = false, value="시간22", example = "22")
    private List<AirQualityCO2InfoVO> hour22;// 

    @ApiModelProperty(position = 7 , required = false, value="시간23", example = "23")
    private List<AirQualityCO2InfoVO> hour23;// 
    


 
	}
