package com.adtcaps.tsop.domain.hvac.vo;

import java.util.Date;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;


/**
 * 배치 연동에 대한 결과를 테이블에 저장하기 위한 info
 * <ul>
 * <li>업무 그룹명 : com.adtcaps.tsopconnectivityexternal.common.model</li>
 * <li>서브 업무명 : com.adtcaps.tsopconnectivityexternal.common.model</li>
 * <li>설  명 : 연동 </li>
 * <li>작성일 : 2021. 11. 1.</li>
 * <li>작성자 : supekss</li>
 * </ul>
 */
@NoArgsConstructor
@AllArgsConstructor
@Data
public class OcoBuildingAddInfoCollectVO  {
      
    private  String  bldId   ;// 건물ID
    private Date    auditDatetime   ;// 최종변경일시
    private String  passCollectYn   ;// PASS연동여부
    private String  plantId ;// 권역ID
    private String  aiHeatSourceStandardYn  ;// 열원조합최적화 연동 사용여부
    private String  aiOutCoolOperationYn    ;// 외기냉방현황분석 연동 사용여부
    private String  aiDamperStandardYn  ;// 층별외기댐퍼개도율 연동 사용여부
    private String  powerClientNum  ;// 전력고객번호
    private String  airQualityCo2Yn ;// 공기질CO2 연동 사용여부
    private Integer  airQualityCo2BaseVal ;// 공기질CO2 기준값


    
}
