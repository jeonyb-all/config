package com.adtcaps.tsop.domain.esop;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class ContactNetworkHistDto {
	private Integer histSeq;
	private String bldId;
	private String contactNetworkId;
	private String contactNetworkChangeItemCd;
	private String newChangeClCd;
	private String changeBeforVal;
	private String changeAfterVal;
	private String auditId;
	private String auditName;
	private String auditDatetime;
	private String orgName;
	private String empId;
}
