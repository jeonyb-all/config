package com.adtcaps.tsop.domain.hvac.vo;

import io.swagger.annotations.ApiModel;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@ApiModel(value = "현재시간  결과값", description = "현재시간  결과값를  조회한다.")

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class HvacCurrentDateInfoVO {

    private String base15DateHourminute     ;     //15분단위 : 년월일시분
    private String base15KorSimpleHourminute;     //15분단위 : HH시mm분
    private String currDateHourminute       ;     //실시간    : 년월일시분
    private String currKorSimpleHourminute  ;     //실시간    : HH시mm분
    
    private String currDateHour       ;     //실시간    : 년월일시
    private String currKorSimpleHour  ;     //실시간    : HH시
    	
 
}
