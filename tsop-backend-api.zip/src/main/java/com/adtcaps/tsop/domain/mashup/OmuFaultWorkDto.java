package com.adtcaps.tsop.domain.mashup;

import lombok.Getter;
import lombok.Setter;

/**
 * 
 * <ul>
 * <li>업무 그룹명 : tsop-backend-api</li>
 * <li>서브 업무명 : com.adtcaps.tsop.domain.mashup</li>
 * <li>설  명 : OmuFaultWorkDto.java</li>
 * <li>작성일 : 2021. 12. 29.</li>
 * <li>작성자 : jeonyb4</li>
 * </ul>
 */
@Getter
@Setter
public class OmuFaultWorkDto {
	private String bldId;
	private Integer faultId;
	private String auditDatetime;
	private String auditId;
	private String serviceClCd;
	private String eventDatetime;
	private Integer eventSeq;
	private Integer alarmNoticeGroupId;
	private String registerId;
	private String locFloor;
	private String objectName;
	private String serviceAlarmCdVal;
	private String serviceAlarmCdValName;
	private String objectId;
	private String alarmGradeCd;
	private String serviceAlarmCd;
	private String serviceAlarmCdName;
	private String occrDatetime;
	private String auditName;
	private String registerName;

}
