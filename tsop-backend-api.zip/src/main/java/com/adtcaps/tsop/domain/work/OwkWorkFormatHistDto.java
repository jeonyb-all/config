/**
 *
 */
package com.adtcaps.tsop.domain.work;

import lombok.Getter;
import lombok.Setter;

/**
 * <ul>
 * <li>업무 그룹명 : com.adtcaps.tsop.domain.work</li>
 * <li>서브 업무명 : com.adtcaps.tsop.domain.work</li>
 * <li>설  명 : OwkWorkFormatHistDto.java</li>
 * <li>작성일 : 2021. 12. 23.</li>
 * <li>작성자 : msham</li>
 * </ul>
 */
@Getter
@Setter
public class OwkWorkFormatHistDto {

	private Integer histSeq;
	private String bldId;
	private Integer formId;
	private String formName;
	private String changeDatetime;
	private String changerId;
	private String changerName;
	private String newChangeClCd;
	private String formatChangeItemCd;
	private String registDatetime;
	private String registerId;
	private String registerName;
	private String auditDatetime;
	private String auditId;
	private String auditName;
	private String changeBeforVal;
	private String changeAfterVal;

}
