package com.adtcaps.tsop.domain.other;

import lombok.Getter;
import lombok.Setter;

/**
 * 
 * <ul>
 * <li>업무 그룹명 : tsop-backend-api</li>
 * <li>서브 업무명 : com.adtcaps.tsop.domain.other</li>
 * <li>설  명 : OotAirQualityDto.java</li>
 * <li>작성일 : 2020. 12. 18.</li>
 * <li>작성자 : jeonyb4</li>
 * </ul>
 */
@Getter
@Setter
public class OotAirQualityDto {
	private String bldId;
	private String measureDateHourminute;
	private String auditDatetime;
	private String measureNetInfo;
	private Double h2so3Concent;
	private Double coConcent;
	private Double o3Concent;
	private Double no2Concent;
	private Double finedustPm10Concent;
	private Double finedustPm10Hr24PredMoveConcent;
	private Double finedustPm2p5Concent;
	private Double finedustPm2p5Hr24PredMoveConcent;
	private Double integrateAirEnvNumval;
	private String integrateAirEnvGradeCd;
	private String h2so3NumidxGradeCd;
	private String coNumidxGradeCd;
	private String o3NumidxGradeCd;
	private String no2NumidxGradeCd;
	private String finedustPm10Hr24GradeCd;
	private String finedustPm2p5Hr24GradeCd;
	private String finedustPm10Hr1GradeCd;
	private String finedustPm2p5Hr1GradeCd;

}
