package com.adtcaps.tsop.domain.common;

import lombok.Getter;
import lombok.Setter;

/**
 * 
 * <ul>
 * <li>업무 그룹명 : tsop-backend-api</li>
 * <li>서브 업무명 : com.adtcaps.tsop.domain.common</li>
 * <li>설  명 : OcoBatchJobDto.java</li>
 * <li>작성일 : 2020. 12. 28.</li>
 * <li>작성자 : jeonyb4</li>
 * </ul>
 */
@Getter
@Setter
public class OcoBatchJobDto {
	private String batchJobId;
	private String auditDatetime;
	private String auditId;
	private String auditName;
	private String bldId;
	private String serviceClCd;
	private String batchJobName;
	private String batchJobDesc;
	private String batchJobPgmName;
	private String startTimes;
	private String monthUnitExecCycleVal;
	private String weekUnitExecCycleVal;
	private String dayUnitExecCycleVal;
	private String hourUnitExecCycleVal;
	private String minuteUnitExecCycleVal;
	private String useYn;
	private String startDate;
	private String endDate;

}
