package com.adtcaps.tsop.domain.esop;

import java.util.List;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class ContactNetworkMemberDto {
	private String bldId;
	private String empId;
	private String responseTeamId;
	private String responseTeamName;
	private String contactNetworkId;
	private String contactNetworkName;
	private String auditDatetime;
	private String auditId;
	private String auditName;
	private List<String> empIdList;
}
