package com.adtcaps.tsop.domain.esop;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class ResponseTeamDto {
	private String bldId;
	private String responseTeamId;
	private String responseTeamName;
	private String defaultYn;
	private String mainTask;
	private String organization;
	private String step1Task;
	private String step2Task;
	private String step3Task;
	private String step4Task;
	private String auditDatetime;
	private String auditId;
	private String auditName;
}
