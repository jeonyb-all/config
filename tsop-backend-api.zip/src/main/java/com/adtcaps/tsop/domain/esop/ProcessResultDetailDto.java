package com.adtcaps.tsop.domain.esop;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class ProcessResultDetailDto {
	private String bldId;
	private String fireResultId;
	private String processId;
	private String stepId;
	private String fireGradeCd;
	private String stepName;
	private String taskTitle;
	private String regDatetime;
	private String processEndDate;
	private String displayYn;
	private String auditId;
	private String auditName;
}
