package com.adtcaps.tsop.domain.esop;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class ContactNetworkDto {
	private String bldId;
	private String contactNetworkId;
	private String contactNetworkName;
	private String auditDatetime;
	private String auditId;
	private String auditName;
}
