package com.adtcaps.tsop.domain.common;

import lombok.Getter;
import lombok.Setter;

/**
 * 
 * <ul>
 * <li>업무 그룹명 : tsop-backend-api</li>
 * <li>서브 업무명 : com.adtcaps.tsop.domain.common</li>
 * <li>설  명 : OcoUserHistDto.java</li>
 * <li>작성일 : 2021. 12. 2.</li>
 * <li>작성자 : jeonyb4</li>
 * </ul>
 */
@Getter
@Setter
public class OcoUserHistDto {
	private Integer histSeq;
	private String changeDatetime;
	private String changerId;
	private String changerName;
	private String newChangeClCd;
	private String userChangeItemCd;
	private String userId;
	private String userName;
	private String auditDatetime;
	private String auditId;
	private String auditName;
	private String changeBeforVal;
	private String changeAfterVal;

}
