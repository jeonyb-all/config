package com.adtcaps.tsop.domain.common;

import lombok.Getter;
import lombok.Setter;

/**
 * 
 * <ul>
 * <li>업무 그룹명 : tsop-backend-api</li>
 * <li>서브 업무명 : com.adtcaps.tsop.domain.common</li>
 * <li>설  명 : OcoTechSupportRequestDto.java</li>
 * <li>작성일 : 2020. 12. 15.</li>
 * <li>작성자 : jeonyb4</li>
 * </ul>
 */
@Getter
@Setter
public class OcoTechSupportRequestDto {
	private Integer techSupportReqId;
	private String auditDatetime;
	private String bldId;
	private String reqerName;
	private String techSupportReqTypeCd;
	private String registDatetime;
	private String reqTitleName;
	private String reqContent;
	private String techSupportStatusCd;
	private Integer attachFileNum;

}
