package com.adtcaps.tsop.domain.inventory;

import lombok.Getter;
import lombok.Setter;

/**
 * 
 * <ul>
 * <li>업무 그룹명 : tsop-backend-api</li>
 * <li>서브 업무명 : com.adtcaps.tsop.domain.inventory</li>
 * <li>설  명 : OivControlCommandTypeCodeDto.java</li>
 * <li>작성일 : 2021. 1. 15.</li>
 * <li>작성자 : jeonyb4</li>
 * </ul>
 */
@Getter
@Setter
public class OivControlCommandTypeCodeDto {
	private String bldId;
	private String controlCmdTypeCd;
	private String auditDatetime;
	private String serviceClCd;
	private String controlCmdTypeCdName;
	private Integer controlCmdCdValQty;
	private String controlCmdResultYn;
	private String syncMethodClCd;
	private String controlCmdTypeUrlAddr;
	private String controlCmdExecPassword;
	private String registDatetime;
	private String registerId;
	private String registerName;

}
