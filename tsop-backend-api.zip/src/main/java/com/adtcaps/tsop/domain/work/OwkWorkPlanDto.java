/**
 *
 */
package com.adtcaps.tsop.domain.work;

import lombok.Getter;
import lombok.Setter;

/**
 * <ul>
 * <li>업무 그룹명 : com.adtcaps.tsop.domain.work</li>
 * <li>서브 업무명 : com.adtcaps.tsop.domain.work</li>
 * <li>설  명 : OwkWorkPlanDto.java</li>
 * <li>작성일 : 2021. 12. 12.</li>
 * <li>작성자 : msham</li>
 * </ul>
 */
@Getter
@Setter
public class OwkWorkPlanDto {

	private String bldId;
	private Integer checkCycleId;
	private Integer formId;
	private String workPlanDate;
	private String auditDatetime;
	private String partCategoryCd;
	private String checkCycleCd;
	private String workStatusCd;
}
