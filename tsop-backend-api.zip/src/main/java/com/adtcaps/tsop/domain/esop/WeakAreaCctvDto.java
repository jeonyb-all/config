package com.adtcaps.tsop.domain.esop;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class WeakAreaCctvDto {
	private String bldId;
	private String objectId;
	private String weakAreaId;
	private String cctvEquipName;
	private String locFloor;
	private String auditDatetime;
}
