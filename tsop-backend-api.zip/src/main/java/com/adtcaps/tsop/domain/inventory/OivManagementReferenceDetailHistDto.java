package com.adtcaps.tsop.domain.inventory;

import lombok.Getter;
import lombok.Setter;

/**
 * 
 * <ul>
 * <li>업무 그룹명 : tsop-backend-api</li>
 * <li>서브 업무명 : com.adtcaps.tsop.domain.inventory</li>
 * <li>설  명 : OivManagementReferenceDetailHistDto.java</li>
 * <li>작성일 : 2021. 10. 20.</li>
 * <li>작성자 : jeonyb4</li>
 * </ul>
 */
@Getter
@Setter
public class OivManagementReferenceDetailHistDto {
	private String bldId;
	private String managementCategoryCd;
	private Integer managementCategorySeq;
	private String changeDatetime;
	private Integer referenceMonth;
	private String locFloor;
	private String referenceValFirst;
	private String referenceValSecond;
	private String managementDetailCd;
	private String auditDatetime;

}
