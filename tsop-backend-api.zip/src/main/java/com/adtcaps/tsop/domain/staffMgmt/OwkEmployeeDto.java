package com.adtcaps.tsop.domain.staffMgmt;

import lombok.Getter;
import lombok.Setter;

/**
 * 
 * <ul>
 * <li>업무 그룹명 : tsop-backend-api</li>
 * <li>서브 업무명 : com.adtcaps.tsop.domain.staffMgmt</li>
 * <li>설  명 : OwkEmployeeDto.java</li>
 * <li>작성일 : 2021. 12. 7.</li>
 * <li>작성자 : ricky</li>
 * </ul>
 */

@Getter
@Setter
public class OwkEmployeeDto {
	private String bldId;
	private String empId;
	private String teamId;
	private String auditDatetime;
	private String empName;
	private String positionCd;
	private String rankCd;
	private String contactPhoneNum;
	private String emailAddress;
	private String companyName;
	private String empStateCd;
	private String accountYn;
	private String userId;
	private String enterDate;
	private String auditId;
	private String auditName;
}