package com.adtcaps.tsop.domain.other;

import lombok.Getter;
import lombok.Setter;

/**
 * 
 * <ul>
 * <li>업무 그룹명 : tsop-backend-api</li>
 * <li>서브 업무명 : com.adtcaps.tsop.domain.other</li>
 * <li>설  명 : OotWeatherForecastExtraShortDto.java</li>
 * <li>작성일 : 2020. 12. 18.</li>
 * <li>작성자 : jeonyb4</li>
 * </ul>
 */
@Getter
@Setter
public class OotWeatherForecastExtraShortDto {
	private String bldId;
	private String announceDateHourminute;
	private String predDateHourminute;
	private String auditDatetime;
	private Double weatherForecastXCodnVal;
	private Double weatherForecastYCodnVal;
	private String temprVal;
	private String hr1RainfallVal;
	private String skyStatusVal;
	private String ewwindIngredientVal;
	private String snwindIngredientVal;
	private String humidityVal;
	private String rainfallFormCd;
	private String lightningVal;
	private String winddirectVal;
	private String windspeedVal;

}
