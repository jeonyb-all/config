package com.adtcaps.tsop.domain.esop;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class EsopProcessDto {
	private String processId;
	private String bldId;
	private String stepId;
	private String stepName;
	private String taskStep;
	private String taskTitle;
	private String esopTaskCd;
	private String contactNetworkId;
	private String endYn;
	private String displayYn;
	private String workExplanation;
	private String auditDatetime;
	private String auditId;
	private String auditName;
}
