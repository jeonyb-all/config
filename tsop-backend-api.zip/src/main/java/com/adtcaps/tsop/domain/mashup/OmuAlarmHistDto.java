package com.adtcaps.tsop.domain.mashup;

import lombok.Getter;
import lombok.Setter;

/**
 * 
 * <ul>
 * <li>업무 그룹명 : tsop-backend-api</li>
 * <li>서브 업무명 : com.adtcaps.tsop.domain.mashup</li>
 * <li>설  명 : OmuAlarmHistDto.java</li>
 * <li>작성일 : 2021. 10. 13.</li>
 * <li>작성자 : jeonyb4</li>
 * </ul>
 */
@Getter
@Setter
public class OmuAlarmHistDto {
	private Integer eventHistSeq;
	private Integer eventSeq;
	private String bldId;
	private String serviceAlarmCdVal;
	private String serviceAlarmCd;
	private String eventDatetime;
	private String serviceClCd;
	private String auditDatetime;
	private String alarmGradeCd;
	private String occrDatetime;
	private String checkDatetime;
	private String checkYn;
	private String objectId;
	private String objectName;
	private String serviceAlarmCdName;
	private Integer serviceAlarmEventSeq;
	private String serviceAlarmCdValName;
	private String locFloor;
	private String locDongName;
	private String locZoneName;
	private String locRoomName;
	private Double locXCodnVal;
	private Double locYCodnVal;
	private Double locZCodnVal;
	private Integer alarmExceptionId;
	private String alarmExceptionName;
	private String esopYn;
	private String clearYn;
	private String auditId;
	private String auditName;

}
