package com.adtcaps.tsop.domain.esop;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class FireGradeDto {
	private String fireGradeCd;
	private String bldId;
	private String fireSize;
	private String fireStep;
	private String damageHuman;
	private String damageProperty;
	private String disruptionComm;
	private String auditDatetime;
}
