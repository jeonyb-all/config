package com.adtcaps.tsop.domain.common;

import lombok.Getter;
import lombok.Setter;

/**
 * 
 * <ul>
 * <li>업무 그룹명 : tsop-backend-api</li>
 * <li>서브 업무명 : com.adtcaps.tsop.domain.common</li>
 * <li>설  명 : OcoBulletinboardDto.java</li>
 * <li>작성일 : 2020. 12. 4.</li>
 * <li>작성자 : jeonyb4</li>
 * </ul>
 */
@Getter
@Setter
public class OcoBulletinboardDto {
	private String bulletinTypeCd;
	private Integer bulletinNum;
	private String auditDatetime;
	private String bulletinClCd;
	private String bulletinTitleName;
	private String bulletinContent;
	private String registerId;
	private String registerName;
	private String registDatetime;
	private Integer superBulletinNum;
	private String bulletinStartDatetime;
	private String bulletinEndDatetime;
	private Integer browseCnt;
	private String deleteYn;
	private Integer attachFileNum;
	private String topBulletinYn;
	private String smsAlarmNoticeYn;
	private String pushAlarmNoticeYn;
	private String onmBulletinTypeCd;
	private Integer onmBulletinNum;
	private String auditId;		// O&M과 통신하기 위해 넣은 항목(실제 컬럼 없음)...

}
