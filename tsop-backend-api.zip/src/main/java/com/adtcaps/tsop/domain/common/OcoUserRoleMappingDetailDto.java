package com.adtcaps.tsop.domain.common;

import lombok.Getter;
import lombok.Setter;

/**
 * 
 * <ul>
 * <li>업무 그룹명 : tsop-backend-api</li>
 * <li>서브 업무명 : com.adtcaps.tsop.domain.common</li>
 * <li>설  명 : OcoUserRoleMappingDetailDto.java</li>
 * <li>작성일 : 2020. 12. 16.</li>
 * <li>작성자 : jeonyb4</li>
 * </ul>
 */
@Getter
@Setter
public class OcoUserRoleMappingDetailDto {
	private String userId;
	private String roleId;
	private Integer roleDetailSeq;
	private String auditDatetime;
	private String bldId;
	private String bldTypeCd;
	private String serviceClCd;

}
