package com.skt.tango;

import org.keycloak.adapters.springboot.KeycloakSpringBootConfigResolver;
import org.keycloak.admin.client.Keycloak;
import org.keycloak.admin.client.KeycloakBuilder;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.context.annotation.PropertySources;

@Configuration
@PropertySources({
	@PropertySource("classpath:properties/keycloak.properties")
})
public class KeycloakConfiguration {
	@Value("${keycloak.auth-server-url}")
	private String authServerUrl;

	@Value("${keycloak.realm}")
	private String adminRealm;

	@Value("${keycloak.resource}")
	private String adminClientId;

	@Value("${tango.keycloak.admin.username}")
	private String adminUsername;
	
	@Value("${tango.keycloak.admin.password}")
	private String adminPassword;
	
	/**
	 * 
	 * keycloak.json 대신에 Spring Boot yml 파일을 이용하도록 돕는다.
	 */
	@Bean
	public KeycloakSpringBootConfigResolver KeycloakConfigResolver() {
		return new KeycloakSpringBootConfigResolver();
	}
	
	@Bean
	public Keycloak adminKeycloak() {
		return KeycloakBuilder.builder()
				.serverUrl(authServerUrl)
				.realm(adminRealm)
				.username(adminUsername)
				.password(adminPassword)
				.clientId(adminClientId)
				.build();
	}
	
}
