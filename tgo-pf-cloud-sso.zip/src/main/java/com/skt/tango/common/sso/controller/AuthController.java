package com.skt.tango.common.sso.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.skt.tango.common.sso.model.ClientVO;
import com.skt.tango.common.sso.model.SsoVO;
import com.skt.tango.common.sso.service.AuthService;

@RestController
@RequestMapping("/tango-common-sso/sso")
public class AuthController {
	
	@Autowired
	private AuthService authService;
	
	
	@RequestMapping(value="/login", method=RequestMethod.POST, produces=MediaType.APPLICATION_JSON_VALUE, consumes=MediaType.APPLICATION_JSON_VALUE)
	public SsoVO publishToken(@RequestBody SsoVO ssoVO) {
		
		System.out.println("AAAAAAAAAAAAAAAAAAAAAAAAAAAA");

		ssoVO = authService.publishToken(ssoVO);
		
    	return ssoVO;
	}
	
	
	@RequestMapping(value="/token/verify", method=RequestMethod.POST, produces=MediaType.APPLICATION_JSON_VALUE, consumes=MediaType.APPLICATION_JSON_VALUE)
	public SsoVO verifyToken(@RequestBody SsoVO ssoVO) {
		
		System.out.println("CCCCCCCCCCCCCCCCCCCCCCCCCCCCC");

		ssoVO = authService.verifyToken(ssoVO);
		
    	return ssoVO;
	}
	
	
	@RequestMapping(value="/logout", method=RequestMethod.POST, produces=MediaType.APPLICATION_JSON_VALUE, consumes=MediaType.APPLICATION_JSON_VALUE)
	public SsoVO logoutToken(@RequestBody SsoVO ssoVO) {
		
		System.out.println("DDDDDDDDDDDDDDDDDDDDDDDDDDDDD");

		ssoVO.setLoginUserStatus(200);
		
    	return ssoVO;
	}
	
	
	@RequestMapping(value="/apply-client", method=RequestMethod.POST, produces=MediaType.APPLICATION_JSON_VALUE, consumes=MediaType.APPLICATION_JSON_VALUE)
	public ClientVO applyClient(@RequestBody ClientVO clientVO) {
		
		System.out.println("BBBBBBBBBBBBBBBBBBBBBBBBBBBB");

		clientVO = authService.applyClient(clientVO);
		
    	return clientVO;
	}
	
	
//	@RequestMapping(value="/modify-client", method=RequestMethod.POST, produces=MediaType.APPLICATION_JSON_VALUE, consumes=MediaType.APPLICATION_JSON_VALUE)
//	public ClientVO modifyClient(@RequestBody ClientVO clientVO) {
//		
//		System.out.println("BBBBBBBBBBBBBBBBBBBBBBBBBBBB");
//
//		clientVO = authService.modifyClient(clientVO);
//		
//    	return clientVO;
//	}
	
	
	@RequestMapping(value="/delete-client", method=RequestMethod.POST, produces=MediaType.APPLICATION_JSON_VALUE, consumes=MediaType.APPLICATION_JSON_VALUE)
	public ClientVO removeClient(@RequestBody ClientVO clientVO) {
		
		System.out.println("BBBBBBBBBBBBBBBBBBBBBBBBBBBB");

		clientVO = authService.removeClient(clientVO);
		
    	return clientVO;
	}

}
