package com.skt.tango.common.sso.service;

import java.security.KeyFactory;
import java.security.interfaces.RSAPublicKey;
import java.security.spec.X509EncodedKeySpec;
import java.util.ArrayList;
import java.util.Base64;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.ws.rs.core.Response;

import org.apache.commons.lang3.StringUtils;
import org.keycloak.TokenVerifier;
import org.keycloak.admin.client.Keycloak;
import org.keycloak.admin.client.resource.ClientResource;
import org.keycloak.admin.client.resource.ClientsResource;
import org.keycloak.admin.client.resource.KeyResource;
import org.keycloak.admin.client.resource.RealmResource;
import org.keycloak.authorization.client.AuthzClient;
import org.keycloak.authorization.client.Configuration;
import org.keycloak.representations.AccessTokenResponse;
import org.keycloak.representations.JsonWebToken;
import org.keycloak.representations.idm.ClientRepresentation;
import org.keycloak.representations.idm.KeysMetadataRepresentation;
import org.keycloak.representations.idm.KeysMetadataRepresentation.KeyMetadataRepresentation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.PropertySource;
import org.springframework.context.annotation.PropertySources;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import com.skt.tango.common.sso.model.ClientVO;
import com.skt.tango.common.sso.model.SsoVO;

@Service
@PropertySources({
	@PropertySource("classpath:properties/keycloak.properties")
})
public class AuthService {
	
	private static final String KEY_ALGORITHM = "RS256";
	
	@Value("${keycloak.auth-server-url}")
	private String authServerUrl;
	
	@Value("${tango.keycloak.grant.type}")
	private String keycloakGrantType;
	
	@Value("${tango.keycloak.realm}")
	private String tangoRealm;
	
	@Value("${tango.token.expired.check}")
	private boolean tokenExpriedCheck;
	
	@Autowired
	private Keycloak adminKeycloak;
	
	public SsoVO publishToken(SsoVO ssoVO) {
		try {
			// 파라미터 없음....
			if (ssoVO == null) {
				ssoVO = new SsoVO();
				ssoVO.setLoginUserStatus(-1000);
				return ssoVO;
			}
			String systmId = StringUtils.defaultString(ssoVO.getSystmId());
			if ("".equals(systmId)) {
				// 파라미터 systmId 없음...
				ssoVO.setLoginUserStatus(-990);
				return ssoVO;
			}
			String userId = StringUtils.defaultString(ssoVO.getUserId());
			if ("".equals(userId)) {
				// 파라미터 userId 없음...
				ssoVO.setLoginUserStatus(-991);
				return ssoVO;
			}
			String userPwd = StringUtils.defaultString(ssoVO.getUserPwd());
			if ("".equals(userPwd)) {
				// 파라미터 userPwd 없음...
				ssoVO.setLoginUserStatus(-992);
				return ssoVO;
			}
			
			// DB 조회 등.. Business Logic 처리...
			
//			int loginUserStatus = ssoVO.getLoginUserStatus();		// 성공 시.. 200
//			if (loginUserStatus == -1001 || loginUserStatus == -1011) {
//				// -1001 : 로그인 불가  or  -1011 : 비밀번호 오류
//				ssoVO.setTdayLginFailNcnt(ssoVO.getTdayLginFailNcnt() + 1);
//				// ssoDao.updateLoginFailCount(ssoVO); 처리해야 함...
//				if (ssoVO.getTdayLginFailNcnt() > 5) {
//					// 하루 로그인 실패 5회 초과....
//					ssoVO.setLoginUserStatus(-1008);
//				}
//				return ssoVO;
//			}
//			if (loginUserStatus != 200) {
//				return ssoVO;
//			}
			
			// Keycloak Process...
			ssoVO = getKeycloakToken(ssoVO);
			
		} catch (Exception e) {
			ssoVO.setLoginUserStatus(-101);
		}

	    return ssoVO;
	}
	
	private SsoVO getKeycloakToken(SsoVO ssoVO) {
		try {
			String systmId = ssoVO.getSystmId();
			String userId = ssoVO.getUserId();
			String userPwd = ssoVO.getUserPwd();
			
			// Get the Client Secret
			// Get the realm resource
			RealmResource realmResource = adminKeycloak.realm(tangoRealm);
			// Get the ClientsResource for the realm
			ClientsResource clientsResource = realmResource.clients();
			// Client Not Found...
			ClientRepresentation clientRepresentation = clientsResource.findByClientId(systmId).get(0);
			if (clientRepresentation == null) {
				ssoVO.setLoginUserStatus(-101);
				return ssoVO;
	        }
			// No ClientSecret...
			String clientSecret = StringUtils.defaultString(clientRepresentation.getSecret());
			if ("".equals(clientSecret)) {
				ssoVO.setLoginUserStatus(-102);
				return ssoVO;
	        }
			
			Map<String, Object> clientCredentials = new HashMap<>();
			clientCredentials.put("secret", clientSecret);
			clientCredentials.put("grant_type", keycloakGrantType);

			Configuration configuration = new Configuration(authServerUrl, tangoRealm, systmId, clientCredentials, null);
			
			AuthzClient authzClient = AuthzClient.create(configuration);
			AccessTokenResponse response = authzClient.obtainAccessToken(userId, userPwd);
			
			String tokenId = response.getToken();
			
			ssoVO.setTokenId(tokenId);
			
		} catch (Exception e) {
			throw e;
		}
		
		return ssoVO;
	}
	
	
	public SsoVO verifyToken(SsoVO ssoVO) {
		try {
			String systmId = StringUtils.defaultString(ssoVO.getSystmId());
			if ("".equals(systmId)) {
				System.out.println("파라미터에 systmId 없음!!!!!!!!!!!!!");
				ssoVO.setLoginUserStatus(-999);
				return ssoVO;
			}
			String userId = StringUtils.defaultString(ssoVO.getUserId());
			if ("".equals(userId)) {
				System.out.println("파라미터에 userId 없음!!!!!!!!!!!!!");
				ssoVO.setLoginUserStatus(-999);
				return ssoVO;
			}
        	String tokenId = StringUtils.defaultString(ssoVO.getTokenId());
			if ("".equals(tokenId)) {
				System.out.println("파라미터에 tokenId 없음!!!!!!!!!!!!!");
				ssoVO.setLoginUserStatus(-999);
				return ssoVO;
			}
			
			RealmResource realmResource = adminKeycloak.realm(tangoRealm);
			KeyResource keyResource = realmResource.keys();
			
			KeysMetadataRepresentation keysMetadataRepresentation = keyResource.getKeyMetadata();
			
			String publicKeyString = "";
			if (keysMetadataRepresentation != null) {
				List<KeyMetadataRepresentation> keyMetadataRepresentationList = keysMetadataRepresentation.getKeys();
				for (KeyMetadataRepresentation keyMetadataRepresentation : keyMetadataRepresentationList) {
					String algorithm = StringUtils.defaultString(keyMetadataRepresentation.getAlgorithm());
					if (KEY_ALGORITHM.equals(algorithm)) {
						publicKeyString = keyMetadataRepresentation.getPublicKey();
						break;
					}
				}
			}
			// Public Key Error...
			if ("".equals(publicKeyString)) {
				ssoVO.setLoginUserStatus(-201);
				return ssoVO;
			}
			
			byte[] publicKeyBytes = Base64.getDecoder().decode(publicKeyString);
			
			X509EncodedKeySpec keySpec = new X509EncodedKeySpec(publicKeyBytes);
			KeyFactory keyFactory = KeyFactory.getInstance("RSA");
			RSAPublicKey publicKey = (RSAPublicKey)keyFactory.generatePublic(keySpec);
			
			JsonWebToken jsonWebToken = TokenVerifier.create(tokenId, JsonWebToken.class)
                  .publicKey(publicKey)
                  .verify()
                  .getToken();
			
			// jsonWebToken NULL...
			if (jsonWebToken == null) {
				ssoVO.setLoginUserStatus(-202);
				return ssoVO;
			}
			
			// token is expired...
			if (tokenExpriedCheck) {
				if (jsonWebToken.isExpired()) {
					ssoVO.setLoginUserStatus(-203);
					return ssoVO;
				}
			}
			
			String keyClientId = StringUtils.defaultString(jsonWebToken.getIssuedFor());
			String keyUserId = StringUtils.defaultString(jsonWebToken.getOtherClaims().get("preferred_username").toString());
			
			// systmId 불일치...
			if (!systmId.equals(keyClientId)) {
				ssoVO.setLoginUserStatus(-204);
				return ssoVO;
			}
			// userId 불일치...
			if (!userId.equals(keyUserId)) {
				ssoVO.setLoginUserStatus(-205);
				return ssoVO;
			}
			
			ssoVO.setLoginUserStatus(200);
			
		} catch (Exception e) {
        	// token verify Exception 발생...
			ssoVO.setLoginUserStatus(-200);
        }
        
        return ssoVO;
	}
	
	
	public ClientVO applyClient(ClientVO clientVO) {
		
		try {
			String systmId = StringUtils.defaultString(clientVO.getSystmId());
			if ("".equals(systmId)) {
				System.out.println("파라미터에 systmId 없음!!!!!!!!!!!!!");
				clientVO.setClientStatus(-999);
				return clientVO;
			}
			String systmNm = StringUtils.defaultString(clientVO.getSystmNm());
			if ("".equals(systmNm)) {
				System.out.println("파라미터에 systmNm 없음!!!!!!!!!!!!!");
				clientVO.setClientStatus(-999);
				return clientVO;
			}
			String redirectUrl = StringUtils.defaultString(clientVO.getRedirectUrl());
			if ("".equals(redirectUrl)) {
				System.out.println("파라미터에 redirectUrl 없음!!!!!!!!!!!!!");
				clientVO.setClientStatus(-999);
				return clientVO;
			}
			
			// Get the realm resource
	        RealmResource realmResource = adminKeycloak.realm(tangoRealm);
	        
	        // Get the ClientsResource for the realm
	        ClientsResource clientsResource = realmResource.clients();
	        
//	        ClientRepresentation existClientRepresentation = clientsResource.findByClientId(systmId).get(0);
	        // Client exist check.....
	        // Find the client by ID
	        List<ClientRepresentation> existClientRepresentationList = clientsResource.findByClientId(systmId); 
	        if (CollectionUtils.isEmpty(existClientRepresentationList)) {
	        	// Create a new client representation
		        ClientRepresentation newClientRepresentation = new ClientRepresentation();
		        newClientRepresentation.setClientId(systmId);
		        newClientRepresentation.setName(systmNm);
		        newClientRepresentation.setPublicClient(false);
		        newClientRepresentation.setEnabled(true);
		        newClientRepresentation.setStandardFlowEnabled(true);
		        newClientRepresentation.setDirectAccessGrantsEnabled(true);
		        newClientRepresentation.setFrontchannelLogout(true);
		        
		        List<String> redirectUris = new ArrayList<String>();
		        redirectUris.add(redirectUrl);
		        newClientRepresentation.setRedirectUris(redirectUris);
		        
		        List<String> webOrigins = new ArrayList<String>();
		        webOrigins.add("*");
		        newClientRepresentation.setWebOrigins(webOrigins);
	        	
		        // Create client...
		        Response response = clientsResource.create(newClientRepresentation);
		        
		        // Check if the client creation was successful
		        int returnVal = response.getStatus();
		        if (returnVal == 201) {
		        	clientVO.setClientStatus(200);
		        } else {
		        	clientVO.setClientStatus(response.getStatus());
		        }
				
	        } else {
	        	List<String> redirectUris = new ArrayList<String>();
		        redirectUris.add(redirectUrl);
		        
		        ClientRepresentation existClientRepresentation = existClientRepresentationList.get(0);
		        existClientRepresentation.setName(systmNm);
		        existClientRepresentation.setRedirectUris(redirectUris);

	            // Update the client
		        ClientResource clientResource = clientsResource.get(existClientRepresentation.getId());
		        clientResource.update(existClientRepresentation);
		        clientVO.setClientStatus(200);
	        }
		} catch (Exception e) {
			// create Client Exception 발생...
			clientVO.setClientStatus(-300);
		}

	    return clientVO;
	}
	
//	public ClientVO modifyClient(ClientVO clientVO) {
//		
//		try {
//			String systmId = StringUtils.defaultString(clientVO.getSystmId());
//			if ("".equals(systmId)) {
//				System.out.println("파라미터에 systmId 없음!!!!!!!!!!!!!");
//				clientVO.setClientStatus(-999);
//				return clientVO;
//			}
//			String systmNm = StringUtils.defaultString(clientVO.getSystmNm());
//			if ("".equals(systmNm)) {
//				System.out.println("파라미터에 systmNm 없음!!!!!!!!!!!!!");
//				clientVO.setClientStatus(-999);
//				return clientVO;
//			}
//			String redirectUrl = StringUtils.defaultString(clientVO.getRedirectUrl());
//			if ("".equals(redirectUrl)) {
//				System.out.println("파라미터에 redirectUrl 없음!!!!!!!!!!!!!");
//				clientVO.setClientStatus(-999);
//				return clientVO;
//			}
//			
//			// Get the realm resource
//	        RealmResource realmResource = adminKeycloak.realm(tangoRealm);
//	        
//	        // Get the ClientsResource for the realm
//	        ClientsResource clientsResource = realmResource.clients();
//	        
//	        // Client exist check.....
//	        // Find the client by ID
//	        ClientRepresentation clientRepresentation = clientsResource.findByClientId(systmId).get(0);
//	        if (clientRepresentation == null) {
//	        	clientVO.setClientStatus(-401);
//				return clientVO;
//	        }
//	        
//	        List<String> redirectUris = new ArrayList<String>();
//	        redirectUris.add(redirectUrl);
//	        
//	        clientRepresentation.setName(systmNm);
//	        clientRepresentation.setRedirectUris(redirectUris);
//
//            // Update the client
//	        ClientResource clientResource = clientsResource.get(clientRepresentation.getId());
//	        clientResource.update(clientRepresentation);
//	        clientVO.setClientStatus(200);
//	        
//		} catch (Exception e) {
//			// modify Client Exception 발생...
//			clientVO.setClientStatus(-400);
//			return clientVO;
//		}
//
//	    return clientVO;
//	}
	
	
	public ClientVO removeClient(ClientVO clientVO) {
		
		try {
			String systmId = StringUtils.defaultString(clientVO.getSystmId());
			if ("".equals(systmId)) {
				System.out.println("파라미터에 systmId 없음!!!!!!!!!!!!!");
				clientVO.setClientStatus(-999);
				return clientVO;
			}
			
			// Get the realm resource
	        RealmResource realmResource = adminKeycloak.realm(tangoRealm);
	        
	        // Get the ClientsResource for the realm
	        ClientsResource clientsResource = realmResource.clients();
	        
	        // Client Not Found.....
	        ClientRepresentation clientRepresentation = clientsResource.findByClientId(systmId).get(0);
	        if (clientRepresentation == null) {
	        	clientVO.setClientStatus(-401);
				return clientVO;
	        }
	        
	        // Delete the client
            clientsResource.get(clientRepresentation.getId()).remove();
	        clientVO.setClientStatus(200);
	        
		} catch (Exception e) {
			// remove Client Exception 발생...
			clientVO.setClientStatus(-400);
			return clientVO;
		}

	    return clientVO;
	}
	

}
