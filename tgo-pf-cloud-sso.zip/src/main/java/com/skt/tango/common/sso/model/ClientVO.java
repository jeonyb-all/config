package com.skt.tango.common.sso.model;

import lombok.Data;

@Data
public class ClientVO {
	private String systmId;
	private String systmNm;
	private String redirectUrl;
	private int clientStatus;

}
