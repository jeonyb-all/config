package com.skt.tango.common.sso.model;

import com.fasterxml.jackson.annotation.JsonInclude;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class SsoVO {
	@JsonInclude(JsonInclude.Include.ALWAYS)
	private String userId = "";
	@JsonInclude(JsonInclude.Include.ALWAYS)
	private String userNm = "";
	private String userPwd;
	private String userPwdEx;
	@JsonInclude(JsonInclude.Include.ALWAYS)
	private String orgId = "";
	@JsonInclude(JsonInclude.Include.ALWAYS)
	private String orgNm = "";
	private int tdayLginFailNcnt = 0;
	/** 비빌번호변경 Flag */
	private String pwdChgFlag;
	/** 임시계정만료 Flag */
	private String vldEndDtFlag;
	/** 미사용자 Flag */
	private String lastLginShotFlag;
	/** 사용자 상태코드 */
	private String userStatCd;
	/** 계정유형코드 */
	private String userAcntgTypCd;
	/** 로그인 불가여부 */
	private String lginImpYn;
	@JsonInclude(JsonInclude.Include.ALWAYS)
	private int loginUserStatus = 0;
	/** 접속 IP 주소 */
	private String cnntIpAddr;
	/** 최종 로그인 IP 주소 */
	private String lastLginpAddr;
	/** 로그인 접속 구분코드(웹, 모바일) */
	private String authAcssDivCd;
	@JsonInclude(JsonInclude.Include.ALWAYS)
	private String tokenId = "";
	private String authMthdDivCd;
	private String systmId;
	private String celpTlno;
	@JsonInclude(JsonInclude.Include.ALWAYS)
	private String emailAddr = "";
	@JsonInclude(JsonInclude.Include.ALWAYS)
	private String uprOrgId = "";
	@JsonInclude(JsonInclude.Include.ALWAYS)
	private String uprOrgNm = "";
	@JsonInclude(JsonInclude.Include.ALWAYS)
	private String lastPwdChgDate = "";
	@JsonInclude(JsonInclude.Include.ALWAYS)
	private String bpId = "";
	@JsonInclude(JsonInclude.Include.ALWAYS)
	private String bpNm = "";
	
	
}
