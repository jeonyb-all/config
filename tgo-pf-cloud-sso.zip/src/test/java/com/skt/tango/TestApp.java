package com.skt.tango;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.TimeZone;

public class TestApp {
	
	public static void main(String[] args) {
		String aaa = "1708495157";			// 2024-02-21 02:59:17 : exp
//		String aaa = "1708494857";			// 2024-02-21 02:54:17 : iat
		long bbb = Long.parseLong(aaa);
		Date date = new Date();
		date.setTime(bbb * 1000);
//		date.setTime(bbb);
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");
		sdf.setTimeZone(TimeZone.getTimeZone("Asia/Seoul"));
		System.out.println("[date] : " + String.valueOf(sdf.format(date)));
	}

}
